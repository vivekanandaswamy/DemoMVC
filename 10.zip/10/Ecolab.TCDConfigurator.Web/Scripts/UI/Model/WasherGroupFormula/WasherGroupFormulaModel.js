Ecolab.Model.WasherGroupFormulaModel = function (options) {
	var defaultOptions = {
		eventHandlers: {
			onWasherGroupDataLoad: function () { },
			onFormulaDataLoad: function () { },
			onGetAddFormulaDataRecieved: null,
			onGetEditFormulaDataRecieved: null,
			onGetImportFormulaDataRecieved: null,
			onFormulaUpdated: null,
			onFormulaCreated: null,
			onCopyFormulaCreated: null,
			onFormulaCreationFailed: function () { },
			onCopyFormulaCreationFailed: function () { },
			onGetChainFormulaNames: function () { },
			onGetChainFormulaData: function () { },
			onWasherFormulaUpdateSuccess: function () { },
			onWasherFormulaUpdateFailed: function () { },
			onWasherFormulaSaveSuccess: function () { },
			onWasherFormulaSaveFailed: function () { },
			//onFormulaDataLoad: function () { },
			onWasherGroupFormulaDeleted: function () { },
			onWasherGroupWashStepDeleted: function () { },
			onWasherGroupFormulaDeletionFailed: function () { },
			onWasherGroupCreated: function () { },
			onWasherGroupCreationFailed: function () { },
			onFormulaUpdationFailed: function () { },
			onInlineFormulaUpdated: function () { },
			onInlineFormulaUpdationFailed: function () { },
			onWasherGroupUpdated: function () { },
			// Wash step call back methods
			onWashStepDataLoad: function () { },
			onCopyWashStepDataLoad: function () { },
			onWashStepCreationSuccess: function () { },
			onWashStepCreationFailed: function () { },
			//Tunnel Wash Step call back methods
			onTunnelWashStepSetData: function () { },
			onTunnelGridViewSetData: function () { },
			onTunnelGridSuccess: function () { },
			onTunnelGridFailed: function () { },
			onWasherDeleted: function () { },
			onWasherDeletionFailed: function () { },
			onSaveFormulaDetailsToPLC: function () { },
			onSaveFormulaDetailsToPLCFailed: function () { },

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			///             Covetional WashStep Product GridView functions                   ///
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			onProdutsDataRecieved: function () { },
			onProdcutsDataRecieveFailed: function () { },
			onproductsgridViewDataSuccess: function () { },
			onproductsgridViewDataFailed: function () { },


			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			///             Covetional WashStep GridView functions                   ///
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			onWashStepgridViewDataSuccess: function () { },
			onWashStepgridViewDataFailed: function () { },
			onProductGridViewRefreshDataRecieved: function () { },
			onDropDownChangeFormulaUpdated: function () { },
			onChangeDropDownWashStepgridViewDataSuccess: function () { },
			onGetCompareFormulaData: function () { },
			onGetCompareFormulaDataFailed: function () { },
			onGetDispenserAndFormulaChangeData: function () { },
			onGetDispenserAndFormulaChangeDataFailed: function () { },
			onSaveSettingsSuccess: function () { },
			onSaveSettingsFailed: function () { },
			onFindMissingChemicals: function () { },
			onGroupFormulaMoveupdated: function () { },
			onGroupFormulaMoveUpdationFailed: function () { }
		}
	};

	this.settings = $.extend(defaultOptions, options);
	this.WasherGroupFormulaModelProxy = new Ecolab.Model.WasherGroupFormulaModelProxy();
}

Ecolab.Model.WasherGroupFormulaModel.prototype = {
	init: function () { },

	//Passing the data from the model proxy to set the washer groups.
	loadAddEditWasherGroupModelData: function (washergroupId, accountNumber, regionId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.loadAddEditWasherGroupModelData(washergroupId, accountNumber, regionId,
            function (washergroupData) { // callback method
            	_this.settings.eventHandlers.onWasherGroupDataLoad(washergroupData);
            });
	},
	//Passing the data from the model proxy to set the washer groups.
	loadWasherGroupModelData: function (washergroupId, accountNumber) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.loadWasherGroupModelData(washergroupId, accountNumber, function (washergroupsData) { _this.settings.eventHandlers.onFormulaDataLoad(washergroupsData); });
	},
	GetAddFormula: function (ecolabAccountNumber, washerGroupId, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetAddFormula(ecolabAccountNumber, washerGroupId, regionId, function (data) {
			_this.settings.eventHandlers.onGetAddFormulaDataRecieved(data);
		});
	},
	GetImportFormula: function (ecolabAccountNumber, washerGroupId, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetImportFormula(ecolabAccountNumber, washerGroupId, regionId, function (data) {
			_this.settings.eventHandlers.onGetImportFormulaDataRecieved(data);
		});
	},
	//For Saving New Formula
	createFormula: function (FormulaData, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.createFormula(FormulaData,
            function (data) {
            	var FormulaId = data;
            	_this.settings.eventHandlers.onFormulaCreated(FormulaId, FormulaData, isSaveAndClose);
            },
            function (error, description) { //Error callback method 
            	_this.settings.eventHandlers.onFormulaCreationFailed(error, description);
            });
	},
	SaveCopyFormula: function (FormulaData) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.SaveCopyFormula(FormulaData,
			function (data) {
				var FormulaId = data;
				_this.settings.eventHandlers.onCopyFormulaCreated(FormulaId);
			},
			function (error, description) { //Error callback method 
				_this.settings.eventHandlers.onCopyFormulaCreationFailed(error, description);
			});
	},
	updateFormula: function (FormulaData, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.updateFormula(FormulaData, function (data) {
			_this.settings.eventHandlers.onFormulaUpdated(data, FormulaData, isSaveAndClose);
		},
        function (error, description) { //Error callback method 
        	_this.settings.eventHandlers.onFormulaUpdationFailed(error, description);
        });
	},
	updateInlineFormula: function (FormulaData) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.updateFormula(FormulaData, function (data) {
			_this.settings.eventHandlers.onInlineFormulaUpdated(data);
		},
        function (error, description) { //Error callback method 
        	_this.settings.eventHandlers.onInlineFormulaUpdationFailed(error, description);
        });
	},
	//Events is for deleting the washer group.
	onDeleteWasherGroupClicked: function (washerGroupData) {
		var _this = this;
		//passing washergroupId
		this.WasherGroupModelProxy.onDeleteWasherGroupClicked(washerGroupData,
            function (WasherGroupData) { //Callback method
            	_this.settings.eventHandlers.onWasherGroupFormulaDeleted(WasherGroupData);
            },
            function (error, description) { //Error callback method 
            	_this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
	},
	// Event for saving the washer group data 
	createWasherGroup: function (washergroupData, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.createWasherGroup(washergroupData, function (responseData) {
			_this.settings.eventHandlers.onWasherGroupCreated(responseData, isSaveAndClose);
		},
		function (error, description) { //Error callback method 
			_this.settings.eventHandlers.onWasherGroupCreationFailed(error, description);
		}
	);
	},

	saveFormulaDetailsToPLC: function (EcolabAccountNumber, WasherGroupId) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.saveFormulaDetailsToPLC(EcolabAccountNumber, WasherGroupId, function (data) {
	        _this.settings.eventHandlers.onSaveFormulaDetailsToPLC(data);
	    },
        function (errorData, description) { //Error callback method 
            _this.settings.eventHandlers.onSaveFormulaDetailsToPLCFailed(errorData, description);
        });
	},

	// Event for updating the washer group details
	UpdateWasherGroup: function (washergroupData, accountNumber, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.updateWasherGroup(washergroupData, accountNumber, function (responseData) {
			_this.settings.eventHandlers.onWasherGroupUpdated(responseData, isSaveAndClose);
		},
        function (error, description) { //Error callback method 
        	_this.settings.eventHandlers.onWasherGroupCreationFailed(error, description);
        });
	},

	//Events is for deleting the washer group.
	onDeleteFormulaListClicked: function (FormulaData) {
		var _this = this;
		//passing washergroupId
		this.WasherGroupFormulaModelProxy.onDeleteFormulaListClicked(FormulaData,
            function (FormulaData, responseData) { //Callback method
                _this.settings.eventHandlers.onWasherGroupFormulaDeleted(FormulaData, responseData);
            },
            function (error, description) { //Error callback method 
            	_this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
	},
	WashStepDelete: function (washStepData) {
		var _this = this;
		//passing washergroupId
		this.WasherGroupFormulaModelProxy.WashStepDelete(washStepData,
            function (washStepDelete) { //Callback method
            	_this.settings.eventHandlers.onWasherGroupWashStepDeleted(washStepDelete);
            },
            function (error, description) { //Error callback method 
            	_this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
	},
	GetEditFormula: function (washerGroupId, id, ecolabAccountNumber, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetEditFormula(washerGroupId, id, ecolabAccountNumber, regionId, function (data) {
			_this.settings.eventHandlers.onGetEditFormulaDataRecieved(data);
		});
	},
	GetEditWashStep: function (washerGroupId, id, formulaId, ecolabAccountNumber, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetEditWashStep(washerGroupId, id, formulaId, ecolabAccountNumber, regionId, function (washSetupData) {
			_this.settings.eventHandlers.onWashStepDataLoad(washSetupData);
		});
	},
	GetCopyWashStep: function (washerGroupId, id, formulaId, ecolabAccountNumber, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetEditWashStep(washerGroupId, id, formulaId, ecolabAccountNumber, regionId, function (washSetupData) {
			_this.settings.eventHandlers.onCopyWashStepDataLoad(washSetupData);
		});
	},

	GetChainFormulaNames: function (plantChainId, callBackData) {
	    var _this = this;
	    var data1 = {};
	    data1.PlantChainId = plantChainId;
	    this.WasherGroupFormulaModelProxy.GetChainFormulaNames(plantChainId, function (chainFormulaNames) {
                data1.ChainFormulaNames = chainFormulaNames;
                _this.settings.eventHandlers.onGetChainFormulaNames(data1);
	    },
             
        function (error, description) {
            _this.settings.eventHandlers.onGetChainFormulaNamesFialedDetails(error, description);
        });
	},

	LoadDropDownData: function (plantChainId, callBackData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.LoadDropDownData(plantChainId,
            function (formulaDropDownData) {
                _this.settings.eventHandlers.onLoadDropDownDataLoaded(formulaDropDownData);
            });
	},

	GetPlantChainId: function (ecolabAccountNumber, callBackData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.GetPlantChainId(ecolabAccountNumber, function (plantChainId) {
	        _this.settings.eventHandlers.onGetPlantChainIdLoaded(plantChainId);
            });
	},

	loadFormulaData: function (callBackData) {
	    var _this = this;
	    var programId = 0;
	    this.WasherGroupFormulaModelProxy.loadFormulaData(programId,
            function (formulaData) {
                _this.settings.eventHandlers.onFormulaDataLoaded(formulaData);
            });
	},

	getChainFormulaData: function (plantProgramId, callBackData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.getChainFormulaData(plantProgramId,
            function (chainFormulaData) {
                _this.settings.eventHandlers.onGetChainFormulaData(chainFormulaData);
            });
	},

	onWasherFormulaUpdate: function (data) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.onWasherFormulaUpdate(data, function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onWasherFormulaUpdateSuccess(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherFormulaUpdateFailed(error, description);
            });
	},

	onWasherFormulaSave: function (formulaData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.onWasherFormulaSave(formulaData, function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onWasherFormulaSaveSuccess(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherFormulaSaveFailed(error, description);
            });
	},

	//Event for sending request to load wash step data
	loadWashStepModelData: function (washerGroupId, accountNumber, formulaId, regionId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.loadWashStepModelData(washerGroupId, accountNumber, formulaId, regionId,
            function (washSetupData) { // callback method
            	_this.settings.eventHandlers.onWashStepDataLoad(washSetupData);
            });
	},
	saveWashStep: function (washdata, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.saveWashStep(washdata,
            function (responseData) {
            	_this.settings.eventHandlers.onWashStepCreationSuccess(responseData, isSaveAndClose);
            },
            function (errorData) {
            	_this.settings.eventHandlers.onWashStepCreationFailed(errorData);
            });
	},
	saveTunnelWashStep: function (washdata, regionId, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.saveTunnelWashStep(washdata, regionId,
            function (responseData) {
            	_this.settings.eventHandlers.onTunnelWashStepCreationSuccess(responseData, isSaveAndClose);
            },
            function (errorData, description) {
            	_this.settings.eventHandlers.onTunnelWashStepCreationFailed(description);
            });
	},
	loadChemicals: function (request, callBack) {
		this.WasherGroupFormulaModelProxy.loadChemicals(request, callBack);
	},
	loadTunneWashStep: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.loadTunneWashStep(formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId,
            function (reponse) { _this.settings.eventHandlers.onTunnelWashStepSetData(reponse); });
	},
	loadTunnelGridViewDetails: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupId, regionId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.loadTunnelGridViewDetails(formulaId, ecolabAccountNumber, compartmentNumber, washerGroupId, regionId,
            function (reponse) { _this.settings.eventHandlers.onTunnelGridViewSetData(reponse); });
	},
	saveTunnelWashStepGrid: function (washdata, regionId, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.saveTunnelWashStep(washdata, regionId,
            function (responseData) {
            	_this.settings.eventHandlers.onTunnelGridSuccess(responseData, isSaveAndClose);
            },
            function (errorData, description) {
            	_this.settings.eventHandlers.onTunnelGridFailed(description);
            });
	},
	onDeleteWasher: function (isTunnel, id, ecolabAccountNumber, washerGroupId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.onDeleteWasher(isTunnel, id, ecolabAccountNumber, washerGroupId, function (data) {
			_this.settings.eventHandlers.onWasherDeleted(data);
		},
            function (error, description) { //Error callback method 
            	_this.settings.eventHandlers.onWasherDeletionFailed(error, description);
            });
	},

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///             Covetional WashStep Product GridView functions                   ///
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// save formula injections gridview data
	onSaveFormulaInjections: function (productsgridViewData, isSaveandClose, formulaId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.onSaveFormulaInjections(productsgridViewData,
            function (responseData) {
            	_this.settings.eventHandlers.onproductsgridViewDataSuccess(responseData, isSaveandClose, formulaId);
            },
            function (errorData) {
            	_this.settings.eventHandlers.onproductsgridViewDataFailed(errorData, formulaId);
            });
	},
	onProductsViewCliked: function (washerGroupId, id, ecolabAccountNumber, regionId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.onProductsViewCliked(washerGroupId, id, ecolabAccountNumber, regionId,
           function (responseData) {
           	_this.settings.eventHandlers.onProdutsDataRecieved(responseData);
           },
           function (errorData) {
           	_this.settings.eventHandlers.onProdcutsDataRecieveFailed(errorData);
           });
	},
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///             Covetional WashStep GridView functions                   ///
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// save wash step grid view
	onSaveWashSteps: function (washStepData, formulaId, isSaveAndClose) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.onSaveWashSteps(washStepData,
            function (responseData) {
            	_this.settings.eventHandlers.onWashStepgridViewDataSuccess(responseData, formulaId, isSaveAndClose);
            },
            function (error, description) {
            	_this.settings.eventHandlers.onWashStepgridViewDataFailed(description);
            });
	},
	ProductGridViewRefresh: function (washerGroupId, id, ecolabAccountNumber, regionId) {
		var _this = this;

		this.WasherGroupFormulaModelProxy.GetEditFormula(washerGroupId, id, ecolabAccountNumber, regionId, function (data) {
			_this.settings.eventHandlers.onProductGridViewRefreshDataRecieved(data);
		});
	},

	updateFormulaOnDropDownChange: function (FormulaData) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.updateFormula(FormulaData, function (data) {
			_this.settings.eventHandlers.onDropDownChangeFormulaUpdated(data, FormulaData);
		});
	},

	onChangeDropDownSaveWashSteps: function (washStepData, formulaId) {
		var _this = this;
		this.WasherGroupFormulaModelProxy.onSaveWashSteps(washStepData,
            function (responseData) {
            	_this.settings.eventHandlers.onChangeDropDownWashStepgridViewDataSuccess(responseData, formulaId, isSaveAndClose);
            },
            function (errorData) {
            	_this.settings.eventHandlers.onWashStepgridViewDataFailed(errorData);
            });
	},
	getCompareFormulaData: function (washerGroupId, formulaId) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.getCompareFormulaData(washerGroupId,formulaId,
            function (responseData) {
                _this.settings.eventHandlers.onGetCompareFormulaData(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onGetCompareFormulaDataFailed(errorData);
            });
	},
	getDispenserAndFormulaChangeData: function (formulaId, controllerId, washerGroupId, washerId) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.getDispenserAndFormulaChangeData(formulaId, controllerId,washerGroupId,washerId,
            function (responseData) {
                _this.settings.eventHandlers.onGetDispenserAndFormulaChangeData(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onGetDispenserAndFormulaChangeDataFailed(errorData);
            });
	},
	onSaveSettings: function (formulaId, controllerId, washerGroupId, washerId) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.onSaveSettings(formulaId, controllerId, washerGroupId,washerId,
            function (responseData) {
                _this.settings.eventHandlers.onSaveSettingsSuccess(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onSaveSettingsFailed(errorData);
            });
	},
	findMissingChemicals: function (importFormulaData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.findMissingChemicals(importFormulaData,
			function (data) {			   
			    _this.settings.eventHandlers.onFindMissingChemicals(data);
			},
			function (error, description) { //Error callback method 
			    _this.settings.eventHandlers.onCopyFormulaCreationFailed(error, description);
			});
	},
	onMoveFormulaFromGroupOne: function (washerGroupData) {
	    var _this = this;
	    this.WasherGroupFormulaModelProxy.onMoveFormulaFromGroupOne(washerGroupData,
            function (responseData) {
                _this.settings.eventHandlers.onGroupFormulaMoveupdated(responseData);
            },
        function (error, description) { //Error callback method 
            _this.settings.eventHandlers.onGroupFormulaMoveUpdationFailed(error, description);
        });
	},
}