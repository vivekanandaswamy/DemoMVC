Ecolab.Model.WasherGroupFormulaModelProxy = function () {
};

Ecolab.Model.WasherGroupFormulaModelProxy.prototype = {
    // event is for getting the washer groups from API controller.
    loadWasherGroupModelData: function (washergroupId, accountNumber, callBack) {
        var url = "/Api/WasherGroupFormula/GetWasherGroupFormula";

        // Passing parameter  to Api .
        var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber};

        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    loadAddEditWasherGroupModelData: function (washergroupId, accountNumber,regionId, callBack) {
        if (washergroupId != null) {
            // Api Url for retrive data.
            var url = "/Api/WasherGroupFormula/GetWasherGroupWithWasherDetails";

            // assigning the required data to the Api.
            var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber, "pageNumber": 0, "numberOfRecordsPerpage": 0, "sortColumn": '', "regionId": regionId };

            this.ApiRead("WasherGroup", url, function (response) { callBack(response); }, null, null, requestData);
        }
        else {
            return false;
        }
    },
    //Event for calling the Api method for deleting the washergroup based on the requested id.
    onDeleteWasherGroupClicked: function (washerGroupData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "/Api/WasherGroupFormula/DeleteWasherGroupFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupData);
    },
    WashStepDelete: function (WashStepData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "/Api/WasherGroupFormula/DeleteWasherGroupFormulaWashStep";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, WashStepData);
    },
    // Event for Api to create a new washer group
    createWasherGroup: function (washerGroupWebData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/CreateWasherGroup";
        //var requestData = {washerGroupWebData,'1' };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupWebData);
    },

    // Event for Api to Send Formulas to PLC
    saveFormulaDetailsToPLC: function (ecolabAccountNumber, washerGroupId, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/SaveFormulasToPLC";
        var requestData = { "EcolabAccountNumber": ecolabAccountNumber, "WasherGroupId": washerGroupId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    // Event for Api to update the washer group details.
    updateWasherGroup: function (washerGroupWebData, accountNumber, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupWebData);
    },

    //Event for calling the Api method for deleting the washergroup based on the requested id.
    onDeleteFormulaListClicked: function (FormulaData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "/Api/WasherGroupFormula/DeleteWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(FormulaData, response); }, function (data, exception) { errorCallBack(data, exception); }, null, FormulaData);
    },
    GetAddFormula: function (ecolabAccountNumber, washerGroupId, regionId, callBack) {
        var url = "Api/WasherGroupFormula/GetAddFormulaDetails";
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber, "WasherGroupId": washerGroupId, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetImportFormula: function (ecolabAccountNumber, washerGroupId, regionId, callBack) {
    	var url = "/Api/WasherGroupFormula/GetImportFormulaDetails";
    	var requestData = { "ecolabAccountNumber": ecolabAccountNumber, "WasherGroupId": washerGroupId, "regionId": regionId };
    	this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    createFormula: function (requestData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/createFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    SaveCopyFormula: function (requestData, callBack, errorCallBack) {
    	var url = "/Api/WasherGroupFormula/SaveCopyFormula";
    	this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateFormula: function (requestData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateWasherGroupFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); },null, requestData);
    },
    GetEditFormula: function (washerGroupId, id, ecolabAccountNumber, regionId, callBack) {
            var url = "/Api/WasherGroupFormula/GetEditFormulaDetails";
            var requestData = { "washerGroupId": washerGroupId, "programSetupId": id, "ecolabAccountNumber": ecolabAccountNumber, "regionId" :regionId };
            this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetEditWashStep: function (WasherGroupId, id,FormulaId, ecolabAccountNumber,regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetEditFormulaWashStepDetails";
        var requestData = { "washerGroupId": WasherGroupId, "programSetupId": FormulaId, "dosingSetupId": id, "ecolabAccountNumber": ecolabAccountNumber, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },

    //******************************//

    // event is for getting the wash steps data from API controller.
    loadWashStepModelData: function (washergroupId, accountNumber, formulaId, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetWashStepDetails";

        // Passing parameter  to Api .
        var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber, "formulaId": formulaId,"regionId":regionId };

        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },

    // Event for saving wash step for a formula
    saveWashStep: function (washerGroupFormulaWashStep, callBack, errorCallBack) {
        //var url = "/Api/WasherGroupFormula/SaveWasherGroupFormulaWashSteps";
        var url = "/Api/WasherGroupFormula/SaveConventionalWashStepGridView";
        //var washerGroupFormulaWashStep = washerGroupFormulaWashStep;
        //var requestData = { "washerGroupFormulaWashStep": washerGroupFormulaWashStep, "regionId": regionId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (response) { errorCallBack(response); }, null, washerGroupFormulaWashStep,null,false);
    },
    // Event for saving wash step for a formula
    saveTunnelWashStep: function (tunnelStepData, regionId, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateTunnelStep";
        //var requestData = { "tunnelStepData": tunnelStepData, "regionId": regionId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, tunnelStepData);
    },
    loadChemicals: function (request, callBack, errorCallBack) {
        var url = "/api/WasherGroupFormula/GetChemicalList";
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, request);
    },
    loadTunneWashStep: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetTunnelDetails";
        var request = { "programSetupId": formulaId, "ecoalabAccountNumber": ecolabAccountNumber, "dosingSetupId": compartmentNumber, "washerGroupId": washerGroupOutPutId, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, request);
    },
    loadTunnelGridViewDetails: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetTunnelGridDetails";
        var request = { "programSetupId": formulaId, "ecoalabAccountNumber": ecolabAccountNumber, "dosingSetupId": compartmentNumber, "washerGroupId": washerGroupOutPutId, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, request);
    },
    onDeleteWasher: function (isTunnel, id, ecolabAccountNumber,washerGroupId, callBack, errorCallBack) {
        var requestData = { "washerId": parseInt(id), "isTunnel": isTunnel, "ecolabAccountNumber": ecolabAccountNumber, "washerGroupId": washerGroupId };
        var url = "/Api/Washer/WasherDelete";
        this.ApiRead("Washer", url, function (response) { callBack(response); }, null, null, requestData);
    },

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///             Covetional WashStep Product GridView functions                   ///
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // save formula injections gridview data
    onSaveFormulaInjections: function (productsgridViewData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateConventionalWashStepInjections";
        var washerGroupFormulaWashStep = productsgridViewData;
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) {
            errorCallBack(data, exception);
        }, null, washerGroupFormulaWashStep, null, true);
    },
    onProductsViewCliked: function (washerGroupId, id, ecolabAccountNumber, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetEditFormulaDetails";
        var requestData = { "washerGroupId": washerGroupId, "programSetupId": id, "ecolabAccountNumber": ecolabAccountNumber, "regionId" :regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, function (response) { errorCallBack(response); }, null, requestData);
    },
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                  ///             Covetional WashStep GridView functions                   ///
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // save formula injections gridview data
    onSaveWashSteps: function (washStepData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/SaveConventionalWashStepGridView";
        var washerGroupFormulaWashStep = washStepData;
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupFormulaWashStep,null,false);
    },
    getCompareFormulaData: function (washerGroupId, formulaId, callBack, errorCallBack) {
        var url = "CompareFormula/Index";
        var requestData = { "washerGroupId": washerGroupId, "formulaId": formulaId };
        
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, null, null, 'html');
    },
    getDispenserAndFormulaChangeData: function (formulaId, controllerId, washerGroupId,washerId, callBack, errorCallBack) {
        var url = "CompareFormula/GetDispenserAndFormulaData";
        var requestData = { "formulaId": formulaId, "controllerId": controllerId, "washerGroupId": washerGroupId ,"washerId" : washerId};
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, null, true, 'html');
    },

    onSaveSettings: function (formulaId, controllerId, washerGroupId,washerId, callBack, errorCallBack) {
        var url = "CompareFormula/WriteSettingsToPlc";
        var requestData = { "formulaId": formulaId, "controllerId": controllerId, "washerGroupId": washerGroupId, "washerId": washerId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, null, null, 'html');
    },
    findMissingChemicals: function (requestData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/FindMissingChemical";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    GetChainFormulaNames: function (plantChainId, callBack, errorCallBack) {
        var url = "Api/PlantFormula/GetChainFormulaNames";
        var requestData = { "plantChainId": plantChainId };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data1, exception) { errorCallBack(data1, exception); }, null, requestData);
    },
    LoadDropDownData: function (plantChainId, callBack) {
        var requestData = { "plantChainId": plantChainId };
        var url = "Api/PlantFormula/GetFormulaForDropDown";
        this.ApiRead("Formula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    loadFormulaData: function (programId, callBack) {
        var requestData = { "programId": programId };
        var url = "Api/PlantFormula/GetFormula";
        this.ApiRead("Formula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetPlantChainId: function (ecolabAccountNumber, callBack) {
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber };
        var url = "Api/WasherGroupFormula/GetPlantChainId";
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    getChainFormulaData: function (plantProgramId, callBack) {
        var url = "Api/PlantFormula/GetChainFormulaData";
        var requestData = { "plantProgramId": plantProgramId };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    onWasherFormulaUpdate: function (data, callBack, errorCallBack) {
        var url = "Api/PlantFormula/Put";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    },
    onWasherFormulaSave: function (formulaData, callBack, errorCallBack) {
        var url = "Api/PlantFormula/CreateFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, formulaData);
    },
    //Event for calling the Api method for updating the washergroup formula
    onMoveFormulaFromGroupOne: function (washerGroupData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "/Api/WasherGroupFormula/UpdateWasherFormulaFromGroupOne";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupData);
    },
}

var base = new Ecolab.Model.Common();
Ecolab.Model.WasherGroupFormulaModelProxy.prototype = $.extend({}, Ecolab.Model.WasherGroupFormulaModelProxy.prototype, base);
Ecolab.Model.WasherGroupFormulaModelProxy.prototype.base = base;