Ecolab.Model.ControllerSetupModel = function (options) {
    //  this.NumberOfItems = 0;
    var defaultOptions = {
        eventHandlers: {
            onGetMetaDataReceived: null,
            onMetaDataSaved: null,
            onMetaDataSavedFailed : null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ControllerSetupModelProxy = new Ecolab.Model.ControllerSetupModelProxy();
};

Ecolab.Model.ControllerSetupModel.prototype = {
    init: function () {
    },
    getMetaData: function (controllerModelId, controllerTypeId, tab) {
        var _this = this;
        this.ControllerSetupModelProxy.getMetaData(controllerModelId, controllerTypeId, tab, function (metaData) {
            _this.onGetMetaDataReceived(metaData);
        });
    },
    getMetaDataWithValues: function (controllerId, tab) {
        var _this = this;
        this.ControllerSetupModelProxy.getMetaDataWithValues(controllerId, tab, function (metaData) {
            _this.onGetMetaDataWithValuesReceived(metaData);
        });
    },
    getGeneralMetaDataWithValues: function (controllerId, tab) {
        var _this = this;
        this.ControllerSetupModelProxy.getMetaDataWithValues(controllerId, tab, function (metaData) {
            _this.onGetGeneralMetaDataWithValuesReceived(metaData);
        });
    },
    saveMetaData: function (metaDatatoSave, isSaveAndClose) {
        var _this = this;
        this.ControllerSetupModelProxy.saveMetaData(metaDatatoSave,
            function (data) { _this.onMetaDataSaved(data, isSaveAndClose); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    updateMetaData: function (metaDatatoSave, isSaveAndClose) {
        var _this = this;
        this.ControllerSetupModelProxy.updateMetaData(metaDatatoSave,
            function () { _this.onMetaDataSaved(null,isSaveAndClose); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    loadControllerModelData: function (regionId, callBackData) {
        var _this = this;
        this.ControllerSetupModelProxy.loadControllerModelData(regionId, function (ControllerSetupData) {
            _this.onDataLoaded(ControllerSetupData, callBackData);
        });       
    },
    loadControllerTypeData: function (controllerModelId, callBackData) {
        var _this = this;
        this.ControllerSetupModelProxy.loadControllerTypeData(controllerModelId, function (ControllerTypeData) {
            _this.onControllerTypeDataLoaded(ControllerTypeData, callBackData);
        });
    },
    getControllerUIData:function(controllerId, callBackData){
        var _this=this;
        this.ControllerSetupModelProxy.getControllerUIData(controllerId, function (ControllerSetupData) {
            _this.onUIDataLoaded(ControllerSetupData, callBackData);
        });
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onControllerModelDataLoaded(data, callBackData);
    },
    onControllerTypeDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onControllerTypeDataLoaded(data, callBackData);
    },
    onGetMetaDataReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataReceived(metadata);
    },
    onGetMetaDataWithValuesReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataWithValuesReceived(metadata);
    },
    onGetGeneralMetaDataWithValuesReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetGeneralMetaDataWithValuesReceived(metadata);
    },
    onMetaDataSaved: function (data, isSaveAndClose) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSaved(data, isSaveAndClose);
    },
    onMetaDataSavedFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSavedFailed(data, exception);
    }
};

