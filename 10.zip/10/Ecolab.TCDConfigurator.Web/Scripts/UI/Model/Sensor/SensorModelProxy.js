Ecolab.Model.SensorModelProxy = function() {
};

Ecolab.Model.SensorModelProxy.prototype =
{
    loadSensorData: function(callBack, errorCallBack) {
        var url = "/Api/Sensor/GetSensor";
        this.ApiRead("Sensor", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadMachineCompartmentByUtilityLocationId: function(id, callBack, errorCallBack) {
        var url = "/Api/Sensor/GeOnLocationChange/{id}";
        var requestData = { "id": id };
        this.ApiRead("Sensor", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadDefaultData: function(id, callBack, errorCallBack) {
        var url = "/Api/Sensor/GetDefaults/{id}";
        var requestData = { "id": id };
        this.ApiRead("Sensor", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadSensorOnAddNewPopupLoad: function(callBack, errorCallBack) {
        var url = "/Api/Sensor/GetDefaults/{id}";
        this.ApiRead("Sensor", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadUoMProxy: function(id, callBack, errorCallBack) {
        var url = "/Api/Sensor/GeOnSensorTypeChange/{id}";
        var requestData = { "id": id };
        this.ApiRead("Sensor", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnMachineCompartmentChange: function(locationId, machineId, callBack, errorCallBack) {
        var url = "/Api/Sensor/GetOnMachineCompartmentChange";
        var requestData = { "locationId": locationId, "machineId": machineId };
        this.ApiRead("GET", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnControllerChange: function (locationId, machineId,controllerId, callBack, errorCallBack) {
        var url = "/Api/Sensor/GetOnControllerChange";
        var requestData = { "locationId": locationId, "machineId": machineId,"controllerId": controllerId};
        this.ApiRead("GET", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    fetchExternalOrInternalCounters: function (locationId, machineId, sensorId, callBack, errorCallBack) {
        var url = "/Api/Sensor/FetchCounters";
        var requestData = { "locationId": locationId, "washerId": machineId, "sensorId": sensorId };
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }


};

var base = new Ecolab.Model.Common();
Ecolab.Model.SensorModelProxy.prototype = $.extend({}, Ecolab.Model.SensorModelProxy.prototype, base);
Ecolab.Model.SensorModelProxy.prototype.base = base;