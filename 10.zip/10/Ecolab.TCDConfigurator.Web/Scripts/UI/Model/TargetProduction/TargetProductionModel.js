Ecolab.Model.TargetProductionModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onTargetProductionDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.TargetProductionModelProxy = new Ecolab.Model.TargetProductionModelProxy();
};

Ecolab.Model.TargetProductionModel.prototype = {
    init: function () {
    },
    loadTargetProductionData: function (callBackData) {
        var _this = this;
        this.TargetProductionModelProxy.loadTargetProductionData(function (data) {
            _this.settings.eventHandlers.onTargetProductionDataLoaded(data, callBackData);
        });
    },
    updateTargetProductionData: function (laborCostViewModel) {
        var _this = this;
        this.TargetProductionModelProxy.updateTargetProductionData(laborCostViewModel, function (data) {
            _this.settings.eventHandlers.onTargetProductionDataUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onTargetProductionDataUpdationFailed(error, description); });
    }
};

