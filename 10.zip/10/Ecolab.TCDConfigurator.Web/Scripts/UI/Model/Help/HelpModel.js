﻿Ecolab.Model.HelpModel = function (options) {   
    var defaultOptions = {
        eventHandlers: {
            onContactDataLoaded: null,
            onPositionDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);   
};

Ecolab.Model.HelpModel.prototype = {
    init: function () {
    },
    loadHelpData: function (data, callBackData) {
        var _this = this;       
    }
};