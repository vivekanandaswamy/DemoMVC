// JavaScript source code
Ecolab.Model.FinnisherModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onFinnisherGroupDataLoaded: null,
            onFinnisherTypesLoaded: null,
            onFinnisherGroupCreated: null,
            onFinnisherGroupCreationFailed: null,
            onFinnisherGroupUpdated: null,
            onFinnisherGroupUpdationFailed: null,
            onFinnisherGroupDeleted: null,
            onFinnisherGroupDeletionFailed: null,
            onFinnisherCreated: null,
            onFinnisherCreationFailed: null,
            onFinnisherUpdated: null,
            onFinnisherUpdationFailed: null,
            onFinnisherDeleted: null,
            onFinnisherDeletionFailed: null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.FinnisherModelProxy = new Ecolab.Model.FinnisherModelProxy();
};

Ecolab.Model.FinnisherModel.prototype = {
    init: function () {
    },
    addNewFinnisherGroup: function () {
        return {
            FinnisherGroupId: -1,
            FinnisherGroupName: ''
        };
    },
    addNewFinnisher: function (groupId, FinnisherTypes) {
        return {
            GroupId: groupId,
            Number: -1,
            Name: '',
            FinnisherTypeId: -1,
            FinnisherTypeName: '',
            FinnisherTypes: FinnisherTypes,
        };
    },
    loadFinnisherGroupData: function () {
        var _this = this;
        _this.FinnisherModelProxy.loadFinnisherGroupData(function (FinnisherGroupData) {
            _this.settings.eventHandlers.onFinnisherGroupDataLoaded(FinnisherGroupData);
        });
    },
    loadFinnisherTypes: function () {
        var _this = this;
        _this.FinnisherModelProxy.loadFinnisherTypes(function (FinnisherTypes) {
            _this.settings.eventHandlers.onFinnisherTypesLoaded(FinnisherTypes);
        });
    },
    createFinnisherGroup: function (FinnisherGroupData) {
        var _this = this;
        this.FinnisherModelProxy.createFinnisherGroup(FinnisherGroupData, function (data) {
            _this.settings.eventHandlers.onFinnisherGroupCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onFinnisherGroupCreationFailed(error, description); });
    },
    updateFinnisherGroup: function (FinnisherGroupData) {
        var _this = this;
        this.FinnisherModelProxy.updateFinnisherGroup(FinnisherGroupData, function (data) {

            _this.settings.eventHandlers.onFinnisherGroupUpdated(data);
        }, function (error, description) {
            _this.settings.eventHandlers.onFinnisherGroupUpdationFailed(error, description);
        });
    },
    deleteFinnisherGroup: function (FinnisherGroupData) {
        var _this = this;
        this.FinnisherModelProxy.deleteFinnisherGroup(FinnisherGroupData, function (data) {
            _this.settings.eventHandlers.onFinnisherGroupDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onFinnisherGroupDeletionFailed(error, description); });
    },
    createFinnisher: function (FinnisherData) {
        var _this = this;
        this.FinnisherModelProxy.createFinnisher(FinnisherData, function (data) {
            _this.settings.eventHandlers.onFinnisherCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onFinnisherCreationFailed(error, description); });
    },
    updateFinnisher: function (FinnisherData, isInline) {
        var _this = this;
        this.FinnisherModelProxy.updateFinnisher(FinnisherData, function (data) {
            _this.settings.eventHandlers.onFinnisherUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onFinnisherUpdationFailed(error, description, isInline); });
    },
    deleteFinnisher: function (FinnisherData) {
        var _this = this;
        this.FinnisherModelProxy.deleteFinnisher(FinnisherData, function (data) {
            _this.settings.eventHandlers.onFinnisherDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onFinnisherDeletionFailed(error, description); });
    },
}