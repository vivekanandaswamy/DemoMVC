// JavaScript source code
Ecolab.Model.MixingVesselsModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
           
            onControllerDataLoaded: null,
            onPumpUpdated: null,
            onControllerNameLoaded: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.MixingVesselsModelProxy = new Ecolab.Model.MixingVesselsModelProxy();
};

Ecolab.Model.MixingVesselsModel.prototype = {
    init: function () {
    },

    
    getControllerName:function(ecoLabAccountNumber, controlNumber){
        var _this = this;
        _this.MixingVesselsModelProxy.getControllerName(ecoLabAccountNumber, controlNumber, function (data) {
           
            _this.settings.eventHandlers.onControllerNameLoaded(data);
        });
    },
   
    loadMixingVesselsData: function (controllerId, ecolabAccountNumber) {
        var _this = this;
        _this.MixingVesselsModelProxy.loadMixingVesselsData(controllerId, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onMixingVesselsDataLoaded(data);
        });
    },
    
    
    loadControllerData: function (controllerId) {
        var _this = this;
        _this.MixingVesselsModelProxy.loadControllerData(controllerId, function (data) {
            _this.settings.eventHandlers.onControllerDataLoaded(data);
        });
    },

    ValidateTags: function (pumpData, isSaveAndClose) {
        var _this = this;
        this.MixingVesselsModelProxy.validateTags(pumpData, function (data) {
            _this.settings.eventHandlers.onValidateSuccess(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onValidateFailed(error, description, pumpData); });
    },

    GetCompartmentValveData: function (controllerEquipSetupId, isEdit, washerGroupNumber, controllerEquipmentTypeId) {
        var _this = this;
        this.PumpsModelProxy.GetCompartmentValveData(controllerEquipSetupId, washerGroupNumber,controllerEquipmentTypeId, function (data) {
            _this.settings.eventHandlers.onGetCompartmentValveData(data, isEdit);
        });
    },

    saveData: function (data, isSaveAndClose) {
        var _this = this;
        var localData = data;
        this.MixingVesselsModelProxy.saveData(data, function (data) {
            _this.settings.eventHandlers.onPumpUpdated(data, isSaveAndClose);
        },
        function (error, description) {
            _this.settings.eventHandlers.onPumpUpdationFailed(error, description);
        });
    }
}