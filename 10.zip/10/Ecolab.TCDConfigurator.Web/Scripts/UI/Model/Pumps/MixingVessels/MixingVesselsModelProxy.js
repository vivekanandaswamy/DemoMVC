// JavaScript source code
Ecolab.Model.MixingVesselsModelProxy = function () {
};

Ecolab.Model.MixingVesselsModelProxy.prototype =
{
    
    loadControllerData: function(controllerId, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId };
        var url = "/Api/Pumps/GetControllerData";
        this.ApiRead("GET", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
   
   

    getControllerName: function (ecoLabAccountNumber, controlNumber, callBack, errorCallBack) {
        var requestData = { "ecolabAccountNumber": ecoLabAccountNumber, "controllerId": controlNumber };
        var url = "/Api/ControllerSetup/GetControllerDetailById";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadMixingVesselsData: function (controllerId, ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId, "ecolabAccountNumber": ecoLabAccountNumber };
        var url = "/Api/Pumps/GetMixingVesselsData";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    validateTags: function (requestData, callBack, errorCallBack) {
        var url = "/api/Pumps/ValidateTags";
        return this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    GetCompartmentValveData: function (controllerEquipSetupId,washerGroupNumber,controllerEquipmentTypeId, callBack, errorCallBack) {
        var requestData = { "controllerEquipSetupId": controllerEquipSetupId, "washerGroupNumber": washerGroupNumber, "controllerEquipmentTypeId": controllerEquipmentTypeId };
        var url = "/api/Pumps/GetCompartmentValveData";
        this.ApiRead("POST", url, function (response) { callBack(response); }, null, null, requestData);
    },
    saveData: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Pumps/SaveMixingVessels";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.MixingVesselsModelProxy.prototype = $.extend({}, Ecolab.Model.MixingVesselsModelProxy.prototype, base);
Ecolab.Model.MixingVesselsModelProxy.prototype.base = base;