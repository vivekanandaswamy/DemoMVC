// JavaScript source code
Ecolab.Model.PumpsProductsModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onPumpsProductDataLoaded: null,
            onControllerNameLoaded: null,
            onProductsLoaded: null,
            onPumpUpdated: null,
            onPumpUpdationFailed:null,

        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.PumpsProductsModelProxy = new Ecolab.Model.PumpsProductsModelProxy();
};

Ecolab.Model.PumpsProductsModel.prototype = {
    init: function () {
    },

    loadProducts: function (ecoLabAccountNumber) {
        var _this = this;
        _this.PumpsProductsModelProxy.loadProducts(ecoLabAccountNumber, function (products) {
            _this.settings.eventHandlers.onProductsLoaded(products);
        });
    },

    getControllerName: function (ecoLabAccountNumber, controlNumber) {
        var _this = this;
        _this.PumpsProductsModelProxy.getControllerName(ecoLabAccountNumber, controlNumber, function (data) {
            _this.settings.eventHandlers.onControllerNameLoaded(data);
        });
    },

    loadPumpsProductData: function (controllerId , ecolabAccountNumber) {
        var _this = this;
        _this.PumpsProductsModelProxy.loadPumpsProductData(controllerId, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onPumpsProductDataLoaded(data);
        });
    },

    saveData: function (data, isSaveAndClose) {
        var _this = this;
        var localData = data;
        this.PumpsProductsModelProxy.saveData(data,  function (data) {
            _this.settings.eventHandlers.onPumpUpdated(data, isSaveAndClose);
        },
        function (error, description) {
             _this.settings.eventHandlers.onPumpUpdationFailed(error, description);
        });
    }
   
}