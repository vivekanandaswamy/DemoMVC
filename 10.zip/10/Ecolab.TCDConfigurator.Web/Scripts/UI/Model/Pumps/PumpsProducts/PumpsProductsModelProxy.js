// JavaScript source code
Ecolab.Model.PumpsProductsModelProxy = function () {
};

Ecolab.Model.PumpsProductsModelProxy.prototype =
{
    loadProducts: function (ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber };
        var url = "/Api/Pumps/GetProductList";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    getControllerName: function (ecoLabAccountNumber, controlNumber, callBack, errorCallBack) {
        var requestData = { "ecolabAccountNumber": ecoLabAccountNumber, "controllerId": controlNumber };
        var url = "/Api/ControllerSetup/GetControllerDetailById";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadPumpsProductData: function (controllerId , ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId, "ecolabAccountNumber": ecoLabAccountNumber };
        var url = "/Api/Pumps/GetPumpsProducts";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    saveData: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Pumps/SavePumpsProducts";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    
}
var base = new Ecolab.Model.Common();
Ecolab.Model.PumpsProductsModelProxy.prototype = $.extend({}, Ecolab.Model.PumpsProductsModelProxy.prototype, base);
Ecolab.Model.PumpsProductsModelProxy.prototype.base = base;