// JavaScript source code
Ecolab.Model.PumpsModelProxy = function () {
};

Ecolab.Model.PumpsModelProxy.prototype =
{
    loadPumpsData: function (ecoLabAccountNumber, controlNumber, controllerModelId, option, callBack, errorCallBack) {
        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "controlNumber": controlNumber, "showOption": option, "controllerModelId": controllerModelId };
        var url = "/Api/Pumps/GetPumps";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadProducts: function (ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber};
        var url = "/Api/Pumps/GetProductList";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    
    loadPumpProductsData: function(controllerId, ecolabAccountNumber, callBack, errorCallBack){
        var requestData = { "controllerId": controllerId, "ecolabAccountNumber": ecolabAccountNumber };
        var url = "/Api/Pumps/GetPumpsProducts";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadControllerData: function(controllerId, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId };
        var url = "/Api/Pumps/GetControllerData";
        this.ApiRead("GET", url, function(response) { callBack(response); }, function(data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadPumpTypes: function (callBack, errorCallBack) {
        var url = "/Api/Pumps/GetPumpModels";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null);
    },
    loadLineData: function (lineNo, controllerId, equipmentId, callBack, errorCallBack) {
        var requestData = { "lineNo": lineNo, "controllerId": controllerId, 'equipmentId': equipmentId };
        var url = "/Api/Pumps/GetLineData";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadAuxiliaryData: function (lineNo, controllerId, callBack, errorCallBack) {
        var requestData = { "LineNumber": lineNo, "controllerid": controllerId };
        var url = "/Api/Pumps/GetAuxiliaryPumpData";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadChemicals: function (request, callBack, errorCallBack) {
        var url = "/api/PlantChemical/GetChemicalList";
        this.ApiRead("Chemical", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, request);
    },
    updatePump: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Pumps/UpdatePump";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    createPumpsChemicalDetails: function (requestData, callBack, errorCallBack) {
        var url = "/Api/PlantChemical/CreatePumpsChemicalDetails";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    WriteTagsToPLC: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Pumps/WriteTagsToPLC";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    getControllerName: function (ecoLabAccountNumber, controlNumber, callBack, errorCallBack) {
        var requestData = { "ecolabAccountNumber": ecoLabAccountNumber, "controllerId": controlNumber };
        var url = "/Api/ControllerSetup/GetControllerDetailById";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    validateTags: function (requestData, callBack, errorCallBack) {
        var url = "/api/Pumps/ValidateTags";
        return this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    GetCompartmentValveData: function (controllerEquipSetupId,washerGroupNumber,controllerEquipmentTypeId, callBack, errorCallBack) {
        var requestData = { "controllerEquipSetupId": controllerEquipSetupId, "washerGroupNumber": washerGroupNumber, "controllerEquipmentTypeId": controllerEquipmentTypeId };
        var url = "/api/Pumps/GetCompartmentValveData";
        this.ApiRead("POST", url, function (response) { callBack(response); }, null, null, requestData);
    }
}
var base = new Ecolab.Model.Common();
Ecolab.Model.PumpsModelProxy.prototype = $.extend({}, Ecolab.Model.PumpsModelProxy.prototype, base);
Ecolab.Model.PumpsModelProxy.prototype.base = base;