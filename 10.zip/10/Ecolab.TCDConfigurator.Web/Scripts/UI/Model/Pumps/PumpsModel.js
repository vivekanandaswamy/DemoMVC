// JavaScript source code
Ecolab.Model.PumpsModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onPumpsDataLoaded: null,
            onProductsLoaded: null,
            onPumpProductsLoaded: null,
            onPumpTypesLoaded: null,
            onLineDataLoaded:null,
            onControllerDataLoaded: null,
            onPumpUpdated: null,
            onPumpUpdationFailed: null,
            onPumpUpdatedEdit: null,
            onControllerNameLoaded: null,
            onValidateFailed: null,
            onGetCompartmentValveData: null,
            onloadAuxiliaryData: null,
            onCreatePumpsChemicalDetails: null,
            onCreatePumpsChemicalFialedDetails: null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.PumpsModelProxy = new Ecolab.Model.PumpsModelProxy();
};

Ecolab.Model.PumpsModel.prototype = {
    init: function () {
    },

    loadPumpsData: function (ecoLabAccountNumber, controlNumber, controllerModelId) {
        var _this = this;
        _this.PumpsModelProxy.loadPumpsData(ecoLabAccountNumber, controlNumber,controllerModelId, "", function (data) {
            _this.settings.eventHandlers.onPumpsDataLoaded(data);
        });
    },
    getControllerName:function(ecoLabAccountNumber, controlNumber){
        var _this = this;
        _this.PumpsModelProxy.getControllerName(ecoLabAccountNumber, controlNumber,function (data) {
            _this.settings.eventHandlers.onControllerNameLoaded(data);
        });
    },
    loadPumpsListOnDropdown: function (ecoLabAccountNumber, controlNumber, controllerModelId, option) {
        var _this = this;
        _this.PumpsModelProxy.loadPumpsData(ecoLabAccountNumber, controlNumber, controllerModelId, option, function (data) {
            _this.settings.eventHandlers.onPumpsDataLoaded(data);
        });
    },
    loadProducts: function (ecoLabAccountNumber, controllerModelId) {
        var _this = this;
        _this.PumpsModelProxy.loadProducts(ecoLabAccountNumber, function (products) {
            _this.settings.eventHandlers.onProductsLoaded(products);
        });
    },
    loadPumpProductsData: function(controllerId, ecolabAccountNumber){
        var _this = this;
        _this.PumpsModelProxy.loadPumpProductsData(controllerId, ecolabAccountNumber, function (products) {
            _this.settings.eventHandlers.onPumpProductsLoaded(products);
        });
    },
    loadPumpTypes: function () {
        var _this = this;
        _this.PumpsModelProxy.loadPumpTypes(function (pumpTypes) {
            _this.settings.eventHandlers.onPumpTypesLoaded(pumpTypes);
        });
    },
    loadLineData: function (lineNo, controllerId, equipmentId, isEdit) {
        var _this = this;
        _this.PumpsModelProxy.loadLineData(lineNo, controllerId, equipmentId, function(lineData) {
            _this.settings.eventHandlers.onLineDataLoaded(lineData, isEdit);
        });
    },
    loadAuxiliaryData: function (lineNo, controllerId) {
        var _this = this;
        _this.PumpsModelProxy.loadAuxiliaryData(lineNo, controllerId, function (lineData) {
            _this.settings.eventHandlers.onloadAuxiliaryData(lineData);
        });
    },
    loadControllerData: function (controllerId) {
        var _this = this;
        _this.PumpsModelProxy.loadControllerData(controllerId, function (data) {
            _this.settings.eventHandlers.onControllerDataLoaded(data);
        });
    },

    loadChemicals: function (request, callBack) {
        this.PumpsModelProxy.loadChemicals(request, callBack);
    },

    createPumpsChemicalDetails: function (requestData, Window) {
        var _this = this;
        _this.PumpsModelProxy.createPumpsChemicalDetails(requestData, function (data) {
            _this.settings.eventHandlers.onCreatePumpsChemicalDetails(data, Window);
        },
        
        function (error, description) {
            _this.settings.eventHandlers.onCreatePumpsChemicalFialedDetails(error, description, Window);
        });
    },

    updatePumpData: function (pumpdata, isInline, isSaveAndClose) {
        var _this = this;
        var localData = pumpdata;
        this.PumpsModelProxy.updatePump(pumpdata, function (data) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdated(data, isSaveAndClose);
            else
                _this.settings.eventHandlers.onPumpUpdatedEdit(localData, isSaveAndClose);
        },
        function (error, description) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdationFailed(error, description);
            else
                _this.settings.eventHandlers.onPumpUpdationFailedEdit(error, description, localData);
        });
    },

    WriteTagsToPLC: function (pumpdata, isInline, isSaveAndClose) {
        var _this = this;
        var localData = pumpdata[0];
        this.PumpsModelProxy.WriteTagsToPLC(pumpdata, function (data) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdated(data);
            else
                _this.settings.eventHandlers.onPumpUpdatedEdit(localData, isSaveAndClose);
        },
        function (error, description) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdationFailed(error, description);
            else
                _this.settings.eventHandlers.onPumpUpdationFailedEdit(error, description, localData);
        });
    },

    ValidateTags: function (pumpData, isSaveAndClose) {
        var _this = this;
        this.PumpsModelProxy.validateTags(pumpData, function (data) {
            _this.settings.eventHandlers.onValidateSuccess(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onValidateFailed(error, description, pumpData); });
    },

    GetCompartmentValveData: function (controllerEquipSetupId, isEdit, washerGroupNumber, controllerEquipmentTypeId) {
        var _this = this;
        this.PumpsModelProxy.GetCompartmentValveData(controllerEquipSetupId, washerGroupNumber,controllerEquipmentTypeId, function (data) {
            _this.settings.eventHandlers.onGetCompartmentValveData(data, isEdit);
        });
    }
}