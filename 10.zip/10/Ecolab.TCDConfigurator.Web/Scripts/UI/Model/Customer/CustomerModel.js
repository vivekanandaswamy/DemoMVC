Ecolab.Model.CustomerModel = function (options) {
    var defaultOptions = {
        eventHandlers: {

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.CustomerModelProxy = new Ecolab.Model.CustomerModelProxy();
};

Ecolab.Model.CustomerModel.prototype = {
    init: function () {
    },
    loadCustomerData: function (pageIndex, callBackData) {
        var _this = this;
        _this.onDataLoaded("data", true);
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onCustomerDataLoaded(data, callBackData);
    }
};

