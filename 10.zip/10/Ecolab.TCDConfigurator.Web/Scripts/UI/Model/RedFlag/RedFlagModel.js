Ecolab.Model.RedFlagModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onRedFlagDataLoaded: null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.RedFlagModelProxy = new Ecolab.Model.RedFlagModelProxy();
};
Ecolab.Model.RedFlagModel.prototype = {
    init: function () {
    },
    loadRedFlagData: function () {
        var _this = this;
        this.RedFlagModelProxy.loadRedFlagData(function (RedFlagData) {
            _this.settings.eventHandlers.onRedFlagDataLoaded(RedFlagData);
        });
    },
    loadItemData: function () {
        var _this = this;
        this.RedFlagModelProxy.loadItemData(function (data) {
            _this.settings.eventHandlers.onAddRedFlagDataLoaded(data);
        });
    },
    loadOnItemChangedData: function (id, itemId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnItemChangedData(id, itemId, function (data) {
            _this.settings.eventHandlers.onItemChangedDataLoaded(data);
        });
    },
    loadOnLocationChangedData: function (id, itemId, locationId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnLocationChangedData(id, itemId, locationId, function (data) {
            _this.settings.eventHandlers.onLocationChangedDataLoaded(data);
        });
    },
    loadOnLocationChangedFormulaCategory: function (id, itemId, locationId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnLocationChangedFormulaCategory(id, itemId, locationId, function (data) {
            _this.settings.eventHandlers.onLocationChangedDataLoadedFormulaCategory(data);
        });
    },
    onEditRedFlagClicked: function (id) {
        var _this = this;
        this.RedFlagModelProxy.onEditRedFlagClicked(id, function (data) {
            _this.settings.eventHandlers.onEditRedFlagDataLoaded(data);
        });
    },
    onDeleteRedFlagClicked: function (id) {
        var _this = this;
        this.RedFlagModelProxy.onDeleteRedFlagClicked(id, function (data) {
            _this.settings.eventHandlers.onDeleteRedFlagResponseLoaded(data);
        });
    },
    loadRedFlagItemList: function (categoryId) {
        var _this = this;
        this.RedFlagModelProxy.loadRedFlagItemList(categoryId, function (data) {
            _this.settings.eventHandlers.onCategoryChangedDataLoaded(data);
        });
    },
    loadOnLocationChangedDataMeter: function (locationId, itemId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnLocationChangedDataMeter(locationId, itemId, function (data, itemId) {
            _this.settings.eventHandlers.onLocationChangedDataLoadedMeter(data, itemId);
        });
    },
    loadOnLocationChangedDataSensor: function (locationId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnLocationChangedDataSensor(locationId, function (data) {
            _this.settings.eventHandlers.onLocationChangedDataLoadedSensor(data);
        });
    
    },

    loadOnFormulaCategoryChanged: function (locationId, id) {
        var _this = this;
        this.RedFlagModelProxy.loadOnFormulaCategoryChanged(locationId, id, function (data) {
            _this.settings.eventHandlers.onFormulaCategoryChangedDataLoaded(data);
        });
    },

    loadOnProductsFormulaChanged: function (locationId, formulaId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnProductsFormulaChanged(locationId, formulaId, function (data) {
            _this.settings.eventHandlers.onFormulaChangeProductsdDataLoaded(data);
        });
    },
};