Ecolab.Model.RedFlagModelProxy = function () {
};

Ecolab.Model.RedFlagModelProxy.prototype =
{
    loadRedFlagData: function (callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetCategoryData";
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadRedFlagItemList: function (categoryId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetRedFlagItemListByCategory";
        var requestData = { "categoryId": categoryId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadItemData: function (callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetCategoryData";
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadOnItemChangedData: function (id, itemId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnItemChange";
        var requestData = { "id": id, "itemId": itemId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnLocationChangedData: function (id, itemId, locationId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnLocationChange";
        var requestData = { "id": id, "itemId": itemId, "locationId": locationId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnLocationChangedFormulaCategory: function (id, itemId, locationId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetFormulaCategoryOnLocationChange";
        var requestData = { "id": id, "itemId": itemId, "locationId": locationId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    onEditRedFlagClicked: function (id, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnEditClicked";
        var requestData = { "id": id };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    onDeleteRedFlagClicked: function (id, callBack, errorCallBack) {
        var url = "/Api/RedFlag/Delete";
        var requestData = { "id": id };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnLocationChangedDataMeter: function (locationId,itemId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetMeterOnLocationChange";
        var requestData = { "locationId": locationId, "itemId": itemId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response, itemId); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnLocationChangedDataSensor: function (locationId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetSensorOnLocationChange";
        var requestData = { "locationId": locationId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnFormulaCategoryChanged: function (locationId, id, callBack, errorCallBack) {
        var url = "Api/RedFlag/GetFormulaOnFormulaCategoryChange";
        var requestData = { "locationId": locationId, "id": id };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnProductsFormulaChanged: function (locationId, formulaId, callBack, errorCallBack) {
        var url = "Api/RedFlag/GetProductsOnFormulaChange";
        var requestData = { "locationId": locationId, "formulaId": formulaId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

};
var base = new Ecolab.Model.Common();
Ecolab.Model.RedFlagModelProxy.prototype = $.extend({}, Ecolab.Model.RedFlagModelProxy.prototype, base);
Ecolab.Model.RedFlagModelProxy.prototype.base = base;