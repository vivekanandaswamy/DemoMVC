﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupController.cs" company="Ecolab">
// Gets the detalis of the washergroups for WasherGroupController Controller class.
// </copyright>
// <summary>The methods for washer group setup.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Text.RegularExpressions;
	using System.Web.Http;
	using AutoMapper;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Ecolab.Models;
	using Ecolab.Models.ControllerSetup;
	using Elmah;
	using Services.ControllerSetup;
	using Services.Interfaces;
	using Services.Interfaces.WasherGroup;
	using Model = Ecolab.Models.WasherGroup;
	using WebModel = Models.WasherGroup;
    using Ecolab.Services.Interfaces.Washers;

    /// <summary>
    ///     This is a Api controller class for washer groups.
    /// </summary>
    public class WasherGroupController : BaseApiController
    {
        /// <summary>
        ///     Interface object for Washer Group Service.
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherGroupController" /> class.
        /// </summary>
        /// <param name="washerGroupService">Wash group Service object.</param>
        public WasherGroupController(IWasherGroupService washerGroupService, IWasherServices washerServices,IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.washerGroupService = washerGroupService;
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     Get all the values related to Plant setup
        /// </summary>
        /// <returns>Returns the plant model</returns>
        [HttpGet]
        public IEnumerable<WebModel.WasherGroup> GetWasherGroupDetails(int washergroupId, string ecolabAccountNumber, int pageNumber, int numberOfRecordsPerpage, string sortColumn)
        {
            IEnumerable<Model.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, pageNumber, numberOfRecordsPerpage, sortColumn);
            IEnumerable<WebModel.WasherGroup> washerGroups = Mapper.Map<IEnumerable<Model.WasherGroup>, IEnumerable<WebModel.WasherGroup>>(washerGroupModel);

            ControllerSetupService controllerSetupService = new ControllerSetupService();
            List<Controller> controllerModel = controllerSetupService.GetControllerDetails(ecolabAccountNumber);
            int count = controllerModel.Count;
            if (washerGroups != null && washerGroups.ToList().Count > 0)
            {
                washerGroups.ToList().ForEach(_ => _.ControllerCount = count);
            }
            else
            {
                washerGroups = new List<WebModel.WasherGroup>();
                washerGroups.ToList().Add(new WebModel.WasherGroup
                {
                    ControllerCount = count
                });
            }

			//var result = from item in washerGroups
			//			 select new WebModel.WasherGroup
			//			 {
			//				 EcolabAccountNumber = item.EcolabAccountNumber,
			//				 Id = item.Id,
			//				 IsDelete = item.IsDelete,
			//				 LastModifiedTimeStamp = item.LastModifiedTimeStamp,
			//				 LastSyncTime = item.LastSyncTime,
			//				 MaxNumberOfRecords = item.MaxNumberOfRecords,
			//				 MyServiceLastModifiedTime = item.MyServiceLastModifiedTime,
			//				 MyServiceWasherGroupGuid = item.MyServiceWasherGroupGuid,
			//				 MyServiceWasherGroupNumber = item.MyServiceWasherGroupNumber,
			//				 RowNumber = item.RowNumber,
			//				 RowTotalCount = item.RowTotalCount,
			//				 WasherGroupDescription = item.WasherGroupDescription,
			//				 WasherGroupId = item.WasherGroupId,
			//				 WasherGroupName = item.WasherGroupName,
			//				 WasherGroupNumber = item.WasherGroupNumber,
			//				 WasherGroupNumberInt = Convert.ToInt32(item.WasherGroupNumber),
			//				 WasherGroupTypeId = item.WasherGroupTypeId,
			//				 WasherGroupTypeName = item.WasherGroupTypeName,
			//				 ControllerCount = item.ControllerCount,
			//			 };
			//return result.OrderBy(x => x.WasherGroupNumberInt);
			return washerGroups;
        }

        /// <summary>
        ///     Deletes the washer group based on the washergroupId.
        /// </summary>
        /// <param name="washerGroupWebData">washer group web data.</param>
        /// <returns>The string value the deletion is passed or failed.</returns>
        [HttpPost]
        public HttpResponseMessage DeleteWasherGroup(WebModel.WasherGroup washerGroupWebData)
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            WebModel.WasherGroup washerGroupModel = this.GetWasherGroupDetails(washerGroupWebData.WasherGroupId, washerGroupWebData.EcolabAccountNumber, 1, 1, "asc").FirstOrDefault();
            washerGroupWebData.IsDelete = true;
            washerGroupWebData.MaxNumberOfRecords = this.washerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            washerGroupWebData.EcolabAccountNumber = user.EcolabAccountNumber;
            washerGroupWebData.LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupModel.LastModifiedTimeStamp, DateTimeKind.Utc);

            Model.WasherGroup washerGroupData = Mapper.Map<WebModel.WasherGroup, Model.WasherGroup>(washerGroupWebData);

            try
            {
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        this.washerGroupService.DeleteWasherGroup(washerGroupWebData.WasherGroupId, user.UserId, washerGroupWebData.EcolabAccountNumber, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupData.LastModifiedTimeStamp, DateTimeKind.Utc);
                        result = Push.PushToLocal(washerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteWasherGroup);
                    }

                }

                switch (result)
                {
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Update the Washer Group Data
        /// </summary>
        /// <param name="washerGroupWebData">Object of Washer group.</param>
        /// <returns>The result of the save opreation in string format.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherGroup(List<WebModel.WasherGroup> washerGroupWebData)
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            washerGroupWebData.Each(item => item.EcolabAccountNumber = user.EcolabAccountNumber);

            //WebModel.WasherGroup washerGroupModel = this.GetWasherGroupDetails(washerGroupWebData.WasherGroupId, washerGroupWebData.EcolabAccountNumber, 1, 1, "asc").FirstOrDefault();
            washerGroupWebData.Each(item => item.LastModifiedTimeStamp = DateTime.SpecifyKind(item.LastModifiedTimeStamp, DateTimeKind.Utc));

            try
            {
                foreach (var washerGroup in washerGroupWebData)
                {
                    if (user != null)
                    {
                            washerGroup.MaxNumberOfRecords = this.washerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                            Model.WasherGroup washerGroupData = Mapper.Map<WebModel.WasherGroup, Model.WasherGroup>(washerGroup);

                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                                washerGroupData.WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupData, user.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupData.LastModifiedTimeStamp, DateTimeKind.Utc);
                            result = Push.PushToLocal(washerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherGroup);
                        }
                    }

                    switch (result)
                    {
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, result);

                        case 51000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, result);
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, result);

                    }
                }                

				return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="washerGroupId"></param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns></returns>
        public int GetWasherCount(int washerGroupId, string ecolabAccountNumber)
        {
            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washerGroupId);
            washersModel = washersModel.Where(item => item.WasherGroupId == washerGroupId);
            return washersModel.Count();
        }
    }
}