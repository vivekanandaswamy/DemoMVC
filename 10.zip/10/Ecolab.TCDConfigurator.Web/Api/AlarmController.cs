﻿// -----------------------------------------------------------------------
// <copyright file="AlarmController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System.Collections.Generic;
    using System.Web.Http;
    using Models;
    using Services.Interfaces;

    /// <summary>
    ///     class AlarmController
    /// </summary>
    public class AlarmController : BaseApiController
    {
        /// <summary>
        ///     Alarm Service
        /// </summary>
        private readonly IAlarmService alarmService;

        /// <summary>
        ///     Initializes a new instance of the AlarmController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="alarmService">alarm Service</param>
        public AlarmController(IUserService userService, IPlantService plantService, IAlarmService alarmService) : base(userService, plantService)
        {
            this.alarmService = alarmService;
        }

        /// <summary>
        ///     Gets alarm details
        /// </summary>
        /// <returns>List of Alarms</returns>
        [HttpGet]
        public IEnumerable<AlarmModel> FetchAlarmDetails()
        {
            var alrmList = new List<AlarmModel>();
            return alrmList;
            //return Mapper.Map<List<Alarm>, List<AlarmModel>>(alarmService.FetchAlarmDetails(EcolabAccountNumber));
        }

        /// <summary>
        ///     Gets alarm Count
        /// </summary>
        /// <returns>Returns alarm count</returns>
        [HttpGet]
        public int FetchAlarmCount()
        {
            var alrmList = new List<AlarmModel>();
            return 0;
            //return Mapper.Map<List<Alarm>, List<AlarmModel>>(alarmService.FetchAlarmDetails(EcolabAccountNumber)).Count;
        }
    }
}