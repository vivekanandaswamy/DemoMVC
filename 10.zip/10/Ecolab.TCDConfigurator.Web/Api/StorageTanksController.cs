﻿// -----------------------------------------------------------------------
// <copyright file="StorageTanksController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Storage Tanks Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Web.Mvc;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.StorageTanks;
    using Models.StorageTanks;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Plc;
    using Services.Interfaces.StorageTanks;
    using Utilities;
    using Controller = Ecolab.Models.ControllerSetup.Controller;
    using ControllerModel = Models.ControllerSetup.ControllerModel;
    using ProductModel = Ecolab.Models.ControllerSetup.Pumps.ProductModel;

    /// <summary>
    ///     class StorageTanks Controller
    /// </summary>
    public class StorageTanksController : BaseApiController
    {
        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IPumpsService pumpServices;

        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IStorageTanksService storageTanksService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="StorageTanksController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="storageTanksService">The storage Tanks Service.</param>
        /// <param name="controllerSetupService">The controller setup service</param>
        /// <param name="pumpServices">The pump service</param>
        /// <param name="plcServiceobj">The PLC service object</param>
        /// <param name="plantService">The Plant Service</param>
        public StorageTanksController(IUserService userService, IStorageTanksService storageTanksService, IControllerSetupService controllerSetupService, IPumpsService pumpServices, IPlcService plcServiceobj, IPlantService plantService)
            : base(userService, plantService)
        {
            this.storageTanksService = storageTanksService;
            this.controllerSetupService = controllerSetupService;
            this.pumpServices = pumpServices;
            this.plcService = plcServiceobj;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get Tanks Details
        /// </summary>
        /// <returns>Returns the Tanks Details</returns>
        [HttpGet]
        public IEnumerable<TanksModel> GetTanksDetails(string ecolabAccountNumber)
        {
            List<Tanks> tanksModel = this.storageTanksService.GetTanksDetails(ecolabAccountNumber).ToList();
            List<TanksModel> tanks = Mapper.Map<List<Tanks>, List<TanksModel>>(tanksModel);
            tanks = ConvertUnits(tanks, false);
            tanks.ForEach(_ => _.CallibrationLevelAsString = _.CallibrationLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.LowLevelAsString = _.LowLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.EmptyLevelAsString = _.EmptyLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.LevelDeviationAsString = _.LevelDeviation.ToString("#,0.##"));
            tanks.ForEach(_ => _.SizeAsString = _.Size.ToString("#,0.##"));
            tanks.ForEach(_ => _.CurrentLevelAsString = _.CurrentLevel.ToString("#,0.##"));
            return tanks;
        }

        /// <summary>
        /// ConvertUnits
        /// </summary>
        /// <param name="tanks">list of tanks</param>
        /// <param name="isEdit">boolean parameter is Edit</param>
        /// <returns>list of tanks</returns>
        private List<TanksModel> ConvertUnits(List<TanksModel> tanks, bool isEdit)
        {
            User user = this.GetUser();
            tanks.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, user.UserId, isEdit, 0);
            return tanks;
        }

        /// <summary>
        ///     Method to delete a StorageTank
        /// </summary>
        /// <param name="storageTankData">Storage tank data.</param>
        /// <returns>returns boolean</returns>
        [System.Web.Http.HttpPost]
        public HttpResponseMessage DeleteStorageTanks(TanksModel storageTankData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            bool result = true;
            int response = 0;

            storageTankData.IsDelete = true;
            storageTankData.EcolabAccountNumber = user.EcolabAccountNumber;
            storageTankData.MaxNumberOfRecords = this.storageTanksService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

            storageTankData.LastModifiedTimeStamp = DateTime.SpecifyKind(storageTankData.LastModifiedTimeStamp, DateTimeKind.Utc);
            Tanks tanks = Mapper.Map<TanksModel, Tanks>(storageTankData);

            if (isDisconnected)
            {
                DateTime lastModifiedTimeStamp;
                result = this.storageTanksService.DeleteStorageTanks(tanks.TankId, this.UserId, storageTankData.EcolabAccountNumber, out lastModifiedTimeStamp);
            }
            else
            {
                response = Push.PushToLocal(tanks, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteStorageTanks);
            }
            switch (response)
            {
                case 51030:
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                case 51060:
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                case 60000:
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Get Tanks Details for Add/Edit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="id">The Id parameter.</param>
        /// <returns>returns boolean</returns>
        public IEnumerable<TanksModel> GetAddEditStorageTanksDetails(string ecolabAccountNumber, int id = 0)
        {
            List<Controller> controllerModel = this.controllerSetupService.GetControllerDetails(ecolabAccountNumber).ToList();
            List<ControllerModel> controller = Mapper.Map<List<Controller>, List<ControllerModel>>(controllerModel);

            List<ProductModel> productModel = this.pumpServices.GetProductList(ecolabAccountNumber);
            List<Models.ControllerSetup.Pumps.ProductModel> products = Mapper.Map<List<ProductModel>, List<Models.ControllerSetup.Pumps.ProductModel>>(productModel);
            List<TanksModel> tanks;
            if (id > 0)
            {
                List<Tanks> tanksModel = this.storageTanksService.GetTanksDetails(ecolabAccountNumber, id).ToList();
                tanks = Mapper.Map<List<Tanks>, List<TanksModel>>(tanksModel);
                tanks = ConvertUnits(tanks, false);
            }
            else
            {
                tanks = this.PopulateValue();
            }

            foreach (TanksModel item in tanks)
            {
                item.Controllers = controller.ToList();
                item.Products = products.ToList();
                item.IsCentral = "Yes";
            }

            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            List<OpcTag> tagsList = new List<OpcTag>();
            TagCollection tagStatus = new TagCollection();

            foreach (TanksModel model in tanks)
            {
                if (!string.IsNullOrEmpty(model.SizeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.SizeTag,
                        Value = Convert.ToString(Convert.ToInt32(model.Size))
                    });
                }

                if (!string.IsNullOrEmpty(model.LevelDeviationTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.LevelDeviationTag,
                        Value = Convert.ToString(Convert.ToInt32(model.LevelDeviation))
                    });
                }
            }

            tanks.ForEach(_ => _.CalibrationLevelDisplay = _.CallibrationLevel);
            tanks.ForEach(_ => _.LowLevelDisplay = _.LowLevel);
            tanks.ForEach(_ => _.EmptyLevelDisplay = _.EmptyLevel);
            tanks.ForEach(_ => _.LevelDeviationDisplay = _.LevelDeviation);
            tanks.ForEach(_ => _.SizeDisplay = _.Size);
            tanks.ForEach(_ => _.CurrentLevelDisplay = _.CurrentLevel);

            tanks.ForEach(_ => _.CallibrationLevelAsString = _.CallibrationLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.LowLevelAsString = _.LowLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.EmptyLevelAsString = _.EmptyLevel.ToString("#,0.##"));
            tanks.ForEach(_ => _.LevelDeviationAsString = _.LevelDeviation.ToString("#,0.##"));
            tanks.ForEach(_ => _.SizeAsString = _.Size.ToString("#,0.##"));
            tanks.ForEach(_ => _.CurrentLevelAsString = _.CurrentLevel.ToString("#,0.##"));

            return tanks;
        }

        /// <summary>
        ///     Get Tanks Details Basing on controller
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>returns Tank Model Details</returns>
        public IEnumerable<TanksModel> GetTankDetailsOnController(string ecolabAccountNumber, int controllerId)
        {
            return Mapper.Map<List<Tanks>, List<TanksModel>>(
                this.storageTanksService.GetTanksDetails(ecolabAccountNumber))
                .Where(_ => _.ControllerId == controllerId);
        }

        /// <summary>
        ///     Save the Storage Tanks Data
        /// </summary>
        /// <param name="data"> The data . </param>
        /// <returns>http response message</returns>
        [HttpPost]
        public HttpResponseMessage CreateStorageTank(TanksModel data)
        {
            User user = this.GetUser();
            TanksModel tanks = new TanksModel();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            data.EcolabAccountNumber = user.EcolabAccountNumber;
            int result = 0;
            Tanks tanksConverted;
            SetConvertedDataOnAdd_Update(data, out tanks, out tanksConverted);

            tanksConverted.MaxNumberOfRecords = this.storageTanksService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

            try
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    tanks.TankId = this.storageTanksService.SaveStorageTank(tanksConverted, this.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(tanksConverted, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddStorageTanks);
                }

                switch (result)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                    case 303:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "303");
                }
            }
            catch (SqlException ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Save the Storage Tanks Data
        /// </summary>
        /// <param name="data"> The data . </param>
        /// <returns>http response message</returns>
        [HttpPost]
        public HttpResponseMessage UpdateStorageTank(TanksModel data)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            data.EcolabAccountNumber = user.EcolabAccountNumber;
            data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);
            TanksModel tanks;
            Tanks tanksConverted;
            SetConvertedDataOnAdd_Update(data, out tanks, out tanksConverted);

            int result = 0;

            tanksConverted.MaxNumberOfRecords = this.storageTanksService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

            try
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    tanks.TankId = this.storageTanksService.UpdateStorageTank(tanksConverted, this.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(tanksConverted, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks);
                }
                switch (result)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                    case 303:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "303");
                }
            }
            catch (SqlException ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Write values to PLC
        /// </summary>
        /// <param name="data">Storage Tanks Data</param>
        private void WriteToPlc(TanksModel data)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            plc.WriteTags(new TagCollection { Tags = new List<Tag>(data.PlcTags) }, data.ControllerId);
        }

        /// <summary>
        ///     To Populate empty list
        /// </summary>
        /// <returns>List of Tank Model</returns>
        private List<TanksModel> PopulateValue()
        {
            return new List<TanksModel> { new TanksModel { TankId = -1, TankName = string.Empty } };
        }

        /// <summary>
        ///     Validate the PLC tag details
        /// </summary>
        /// <param name="data">Storage Tanks Data</param>
        /// <returns>Success or failure message</returns>
        [HttpPost]
        public HttpResponseMessage ValidateTags(TanksModel data)
        {
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                var tagStatus = new TagCollection();
                if (!string.IsNullOrEmpty(data.CurrentLevelTag))
                {
                    tagsList.Add(new OpcTag { Address = data.CurrentLevelTag, Value = data.CurrentLevel.ToString() });
                }

                if (!string.IsNullOrEmpty(data.LevelDeviationTag))
                {
                    tagsList.Add(new OpcTag { Address = data.LevelDeviationTag, Value = data.LevelDeviation.ToString() });
                }

                if (!string.IsNullOrEmpty(data.SizeTag))
                {
                    tagsList.Add(new OpcTag { Address = data.SizeTag, Value = data.Size.ToString() });
                }
                List<OpcTag> tags = null;
                if (tagsList.Any())
                {
                    tags = tagsList.Clone();
                    tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, data.ControllerId);
                    string errorCode = null;
                    foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                    {
                        if (status.Address == data.CurrentLevelTag)
                        {
                            errorCode += "804,";
                        }
                        if (status.Address == data.LevelDeviationTag)
                        {
                            errorCode += "805,";
                        }
                        if (status.Address == data.SizeTag)
                        {
                            errorCode += "806,";
                        }
                    }
                    if (!string.IsNullOrEmpty(errorCode))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                    }
                }

                var message = new StringBuilder();
                var ambiguousTags = new List<OpcTag>();
                if (tags != null)
                {
                    foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                            {
                                message.Append(
                                    string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>",
                                        tag.Address, tag.Value, plcTag.Value));
                                ambiguousTags.Add(tag);
                            }
                        }
                    }
                }
                if (!string.IsNullOrWhiteSpace(message.ToString()))
                {
                    message.Append("Do you want to override the value in plc ?");

                    var error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, error);
                }
                return Request.CreateResponse(HttpStatusCode.OK, message.ToString());
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        /// <summary>
        /// SetConvertedDataOnAdd_Update
        /// </summary>
        /// <param name="data">tanks data</param>
        /// <param name="tanks">tanks details</param>
        /// <param name="tanksConverted">tanksConverted</param>
        private void SetConvertedDataOnAdd_Update(TanksModel data, out TanksModel tanks, out Tanks tanksConverted)
        {
            tanks = data;
            List<TanksModel> lstTanksModel = new List<TanksModel>();
            lstTanksModel.Add(tanks);
            lstTanksModel = ConvertUnits(lstTanksModel, true);
            tanksConverted = Mapper.Map<TanksModel, Tanks>(lstTanksModel.FirstOrDefault());
        }
    }
}