﻿// -----------------------------------------------------------------------
// <copyright file="ContactController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Contact Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Web.Http;
	using AutoMapper;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Ecolab.Models.Common;
	using Elmah;
	using Models.PlantSetup;
	using Services;
	using Services.Interfaces;
	using ServiceModel = Ecolab.Models;

    /// <summary>
    ///     Class Contact Controller
    /// </summary>
    public class ContactController : BaseApiController
    {
        /// <summary>
        ///     Plant Contact Service
        /// </summary>
        private readonly IPlantContactService plantContactService = new PlantContactService();

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plantContactService">plant Contact Service</param>
        public ContactController(IUserService userService, IPlantService plantService, IPlantContactService plantContactService) : base(userService, plantService)
        {
            this.plantContactService = plantContactService;
        }

        /// <summary>
        ///     Get the Contact list
        /// </summary>
        /// <returns>Returns the Contact list</returns>
        [HttpGet]
        public IEnumerable<PlantContactModel> GetContact()
        {
            var user = GetUser();
            List<ServiceModel.PlantContact> contact = plantContactService.GetPlantContactDetails(user.EcolabAccountNumber);
            List<PlantContactModel> contactList = Mapper.Map<List<ServiceModel.PlantContact>, List<PlantContactModel>>(contact);
            contactList = contactList.Where(item => item.IsDelete == false).ToList();
            return contactList;
        }

        /// <summary>
        ///     Gets UOM basing on Utility Type
        /// </summary>
        /// <returns>List of UOM</returns>
        [HttpGet]
        public IEnumerable<PlantContactPositionModel> FetchPlantContactPosition()
        {
            IEnumerable<PlantContactPosition> plantContPositions = this.plantContactService.FetchPlantContactPosition();
            IEnumerable<PlantContactPositionModel> plantList = Mapper.Map<IEnumerable<PlantContactPosition>, IEnumerable<PlantContactPositionModel>>(plantContPositions);
            return plantList;
        }

        /// <summary>
        ///     creates new the Contact data
        /// </summary>
        /// <param name="data">Contact data to create</param>
        /// <returns>Returns created Contact data</returns>
        [HttpPost]
        public HttpResponseMessage CreateContact([FromBody] List<PlantContactModel> data)
        {
            ServiceModel.User user = this.GetUser();
            int userId = user.UserId;
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                if(data[0].Id == 0)
                {
                    data[0].Id = -1;
                }
                data[0].ContactTitle = data[0].ContactTitle == string.Empty ? null : data[0].ContactTitle;
                data[0].MaxNumberOfRecords = this.plantContactService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                ServiceModel.PlantContact objPlantContact = Mapper.Map<PlantContactModel, ServiceModel.PlantContact>(data[0]);
                objPlantContact.EcoalabAccountNumber = user.EcolabAccountNumber;
                objPlantContact.MyServiceCntctGuid = Guid.NewGuid();

                if(isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    objPlantContact.Id = this.plantContactService.SavePlantContactDetails(objPlantContact, userId, out lastModifiedTimeStamp);
                }
                else
                {
                   result = Push.PushToLocal(objPlantContact, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddPlantContact);
                    objPlantContact.Id = result;
                }

                switch(result)
                {
                   case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
            }
            catch(Exception ex)
            {
                //Logger.Error("Api - Contact - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to create the Contact. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     To update the Contact details
        /// </summary>
        /// <param name="id">Contact id</param>
        /// <param name="data">Contact data to update</param>
        /// <returns>Returns updated Contact data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, List<PlantContactModel> data)
        {
            
            var user = GetUser();
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            if (id > 0)
            {
                try
                {
                    foreach (var contact in data)
                    {
                        contact.LastModifiedTimeStamp = DateTime.SpecifyKind(contact.LastModifiedTimeStamp, DateTimeKind.Utc);

                        contact.ContactTitle = contact.ContactTitle == string.Empty ? null : contact.ContactTitle;
                        contact.MaxNumberOfRecords = this.plantContactService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                        ServiceModel.PlantContact objplantContact = Mapper.Map<PlantContactModel, ServiceModel.PlantContact>(contact);
                        objplantContact.EcoalabAccountNumber = user.EcolabAccountNumber;

                        int userId = user.UserId;

                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            contact.Id = this.plantContactService.SavePlantContactDetails(objplantContact, userId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            result = Push.PushToLocal(objplantContact, user.EcolabAccountNumber, userId, (int)TcdAdminMessageTypes.TcdUpdatePlantContact);
                        }
                        switch (result)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                            case 51060:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                    }
                    
                }
                catch(Exception)
                {
                    //Logger.Error("Api - Contact - Update Error :", ex);
                    //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Contact. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Contact details.");
        }

        /// <summary>
        ///     Updates the data
        /// </summary>
        /// <param name="data">The Contact related data</param>
        /// <returns>the saved data</returns>
        [HttpPut]
        public HttpResponseMessage Put(List<PlantContactModel> data)
        {
            return this.Put(data[0].Id, data);
        }

        /// <summary>
        ///     Delete the Contact data
        /// </summary>
        /// <param name="id">Contact ID</param>
        /// <param name="data">delete contact data</param>
        /// <returns>the deleted data</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteContact(int? id, PlantContactModel data)
        {
            int result = 0;
            ServiceModel.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            if(id > 0)
            {
                try
                {
                    data.IsDelete = true;
                    data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);
                    data.MaxNumberOfRecords = this.plantContactService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    ServiceModel.PlantContact objplantContact = Mapper.Map<PlantContactModel, ServiceModel.PlantContact>(data);
                    objplantContact.EcoalabAccountNumber = user.EcolabAccountNumber;
                    
                    if(isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        this.plantContactService.DeletePlantContactDetails(objplantContact, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(objplantContact, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeletePlantContact);
                    }
                    switch (result)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    }
                }
                catch(Exception)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the Contact. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Contact details.");
        }

        /// <summary>
        ///     Delete Contact related data
        /// </summary>
        /// <param name="data">The data in contact</param>
        /// <returns>contact deleted data</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteContact(List<PlantContactModel> data)
        {
            return this.DeleteContact(data[0].Id, data[0]);
        }

        /// <summary>
        ///     Get the Contact list
        /// </summary>
        /// <param name="term">Part of First Name or Last Name</param>
        /// <returns>List of filtered Contact details</returns>
        [HttpGet]
        public IEnumerable<PlantContactModel> GetContactList(string term)
        {
            return Mapper.Map<IEnumerable<ServiceModel.PlantContact>, IEnumerable<PlantContactModel>>(this.plantContactService.GetContactList(term, this.EcolabAccountNumber));
        }
    }
}