﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Setup Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Elmah;
    using Helper;
    using Models.PlantSetup;
    using Services.Interfaces;

    /// <summary>
    ///     Plant Setup Controller
    /// </summary>
    public class PlantSetupController : BaseApiController
    {
        /// <summary>
        ///     Plant Setup Controller
        /// </summary>
        /// <param name="userService">user Service</param>
        /// <param name="plantService">plant Service</param>
        /// <returns></returns>
        public PlantSetupController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Get all the values related to Plant setup
        /// </summary>
        /// <returns>Returns the plant model</returns>
        public PlantModel Get()
        {
            User user = this.GetUser();
            List<CurrencyMaster> currencyCode = this.PlantService.GetCurrencyDetails();
            List<LanguageMaster> languages = this.PlantService.GetLanguageDetails();
            List<DimensionalUnitSystems> uoms = this.PlantService.GetDimensionalUnitSystems();

            PlantModel plantModel = new PlantModel();

            plantModel = Mapper.Map<Plant, PlantModel>(this.PlantService.GetPlantDetails(user.UserId, user.EcolabAccountNumber));
            plantModel.StartTime = DateTime.ParseExact(plantModel.StartTime, "HH:mm:ss", null).ToString("HH:mm");
            plantModel.EndTime = DateTime.ParseExact(plantModel.EndTime, "HH:mm:ss", null).ToString("HH:mm");
            plantModel.CurrencyCodes = currencyCode.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Languages = languages.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Uoms = uoms.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();

            return plantModel;
        }

        /// <summary>
        ///     The plant Setup save
        /// </summary>
        /// <param name="plant">Save the plant details</param>
        /// <returns>HttpResponseMessage</returns>
        [HttpPost]
        public HttpResponseMessage Save(PlantModel plant)
        {
            plant.LastModifiedTimeStamp = DateTime.SpecifyKind(plant.LastModifiedTimeStamp, DateTimeKind.Utc);
            int result = 0;
            User user = this.GetUser();
            try
            {
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                plant.MaxNumberOfRecords = this.PlantService.GetMaxNumberOfRecords(plant.EcoalabAccountNumber);
                Plant objPlant = EntityConverter.ConvertToServiceModel(plant);
                if(isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    objPlant.EcoalabAccountNumber = this.PlantService.SavePlantDetails(objPlant, user.UserId, out lastModifiedTimeStamp);
                }   
                else
                {
                    result = Push.PushToLocal(objPlant, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdatePlant);
                }
                switch(result)
                {
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch(Exception ex)
            {
                //Logger.Error("PlantSetup  - Save Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "An exception occurred saving the plant details.");
            }
        }

        /// <summary>
        ///     Gets the values
        /// </summary>
        /// <param name="id">gets the values by ID</param>
        /// <returns>Returns the fetched values</returns>
        public string Get(int id)
        {
            return "value";
        }

        /// <summary>
        ///     Post the values
        /// </summary>
        /// <param name="value">Post the fetched values</param>
        public void Post([FromBody] string value)
        {
        }

        /// <summary>
        ///     Update the values
        /// </summary>
        /// <param name="id">Update the values by ID</param>
        /// <param name="value">Update the modified values</param>
        public void Put(int id, [FromBody] string value)
        {
        }

        /// <summary>
        ///     Delete the values
        /// </summary>
        /// <param name="id">Delete the values by ID</param>
        public void Delete(int id)
        {
        }
    }
}