﻿// -----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Customer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Helper;
    using Models.PlantSetup;
    using Services.Interfaces;

    /// <summary>
    ///     class Customer Controller
    /// </summary>
    public class CustomerController : BaseApiController
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private readonly IPlantCustomerService plantCustService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="CustomerController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantCustService">The Plant Customer Service</param>
        /// <param name="plantService">The plant service</param>
        public CustomerController(IUserService userService, IPlantCustomerService plantCustService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.plantCustService = plantCustService;
        }

        /// <summary>
        ///     Get the Customer list
        /// </summary>
        /// <returns>Returns the Customer list</returns>
        [HttpGet]
        public IEnumerable<PlantCustomerModel> GetCustomer()
        {
            var user = GetUser();
            List<PlantCustomer> cust = plantCustService.GetPlantCustomer(user.EcolabAccountNumber);
            List<PlantCustomerModel> custList = cust.Select(EntityConverter.ConvertToWebModel).ToList();
            custList = custList.Where(item => item.IsDeleted == false).ToList();
            return custList.AsEnumerable();
        }

        /// <summary>
        ///     creates new the customer data
        /// </summary>
        /// <param name="data">customer data to create</param>
        /// <returns>Returns created customer data</returns>
        [HttpPost]
        public HttpResponseMessage CreateCustomer([FromBody] List< PlantCustomerModel> data)
        {
            User user = this.GetUser();
            int response = 0;
            int id = 0;
            PlantCustomer objplantCust = EntityConverter.ConvertToServiceModel(data[0]);
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                objplantCust.MaxNumberOfRecords = plantCustService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                objplantCust.EcoalabAccountNumber = user.EcolabAccountNumber;

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    response = this.plantCustService.SavePlantCustomer(objplantCust, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    response = Push.PushToLocal(objplantCust, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddPlantCustomer, out id);
                    if (response == 0)
                    {
                        response = id;
                    }
                }
                switch (response)
                {
                    case 49:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
            }
            catch (Exception)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Customer already exist. Please enter new customer id.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        /// <summary>
        ///     To update the customer details
        /// </summary>
        /// <param name="id">customer id</param>
        /// <param name="data">customer data to update</param>
        /// <returns>Returns updated customer data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int id, PlantCustomerModel data)
        {
            var user = GetUser();
            int response = 0;
            PlantCustomer objplantCust = Ecolab.TCDConfigurator.Web.Helper.EntityConverter.ConvertToServiceModel(data);
            objplantCust.MaxNumberOfRecords = plantCustService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            if (id > 0)
            {
                try
                {
                    objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                    objplantCust.EcoalabAccountNumber = user.EcolabAccountNumber;

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        objplantCust.Id = this.plantCustService.SavePlantCustomer(objplantCust, user.UserId, out lastModifiedTimeStamp);
                        if (objplantCust.Id == 301)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "301");
                        }
                    }
                    else
                    {
                        objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                        response = Push.PushToLocal(objplantCust, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdatePlantCustomer);
                    }
                    switch (response)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        case 49:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 2627)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Customer Id already exists. Please try again.");
                    }
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the customer. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid customer details.");
        }

        /// <summary>
        ///     To update the customer details
        /// </summary>
        /// <param name="data">Customer data to update</param>
        /// <returns>Returns the updated data</returns>
        [HttpPut]
        public HttpResponseMessage Put(List< PlantCustomerModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (PlantCustomerModel PlantCustomerModel in data)
            {
                HttpResponseMessage = this.Put(PlantCustomerModel.CustomerId, PlantCustomerModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Delete the Customer
        /// </summary>
        /// <param name="id">Delete the cUstomer based on ID</param>
        /// <param name="plantCustomerModel">The Plant Customer Model</param>
        /// <returns>Returns the Customer data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteCustomer(int? id, PlantCustomerModel plantCustomerModel)
        {
            int response = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            PlantCustomer objplantCust = EntityConverter.ConvertToServiceModel(plantCustomerModel);
            if (id > 0)
            {
                try
                {
                    objplantCust.MaxNumberOfRecords = plantCustService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                    if (user != null)
                    {
                        int userId = user.UserId;
                        DateTime lastModifiedTimeStamp;
                        if (isDisconnected)
                        {
                            this.plantCustService.DeletePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                            response = Push.PushToLocal(objplantCust, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeletePlantCustomer);
                        }
                        switch (response)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                            case 51060:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        }
                    }
                }
                catch
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the customer. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid customer details.");
        }

        /// <summary>
        ///     Delete the Customer data
        /// </summary>
        /// <param name="data">Delete the Customer datas</param>
        /// <returns>Returns the deleted data by Id</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteCustomer(List< PlantCustomerModel> data)
        {
            return this.DeleteCustomer(data[0].Id, data[0]);
        }
    }
}