﻿// -----------------------------------------------------------------------
// <copyright file="SensorController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Models;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using WebModel = Models.PlantSetup;

    /// <summary>
    /// class SensorController
    /// </summary>
    public class SensorController : BaseApiController
    {
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Sensor Service
        /// </summary>
        private readonly ISensorService sensorService;

        /// <summary>
        ///     Initializes a new instance of the SensorController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="sensorService">Sensor Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plcService">The Plc Service</param>
        public SensorController(IUserService userService, ISensorService sensorService, IPlantService plantService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.sensorService = sensorService;
            this.plcService = plcService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        [HttpGet]
        public IEnumerable<WebModel.SensorWebModel> GetSensor()
        {
            User user = this.GetUser();
            List<Sensor> sensors = this.sensorService.GetPlantSensorDetails(null, user.EcolabAccountNumber);
            List<WebModel.SensorWebModel> sensorList = Mapper.Map<List<Sensor>, List<WebModel.SensorWebModel>>(sensors);
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            var tagsList = new List<OpcTag>();
            TagCollection tagStatus = new TagCollection();
            foreach (WebModel.SensorWebModel model in sensorList)
            {
                if (!string.IsNullOrEmpty(model.CalibrationTag4))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.CalibrationTag4,
                        Value = model.CalibrationValue4.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (!string.IsNullOrEmpty(model.CalibrationTag20))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.CalibrationTag20,
                        Value = model.CalibrationValue20.ToString(CultureInfo.CurrentCulture)
                    });
                }
            }
            if (tagsList.Count > 0)
            {
                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, sensorList.FirstOrDefault().ControllerId.Value);
                List<string> tagCollectionList = new List<string>();
                //  CompareTags(tagStatus, tags, out tagsDetails);
                foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                {
                    tagCollectionList.AddRange(
                        tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value))
                            .Where(plcTag => tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                            .Select(plcTag => tag.Address));
                }
                foreach (WebModel.SensorWebModel metaData in sensorList)
                {
                    if (!string.IsNullOrEmpty(metaData.CalibrationTag4) && tagCollectionList.Contains(metaData.CalibrationTag4))
                    {
                        metaData.Calibration4Override = true;
                    }
                    if (!string.IsNullOrEmpty(metaData.CalibrationTag20) && tagCollectionList.Contains(metaData.CalibrationTag20))
                    {
                        metaData.Calibration20Override = true;
                    }
                }
            }
            return sensorList.AsEnumerable();
        }

        /// <summary>
        ///     creates new the sensor
        /// </summary>
        /// <param name="data">Sensor data to create</param>
        /// <returns>Returns created sensor data</returns>
        [HttpPost]
        public HttpResponseMessage CreateSensor([FromBody] List<WebModel.SensorWebModel> data)
        {
            try
            {
                User user = this.GetUser();
                int? controllerId = null;
                if ((data[0].SensorLocationId == null && data[0].MachineId == null) || data[0].ControllerId == null)
                {
                    if (data[0].ControllerId != null)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "603");
                    }
                    data[0].ControllerId = -1;
                    data[0].ControllerModelId = 5;

                    List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(null, null, this.EcolabAccountNumber);
                    IEnumerable<ConduitController> utilityLogger = controller.Where(_ => _.ControllerModelId == 5);
                    ConduitController[] conduitControllers = utilityLogger as ConduitController[] ?? utilityLogger.ToArray();
                    if (conduitControllers.Any())
                    {
                        ConduitController first = conduitControllers.FirstOrDefault();
                        if (first != null)
                        {
                            controllerId = first.ControllerId;
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "701");
                    }
                }
                else if (data[0].SensorLocationId != null && data[0].MachineId == null)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "602");
                }
                else if (data[0].SensorLocationId != null && data[0].ControllerId == 0)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "601");
                }
                else
                {
                    controllerId = data[0].ControllerId;
                }

                Sensor objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data[0]);
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                objSensor.MaxNumberOfRecords = this.sensorService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                objSensor.EcolabAccountNumber = this.EcolabAccountNumber;
                objSensor.LastModifiedTime = DateTime.SpecifyKind(objSensor.LastModifiedTime, DateTimeKind.Utc);
                objSensor.AnalogueImputNumber = null;
                objSensor.CalibrationTag4 = null;
                objSensor.CalibrationTag20 = null;

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    string errorCode;
                    objSensor.SensorNumber = this.sensorService.SavePlantSensorDetails(objSensor, user.UserId, out errorCode, out lastModifiedTimeStamp);

                    if (!string.IsNullOrWhiteSpace(errorCode))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode + "#" + objSensor.SensorNumber);
                    }
                }
                else
                {
                    int retVal = Push.PushToLocal(objSensor, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddSensor);

                    if (retVal != 0)
                    {
                        if (retVal == 51030)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                        }
                        else if (retVal == 51060)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                        }
                        else if (retVal == 60000)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                        }
                        else if (retVal == 54)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "101");
                        }
                        else if (retVal == 55)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "201");
                        }
                        else if (retVal == 56)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "301");
                        }
                        else if (retVal == 57)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "401");
                        }
                        else if (retVal == 58)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "501");
                        }
                        else if (retVal == 59)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "405");
                        }
                        else if (retVal == 60)
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "701");
                        }
                       
                        const string errorMessage = "Unable to save the Sensor Details. Some error has occured. Please try again.";
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);                    
                        
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Sensor - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Sensor addition failed");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     To update the Sensor details
        /// </summary>
        /// <param name="id">Sensor id</param>
        /// <param name="data">Sensor data to update</param>
        /// <returns>Returns updated Sensor data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, WebModel.SensorWebModel data)
        {
            if (id > 0)
            {
                try
                {
                    User user = this.GetUser();
                    Sensor objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data);
                    bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                    objSensor.MaxNumberOfRecords = this.sensorService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    objSensor.EcolabAccountNumber = this.EcolabAccountNumber;
                    objSensor.LastModifiedTime = DateTime.SpecifyKind(objSensor.LastModifiedTime, DateTimeKind.Utc);
                    objSensor.AnalogueImputNumber = null;
                    objSensor.CalibrationTag4 = null;
                    objSensor.CalibrationTag20 = null;

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        string errorCode;
                        objSensor.SensorNumber = this.sensorService.SavePlantSensorDetails(objSensor, user.UserId, out errorCode, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        int retVal = Push.PushToLocal(objSensor, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateSensor);

                        if (retVal != 0)
                        {
                            if (retVal == 51030)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            }
                            else if (retVal == 51060)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                            }
                            else if (retVal == 60000)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                            }
                            const string errorMessage = "Unable to update the Sensor Details. Some error has occured. Please try again.";
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Sensor - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Sensor. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Sensor details.");
        }

        /// <summary>
        ///     To update the Sensor details
        /// </summary>
        /// <param name="data">Sensor data to update</param>
        /// <returns>Status Message</returns>
        [HttpPut]
        public HttpResponseMessage Put(List<WebModel.SensorWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.SensorWebModel SensorWebModel in data)
            {
                HttpResponseMessage = this.Put(SensorWebModel.SensorNumber, SensorWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Method to set all the default dropdown values
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Dictionary object</returns>
        [HttpGet]
        public Dictionary<string, object> GetDefaults(int? id)
        {
            User user = this.GetUser();
            int? machineId = null;
            int? locationId = null;
            int? controllerId = null;
            var sensorData = new Dictionary<string, object>();
            if (id != null)
            {
                List<Sensor> sensors = this.sensorService.GetPlantSensorDetails(null, user.EcolabAccountNumber);
                List<WebModel.SensorWebModel> sensorList = Mapper.Map<List<Sensor>, List<WebModel.SensorWebModel>>(sensors);
                WebModel.SensorWebModel sensor = sensorList.FirstOrDefault(a => a.SensorNumber == id);
                List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(sensor.SensorLocationId, sensor.MachineId, user.EcolabAccountNumber);
                List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);
                IEnumerable<WebModel.MachineSetupModel> machineList = this.GetMachineOrCompartment(sensor.SensorLocationId, Convert.ToInt32(sensor.SensorType));
                // set is tunnel
                IEnumerable<WebModel.UOMSensorModel> unitofMeasureList = this.GetUomSensorDetails(sensor.SensorType);
                sensorData.Add("Sensor", sensor);
                sensorData.Add("SensorController", controllerList);
                sensorData.Add("MachineList", machineList);
                sensorData.Add("UoMList", unitofMeasureList);
                sensorData.Add("Counters", this.sensorService.FetchCounters(sensor.SensorLocationId, sensor.MachineId, sensor.SensorType.HasValue ? sensor.SensorType.Value.ToString() : string.Empty, sensor.IsTunnel ,false, this.EcolabAccountNumber, id, sensor.ControllerId));
                locationId = sensor.SensorLocationId;
                machineId = sensor.MachineId;
                controllerId = sensor.ControllerId;
            }
            else
            {
                List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(null, null, user.EcolabAccountNumber);
                List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);
                sensorData.Add("SensorController", controllerList);
            }
            IEnumerable<WebModel.SensorChemicalChartModel> chemicalsList = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, user.EcolabAccountNumber)).AsEnumerable();
            sensorData.Add("ChemicalList", chemicalsList);
            List<SensorType> sensorType = this.sensorService.GetSensorTypeDetails();
            List<WebModel.SensorTypeModel> sensorTypeList = Mapper.Map<List<SensorType>, List<WebModel.SensorTypeModel>>(sensorType);
            List<GroupType> utilityLocations = this.sensorService.GetGroupTypeDetails(user.EcolabAccountNumber);
            List<GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<GroupTypeModel>>(utilityLocations);
            sensorData.Add("SensorType", sensorTypeList);
            sensorData.Add("SensorLocation", utilityLocationsList);
            return sensorData;
        }

        /// <summary>
        ///     Method to Get Machine or Compartment based on location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>Machines or compartments</returns>
        [HttpGet]
        public IEnumerable<WebModel.MachineSetupModel> GetMachineOrCompartment(int? id, int sensorTypeId = 0)
        {
            User user = this.GetUser();
            List<MachineSetup> machineOrCompartment = this.sensorService.GetPlantMachineDetails(id, user.EcolabAccountNumber, sensorTypeId);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);
            return machineOrCompartmentList.AsEnumerable();
        }

        /// <summary>
        ///     Method to Get UoM based on location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <returns>list of UOM's</returns>
        [HttpGet]
        public IEnumerable<WebModel.UOMSensorModel> GetUomSensorDetails(int? id)
        {
            List<UOMSensor> uom = this.sensorService.GetUomSensorDetails(id);
            List<WebModel.UOMSensorModel> uomList = Mapper.Map<List<UOMSensor>, List<WebModel.UOMSensorModel>>(uom);
            return uomList.AsEnumerable();
        }

        /// <summary>
        ///     Method to get Controller and Machine values based on Sensor Location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>Machines/Compartments</returns>
        [HttpGet]
        public Dictionary<string, object> GeOnLocationChange(int id, int sensorTypeId = 0)
        {
            User user = this.GetUser();
            List<MachineSetup> machineOrCompartment = this.sensorService.GetPlantMachineDetails(id, user.EcolabAccountNumber, sensorTypeId);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            List<ConduitController> controller = (id > 0)
                ? this.sensorService.GetConduitControllerDetails(id, null, user.EcolabAccountNumber)
                : this.sensorService.GetConduitControllerDetails(null, null, user.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList =
                Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            List<WebModel.SensorChemicalChartModel> chemicalForChart = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(id, null, null, user.EcolabAccountNumber));
            var controllerData = new Dictionary<string, object>
            {
                { "Controller", controllerList },
                { "Machine", machineOrCompartmentList },
                { "ChemicalForChart", chemicalForChart }
            };
            return controllerData;
        }

        /// <summary>
        ///     Method to get UoM values on Sensor Type change
        /// </summary>
        /// <param name="id">id of the sensor type</param>
        /// <returns>UOM's assosiated to the sensor</returns>
        [HttpGet]
        public Dictionary<string, object> GeOnSensorTypeChange(int id)
        {
            List<UOMSensor> uom = this.sensorService.GetUomSensorDetails(id);
            List<WebModel.UOMSensorModel> uomList = Mapper.Map<List<UOMSensor>, List<WebModel.UOMSensorModel>>(uom);
            var uomData = new Dictionary<string, object> { { "UoM", uomList } };
            return uomData;
        }

        /// <summary>
        ///     Method to get on Controller Change
        /// </summary>
        /// <param name="locationId">The Locaion Id</param>
        /// <param name="machineId">id of the machine/compartment</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>Chemicals for chart</returns>
        [HttpGet]
        public IEnumerable<WebModel.SensorChemicalChartModel> GetOnControllerChange(int? locationId, int? machineId, int controllerId)
        {
            User user = this.GetUser();
            return Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, user.EcolabAccountNumber)).AsEnumerable();
        }

        /// <summary>
        ///     Gets data on machine Dropdown change
        /// </summary>
        /// <param name="locationId">The Location Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>List of SensorChemicalChartModel and ConduitControllerModel</returns>
        [HttpGet]
        public Dictionary<string, object> GetOnMachineCompartmentChange(int? locationId, int? machineId, int sensorTypeId = 0)
        {
            User user = this.GetUser();
            int controllerId = 0;
            MachineSetup machine = this.sensorService.GetPlantMachineDetails(locationId, user.EcolabAccountNumber, sensorTypeId).FirstOrDefault(_ => _.MachineId == machineId);
            if (machine != null)
            {
                controllerId = machine.ControllerId;
            }
            List<WebModel.SensorChemicalChartModel> chemicalForChart = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, user.EcolabAccountNumber));
            List<WebModel.ConduitControllerModel> controller = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(this.sensorService.GetConduitControllerDetails(locationId, machineId, user.EcolabAccountNumber));
            return new Dictionary<string, object> { { "ChemicalForChart", chemicalForChart }, { "Controller", controller } };
        }

        /// <summary>
        ///     Delete the Sensor
        /// </summary>
        /// <param name="id">Delete the Sensor based on ID</param>
        /// <param name="data">The Sensor Model Data</param>
        /// <returns>Returns the Sensor data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteSensor(int? id, WebModel.SensorWebModel data)
        {
            if (id > 0)
            {
                try
                {
                    User user = this.GetUser();
                    Sensor objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data);
                    bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                    objSensor.MaxNumberOfRecords = this.sensorService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    objSensor.LastModifiedTime = DateTime.SpecifyKind(objSensor.LastModifiedTime, DateTimeKind.Utc);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        int error;
                        this.sensorService.DeletePlantSensorDetails(objSensor, user.UserId, out error, out lastModifiedTimeStamp);
                        if (error > 0)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, error);
                        }
                    }
                    else
                    {
                        int retVal = Push.PushToLocal(objSensor, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteSensor);

                        if (retVal != 0)
                        {
                            if (retVal == 51030)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            }
                            else if (retVal == 51060)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                            }
                            else if (retVal == 60000)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                            }
                            const string errorMessage = "Unable to delete the Sensor Details. Some error has occured. Please try again.";
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Meter - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the sensor. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid sensor details.");
        }

        /// <summary>
        ///     Method to delete sensor
        /// </summary>
        /// <param name="data">Sensor Model</param>
        /// <returns>Whether sensor deleted or not</returns>
        public HttpResponseMessage DeleteSensor(List<WebModel.SensorWebModel> data)
        {
            return this.DeleteSensor(data[0].SensorNumber, data[0]);
        }

        /// <summary>
        /// Fetches the external or internal counter
        /// </summary>
        /// <param name="locationId">The locationId</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="utilityTypeId">Utility Type Id</param>
        /// <param name="isTunnel">Is Tunnel</param>
        /// <param name="sensorId">Sensor Id</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns></returns>
        [HttpGet]
        public Dictionary<string, string> FetchCounters(int? locationId, int? washerId, string utilityTypeId, bool isTunnel, int? sensorId, int? controllerId)
        {
            return this.sensorService.FetchCounters(locationId, washerId, utilityTypeId, isTunnel, false, this.EcolabAccountNumber, sensorId, controllerId);
        }
    }
}