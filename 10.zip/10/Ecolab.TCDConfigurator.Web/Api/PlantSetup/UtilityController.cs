﻿// -----------------------------------------------------------------------
// <copyright file="UtilityController.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Utility Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    /// <summary>
    ///     Api controller for Utility
    /// </summary>
    public class UtilityController : BaseApiController
    {
        /// <summary>
        ///     Utility Service
        /// </summary>
        private readonly IUtilityService utilityService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="UtilityController" /> class.
        /// </summary>
        /// <param name="userService"> the user service </param>
        /// <param name="utilityService">the utility service </param>
        /// <param name="plantService">Plant Service</param>
        public UtilityController(IUserService userService, IUtilityService utilityService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.utilityService = utilityService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// List of utilities
        /// </summary>
        /// <value>The utility list.</value>
        public static List<Utility> utilities { get; set; }

        /// <summary>
        ///     GET api/utility
        /// </summary>
        /// <returns>List of UtilityModel</returns>
        [HttpGet]
        public IEnumerable<UtilityModel> GetUtility()
        {
            var user = GetUser();
            utilities = utilityService.GetUtilityDetails(user.EcolabAccountNumber);

            List<UtilityModel> utilityList = Mapper.Map<List<Utility>, List<UtilityModel>>(utilities);
            return utilityList.AsEnumerable();
        }

        /// <summary>
        ///     Get utility details for edit
        /// </summary>
        /// <returns>The dictonary.</returns>
        [HttpGet]
        public Dictionary<string, object> GetUtilityOnAddNew()
        {
            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();
            List<DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<DeviceTypeModel>>(deviceTypes);

            var utilityData = new Dictionary<string, object> { { "DeviceType", deviceTypeList }, { "DeviceNumber", utilities.Max(x => x.DeviceNumber) != null ? utilities.Max(x => x.DeviceNumber) + 1 : 1 } };

            return utilityData;
        }

        /// <summary>
        ///     Get utility details for edit
        /// </summary>
        /// <param name="id">The Parameter ID</param>
        /// <returns>Returns Dictionary</returns>
        [HttpGet]
        public Dictionary<string, object> GetUtilityOnEdit(int id)
        {
            var user = GetUser();
            List<Utility> utilities = utilityService.GetUtilityDetails(EcolabAccountNumber);

            Mapper.CreateMap<Utility, UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                DateTime dt = src.InstallDate;
                return string.Format("{0:MM'/'dd'/'yyyy}", dt);
            }));
            List<UtilityModel> utilityList = Mapper.Map<List<Utility>, List<UtilityModel>>(utilities);
            UtilityModel utility = utilityList.FirstOrDefault(a => a.Id == id);

            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();
            List<DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<DeviceTypeModel>>(deviceTypes);

            List<DeviceModel> deviceModels = this.utilityService.GetDeviceModelDetails(utility.DeviceTypeId, this.EcolabAccountNumber);
            List<DevicemodelModel> deviceModelList = Mapper.Map<List<DeviceModel>, List<DevicemodelModel>>(deviceModels);

            var utilityData = new Dictionary<string, object> { { "Utility", utility }, { "DeviceType", deviceTypeList }, { "DeviceModel", deviceModelList } };
            return utilityData;
        }

        /// <summary>
        ///     GET Device type details
        /// </summary>
        /// <returns>IEnumerable DeviceTypeModel</returns>
        [HttpGet]
        public IEnumerable<DeviceTypeModel> GetDeviceTypeDetails()
        {
            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();

            // AutoMapper.Mapper.CreateMap<Model.Common.DeviceType, WebModel.DeviceTypeModel>();
            List<DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<DeviceTypeModel>>(deviceTypes);
            return deviceTypeList.AsEnumerable();
        }

        /// <summary>
        ///     GET Device model details
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <returns>List of Device Model</returns>
        [HttpGet]
        public IEnumerable<DevicemodelModel> GetDeviceModelDetails(int id)
        {
            List<DeviceModel> deviceModels = this.utilityService.GetDeviceModelDetails(id, this.EcolabAccountNumber);

            //AutoMapper.Mapper.CreateMap<Model.PlantSetup.DeviceModel, WebModel.DevicemodelModel>();
            List<DevicemodelModel> deviceModelList = Mapper.Map<List<DeviceModel>, List<DevicemodelModel>>(deviceModels);
            return deviceModelList.AsEnumerable();
        }

        /// <summary>
        ///     creates the new utility data
        /// </summary>
        /// <param name="data">Utility data to create</param>
        /// <returns>Returns the created utility data</returns>
        [HttpPost]
        public HttpResponseMessage CreateUtility([FromBody] List< UtilityModel> data)
        {
            var user = GetUser();
            int result = 0;
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                bool deviceNumberExists = utilities.Any(x => x.DeviceNumber == data[0].DeviceNumber);
                if (!deviceNumberExists)
                {
                    data[0].MaxNumberOfRecords = utilityService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    data[0].EcolabAccountNumber = user.EcolabAccountNumber;
                    DateTime dateTime;
                    if (DateTime.TryParse(data[0].InstallDate, out dateTime))
                    {
                        Utility objUtility = Mapper.Map<UtilityModel, Utility>(data[0]);
                        int userId = user.UserId;
                        objUtility.MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid();
                        objUtility.InstallDate = DateTime.SpecifyKind(objUtility.InstallDate, DateTimeKind.Utc);
                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            result = this.utilityService.SaveUtilityDetails(objUtility, userId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                           result = Push.PushToLocal(objUtility, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddUtility);
                        }
                        switch (result)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            case 401:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "401");

                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                            case 51060:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid install date. Please try again");
                    }
                }
                else
                {
                    //501 - Device number already exists
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "501");
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Api - Utility - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     update the utility details
        /// </summary>
        /// <param name="id">device number</param>
        /// <param name="data">Utility data</param>
        /// <returns>Http response message</returns>
        [HttpPut]
        public HttpResponseMessage Put(int id, UtilityModel data)
        {
            var user = GetUser();
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            if (id > 0)
            {
                try
                {
                    int deviceNumberExists = utilities.Count(x => (x.DeviceNumber == data.DeviceNumber) && (x.Id != data.Id));
                    if (deviceNumberExists == 0)
                    {
                        data.MaxNumberOfRecords = this.utilityService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                        //data.DeviceModelId = id; // to be confirmed
                        data.EcolabAccountNumber = user.EcolabAccountNumber;

                        int userId = user.UserId;
                        DateTime dateTime;
                        if (DateTime.TryParse(data.InstallDate, out dateTime))
                        {
                            Utility objUtility = Mapper.Map<UtilityModel, Utility>(data);
                            objUtility.InstallDate = DateTime.SpecifyKind(objUtility.InstallDate, DateTimeKind.Utc);
                            objUtility.LastModifiedTimeStamp = DateTime.SpecifyKind(objUtility.LastModifiedTimeStamp, DateTimeKind.Utc);
                            if (isDisconnected)
                            {
                                DateTime lastModifiedTimeStamp;
                                result = this.utilityService.SaveUtilityDetails(objUtility, userId, out lastModifiedTimeStamp);
                            }
                            else
                            {
                                result = Push.PushToLocal(objUtility, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateUtility);
                            }

                            switch (result)
                            {
                                case 51030:
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");

                                case 401:
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "401");

                                case 60000:
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");

                                case 51060:
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                            }
                        }
                        else
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid install date. Please try again");
                        }
                    }
                    else
                    {
                        //501 - Device number already exists
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "501");
                    }
                }
                catch (SqlException ex)
                {
                    Logger.Error("Api - Utility - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    string msg = string.Empty;
                    msg = ex.Message;
                    if (ex.Number == 2627)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Utility already exists. Please try again.");
                    }
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, msg);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid utility details.");
        }

        /// <summary>
        ///     To update the utility details
        /// </summary>
        /// <param name="data">Utility data to update</param>
        /// <returns>Returns the updated utility data</returns>
        public HttpResponseMessage Put(List< UtilityModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (UtilityModel UtilityModel in data)
            {
                HttpResponseMessage = this.Put((int)UtilityModel.DeviceNumber, UtilityModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Delete the Utility data
        /// </summary>
        /// <param name="id">Device Number</param>
        /// <param name="data">The Utility Model object</param>
        /// <returns>the deleted data</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteUtility(int? id, UtilityModel data)
        {
            User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            if (id > 0)
            {
                try
                {
                    data.IsDeleted = true;
                    data.EcolabAccountNumber = user.EcolabAccountNumber;
                    data.MaxNumberOfRecords = this.utilityService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                    int userId = user.UserId;
                    Utility objUtility = Mapper.Map<UtilityModel, Utility>(data);
                    objUtility.InstallDate = DateTime.SpecifyKind(objUtility.InstallDate, DateTimeKind.Utc);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = utilityService.DeleteUtilityDetails(id.Value, userId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(objUtility, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteUtility);
                    }

                    switch (result)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");

                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");

                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("Api - Utility - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the utility. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid utility details.");
        }

        /// <summary>
        ///     Delete Utility
        /// </summary>
        /// <param name="data">data parameter</param>
        /// <returns>HttpResponseMessage</returns>
        public HttpResponseMessage DeleteUtility(List< UtilityModel> data)
        {
            return this.DeleteUtility(data[0].DeviceNumber, data[0]);
        }
    }
}