﻿// -----------------------------------------------------------------------
// <copyright file="MeterController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Meter Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Models;
    using Models.Common;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using WebModel = Models.PlantSetup;
    using Services.Interfaces.Washers;

    /// <summary>
    ///     Class Meter Controller
    /// </summary>
    public class MeterController : BaseApiController
    {
        /// <summary>
        ///     Meter Service
        /// </summary>
        private readonly IMeterService meterService;

        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlantUtilityService plantUtilityService;
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlantService plantService;

        /// <summary>
        /// The washer service
        /// </summary>
        private readonly IWasherServices washerService;

        /// <summary>
        ///     Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="meterService">The meter service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="plcService">The PLC Service</param>
        public MeterController(IUserService userService, IMeterService meterService, IPlantService plantService, IPlcService plcService, IPlantUtilityService plantUtilityService, IWasherServices washerService)
            : base(userService, plantService)
        {
            this.meterService = meterService;
            this.plcService = plcService;
            this.plantUtilityService = plantUtilityService;
            this.plantService = plantService;
            this.washerService = washerService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get the Meter details
        /// </summary>
        /// <returns>List of MeterModel</returns>
        [HttpGet]
        public IEnumerable<WebModel.MeterWebModel> GetMeter()
        {
            List<Meter> meters = this.meterService.GetPlantMeterDetails(null, this.EcolabAccountNumber);

            List<WebModel.MeterWebModel> meterList = Mapper.Map<List<Meter>, List<WebModel.MeterWebModel>>(meters);
            meterList.ForEach(_ => _.CalibrationAsString = _.Calibration.ToString("#,0.##"));
            meterList.ForEach(_ => _.MaxValueLimitAsString = _.MaxValueLimit.ToString("#,0.##"));
            return meterList.AsEnumerable();
        }

        /// <summary>
        ///     Gets Meter Details on Add Clicked
        /// </summary>
        /// <returns>Dictionary of ResourceMasterModel, GroupTypeModel, ParentMeterModel, ConduitControllerModel</returns>
        [HttpGet]
        public Dictionary<string, object> GetMeterOnAdd()
        {
            List<ResourceMaster> utilityType = this.meterService.GetUtilitySetupDetails();
            List<WebModel.ResourceMasterModel> utilityTypeList = Mapper.Map<List<ResourceMaster>, List<WebModel.ResourceMasterModel>>(utilityType);

            List<GroupType> utilityLocations = this.meterService.GetMeterUtilityLocation(this.EcolabAccountNumber);
            List<GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<GroupTypeModel>>(utilityLocations);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(null, null, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            Ecolab.Models.Plant plantDetails = this.plantService.GetPlantDetails(this.EcolabAccountNumber);
            List<PlantUtilityWaterTypeMaster> waterTypes = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, plantDetails.RegionId);
            List<WebModel.PlantUtilityWaterTypeMasterModel> waterTypesList = Mapper.Map<List<PlantUtilityWaterTypeMaster>, List<WebModel.PlantUtilityWaterTypeMasterModel>>(waterTypes);

            var meterData = new Dictionary<string, object> { { "UtilityType", utilityTypeList }, { "UtilityLocation", utilityLocationsList }, { "Controller", controllerList }, { "WaterType", waterTypesList } };
            return meterData;
        }

        /// <summary>
        ///     Gets Meter Details on Edit Clicked
        /// </summary>
        /// <param name="id">Meter Id</param>
        /// <returns>
        ///     Dictionary of selected MeterModel, ResourceMasterModel, GroupTypeModel, MachineSetupModel, ParentMeterModel,
        ///     UOMMeterModel, ConduitControllerModel
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GetMeterOnEdit(int id)
        {
            Meter meterDetails = this.meterService.GetPlantMeterDetails(id, this.EcolabAccountNumber).FirstOrDefault();
            WebModel.MeterWebModel meter = Mapper.Map<Meter, WebModel.MeterWebModel>(meterDetails);

            List<Ecolab.Models.Washers.Washers> washerlist = this.washerService.GetWashersDetails(this.EcolabAccountNumber, meter.UtilityId.Value, false).ToList();
            meter.IsTunnel = washerlist.Where(x => x.WasherType.Contains("WasherExtractor")).Count() > 0 ? false : true;

            List<ResourceMaster> utilityType = this.meterService.GetUtilitySetupDetails();
            List<WebModel.ResourceMasterModel> utilityTypeList = Mapper.Map<List<ResourceMaster>, List<WebModel.ResourceMasterModel>>(utilityType);

            List<GroupType> utilityLocations = this.meterService.GetMeterUtilityLocation(this.EcolabAccountNumber);
            List<GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<GroupTypeModel>>(utilityLocations);

            List<MachineSetup> machineOrCompartment = this.meterService.GetPlantMachineDetails(meter.UtilityId, this.EcolabAccountNumber);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            int meterType = Convert.ToInt32(meter.MeterType);
            List<ParentMeter> parent = this.meterService.GetParentMeterDetails(meterType, id, this.EcolabAccountNumber);
            List<WebModel.ParentMeterModel> parentList = Mapper.Map<List<ParentMeter>, List<WebModel.ParentMeterModel>>(parent);

            List<UOMMeter> uom = this.meterService.GetUomMeterDetails(Convert.ToInt32(meter.MeterType));
            List<WebModel.UOMMeterModel> uomList = Mapper.Map<List<UOMMeter>, List<WebModel.UOMMeterModel>>(uom);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(meter.UtilityId, meter.MachineId, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            Ecolab.Models.Plant plantDetails = this.plantService.GetPlantDetails(this.EcolabAccountNumber);
            List<PlantUtilityWaterTypeMaster> waterTypes = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, plantDetails.RegionId);
            List<WebModel.PlantUtilityWaterTypeMasterModel> waterTypesList = Mapper.Map<List<PlantUtilityWaterTypeMaster>, List<WebModel.PlantUtilityWaterTypeMasterModel>>(waterTypes);

            var meterData = new Dictionary<string, object> { { "Meter", meter }, { "UtilityType", utilityTypeList }, { "UtilityLocation", utilityLocationsList }, { "MachineCompartment", machineOrCompartmentList }, { "Parent", parentList }, { "UOM", uomList }, { "Controller", controllerList }, { "WaterType", waterTypesList }, { "Counters", this.meterService.FetchCounters(meter.GroupId, meter.MachineId, meter.MeterType, meter.MeterId.Value, meter.IsTunnel, true, this.EcolabAccountNumber, meter.ControllerId) } };
            return meterData;
        }

        /// <summary>
        /// Ges the on utility location change.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns dictionary of string and the object
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GeOnUtilityLocationChange(int id)
        {
            int? locationId = id > 0 ? (int?)id : null;
            List<MachineSetup> machineOrCompartment = meterService.GetPlantMachineDetails(id, EcolabAccountNumber);
            List<WebModel.MachineSetupModel> machineOrCompartmentList =
                Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(locationId, null, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            var meterData = new Dictionary<string, object> { { "MachineCompartment", machineOrCompartmentList }, { "Controller", controllerList } };
            return meterData;
        }

        /// <summary>
        /// Gets UOM basing on Utility Type
        /// </summary>
        /// <param name="utilityId">Utility Type Id</param>
        /// <param name="id">The meter Id</param>
        /// <returns>List of UOM</returns>
        [HttpGet]
        public Dictionary<string, object> GetUom(int utilityId, int? id)
        {
            List<ParentMeter> parent = this.meterService.GetParentMeterDetails(utilityId, id, this.EcolabAccountNumber);
            List<WebModel.ParentMeterModel> parentList = Mapper.Map<List<ParentMeter>, List<WebModel.ParentMeterModel>>(parent);

            List<UOMMeter> uom = meterService.GetUomMeterDetails(utilityId);
            List<WebModel.UOMMeterModel> uomList = Mapper.Map<List<UOMMeter>, List<WebModel.UOMMeterModel>>(uom);

            return new Dictionary<string, object> { { "Parent", parentList }, { "UOM", uomList } };
        }

        /// <summary>
        ///     Gets data on machine Dropdown change
        /// </summary>
        /// <param name="locationId">The Location Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <returns>List of ConduitControllerModel</returns>
        [HttpGet]
        public List<WebModel.ConduitControllerModel> GetOnMachineCompartmentChange(int? locationId, int? machineId)
        {
            return Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(this.meterService.GetPlantMeterControllerDetailsOnMachineChange(locationId, machineId, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     creates new the Meter data
        /// </summary>
        /// <param name="data">Meter data to create</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPost]
        public HttpResponseMessage CreateMeter([FromBody] List<WebModel.MeterWebModel> data)
        {
            try
            {
                int controllerId;
                if (data[0].UtilityId == null && data[0].MachineId == null)
                {
                    data[0].ControllerId = -1;
                    data[0].ControllerModelId = 5;

                    List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(null, null, this.EcolabAccountNumber);
                    IEnumerable<ConduitController> utilityLogger = controller.Where(_ => _.ControllerModelId == 5);
                    if (utilityLogger.Any())
                    {
                        controllerId = utilityLogger.FirstOrDefault().ControllerId;
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "701" });
                    }
                }
                else if (data[0].UtilityId != null && data[0].MachineId == null)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                }
                else if (data[0].UtilityId != null && data[0].ControllerId == 0 && data[0].AllowManualEntry == false)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                }
                else
                {
                    controllerId = data[0].ControllerId;
                }

                Meter objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data[0]);
                bool isDisconnected = this.PlantService.IsPlantConnected(this.EcolabAccountNumber);
                objMeter.MaxNumberOfRecords = this.meterService.GetMaxNumberOfRecords(this.EcolabAccountNumber);
                objMeter.EcolabAccountNumber = this.EcolabAccountNumber;
                objMeter.LastModifiedTime = DateTime.SpecifyKind(objMeter.LastModifiedTime, DateTimeKind.Utc);
                objMeter.DigitalInputNumber = null;

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    string errorCode;
                    objMeter.MeterId = this.meterService.SavePlantMeterDetails(objMeter, this.UserId, out errorCode, out lastModifiedTimeStamp);

                    if (!string.IsNullOrWhiteSpace(errorCode))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode + "#" + objMeter.MeterId });
                    }
                }
                else
                {
                    int retVal = Push.PushToLocal(objMeter, EcolabAccountNumber, UserId, (int)TcdAdminMessageTypes.TcdAddMeters);

                    if (retVal != 0)
                    {
                        if (retVal == 69)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "101" });
                        }
                        else if (retVal == 62)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "201" });
                        }
                        else if (retVal == 61)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "301" });
                        }
                        else if (retVal == 63)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                        }
                        else if (retVal == 64)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "302" });
                        }
                        else if (retVal == 65)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                        }
                        else if (retVal == 66)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "601" });
                        }
                        else if (retVal == 67)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "701" });
                        }
                        else if (retVal == 68)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "405" });
                        }
                        else if (retVal == 51030)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "51030" });
                        }
                        else if (retVal == 60000)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "60000" });
                        }
                        else if (retVal == 51060)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "51060" });
                        }

                        string errorMessage = "Unable to save the Meter Details. Some error has occured. Please try again.";
                        return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorMessage });

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Api - Meter - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message });
            }

            return Request.CreateResponse(HttpStatusCode.OK, new { message = data });
        }

        /// <summary>
        ///     To update the Meter details
        /// </summary>
        /// <param name="id">Meter id</param>
        /// <param name="data">Meter data to update</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, WebModel.MeterWebModel data)
        {
            string errorCode = string.Empty;
            if (id > 0)
            {
                try
                {
                    if (data.UtilityId == null && data.MachineId == null && data.ControllerModelId != 5)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "601" });
                    }

                    if (data.UtilityId != null && data.MachineId == null)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                    }

                    if (data.UtilityId != null && data.ControllerId == 0 && data.AllowManualEntry == false)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                    }

                    Meter meterDetails = this.meterService.GetPlantMeterDetails(id, this.EcolabAccountNumber).FirstOrDefault();

                    Meter objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data);
                    bool isDisconnected = this.PlantService.IsPlantConnected(this.EcolabAccountNumber);
                    objMeter.MaxNumberOfRecords = this.meterService.GetMaxNumberOfRecords(this.EcolabAccountNumber);
                    objMeter.EcolabAccountNumber = this.EcolabAccountNumber;
                    objMeter.LastModifiedTime = DateTime.SpecifyKind(objMeter.LastModifiedTime, DateTimeKind.Utc);
                    objMeter.DigitalInputNumber = null;

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        objMeter.MeterId = this.meterService.SavePlantMeterDetails(objMeter, this.UserId, out errorCode, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        int retVal = Push.PushToLocal(objMeter, EcolabAccountNumber, UserId, (int)TcdAdminMessageTypes.TcdUpdateMeters);

                        if (retVal != 0)
                        {
                            if (retVal == 51030)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "51030" });
                            }
                            else if (retVal == 60000)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "60000" });
                            }
                            else if (retVal == 51060)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "51060" });
                            }
                            else if (retVal == 53)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "405" });
                            }
                            else if (retVal == 69)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "101" });
                            }
                            else if (retVal == 62)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "201" });
                            }
                            else if (retVal == 61)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "301" });
                            }
                            else if (retVal == 63)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                            }
                            else if (retVal == 64)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "302" });
                            }
                            else if (retVal == 65)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                            }
                            else if (retVal == 66)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "601" });
                            }
                            else if (retVal == 67)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "701" });
                            }
                            else if (retVal == 68)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "405" });
                            }
                            else
                            {
                                string errorMessage = "Unable to update the meter. Some error has occured. Please try again.";
                                return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorMessage });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("Api - Meter - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message });
                }
                if (errorCode != string.Empty)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode });
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, new { message = data });
                }
            }

            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "Save failed. Invalid meter details." });
        }

        /// <summary>
        ///     To update the meter details
        /// </summary>
        /// <param name="data">Meter data to update</param>
        /// <returns>Returns Success or failure response Messages</returns>
        public HttpResponseMessage Put(List<WebModel.MeterWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.MeterWebModel MeterWebModel in data)
            {
                HttpResponseMessage = this.Put(MeterWebModel.MeterId, MeterWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     To delete the Meter
        /// </summary>
        /// <param name="id">Delete Meter based on ID</param>
        /// <param name="data">Meter data to delete</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteMeter(int? id, WebModel.MeterWebModel data)
        {
            int retVal;
            if (id > 0)
            {
                try
                {
                    Meter objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data);
                    objMeter.MaxNumberOfRecords = this.meterService.GetMaxNumberOfRecords(this.EcolabAccountNumber);
                    objMeter.LastModifiedTime = DateTime.SpecifyKind(objMeter.LastModifiedTime, DateTimeKind.Utc);
                    bool isDisconnected = this.PlantService.IsPlantConnected(this.EcolabAccountNumber);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        int error;
                        retVal = this.meterService.DeletePlantMeterDetails(objMeter, this.UserId, out error, out lastModifiedTimeStamp);
                        if (error > 0)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, error);
                        }
                        if (retVal < 0 && objMeter.MeterId.Value < 0)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, id);
                        }
                    }
                    else
                    {
                        retVal = Push.PushToLocal(objMeter, EcolabAccountNumber, UserId, (int)TcdAdminMessageTypes.TcdDeleteMeters);

                        if (retVal != 0)
                        {
                            if (retVal == 51030)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            }
                            else if (retVal == 60000)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                            }
                            else if (retVal == 51060)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                            }
                            else if (retVal == 302)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "302");
                            }
                            else
                            {
                                string errorMessage = "Unable to delete the meter. Some error has occured. Please try again.";
                                return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error("Api - Meter - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the meter. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }

            return Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid meter details.");
        }

        /// <summary>
        ///     Delete the Meter data
        /// </summary>
        /// <param name="data">The Meter data</param>
        /// <returns>Returns Success or failure response Messages</returns>
        public HttpResponseMessage DeleteMeter(List<WebModel.MeterWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.MeterWebModel MeterWebModel in data)
            {
                HttpResponseMessage = this.DeleteMeter(MeterWebModel.MeterId, MeterWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Validate PLC Tags
        /// </summary>
        /// <param name="tag">Tag address</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>Status Exception Code</returns>
        private string ValidateTag(string tag, int controllerId)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag> { new OpcTag { Address = tag } } }, controllerId);
            return tagStatus.Tags.FirstOrDefault().IsValid && tagStatus.Tags[0].Quality == "Good" ? string.Empty : "801";
        }

        /// <summary>
        /// Fetches the external or internal counter
        /// </summary>
        /// <param name="locationId">The locationId</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="utilityTypeId">Utility Type Id</param>
        /// <param name="meterId">Meter Id</param>
        /// <param name="isTunnel">Is Tunnel</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>Returns Dictionary .</returns>
        [HttpGet]
        public Dictionary<string, string> FetchCounters(int? locationId, int? washerId, string utilityTypeId,int? meterId, bool isTunnel, int? controllerId)
        {
            return this.meterService.FetchCounters(locationId, washerId, utilityTypeId, meterId, isTunnel, true, this.EcolabAccountNumber, controllerId);
        }
    }
}