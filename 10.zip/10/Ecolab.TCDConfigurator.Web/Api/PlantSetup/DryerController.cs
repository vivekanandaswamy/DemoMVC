﻿// -----------------------------------------------------------------------
// <copyright file="DryerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.Dryer;
    using Models.PlantSetup.Dryer;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Dryer;
    using Utilities;

    /// <summary>
    ///     Api controller for DryerController
    /// </summary>
    public class DryerController : BaseApiController
    {
        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private readonly IDryerGroupService dryerGroupService;

        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private readonly IDryerService dryerService;

        /// <summary>
        ///     Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService"></param>
        /// <param name="dryerGroupService">dryerGroupService</param>
        /// <param name="dryerService">dryerService</param>
        public DryerController(IUserService userService, IPlantService plantService, IDryerGroupService dryerGroupService, IDryerService dryerService)
            : base(userService, plantService)
        {
            this.dryerGroupService = dryerGroupService;
            this.dryerService = dryerService;
        }

        #region DryerGroups

        /// <summary>
        ///     Method to get the Dryers along with Dryer Groups
        /// </summary>
        /// <returns>get dryer</returns>
        public List<DryerGroupModel> Get()
        {
            List<DryerGroup> dryers = this.dryerGroupService.FetchDryerGroupDetails(this.EcolabAccountNumber);
            List<DryerGroupModel> dryerGroupModel = Mapper.Map<List<DryerGroup>, List<DryerGroupModel>>(dryers);
            dryerGroupModel.ForEach(x => x.Dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, false, 0));
            var groupList = dryerGroupModel.Select(x => new { x.Id, x.Name, x.DesiredUnits, x.IsDeleted, x.LastModifiedTimestampAtCentral, x.LastModifiedTimeStampDryer, x.LastModifiedTimeStampDryerGroup }).Where(x => x.IsDeleted == false).Distinct().ToList();

            return (from @group in groupList let dryersList = dryerGroupModel.FindAll(x => x.Id == @group.Id) let drList = 
                    dryersList.Where(dr => dr.Dryer.Number > 0).Select(dr => new DryerModel
                    {
                        LastModifiedTimestampAtCentral = dr.Dryer.LastModifiedTimestampAtCentral == DateTime.MinValue ? null : dr.Dryer.LastModifiedTimestampAtCentral,
                        LastModifiedTimeStampDryer = dr.Dryer.LastModifiedTimeStampDryer,
                        LastModifiedTimeStampDryerGroup = dr.Dryer.LastModifiedTimeStampDryerGroup,
                        GroupId = @group.Id, Id = dr.Dryer.Id, Name = dr.Dryer.Name, Number = dr.Dryer.Number,
                        Nominalload = dr.Dryer.Nominalload, ConvertedNominalload = dr.Dryer.ConvertedNominalload,
                        ConvertedNominalloadAsString = dr.Dryer.ConvertedNominalload.ToString("#,0.##"),
                        DesiredUnits = dr.Dryer.DesiredUnits,
                        DryerType = new DryerTypeModel
                        {
                            Id = dr.Dryer.DryerType.Id, Name = dr.Dryer.DryerType.Name
                        }
                    }).ToList()
                    select new DryerGroupModel
                    {
                        Id = @group.Id, Name = @group.Name, DesiredUnits = @group.DesiredUnits,
                        Dryers = drList.OrderBy(_ => _.Number).ToList(),
                        LastModifiedTimeStampDryerGroup = @group.LastModifiedTimeStampDryerGroup
                    }).ToList();
                    }

        /// <summary>
        ///     Method to create a new Dryer group
        /// </summary>
        /// <param name="dryerGroup"></param>
        /// <returns>create dryer</returns>
        [HttpPost]
        public HttpResponseMessage CreateDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                dryerGroup.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(dryerGroup.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);
                DryerGroup dryerGroupData = new DryerGroup { Name = dryerGroup.Name, EcolabAccountNumber = user.EcolabAccountNumber };
                dryerGroupData.MaxNumberOfRecords = this.dryerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerGroupService.InsertDryerGroup(dryerGroupData, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddDryerGroup);
                }

                switch (result)
                {
                    case 46:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);

                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Dryer group
        /// </summary>
        /// <param name="dryerGroup">Dryer Group</param>
        /// <returns>update dryer group</returns>
        [HttpPost]
        public HttpResponseMessage UpdateDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                dryerGroup.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(dryerGroup.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);
                var dryerGroupData = new DryerGroup
                {
                    Id = dryerGroup.Id,
                    Name = dryerGroup.Name,
                    EcolabAccountNumber = user.EcolabAccountNumber,
                    LastModifiedTimeStampDryerGroup = dryerGroup.LastModifiedTimeStampDryerGroup
                };
                dryerGroupData.MaxNumberOfRecords = dryerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                dryerGroupData.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);
                dryerGroupData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                dryerGroupData.LastModifiedTimestampAtCentral = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerGroupService.UpdateDryerGroup(dryerGroupData, this.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateDryerGroup);
                }

                switch (result)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a DryerGroup
        /// </summary>
        /// <param name="dryerGroup">dryerGroup</param>
        /// <returns>delete DryerGroup</returns>
        [HttpPost]
        public HttpResponseMessage DeleteDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {

                var dryerGroupData = new DryerGroup
                {
                    Id = dryerGroup.Id,
                    Name = dryerGroup.Name,
                    LastModifiedTimeStampDryerGroup = dryerGroup.LastModifiedTimeStampDryerGroup
                };
                dryerGroupData.IsDelete = true;
                dryerGroupData.MaxNumberOfRecords = this.dryerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                dryerGroupData.EcolabAccountNumber = user.EcolabAccountNumber;
                dryerGroupData.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);
                dryerGroupData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                dryerGroupData.LastModifiedTimestampAtCentral = DateTime.SpecifyKind(dryerGroupData.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerGroupService.DeleteDryerGroup(dryerGroupData, dryerGroupData.Id, this.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteDryerGroup);
                }
                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion

        #region Dryer

        [HttpGet]
        public List<DryerTypeModel> FetchDryerTypes()
        {
            List<DryerType> dryerType = this.dryerService.FetchDryerTypes(this.EcolabAccountNumber);
            return Mapper.Map<List<DryerType>, List<DryerTypeModel>>(dryerType).ToList();
        }

        /// <summary>
        ///     Method to create a new Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>Crreate dryer</returns>
        [HttpPost]
        public HttpResponseMessage CreateDryer([FromBody] DryerModel dryer)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                int dryerGroupId = dryer.GroupId;
                dryer.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryer.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, true, 0);
                Dryer dryerData = new Dryer { Number = dryer.Number, Name = dryer.Name, Nominalload = dryer.Nominalload,ConvertedNominalload = dryer.ConvertedNominalload, DryerType = new DryerType { Id = dryer.DryerType.Id }, EcolabAccountNumber = user.EcolabAccountNumber, GroupId = dryer.GroupId };
                dryerData.MaxNumberOfRecords = this.dryerService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerService.InsertDryer(dryerData, dryerGroupId, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddDryers);
                }

                switch (result)
                {
                    case 42:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 43:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51031:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>update dryer</returns>
        [HttpPost]
        public HttpResponseMessage UpdateDryer([FromBody] DryerModel dryer)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, true, 0);
                dryer.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryer.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                var dryerData = new Dryer
                {
                    GroupId = dryer.GroupId,
                    Id = dryer.Id,
                    Number = dryer.Number,
                    Name = dryer.Name,
                    Nominalload = dryer.Nominalload,
                    ConvertedNominalload = dryer.ConvertedNominalload,
                    DryerType = new DryerType { Id = dryer.DryerType.Id },
                    EcolabAccountNumber = user.EcolabAccountNumber,
                    LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryer.LastModifiedTimeStampDryer, DateTimeKind.Utc),
                    LastModifiedTimestampAtCentral = DateTime.SpecifyKind(dryer.LastModifiedTimeStampDryer, DateTimeKind.Utc)
                };
                dryerData.MaxNumberOfRecords = dryerService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerService.UpdateDryer(dryerData, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateDryers);
                }

                switch (result)
                {
                    case 42:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 43:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51031:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51031);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>delete dryer</returns>
        [HttpPost]
        public HttpResponseMessage DeleteDryer([FromBody] DryerModel dryer)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                int result = 0;
                var dryerData = new Dryer
                {
                    Id = dryer.Id,
                    GroupId = dryer.GroupId,
                    Number = dryer.Number,
                    Name = dryer.Name,
                    Nominalload = dryer.Nominalload,
                    DesiredUnits = dryer.DesiredUnits,
                    LastModifiedTimeStampDryer = dryer.LastModifiedTimeStampDryer,
                    DryerType = new DryerType { Id = dryer.DryerType.Id }
                };
                dryerData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryerData.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                dryerData.MaxNumberOfRecords = dryerService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                dryerData.IsDelete = true;
                dryerData.EcolabAccountNumber = user.EcolabAccountNumber;
                dryerData.LastModifiedTimestampAtCentral = dryerData.LastModifiedTimeStampDryer;

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.dryerService.DeleteDryer(dryerData, dryerData.Id, this.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(dryerData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteDryers);
                }
                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion
    }
}