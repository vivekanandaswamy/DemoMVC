﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The RedFlag Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Models.PlantSetup.RedFlag;
    using Models.PlantSetup;
    using Models.PlantSetup.RedFlag;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    /// <summary>
    /// RedFlag Controller class
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Api.BaseApiController" />
    public class RedFlagController : BaseApiController
    {
        /// <summary>
        ///     RedFlag Service
        /// </summary>
        private readonly IRedFlagService redFlagService;

        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="redFlagService">The red flag service</param>
        public RedFlagController(IUserService userService, IPlantService plantService, IRedFlagService redFlagService)
            : base(userService, plantService)
        {
            this.redFlagService = redFlagService;
        }

        /// <summary>
        ///     Gets Red Flag details
        /// </summary>
        /// <returns>List of RedFlagModel</returns>
        [HttpGet]
        public List<RedFlagModel> Get()
        {
            User user = this.GetUser();
            List<RedFlag> redFlag = this.redFlagService.FetchRedFlagDetails(null, user.EcolabAccountNumber);
            List<RedFlagModel> redflagList = Mapper.Map<List<RedFlag>, List<RedFlagModel>>(redFlag);
            redflagList = redflagList.Where(item => item.IsDelete == false).ToList();
            redflagList.ForEach(_ => _.MinimumRangeAsString = _.MinimumRange.ToString("#,0.###"));
            redflagList.ForEach(_ => _.MaximumRangeAsString = _.MaximumRange.ToString("#,0.###"));
            return redflagList;
        }

        /// <summary>
        ///     Gets Items for Dropdown
        /// </summary>
        /// <returns>List of ItemModel</returns>
        [HttpGet]
        public List<ItemModel> GetItemData()
        {
            User user = this.GetUser();
            List<RedFlagItem> item = this.redFlagService.FetchRedFlagItemDetails(null, user.EcolabAccountNumber);
            return Mapper.Map<List<RedFlagItem>, List<ItemModel>>(item);
        }

        /// <summary>
        ///     Gets Items for Dropdown
        /// </summary>
        /// <returns>List of ItemModel</returns>
        [HttpGet]
        public List<RedFlagCategoryModel> GetCategoryData()
        {
            // List<Ecolab.Models.PlantSetup.RedFlag.RedFlagCategory> item = this.redFlagService.FetchRedFlagItemDetails(null, this.EcolabAccountNumber);
            List<Ecolab.Models.PlantSetup.RedFlag.RedFlagCategory> category = this.redFlagService.FetchRedFlagCategoryData();
            return Mapper.Map<List<RedFlagCategory>, List<RedFlagCategoryModel>>(category);
        }

        /// <summary>
        ///     Gets Cascading locations data on Item change
        /// </summary>
        /// <param name="id">Red Flag Id</param>
        /// <param name="itemId">Item Id</param>
        /// <returns>List of RedFlagLocationModel</returns>
        [HttpGet]
        public List<RedFlagLocationModel> GetOnItemChange(int? id, int itemId)
        {
            User user = this.GetUser();
            List<RedFlagLocation> location = this.redFlagService.FetchRedFlagLocationDetails(itemId, user.EcolabAccountNumber);
            List<RedFlagLocationModel> locationList = Mapper.Map<List<RedFlagLocation>, List<RedFlagLocationModel>>(location);
            return locationList;
        }

        /// <summary>
        ///     Gets Cascading locations data on Location change
        /// </summary>
        /// <param name="id">Red flag Id</param>
        /// <param name="itemId">Item Id</param>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of RedFlagLocationModel</returns>
        [HttpGet]
        public List<MachineSetupModel> GetOnLocationChange(int? id, int itemId, int locationId)
        {
			User user = this.GetUser();
            List<MachineSetupModel> objMachines = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.redFlagService.GetRedFlagMachineDetails(locationId, user.EcolabAccountNumber));
            return objMachines;
        }

        /// <summary>
        /// Gets RedFlagItems for dropdown based on category
        /// </summary>
        /// <param name="categoryId">The category identifier.</param>
        /// <returns>
        /// List of ItemModel
        /// </returns>
        [HttpGet]
        public List<ItemModel> GetRedFlagItemListByCategory(int categoryId)
        {
            List<RedFlagItem> RedFlagItemList = this.redFlagService.GetRedFlagItemListByCategory(categoryId,this.EcolabAccountNumber);
            return Mapper.Map<List<RedFlagItem>, List<ItemModel>>(RedFlagItemList);
        }

        /// <summary>
        ///     Gets Cascading FormulaCategory data on Location change
        /// </summary>
        /// <param name="id">Red flag Id</param>
        /// <param name="itemId">Item Id</param>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of EcolabTextileCategoryModel</returns>
        [HttpGet]
        public List<Models.PlantSetup.FormulaModel> GetFormulaCategoryOnLocationChange(int id, int itemId, int locationId)
        {
            List<Models.PlantSetup.FormulaModel> objTxt = Mapper.Map<List<Ecolab.Models.Formula>, List<Models.PlantSetup.FormulaModel>>(this.redFlagService.FetchFormulaCategorybyLocationId(locationId, this.EcolabAccountNumber));
            return objTxt;
        }
        /// <summary>
        /// Gets Cascading formula data on FormulaCategory change
        /// </summary>
        /// <param name="locationId">locationId</param>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// List of FormulaModel
        /// </returns>
        public List<FormulaModel> GetFormulaOnFormulaCategoryChange(int locationId, int id)
        {
            List<FormulaModel> objFormula = Mapper.Map<List<Formula>, List<FormulaModel>>(this.redFlagService.FetchFormulabyFormulaCategory(locationId,id, this.EcolabAccountNumber));
            return objFormula;
        }

        /// <summary>
        /// Gets Cascading formula data on FormulaCategory change
        /// </summary>
        /// <param name="locationId">locationId</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>
        /// List of FormulaModel
        /// </returns>
        public List<ProductMasterModel> GetProductsOnFormulaChange(int locationId, int? formulaId)
        {
            List<ProductMasterModel> objProducts = Mapper.Map<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>, List<ProductMasterModel>>(this.redFlagService.FetchProductsByFormulaId(locationId,formulaId, this.EcolabAccountNumber));
            return objProducts;
        }

        /// <summary>
        ///     Gets list of Meters for the location
        /// </summary>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of Meters</returns>
        [HttpGet]
        public List<MeterModel> GetMeterOnLocationChange(int locationId,int itemId)
        {
            List<MeterModel> meters = Mapper.Map<List<Meter>, List<MeterModel>>(this.redFlagService.GetRedFlagMetersByLocation(locationId,  this.EcolabAccountNumber, itemId));
            return meters;
        }

        /// <summary>
        ///     Gets list of Sensors for the location
        /// </summary>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of Sensors</returns>
        [HttpGet]
        public List<Sensor> GetSensorOnLocationChange(int locationId)
        {
            List<Sensor> sensors = this.redFlagService.GetRedFlagSensorsByLocation(locationId, this.EcolabAccountNumber);
            return sensors;
        }
        /// <summary>
        ///     Gets RedFlag Data on Edit Clicked
        /// </summary>
        /// <param name="id">Red Flag Id</param>
        /// <returns>Dictionary of selected Category,RedFlagModel, ItemModel, RedFlagLocationModel</returns>
        [HttpGet]
        public Dictionary<string, object> GetOnEditClicked(int id)
        {
            User user = this.GetUser();
            RedFlagModel redFlag = Mapper.Map<RedFlag, RedFlagModel>(this.redFlagService.FetchRedFlagDetails(id, user.EcolabAccountNumber).FirstOrDefault());

            List<ItemModel> itemList = Mapper.Map<List<RedFlagItem>, List<ItemModel>>(this.redFlagService.FetchRedFlagItemDetails(null, user.EcolabAccountNumber));
            List<RedFlagLocation> location = this.redFlagService.FetchRedFlagLocationDetails(redFlag.ItemId, this.EcolabAccountNumber);
            List<RedFlagLocationModel> locationList = Mapper.Map<List<RedFlagLocation>, List<RedFlagLocationModel>>(location);

            List<MachineSetupModel> objMachines = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.redFlagService.GetRedFlagMachineDetails(redFlag.LocationId, user.EcolabAccountNumber));
            List<RedFlagCategory> category = this.redFlagService.FetchRedFlagCategoryData();
            List<MeterModel> objMeters = Mapper.Map<List<Meter>, List<MeterModel>>(this.redFlagService.GetRedFlagMetersByLocation(redFlag.LocationId, this.EcolabAccountNumber, redFlag.ItemId));
            List<Models.PlantSetup.FormulaModel> textileCategory = Mapper.Map<List<Formula>, List<Models.PlantSetup.FormulaModel>>(this.redFlagService.FetchFormulaCategorybyLocationId(redFlag.LocationId, this.EcolabAccountNumber));
            List<FormulaModel> formula = Mapper.Map<List<Formula>, List<FormulaModel>>(this.redFlagService.FetchFormulabyFormulaCategory(redFlag.LocationId, id, this.EcolabAccountNumber));
            List<ProductMasterModel> products = Mapper.Map<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>, List<ProductMasterModel>>(this.redFlagService.FetchProductsByFormulaId(redFlag.LocationId,redFlag.FormulaId, this.EcolabAccountNumber));
            List<MeterModel> meters = Mapper.Map<List<Meter>, List<MeterModel>>(this.redFlagService.GetRedFlagMetersByLocation(redFlag.LocationId, this.EcolabAccountNumber, redFlag.ItemId));
            List<Sensor> sensors = this.redFlagService.GetRedFlagSensorsByLocation(redFlag.LocationId, this.EcolabAccountNumber);
            var selectedFormula = textileCategory.Where(a => a.ProgramId == redFlag.FormulaId).DefaultIfEmpty(new FormulaModel() { EcolabTextileId = 0, ChainTextileId = 0 }).FirstOrDefault();
            redFlag.FormulaCategoryId = selectedFormula.EcolabTextileId != 0 ? selectedFormula.EcolabTextileId : selectedFormula.ChainTextileId;
            return new Dictionary<string, object> { { "Category", category }, { "RedFlag", redFlag }, { "Item", itemList }, { "Location", locationList }, { "Machines", objMachines }, { "FormulaCategory", textileCategory }, { "Formula", formula }, { "Product", products }, { "Meter", meters } , { "Sensor", sensors} };
        }

        /// <summary>
        ///     Creates new Red Flag
        /// </summary>
        /// <param name="data">Data to create Red Flag</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPost]
        public HttpResponseMessage Create([FromBody] List< RedFlagModel> data)
        {
            int id = 0;
            try
            {
                User user = this.GetUser();
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                int status = 0;
                data[0].LastModifiedTimeStamp = DateTime.SpecifyKind(data[0].LastModifiedTimeStamp, DateTimeKind.Utc);

                //for Plant Level and Group Level machineIds will be null
                data[0].MachineIds = data[0].MachineIds ?? "-1";
                data[0].EcolabAccountNumber = user.EcolabAccountNumber;
                data[0].MaxNumberOfRecords = this.redFlagService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                List<RedFlagModel> redFlagFiltered = this.RedFlagFilteredData(data[0]);

                List<RedFlag> objRedFlag = Mapper.Map<List<RedFlagModel>, List<RedFlag>>(redFlagFiltered);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                     status = this.redFlagService.InsertRedFlag(objRedFlag, this.UserId, out lastModifiedTimeStamp);
                    id = status;
                    objRedFlag.ForEach(r => r.Id = status);
                }
                else
                {
                    foreach (RedFlag itemRedFlag in objRedFlag)
                    {
                        
                        status = Push.PushToLocal(itemRedFlag, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddRedFlag, out id);
                        data[0].Id = id;
                    }
                }
                switch (status)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 401:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "401");
                    case 48:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "401");
					case 301:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "301");
					case 50:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "301");
                }

                return (id > 0) ? this.Request.CreateResponse(HttpStatusCode.OK, data) : this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     To update the Red Flag details
        /// </summary>
        /// <param name="id">RedFlag Id</param>
        /// <param name="data">Data to update Red Flag</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, RedFlagModel data)
        {
            try
            {
                User user = this.GetUser();
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                int redFlagId = 0;
                int status = 0;

                //for Plant Level machineIds will be null
                data.MachineIds = String.IsNullOrEmpty(data.MachineIds) ? "-1" : data.MachineIds;
                data.EcolabAccountNumber = user.EcolabAccountNumber;
                data.MaxNumberOfRecords = this.redFlagService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);

                RedFlagModel redFlag = Mapper.Map<RedFlag, RedFlagModel>(this.redFlagService.FetchRedFlagDetails(id, this.EcolabAccountNumber).FirstOrDefault());
                var redFlagFiltered = new List<RedFlagModel>();
                var oldMachines = new List<int>();
                List<int> newMachines = new List<int>();

                if (redFlag.MachineIds != null)
                {
                    oldMachines = redFlag.MachineIds.Split(',').Select(int.Parse).ToList();
                }

                if (data.MachineIds != null)
                {
                    newMachines = data.MachineIds.Split(',').Select(int.Parse).ToList();
                }
                
                data.MachineID = newMachines.FirstOrDefault();
                if (redFlag.ItemId == data.ItemId && redFlag.LocationId == data.LocationId)
                {
                    var diff = oldMachines.Except(newMachines).Union(newMachines.Except(oldMachines)).Select(item => new { MachineID = item, IsSelected = newMachines.Contains(item) }).ToList();
                    if (diff.Any())
                    {
                        if (diff.FirstOrDefault().MachineID == -1)
                        {
                            diff.Remove(diff.FirstOrDefault());
                        }

                        redFlagFiltered = (from d in diff select new RedFlagModel
                            {
                                Id = data.Id, ItemId = data.ItemId, UOM = data.UOM, MinimumRange = data.MinimumRange, MaximumRange = data.MaximumRange,
                                LocationId = data.LocationId, EcolabAccountNumber = this.EcolabAccountNumber, IsSelected = d.IsSelected,
                                MachineID = (d.MachineID == -1) ? (int?)null : d.MachineID,
                                FormulaId = (data.FormulaId == -1) ? (int?)null : data.FormulaId,
                                ProductId = data.ProductId == -1 ? (int?)null : data.ProductId,
                                MeterId = data.MeterId == -1 ? (int?)null : data.MeterId,
                                SensorId = data.SensorId == -1 ? (int?)null : data.SensorId,
                                CategoryId = data.CategoryId
                        }).ToList();
                    }
                    else
                    {
                        data.FormulaId = (data.FormulaId == -1) ? (int?)null : data.FormulaId;
                        data.ProductId = data.ProductId == -1 ? (int?)null : data.ProductId;
                        data.MeterId = data.MeterId == -1 ? (int?)null : data.MeterId;
                        data.SensorId = data.SensorId == -1 ? (int?)null : data.SensorId;
                        redFlagFiltered.Add(data);
                        data.IsDirty = true;
                    }
                }
                else
                {
                    redFlagFiltered = this.RedFlagFilteredData(data);
                }

                List<RedFlag> objRedFlag = Mapper.Map<List<RedFlagModel>, List<RedFlag>>(redFlagFiltered);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    status = this.redFlagService.UpdateRedFlag(objRedFlag, user.UserId, out lastModifiedTimeStamp);
                    objRedFlag.ForEach(r => r.Id = redFlagId);
                }
                else
                {
                    foreach (RedFlag itemRedFlag in objRedFlag)
                    {
                        status = Push.PushToLocal(itemRedFlag, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateRedFlag);
                        data.Id = status;
                    }
                }
                switch (status)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
					case 401:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "401");
					case 48:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "401");
					case 301:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "301");
					case 50:
						return Request.CreateResponse(HttpStatusCode.BadRequest, "301");
                }

                return (status == 0 || status == 201) ? this.Request.CreateResponse(HttpStatusCode.OK, data) : this.Request.CreateResponse(HttpStatusCode.BadRequest, redFlagId);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     To update the Red Flag details
        /// </summary>
        /// <param name="data">Data to update Red Flag</param>
        /// <returns>Returns Success or failure response Messages</returns>
        public HttpResponseMessage Put(List< RedFlagModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (RedFlagModel RedFlagModel in data)
            {
                HttpResponseMessage = this.Put(RedFlagModel.Id, RedFlagModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Delete the RedFlag data
        /// </summary>
        /// <param name="data">Delete the Meter data</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpDelete]
        public HttpResponseMessage Delete(List< RedFlagModel> data)
        {
            try
            {
                User user = this.GetUser();
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                int result = 0;

                data[0].IsDelete = true;
                data[0].MaxNumberOfRecords = this.redFlagService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                data[0].EcolabAccountNumber = user.EcolabAccountNumber;
                data[0].LastModifiedTimeStamp = DateTime.SpecifyKind(data[0].LastModifiedTimeStamp, DateTimeKind.Utc);

                RedFlag objRedFlag = Mapper.Map<RedFlagModel, RedFlag>(data[0]);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.redFlagService.DeleteRedFlag(objRedFlag, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(objRedFlag, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteRedFlag);
                    }
                    switch (result)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    }
                    return this.Request.CreateResponse(HttpStatusCode.OK, data);
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid User");
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Gets list of redFlag with machines when new location is selected
        /// </summary>
        /// <param name="redFlag">redFlag Modal data</param>
        /// <returns>List of RedFlagModel</returns>
        public List<RedFlagModel> RedFlagFilteredData(RedFlagModel redFlag)
        {
            List<int> newMachines = redFlag.MachineIds.Split(',').Select(int.Parse).ToList();
            return (from machineId in newMachines
                    select new RedFlagModel
                    {
                        Id = redFlag.Id,
                        ItemId = redFlag.ItemId,
                        UOM = redFlag.UOM,
                        MinimumRange = redFlag.MinimumRange,
                        MaximumRange = redFlag.MaximumRange,
                        LocationId = redFlag.LocationId,
                        EcolabAccountNumber = EcolabAccountNumber,
                        IsSelected = true,
                        MachineID = machineId == -1 ? (int?)null : machineId,
                        MaxNumberOfRecords = redFlag.MaxNumberOfRecords,
                        LastModifiedTimeStamp = redFlag.LastModifiedTimeStamp,
                        CategoryId = redFlag.CategoryId,
                        FormulaCategoryId = redFlag.FormulaCategoryId,
                        FormulaId = redFlag.FormulaId == -1 ? null : redFlag.FormulaId,
                        ProductId = redFlag.ProductId == -1 ? null : redFlag.ProductId,
                        MeterId = redFlag.MeterId == -1 ? null : redFlag.MeterId,
                        SensorId = redFlag.SensorId == -1 ? null : redFlag.SensorId
                    }).ToList();
        }
    }
}