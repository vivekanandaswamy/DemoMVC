﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shift Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.Common;
    using Elmah;
    using Models;
    using Models.PlantSetup;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Utilities;
    using Model = Ecolab.Models.PlantSetup.ShiftLabor;

    /// <summary>
    ///     Api controller for ShiftLaborController
    /// </summary>
    public class ShiftLaborController : BaseApiController
    {
        /// <summary>
        ///     ShiftBreak Service
        /// </summary>
        private readonly ILaborService laborService;

        /// <summary>
        ///     ShiftBreak Service
        /// </summary>
        private readonly IShiftBreakService shiftBreakService;

        public ShiftLaborController(IUserService userService, IShiftBreakService shiftBreakService, ILaborService laborService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.shiftBreakService = shiftBreakService;
            this.laborService = laborService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Method to get shifts data based on shift id and day id.
        /// </summary>
        /// <param name="dayId">day is value</param>
        /// <param name="shiftId">shift id value</param>
        /// <returns>Dictionary of day as key and shifts as value</returns>
        public Dictionary<string, List<ShiftModel>> GetShiftData(int? dayId, int? shiftId)
        {
            var dicShift = new Dictionary<string, List<ShiftModel>>();
            string[] days = { "Samle", "SunDay", "MonDay", "TuesDay", "Wednesday", "Thursday", "FriDay", "Saturday" };
            List<Model.Shift> shifts = this.shiftBreakService.FetchShiftDetails(shiftId, dayId, this.EcolabAccountNumber);
            List<Model.ShiftLabor> shiftsLabors = this.laborService.FetchShiftLaborDetails(this.EcolabAccountNumber);
            var shiftModel = new List<ShiftModel>();
            shiftModel = Mapper.Map<List<Model.Shift>, List<ShiftModel>>(shifts);
            var shiftBreak = shiftModel.AsEnumerable().Select(x => x).GroupBy(s => new { s.DayId, s.ShiftId }).ToDictionary(a => a.Key, a => a.ToList());
            var shiftDays = new List<ShiftModel>();

            foreach (var item in shiftBreak)
            {
                ShiftModel shiftDay = new ShiftModel();
                for (int i = 0; i < item.Value.Count(); i++)
                {
                    if (item.Key.ShiftId == item.Value[i].ShiftId && item.Key.DayId == item.Value[i].DayId)
                    {
                        shiftDay.Id = item.Value[i].Id;
                        shiftDay.DayId = item.Value[i].DayId;
                        shiftDay.ShiftId = item.Value[i].ShiftId;
                        shiftDay.ShiftName = item.Value[i].ShiftName;
                        shiftDay.DayName = item.Value[i].DayName;
                        shiftDay.TargetProduction = item.Value[i].TargetProduction;
                        shiftDay.TargetProductionAsString = shiftDay.TargetProduction.ToString("#,0.##");
                        shiftDay.TargetProductionDisplay = shiftDay.TargetProduction;
                        shiftDay.DesiredUnits = this.shiftBreakService.FetchUnits(this.EcolabAccountNumber);
                        shiftDay.StartTime = shiftDay.StartTime = DateTime.ParseExact(item.Value[i].StartTime, "HH:mm:ss", null).ToString("HH:mm");
                        shiftDay.EndTime = DateTime.ParseExact(item.Value[i].EndTime, "HH:mm:ss", null).ToString("HH:mm");
                        if ((item.Value[i].ShiftBreak.StartTime != "00:00:00") || (item.Value[i].ShiftBreak.EndTime != "00:00:00"))
                        {
                            shiftDay.ShiftBreaks.Add(new ShiftBreakModel
                            {
                                BreakId = item.Value[i].ShiftBreak.BreakId,
                                DayId = item.Value[i].ShiftBreak.DayId,
                                ShiftId = item.Value[i].ShiftBreak.ShiftId,
                                StartTime = DateTime.ParseExact(item.Value[i].ShiftBreak.StartTime, "HH:mm:ss", null).ToString("HH:mm"),
                                EndTime = DateTime.ParseExact(item.Value[i].ShiftBreak.EndTime, "HH:mm:ss", null).ToString("HH:mm")
                            });
                        }
                    }
                }

                shiftDays.Add(shiftDay);
                string day = Days.Sunday.ToString();
                List<ShiftModel> lstShiftModel = shiftDays.Where(x => x.DayId == item.Key.DayId && x.ShiftId == item.Key.ShiftId).ToList();
                lstShiftModel.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, false, 0);
                if (!dicShift.ContainsKey(days[item.Key.DayId]))
                {
                    dicShift.Add(days[item.Key.DayId], lstShiftModel);
                }
                else
                {
                    dicShift[days[item.Key.DayId]].AddRange(lstShiftModel);
                }
            }

            if (shiftId == null && dayId == null)
            {
                List<ShiftLaborModel> laborList = Mapper.Map<List<Model.ShiftLabor>, List<ShiftLaborModel>>(shiftsLabors);
                var shiftLaborModel = new List<ShiftLaborModel>();
                laborList.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, false, 0, ExchangeRate, GetPlantDetails().CurrencyCode);
                foreach (ShiftLaborModel labor in laborList)
                {
                    labor.PricePerHrAsString = labor.PricePerHr.ToString("#,0.##");
                    labor.LaborTypes = this.FetchLaborType();
                    labor.Locations = this.FetchLaborLocation();
                    labor.LaborHoursAsString = labor.LaborHours.ToString("#,0.##");
                    if (dicShift.ContainsKey(days[labor.DayId]))
                    {
                        dicShift[days[labor.DayId]].AsEnumerable().Where(x => x.ShiftId == labor.ShiftId).First().ShiftLabors.Add(labor);
                    }
                }
                return dicShift;
            }
            return this.FetchShiftsWithWeekDays(dicShift, dayId);
        }

        /// <summary>
        ///     Method to construct shift to display while editing.
        /// </summary>
        /// <param name="dicShift"></param>
        /// <param name="dayId"></param>
        /// <returns>Dictionary with days information</returns>
        private Dictionary<string, List<ShiftModel>> FetchShiftsWithWeekDays(Dictionary<string, List<ShiftModel>> dicShift, int? dayId)
        {
            var dicShiftEdit = new Dictionary<string, List<ShiftModel>>();
            var tempList = new List<ShiftModel>();
            string weekDay = string.Empty;
            foreach (KeyValuePair<string, List<ShiftModel>> item in dicShift)
            {
                switch (item.Key.ToLower())
                {
                    case "monday":
                        weekDay += "monday_";
                        break;
                    case "tuesday":
                        weekDay += "tuesday_";
                        break;
                    case "wednesday":
                        weekDay += "wednesday_";
                        break;
                    case "thursday":
                        weekDay += "thursday_";
                        break;
                    case "friday":
                        weekDay += "friday_";
                        break;
                    case "saturday":
                        weekDay += "saturday_";
                        break;
                    case "sunday":
                        weekDay += "sunday_";
                        break;
                }
                if (item.Value.AsEnumerable().Any(x => x.DayId == dayId))
                {
                    tempList.AddRange(item.Value);
                }
            }
            string[] day = weekDay.TrimEnd('_').Split('_');
            foreach (string dayItem in day)
            {
                switch (dayItem.ToLower())
                {
                    case "monday":
                        tempList[0].IsMonday = true;
                        break;
                    case "tuesday":
                        tempList[0].IsTuesday = true;
                        break;
                    case "wednesday":
                        tempList[0].IsWednesday = true;
                        break;
                    case "thursday":
                        tempList[0].IsThursday = true;
                        break;
                    case "friday":
                        tempList[0].IsFriday = true;
                        break;
                    case "saturday":
                        tempList[0].IsSaturday = true;
                        break;
                    case "sunday":
                        tempList[0].IsSunday = true;
                        break;
                }
            }
            //tempList.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
            dicShiftEdit.Add("day", tempList);
            return dicShiftEdit;
        }

        /// <summary>
        ///     Method to Get all shifts data on page load
        /// </summary>
        /// <returns>All shifts with day as key </returns>
        public Dictionary<string, List<ShiftModel>> Get()
        {
            return this.GetShiftData(null, null);
        }

        /// <summary>
        ///     Method to update shift
        /// </summary>
        /// <param name="shift"></param>
        /// <returns>Message returned from service</returns>
        public string UpdateShift(ShiftModel shift)
        {
            User user = this.GetUser();
            
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            shift.LastModifiedTimeStamp = DateTime.SpecifyKind(shift.LastModifiedTimeStamp, DateTimeKind.Utc);
            shift.MaxNumberOfRecords = this.shiftBreakService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            shift.EcolabAccountNumber = user.EcolabAccountNumber;
            string result = string.Empty;
	        int status = 0;
            string getMessage = string.Empty;
            shift.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, true, 0);
            List<Model.Shift> lstShift = new List<Model.Shift>();
            lstShift.AddRange(this.ConstructShift(shift, shift.DayId));
            if (user != null)
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.shiftBreakService.UpdateShiftAndBreak(lstShift, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    result = this.shiftBreakService.ValidateUpdateShiftOverlapp(lstShift, user.UserId);
                    if (result.Contains("Success"))
                    {
                        result = string.Empty;
                        if (lstShift.Count > 0)
                        {
                            shiftContainer.Shift = new List<Model.Shift>();
                            shiftContainer.Shift = lstShift;
                            status = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateShift);
                        }
	                    if (status == 51030)
	                    {
		                    return status.ToString();
	                    }
						else if (status == 60000)
						{
							return status.ToString();
						}
                        else if (status == 51060)
                        {
                            return status.ToString();
                        }
                        else if (status == 39)
						{
							return status.ToString();
						}
                    }
                }
                if (!getMessage.Contains(result))
                {
                    getMessage = result + "_" + getMessage;
                }
            }
            return getMessage;
        }

        /// <summary>
        ///     Method to return EcoLabAccountNumber
        /// </summary>
        /// <returns></returns>
        public string GetEcoLabAccountNumber()
        {
            PlantModel plantDetails = this.GetPlantDetails();
            return plantDetails.EcoalabAccountNumber;
        }

        /// <summary>
        ///     Method to construct shift type with day id's for creating shifts
        /// </summary>
        /// <param name="shift"></param>
        /// <param name="dayId"></param>
        /// <returns>List of shifts</returns>
        private List<Model.Shift> ConstructShift(ShiftModel shift, int dayId)
        {
            var lstShift = new List<Model.Shift>();
            bool breakDeleted = false;

            foreach (ShiftBreakModel item in shift.ShiftBreaks)
            {
                if (shift.ShiftId == 0)
                {
                    breakDeleted = item.IsDeleted;
                }
                if (!breakDeleted)
                {
                    Model.Shift objShift = new Model.Shift
                    {
                        DayId = dayId,
                        DayName = shift.DayName,
                        StartTime = new TimeSpan(Convert.ToInt32(shift.StartTime.Split(':')[0]), Convert.ToInt32(shift.StartTime.Split(':')[1]), 0),
                        EndTime = new TimeSpan(Convert.ToInt32(shift.EndTime.Split(':')[0]), Convert.ToInt32(shift.EndTime.Split(':')[1]), 0),
                        Id = Convert.ToInt16(shift.Id),
                        ShiftId = shift.ShiftId,
                        ShiftName = shift.ShiftName,
                        EcolabAccountNumber = this.EcolabAccountNumber,
                        TargetProduction = shift.TargetProduction,
                        IsFriday = shift.IsFriday,
                        IsSaturday = shift.IsSaturday,
                        IsSunday = shift.IsSunday,
                        IsMonday = shift.IsMonday,
                        IsTuesday = shift.IsTuesday,
                        IsWednesday = shift.IsWednesday,
                        IsThursday = shift.IsThursday,
                        DesiredUnits = shift.DesiredUnits,
                        MaxNumberOfRecords = shift.MaxNumberOfRecords,
                        ShiftBreak = new Model.ShiftBreak
                        {
                            IsDeleted = item.IsDeleted,
                            BreakId = item.BreakId,
                            ShiftId = shift.ShiftId,
                            DayId = dayId,
                            StartTime = new TimeSpan(Convert.ToInt32(item.StartTime.Split(':')[0]), Convert.ToInt32(item.StartTime.Split(':')[1]), 0),
                            EndTime = new TimeSpan(Convert.ToInt32(item.EndTime.Split(':')[0]), Convert.ToInt32(item.EndTime.Split(':')[1]), 0),
                            EcolabAccountNumber = this.EcolabAccountNumber
                        }
                    };
                    lstShift.Add(objShift);
                }
                else
                {
                    lstShift.Add(this.ConstructShiftWithoutBreaks(shift, dayId));
                }
            }

            if (shift.ShiftBreaks.Count == 0)
            {
                lstShift.Add(this.ConstructShiftWithoutBreaks(shift, dayId));
            }

            return lstShift;
        }

        /// <summary>
        ///     Method to construct shift object
        /// </summary>
        /// <param name="shift"></param>
        /// <param name="dayId"></param>
        /// <returns>shift object</returns>
        private Model.Shift ConstructShiftWithoutBreaks(ShiftModel shift, int dayId)
        {
            Model.Shift objShift = new Model.Shift
            {
                DayId = dayId,
                DayName = shift.DayName,
                TargetProduction = shift.TargetProduction,
                StartTime = new TimeSpan(Convert.ToInt32(shift.StartTime.Split(':')[0]), Convert.ToInt32(shift.StartTime.Split(':')[1]), 0),
                EndTime = new TimeSpan(Convert.ToInt32(shift.EndTime.Split(':')[0]), Convert.ToInt32(shift.EndTime.Split(':')[1]), 0),
                Id = Convert.ToInt16(shift.Id),
                ShiftId = shift.ShiftId,
                ShiftName = shift.ShiftName,
                IsFriday = shift.IsFriday,
                IsSaturday = shift.IsSaturday,
                IsSunday = shift.IsSunday,
                IsMonday = shift.IsMonday,
                IsTuesday = shift.IsTuesday,
                IsWednesday = shift.IsWednesday,
                IsThursday = shift.IsThursday,
                EcolabAccountNumber = this.EcolabAccountNumber,
                MaxNumberOfRecords = shift.MaxNumberOfRecords,
                ShiftBreak = new Model.ShiftBreak()
            };
            return objShift;
        }

        /// <summary>
        ///     Method to create shift
        /// </summary>
        /// <param name="shift"></param>
        /// <returns>success/ error message</returns>
        [HttpPost]
        public HttpResponseMessage CreateShift([FromBody] ShiftModel shift)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            string result = string.Empty;
            string editResult = string.Empty;
            List<Model.Shift> lstShift = new List<Model.Shift>();
            shift.MaxNumberOfRecords = this.shiftBreakService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            shift.EcolabAccountNumber = user.EcolabAccountNumber;
            if (shift.IsSunday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 1));
            }
            if (shift.IsMonday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 2));
            }
            if (shift.IsTuesday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 3));
            }
            if (shift.IsWednesday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 4));
            }
            if (shift.IsThursday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 5));
            }
            if (shift.IsFriday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 6));
            }
            if (shift.IsSaturday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 7));
            }
            //If shift id > 0, it is edit.
            if (shift.ShiftId > 0)
            {
                editResult = this.UpdateShift(shift);
                string s = editResult;
                string[] values = s.Split('_');
                string resultMess = "201";
                if (!values.Any(resultMess.Contains))
                {
	                if (values.Any("51030".Contains))
	                {
						return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51030);
	                }
					else if (values.Any("60000".Contains))
					{
						return this.Request.CreateResponse(HttpStatusCode.Forbidden, 60000);
					}
                    else if (values.Any("51060".Contains))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51060);
                    }
                    else
					{
						return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Shift updation");
					}

                }
                return this.Request.CreateResponse(HttpStatusCode.OK, editResult.TrimEnd('#'));
            }

            string dbresult = string.Empty;
            int status = 0;
            if (user != null)
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    dbresult = this.shiftBreakService.InsertShiftAndBreak(lstShift, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    dbresult = this.shiftBreakService.ValidateShiftOverlapp(lstShift, user.UserId);
                    if (dbresult.Contains('#'))
                    {
						
						lstShift.Clear();
                    }
					if (lstShift.Count > 0)
					{
						shiftContainer.Shift = new List<Model.Shift>();
						shiftContainer.Shift = lstShift;
						status = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId,
							 (int)TcdAdminMessageTypes.TcdAddShift);
					}
                    switch (status)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51030);
                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.Forbidden, 60000);
                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51060);
                        case 39:
							return this.Request.CreateResponse(HttpStatusCode.Forbidden);
                    }
                }
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, dbresult.TrimEnd('#'));
        }

        /// <summary>
        ///     Method to delete shift
        /// </summary>
        /// <param name="id"></param>
        /// <param name="shiftId"></param>
        [HttpGet]
        public HttpResponseMessage DeleteShift(int id, int shiftId)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;

            int maxNumberOfRecords = this.shiftBreakService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            DateTime lastModifiedTimeStamp;

            if (user != null)
            {

                Model.Shift objshift = new Model.Shift { DayId = id, ShiftId = Convert.ToInt16(shiftId), EcolabAccountNumber = this.EcolabAccountNumber, MaxNumberOfRecords = maxNumberOfRecords };
                objshift.IsDelete = true;
                if (isDisconnected)
                {
                    this.shiftBreakService.DeleteShiftAndBreak(objshift, user.UserId, out lastModifiedTimeStamp);
                    objshift.LastModifiedTimeStamp = lastModifiedTimeStamp;
                }
                else
                {
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    shiftContainer.Shift = new List<Model.Shift>();
                    shiftContainer.Shift.Add(objshift);
                    result = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteShift);
                }
	            switch (result)
	            {
		            case 51030:
			            return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51060);
                    case 60000:
			            return this.Request.CreateResponse(HttpStatusCode.Forbidden, 60000);
		            case 39:
			            return this.Request.CreateResponse(HttpStatusCode.Forbidden);
	            }
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Method to delete break
        /// </summary>
        /// <param name="id"></param>
        /// <param name="dayId"></param>
        /// <param name="breakId"></param>
        [HttpGet]
        public HttpResponseMessage DeleteBreak(int id, int dayId, int breakId)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;

            int maxNumberOfRecords = this.shiftBreakService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            DateTime lastModifiedTimeStamp;
            if (user != null)
            {
                Model.Shift objshift = new Model.Shift { DayId = dayId, ShiftId = Convert.ToInt16(id), ShiftBreak = new Model.ShiftBreak { BreakId = breakId }, EcolabAccountNumber = this.EcolabAccountNumber, MaxNumberOfRecords = maxNumberOfRecords };
                objshift.IsDelete = true;
                if (isDisconnected)
                {
                    this.shiftBreakService.DeleteBreak(objshift, user.UserId, out lastModifiedTimeStamp);
                    objshift.LastModifiedTimeStamp = lastModifiedTimeStamp;
                }
                else
                {
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    shiftContainer.Shift = new List<Model.Shift>();
                    shiftContainer.Shift.Add(objshift);
                    result = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteBreak);
                }
                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51060);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
					case 39:
						return this.Request.CreateResponse(HttpStatusCode.BadRequest);
                }

            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Method to get shifts data based on day id and shift id to edit
        /// </summary>
        /// <param name="id"></param>
        /// <param name="shiftId"></param>
        /// <returns>Dictionary of day as key and shift as value for editing</returns>
        [HttpGet]
        public Dictionary<string, List<ShiftModel>> GetShiftToEdit(int id, int shiftId)
        {
            return this.GetShiftData(id, shiftId);
        }

        /// <summary>
        ///     Fetches Labor Cost basing on Labor Type
        /// </summary>
        /// <param name="id">Labor Type Id</param>
        /// <returns>Labor Cost</returns>
        [HttpGet]
        public decimal FetchLaborCost(int id)
        {
            Model.LaborTypeCost cost = this.laborService.FetchCostByLabourType(id, this.EcolabAccountNumber);
            LaborTypeCostModel laborCost = Mapper.Map<Model.LaborTypeCost, LaborTypeCostModel>(cost);
            laborCost.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, false, 0, ExchangeRate, GetPlantDetails().CurrencyCode);
            return laborCost.Cost;
        }

        #region Labor

        /// <summary>
        ///     Method to get Labor Type and Labor Locations
        /// </summary>
        /// <returns>ShiftLaborModel </returns>
        [HttpGet]
        public ShiftLaborModel GetLaborTypeAndLocation()
        {
            ShiftLaborModel shiftLaborModel = new ShiftLaborModel();
            shiftLaborModel.Locations = this.FetchLaborLocation();
            shiftLaborModel.LaborTypes = this.FetchLaborType();
            return shiftLaborModel;
        }

        /// <summary>
        ///     Method to get Labor Types for dropdowns
        /// </summary>
        /// <returns>List of LaborTypeModel</returns>
        public List<LaborTypeModel> FetchLaborType()
        {
            List<LaborType> laborType = this.laborService.FetchLabourType();
            List<LaborTypeModel> laborTypeList = Mapper.Map<List<LaborType>, List<LaborTypeModel>>(laborType);
            return laborTypeList;
        }

        /// <summary>
        ///     Method to return Labor Locations for dropdowns
        /// </summary>
        /// <returns>List of GroupTypeModel</returns>
        public List<GroupTypeModel> FetchLaborLocation()
        {
            User user = this.GetUser();
            List<GroupType> laborLocation = this.laborService.GetGroupTypeDetails(user.EcolabAccountNumber);
            List<GroupTypeModel> laborLocationList = Mapper.Map<List<GroupType>, List<GroupTypeModel>>(laborLocation);
            return laborLocationList;
        }

        /// <summary>
        ///     Method to create Labor
        /// </summary>
        /// <param name="labor">labor object.</param>
        /// <returns>success/ error message</returns>
        [HttpPost]
        public HttpResponseMessage CreateLabor([FromBody] ShiftLaborModel labor)
        {
            User user = this.GetUser();
            int result = 0;
            int id = 0;
            string editResult = string.Empty;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                labor.MaxNumberOfRecords = this.laborService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                labor.EcolabAccountNumber = user.EcolabAccountNumber;
                Model.ShiftLabor objLabor = Mapper.Map<ShiftLaborModel, Model.ShiftLabor>(labor);
                objLabor.EcolabAccountNumber = this.GetEcoLabAccountNumber();
                //If shift id > 0, it is edit.
                if (labor.LaborId > 0)
                {
                    editResult = this.Updatelabor(objLabor);
                    if (editResult == "201")
                    {
                        return this.Request.CreateResponse(HttpStatusCode.OK, editResult);
                    }
					else if (editResult == "51030")
					{
						return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
					}
					else if (editResult == "60000")
					{
						return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
					}
                    else if (editResult == "51060")
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                    else if (editResult == "39")
					{
						return this.Request.CreateResponse(HttpStatusCode.BadRequest);
					}
                    return this.Request.CreateResponse(HttpStatusCode.Forbidden, editResult);
                }
                if (isDisconnected)
                {
                    if (user != null)
                    {
                        int userId = user.UserId;
                        int count = 0;
                        DateTime lastModifiedTimeStamp;
                        result = this.laborService.InsertShiftLabor(objLabor, userId, out lastModifiedTimeStamp);
                        if (result != 0)
                        {
                            if (result == 301)
                            {
                                return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Labor Creation");
                            }
                        }
                        count++;
                    }
                }
                else
                {
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    shiftContainer.ShiftLabor = new List<Model.ShiftLabor>();
                    shiftContainer.ShiftLabor.Add(objLabor);
	                shiftContainer.IsLabor = true;
                    result = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddShiftLabor, out id);
                   if (id == 101)
                   {
                       result = id;
                   }
				   if (result != 0)
				   {
					   if (result == 301 || result == 39)
					   {
						   return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Labor Creation");
					   }
					   else if (result == 51030)
					   {
                           return this.Request.CreateResponse(HttpStatusCode.Forbidden, 51030);
					   }
					   else if (result == 60000)
					   {
						   return this.Request.CreateResponse(HttpStatusCode.Forbidden, 60000);
					   }
				   }
                   
                }
            }
            catch (Exception)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Shift Labor adding failed.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Method to update Labor
        /// </summary>
        /// <param name="labor"></param>
        /// <returns>result</returns>
        public string Updatelabor(Model.ShiftLabor labor)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            //IPrincipal user = HttpContext.Current.User;
            try
            {
                labor.MaxNumberOfRecords = this.laborService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                labor.EcolabAccountNumber = user.EcolabAccountNumber;
                if (isDisconnected)
                {
                    if (user != null)
                    {
                        int userId = user.UserId;
                        DateTime lastModifiedTimeStamp;
                        result = this.laborService.UpdateShiftLabor(labor, userId, out lastModifiedTimeStamp);
                    }
                }
                else
                {
	                int id;
                    Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                    shiftContainer.ShiftLabor = new List<Model.ShiftLabor>();
                    shiftContainer.ShiftLabor.Add(labor);
	                shiftContainer.IsLabor = true;
					result = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateShiftLabor, out id);
	                if (id == 201)
					{
						result = id;
	                }
                }
            }
            catch (Exception)
            {
                return "Shift Labor adding failed.";
                //return Request.CreateResponse(HttpStatusCode.BadRequest, "Shift Labor adding failed.");
            }
            return Convert.ToString(result);
        }

        [HttpGet]
        public HttpResponseMessage DeleteLabor(int id)
        {
            User user = this.GetUser();
            int isDeleted = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			int result = 0;
            try
            {
                if (user != null)
                {
                    int userId = user.UserId;
                    Model.ShiftLabor objShiftLabor = new Model.ShiftLabor { LaborId = id, EcolabAccountNumber = this.GetEcoLabAccountNumber() };
                    objShiftLabor.IsDelete = true;
                    objShiftLabor.EcolabAccountNumber = user.EcolabAccountNumber;
                    objShiftLabor.MaxNumberOfRecords = this.laborService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        isDeleted = this.laborService.DeleteShiftLabor(objShiftLabor, userId, out lastModifiedTimeStamp);
                        if (isDeleted == id)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.OK, "Labor Deleted");
                        }
                    }
                    else
                    {
	                    int outId;
                        Model.ShiftSyncContainer shiftContainer = new Model.ShiftSyncContainer();
                        shiftContainer.ShiftLabor = new List<Model.ShiftLabor>();
                        shiftContainer.ShiftLabor.Add(objShiftLabor);
	                    shiftContainer.IsLabor = true;
						result = Push.PushToLocal(shiftContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteShiftLabor, out outId);
						if (result == 51030)
						{
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
						}
						else if (result == 60000)
						{
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
						}
                        else if (result == 51060)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        }
                        else if (result == 39)
						{
							return this.Request.CreateResponse(HttpStatusCode.BadRequest);
						}
						if (outId == id)
						{
							return this.Request.CreateResponse(HttpStatusCode.OK, "Labor Deleted");
						}
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Shift Labor - Delete Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Shift Labor. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Labor Deletion");
        }

        #endregion
    }
}