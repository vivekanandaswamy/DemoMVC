﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Formula Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Mvc;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Elmah;
    using Models.PlantSetup.Formula;
    using Services.Interfaces;
    using Utilities;
    using Model = Ecolab.Models;
    using WebModel = Models.PlantSetup;
    using Models.PlantSetup;

    /// <summary>
    ///     class Plant Chemical Controller
    /// </summary>
    public class PlantFormulaController : BaseApiController
    {
        /// <summary>
        ///     Plant CustomerService
        /// </summary>
        private readonly IPlantCustomerService customerService;

        /// <summary>
        ///     Plant Customer Service
        /// </summary>
        private readonly IProgramMasterService progMasterService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantFormulaController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="progMasterService">The program Master Service.</param>
        public PlantFormulaController(IUserService userService, IProgramMasterService progMasterService, IPlantCustomerService customerService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.progMasterService = progMasterService;
            this.customerService = customerService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// Get the Formula list
        /// </summary>
        /// <returns>
        /// Returns the Formula list
        /// </returns>
        [System.Web.Http.HttpGet]
        public HttpResponseMessage GetFormula(int programId)
        {
            Model.User user = this.GetUser();
            List<Model.Formula> formulas = this.progMasterService.GetFormulaDetails(user.EcolabAccountNumber, 1, 12, programId);
            formulas = this.CalPieceWeight(formulas);
            formulas.ForEach(f => f.WeightDisplay = f.Weight);
            List<WebModel.FormulaModel> meterList = Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(formulas);
            //meterList = ConvertUnits(meterList, false);
            long total = meterList.Count > 0 ? meterList[0].TotalCount : 0;
            List<Model.PlantUtilityUnitTypes> units = this.progMasterService.GetFormulaUnits(user.EcolabAccountNumber, user.RegionId );

            var result = new { Items = meterList, TotalCount = total, Units = units };

            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Convert Units
        /// </summary>
        /// <param name="meterList"></param>
        /// <param name="isEdit"></param>
        /// <returns></returns>
        private List<WebModel.FormulaModel> ConvertUnits(List<WebModel.FormulaModel> meterList, bool isEdit)
        {
            Model.User user = this.GetUser();
            meterList.ConvertUnit(user.RegionId, user.EcolabAccountNumber, user.UserId, true, 0);
            return meterList;
        }

        /// <summary>
        /// Get the Formula list
        /// </summary>
        /// <param name="page">page</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="programId">The program identifier.</param>
        /// <returns>
        /// Returns the Formula list
        /// </returns>
        [System.Web.Http.HttpGet]
        public List<WebModel.FormulaModel> GetFormulaForPrint(int page, int pageSize, int programId)
        {
            Model.User user = this.GetUser();
            List<Model.Formula> formulas = this.progMasterService.GetFormulaDetails(user.EcolabAccountNumber, page, pageSize, programId);
            PlantModel plantModel = this.GetPlantDetails();
            formulas.ForEach(cc => cc.PlantChainId = plantModel.PlantChainId);
            return Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(this.CalPieceWeight(formulas));
        }

        /// <summary>
        ///     Get Formula List
        /// </summary>
        /// <returns>returns the meter list</returns>
        [System.Web.Http.HttpGet]
        public WebModel.FormulaViewModel GetFormulaForDropDown(int plantChainId)
        {
            Model.User user = this.GetUser();
            //List<Model.Formula> formulas = this.progMasterService.GetFormulaDetails(user.EcolabAccountNumber, 1, 12,0);
            List<Model.EcolabTextileCategory> ecolabTextileCategory = this.progMasterService.GetEcolabTextileCategory(user.EcolabAccountNumber);
            List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(0);
            List<Model.PlantChainProgram> plantChainProgram = this.progMasterService.GetPlantChainProgramByChainId(plantChainId);
            List<Model.ChainTextileCategory> chainTextileCategory = this.progMasterService.GetChainTextileCategory(user.EcolabAccountNumber);
            List<Model.PlantCustomer> customer = this.customerService.GetPlantCustomer(user.EcolabAccountNumber);
            List<Model.PlantUtilityUnitTypes> units = this.progMasterService.GetFormulaUnits(user.EcolabAccountNumber, user.RegionId);
            List<Model.FormulaSegment> formulaSegments = this.progMasterService.GetFormulaSegments();
            List<EcolabTextileCategoryModel> utilityTypeList = Mapper.Map<List<Model.EcolabTextileCategory>, List<EcolabTextileCategoryModel>>(ecolabTextileCategory);
            List<EcolabSaturationModel> utilityLocationsList = Mapper.Map<List<Model.EcolabSaturation>, List<EcolabSaturationModel>>(ecolabSaturation);
            List<PlantChainProgramModel> controllerList = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(plantChainProgram);
            List<ChainTextileCategoryModel> parentList = Mapper.Map<List<Model.ChainTextileCategory>, List<ChainTextileCategoryModel>>(chainTextileCategory);
            List<Model.PlantUtilityUnitTypes> unitlist = Mapper.Map<List<Model.PlantUtilityUnitTypes>, List<Model.PlantUtilityUnitTypes>>(units);
            List<FormulaSegmentModel> formulaSegmentsmodel = Mapper.Map<List<Model.FormulaSegment>, List<FormulaSegmentModel>>(formulaSegments);

            WebModel.FormulaViewModel formulaView = new WebModel.FormulaViewModel { EcolabTextileCategory = utilityTypeList, FormulaSegments = formulaSegmentsmodel, ecolabSaturation = utilityLocationsList, plantChainProgram = controllerList, chainTextileCategory = parentList, units = unitlist, CustomerList = customer };

            return formulaView;
        }

        /// <summary>
        /// To save the data
        /// </summary>
        /// <param name="programid">program id</param>
        /// <param name="data">the data</param>
        /// <returns>
        /// Returns updated customer data
        /// </returns>
        [System.Web.Http.HttpPut]
        public HttpResponseMessage Put(int programid, List<WebModel.FormulaModel> data)
        {
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            
            int response = 0;
            if (programid > 0)
            {
                try
                {
                    foreach (var formula in data)
                    {
                        formula.LastModifiedTimeStamp = DateTime.SpecifyKind(formula.LastModifiedTimeStamp, DateTimeKind.Utc);

                        formula.ConvertUnit(user.RegionId, user.EcolabAccountNumber, user.UserId, true, 0);
                        formula.MaxNumberOfRecords = this.progMasterService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                        Model.Formula objformula = Mapper.Map<WebModel.FormulaModel, Model.Formula>(formula);
                        objformula.EcolabAccountNumber = user.EcolabAccountNumber;

                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            objformula.ProgramId = this.progMasterService.SaveFormulaDetails(objformula, user.UserId, out lastModifiedTimeStamp);
                            if (objformula.ProgramId == 303)
                            {
                                string errorMessage = "Formula Name already exists.";
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                            }
                        }
                        else
                        {
                            response = Push.PushToLocal(objformula, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdatePlantFormula);
                        }
                        switch (response)
                        {
                            case 51030:
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                            case 51060:
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                            case 60000:
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                            case 303:
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);

                            case 51031:
                                string errorMessage = "Formula Name already exists.";
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                        }
                    }
                }
                catch (SqlException ex)
                {
                    string errorMessage = string.Empty;
                    int errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                }

                var result = new { Items = data, data[0].TotalCount };
                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid Formula details.");
        }

        /// <summary>
        /// creates new the customer data
        /// </summary>
        /// <param name="data">Meter data to create</param>
        /// <returns>
        /// Returns created meter data
        /// </returns>
        [System.Web.Http.HttpPost]
        public HttpResponseMessage CreateFormula(FormulaModel data)
        {
            Model.User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                //data.ConvertUnit(user.RegionId, user.EcolabAccountNumber, user.UserId, true, 0);
                data.MaxNumberOfRecords = this.progMasterService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                Model.Formula objFormula = Mapper.Map<WebModel.FormulaModel, Model.Formula>(data);
                data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);
                objFormula.EcolabAccountNumber = user.EcolabAccountNumber;

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    objFormula.ProgramId = this.progMasterService.SaveFormulaDetails(objFormula, user.UserId, out lastModifiedTimeStamp);
                    data.ProgramId = result;
                    if (objFormula.ProgramId == 303)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    }
                }
                else
                {
                    result = Push.PushToLocal(objFormula, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddPlantFormula);
                    data.ProgramId = result;
                }
                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                    case 51031:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51031);

                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                }
            }
            catch (Exception ex)
            {
                int errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        /// To update the formula details
        /// </summary>
        /// <param name="data">formula data to update</param>
        /// <returns>
        /// Returns the updated data
        /// </returns>
        [System.Web.Http.HttpPost]
        public HttpResponseMessage Put(List<WebModel.FormulaModel> data)
        {
            return this.Put(data[0].ProgramId, data);
        }

        /// <summary>
        /// Delete the Formula
        /// </summary>
        /// <param name="programId">The program id</param>
        /// <returns>
        /// Returns the status code
        /// </returns>
        [System.Web.Http.HttpGet]
        public HttpResponseMessage DeleteFormula(int programId, DateTime lastmodifiedtime)
        {
            int result = 0;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            Model.Formula objFormula = new Ecolab.Models.Formula();
            if (programId > 0)
            {
                try
                {
                    objFormula.IsDelete = true;
                    objFormula.MaxNumberOfRecords = this.progMasterService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    objFormula.EcolabAccountNumber = user.EcolabAccountNumber;
                    objFormula.LastModifiedTimeStamp = DateTime.SpecifyKind(lastmodifiedtime, DateTimeKind.Utc);
                    objFormula.ProgramId = programId;
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        this.progMasterService.DeleteFormulaDetails(objFormula.ProgramId, lastmodifiedtime, user.EcolabAccountNumber, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(objFormula, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeletePlantFormula);
                    }
                    switch (result)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51031:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51031);

                        case 303:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the Formula. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, programId);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid Formula details.");
        }

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <returns></returns>
        [System.Web.Http.HttpGet]
        public JsonResult GetCategories()
        {
            Model.User user = this.GetUser();
            List<Model.EcolabTextileCategory> ecolabTextileCategory = this.progMasterService.GetEcolabTextileCategory(user.EcolabAccountNumber);
            List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(0);
            List<Model.PlantChainProgram> plantChainProgram = this.progMasterService.GetPlantChainProgram();
            List<Model.ChainTextileCategory> chainTextileCategory = this.progMasterService.GetChainTextileCategory(user.EcolabAccountNumber);
            List<Model.PlantCustomer> customerLists = this.customerService.GetPlantCustomer(user.EcolabAccountNumber);
            var result = new { TextileCategory = ecolabTextileCategory, Saturation = ecolabSaturation, ChainProgram = plantChainProgram, ChainTextileCategory = chainTextileCategory, CustomerList = customerLists };

            return new JsonResult { Data = result, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }

        /// <summary>
        /// Based TextileId it will loa the Saturation
        /// </summary>
        /// <param name="textileId"></param>
        /// <returns>List of Saturation Collections</returns>
        [System.Web.Http.HttpGet]
        public List<Model.EcolabSaturation> GetSaturationDetails(int textileId)
        {
            List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(textileId);
            return ecolabSaturation;
        }

        /// <summary>
        /// Gets the chain formula names.
        /// </summary>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <returns></returns>
        public List<PlantChainProgramModel> GetChainFormulaNames(int plantChainId)
        {
            List<Model.PlantChainProgram> chainFormulas = this.progMasterService.GetChainFormulaNames(plantChainId);
            List<PlantChainProgramModel> chainFormulaNames = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(chainFormulas);
            return chainFormulaNames;
        }

        /// <summary>
        /// Gets the chain formula data.
        /// </summary>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <returns></returns>
        public List<PlantChainProgramModel> GetChainFormulaData(int plantProgramId)
        {
            List<Model.PlantChainProgram> chainFormulasData = this.progMasterService.GetChainFormulaData(plantProgramId);
            List<PlantChainProgramModel> chainFormulaData = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(chainFormulasData);
            return chainFormulaData;
        }

        #region privatemethods

        /// <summary>
        ///     Caluculate Piece Weight
        /// </summary>
        /// <param name="formulas">The formulas</param>
        /// <returns>Returns the calculate value</returns>
        private List<Model.Formula> CalPieceWeight(List<Model.Formula> formulas)
        {
            foreach (Model.Formula item in formulas)
            {
                if (item.Weight.HasValue && item.Weight.Value != 0 && item.Pieces.HasValue && item.Pieces.Value != 0)
                {
                    item.PieceWeight = Math.Round(item.Weight.Value / item.Pieces.Value, 2);
                }
                else
                {
                    item.PieceWeight = 0;
                }
                item.PieceWeightAsString = item.PieceWeight.ToString("#,0.##");
            }
            return formulas;
        }

        #endregion privatemethods
    }
}