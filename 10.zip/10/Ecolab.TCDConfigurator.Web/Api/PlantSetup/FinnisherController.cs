﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.Finnisher;
    using Models.PlantSetup.Finnisher;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Finnisher;

    /// <summary>
    ///     Api controller for FinnisherController
    /// </summary>
    public class FinnisherController : BaseApiController
    {
        /// <summary>
        ///     FinnisherGroup Service
        /// </summary>
        private readonly IFinnisherGroupService finnisherGroupService;

        /// <summary>
        ///     z,o
        ///     FinnisherGroup Service
        /// </summary>
        private readonly IFinnisherService finnisherService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="CustomerController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        public FinnisherController(IUserService userService, IFinnisherGroupService finnisherGroupService, IFinnisherService finnisherService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.finnisherGroupService = finnisherGroupService;
            this.finnisherService = finnisherService;
        }

        #region FinnisherGroups

        /// <summary>
        ///     Method to get the Finnishers along with Finnisher Groups
        /// </summary>
        /// <returns>List of FinnisherGroupModel</returns>
        public List<FinnisherGroupModel> Get()
        {
            List<FinnisherGroup> finnishers = this.finnisherGroupService.FetchFinnisherGroupDetails(this.EcolabAccountNumber);
            List<FinnisherGroupModel> finnisherGroupModel = Mapper.Map<List<FinnisherGroup>, List<FinnisherGroupModel>>(finnishers);

            var groupList = finnisherGroupModel.Select(x => new { x.Id, x.Name, x.IsDeleted, x.LastModifiedTimeStampFinnisherGroup }).Where(x => x.IsDeleted == false).Distinct().ToList();

            var finnisherGroupModels = new List<FinnisherGroupModel>();

            foreach (var group in groupList)
            {
                List<FinnisherGroupModel> finnishersList = finnisherGroupModel.FindAll(x => x.Id == group.Id);
                var finnisherModelList = new List<FinnisherModel>();
                foreach (FinnisherGroupModel dr in finnishersList)
                {
                    if (dr.Finnisher.Number > 0)
                    {
                        var drm = new FinnisherModel
                        {
                            GroupId = group.Id,
                            Name = dr.Finnisher.Name,
                            Number = dr.Finnisher.Number,
                            FinisherId = dr.Finnisher.FinisherId,
                            FinnisherType = new FinnisherTypeModel
                            {
                                Id = dr.Finnisher.FinnisherType.Id,
                                Name = dr.Finnisher.FinnisherType.Name
                            },
                            LastModifiedTimeStampFinnisher = dr.Finnisher.LastModifiedTimeStampFinnisher
                        };
                        finnisherModelList.Add(drm);
                    }
                }

                var finnisherGroupModelList = new FinnisherGroupModel
                {
                    Id = group.Id,
                    Name = group.Name,
                    LastModifiedTimeStampFinnisherGroup = group.LastModifiedTimeStampFinnisherGroup,
                    Finnishers = finnisherModelList.OrderBy(_ => _.Number).ToList()
                };
                finnisherGroupModels.Add(finnisherGroupModelList);
            }

            return finnisherGroupModels;
        }

        /// <summary>
        ///     Method to create a new Finnisher group
        /// </summary>
        /// <param name="finnisherGroup"></param>
        /// <returns>Returns HttpResponseMessage </returns>
        [HttpPost]
        public HttpResponseMessage CreateFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Name = finnisherGroup.Name, EcolabAccountNumber = user.EcolabAccountNumber };

                finnisherGroupData.MaxNumberOfRecords = this.finnisherGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherGroupService.InsertFinnisherGroup(finnisherGroupData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddFinnisherGroup);
                    }
                    switch (result)
                    {
                        case 301:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);

                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Finnisher group
        /// </summary>
        /// <param name="finnisherGroup"></param>
        /// <returns>Returns HttpResponseMessage</returns>
        [HttpPost]
        public HttpResponseMessage UpdateFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Id = finnisherGroup.Id, Name = finnisherGroup.Name, EcolabAccountNumber = user.EcolabAccountNumber };
                finnisherGroupData.MaxNumberOfRecords = this.finnisherGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                finnisherGroupData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(finnisherGroup.LastModifiedTimeStampFinnisherGroup, DateTimeKind.Utc);
                finnisherGroupData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(finnisherGroup.LastModifiedTimeStampFinnisher, DateTimeKind.Utc);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherGroupService.UpdateFinnisherGroup(finnisherGroupData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateFinnisherGroup);
                    }
                    if (result > 0)
                    {
                        if (result == 301)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        }
                        if (result == 302)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                        }
                        if (result == 51030)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        }
                        if (result == 60000)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                        if (result == 51060)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        }
                    }
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a FinnisherGroup
        /// </summary>
        /// <param name="finnisherGroup"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage DeleteFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Id = finnisherGroup.Id };

                finnisherGroupData.IsDelete = true;
                finnisherGroupData.MaxNumberOfRecords = this.finnisherGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                finnisherGroupData.EcolabAccountNumber = user.EcolabAccountNumber;
                finnisherGroupData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(finnisherGroup.LastModifiedTimeStampFinnisherGroup, DateTimeKind.Utc);
                finnisherGroupData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(finnisherGroup.LastModifiedTimeStampFinnisher, DateTimeKind.Utc);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherGroupService.DeleteFinnisherGroup(finnisherGroupData, finnisherGroupData.Id, user.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteFinnisherGroup);
                    }
                    switch (result)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion FinnisherGroups

        #region Finnisher

        [HttpGet]
        public IEnumerable<FinnisherTypeModel> FetchFinnisherTypes()
        {
            List<FinnisherType> finnisherType = this.finnisherService.FetchFinnisherTypes(this.EcolabAccountNumber);
            List<FinnisherTypeModel> finnisherTypeModel = Mapper.Map<List<FinnisherType>, List<FinnisherTypeModel>>(finnisherType);
            return finnisherTypeModel.ToList();
        }

        /// <summary>
        ///     Method to create a new Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage CreateFinnisher([FromBody] FinnisherModel finnisher)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                int finnisherGroupId = finnisher.GroupId;

                Finnisher finnisherData = new Finnisher { Name = finnisher.Name, FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id }, EcolabAccountNumber = user.EcolabAccountNumber, Number = finnisher.Number, GroupId = finnisher.GroupId };

                finnisherData.MaxNumberOfRecords = this.finnisherService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherService.InsertFinnisher(finnisherData, finnisherGroupId, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddFinnisher);
                    }
                    switch (result)
                    {
                        case 44:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);

                        case 45:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 301:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 302:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);

                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http Response messgae</returns>
        [HttpPost]
        public HttpResponseMessage UpdateFinnisher([FromBody] FinnisherModel finnisher)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                var finnisherData = new Finnisher
                {
                    GroupId = finnisher.GroupId,
                    FinisherId = finnisher.FinisherId,
                    Name = finnisher.Name,
                    EcolabAccountNumber = user.EcolabAccountNumber,
                    Number = finnisher.Number,
                    FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id },
                    LastModifiedTimeStampFinnisher = finnisher.LastModifiedTimeStampFinnisher,
                    MaxNumberOfRecords = finnisherService.GetMaxNumberOfRecords(user.EcolabAccountNumber)
                };
                finnisherData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(finnisherData.LastModifiedTimeStampFinnisher, DateTimeKind.Utc);
                finnisherData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(finnisherData.LastModifiedTimeStampFinnisherGroup, DateTimeKind.Utc);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherService.UpdateFinnisher(finnisherData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateFinnisher);
                    }
                    switch (result)
                    {
                        case 42:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);

                        case 43:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);

                        case 301:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 302:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);

                        case 51031:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);

                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http response message</returns>
        [HttpPost]
        public HttpResponseMessage DeleteFinnisher([FromBody] FinnisherModel finnisher)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;

            try
            {
                var finnisherData = new Finnisher
                {
                    Number = finnisher.Number,
                    GroupId = finnisher.GroupId,
                    FinisherId = finnisher.FinisherId,
                    Name = finnisher.Name,
                    EcolabAccountNumber = user.EcolabAccountNumber,
                    FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id },
                    LastModifiedTimeStampFinnisher = finnisher.LastModifiedTimeStampFinnisher,
                    MaxNumberOfRecords = this.finnisherService.GetMaxNumberOfRecords(user.EcolabAccountNumber),
                    IsDelete = true
                };

                finnisherData.EcolabAccountNumber = user.EcolabAccountNumber;
                finnisherData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(finnisherData.LastModifiedTimeStampFinnisher, DateTimeKind.Utc);
                finnisherData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(finnisherData.LastModifiedTimeStampFinnisherGroup, DateTimeKind.Utc);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.finnisherService.DeleteFinnisher(finnisherData, finnisherData.Number, user.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(finnisherData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteFinnisher);
                    }
                    switch (result)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion Finnisher
    }
}