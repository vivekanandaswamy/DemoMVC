﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Labor Cost Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.ShiftLabor;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Utilities;
    using Model = Ecolab.Models.PlantSetup.ShiftLabor;

    /// <summary>
    ///     Api controller for FinnisherController
    /// </summary>
    public class LaborCostController : BaseApiController
    {
        /// <summary>
        ///     Labor Cost Service
        /// </summary>
        private readonly ILaborCostService laborCostService;

        /// <summary>
        ///     Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="laborCostService">The labor cost service</param>
        public LaborCostController(IUserService userService, IPlantService plantService, ILaborCostService laborCostService)
            : base(userService, plantService)
        {
            this.laborCostService = laborCostService;
        }

        /// <summary>
        ///     Get Labor Cost Details
        /// </summary>
        /// <returns>List of LaborCostModel</returns>
        [HttpGet]
        public List<LaborCostModel> Fetch()
        {
            List<Model.LaborCost> laborCost = this.laborCostService.FetchLaborTypeCostDetails(this.EcolabAccountNumber);
            List<LaborCostModel> laborCostList = Mapper.Map<List<Model.LaborCost>, List<LaborCostModel>>(laborCost);
            laborCostList.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, false, 2, ExchangeRate, GetPlantDetails().CurrencyCode);
			laborCostList.ForEach(_ => _.CostAsString = _.Cost.ToString("#,0.##"));
            return laborCostList;
        }

        /// <summary>
        ///     Update Labor cost Details
        /// </summary>
        /// <param name="data">List of LaborCostModel</param>
        /// <returns>Update status code</returns>
        [HttpPost]
        public HttpResponseMessage Put(IEnumerable<LaborCostModel> data)
        {
            int status = 0, result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            //data.ToList().ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, true, 2, ExchangeRate);
            List<Model.LaborCost> laborCostList = Mapper.Map<IEnumerable<LaborCostModel>, IEnumerable<Model.LaborCost>>(data).ToList();
            IEnumerable<Model.LaborCost> laborCosts = laborCostList.AsEnumerable();
            try
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    int errorCode = 0;
                    laborCosts = this.laborCostService.SaveLaborCost(laborCostList.AsEnumerable(), this.EcolabAccountNumber, user.UserId, out lastModifiedTimeStamp, out errorCode);
                }
                else
                {
                    int maxNumRecord = laborCostService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    laborCostList.ForEach(_ => _.MaxNumberOfRecords = maxNumRecord);
                    laborCostList.ForEach(_ => _.EcolabAccountNumber = user.EcolabAccountNumber);
                    laborCostList.ForEach(_ => _.LastModifiedTimeStamp = DateTime.SpecifyKind(_.LastModifiedTimeStamp, DateTimeKind.Utc));

                    LaborCostContainer laborCostContainer = new LaborCostContainer();
                    laborCostContainer.LaborCostList = new List<LaborCost>();
                    laborCostContainer.LaborCostList = laborCostList;

                    result = Push.PushToLocal(laborCostContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateLaborCost);

                }
                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }

                foreach (Model.LaborCost laborCost in laborCosts)
                {
                    if (result == 0)
                    {
                        status = 201;
                        return this.Request.CreateResponse(HttpStatusCode.OK, status);
                        
                    }
                    if (laborCost.Id < 0 || laborCost.Id == 0)
                    {
                        status = 0;
                        break;
                    }

                    status = 201;
                }

                return (status == 201) ? this.Request.CreateResponse(HttpStatusCode.OK, status) : this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }
    }
}