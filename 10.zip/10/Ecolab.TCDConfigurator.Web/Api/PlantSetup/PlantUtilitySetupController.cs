﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupController.cs" company="Ecolab">
// Constructor and entities of the PlantUtilitySetup Controller class.
// </copyright>
// <summary>The methods for plant utility setup.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Helper;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Model = Ecolab.Models;
    using WebModel = Models.PlantSetup;

    /// <summary>
    ///     Class for plant utility setup controller.
    /// </summary>
    public class PlantUtilitySetupController : BaseApiController
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private readonly IUserService userService;

        /// <summary>
        ///     Plant service
        /// </summary>
        private readonly IPlantUtilityService utilityService;

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantUtilitySetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        /// <param name="utilityService">The utility Service.</param>
        public PlantUtilitySetupController(IUserService userService, IPlantService plantService, IPlantUtilityService utilityService)
            : base(userService, plantService)
        {
            this.userService = userService;
            this.utilityService = utilityService;
        }

        /// <summary>
        ///     Get all the values related to Plant setup
        /// </summary>
        /// <returns>Returns the plant model</returns>
        public WebModel.PlantUtilityListModel Get()
        {
			int regionId = this.GetUser().RegionId;
			List<PlantUtilityWaterTypeMaster> waterTypes = this.utilityService.GetFreeWaterDetails(regionId);
            List<PlantUtilityGasoilTypes> gasoilData = this.utilityService.GetGasoilTypes(this.EcolabAccountNumber);
            List<PlantUtilityDimensionTypes> dimensionsData = this.utilityService.GetDimensionTypes(this.EcolabAccountNumber);
            List<Model.PlantUtilityUnitTypes> energyContentunitsData = this.utilityService.GetPlantUtilityEnergyContentUnits(this.EcolabAccountNumber);
            List<Model.PlantUtilityUnitTypes> energyPriceUnitsData = this.utilityService.GetPlantUtilityEnergyPriceUnits(this.EcolabAccountNumber, regionId);
            List<PlantUtilityFactorTypes> utilityData = this.utilityService.GetPlantUtilityDetails(EcolabAccountNumber);
            if (utilityData.Count == 0)
            {
                utilityData = this.utilityService.GetPlantUtilityDetailsList(regionId);
            }

            WebModel.PlantUtilityListModel utilityListModel = new WebModel.PlantUtilityListModel();
            utilityListModel.FreeWaterTypes = waterTypes.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            utilityListModel.GasOilTypes = gasoilData.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            utilityListModel.FactorTypes = utilityData.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            foreach (WebModel.PlantUtilityFactorTypes plantUtilityFactorType in utilityListModel.FactorTypes)
            {
                plantUtilityFactorType.EnergyContentAsString = plantUtilityFactorType.EnergyContent.ToString("#,0.##");
                plantUtilityFactorType.PriceAsString = plantUtilityFactorType.Price.ToString("#,###,###.####");
                if (plantUtilityFactorType.EvaporationFactor < 100)
                {
                    plantUtilityFactorType.EvaporationFactorAsString = plantUtilityFactorType.EvaporationFactor.ToString("#,0.00");
                }
                else
                {
                    plantUtilityFactorType.EvaporationFactorAsString = plantUtilityFactorType.EvaporationFactor.ToString("#,0.0");
                }
                    
                if (plantUtilityFactorType.RewashFactor < 100)
                {
                    plantUtilityFactorType.RewashFactorAsString = plantUtilityFactorType.RewashFactor.ToString("#,0.00");
                }
                else
                {
                    plantUtilityFactorType.RewashFactorAsString = plantUtilityFactorType.RewashFactor.ToString("#,0.0");
                }

                if (plantUtilityFactorType.StackPercentage < 100)
                {
                    plantUtilityFactorType.StackPercentageAsString = plantUtilityFactorType.StackPercentage.ToString("#,0.00");
                }
                else
                {
                    plantUtilityFactorType.StackPercentageAsString = plantUtilityFactorType.StackPercentage.ToString("#,0.0");
                }

                if (plantUtilityFactorType.SteamPercentage < 100)
                {
                    plantUtilityFactorType.SteamPercentageAsString = plantUtilityFactorType.SteamPercentage.ToString("#,0.00");
                }
                else
                {
                    plantUtilityFactorType.SteamPercentageAsString = plantUtilityFactorType.SteamPercentage.ToString("#,0.0");
                }

                if (plantUtilityFactorType.BoilerPercentage < 100)
                {
                    plantUtilityFactorType.BoilerPercentageAsString = plantUtilityFactorType.BoilerPercentage.ToString("#,0.00");
                }
                else
                {
                    plantUtilityFactorType.BoilerPercentageAsString = plantUtilityFactorType.BoilerPercentage.ToString("#,0.0");
                }

                plantUtilityFactorType.EnergyPriceAsString = plantUtilityFactorType.EnergyPrice.ToString("#,###,###.####");
                plantUtilityFactorType.ElectricPriceAsString = plantUtilityFactorType.ElectricPrice.ToString("#,0.00");
                plantUtilityFactorType.TemperatureAsString = plantUtilityFactorType.Temperature.ToString("#,0");
            }
            utilityListModel.DimensionTypes = dimensionsData.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            utilityListModel.PlantUtilityEnergyContentUnits = energyContentunitsData.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            utilityListModel.PlantUtilityEnergyPriceUnits = energyPriceUnitsData.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            // var temperatureUnits = GetPlantUOMSubUnits(GetPlantDetails().UOMId,GetPlantDetails().EcoalabAccountNumber).Where(x=>x.Unit=="Temperature").FirstOrDefault();
            // utilityListModel.FactorTypes.ConvertUnit(temperatureUnits.SubUnit_Source, temperatureUnits.SubUnit_Target);
            return utilityListModel;
        }

        /// <summary>
        ///     Saving the plant utility factors with price and temperatures.
        /// </summary>
        /// <param name="plantUtilityFactorTypes">
        ///     Passing the plant utility values for saving into database in plant utility setup
        ///     object.
        /// </param>
        [HttpPost]
        public HttpResponseMessage Save(List<PlantUtilityFactorTypes> plantUtilityFactorTypes)
        {
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            List<PlantUtilityFactorTypes> plantUtilitySetup =
                Mapper.Map<List<PlantUtilityFactorTypes>, List<PlantUtilityFactorTypes>>(
                    plantUtilityFactorTypes);
            int response = 0;
            try
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    plantUtilitySetup.ForEach(t => t.EcolabAccountNumber = user.EcolabAccountNumber);
                    utilityService.SavePlantWaterEnergyUtilityDetails(plantUtilitySetup, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    PlantUtilityContainer plantUtilityContainer = new PlantUtilityContainer();
                    plantUtilityContainer.PlantUtilityFactorTypes = new List<PlantUtilityFactorTypes>();
                    foreach (PlantUtilityFactorTypes plantUtilityFactor in plantUtilitySetup)
                    {
                        plantUtilityFactor.LastModifiedTime =
                            DateTime.SpecifyKind(plantUtilityFactor.LastModifiedTime, DateTimeKind.Utc);
                        plantUtilityFactor.EcolabAccountNumber = user.EcolabAccountNumber;
                        plantUtilityContainer.PlantUtilityFactorTypes.Add(plantUtilityFactor);
                        
                    }
                    response = Push.PushToLocal(plantUtilityContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateUtilityFactor);
                    switch (response)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the utility. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        /// <summary>
        ///     Gets the gas/oil default value and unit of measure code based on the gas/oil type selected.
        /// </summary>
        /// <param name="id">Gets the gas/oil type id selected.</param>
        /// <returns>The default value and unit of measure code of the selected gas/oil type.</returns>
        [HttpGet]
        public Dictionary<string, string> GasTypeDetails(int id)
        {
            var gasTypeData = new Dictionary<string, string>();
            List<PlantUtilityGasoilTypes> gasoilData = this.utilityService.GetGasoilTypes(this.EcolabAccountNumber);

            if (gasoilData != null)
            {
                for (int gasType = 0; gasType < gasoilData.Count; gasType++)
                {
                    if (gasoilData[gasType].GasoilTypeId == id)
                    {
                        string defaultValue = gasoilData[gasType].DefaultValue.ToString();
                        string uomCode = gasoilData[gasType].UOMCode;
                        gasTypeData.Add("defaultValue", defaultValue);
                        gasTypeData.Add("uomCode", uomCode);
                    }
                }
            }
            return gasTypeData;
        }
    }
}