﻿// -----------------------------------------------------------------------
// <copyright file="PlantChemicalController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Plant Chemical Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
	using Ecolab.Models.WasherGroup;
	using Ecolab.Services.Interfaces.WasherGroup;
    using Helper;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Model = Ecolab.Models.PlantSetup.Chemical;

    /// <summary>
    ///     class Plant Chemical Controller
    /// </summary>
    public class PlantChemicalController : BaseApiController
    {
        /// <summary>
        ///     Product Master Service(Plant chemical)
        /// </summary>
        private readonly IProductMasterService prodMastService;

		/// <summary>
		/// Washer Group Service
		/// </summary>
		private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="prodMastService">The product master service</param>
        /// <param name="plantService">The Plant Service</param>
		public PlantChemicalController(IUserService userService, IProductMasterService prodMastService, IPlantService plantService, IWasherGroupService washerGroupService)
            : base(userService, plantService)
        {
            this.prodMastService = prodMastService;
			this.washerGroupService = washerGroupService;
        }

        /// <summary>
        ///     Get the plant chemical details
        /// </summary>
        /// <returns>List of ProductMasterModel</returns>
        [System.Web.Mvc.HttpGet]
        public IEnumerable<ProductMasterModel> GetPlantChemical()
        {
            List<Model.ProductMaster> plantChem = this.prodMastService.FetchPlantChemicalList(this.EcolabAccountNumber);
            List<ProductMasterModel> plantChemList = plantChem.Select(EntityConverter.ConvertToWebModel).ToList();
            plantChemList.ForEach(_ => _.CostAsString = _.Cost.ToString("#,0.##"));
            foreach (var item in plantChemList)
            {
                if (!string.IsNullOrEmpty(item.PackagingSize))
                {
                    item.PackagingSize = item.UnitPerPackage + "-" + Math.Round(item.UnitWeightVolume.GetValueOrDefault()) + " " + item.UnitWeightVolumeUOMCode;
                }
            }
            return plantChemList.AsEnumerable();
        }

        /// <summary>
        ///     Gets the ChemicalsList
        /// </summary>
        /// <param name="term">Search term to get matching chemicals</param>
        /// <returns>List of ChemicalsModel</returns>
        [System.Web.Mvc.HttpGet]
        public IEnumerable<ChemicalsModel> GetChemicalList(string term)
        {
            PlantModel plantDetails = this.GetPlantDetails();
            List<Model.Chemicals> chemicals = this.prodMastService.FetchChemicalList(term, plantDetails.EcoalabAccountNumber);
            List<ChemicalsModel> chemicalList = Mapper.Map<List<Model.Chemicals>, List<ChemicalsModel>>(chemicals);

            return chemicalList;
        }

        /// <summary>
        ///     creates new the Chemical data
        /// </summary>
        /// <param name="data">Chemical data to create</param>
        /// <returns>Returns Success or failure response Message</returns>
        [System.Web.Mvc.HttpPost]
        public HttpResponseMessage CreateChemical([FromBody] List<ProductMasterModel> data)
        {
            User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            data[0].LastModifiedTimeStamp = DateTime.SpecifyKind(data[0].LastModifiedTimeStamp, DateTimeKind.Utc);
            try
            {
                data[0].MaxNumberOfRecords = this.prodMastService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                data[0].EcolabAccountNumber = user.EcolabAccountNumber;
                data[0].Volume = "0";
                data[0].Weight = "0";
                Model.ProductMaster objChemical = Mapper.Map<ProductMasterModel, Model.ProductMaster>(data[0]);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    this.prodMastService.SavePlantChemicalDetails(objChemical, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(objChemical, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddPlantChemical);
                }

                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
            }
            catch (Exception)
            {
                //Logger.Error("Api - Chemical - Create Error :", ex);
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Chemical adding failed.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Update plant chemical
        /// </summary>
        /// <param name="productId">Chemical Id in My Serice</param>
        /// <param name="data">The Product Master Model</param>
        /// <returns>Returns Success or failure response Message</returns>
        [System.Web.Mvc.HttpPut]
        public HttpResponseMessage Put(int productId, ProductMasterModel data) //'?' is req for product id
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);
            try
            {
                data.MaxNumberOfRecords = this.prodMastService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                data.EcolabAccountNumber = user.EcolabAccountNumber;
                if (!data.IncludeinCI)
                {
                    data.InventoryExpense = null;
                }
                else if (string.IsNullOrEmpty(data.InventoryExpense))
                {
                    data.InventoryExpense = "I";
                }

                Model.ProductMaster objChemical = EntityConverter.ConvertToServiceModel(data);
                objChemical.Id = productId;
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    this.prodMastService.UpdateChemicalDetails(objChemical, user.UserId, out lastModifiedTimeStamp);
                    data.CostAsString = data.Cost.ToString("#,0.##");
                }
                else
                {
                    result = Push.PushToLocal(objChemical, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdatePlantChemical);
                }
                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
            }
            catch (Exception)
            {
                //Logger.Error("Api - Plant Chemical - Update Error :", ex);
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the plant chemical. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Update plant chemical
        /// </summary>
        /// <param name="data">The Product Master Model</param>
        /// <returns>Returns Success or failure response Message</returns>
        public HttpResponseMessage Put(List<ProductMasterModel> data)
        {
            HttpResponseMessage status = new HttpResponseMessage();

            foreach (var item in data)
            {
                status = this.Put(item.ProductId, item);
            }

            return status;
        }

        /// <summary>
        ///     Delete the Chemical based on Id
        /// </summary>
        /// <param name="id">Delete the chemical</param>
        /// <param name="data">Product Master Model data</param>
        /// <returns>Returns Success or failure response Message</returns>
        [System.Web.Mvc.HttpDelete]
        public HttpResponseMessage DeleteChemical(int? id, ProductMasterModel data)
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            data.LastModifiedTimeStamp = DateTime.SpecifyKind(data.LastModifiedTimeStamp, DateTimeKind.Utc);
            try
            {
                data.IsDelete = true;
                data.EcolabAccountNumber = user.EcolabAccountNumber;
                data.MaxNumberOfRecords = this.prodMastService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                Model.ProductMaster objChemical = EntityConverter.ConvertToServiceModel(data);

                if (id != null)
                {
                    objChemical.Id = id.Value;
                }

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    this.prodMastService.DeleteChemicalDetails(objChemical, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    result = Push.PushToLocal(objChemical, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeletePlantChemical);
                }
                switch (result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
            }
            catch (Exception Ex)
            {
                //Logger.Error("Api - Chemical - Delete Error :", ex);
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the chemical. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, id);
        }

        /// <summary>
        ///     Delete the Meter data
        /// </summary>
        /// <param name="data">Chemical data to be deleted</param>
        /// <returns>Returns Success or failure response Message</returns>
        public HttpResponseMessage DeleteChemical(List<ProductMasterModel> data)
        {
            return this.DeleteChemical(data[0].ProductId, data[0]);
        }

		/// <summary>
		///     Get all the values related to Plant setup
		/// </summary>
		/// <returns>Returns the plant model</returns>
		[HttpGet]
		public IEnumerable<Models.WasherGroup.WasherGroup> GetWasherGroupList()
		{
			IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(-1, this.EcolabAccountNumber, 0, 0, string.Empty);
			IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

			var result = from item in washerGroups
						 select new Models.WasherGroup.WasherGroup
						 {
							 EcolabAccountNumber = item.EcolabAccountNumber,
							 Id = item.Id,
							 IsDelete = item.IsDelete,
							 LastModifiedTimeStamp = item.LastModifiedTimeStamp,
							 LastSyncTime = item.LastSyncTime,
							 MaxNumberOfRecords = item.MaxNumberOfRecords,
							 MyServiceLastModifiedTime = item.MyServiceLastModifiedTime,
							 MyServiceWasherGroupGuid = item.MyServiceWasherGroupGuid,
							 MyServiceWasherGroupNumber = item.MyServiceWasherGroupNumber,
							 RowNumber = item.RowNumber,
							 RowTotalCount = item.RowTotalCount,
							 WasherGroupDescription = item.WasherGroupDescription,
							 WasherGroupId = item.WasherGroupId,
							 WasherGroupName = item.WasherGroupName,
							 WasherGroupNumber = item.WasherGroupNumber,
							 WasherGroupNumberInt = Convert.ToInt32(item.WasherGroupNumber),
							 WasherGroupTypeId = item.WasherGroupTypeId,
							 WasherGroupTypeName = item.WasherGroupTypeName,
							 ControllerCount = item.ControllerCount,
						 };
			return result.OrderBy(x => x.WasherGroupNumberInt);
		}

		/// <summary>
		///     Get the plant chemical details
		/// </summary>
		/// <returns>List of ProductMasterModel</returns>
		[HttpGet]
		public IEnumerable<Models.PlantSetup.ChemicalsModel> GetUnUsedPlantChemicalList(int washerGroupId)
		{
			List<Model.Chemicals> chemicals = this.prodMastService.GetUnUsedPlantChemicalList(this.EcolabAccountNumber, washerGroupId).OrderBy(x => x.Name).ToList();
			List<Models.PlantSetup.ChemicalsModel> chemicalList =
				Mapper.Map<List<Model.Chemicals>, List<Models.PlantSetup.ChemicalsModel>>(chemicals);

			return chemicalList;
		}

		/// <summary>
		///     Check whether new product is used by any other washer group
		/// </summary>
		/// <param name="data">Chemical data to create</param>
		/// <returns>Responce Message</returns>
		[HttpPost]
		public Models.PlantSetup.SubstituteChemicalModel CheckWasherGroupForProduct(Models.PlantSetup.SubstituteChemicalModel data)
		{
			try
			{
				data.EcolabAccountNumber = this.EcolabAccountNumber;

				data.WasherGroupIds = this.prodMastService.CheckWasherGroupForProduct(data.WasherGroupId, data.EcolabAccountNumber);
				data.WasherGroupIds.Remove(data.WasherGroupId);
			}
			catch (Exception)
			{
				return null;
			}

			return data;
		}

		/// <summary>
		///     update the old chemical with new chemical
		/// </summary>
		/// <param name="data">Chemical data to update</param>
		/// <returns>Responce Message</returns>
		[HttpPost]
		public HttpResponseMessage SaveSubstitueChemical(Models.PlantSetup.SubstituteChemicalModel data)
		{
			int result = 0;
			User user = this.GetUser();
			bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			try
			{
				data.EcolabAccountNumber = this.EcolabAccountNumber;
				Model.SubstituteChemical objChemical = Mapper.Map<Models.PlantSetup.SubstituteChemicalModel, Model.SubstituteChemical>(data);

				if (isDisconnected)
				{
					result = this.prodMastService.SaveSubstitueChemical(objChemical, this.UserId);
				}
				else
				{
					result = Push.PushToLocal(objChemical, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdSubstituteChemical);
				}
			}
			catch (Exception)
			{
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Substitute Chemical update failed.");
			}

			return this.Request.CreateResponse(HttpStatusCode.OK, result);
		}

        /// <summary>
        /// creates new the Chemical data
        /// </summary>
        /// <param name="productMasterModel">The product master model.</param>
        /// <returns>
        /// Returns Success or failure response Message
        /// </returns>
        [HttpPost]
        public HttpResponseMessage CreatePumpsChemicalDetails(ProductMasterModel productMasterModel)
        {
            User user = this.GetUser();
            int response = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            productMasterModel.LastModifiedTimeStamp = DateTime.SpecifyKind(productMasterModel.LastModifiedTimeStamp, DateTimeKind.Utc);
            try
            {
                productMasterModel.MaxNumberOfRecords = this.prodMastService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                productMasterModel.EcolabAccountNumber = user.EcolabAccountNumber;
                productMasterModel.Volume = "0";
                productMasterModel.Weight = "0";
                Model.ProductMaster objChemical = Mapper.Map<ProductMasterModel, Model.ProductMaster>(productMasterModel);

                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    this.prodMastService.SavePlantChemicalDetails(objChemical, user.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    response = Push.PushToLocal(objChemical, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddPlantChemical);                    
                }

                switch (response)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
            }
            catch (Exception)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Chemical adding failed.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}