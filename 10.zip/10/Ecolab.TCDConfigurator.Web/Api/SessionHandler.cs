﻿// -----------------------------------------------------------------------
// <copyright file="SessionHandler.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SessionHandler </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Api
{
    using System.Web;
    using System.Web.Http.WebHost;
    using System.Web.Routing;
    using System.Web.SessionState;

    /// <summary>
    /// Class for Handle the Sessions
    /// </summary>
    /// <seealso cref="System.Web.Http.WebHost.HttpControllerHandler" />
    /// <seealso cref="System.Web.SessionState.IRequiresSessionState" />
    public class SessionHandler : HttpControllerHandler, IRequiresSessionState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SessionHandler"/> class.
        /// </summary>
        /// <param name="routeData">The route data.</param>
        public SessionHandler(RouteData routeData) : base(routeData)
        {
        }
    }
}