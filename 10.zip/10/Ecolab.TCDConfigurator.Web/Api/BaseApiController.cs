﻿// -----------------------------------------------------------------------
// <copyright file="BaseApiController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Base API Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
	using System.Globalization;
	using System.Net.Http;
	using System.Threading;
	using System.Threading.Tasks;
	using System.Web;
	using System.Web.Http;
	using System.Web.Http.Controllers;
	using AutoMapper;
	using Models.PlantSetup;
	using Services.Interfaces;
	using ServiceModel = Ecolab.Models;
	using WebModel = Models;
    
	public class BaseApiController : ApiController
    {
        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantService PlantService;

        /// <summary>
        ///     User Service
        /// </summary>
        /// `
        protected readonly IUserService UserService;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        private string ecolabAccountNumber;

        /// <summary>
        ///     exchangeRate
        /// </summary>
        private double exchangeRate;

        /// <summary>
        ///     Logo
        /// </summary>
        private string logo;

        /// <summary>
        ///     Role Id
        /// </summary>
       // private int roleId;

        /// <summary>
        ///     User Id
        /// </summary>
        private int userId;

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        protected BaseApiController(IUserService userService, IPlantService plantService)
        {
            this.UserService = userService;
            this.PlantService = plantService;
            
        }

        /// <summary>
        ///     Gets Ecolab Account Number
        /// </summary>
        protected string EcolabAccountNumber
        {
            get { return this.ecolabAccountNumber ?? (this.ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber); }
        }

        protected string Logo
        {
            get { return this.logo ?? (this.logo = this.GetPlantDetails().Logo); }
        }

        /// <summary>
        ///     Gets Exchange Rate
        /// </summary>
        protected double ExchangeRate
        {
            get { return this.exchangeRate = this.GetExchangeRates(this.GetPlantDetails().CurrencyCode, "USD").Rate; }
        }

        /// <summary>
        ///     Gets User Id
        /// </summary>
        protected int UserId
        {
            get
            {
                this.userId = this.GetUser() != null ? this.GetUser().UserId : 0;
                if (this.userId > 0)
                {
                    return this.userId;
                }
                return this.userId;
            }
        }

        protected int RoleId
        {
            
            get
            {
                int roleId = 9;
                return roleId; // Nedd to chnage once authentication is done
            }
        }

        /// <summary>
        ///     Gets Plant Details
        /// </summary>
        /// <returns>PlantModel</returns>
        protected PlantModel GetPlantDetails()
        {
            //var usr = (ServiceModel.User) HttpContext.Current.Session["Üser"];
            //int userId = usr.UserId;
            ServiceModel.User usr = this.GetUser();
            return Mapper.Map<ServiceModel.Plant, PlantModel>(this.PlantService.GetPlantDetails(usr.UserId, usr.EcolabAccountNumber));
        }

        /// <summary>
        ///     Gets Plant Details
        /// </summary>
        /// <returns>PlantModel</returns>
        protected ServiceModel.User GetUser()
        {
            return (ServiceModel.User)HttpContext.Current.Session["Üser"];
        }

        /// <summary>
        /// Executes asynchronously a single HTTP operation.
        /// </summary>
        /// <returns>
        /// The newly started task.
        /// </returns>
        /// <param name="controllerContext">The controller context for a single HTTP operation.</param>
        /// <param name="cancellationToken">The cancellation token assigned for the HTTP operation.</param>
        public override Task<HttpResponseMessage> ExecuteAsync(HttpControllerContext controllerContext, CancellationToken cancellationToken)
        {
            System.Globalization.CultureInfo[] cultures = System.Globalization.CultureInfo.GetCultures(System.Globalization.CultureTypes.AllCultures);
            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo("en-US");
            
            return base.ExecuteAsync(controllerContext, cancellationToken);
        }

        /// <summary>
        /// Get Currency exchange rates
        /// </summary>
        /// <param name="sourceCurrency">source Currency</param>
        /// <param name="targetCurrency">target Currency</param>
        /// <returns>ExchangeRate Model Object</returns>
        protected Ecolab.TCDConfigurator.Web.Models.ExchangeRate GetExchangeRates(string sourceCurrency, string targetCurrency)
        {
            Ecolab.Models.ExchangeRate rate = this.PlantService.GetExchangeRates(sourceCurrency, targetCurrency);
            if (rate != null)
            {
                return Mapper.Map<ServiceModel.ExchangeRate, WebModel.ExchangeRate>(rate);
            }
            else
            {
                return new WebModel.ExchangeRate();
            }
        }
    }
}