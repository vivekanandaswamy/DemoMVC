﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ProductDeviationController </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.PushHandler;
using Ecolab.Models.Washers;
using Ecolab.Models.Washers.Conventional;
using Ecolab.Services.Interfaces;
using Ecolab.Services.Interfaces.WasherGroup;
using Ecolab.Services.Interfaces.Washers;
using Ecolab.Services.Interfaces.Washers.Conventional;
using Ecolab.TCDConfigurator.Web.Models.Washers;
using Ecolab.TCDConfigurator.Web.Models.Washers.Conventional;

namespace Ecolab.TCDConfigurator.Web.Api.Washers
{
    public class ProductDeviationController : BaseApiController
    {
        /// <summary>
        ///     The Conventional General services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     The Product Deviation Service
        /// </summary>
        private readonly IProductDeviationService productDeviationService;

        /// <summary>
        /// Initializes a new instance of the ProductDeviationController class.
        /// </summary>
        /// <param name="userService">User Service for Product</param>
        /// <param name="plantService">Plant Service for Product</param>
        /// <param name="productDeviationServiceInstance">The ProductDeviation services.</param>
        /// <param name="conventionalServices">The conventional general services.</param>
        /// <param name="washerGroupServiceInstance">The washer group service.</param>
        public ProductDeviationController(IUserService userService, IPlantService plantService, IProductDeviationService productDeviationServiceInstance, IConventionalGeneralServices conventionalServices, IWasherGroupService washerGroupServiceInstance)
            : base(userService, plantService)
        {
            this.productDeviationService = productDeviationServiceInstance;
            this.conventionalGeneralServices = conventionalServices;
            this.washerGroupService = washerGroupServiceInstance;
        }

        /// <summary>
        /// Get all the values related to ProductDeviation Data
        /// </summary>
        /// <param name="machineId">The Machine Id .</param>
        /// <param name="groupId">The Group Id .</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>
        /// Returns the Product Deviation model
        /// </returns>
        [HttpGet]
        public WasherProductDeviationModel GetProductDeviationData(int machineId, int groupId, int controllerId)
        {
            ConventionalGeneralModel conventionaldata = AutoMapper.Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(this.conventionalGeneralServices.GetConventionalData(machineId, groupId, EcolabAccountNumber));
            Models.WasherGroup.WasherGroup washerGroup = AutoMapper.Mapper.Map<Ecolab.Models.WasherGroup.WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(groupId, EcolabAccountNumber, 0, 12, string.Empty).FirstOrDefault());
            WasherProductDeviationModel washerProductDeviationModel = new WasherProductDeviationModel
            {
                MachineId = conventionaldata.Id,
                WasherGroupId = conventionaldata.WasherGroupId,
                WasherGroupNumber = washerGroup.WasherGroupNumber,
                WasherGroupName = washerGroup.WasherGroupName,
                WasherGroupTypeId = washerGroup.WasherGroupTypeId,
                WasherGroupType = washerGroup.WasherGroupTypeName,
                ControllerId = conventionaldata.ControllerId,
                ControllerModelId = conventionaldata.ControllerModelId,
                ControllerTypeId = conventionaldata.ControllerTypeId,
                MachineNumber = conventionaldata.LfsWasher,
                MachineName = conventionaldata.Name,
                ProductDeviationdata = AutoMapper.Mapper.Map<IEnumerable<ProductDeviation>, IEnumerable<ProductDeviationModel>>(this.productDeviationService.GetProductDeviationData(machineId, controllerId, EcolabAccountNumber)).ToList(),
                PumpsAndMECount = AutoMapper.Mapper.Map<PumpsAndMECount, PumpsAndMECountModel>(this.productDeviationService.GetPumpsAndMECount(controllerId, EcolabAccountNumber)),
                WasherDosingNumber = washerGroup.WasherDosingNumber
            };
            return washerProductDeviationModel;
        }

        /// <summary>
        /// Save the Product Deviation Data
        /// </summary>
        /// <param name="washerProductDeviationModel">The washer product deviation model.</param>
        /// <returns>
        /// The result of the save operation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveProductDeviationData(WasherProductDeviationModel washerProductDeviationModel)
        {
            Ecolab.Models.User user = this.GetUser();
            int status = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            IEnumerable<ProductDeviation> productDeviationList = AutoMapper.Mapper.Map<List<ProductDeviationModel>, List<ProductDeviation>>(washerProductDeviationModel.ProductDeviationdata);
            ProductDeviationContainer productDeviationContainer = new ProductDeviationContainer();
            productDeviationContainer.LstProductDeviation = productDeviationList.ToList();
            productDeviationContainer.EcolabAccountNumber = user.EcolabAccountNumber;
			productDeviationContainer.LstProductDeviation.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            productDeviationContainer.MaxNumberOfRecords = productDeviationService.GetMaxNumberOfRecord(productDeviationList.ToList()[0].WasherId, user.EcolabAccountNumber);

            try
            {
                if (isDisconnected )
                {
                    status = productDeviationService.SaveProductDeviationData(productDeviationList, EcolabAccountNumber);
                }
                else
                {
                    int id = 0;
                    status = Push.PushToLocal(productDeviationContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddProductDeviation, out id);
                }
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
            switch (status)
            {
                case 51030:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                case 60000:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                case 51060:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
            }
            if (status == 0)
            {
                return this.Request.CreateResponse(HttpStatusCode.OK, 0);
            }
            return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, -1);
        }
    }
}