﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Conventional Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers.Conventional;
    using Elmah;
    using Models.Washers.Conventional;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers.Conventional;
    using Tunnel;
    using Services.Interfaces.Washers;

    /// <summary>
    ///     Api Controller for Conventional.
    /// </summary>
    public class ConventionalController : BaseApiController
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The _conventional general services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ConventionalController" /> class.
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        /// The injection service
        /// </summary>
        private readonly IInjectionService injectionService;

        /// <summary>
        /// The washer services
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="conventionalGeneralServices">conventional general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupService">The washer Group Service.</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public ConventionalController(IConventionalGeneralServices conventionalGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService, IInjectionService injectionService, IWasherServices washerServices)
            : base(userService, plantService)
        {
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.injectionService = injectionService;
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     Initializes a new instance of the
        ///     <see cref="TunnelController" />
        ///     class.
        /// </summary>
        /// <param name="conventionalGeneralServices">conventional general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupService">The washer Group Service.</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public ConventionalController(IConventionalGeneralServices conventionalGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IPlcService plcService, IUserService userService, IPlantService plantService, IInjectionService injectionService)
            : base(userService, plantService)
        {
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
            this.injectionService = injectionService;
        }

        /// <summary>
        ///     Gets the drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="washerGroupId">The washerGroup identifier.</param>
        /// <param name="washerType">Type of the washer.</param>
        /// <returns>ConventionalGeneralDropDownModel.</returns>
        [HttpGet]
        public ConventionalGeneralDropDownModel GetDropDownData(string ecoLabAccountNumber, int regionId, int washerGroupId, string washerType)
        {
            ConventionalGeneralDropDownModel conventionalGeneralDropdownsModel = new ConventionalGeneralDropDownModel();
            IEnumerable<WasherModelList> objList = this.conventionalGeneralServices.GetWashersModelList(washerType, regionId);
            IEnumerable<WasherModelListModel> washerModelList = Mapper.Map<IEnumerable<WasherModelList>, List<WasherModelListModel>>(objList);
            conventionalGeneralDropdownsModel.WashersModelList = washerModelList;
            IEnumerable<Ecolab.Models.ControllerSetup.Controller> controllerList = controllerSetupService.GetControllerDetails(
                 ecoLabAccountNumber, false)
                 .Where(c => !string.IsNullOrEmpty(c.ControllerName));
            controllerList = controllerList.Where(c => c.WasherExtractorCount > 0);

            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);
            IEnumerable<WasherGroup> washerGroupListObj = washerGroupService.GetWasherGroupDetails(-1, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Ecolab.Models.Washers.Washers> washerList = washerServices.GetWashersDetails(ecoLabAccountNumber, washerGroupId, false);

            if (washerGroups.FirstOrDefault() != null && washerGroups.FirstOrDefault().ControllerId > 0)
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId > 6 || c.ControllerModelId != 12 || c.ControllerModelId != 13);
            }
            else if (washerGroups.FirstOrDefault() != null && washerGroups.FirstOrDefault().WasherCount > 0 && washerList.FirstOrDefault().WasherControllerId != 0)
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId == 12 || c.ControllerModelId == 13 || c.ControllerModelId < 7);
            }
            else
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId == 12 || c.ControllerModelId == 13 || c.ControllerModelId < 8);
            }

            conventionalGeneralDropdownsModel.WasherGroupList = washerGroups;
            conventionalGeneralDropdownsModel.WasherGroupListForDropDown = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupListObj);

            conventionalGeneralDropdownsModel.WasherGroupListForDropDown = conventionalGeneralDropdownsModel.WasherGroupListForDropDown.Where(item => item.WasherGroupTypeId == 1);

            return conventionalGeneralDropdownsModel;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="washerModelName">The washer model Name.</param>
        /// <param name="regionId">The Region Id</param>
        /// <param name="washerType">The Washer Type</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.WasherModelSizeModel.</returns>
        public IEnumerable<WasherModelSizeModel> GetSizeList(string washerModelName, int regionId, string washerType)
        {
            IEnumerable<WasherModelSize> objList = this.conventionalGeneralServices.GetWashersModelSizeList(washerModelName, regionId, washerType);
            IEnumerable<WasherModelSizeModel> washerModelSizeList = Mapper.Map<IEnumerable<WasherModelSize>, IEnumerable<WasherModelSizeModel>>(objList);
            return washerModelSizeList;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.LfsWasherNumberModel.</returns>
        public LfsWasherNumberModel GetLfsWasherList(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                LfsWasherNumber objList = this.conventionalGeneralServices.GetLfsWasherList(controllerId.Value, ecoLabAccountNumber);
                LfsWasherNumberModel lfsWasherList = Mapper.Map<LfsWasherNumber, LfsWasherNumberModel>(objList);
                return lfsWasherList;
            }
            else
            {
                return new LfsWasherNumberModel();
            }
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel.</returns>
        public List<WasherModeListModel> GetWasherModeList(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                IEnumerable<WasherModeList> objWasherMode = this.conventionalGeneralServices.GetWasherModeList(ecoLabAccountNumber, controllerId.Value);
                List<WasherModeListModel> washerModeList = Mapper.Map<IEnumerable<WasherModeList>, IEnumerable<WasherModeListModel>>(objWasherMode).ToList();
                return washerModeList;
            }
            else
            {
                return new List<WasherModeListModel>();
            }
        }

        /// <summary>
        ///     Saves the Conventional data.
        /// </summary>
        /// <param name="conventionalData">The Conventional data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        public HttpResponseMessage SaveConventionalData(ConventionalGeneralModel conventionalData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            //conventionalData.ConventionalWasherTagList = null;

            //int status = 0;
            try
            {
                //if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupIdNew != conventionalData.WasherGroupId)
                //{
                //	status = this.conventionalGeneralServices.CheckControllerValidForWasherGroup(conventionalData.ControllerId, conventionalData.WasherGroupIdNew, conventionalData.EcolabAccountNumber);
                //}
                //else
                //{
                //	status = this.conventionalGeneralServices.CheckControllerValidForWasherGroup(conventionalData.ControllerId, conventionalData.WasherGroupId, conventionalData.EcolabAccountNumber);
                //}

                //if (status > 0)
                //{
                //	return Request.CreateResponse(HttpStatusCode.BadRequest, "51011");
                //}
                string result = string.Empty;
                int isNumeric;
                if (conventionalData.ControllerModelId > 7)
                {
                    conventionalData.EndOfFormula = 0;
                    conventionalData.HoldSignal = false;
                    conventionalData.HoldDelay = 0;
                    conventionalData.WaterFlushTime = 0;
                    conventionalData.RatioDosingActive = false;
                }
                conventionalData.EcolabAccountNumber = user.EcolabAccountNumber;
                conventionalData.MaxNumberOfRecords =
                    this.conventionalGeneralServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                ConventionalGeneral objConventionalData =
                    Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                objConventionalData.MyServiceCustMchGuid = Guid.NewGuid();
                objConventionalData.LastModifiedTimeStamp =
                    DateTime.SpecifyKind(objConventionalData.LastModifiedTimeStamp, DateTimeKind.Utc);

                if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupId != conventionalData.WasherGroupIdNew)
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, true);
                }
                else
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, false);
                }

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;

                        result = this.conventionalGeneralServices.SaveConventionalData(objConventionalData,
                            user.UserId, conventionalData.Role, out lastModifiedTimeStamp);
                        objConventionalData.Id = Convert.ToInt32(result);

                        bool saveInEnvision = Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInEnvision"]);

                        if (saveInEnvision)
                        {
                            this.conventionalGeneralServices.SaveControllerSystemInEnvisionFromMyService(objConventionalData);
                        }
                    }
                    else
                    {
                        int id;
                        result = Push.PushToLocal(objConventionalData, user.EcolabAccountNumber, user.UserId,
                                (int)TcdAdminMessageTypes.TcdAddConventionaGeneral, out id).ToString();

                        if (Convert.ToInt32(result) == 0)
                        {
                            result = Convert.ToString(id);
                        }
                    }
                    switch (Convert.ToInt32(result))
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                        case 51001:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51001");
                        case 51002:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51002");
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                        case 51003:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51003");
                        case 51004:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51004");
                        case 51005:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51005");
                        case 51010:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51010");
                        case 51011:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51011");
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");

                    }
                }
                if (int.TryParse(result, out isNumeric))
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, result);
                }

                return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
            }
            catch (SqlException sqlex)
            {
                if (conventionalData.ControllerId > 0)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, Int32.Parse(Regex.Match(sqlex.Message, @"\d+").Value));
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, "PhonyWasher");
                }
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Updates the Conventional data.
        /// </summary>
        /// <param name="conventionalData">The Conventional data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateConventionalData(ConventionalGeneralModel conventionalData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            conventionalData.ConventionalWasherTagList = null;
            //int status = 0;
            try
            {
                //if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupIdNew != conventionalData.WasherGroupId)
                //{
                //	status = this.conventionalGeneralServices.CheckControllerValidForWasherGroup(conventionalData.ControllerId, conventionalData.WasherGroupIdNew, conventionalData.EcolabAccountNumber);
                //}
                //else
                //{
                //	status = this.conventionalGeneralServices.CheckControllerValidForWasherGroup(conventionalData.ControllerId, conventionalData.WasherGroupId, conventionalData.EcolabAccountNumber);
                //}

                //if (status > 0)
                //{
                //	return Request.CreateResponse(HttpStatusCode.BadRequest, "51011");
                //}
                string result = string.Empty;
                if (conventionalData.ControllerModelId == 7)
                {
                    conventionalData.EndOfFormula = 0;
                    conventionalData.HoldSignal = false;
                    conventionalData.HoldDelay = 0;
                    conventionalData.WaterFlushTime = 0;
                    conventionalData.RatioDosingActive = false;
                }
                conventionalData.EcolabAccountNumber = user.EcolabAccountNumber;
                conventionalData.MaxNumberOfRecords = this.conventionalGeneralServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                ConventionalGeneral objConventionalData = Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                objConventionalData.LastModifiedTimeStamp = DateTime.SpecifyKind(objConventionalData.LastModifiedTimeStamp, DateTimeKind.Utc);
                objConventionalData.ConventionalWasherTagList = null;
                if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupId != conventionalData.WasherGroupIdNew)
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, true);
                }
                else
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, false);
                }

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;

                        result = this.conventionalGeneralServices.UpdateConventionalData(objConventionalData, user.UserId, conventionalData.Role, out lastModifiedTimeStamp);
                        objConventionalData.Id = Convert.ToInt32(result);

                        bool saveInEnvision = Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInEnvision"]);

                        if (saveInEnvision)
                        {
                            this.conventionalGeneralServices.SaveControllerSystemInEnvisionFromMyService(objConventionalData);
                        }
                    }
                    else
                    {
                        int id;
                        result = Push.PushToLocal(objConventionalData, user.EcolabAccountNumber, user.UserId,
                                (int)TcdAdminMessageTypes.TcdUpdateConventionaGeneral, out id).ToString();

                        if (Convert.ToInt32(result) == 0)
                        {
                            result = Convert.ToString(id);
                        }

                    }
                    switch (Convert.ToInt32(result))
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");

                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");

                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                    }

                    int isNumeric;
                    if (int.TryParse(result, out isNumeric))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.OK, result);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, Int32.Parse(Regex.Match(sqlex.Message, @"\d+").Value));
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Gets the tunnel data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>Ecolab.ConduitLocal.Web.Models.Washers.Conventional.ConventionalGeneralModel.</returns>
        [HttpGet]
        public ConventionalGeneralModel GetConventionalData(int id, int washerGroupId, string ecoLabAccountNumber, int regionId)
        {
            User user = this.GetUser();
            ConventionalGeneral objList = this.conventionalGeneralServices.GetConventionalData(id, washerGroupId, ecoLabAccountNumber);
            if (objList != null && objList.Id > 0)
            {
                objList.ConventionalWasherTagList = this.conventionalGeneralServices.GetConventionalWasherTags(objList.Id, user.EcolabAccountNumber);
            }
            ConventionalGeneralModel conventionaldata = Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(objList);
            if (!conventionaldata.ConventionalWasherTagList.Any())
            {
                conventionaldata.ConventionalWasherTagList = null;
            }
            if (conventionaldata.ConventionalWasherTagList != null)
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                TagCollection tagStatus = new TagCollection();

                var tagModel = conventionaldata.ConventionalWasherTagList.FirstOrDefault();

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.EndOfFormulaTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.EndOfFormulaTag,
                        Value = conventionaldata.EndOfFormula.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WasherModeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WasherModeTag,
                        Value = conventionaldata.WasherModeId.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.HoldDelayTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.HoldDelayTag,
                        Value = conventionaldata.HoldDelay.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WaterFlushTimeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WaterFlushTimeTag,
                        Value = conventionaldata.WaterFlushTime.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.RatioDosingActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.RatioDosingActiveTag,
                        Value = conventionaldata.RatioDosingActive.ToString(CultureInfo.CurrentCulture)
                    });
                }
                if (tagsList.Count > 0)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                }
            }
            return conventionaldata;
        }

        /// <summary>
        ///     Gets the maximum washer number
        /// </summary>
        /// <returns>returns the integer.</returns>
        [HttpGet]
        public int GetMaxPlantWasherNumber(string ecoLabAccountNumber)
        {
            int MaxWasherNumber = conventionalGeneralServices.GetMaxPlantWasherNumber(ecoLabAccountNumber);
            return MaxWasherNumber;
        }
    }
}