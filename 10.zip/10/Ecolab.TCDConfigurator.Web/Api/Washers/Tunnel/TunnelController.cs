﻿// -----------------------------------------------------------------------
// <copyright file="TunnelController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Tunnel Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Dcs.Entities;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers.Tunnel;
    using Elmah;
    using Helper;
    using Models.Washers.Conventional;
    using Models.Washers.Tunnel;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers.Tunnel;
    using ApplicationException = System.ApplicationException;

    /// <summary>
    ///     Tunnel Controller
    /// </summary>
    public class TunnelController : BaseApiController
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        private readonly ITunnelCompartmentServices tunnelCompartmentServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
        ///     The _washer group formula service
        /// </summary>
        private readonly IWasherGroupFormulaService washerGroupFormulaService;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     The _tunnel Connection services
        /// </summary>
        private readonly ITunnelConnectionServices tunnelConnectionServices;
        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly ITunnelAnalogueDosingControlServices analogueDosingControlServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
        /// <param name="tunnelCompartmentServices">Tunnel Compartment Services</param>
        /// <param name="washerGroupService">Washer Group Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public TunnelController(ITunnelGeneralServices tunnelGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupFormulaService washerGroupFormulaService, ITunnelCompartmentServices tunnelCompartmentServices, IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService, ITunnelConnectionServices tunnelConnectionServices)
            : base(userService, plantService)
        {
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.tunnelCompartmentServices = tunnelCompartmentServices;
            this.washerGroupService = washerGroupService;
            this.tunnelConnectionServices = tunnelConnectionServices;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
        /// <param name="tunnelCompartmentServices">Tunnel Compartment Services</param>
        /// <param name="washerGroupService">Washer Group Service</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
		public TunnelController(ITunnelGeneralServices tunnelGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupFormulaService washerGroupFormulaService, ITunnelCompartmentServices tunnelCompartmentServices, IWasherGroupService washerGroupService, IPlcService plcService, IUserService userService, IPlantService plantService, ITunnelConnectionServices tunnelConnectionServices, ITunnelAnalogueDosingControlServices analogueDosingControlService)
            : base(userService, plantService)
        {
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.tunnelCompartmentServices = tunnelCompartmentServices;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
            this.tunnelConnectionServices = tunnelConnectionServices;
            this.analogueDosingControlServices = analogueDosingControlService;
        }

        /// <summary>
        ///     Gets the drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="washerType">Type of the washer.</param>
        /// <param name="washerGroupId">The washer Group Id</param>
        /// <returns>
        ///     TunnelGeneralDropdownsModel.
        /// </returns>
        [HttpGet]
        public TunnelGeneralDropdownsModel GetDropDownData(string ecoLabAccountNumber, int regionId, string washerType, int washerGroupId)
        {
            TunnelGeneralDropdownsModel tunnelGeneralDropdownsModel = new TunnelGeneralDropdownsModel();
            IEnumerable<WashersList> objList = this.tunnelGeneralServices.GetWashersList(washerType, regionId);
            IEnumerable<WashersListModel> washerModelList = Mapper.Map<IEnumerable<WashersList>, List<WashersListModel>>(objList);
            tunnelGeneralDropdownsModel.WashersModelList = washerModelList;

            IEnumerable<PressExtractor> objPressExtractorList = this.tunnelGeneralServices.GetPressExtractorList(this.EcolabAccountNumber);
            IEnumerable<PressExtractorModel> pressExtractorList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objPressExtractorList);
            tunnelGeneralDropdownsModel.PressExtractorList = pressExtractorList;

            IEnumerable<PressExtractor> objTransferTypeList = this.tunnelGeneralServices.GetTransferTypeList(this.EcolabAccountNumber);
            IEnumerable<PressExtractorModel> transferTypeList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objTransferTypeList);
            tunnelGeneralDropdownsModel.TransferTypeList = transferTypeList;
            tunnelGeneralDropdownsModel.ControllerList = this.tunnelGeneralServices.GetControllerDetailsforTunnel(ecoLabAccountNumber, washerGroupId);

            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

            tunnelGeneralDropdownsModel.WasherGroupList = washerGroups;

            return tunnelGeneralDropdownsModel;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="washerModelId">The washer model identifier.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.WasherModelSizeModel.</returns>
        public IEnumerable<WasherModelSizeModel> GetSizeList(int washerModelId)
        {
            IEnumerable<WasherModelSize> objList = this.tunnelGeneralServices.GetWashersModelSizeList(washerModelId);
            IEnumerable<WasherModelSizeModel> washerModelSizeList = Mapper.Map<IEnumerable<WasherModelSize>, IEnumerable<WasherModelSizeModel>>(objList);
            return washerModelSizeList;
        }

        /// <summary>
        ///     Saves the tunnel data.
        /// </summary>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        public HttpResponseMessage SaveTunnelData(TunnelGeneralModel tunnelData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {
                string result = string.Empty;
                int isNumeric = 0;

                tunnelData.EcolabAccountNumber = user.EcolabAccountNumber;
                tunnelData.MaxNumberOfRecords = this.tunnelGeneralServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                TunnelGeneral objTunnelData = Mapper.Map<TunnelGeneralModel, TunnelGeneral>(tunnelData);
                objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(objTunnelData.LastModifiedTimeStamp, DateTimeKind.Utc);
                objTunnelData.MyServiceWashersGuid = Guid.NewGuid();
                //objTunnelData.TunnelTags = null;
                //objTunnelData.TunnelTagsList = null;

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.tunnelGeneralServices.SaveTunnelData(objTunnelData, user.UserId, out lastModifiedTimeStamp);
                        objTunnelData.Id = Convert.ToInt32(result);

                        bool saveInEnvision = Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInEnvision"]);

                        if (saveInEnvision)
                        {
                            this.tunnelGeneralServices.SaveControllerSystemInEnvision(objTunnelData);
                        }
                    }
                    else
                    {
                        result = Push.PushToLocal(objTunnelData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddTunnelGeneral, out isNumeric).ToString();
                    }
                    switch (Convert.ToInt32(result))
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51001:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51001);

                        case 51008:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51008);

                        case 51002:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51002);

                        case 51003:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51003);

                        case 51004:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51004);

                        case 51005:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51005);
                        case 51010:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51010);
                        case 0:
                            result = isNumeric.ToString();
                            break;
                    }
                }
                if (int.TryParse(result, out isNumeric))
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, result);
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5));
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Saves the tunnel compartment data.
        /// </summary>
        /// <param name="tunnelCompartmentData">The tunnel compartment data.</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage SaveTunnelCompartmentData(TunnelCompartmentModel tunnelCompartmentData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int id = 0;

            tunnelCompartmentData.MaxNumberOfRecords = this.tunnelCompartmentServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            tunnelCompartmentData.EcolabAccountNumber = user.EcolabAccountNumber;

            TunnelCompartment objTunnelData = Mapper.Map<TunnelCompartmentModel, TunnelCompartment>(tunnelCompartmentData);
            objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(objTunnelData.LastModifiedTimeStamp, DateTimeKind.Utc);
            try
            {
                if (user != null)
                {
                    int result;
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.tunnelCompartmentServices.SavetunnelCompartmentData(objTunnelData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        result = Push.PushToLocal(objTunnelData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdSaveTunnnelCompartment, out id);
                        objTunnelData.TunnelCompartmentId = id;

                    }

                    tunnelCompartmentData = Mapper.Map<TunnelCompartment, TunnelCompartmentModel>(objTunnelData);

                    switch (result)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, tunnelCompartmentData);
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5));
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Updates the tunnel data.
        /// </summary>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateTunnelData(TunnelGeneralModel tunnelData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {
                string result = string.Empty;
                int isNumeric;

                tunnelData.EcolabAccountNumber = user.EcolabAccountNumber;
                tunnelData.MaxNumberOfRecords = this.tunnelGeneralServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                TunnelGeneral objTunnelData = Mapper.Map<TunnelGeneralModel, TunnelGeneral>(tunnelData);
                objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(objTunnelData.LastModifiedTimeStamp, DateTimeKind.Utc);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.tunnelGeneralServices.UpdateTunnelData(objTunnelData, user.UserId, out lastModifiedTimeStamp);
                        objTunnelData.Id = Convert.ToInt32(result);

                        bool saveInEnvision = Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInEnvision"]);

                        if (saveInEnvision)
                        {
                            this.tunnelGeneralServices.SaveControllerSystemInEnvision(objTunnelData);
                        }
                    }
                    else
                    {
                        result = Push.PushToLocal(objTunnelData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateTunnelGeneral).ToString();
                    }
                }

                int response = int.Parse(result);
                switch (response)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                    case 60000:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                    case 51060:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                    case 51001:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51001);

                    case 51008:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51008);

                    case 51002:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51002);

                    case 51003:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51003);

                    case 51004:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51004);

                    case 51005:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51005);
                }
                if (int.TryParse(result, out isNumeric))
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, result);
                }

                return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5));
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Gets the tunnel data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <returns>
        ///     Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.TunnelGeneralModel.
        /// </returns>
        [HttpGet]
        public TunnelGeneralModel GetTunnelData(int id, int washerGroupId, string ecoLabAccountNumber)
        {
            TunnelGeneral objList = this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber);
            if (objList != null && objList.Id > 0)
            {
                objList.TunnelTagsList = this.tunnelGeneralServices.GetTunnelWasherTags(objList.Id, ecoLabAccountNumber);
                objList.TunnelTags = objList.TunnelTagsList.FirstOrDefault();
            }
            TunnelGeneralModel tunneldata = Mapper.Map<TunnelGeneral, TunnelGeneralModel>(objList);
            if (tunneldata.TunnelTagsList != null)
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                TagCollection tagStatus = new TagCollection();
                var tagModel = tunneldata.TunnelTagsList.FirstOrDefault();

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WasherModeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WasherModeTag,
                        Value = tunneldata.WasherMode.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.AutoWeightEntryActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.AutoWeightEntryActiveTag,
                        Value = tunneldata.AweActive.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.RatioDosingActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.RatioDosingActiveTag,
                        Value = tunneldata.RatioDosingActive.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.EndOfFormulaTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.EndOfFormulaTag,
                        Value = tunneldata.EndOfFormula.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagsList.Count > 0)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                }
            }

            return tunneldata;
        }

        /// <summary>
        ///     Gets the compartment data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="compartmentNumber">The compartment number.</param>
        /// <returns>Tunnel Compartment Data</returns>
        [HttpGet]
        public TunnelCompartmentModel GetCompartmentData(int id, int washerGroupId, string ecoLabAccountNumber, byte compartmentNumber, int regionId, int controllerId)
        {
            TunnelCompartment objList = this.tunnelCompartmentServices.GetCompartmentData(id, washerGroupId, ecoLabAccountNumber, compartmentNumber, false);
            TunnelCompartmentModel tunneldata = Mapper.Map<TunnelCompartment, TunnelCompartmentModel>(objList);
            tunneldata.CompartmentNumber = compartmentNumber;
            tunneldata.TunnelDropDowns = this.GetCompartmentDropDownData(ecoLabAccountNumber, regionId, controllerId, id, washerGroupId);
            TunnelGeneralModel tunnelGendata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
            tunneldata.MachineNumber = tunnelGendata.LfsWasher;
            return tunneldata;
        }

        /// <summary>
        ///     Gets the compartment drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="tunnelId">The tunnel identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>
        ///     Returns Tunnel Conventional Drop Down Model
        /// </returns>
        [HttpGet]
        public TunnelConventionalDropDownModel GetCompartmentDropDownData(string ecoLabAccountNumber, int regionId, int controllerId, int tunnelId, int washerGroupId)
        {
            TunnelConventionalDropDownModel objTunnelConventionalDropDownModel = new TunnelConventionalDropDownModel();

            IEnumerable<PressExtractor> objWaterInletDrainList = this.tunnelCompartmentServices.GetWaterInletDrainList(ecoLabAccountNumber);
            IEnumerable<PressExtractorModel> waterInletDrainList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objWaterInletDrainList);
            objTunnelConventionalDropDownModel.WaterInletDrainList = waterInletDrainList;

            IEnumerable<PressExtractor> objWaterFlowList = this.tunnelCompartmentServices.GetWaterFlowList(regionId);
            IEnumerable<PressExtractorModel> waterFlowList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objWaterFlowList);
            objTunnelConventionalDropDownModel.WaterFlowList = waterFlowList;

            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            objTunnelConventionalDropDownModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();

            IEnumerable<PumpAssociation> objPumpsProductsList = this.tunnelCompartmentServices.PumpsProductsList(ecoLabAccountNumber, controllerId, tunnelId);
            IEnumerable<PumpAssociationModel> pumpsProductsList = Mapper.Map<IEnumerable<PumpAssociation>, IEnumerable<PumpAssociationModel>>(objPumpsProductsList);
            objTunnelConventionalDropDownModel.PumpsProductList = pumpsProductsList;

            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

            objTunnelConventionalDropDownModel.WasherGroupList = washerGroups;

            return objTunnelConventionalDropDownModel;
        }
        /// <summary>
        /// Fetches the Tunnel Compartment Data
        /// </summary>
        /// <returns>List of the Connections Data and WasherGroup Info  for a particular Tunnel</returns>
        [HttpGet]
        public IDictionary<string, object> FetchTunnelConnectionsData(int id, int washerGroupId, string ecoLabAccountNumber, int compartmentNumber, int regionId, int controllerId)
        {
            IDictionary<string, object> data = new Dictionary<string, object>();
            IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections> lstconn = this.tunnelConnectionServices.FetchTunnelConnections(id, controllerId, ecoLabAccountNumber);
            data.Add("List", lstconn);
            data.Add("WasherGroupInfo", AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty).FirstOrDefault()));
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
            data.Add("WasherName", tunneldata.Name);
            data.Add("MachineNumber", tunneldata.LfsWasher);
            return data;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel.</returns>
        public List<Ecolab.TCDConfigurator.Web.Models.Washers.Conventional.WasherModeListModel> GetWasherModes(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                var objWasherMode = tunnelGeneralServices.GetWasherModes(ecoLabAccountNumber, controllerId.Value);
                var washerModeList =
                    Mapper.Map<IEnumerable<Ecolab.Models.Washers.Conventional.WasherModeList>, IEnumerable<Ecolab.TCDConfigurator.Web.Models.Washers.Conventional.WasherModeListModel>>(objWasherMode).ToList();
                return washerModeList;
            }
            else
            {
                return new List<WasherModeListModel>();
            }
        }

        /// <summary>
        /// Fetches the Analogue Dosing Data
        /// </summary>
        /// <param name="id">The WasherId</param>
        /// <param name="washerGroupId">The WasherGroupId</param>
        /// <param name="ecoLabAccountNumber">The EcolabAccount Number</param>
        /// <param name="compartmentNumber">The CompartmentNumber</param>
        /// <param name="regionId">The region Id</param>
        /// <param name="controllerId">The controllerId</param>
        /// <returns></returns>
        [HttpGet]
        public IDictionary<string, object> FetchAnalogueDosingData(int id, int washerGroupId, string ecoLabAccountNumber, int compartmentNumber, int regionId, int controllerId)
        {
            IDictionary<string, object> data = new Dictionary<string, object>();
            List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstAnalogDosing = analogueDosingControlServices.FetchAnalogueDosingDataForMachineId(id, this.EcolabAccountNumber);
            List<Models.Washers.Tunnel.AnalogueDosing> lstconn = Mapper.Map<List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>, List<Models.Washers.Tunnel.AnalogueDosing>>(lstAnalogDosing);
            data.Add("List", lstconn);
            data.Add("WasherGroupInfo", AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty).FirstOrDefault()));
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
            data.Add("WasherName", tunneldata.Name);
            data.Add("MachineNumber", tunneldata.LfsWasher);
            return data;
        }

        /// <summary>
        /// Saves the Analogue Dosing data
        /// </summary>
        /// <param name="lstData">Analogue Dosing data List</param>
        /// <returns>True for saved and False for not saved</returns>
        [HttpPost]
        public HttpResponseMessage SaveAnalogueDosingData(List<Models.Washers.Tunnel.AnalogueDosing> lstData)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int response = 0;
            try
            {
                lstData.ForEach(t => t.MaxNumberOfRecords = this.analogueDosingControlServices.GetMaxNumOfRecordsTunnelAnalogueDosing(user.EcolabAccountNumber));
                lstData.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
                lstData.ForEach(t => t.EcolabAccountNumber = this.EcolabAccountNumber);
                List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstSaveData = Mapper.Map<List<Models.Washers.Tunnel.AnalogueDosing>, List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>>(lstData);
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        response = Convert.ToInt32(this.analogueDosingControlServices.SaveAnalogueDosingData(lstSaveData, this.EcolabAccountNumber, user.UserId));
                    }
                    else
                    {
                        TunnelAnalogueDosingControlContainer analogueDosingContainer = new TunnelAnalogueDosingControlContainer();
                        analogueDosingContainer.AnalogueDosingControlList = lstSaveData;
                        response = Push.PushToLocal(analogueDosingContainer, this.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddTunnelAnalogueDosingControl);
                    }
                    switch (response)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");

                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
                }

            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, 0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tunnelId"></param>
        /// <param name="washerGroupId"></param>
        /// <param name="ecoLabAccountNumber"></param>
        /// <returns></returns>
        [HttpGet]
        public List<TunnelCompartmentModel> GetCompartmentCount(int tunnelId, int washerGroupId, string ecoLabAccountNumber)
        {
            List<TunnelCompartment> objList = this.tunnelCompartmentServices.getCompartmentCount(tunnelId, washerGroupId, ecoLabAccountNumber);
            return Mapper.Map<List<TunnelCompartment>, List<TunnelCompartmentModel>>(objList);
        }

        /// <summary>
        /// the move pump method
        /// </summary>
        /// <param name="moveCompartmentData">the compartment data</param>
        /// <returns>success/failure</returns>
        public HttpResponseMessage MovePump(TunnelCompartmentModel moveCompartmentData)
        {
            try
            {
                User user = this.GetUser();
                int userId = user.UserId;
                int result = 0;
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                TunnelCompartment objTunnelData = Mapper.Map<TunnelCompartmentModel, TunnelCompartment>(moveCompartmentData);
                objTunnelData.MaxNumberOfRecords = this.tunnelCompartmentServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(objTunnelData.LastModifiedTimeStamp, DateTimeKind.Utc);
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        result = this.tunnelCompartmentServices.MovePump(objTunnelData, userId, out lastModifiedTimeStamp);
                        objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    }
                    else
                    {
                        result = Push.PushToLocal(objTunnelData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdMovePump);
                    }
                }
                if (result == 51034 || result == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, moveCompartmentData);
                }
                else if (result == 51060)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                }
                else if (result == 51030)
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                else if (result == 60000)
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, moveCompartmentData);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }
    }
}