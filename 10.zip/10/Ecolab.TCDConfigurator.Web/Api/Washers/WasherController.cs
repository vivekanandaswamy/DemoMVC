﻿// -----------------------------------------------------------------------
// <copyright file="WasherController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Washer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.Washers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
	using System.Security.Principal;
	using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers;
    using Ecolab.Models.Washers.Conventional;
    using Ecolab.Models.Washers.Tunnel;
	using Ecolab.Services;
    using Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Conventional;
    using Services.Interfaces.Washers.Tunnel;

    /// <summary>
    ///     Class WasherController.
    /// </summary>
    public class WasherController : BaseApiController
    {
        /// <summary>
        ///     The _conventional general services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        ///     The tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormulaController" /> class.
        /// </summary>
        /// <param name="_washerServices">The _washer services.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        /// <param name="conventionalGeneralServices">The conventional general services.</param>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        public WasherController(IWasherServices _washerServices, IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService, IConventionalGeneralServices conventionalGeneralServices, ITunnelGeneralServices tunnelGeneralServices) : base(userService, plantService)
        {
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.washerServices = _washerServices;
            this.washerGroupService = washerGroupService;
            this.tunnelGeneralServices = tunnelGeneralServices;
        }

        /// <summary>
        /// Get all the values related to washers
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <returns>
        /// Returns the washers model
        /// </returns>
        [HttpGet]
        public IEnumerable<WashersModel> GetWashersDetails(string ecolabAccountNumber)
        {
            IEnumerable<Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Washers>, IEnumerable<WashersModel>>(washersModel);
            return washers.ToList().OrderBy(x => x.WasherNumber);
        }

        /// <summary>
        /// Deletes the washers.
        /// </summary>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="isTunnel">if set to <c>true</c> [is tunnel].</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>
        /// The string value the deletion is passed or failed.
        /// </returns>
        [HttpGet]
        public bool WasherDelete(int washerId, bool isTunnel, string ecolabAccountNumber, int washerGroupId)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            Washers washer = new Washers { Id = washerId, WasherTypeFlag = isTunnel, EcolabAccountNumber = ecolabAccountNumber, WasherGroupId = washerGroupId };

            washer.EcolabAccountNumber = user.EcolabAccountNumber;
            bool result = true;

            try
            {
                if(user != null)
                {
                    if(isTunnel)
                    {
                        TunnelGeneral tunnelGeneral = this.tunnelGeneralServices.GetTunnelData(washerId, washerGroupId, ecolabAccountNumber);
                        washer.MaxNumberOfRecords = this.tunnelGeneralServices.GetMaxNumberOfRecords(ecolabAccountNumber);
                        washer.LastModifiedTimeStamp = tunnelGeneral.LastModifiedTimeStamp;
                        washer.LastModifiedTimeStamp = DateTime.SpecifyKind(washer.LastModifiedTimeStamp, DateTimeKind.Utc);

                        if(isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            this.washerServices.DeleteWasher(isTunnel, washerId, ecolabAccountNumber, user.UserId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            result = Convert.ToBoolean(Push.PushToLocal(washer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteTunnelGeneral));
                        }

                        return true;
                    }
                    else
                    {
                        ConventionalGeneral conventionalGeneral = this.conventionalGeneralServices.GetConventionalData(washerId, washerGroupId, ecolabAccountNumber);
                        washer.LastModifiedTimeStamp = conventionalGeneral.LastModifiedTimeStamp;
                        washer.LastModifiedTimeStamp = DateTime.SpecifyKind(washer.LastModifiedTimeStamp, DateTimeKind.Utc);

                        washer.MaxNumberOfRecords = this.conventionalGeneralServices.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            this.washerServices.DeleteConventional(washerId, ecolabAccountNumber, user.UserId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            result = Convert.ToBoolean(Push.PushToLocal(washer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteConventionaGeneral));
                        }
                    }
                   
                    switch (Convert.ToInt32(result))
                    {
                        case 51030:
                            return false;
                        case 60000:
                            return false;
                        case 51060:
                            return false;
                    }
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Get AlarmSetup Details.
        /// </summary>
        /// <param name="controllerModelId">The controllerModelId</param>
        /// <param name="controllerTypeId">The controllerTypeId</param>
        /// <param name="machineNumber">The machineNumber</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        /// <param name="tunnelId">The tunnel identifier.</param>
        /// <param name="isBatchEjectCondition">if set to <c>true</c> [is batch eject condition].</param>
        /// <returns>
        /// Returns alarm list
        /// </returns>
        [HttpGet]
		public AlarmsData GetAlarmSetupDetails(int controllerModelId, int controllerTypeId, int machineNumber, int washerGroupId, string ecoLabAccountNumber, int washerGroupTypeId, int tunnelId, bool isBatchEjectCondition)
        {
			User user = this.GetUser();
			int userId = user.UserId;
			AlarmsData alarmsData = new AlarmsData();
			IEnumerable<Alarms> alarmsModel = new List<Alarms>();
			if(isBatchEjectCondition)
			{
				alarmsModel = this.washerServices.FetchBatchEjectConditions(controllerModelId, tunnelId, ecoLabAccountNumber, userId);
			}
			else
			{
				alarmsModel = this.washerServices.GetAlarmSetupDetails(controllerModelId, controllerTypeId, machineNumber, ecoLabAccountNumber, washerGroupTypeId, tunnelId);
			}
			if(alarmsModel.ToList().Count > 0)
			{
				alarmsData.LastModifiedTimeStamp = alarmsModel.ToList().Where(obj => obj.Active).DefaultIfEmpty(new Alarms() { LastModifiedTimeStamp = null }).FirstOrDefault().LastModifiedTimeStamp;
			}
			IEnumerable<AlarmsModel> alarms = Mapper.Map<IEnumerable<Alarms>, IEnumerable<AlarmsModel>>(alarmsModel);
			alarmsData.AlarmsModel = alarms;
			IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
			IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);
			alarmsData.WasherGroupList = washerGroups;
			return alarmsData;
        }

        /// <summary>
        /// Save the Alarm Data
        /// </summary>
        /// <param name="alarmData">Object of alarmData.</param>
        /// <returns>
        /// The result of the save operation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveAlarmStatus(AlarmsModel alarmData)
        {
            int result = 0;
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            alarmData.EcolabAccountNumber = user.EcolabAccountNumber;

            Alarms alarm = Mapper.Map<AlarmsModel, Alarms>(alarmData);
            alarm.MaxNumberOfRecords = this.washerServices.GetMaxNumberOfRecordsForAlarms(alarm, user.EcolabAccountNumber);
			alarm.LastModifiedTimeStamp = alarmData.IsBatchEjectCondition ? DateTime.UtcNow : alarm.LastModifiedTimeStamp;
            if(user != null)
            {
                if(isDisconnected)
                {
					if(alarmData.IsBatchEjectCondition)
					{						
						result = this.washerServices.SaveBatchEjectConditionStatus(alarm, user.UserId, user.EcolabAccountNumber);
					}
					else
					{
						result = this.washerServices.SaveAlarmStatus(alarm, user.UserId, user.EcolabAccountNumber);
					}
                }
                else
                {
					int messageType = alarmData.IsBatchEjectCondition ? (int)TcdAdminMessageTypes.TcdAddBatchEjectConditionStatus : (int)TcdAdminMessageTypes.TcdAddAlarmStatus;
					result = Push.PushToLocal(alarm, user.EcolabAccountNumber, user.UserId, messageType);
				}                
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }
    }
}