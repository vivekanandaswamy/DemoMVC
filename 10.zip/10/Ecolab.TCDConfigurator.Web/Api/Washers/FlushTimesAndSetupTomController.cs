﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTomController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The FlushTimesAndSetupTom Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api.Washers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers;
    using Ecolab.Models.Washers.Tunnel;
    using Models.Washers;
    using Models.Washers.Tunnel;
    using Services.Interfaces;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Tunnel;

    public class FlushTimesAndSetupTomController : BaseApiController
    {
        /// <summary>
        ///     The Flush Times And Setup Tom Services service
        /// </summary>
        private readonly IFlushTimesAndSetupTomServices FlushTimesAndSetupTomServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices TunnelGeneralServices;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService WasherGroupService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="flushTimesAndSetupTomServices">The flushTimesAndSetupTom services.</param>
        public FlushTimesAndSetupTomController(IUserService userService, IPlantService plantService, IFlushTimesAndSetupTomServices flushTimesAndSetupTomServices, ITunnelGeneralServices tunnelGeneralServices, IWasherGroupService washerGroupService)
            : base(userService, plantService)
        {
            this.FlushTimesAndSetupTomServices = flushTimesAndSetupTomServices;
            this.TunnelGeneralServices = tunnelGeneralServices;
            this.WasherGroupService = washerGroupService;
        }

        /// <summary>
        ///     Get all the values related to FlushTimes And Setup TOM
        /// </summary>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="groupTypeId">The group type Id</param>
        /// <returns>Returns the washers model</returns>
        [HttpGet]
        public Web.Models.Washers.FlushTimesAndSetupTom GetData(int machineId, int groupId, int groupTypeId)
        {
            Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom = new Web.Models.Washers.FlushTimesAndSetupTom();
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.TunnelGeneralServices.GetTunnelData(machineId, groupId, EcolabAccountNumber));
            Models.WasherGroup.WasherGroup washerGroup = AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.WasherGroupService.GetWasherGroupDetails(groupId, EcolabAccountNumber, 0, 12, string.Empty).FirstOrDefault());

            GetWasherFlushTimesList(machineId, EcolabAccountNumber,
                tunneldata.ControllerModelId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);

            flushTimesAndSetupTom.MachineId = tunneldata.Id;
            flushTimesAndSetupTom.WasherGroupId = tunneldata.WasherGroupId;
            flushTimesAndSetupTom.WasherGroupNumber = washerGroup.WasherGroupNumber;
            flushTimesAndSetupTom.WasherGroupName = washerGroup.WasherGroupName;
            flushTimesAndSetupTom.WasherGroupTypeId = washerGroup.WasherGroupTypeId;
            flushTimesAndSetupTom.WasherGroupType = washerGroup.WasherGroupTypeName;
            flushTimesAndSetupTom.ControllerId = tunneldata.ControllerId;
            flushTimesAndSetupTom.ControllerTypeId = tunneldata.ControllerTypeId;
            flushTimesAndSetupTom.ControllerModelId = tunneldata.ControllerModelId;
            flushTimesAndSetupTom.MachineNumber = tunneldata.LfsWasher;
            flushTimesAndSetupTom.NoOfCompartments = tunneldata.NoofCompartments;
            flushTimesAndSetupTom.MachineName = tunneldata.Name;
            if (tunneldata.ControllerModelId == 14 && tunneldata.WasherTypeName == "Tunnel")
            {
                if (tunneldata.TunInTomMode)
                {
                    GetWasherTimeOutMachinesList(machineId, EcolabAccountNumber, tunneldata.ControllerModelId, washerGroup.WasherGroupTypeId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);
                }
            }
            else
            {
                GetWasherTimeOutMachinesList(machineId, EcolabAccountNumber, tunneldata.ControllerModelId, washerGroup.WasherGroupTypeId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);
            }

            return flushTimesAndSetupTom;
        }

        /// <summary>
        /// GetWasherTimeOutMachinesList
        /// </summary>
        /// <param name="machineId">the washer id</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="controllerModelId">controllerModelId</param>
        /// <param name="washerGroupTypeId">washerGroupTypeId</param>
        /// <param name="controllerTypeId">controllerTypeId</param>
        /// <param name="flushTimesAndSetupTom">flushTimesAndSetupTom</param>
        private void GetWasherTimeOutMachinesList(int machineId, string ecolabAccountNumber, int controllerModelId,
            int washerGroupTypeId, int controllerTypeId, Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            flushTimesAndSetupTom.WasherTimeOutMachine =
                AutoMapper.Mapper.Map<IEnumerable<WasherTimeOutMachine>, IEnumerable<WasherTimeOutMachineModel>>(
                    this.FlushTimesAndSetupTomServices.GetWasherTimeOutMachine(machineId, ecolabAccountNumber, controllerModelId,
                        controllerTypeId)).ToList();
            if ((flushTimesAndSetupTom.WasherTimeOutMachine.Count == 1 && (
                flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount != 0 ||
                flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount != 0)) ||
                (flushTimesAndSetupTom.WasherTimeOutMachine.Count == 1 &&
                 (flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount == 0 ||
                  flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount == 0)))
            {
                if (flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount > 0)
                {
                    flushTimesAndSetupTom.DosingPointTom = new List<WasherTimeOutMachineModel>();
                    for (int i = 0; i < flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount; i++)
                    {
                        flushTimesAndSetupTom.DosingPointTom.Add(new WasherTimeOutMachineModel() { });
                    }
                }
                if (flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount > 0)
                {
                    flushTimesAndSetupTom.EquipmentTom = new List<WasherTimeOutMachineModel>();
                    for (int i = 0; i < flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount; i++)
                    {
                        flushTimesAndSetupTom.EquipmentTom.Add(new WasherTimeOutMachineModel() { });
                    }
                }
            }
            else
            {
                flushTimesAndSetupTom.DosingPointTom = new List<WasherTimeOutMachineModel>();
                flushTimesAndSetupTom.EquipmentTom = new List<WasherTimeOutMachineModel>();
                if ((controllerModelId == 7 && washerGroupTypeId == 1) || (controllerModelId == 14 && washerGroupTypeId == 2))
                {
                    foreach (var washerTimeOutMachineModel in flushTimesAndSetupTom.WasherTimeOutMachine)
                    {
                        flushTimesAndSetupTom.EquipmentTom.Add(new WasherTimeOutMachineModel()
                        {
                            EquipmentNumber = washerTimeOutMachineModel.EquipmentNumber,
                            WasherId = washerTimeOutMachineModel.WasherId,
                            SignalNumber = washerTimeOutMachineModel.SignalNumber,
                            LastModifiedTime = washerTimeOutMachineModel.LastModifiedTime,
                            ControllerTypelId = washerTimeOutMachineModel.ControllerTypelId
                        });
                    }
                }
                else
                {
                    foreach (var washerTimeOutMachineModel in flushTimesAndSetupTom.WasherTimeOutMachine)
                    {
                        flushTimesAndSetupTom.DosingPointTom.Add(new WasherTimeOutMachineModel()
                        {
                            EquipmentNumber = washerTimeOutMachineModel.EquipmentNumber,
                            DosingPointNumber = washerTimeOutMachineModel.DosingPointNumber,
                            WasherId = washerTimeOutMachineModel.WasherId,
                            SignalNumber = washerTimeOutMachineModel.SignalNumber,
                            LastModifiedTime = washerTimeOutMachineModel.LastModifiedTime,
                            ControllerTypelId = washerTimeOutMachineModel.ControllerTypelId
                        });
                    }
                }

            }
        }

        /// <summary>
        /// GetWasherFlushTimesList
        /// </summary>
        /// <param name="machineId">the washer id</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="controllerModelId">controllerModelId</param>
        /// <param name="controllerTypeId">controllerTypeId</param>
        /// <param name="flushTimesAndSetupTom">flushTimesAndSetupTom</param>
        private void GetWasherFlushTimesList(int machineId, string ecolabAccountNumber, int controllerModelId, int controllerTypeId, Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<WasherFlushTimeModel> flushTimes = AutoMapper.Mapper.Map<IEnumerable<WasherFlushTime>, IEnumerable<WasherFlushTimeModel>>(
                    this.FlushTimesAndSetupTomServices.GetWasherFlushTime(machineId, ecolabAccountNumber, controllerModelId, controllerTypeId)).ToList();
            if (flushTimes.Count() == 1 && (flushTimes[0].AirCount != 0 || flushTimes[0].MeCount != 0 ||
                flushTimes[0].PumpCount != 0 || flushTimes[0].WaterCount != 0))
            {
                flushTimesAndSetupTom.WasherFlushTime = new List<WasherFlushTimeModel>();
                if (flushTimes[0].PumpCount > 0)
                {
                    flushTimesAndSetupTom.Pumps = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].PumpCount; i++)
                    {
                        flushTimesAndSetupTom.Pumps.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = Models.Washers.WasherFlushType.Pump
                        });
                    }
                }
                if (flushTimes[0].MeCount > 0)
                {
                    flushTimesAndSetupTom.MainEquipment = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].MeCount; i++)
                    {
                        flushTimesAndSetupTom.MainEquipment.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = Models.Washers.WasherFlushType.MainEquipment
                        });
                    }
                }
                if (flushTimes[0].WaterCount > 0)
                {
                    flushTimesAndSetupTom.Water = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].WaterCount; i++)
                    {
                        flushTimesAndSetupTom.Water.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = Models.Washers.WasherFlushType.Water
                        });
                    }
                }
                if (flushTimes[0].AirCount > 0)
                {
                    flushTimesAndSetupTom.Air = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].AirCount; i++)
                    {
                        flushTimesAndSetupTom.Air.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = Models.Washers.WasherFlushType.Air
                        });
                    }
                }
            }
            else
            {
                foreach (var washerFlushTimeModel in flushTimes)
                {
                    switch (washerFlushTimeModel.WasherFlushTypeId)
                    {
                        case Models.Washers.WasherFlushType.Air:
                            {
                                if (flushTimesAndSetupTom.Air == null)
                                {
                                    flushTimesAndSetupTom.Air = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Air.Add((washerFlushTimeModel));
                                break;
                            }
                        case Models.Washers.WasherFlushType.Water:
                            {
                                if (flushTimesAndSetupTom.Water == null)
                                {
                                    flushTimesAndSetupTom.Water = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Water.Add((washerFlushTimeModel));
                                break;
                            }
                        case Models.Washers.WasherFlushType.Pump:
                            {
                                if (flushTimesAndSetupTom.Pumps == null)
                                {
                                    flushTimesAndSetupTom.Pumps = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Pumps.Add((washerFlushTimeModel));
                                break;
                            }
                        case Models.Washers.WasherFlushType.MainEquipment:
                            {
                                if (flushTimesAndSetupTom.MainEquipment == null)
                                {
                                    flushTimesAndSetupTom.MainEquipment = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.MainEquipment.Add((washerFlushTimeModel));
                                break;
                            }
                    }
                }
            }
        }

        /// <summary>
        ///     Save the Alarm Data
        /// </summary>
        /// <param name="flushTimesAndSetupTom">Object of FlushTimesAndSetupTom.</param>
        /// <returns>The result of the save operation in string format.</returns>
        [HttpPost]
        public HttpResponseMessage SaveFlushTimesAndSetupTom(Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            Ecolab.Models.User user = this.GetUser();
            int result = 0;
            int flushTimeStatus = 0;
            int washerTomStatus = 0;

            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            List<WasherFlushTimeModel> flushTimes = new List<WasherFlushTimeModel>();
            if (flushTimesAndSetupTom.Pumps != null && flushTimesAndSetupTom.Pumps.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Pumps);
            }
            if (flushTimesAndSetupTom.MainEquipment != null && flushTimesAndSetupTom.MainEquipment.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.MainEquipment);
            }
            if (flushTimesAndSetupTom.Air != null && flushTimesAndSetupTom.Air.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Air);
            }
            if (flushTimesAndSetupTom.Water != null && flushTimesAndSetupTom.Water.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Water);
            }
            List<WasherFlushTime> washerFlushTime = AutoMapper.Mapper.Map<List<WasherFlushTimeModel>, List<WasherFlushTime>>(flushTimes);
            List<WasherTimeOutMachine> washerTimeOutMachine = AutoMapper.Mapper.Map<List<WasherTimeOutMachineModel>, List<WasherTimeOutMachine>>(flushTimesAndSetupTom.WasherTimeOutMachine);

            Ecolab.Models.Washers.FlushTimesAndSetupTom flushTimeAndSetupTom = new Ecolab.Models.Washers.FlushTimesAndSetupTom();
            flushTimeAndSetupTom.MachineId = flushTimesAndSetupTom.MachineId;
            flushTimeAndSetupTom.ControllerModelId = flushTimesAndSetupTom.ControllerModelId;
            flushTimeAndSetupTom.ControllerTypeId = flushTimesAndSetupTom.ControllerTypeId;
            flushTimeAndSetupTom.EcolabAccountNumber = flushTimesAndSetupTom.EcolabAccountNumber;
            flushTimeAndSetupTom.WasherFlushTime = washerFlushTime;
            flushTimeAndSetupTom.WasherTimeOutMachine = washerTimeOutMachine;
            flushTimeAndSetupTom.WasherFlushTime.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            flushTimeAndSetupTom.WasherTimeOutMachine.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            flushTimeAndSetupTom.EcolabAccountNumber = user.EcolabAccountNumber;

            flushTimeAndSetupTom.MaxNumberOfRecordsWasherFlushTime
                                = this.FlushTimesAndSetupTomServices.GetMaxNumOfRecordsWasherFlushTime(flushTimeAndSetupTom.MachineId, user.EcolabAccountNumber);

            flushTimeAndSetupTom.MaxNumberOfRecordsWasherTimeOutMachine
                                = this.FlushTimesAndSetupTomServices.GetMaxNumOfRecordswasherTimeOutMachine(flushTimeAndSetupTom.MachineId, user.EcolabAccountNumber);

            try
            {
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        if (washerFlushTime != null && washerFlushTime.Count > 0)
                        {
                            flushTimeStatus = this.FlushTimesAndSetupTomServices.SaveWasherFlushTime(washerFlushTime, UserId, EcolabAccountNumber, flushTimeAndSetupTom.ControllerModelId);
                        }
                        if (washerTimeOutMachine != null && washerTimeOutMachine.Count > 0)
                        {
                            washerTomStatus = this.FlushTimesAndSetupTomServices.SaveWasherTimeOutMachine(washerTimeOutMachine, UserId, EcolabAccountNumber, flushTimesAndSetupTom.WasherGroupTypeId);
                        }
                        if (flushTimeStatus == 0 && washerTomStatus == 0) { result = 0; }
                    }
                    else
                    {
                        int id = 0;
                        result = Push.PushToLocal(flushTimeAndSetupTom, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddFlushTimesAndSetupTom, out id);
                    }
                    switch (result)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                    }
                    return this.Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }

            switch (result)
            {
                case 51030:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                case 60000:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                case 51060:
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, 0);
        }
    }
}