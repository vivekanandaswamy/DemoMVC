﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaController.cs" company="Ecolab">
// Gets the detalis of the washergroupformula for WasherGroupFormulaController Controller class.
// </copyright>
// <summary>The methods for washer group formula setup.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Services.Interfaces.Washers;
    using Ecolab.Services.WasherGroup;
    using Ecolab.TCDConfigurator.Web.Helper;
    using Models.PlantSetup;
    using Models.WasherGroup;
    using Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Model = Ecolab.Models;
    using ModelChemical = Ecolab.Models.PlantSetup.Chemical;
    using WasherGroup = Models.WasherGroup.WasherGroup;
    using WebModelChemical = Models.PlantSetup;

    public class WasherGroupFormulaController : BaseApiController
    {
        /// <summary>
        ///     Interface object for plant utility service.
        /// </summary>
        private readonly IPlantUtilityService plantUtilityService;

        /// <summary>
        ///     Product Master Service(Plant chemical)
        /// </summary>
        private readonly IProductMasterService prodMastService;

        /// <summary>
        /// The prog master service
        /// </summary>
        private readonly IProgramMasterService progMasterService;

        /// <summary>
        ///     Interface object for Washer Group formula Service.
        /// </summary>
        private readonly IWasherGroupFormulaService washerGroupFormulaService;

        /// <summary>
        ///     Interface object for Washer Group Service.
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherGroupFormulaController" /> class.
        /// </summary>
        /// <param name="washerGroupService">Wash group formula Service object.</param>
        /// <param name="progMasterService">IProduct Master Service</param>
        /// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
        /// <param name="plantUtilityService">Plant Utility Service</param>
        /// <param name="prodMastService">Product Master Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="userService">User Service</param>
        /// <param name="washerServices">Washer Service</param>
        public WasherGroupFormulaController(IWasherGroupService washerGroupService, IProgramMasterService progMasterService, IWasherGroupFormulaService washerGroupFormulaService, IPlantUtilityService plantUtilityService, IProductMasterService prodMastService, IPlantService plantService, IUserService userService, IWasherServices washerServices)
            : base(userService, plantService)
        {
            this.washerGroupService = washerGroupService;
            this.progMasterService = progMasterService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.plantUtilityService = plantUtilityService;
            this.prodMastService = prodMastService;
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     Get all the values related to washergroup
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <param name="pageNumber">Page Number.</param>
        /// <param name="numberOfRecordsPerpage">Number Of Records Perpage.</param>
        /// <param name="sortColumn">The sort column.</param>
        /// <param name="regionId">The Region Id</param>
        /// <returns>Returns the washergroup model</returns>
        [HttpGet]
        public IEnumerable<WasherGroup> GetWasherGroupDetails(int washergroupId, string ecolabAccountNumber, int pageNumber, int numberOfRecordsPerpage, string sortColumn, int regionId)
        {
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, pageNumber, numberOfRecordsPerpage, sortColumn);
            IEnumerable<WasherGroup> washerGroups = Mapper.Map<IEnumerable<Ecolab.Models.WasherGroup.WasherGroup>, IEnumerable<WasherGroup>>(washerGroupModel);
            return washerGroups;
        }

        /// <summary>
        ///     Get all the values related to washergroup with washer list.
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <param name="pageNumber">Page Number.</param>
        /// <param name="numberOfRecordsPerpage">Number Of Records Perpage.</param>
        /// <param name="sortColumn">the Sort Column</param>
        /// <param name="regionId">the regionId.</param>
        /// <returns>Returns the WasherGroupFormulaLists model</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWasherGroupWithWasherDetails(int washergroupId, string ecolabAccountNumber, int pageNumber, int numberOfRecordsPerpage, string sortColumn, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            objWasherGroupFormulaModel.NextAvailableWasherGroupNumber = this.washerGroupService.GetNextAvailableWasherGroupNumber(ecolabAccountNumber);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, pageNumber, numberOfRecordsPerpage, sortColumn);
            IEnumerable<WasherGroup> washerGroups = Mapper.Map<IEnumerable<Ecolab.Models.WasherGroup.WasherGroup>, IEnumerable<WasherGroup>>(washerGroupModel);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroups;
            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washergroupId);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);
            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Get all the values related to washergroup formula
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber.</param>
        /// <returns>Returns the washergroup formula model</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWasherGroupFormula(int washergroupId, string ecolabAccountNumber)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();

            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washergroupId, 0);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, 1, 12, string.Empty);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).OrderBy(x => x.ProgramNumber).ToList();
            if (objWasherGroupFormulaModel.WasherGroupFormulaDetails.Count > 0)
            {
                foreach (WasherGroupFormulaModel wgfm in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                    if (washerGroupModel != null && washerGroupModel.First().ControllerModelId == 8)
                    {
                        wgfm.CompartmentStandardRunTime = wgfm.StandardRunTime != 0 ? this.ConvertionofSeconds(wgfm.StandardRunTime) : "01:30";
                    }
                    else
                    {
                        wgfm.CompartmentStandardRunTime = wgfm.StandardRunTime != 0 ? this.ConvertionofSeconds(wgfm.StandardRunTime) : "02:00";
                    }
                }
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.ForEach(_ => _.LoadsPerMonthAsString = _.LoadsPerMonth.ToString("#,0.##"));
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.ForEach(_ => _.NominalLoadAsString = _.NominalLoad.ToString("#,0.##"));
            }

            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = new List<WasherFormulaWashStepModel>();
            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Save the Washer Group Data
        /// </summary>
        /// <param name="washerGroupWebData">Object of Washer group.</param>
        /// <returns>The result of the save opreation in string format.</returns>
        [HttpPost]
        public HttpResponseMessage CreateWasherGroup(WasherGroup washerGroupWebData)
        {
            int result = 0;
            int error = 0;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            washerGroupWebData.EcolabAccountNumber = user.EcolabAccountNumber;
            try
            {
                if (user != null)
                {
                    washerGroupWebData.MaxNumberOfRecords = this.washerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                    Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washerGroupWebData);
                    washerGroupData.MyServiceWasherGroupGuid = Guid.NewGuid();

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        washerGroupData.WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupData, user.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                        result = washerGroupData.WasherGroupId;
                    }
                    else
                    {
                        int id = 0;
                        washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupData.LastModifiedTimeStamp, DateTimeKind.Utc);
                        error = Push.PushToLocal(washerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddWasherGroup, out id);
                        result = id;
                    }
                    switch (error)
                    {
                        case 51030:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 51000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51000);

                        case 60000:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Update the Washer Group Data
        /// </summary>
        /// <param name="washerGroupWebData">Washer group web data.</param>
        /// <returns>The result of the save opreation in string format.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherGroup(WasherGroup washerGroupWebData)
        {
            int error = 0;
            int result = 0;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            washerGroupWebData.EcolabAccountNumber = user.EcolabAccountNumber;
            try
            {
                if (user != null)
                {
                    washerGroupWebData.MaxNumberOfRecords = this.washerGroupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);

                    Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washerGroupWebData);

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        washerGroupData.WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupData, user.UserId, washerGroupWebData.EcolabAccountNumber, out lastModifiedTimeStamp);
                        result = washerGroupData.WasherGroupId;
                    }
                    else
                    {
                        int id = 0;
                        washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupData.LastModifiedTimeStamp, DateTimeKind.Utc);
                        error = Push.PushToLocal(washerGroupData, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherGroup, out id);
                        result = id;
                    }
                    result = washerGroupData.WasherGroupId;
                }
                switch (error)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);

                    case 51000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51000);

                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Save the WasherFormulaWashStepModel Data
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">washer group formula wash step.</param>
        /// <returns>The result of the save opreation.</returns>
        [HttpPost]
        public HttpResponseMessage SaveWasherGroupFormulaWashSteps(WasherFormulaWashStepModel washerGroupFormulaWashStep)
        {
            int result = 0, error = 0;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            washerGroupFormulaWashStep.EcolabAccountNumber = user.EcolabAccountNumber;

            try
            {
                if (user != null)
                {
                    WasherFormulaWashStep objWasherGroupFormulaWashStep = Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(washerGroupFormulaWashStep);
                    DateTime lastModifiedTimeStamp;
                    if (objWasherGroupFormulaWashStep.Id > 0)
                    {
                        if (isDisconnected)
                        {
                            result = this.washerGroupFormulaService.UpdateWasherGroupWashStepFormula(objWasherGroupFormulaWashStep, user.UserId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormulaWashStep = new List<WasherFormulaWashStep>();
                            washerModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault();
                            washerModel.washerFormulaWashStep.Add(objWasherGroupFormulaWashStep);

                            Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherFormulaWashStep);
                        }
                    }
                    else
                    {
                        objWasherGroupFormulaWashStep.MyServiceCusrFrmulaStpGuid = Guid.NewGuid();
                        if (isDisconnected)
                        {
                            result = this.washerGroupFormulaService.AddWasherGroupFormulaWashSteps(objWasherGroupFormulaWashStep, user.UserId, washerGroupFormulaWashStep.RegionId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault();
                            washerModel.washerFormulaWashStep = new List<WasherFormulaWashStep>();
                            washerModel.washerFormulaWashStep.Add(objWasherGroupFormulaWashStep);

                            error = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddWasherFormulaWashStepLocal);
                        }
                    }

                }
                switch (error)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 51000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51000);

                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);

                }
                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Get Formula Details for Add
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="washerGroupId">washer group id.</param>
        /// <returns>Returns the Fromula Details</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetAddFormulaDetails(string ecolabAccountNumber, int washerGroupId, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();

            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, this.EcolabAccountNumber, washerGroupId);
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();
            objWasherGroupFormulaModel.GetDrainDestinationsList =
               Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.TCDConfigurator.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            objWasherGroupFormulaModel.WasherGroupFormulaDetails = new List<WasherGroupFormulaModel>();

            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<TCDConfigurator.Web.Models.PlantSetup.FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<TCDConfigurator.Web.Models.PlantSetup.FormulaModel>>(formulaName);

            string comaprtmentStandardRunTime = String.Empty;
            if (washerGroupModel != null && washerGroupModel.First().ControllerModelId == 8)
            {
                comaprtmentStandardRunTime = "01:30";
            }
            else
            {
                comaprtmentStandardRunTime = "02:00";
            }
            WasherGroupFormulaModel washerGroupFormulaModel = new WasherGroupFormulaModel { Formulas = formulaNameDropDown, CompartmentStandardRunTime = comaprtmentStandardRunTime };
            washerGroupFormulaModel.CanAddInjections = true;
            washerGroupFormulaModel.ControllerId = washerGroupModel.ToList().Count() > 0 ? washerGroupModel.FirstOrDefault().ControllerId : 0;
            washerGroupFormulaModel.ControllerModelId = washerGroupModel.ToList().Count() > 0 ? washerGroupModel.FirstOrDefault().ControllerModelId : 0;
            washerGroupFormulaModel.MaxInjectionsCount = this.washerGroupFormulaService.GetMaxInjectionCount(ecolabAccountNumber, washerGroupId, washerGroupFormulaModel.ControllerModelId, washerGroupFormulaModel.ControllerId);
            int refrenceLoad = this.washerGroupFormulaService.GetReferenceLoad(ecolabAccountNumber, washerGroupId);

            objWasherGroupFormulaModel.DefaultDrainDestination = this.washerGroupFormulaService.GetDefaultDrainDestinationId();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails.Add(washerGroupFormulaModel);
            objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].ReferenceLoad = refrenceLoad;

            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washerGroupId);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);
            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Get Fromula Details for Add/Edit
        /// </summary>
        /// <param name="washerGroupId">Washer Group Id</param>
        /// <param name="programSetupId">Program Setup Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="regionId">the region Id.</param>
        /// <returns>Returns the Fromula Details</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetEditFormulaDetails(int washerGroupId, int programSetupId, string ecolabAccountNumber, int regionId)
        {
            int washerDosingCount = 0;
            var objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            List<WasherFormulaWashStep> washerGroupFormulaWashSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, 0).ToList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);

            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, ecolabAccountNumber, washerGroupId);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();

            IEnumerable<WasherGroupFormula> washerGroupFormulaModelNumbers = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, 0);
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers = washerGroupFormulaModelNumbers.Select(EntityConverter.ConvertToWebModel).OrderBy(x => x.ProgramNumber).ToList();

            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = Mapper.Map<List<WasherFormulaWashStep>, List<WasherFormulaWashStepModel>>(washerGroupFormulaWashSteps);

            objWasherGroupFormulaModel.SensorAttached = this.washerGroupFormulaService.GetSensorAttachedValue(washerGroupId, ecolabAccountNumber);

            foreach (WasherFormulaWashStepModel wfws in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {
                wfws.StepRunTime = this.ConvertionofSeconds(wfws.RunTime);
            }
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            if (objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].TotalRunTime > 0)
            {
                objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].RunTime = this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].TotalRunTime);
                objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].CompartmentStandardRunTime = objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].StandardRunTime != 0 ? this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].StandardRunTime) : "02:00";
            }
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<FormulaModel>>(formulaName);

            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {
                List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(ecolabAccountNumber, washStep.Id, false).ToList();

                if (washerGroupFormulaModel != null && washerGroupFormulaModel.Count() > 0
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId > 6
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId != 12
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId != 13)
                {
                    foreach (WasherDosingProduct Product in prodDosing)
                    {
                        foreach (ModelChemical.Chemicals chemical in chemicals)
                        {
                            if (Product.ProductId == chemical.ProductId && Product.ControllerEquipmentSetupId == chemical.ControllerEquipmentSetupId)
                            {
                                Product.ControllerEquipmentTypeId = chemical.ControllerEquipmentTypeId;
                            }
                        }
                    }
                    prodDosing = (from pd in prodDosing where (pd.ControllerEquipmentTypeId != 0) select pd).ToList();
                }
                washStep.WasherDosingProducts = Mapper.Map<List<WasherDosingProduct>, List<WasherDosingProductModel>>(prodDosing);
            }
            foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {

                Ecolab.Models.WasherGroup.ConventionalAnalogueControl analogDosing = this.washerGroupFormulaService.GetWasherAnalogControl(ecolabAccountNumber, washStep.ProgramSetupId, washStep.StepNumber);
                washStep.ConventionalAnalogue = analogDosing;
                washerDosingCount++;
            }
            objWasherGroupFormulaModel.GetDrainDestinationsList =
                Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);
            foreach (WasherGroupFormulaModel item in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
            {
                item.Formulas = formulaNameDropDown;
            }
            objWasherGroupFormulaModel.DefaultDrainDestination = this.washerGroupFormulaService.GetDefaultDrainDestinationId();

            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washerGroupId);
            washersModel.ToList().ForEach(a => a.WasherName = a.WasherNumber + " : " + a.WasherName);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="dosingSetupId">dosing setup id.</param>
        /// <param name="ecolabAccountNumber">Passing ecolab account number.</param>
        /// <param name="regionId">Passing RegionId.</param>
        /// <returns>the lists of wash step details.</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetEditFormulaWashStepDetails(int washerGroupId, int programSetupId, int dosingSetupId, string ecolabAccountNumber, int regionId)
        {
            var objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, ecolabAccountNumber, washerGroupId);
            List<WasherFormulaWashStep> washerGroupFormulaWashSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, dosingSetupId).ToList();
            objWasherGroupFormulaModel.WashStepsWithDosing = new List<KeyValuePair<int, int>>();
            List<WasherFormulaWashStep> washSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, 0).ToList();
            foreach (WasherFormulaWashStep washStep in washSteps)
            {
                objWasherGroupFormulaModel.WashStepsWithDosing.Add(new KeyValuePair<int, int>(washStep.Id, washStep.StepNumber));
            }

            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = Mapper.Map<List<WasherFormulaWashStep>, List<WasherFormulaWashStepModel>>(washerGroupFormulaWashSteps);
            if (objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel != null)
            {
                if (objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel.Count > 0)
                {
                    objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel[0].StepRunTime = this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel[0].RunTime);
                }

                objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
                foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
                {
                    List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(ecolabAccountNumber, washStep.Id, false).ToList();
                    washStep.WasherDosingProducts = Mapper.Map<List<WasherDosingProduct>, List<WasherDosingProductModel>>(prodDosing);
                }
            }

            objWasherGroupFormulaModel.GetDrainDestinationsList =
                Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Save the Formula Data
        /// </summary>
        /// <param name="FormulaData">Washer Group Formula object</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage CreateFormula(WasherGroupFormulaModel FormulaData)
        {
            int formulaId = 0;
            var user = GetUser();
            int result = 0;
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            FormulaData.EcolabAccountNumber = user.EcolabAccountNumber;
            try
            {
                if (user != null)
                {
                    WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();
                    if (FormulaData.WasherGroupTypeName == "Conventional")
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                    }
                    else
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(user.EcolabAccountNumber);
                    }
                    WasherGroupFormula formulaData = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(FormulaData);
                    formulaData.MyServiceCustFrmulaMchGrpGUID = Guid.NewGuid();
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        formulaId = this.washerGroupFormulaService.AddWasherGroupFormula(formulaData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        if (formulaData.WasherGroupTypeName == "Conventional")
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormula = formulaData;
                            int Id = 0;
                            washerModel.washerFormula.LastModifiedTime =
                                DateTime.SpecifyKind(washerModel.washerFormula.LastModifiedTime, DateTimeKind.Utc);
                            result = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddWasherFormula, out Id);
                            formulaId = Id;
                        }
                        else if (formulaData.WasherGroupTypeName == "Tunnel")
                        {
                            TunnelFormulaModel tunnelModel = new TunnelFormulaModel();
                            tunnelModel.tunnelFormula = formulaData;
                            int Id = 0;
                            tunnelModel.tunnelFormula.LastModifiedTime =
                                DateTime.SpecifyKind(tunnelModel.tunnelFormula.LastModifiedTime, DateTimeKind.Utc);
                            result = Push.PushToLocal(tunnelModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddTunnelFormula, out Id);
                            formulaId = Id;
                        }
                        switch (result)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            case 51060:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                            case 51000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51000");
                            case 51012:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51012");
                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, formulaId);
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627 || ex.Message.Contains("51012"))
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Number == 2627 ? "Storage tank already exists. Please try again." : ex.Message.Substring(9, 5));
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Storage tank. Some error has occured. Please try again.");
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Deletes the washer group based on the washergroupId.
        /// </summary>
        /// <param name="FormulaData">The Formula data</param>
        /// <returns>The string value the deletion is passed or failed.</returns>
        [HttpPost]
        public HttpResponseMessage DeleteWasherGroup(WasherGroupFormulaModel FormulaData)
        {
            Model.User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            FormulaData.EcolabAccountNumber = user.EcolabAccountNumber;
            Ecolab.Models.WasherGroup.WasherGroup washerGroupModel = washerGroupService.GetWasherGroupDetails(FormulaData.WasherGroupId, EcolabAccountNumber, 1, 12, string.Empty).FirstOrDefault();
            FormulaData.LastModifiedTime = DateTime.SpecifyKind(FormulaData.LastModifiedTime, DateTimeKind.Utc);
            try
            {
                if (user != null)
                {
                    WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();
                    if (FormulaData.WasherGroupTypeName == "Conventional")
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                    }
                    else
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(user.EcolabAccountNumber);
                    }
                    WasherGroupFormula formulaData = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(FormulaData);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        bool response = this.washerGroupFormulaService.DeleteWasherGroupFormula(formulaData, user.UserId, out lastModifiedTimeStamp);
                        if (response == false)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest);
                        }
                    }
                    else
                    {
                        if (washerGroupModel.WasherGroupTypeName == "Conventional")
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormula = formulaData;
                            washerModel.washerFormula.IsDelete = true;

                            result = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteWasherFormula);
                        }
                        else if (washerGroupModel.WasherGroupTypeName == "Tunnel")
                        {
                            TunnelFormulaModel tunnelModel = new TunnelFormulaModel();
                            tunnelModel.tunnelFormula = formulaData;
                            tunnelModel.tunnelFormula.IsDelete = true;

                            result = Push.PushToLocal(tunnelModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteTunnelFormula);
                        }
                    }
                }
                switch (result)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, true);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        /// <summary>
        ///     Deletes the Formula Wash Step based on the washergroupId.
        /// </summary>
        /// <param name="formulaWashStepData">Formula Wash Step Data </param>
        /// <returns>The string value the deletion is passed or failed.</returns>
        [HttpPost]
        public HttpResponseMessage DeleteWasherGroupFormulaWashStep(WasherFormulaWashStepModel formulaWashStepData)
        {
            WasherGroupFormulaService objWasherGroupFormulaService = new WasherGroupFormulaService();
            Model.User user = this.GetUser();
            int result = 0;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            formulaWashStepData.EcolabAccountNumber = user.EcolabAccountNumber;
            try
            {
                if (user != null)
                {
                    WasherFormulaWashStep formulaWashData = Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(formulaWashStepData);
                    formulaWashData.IsDelete = true;
                    formulaWashData.MaxNumberOfRecords = objWasherGroupFormulaService.GetMaxNumberOfRecordsForWasherGroupFormulaWashStep(user.EcolabAccountNumber);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        bool response = this.washerGroupFormulaService.DeleteWasherGroupFormulaWashStep(formulaWashData, user.UserId, out lastModifiedTimeStamp);
                        if (response == false)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest);
                        }
                    }
                    else
                    {
                        WasherFormulaModel washerModel = new WasherFormulaModel();
                        washerModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, formulaWashData.WasherGroupId, formulaWashData.ProgramSetupId).FirstOrDefault();
                        washerModel.washerFormula.MaxNumberOfRecords = objWasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                        List<WasherFormulaWashStep> washerFormulaWashStep = new List<WasherFormulaWashStep>();
                        washerFormulaWashStep.Add(formulaWashData);
                        washerModel.washerFormulaWashStep = washerFormulaWashStep;
                        result = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteWasherFormulaWashStep);
                    }
                }

                switch (result)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        /// <summary>
        ///     Update the Washer Group Formula
        /// </summary>
        /// <param name="FormulaData">The Formula data.</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherGroupFormula(WasherGroupFormulaModel FormulaData)
        {
            var user = GetUser();
            int result = 0;
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            FormulaData.EcolabAccountNumber = user.EcolabAccountNumber;
            FormulaData.IsPLCConnected = true;
            WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();
            FormulaData.LastModifiedTime = DateTime.SpecifyKind(FormulaData.LastModifiedTime, DateTimeKind.Utc);
            try
            {
                if (user != null)
                {
                    if (FormulaData.WasherGroupTypeName == "Conventional")
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                    }
                    else
                    {
                        FormulaData.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(user.EcolabAccountNumber);
                    }
                    WasherGroupFormula formulaData = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(FormulaData);
                    Ecolab.Models.WasherGroup.WasherGroup washerGroupModel = washerGroupService.GetWasherGroupDetails(formulaData.WasherGroupId, EcolabAccountNumber, 1, 12, string.Empty).FirstOrDefault();

                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        this.washerGroupFormulaService.UpdateWasherGroupFormula(formulaData, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        if (washerGroupModel.WasherGroupTypeName == "Conventional")
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormula = formulaData;

                            result = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherFormula);
                        }
                        else if (washerGroupModel.WasherGroupTypeName == "Tunnel")
                        {
                            TunnelFormulaModel tunnelModel = new TunnelFormulaModel();
                            tunnelModel.tunnelFormula = formulaData;

                            result = Push.PushToLocal(tunnelModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateTunnelFormula);
                        }
                        switch (result)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                            case 51060:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, FormulaData);
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Storage tank already exists. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Storage tank. Some error has occured. Please try again.");
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="washergroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="ecolabAccountNumber">Passing ecolab account number.</param>
        /// <param name="formulaId">Passing the formulaId.</param>
        /// <param name="regionId">Passing regionId.</param>
        /// <returns>the lists of wash step details.</returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWashStepDetails(int washergroupId, string ecolabAccountNumber, int formulaId, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washergroupId, formulaId);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, this.EcolabAccountNumber, washergroupId);

            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(this.EcolabAccountNumber, 0, 0, 0);
            List<FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<FormulaModel>>(formulaName);
            foreach (WasherGroupFormulaModel item in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
            {
                item.Formulas = formulaNameDropDown;
            }

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        ///     Save Wash Step
        /// </summary>
        /// <param name="washdata">The Wash Data</param>
        /// <param name="productData">The Product Data</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage SaveWashStep(WasherFormulaWashStepModel washdata, WasherDosingProductModel productData)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK);
        }

        /// <summary>
        ///     Gets the ChemicalsList
        /// </summary>
        /// <param name="term">Search term to get matching chemicals</param>
        /// <returns>List of ChemicalsModel</returns>
        [HttpGet]
        public IEnumerable<WebModelChemical.ChemicalsModel> GetChemicalList(string term)
        {
            Model.User user = this.GetUser();
            List<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(term, user.EcolabAccountNumber, 0);
            List<WebModelChemical.ChemicalsModel> chemicalList = Mapper.Map<List<ModelChemical.Chemicals>, List<WebModelChemical.ChemicalsModel>>(chemicals);
            return chemicalList;
        }

        /// <summary>
        ///     Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="dosingSetupId">Passing dosingSetupId.</param>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="regionId">Passing regionId.</param>
        /// <returns>wash step details.</returns>
        [HttpGet]
        public TunnelGroupFormulaLists GetTunnelDetails(int programSetupId, string ecoalabAccountNumber, int dosingSetupId, int washerGroupId, int regionId)
        {
            TunnelGroupFormulaLists objTunnelGroupFormulaListsModel = new TunnelGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecoalabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoalabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            objTunnelGroupFormulaListsModel.WashStepsWithDosing = new List<KeyValuePair<int, int>>();
            List<TunnelWashStep> washSteps = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, 0).ToList();
            foreach (TunnelWashStep washStep in washSteps)
            {
                objTunnelGroupFormulaListsModel.WashStepsWithDosing.Add(new KeyValuePair<int, int>(washStep.Id, washStep.CompartmentNumber));
            }

            dosingSetupId = dosingSetupId > 0 ? dosingSetupId : washSteps.FirstOrDefault() == null ? 0 : washSteps.FirstOrDefault().Id;
            TunnelWashStep washStepsData = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, dosingSetupId).FirstOrDefault();
            TunnelWashStepModel tunnelWashSteps = Mapper.Map<TunnelWashStep, TunnelWashStepModel>(washStepsData);
            if (tunnelWashSteps != null)
            {
                tunnelWashSteps.TunnelAnalogueControl = Mapper.Map<Ecolab.Models.WasherGroup.TunnelAnalogueControl, Web.Models.WasherGroup.TunnelAnalogueControlModel>(this.washerGroupFormulaService.FetchTunnelAnalogueControl(programSetupId, tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber));
                List<TunnelWashStepProducts> productData = this.washerGroupFormulaService.GetTunnelProductList(tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber, tunnelWashSteps.GroupId, dosingSetupId);
                List<TunnelWashStepProductsModel> productListData = Mapper.Map<List<TunnelWashStepProducts>, List<TunnelWashStepProductsModel>>(productData);
                tunnelWashSteps.ProductsList = productListData;
                tunnelWashSteps.RunTime = this.ConvertionofSeconds(tunnelWashSteps.StepRunTime);
                objTunnelGroupFormulaListsModel.TunnelWashStepsModel = new List<TunnelWashStepModel> { tunnelWashSteps };
            }

            objTunnelGroupFormulaListsModel.TunnelProductsWithInjectionCount = this.GetTunnelProdsWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            if (objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails != null)
            {
                foreach (WasherGroupFormulaModel wgfm in objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                }
            }
            return objTunnelGroupFormulaListsModel;
        }

        /// <summary>
        ///     Update Tunnel Step.
        /// </summary>
        /// <param name="tunnelStepData">Passing the tunnelStepData.</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateTunnelStep([FromBody] List<TunnelWashStepModel> tunnelStepData)
        {
            int returnValue = 0, result = 0;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            tunnelStepData[0].EcolabAccountNumber = user.EcolabAccountNumber;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            try
            {
                if (user != null)
                {
                    WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();

                    List<TunnelWashStep> tunnelStepDetails = Mapper.Map<List<TunnelWashStepModel>, List<TunnelWashStep>>(tunnelStepData);
                    if (isDisconnected)
                    {
                        returnValue = this.washerGroupFormulaService.UpdateTunnelWashStep(tunnelStepDetails, user.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        TunnelFormulaModel tunnelModel = new TunnelFormulaModel();
                        tunnelModel.tunnelFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, tunnelStepDetails.ElementAt(0).GroupId, tunnelStepDetails.ElementAt(0).TunnelProgramSetupId).FirstOrDefault();
                        tunnelModel.tunnelFormula.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(user.EcolabAccountNumber);
                        tunnelModel.tunnelFormula.LastModifiedTime = lastModifiedTimeStamp;

                        tunnelModel.tunnelWashStep = tunnelStepDetails;

                        result = Push.PushToLocal(tunnelModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateTunnelFormulaWashStep);
                    }
                }
                switch (result)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, 200);
        }

        /// <summary>
        ///     Gets the basic details for loading the tunnel grid view data.
        /// </summary>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="dosingSetupId">Passing dosingSetupId.</param>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="regionId">Passing regionId.</param>
        /// <returns>Gets all compartment details.</returns>
        [HttpGet]
        public TunnelGroupFormulaLists GetTunnelGridDetails(int programSetupId, string ecoalabAccountNumber, int dosingSetupId, int washerGroupId, int regionId)
        {
            TunnelGroupFormulaLists objTunnelGroupFormulaListsModel = new TunnelGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecoalabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoalabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            List<TunnelWashStep> washSteps = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, 0).ToList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);

            objTunnelGroupFormulaListsModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.TunnelProductsWithInjectionCount = this.GetTunnelProdsWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId).ToList();
            objTunnelGroupFormulaListsModel.TunnelWashStepsModel = new List<TunnelWashStepModel>();
            foreach (TunnelWashStep washStep in washSteps)
            {
                washStep.TunnelAnalogueControl = this.washerGroupFormulaService.FetchTunnelAnalogueControl(programSetupId, washStep.CompartmentNumber, ecoalabAccountNumber);
                TunnelWashStepModel tunnelWashSteps = Mapper.Map<TunnelWashStep, TunnelWashStepModel>(washStep);
                if (tunnelWashSteps == null)
                {
                    continue;
                }
                tunnelWashSteps.RunTime = this.ConvertionofSeconds(tunnelWashSteps.StepRunTime);
                List<TunnelWashStepProducts> productData = this.washerGroupFormulaService.GetTunnelProductList(tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber, tunnelWashSteps.GroupId, tunnelWashSteps.TunnelDosingSetupId);
                List<TunnelWashStepProductsModel> productListData = Mapper.Map<List<TunnelWashStepProducts>, List<TunnelWashStepProductsModel>>(productData);
                tunnelWashSteps.ProductsList = productListData;
                objTunnelGroupFormulaListsModel.TunnelWashStepsModel.Add(tunnelWashSteps);
            }
            if (objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails != null)
            {
                foreach (WasherGroupFormulaModel wgfm in objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                }
            }
            objTunnelGroupFormulaListsModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            return objTunnelGroupFormulaListsModel;
        }

        /// <summary>
        ///     Gets the Tunnel products with count.
        /// </summary>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="washerGroupId">Washer Group Id.</param>
        /// <param name="programSetupId">Program Setup Id.</param>
        /// <returns>TunnelWashStepProductsModel list.</returns>
        private IEnumerable<TunnelWashStepProductsModel> GetTunnelProdsWithInjectionCount(string ecoalabAccountNumber, int washerGroupId, int programSetupId)
        {
            IEnumerable<TunnelWashStepProducts> tunnelProdWithInj = this.washerGroupFormulaService.GetTunnelProductListForFormulaWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId);
            return Mapper.Map<IEnumerable<TunnelWashStepProducts>, IEnumerable<TunnelWashStepProductsModel>>(tunnelProdWithInj);
        }

        private string ConvertionofSeconds(int runTime)
        {
            string strRunTime;
            if (runTime != 0)
            {
                int mins = runTime / 60;
                int secs = runTime % 60;
                if (mins < 10)
                {
                    strRunTime = "0" + mins;
                }
                else
                {
                    strRunTime = Convert.ToString(mins);
                }
                if (secs < 10)
                {
                    strRunTime = strRunTime + ":" + "0" + secs;
                }
                else
                {
                    strRunTime = strRunTime + ":" + secs;
                }
            }
            else
            {
                strRunTime = "01:30";
            }

            return strRunTime;
        }

        /// <summary>
        ///  Updating the conventional wash setp injections for a formula
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">class object of washergroup formula washstep</param>
        /// <returns>Status of the operation. </returns>
        [HttpPost]
        public HttpResponseMessage UpdateConventionalWashStepInjections(WasherFormulaWashStepModel washerGroupFormulaWashStep)
        {
            try
            {
                bool result = true;
                Model.User user = this.GetUser();
                int error = 0;
                bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
                WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();
                WasherFormulaWashStep objWasherGroupFormulaWashStep =
                    Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(washerGroupFormulaWashStep);
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    result =
                        this.washerGroupFormulaService.UpdateConventionalWashStepInjections(objWasherGroupFormulaWashStep,
                            this.UserId, out lastModifiedTimeStamp);
                }
                else
                {
                    WasherFormulaModel washerFormulaModel = new WasherFormulaModel();
                    washerFormulaModel.washerFormulaWashStep = new List<WasherFormulaWashStep>();
                    washerFormulaModel.washerFormulaWashStep.Add(objWasherGroupFormulaWashStep);
                    washerFormulaModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault();
                    washerFormulaModel.washerFormula.EcolabAccountNumber = user.EcolabAccountNumber;
                    washerFormulaModel.washerFormula.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                    error = Push.PushToLocal(washerFormulaModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateConvFormulaInjections);
                }
                switch (error)
                {
                    case 51030:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    case 51060:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    case 51000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51000);
                    case 60000:
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                }
                if (!result)
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, 400);
                }
                return Request.CreateResponse(HttpStatusCode.OK, 200);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, int.Parse(Regex.Match(ex.Message, @"\d+").Value));
            }
        }

        /// <summary>
        /// save the Conventional washsteps Grid View details
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">steps object </param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage SaveConventionalWashStepGridView(List<WasherFormulaWashStepModel> washerGroupFormulaWashStep)
        {
            WasherGroupFormulaService objWasherGroupFormulaService = new WasherGroupFormulaService();
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            int result = 0;
            try
            {
                if (user != null)
                {
                    WasherGroupFormulaService formulaService = new WasherGroupFormulaService();
                    List<WasherFormulaWashStep> objWasherGroupFormulaWashStep =
                        Mapper.Map<List<WasherFormulaWashStepModel>, List<WasherFormulaWashStep>>(
                            washerGroupFormulaWashStep);
                    objWasherGroupFormulaWashStep.ForEach(t => t.MaxNumberOfRecords = formulaService.GetMaxNumberOfRecordsForWasherGroupFormulaWashStep(user.EcolabAccountNumber));

                    if (isDisconnected)
                    {
                        result = Convert.ToInt32(washerGroupFormulaService.SaveConventionalWashStepGridView(objWasherGroupFormulaWashStep, this.UserId));

                        var formulaWashStep = objWasherGroupFormulaWashStep.FirstOrDefault();
                        if (formulaWashStep != null && objWasherGroupFormulaWashStep.Count > 0)
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormulaWashStep = new List<WasherFormulaWashStep>();
                            washerModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, formulaWashStep.WasherGroupId, formulaWashStep.ProgramSetupId).FirstOrDefault();
                            washerModel.washerFormula.MaxNumberOfRecords = objWasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                            washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(washerModel.washerFormula.LastModifiedTime, DateTimeKind.Utc);

                            foreach (var washerFormulaWashStepModel in objWasherGroupFormulaWashStep)
                            {
                                washerModel.washerFormulaWashStep.Add(washerFormulaWashStepModel);
                            }

                            //Update Washer Group Formula For Cool Down Step
                            if (washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").Any())
                            {
                                washerModel.washerFormula.CoolDownStep = washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").First().StepNumber;
                            }
                            else
                            {
                                washerModel.washerFormula.CoolDownStep = 0;
                            }
                            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                            this.washerGroupFormulaService.UpdateWasherGroupFormula(washerModel.washerFormula, this.UserId, out lastModifiedTimeStamp);
                        }
                    }
                    else
                    {
                        var formulaWashStep = objWasherGroupFormulaWashStep.FirstOrDefault();
                        if (formulaWashStep != null && objWasherGroupFormulaWashStep.Count > 0)
                        {
                            WasherFormulaModel washerModel = new WasherFormulaModel();
                            washerModel.washerFormulaWashStep = new List<WasherFormulaWashStep>();
                            washerModel.washerFormula = washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, formulaWashStep.WasherGroupId, formulaWashStep.ProgramSetupId).FirstOrDefault();
                            washerModel.washerFormula.MaxNumberOfRecords = objWasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                            washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(washerModel.washerFormula.LastModifiedTime, DateTimeKind.Utc);

                            foreach (var washerFormulaWashStepModel in objWasherGroupFormulaWashStep)
                            {
                                washerModel.washerFormulaWashStep.Add(washerFormulaWashStepModel);
                            }

                            //Update Washer Group Formula For Cool Down Step
                            if (washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").Any())
                            {
                                washerModel.washerFormula.CoolDownStep = washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").First().StepNumber;
                            }
                            else
                            {
                                washerModel.washerFormula.CoolDownStep = 0;
                            }
                            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                            washerModel.washerFormula.WasherGroupId = washerModel.washerFormulaWashStep.FirstOrDefault().WasherGroupId;
                            result = Push.PushToLocal(washerModel, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherFormulaWashStep);
                        }
                    }
                }
                if (result == 1 || result == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, new { message = 200 });
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, int.Parse(Regex.Match(ex.Message, @"\d+").Value));
            }
        }

        /// <summary>
        /// Get Formula Details for Copy
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>
        /// Returns the Fromula Details
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetImportFormulaDetails(string ecolabAccountNumber, int washerGroupId, int regionId)
        {
            var user = GetUser();
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);

            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();

            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(-1, ecolabAccountNumber, 1, 0, string.Empty);

            string washerGroupType = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).WasherGroupTypeName;
            int controllerModelId = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).ControllerModelId;
            if (washerGroupType.Equals("Conventional"))
            {
                if (controllerModelId > 6 || controllerModelId != 12 || controllerModelId != 13)
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Conventional") && t.ControllerModelId == controllerModelId).ToList();
                }
                else
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Conventional")).ToList();
                }
            }
            else
            {
                if (controllerModelId > 6 || controllerModelId != 12 || controllerModelId != 13)
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Tunnel") && t.ControllerModelId == controllerModelId).ToList();
                }
                else
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Tunnel")).ToList();
                }
            }

            objWasherGroupFormulaModel.WasherGroupFormulaDetails = new List<WasherGroupFormulaModel>();
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers = new List<WasherGroupFormulaModel>();
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<FormulaModel>>(formulaName);

            WasherGroupFormulaModel washerGroupFormulaModel = new WasherGroupFormulaModel { Formulas = formulaNameDropDown };
            washerGroupFormulaModel.WasherGroupTypeName = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).WasherGroupTypeName;

            foreach (var item in objWasherGroupFormulaModel.WasherGroupDetails)
            {
                IEnumerable<WasherGroupFormula> washerGroupFormula = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, item.WasherGroupId, -1);
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.AddRange(washerGroupFormula.Select(EntityConverter.ConvertToWebModel).ToList().OrderBy(o => o.ProgramNumber).ToList());
            }

            washerGroupFormulaModel.ProgramId = objWasherGroupFormulaModel.WasherGroupFormulaDetails.Where(t => t.WasherGroupId == washerGroupId).ToList().Count > 0 ?
                                                objWasherGroupFormulaModel.WasherGroupFormulaDetails.FirstOrDefault(t => t.WasherGroupId == washerGroupId).ProgramId : 0;
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers.Add(washerGroupFormulaModel);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Save the Formula Data
        /// </summary>
        /// <param name="formulaDataContainer">The formula data container.</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveCopyFormula(Ecolab.TCDConfigurator.Web.Models.WasherGroup.CopyFormulaContainerModel formulaDataContainer)
        {
            var user = GetUser();
            int result = 0;
            bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
            Model.WasherGroup.CopyFormulaContainer copyFormulaList = Mapper.Map<Ecolab.TCDConfigurator.Web.Models.WasherGroup.CopyFormulaContainerModel, Model.WasherGroup.CopyFormulaContainer>(formulaDataContainer);
            try
            {
                if (isDisconnected)
                {
                    this.washerGroupFormulaService.SaveCopyFormula(copyFormulaList, this.UserId);
                }
                else
                {
                    WasherGroupFormulaService objwasherGroupFormulaService = new WasherGroupFormulaService();
                    if (copyFormulaList.FormulaList.FirstOrDefault().WasherGroupTypeName.Equals("Conventional"))
                    {
                        copyFormulaList.IsConventional = true;
                        copyFormulaList.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(user.EcolabAccountNumber);
                    }
                    else
                    {
                        copyFormulaList.IsConventional = false;
                        copyFormulaList.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(user.EcolabAccountNumber);
                    }
                    copyFormulaList.EcolabAccountNumber = user.EcolabAccountNumber;
                    result = Push.PushToLocal(copyFormulaList, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdCopyFormula);

                    if (result == 51030)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
                    }
                    else if (result == 51060)
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51060");
                    }
                    else if (result == 51012)
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, "51012");
                    }
                    else if (result == 60000)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains("51012"))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "51012");
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message.Substring(9, 5));
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, "51033");
        }

        /// <summary>
        ///  Find the missing Chemicals if any
        /// </summary>
        /// <param name="formulaDataContainer">Washer Group Formula object</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage FindMissingChemical(Ecolab.TCDConfigurator.Web.Models.WasherGroup.CopyFormulaContainerModel formulaDataContainer)
        {
            List<object> data = new List<object>();
            var tunnelCannotImport = false;
            try
            {
                Model.WasherGroup.CopyFormulaContainer copyFormulaList = Mapper.Map<Ecolab.TCDConfigurator.Web.Models.WasherGroup.CopyFormulaContainerModel, Model.WasherGroup.CopyFormulaContainer>(formulaDataContainer);
                IEnumerable<ModelChemical.Chemicals> fromWasherGroupChemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);
                IEnumerable<ModelChemical.Chemicals> toWasherGroupChemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().ToWasherGroupId);
                var missingFromChemicals = (from obj1 in fromWasherGroupChemicals where !toWasherGroupChemicals.Any(x => x.ProductId == obj1.ProductId) select obj1).ToList();
                var missingToChemicals = (from obj1 in toWasherGroupChemicals where !fromWasherGroupChemicals.Any(x => x.ProductId == obj1.ProductId) select obj1).ToList();
                IEnumerable<ModelChemical.Chemicals> fromWasherDosingProductList = this.prodMastService.FetchWasherDosingProductList(copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);
                var unusedChemicals = (from obj1 in toWasherGroupChemicals where !fromWasherDosingProductList.Any(x => x.ProductId == obj1.ProductId) select obj1).OrderBy(x => x.Name).ToList();
                data.Add(missingFromChemicals);
                data.Add(unusedChemicals);
                if (missingFromChemicals.ToList().Count > 0 || missingToChemicals.ToList().Count > 0)
                {
                    tunnelCannotImport = true;
                }
                else
                {
                    if (copyFormulaList.FormulaList.FirstOrDefault().WasherGroupTypeName.Equals("Tunnel"))
                    {
                        tunnelCannotImport = this.washerGroupFormulaService.ValidateTunnelSettings(copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().ToWasherGroupId, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);
                    }
                }
                data.Add(tunnelCannotImport);
            }
            catch (SqlException ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message.Substring(9, 5));
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///  Get plant chain id.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <returns>Integer value of plant chain id.</returns>
        [HttpGet]
        public int GetPlantChainId(string ecolabAccountNumber)
        {
            int plantChainId = this.progMasterService.GetPlantChainId(ecolabAccountNumber);
            return plantChainId;
        }

        /// <summary>
        /// Update Washer Formula From Group One
        /// </summary>
        /// <param name="washergroupdata">washergroupdata</param>
        /// <returns></returns>
        public HttpResponseMessage UpdateWasherFormulaFromGroupOne(WasherGroup washergroupdata)
        {
            int error = 0;
            int result = 0;
            washergroupdata.MaxNumberOfRecords = this.washerGroupService.GetMaxNumberOfRecords(washergroupdata.EcolabAccountNumber);
            Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washergroupdata);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupData.WasherGroupId, washerGroupData.EcolabAccountNumber, 0, 0, string.Empty);
            washerGroupModel.FirstOrDefault().MaxNumberOfRecords = washerGroupData.MaxNumberOfRecords;
            Model.User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        if (washerGroupModel.FirstOrDefault().UseGroup1Formulas == false)
                        {
                            washerGroupModel.FirstOrDefault().UseGroup1Formulas = true;
                        }
                        else
                        {
                            washerGroupModel.FirstOrDefault().UseGroup1Formulas = false;
                        }
                        DateTime lastModifiedTimeStamp;
                        washerGroupModel.First().WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupModel.FirstOrDefault(), user.UserId, washergroupdata.EcolabAccountNumber, out lastModifiedTimeStamp);
                        result = washerGroupModel.First().WasherGroupId;
                        return this.Request.CreateResponse(HttpStatusCode.OK, washerGroupModel.FirstOrDefault().UseGroup1Formulas);
                    }
                    else
                    {
                        if (washerGroupModel.FirstOrDefault().UseGroup1Formulas == false)
                        {
                            washerGroupModel.FirstOrDefault().UseGroup1Formulas = true;
                        }
                        else
                        {
                            washerGroupModel.FirstOrDefault().UseGroup1Formulas = false;
                        }
                        int id = 0;
                        washerGroupModel.FirstOrDefault().LastModifiedTimeStamp = DateTime.SpecifyKind(washerGroupModel.First().LastModifiedTimeStamp, DateTimeKind.Utc);
                        error = Push.PushToLocal(washerGroupModel.FirstOrDefault(), user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateWasherGroup, out id);
                        switch (error)
                        {
                            case 51030:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);

                            case 60000:
                                return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                        if (error == 0)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.OK, washerGroupModel.FirstOrDefault().UseGroup1Formulas);
                        }
                    }
                }
            }
            catch
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 111);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 111);
        }
    }
}