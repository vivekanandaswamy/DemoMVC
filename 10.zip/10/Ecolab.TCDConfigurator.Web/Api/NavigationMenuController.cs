﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Models.NavigationMenu;
    using Models.NavigationMenu;
    using Services.Interfaces;
    using Services.Interfaces.NavigationMenu;

    /// <summary>
    ///     class NavigationMenuController Controller
    /// </summary>
    public class NavigationMenuController : BaseApiController
    {
        /// <summary>
        ///     Meter Service
        /// </summary>
        private readonly INavigationMenuService NavigationMenuService;

        /// <summary>
        /// Initializes a new instance of the LeftNavigationController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="navigationMenuService">The navigation menu service.</param>
        public NavigationMenuController(IUserService userService, IPlantService plantService, INavigationMenuService navigationMenuService) : base(userService, plantService)
        {
            this.NavigationMenuService = navigationMenuService;
        }

        /// <summary>
        ///     Gets Dashboard list
        /// </summary>k
        /// <returns>Returns list of Navigation menu list</returns>
        [HttpGet]
        public NavigationMenuDataViewModel FetchNavigationMenuItems()
        {
            NavigationMenuDataViewModel navigationMenuDataViewModel = new NavigationMenuDataViewModel();

            string roles = string.Join(",", this.GetUser().Roles.Select(i => i.Code).ToArray());
            List<NavigationMenuModel> leftNavigationModelList = Mapper.Map<List<NavigationMenu>, List<NavigationMenuModel>>(this.NavigationMenuService.FetchNavigationMenuDetails(this.EcolabAccountNumber, roles));

            navigationMenuDataViewModel.NavigationMenuModelList = leftNavigationModelList;

            List<int> typeIds = leftNavigationModelList.GroupBy(_ => _.TypeId).Select(_ => _.First().TypeId).ToList();

            var leftNavigationViewModelList = new List<NavigationMenuViewModel>();

            foreach (int typeId in typeIds)
            {
                NavigationMenuViewModel mainMenuViewModel = new NavigationMenuViewModel();
                mainMenuViewModel.MainMenu = leftNavigationModelList.Where(_ => _.TypeId == typeId && _.Id == 0).FirstOrDefault();
                List<NavigationMenuModel> menus = leftNavigationModelList.Where(_ => _.TypeId == typeId && _.Id != 0 && _.ParentId == 0).ToList();
                var menuViewModelList = new List<MenuViewModel>();
                foreach (NavigationMenuModel menu in menus)
                {
                    MenuViewModel menuViewModel = new MenuViewModel { Menu = menu };

                    List<NavigationMenuModel> subMenus = leftNavigationModelList.Where(_ => _.TypeId == typeId && _.Id != 0 && _.ParentId != 0 && _.ParentId == menu.Id).ToList();
                    var subMenuViewModelList = new List<SubMenuViewModel>();
                    foreach (NavigationMenuModel subMenu in subMenus)
                    {
                        SubMenuViewModel subMenuViewModel = new SubMenuViewModel { SubMenu = subMenu };

                        subMenuViewModelList.Add(subMenuViewModel);
                    }
                    menuViewModel.SubMenus = subMenuViewModelList;

                    menuViewModelList.Add(menuViewModel);
                }
                mainMenuViewModel.Menus = menuViewModelList;
                leftNavigationViewModelList.Add(mainMenuViewModel);
            }
            navigationMenuDataViewModel.NavigationMenuViewModelList = leftNavigationViewModelList;

            return navigationMenuDataViewModel;
        }
    }
}