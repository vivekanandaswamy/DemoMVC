﻿// -----------------------------------------------------------------------
// <copyright file="SessionRouteHandler.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SessionRouteHandler </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Api
{
    using System.Web;
    using System.Web.Http.WebHost;
    using System.Web.Routing;
    using System.Web.SessionState;

    /// <summary>
    /// Class for Handle the SessionRouteHandler
    /// </summary>
    /// <seealso cref="System.Web.Http.WebHost.HttpControllerRouteHandler" />
    public class SessionRouteHandler : HttpControllerRouteHandler
    {
        /// <summary>
        /// Gets the HTTP handler.
        /// </summary>
        /// <param name="requestContext">The request context.</param>
        /// <returns></returns>
        protected override IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            return new SessionHandler(requestContext.RouteData);
        }
    }
}