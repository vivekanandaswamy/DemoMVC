﻿// -----------------------------------------------------------------------
// <copyright file="PlcTagController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PLC Tag Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using AutoMapper;
    using Dcs.CollectData;
    using Dcs.CollectData.Beckhoff;
    using Dcs.CollectData.Opc;
    using Dcs.Entities;
    using Ecolab.Models.Common;
    using Models.Common;
    using Services.Interfaces;
    using Services.Interfaces.Plc;

    /// <summary>
    ///     Plc Tag Controller
    /// </summary>
    public class PlcTagController : BaseApiController
    {
        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public PlcTagController(IPlcService plcService, IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.plcService = plcService;
        }

        /// <summary>
        ///     Get Controller Info
        /// </summary>
        /// <param name="controllerId">controller</param>
        /// <returns>List of ControllerInfoForPlcModel</returns>
        public List<ControllerInfoForPlcModel> GetControllerInfo(int controllerId)
        {
            Ecolab.Models.User user = this.GetUser();
            return Mapper.Map<List<ControllerInfoForPlc>, List<ControllerInfoForPlcModel>>(this.plcService.GetControllerInfoForPlc(controllerId, user.EcolabAccountNumber));
        }

        /// <summary>
        ///     Validate Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns validated tags with status from PLC</returns>
        public TagCollection ValidateTags(TagCollection tags, int controllerId)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

			if(controllerInfo != null)
			{
				switch(controllerInfo.ControllerTypeId)
				{
				case 1:
					Mapper.CreateMap<Tag, OpcTag>();
					var opcTags = new List<OpcTag>(Mapper.Map<List<Tag>, List<OpcTag>>(tags.Tags));
					opcTags.ForEach(_ => _.Topic = controllerInfo.TopicName);
					return new TagCollection
					{
						Tags = new List<Tag>(ValidateAllenBradleyTags(opcTags, controllerInfo.ControllerId,
							controllerInfo.TopicName, controllerInfo.Value))
					};
				case 2:
					Mapper.CreateMap<Tag, BeckhoffTag>();
					var beckhoffTags = new List<BeckhoffTag>(Mapper.Map<List<Tag>, List<BeckhoffTag>>(tags.Tags));
					return new TagCollection
					{
						Tags = new List<Tag>(ValidateBeckhoffTags(beckhoffTags, controllerInfo.Value, controllerId))
					};
				default:
					return null;
				}
			}
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        ///     Validate Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="topicName">Contrller Topic Name</param>
        /// <param name="opcServer">Controller Opc Server</param>
        /// <returns>Returns validated tags with status from PLC</returns>
        private IEnumerable<OpcTag> ValidateAllenBradleyTags(IList<OpcTag> tags, int controllerId, string topicName,
            string opcServer)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
                string opcItemFormat = ConfigurationManager.AppSettings["OpcItemFormat"];
                DataReader<OpcTag> dataReader =
                    new OpcDataReader(
                        new AllenBradleyController
                        {
                            ControllerId = controllerId,
                            Name = topicName,
                            OpcServer = opcServer
                        },
                        opcItemFormat);
                return dataReader.ReadTags(tags); //, opcServer, comPort);
            }
            catch (Exception ex)
            {
                switch (ex.Message)
                {
                    case "Invalid_Server":
                        throw new NoNullAllowedException("909", ex);
                    default:
                        throw;
                }
            }
        }

        /// <summary>
        ///     Validate Beckhoff Tags
        /// </summary>
        /// <param name="beckhoffTags">List of Beckhoff Tags</param>
        /// <param name="amsNetId">AMS Net id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns></returns>
        private IEnumerable<BeckhoffTag> ValidateBeckhoffTags(IList<BeckhoffTag> beckhoffTags, string amsNetId,
            int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            var beckhoffReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);
            bool status = beckhoffReader.ConnectToPlc(amsNetId, comPort);
            if (status)
            {
                return beckhoffReader.ValidateTags(beckhoffTags);
            }
            throw new ApplicationException("901");
        }

        /// <summary>
        ///     Write Tags to the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns the tags with status from PLC aftre write</returns>
        public TagCollection WriteTags(TagCollection tags, int controllerId)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
			if(controllerInfo != null)
			{
				switch(controllerInfo.ControllerTypeId)
				{
				case 1:
					Mapper.CreateMap<Tag, OpcTag>();
					var opcTags = new List<OpcTag>(Mapper.Map<List<Tag>, List<OpcTag>>(tags.Tags));
					opcTags.ForEach(_ => _.Topic = controllerInfo.TopicName);
					return new TagCollection
					{
						Tags = new List<Tag>(WriteAllenBradleyTags(opcTags, controllerInfo.ControllerId,
							controllerInfo.TopicName, controllerInfo.Value))
					};
				case 2:
					Mapper.CreateMap<Tag, BeckhoffTag>();
					var beckhoffTags = new List<BeckhoffTag>(Mapper.Map<List<Tag>, List<BeckhoffTag>>(tags.Tags));
					return new TagCollection
					{
						Tags = new List<Tag>(WriteBeckhoffTags(beckhoffTags, controllerInfo.Value, controllerId))
					};
				default:
					return null;
				}
			}
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        ///     Write Allen Bradley Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="topicName">Contrller Topic Name</param>
        /// <param name="opcServer">Controller Opc Server</param>
        /// <returns>Returns validated tags with status from PLC</returns>
        private IEnumerable<OpcTag> WriteAllenBradleyTags(IList<OpcTag> tags, int controllerId, string topicName,
            string opcServer)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            string opcItemFormat = ConfigurationManager.AppSettings["OpcItemFormat"];
            DataWriter<OpcTag> dataWriter =
                new OpcDataWriter(
                    new AllenBradleyController { ControllerId = controllerId, Name = topicName, OpcServer = opcServer },
                    opcItemFormat);
            return dataWriter.WriteTags(tags);
        }

        /// <summary>
        ///     Write Beckhoff Tags
        /// </summary>
        /// <param name="beckhoffTags">List of Beckhoff Tags</param>
        /// <param name="amsNetId">AMS Net id</param>
        /// <param name="controllerId"></param>
        /// <returns></returns>
        private IEnumerable<BeckhoffTag> WriteBeckhoffTags(IList<BeckhoffTag> beckhoffTags, string amsNetId,
            int controllerId)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
                var beckhoffWriter =
                    new BeckoffDataWriter(
                        new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort },
                        string.Empty, amsNetId, comPort);
                beckhoffWriter.ConnectToPlc(amsNetId, comPort);

                return beckhoffWriter.WriteTags(beckhoffTags);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("902", ex);
            }
        }
    }
}