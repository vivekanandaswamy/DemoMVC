﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Labor Cost Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Utilities;
    using Model = Ecolab.Models.PlantSetup.ShiftLabor;
    
    public class TargetProductionController : BaseApiController
    {
        /// <summary>
        ///     Shift Break Service
        /// </summary>
        private readonly IShiftBreakService shiftBreakService;

        /// <summary>
        ///     Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="shiftBreakService">shiftBreakService</param>
        public TargetProductionController(IUserService userService, IPlantService plantService, IShiftBreakService shiftBreakService)
            : base(userService, plantService)
        {
            this.shiftBreakService = shiftBreakService;
        }

        /// <summary>
        ///     Method to fetch target production details
        /// </summary>
        /// <returns>List of target production</returns>
        [HttpGet]
        public TargetProdDetails FetchTargetProductionDetails()
        {
            User user = this.GetUser();
            List<Model.TargetProduction> targetProd = this.shiftBreakService.FetchTargetProductionDetails(user.EcolabAccountNumber);
            List<TargetProduction> prodList = Mapper.Map<List<Model.TargetProduction>, List<TargetProduction>>(targetProd);
            IEnumerable<string> shifts = prodList.AsEnumerable().Where(y => y.ShiftName != null).Select(x => x.ShiftName).Distinct();
            var details = targetProd.AsEnumerable().Select(x => x).GroupBy(s => new { s.ShiftName }).ToDictionary(a => a.Key, a => a.ToList());
            TargetProdDetails objTpDetails = new TargetProdDetails();
            objTpDetails.Sunday = new TargetProductionData();
            objTpDetails.Monday = new TargetProductionData();
            objTpDetails.Tuesday = new TargetProductionData();
            objTpDetails.Wednesday = new TargetProductionData();
            objTpDetails.Thursday = new TargetProductionData();
            objTpDetails.Friday = new TargetProductionData();
            objTpDetails.Saturday = new TargetProductionData();
            objTpDetails.Shift = new List<string>();
            objTpDetails.Shift.AddRange(shifts);
            int[] days = { 1, 2, 3, 4, 5, 6, 7 };
            foreach (var item1 in details)
            {
                int[] shiftDays = item1.Value.AsEnumerable().Select(x => x.DayId).ToArray();
                int[] remainingDays = null;
                foreach (Model.TargetProduction item in details[item1.Key])
                {
                    remainingDays = days.Except(shiftDays).ToArray();
                    BindTargetProduction(objTpDetails, item);
                }
                foreach (int item in remainingDays)
                {
                    switch (item)
                    {
                        case 1:
                            if (objTpDetails.Sunday.DayData != null)
                            {
                                objTpDetails.Sunday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Sunday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                                objTpDetails.Sunday.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                            }
                            break;
                        case 2:
                            if (objTpDetails.Monday.DayData != null)
                            {
                                objTpDetails.Monday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Monday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 3:
                            if (objTpDetails.Tuesday.DayData != null)
                            {
                                objTpDetails.Tuesday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Tuesday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 4:
                            if (objTpDetails.Wednesday.DayData != null)
                            {
                                objTpDetails.Wednesday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Wednesday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 5:
                            if (objTpDetails.Thursday.DayData != null)
                            {
                                objTpDetails.Thursday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Thursday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 6:
                            if (objTpDetails.Friday.DayData != null)
                            {
                                objTpDetails.Friday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Friday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 7:
                            if (objTpDetails.Saturday.DayData != null)
                            {
                                objTpDetails.Saturday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Saturday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                    }
                }
            }

            return sortDays(objTpDetails);
        }

        private TargetProdDetails sortDays(TargetProdDetails objTpDetails)
        {
            string[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
            var currentDay = DateTime.Now.DayOfWeek.ToString();
            List<string> sortedDays = days.Skip(Array.IndexOf(days, currentDay)).ToList();
            List<string> finalList = new List<string>();
            finalList.AddRange(sortedDays);
            finalList.AddRange(days.Except(finalList));
            return SetDisplayOrder(objTpDetails, finalList);
        }

        private TargetProdDetails SetDisplayOrder(TargetProdDetails objTpDetails, List<string> days)
        {
            objTpDetails.Sunday.DisplayOrder = days.IndexOf("Sunday");
            objTpDetails.Sunday.Date = BindDate(days.IndexOf("Sunday"));
            objTpDetails.Monday.DisplayOrder = days.IndexOf("Monday");
            objTpDetails.Monday.Date = BindDate(days.IndexOf("Monday"));
            objTpDetails.Tuesday.DisplayOrder = days.IndexOf("Tuesday");
            objTpDetails.Tuesday.Date = BindDate(days.IndexOf("Tuesday"));
            objTpDetails.Wednesday.DisplayOrder = days.IndexOf("Wednesday");
            objTpDetails.Wednesday.Date = BindDate(days.IndexOf("Wednesday"));
            objTpDetails.Thursday.DisplayOrder = days.IndexOf("Thursday");
            objTpDetails.Thursday.Date = BindDate(days.IndexOf("Thursday"));
            objTpDetails.Friday.DisplayOrder = days.IndexOf("Friday");
            objTpDetails.Friday.Date = BindDate(days.IndexOf("Friday"));
            objTpDetails.Saturday.DisplayOrder = days.IndexOf("Saturday");
            objTpDetails.Saturday.Date = BindDate(days.IndexOf("Saturday"));
            return objTpDetails;
        }

        private string BindDate(int daysToAdd)
        {
            return DateTime.Now.AddDays(daysToAdd).ToString("MM/dd/yyyy");
        }

        /// <summary>
        ///     Method to build target production class for view
        /// </summary>
        /// <param name="objTpDetails"></param>
        /// <param name="item"></param>
        private void BindTargetProduction(TargetProdDetails objTpDetails, Model.TargetProduction item)
        {
            User user = this.GetUser();
            List<Model.Shift> runningShifts = this.shiftBreakService.FetchRunningShiftDetails();
            switch (item.DayId)
            {
                case 1:
                    if (objTpDetails.Sunday.DayData != null)
                    {
                        objTpDetails.Sunday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdDisplay = item.TargetProd,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Sunday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Sunday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, 
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                              IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Sunday ? (runningShifts.Exists(x=>x.ShiftName == item.ShiftName) ? false : true) : true
                        } };
                    }
                    objTpDetails.Sunday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 2:
                    if (objTpDetails.Monday.DayData != null)
                    {
                        objTpDetails.Monday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Monday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Monday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                              IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Monday ? (runningShifts.Exists(x=>x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    objTpDetails.Monday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 3:
                    if (objTpDetails.Tuesday.DayData != null)
                    {
                        objTpDetails.Tuesday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Tuesday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd, 
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    objTpDetails.Tuesday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 4:
                    if (objTpDetails.Wednesday.DayData != null)
                    {
                        objTpDetails.Wednesday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Wednesday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd, 
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true } };
                    }
                    objTpDetails.Wednesday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 5:
                    if (objTpDetails.Thursday.DayData != null)
                    {
                        objTpDetails.Thursday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Thursday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Thursday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Thursday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    objTpDetails.Thursday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 6:
                    if (objTpDetails.Friday.DayData != null)
                    {
                        objTpDetails.Friday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Friday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Friday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                           IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Friday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    objTpDetails.Friday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
                case 7:
                    if (objTpDetails.Saturday.DayData != null)
                    {
                        objTpDetails.Saturday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Saturday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Saturday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                           IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Saturday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    objTpDetails.Saturday.DayData.ConvertUnit(GetPlantDetails().UOMId, user.EcolabAccountNumber, user.UserId, false, 0);
                    break;
            }
        }

        /// <summary>
        ///     Update Target production Details
        /// </summary>
        /// <param name="data">List of Target production</param>
        /// <returns>Update status code</returns>
        [HttpPost]
        public HttpResponseMessage Put(IEnumerable<TargetProduction> data)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            string status = string.Empty;
            data = data.ToList().ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetUser().UserId, true, 0);
            List<Model.TargetProduction> targetProductionLists = Mapper.Map<IEnumerable<TargetProduction>, IEnumerable<Model.TargetProduction>>(data).ToList();
            targetProductionLists.FirstOrDefault().MaxNumberOfRecords =
                this.shiftBreakService.GetMaxNumberOfRecordsForTargetProduction(user.EcolabAccountNumber);
            targetProductionLists.FirstOrDefault().EcolabAccountNumber = user.EcolabAccountNumber;
            if (user != null)
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTime = DateTime.UtcNow;
                    status = this.shiftBreakService.SaveTargetProduction(targetProductionLists.AsEnumerable(),
                    user.EcolabAccountNumber, user.UserId, out lastModifiedTime);
                }
                else
                {
                    Model.TargetProductionContainer targetProductionContainer = new Model.TargetProductionContainer();
                    targetProductionContainer.TargetProduction = targetProductionLists;
                    Push.PushToLocal(targetProductionContainer, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateTargetProduction);
                }
            }
            return (status == "201") ? this.Request.CreateResponse(HttpStatusCode.OK, status) : this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
        }
    }
}