﻿// -----------------------------------------------------------------------
// <copyright file="PumpsController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Pump Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.ControllerSetup.Pumps;
    using Elmah;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Plc;
    using Model = Ecolab.Models;
    using PumpsModel = Models.ControllerSetup.Pumps.PumpsModel;

    /// <summary>
    ///     Api Controller for Pumps/Valves
    /// </summary>
    public class PumpsController : BaseApiController
    {
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Pumps Setup Service
        /// </summary>
        private readonly IPumpsService pumpServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PumpsController" /> class.
        /// </summary>
        /// <param name="pumpServices">The pump services.</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public PumpsController(IPumpsService pumpServices, IPlcService plcService, IUserService userService,
            IPlantService plantService)
            : base(userService, plantService)
        {
            this.pumpServices = pumpServices;
            this.plcService = plcService;
        }

        /// <summary>
        ///     To Get the Product List
        /// </summary>
        /// <param name="ecolabAccountNumber">The eco lab account number.</param>
        /// <returns>Product List</returns>
        [HttpGet]
        public List<ProductModel> GetProductList(string ecolabAccountNumber)
        {
            Model.User user = this.GetUser();
            try
            {
                List<ProductModel> products = this.pumpServices.GetProductList(user.EcolabAccountNumber);
                return products.ToList();
            }
            catch
            {
                return new List<ProductModel>();
            }
        }

        /// <summary>
        ///     Getting All Pumps based on Controller id and EcoLab AccountNumber
        /// </summary>
        /// <param name="ecolabAccountNumber">EcoLabAccountNumber</param>
        /// <param name="controlNumber">Control Number</param>
        /// <param name="showOption">Option value(Active/Inactive)</param>
        /// <returns>Pumps List</returns>
        public List<PumpsModel> GetPumps(string ecolabAccountNumber, int controlNumber, string showOption, int controllerModelId)
        {
            try
            {
                if (showOption == "All")
                {
                    showOption = string.Empty;
                }

                List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel> pumpDataModel = this.pumpServices.GetPumps(ecolabAccountNumber, controlNumber, showOption);
                List<PumpsModel> pumpMetaData = Mapper.Map<List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel>, List<PumpsModel>>(pumpDataModel);
                pumpMetaData.ForEach(_ => _.PumpCalibrationAsString = _.PumpCalibration == 0 ? "0" : _.PumpCalibration.ToString("#,0.0#"));
                pumpMetaData.ForEach(_ => _.KFactorAsString = _.KFactor == 0 ? "0" : _.KFactor.ToString("#,0.0#"));
                return pumpMetaData;
            }
            catch(Exception ex)
            {
                return new List<PumpsModel>();
            }
        }

        /// <summary>
        /// Updating Pump Details
        /// </summary>
        /// <param name="pumpDataList">The pump data list.</param>
        /// <returns>
        /// Success
        /// </returns>
        [HttpPost]
        public HttpResponseMessage UpdatePump(List<PumpsModel> pumpDataList)
        {
            try
            {
                Model.User user = this.GetUser();
                int result = 0;
                bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
                Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = null;
                foreach (PumpsModel pumpData in pumpDataList)
                {
                    objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
                    objPumpData.LastModifiedTimeStamp = DateTime.SpecifyKind(objPumpData.LastModifiedTimeStamp, DateTimeKind.Utc);
                    objPumpData.EcolabAccountNumber = user.EcolabAccountNumber;
                    objPumpData.MaxNumberOfRecords = pumpServices.GetMaxNumberOfRecords(objPumpData.EcolabAccountNumber);
                    if (isDisconnected)
                    {
                        DateTime lastModifiedTimeStamp;
                        int response = pumpServices.UpdatePump(objPumpData, UserId, out lastModifiedTimeStamp, null);
                        pumpData.LastModifiedTimeStamp = lastModifiedTimeStamp;
                    }
                    else
                    {
                        result = Push.PushToLocal(objPumpData, user.EcolabAccountNumber, user.UserId,
                            (int)TcdAdminMessageTypes.TcdUpdatePump);
                    }
                    switch (result)
                    {
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        case 51060:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 60000:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        case 8014:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 8014);
                    }

                    if (objPumpData.ControllerId > 0)
                    {
                        // return this.Request.CreateResponse(HttpStatusCode.OK);
                        pumpData.HttpStatusCode = (int)HttpStatusCode.OK;
                        // pumpData.Eorror = "60000";
                    }

                    switch (objPumpData.ControllerId)
                    {
                        case 301:
                            // return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                            pumpData.HttpStatusCode = (int)HttpStatusCode.BadRequest;
                            pumpData.Eorror = "301";
                            break;

                        case 302:
                            // return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                            pumpData.HttpStatusCode = (int)HttpStatusCode.BadRequest;
                            pumpData.Eorror = "302";
                            break;

                        case 303:
                            // return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                            pumpData.HttpStatusCode = (int)HttpStatusCode.BadRequest;
                            pumpData.Eorror = "303";
                            break;
                    }

                    if (this.RoleId >= 8)
                    {
                        if (pumpData.OverridePlcValues)
                        {
                            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                            plc.WriteTags(new TagCollection { Tags = new List<Tag>(pumpData.PlcTags) }, pumpData.ControllerId);
                        }
                    }
                }

                if (pumpDataList != null && pumpDataList.Count > 0)
                {
                    return this.Request.CreateResponse((HttpStatusCode)Enum.Parse(typeof(HttpStatusCode), pumpDataList[0].HttpStatusCode.ToString(), true), pumpDataList[0].Eorror);
                }
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message);
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }

        /// <summary>
        ///     To Get the Pump Models Model List
        /// </summary>
        /// <returns>PumpModelsModel List</returns>
        [HttpGet]
        public List<PumpModelsModel> GetPumpModels()
        {
            try
            {
                return this.pumpServices.GetPumpModels().ToList();
            }
            catch
            {
                return new List<PumpModelsModel>();
            }
        }

        /// <summary>
        ///     To Get the Pump Models Model List
        /// </summary>
        /// <returns>PumpModelsModel List</returns>
        /// <param name="lineNo">The line Number</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="equipmentId">The Equipment Id</param>
        [HttpGet]
        public List<LineCompartmentMappingModel> GetLineData(int lineNo, int controllerId, int equipmentId = 0)
        {
            try
            {
                return this.pumpServices.GetLineData(lineNo, controllerId, equipmentId, this.EcolabAccountNumber).ToList();
            }
            catch
            {
                return new List<LineCompartmentMappingModel>();
            }
        }

        /// <summary>
        ///     To Get the Pump Models Model List
        /// </summary>
        /// <returns>PumpModelsModel List</returns>
        /// <param name="controllerId">The Controller Id</param>
        [HttpGet]
        public List<ControllerDataModel> GetControllerData(int controllerId)
        {
            try
            {
                return this.pumpServices.GetControllerData(controllerId, EcolabAccountNumber).ToList();
            }
            catch
            {
                return new List<ControllerDataModel>();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controllerEquipSetupId"></param>
        /// <returns></returns>
        public List<Web.Models.ControllerSetup.Pumps.LineCompartmentMappingModel> GetCompartmentValveData(int controllerEquipSetupId, int washerGroupNumber, int controllerEquipmentTypeId)
        {
            List<LineCompartmentMappingModel> tunnelCmptValvelist = this.pumpServices.GetCompartmentValveData(controllerEquipSetupId, washerGroupNumber, controllerEquipmentTypeId, this.EcolabAccountNumber).ToList();
            return Mapper.Map<List
                <LineCompartmentMappingModel>, List<Web.Models.ControllerSetup.Pumps.LineCompartmentMappingModel>>(tunnelCmptValvelist);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controllerId"></param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns></returns>
        public List<Web.Models.ControllerSetup.Pumps.ProductModel> GetPumpsProducts(int controllerId, string ecolabAccountNumber)
        {
            List<ProductModel> pumpsProductList = this.pumpServices.GetPumpsProductData(controllerId, ecolabAccountNumber);
            return Mapper.Map<List
                <ProductModel>, List<Web.Models.ControllerSetup.Pumps.ProductModel>>(pumpsProductList);
        }
        public List<Web.Models.ControllerSetup.Pumps.SetupDosingLineModel> GetAuxiliaryPumpData(int LineNumber, int controllerid)
        {
            List<SetupDosingLine> dosingLinelsList = this.pumpServices.GetAuxiliaryPumpData(LineNumber, controllerid, EcolabAccountNumber);
            return Mapper.Map<List
                <SetupDosingLine>, List<Web.Models.ControllerSetup.Pumps.SetupDosingLineModel>>(dosingLinelsList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pumpProductdata"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage SavePumpsProducts(List<Web.Models.ControllerSetup.Pumps.ProductModel> pumpProductdata)
        {
            Model.User user = this.GetUser();

            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            List<Ecolab.Models.ControllerSetup.Pumps.ProductModel> objpumpProductdata = Mapper.Map<List<Web.Models.ControllerSetup.Pumps.ProductModel>, List<Ecolab.Models.ControllerSetup.Pumps.ProductModel>>(pumpProductdata);

            //for
            //objpumpProductdata = user.EcolabAccountNumber;
            //objpumpProductdata.MaxNumberOfRecords = pumpServices.GetMaxNumberOfRecords(objPumpData.EcolabAccountNumber);
            
            //PumpsProductContainer pumpsProductContainer = new PumpsProductContainer();
            //DateTime lastModifiedTime;
            //try
            //{                

            //    this.pumpServices.SavePumpsProducts(objPumpProductData, pumpProductdata[0].ControllerId, EcolabAccountNumber, out lastModifiedTime);

            //    List<Ecolab.Models.ControllerSetup.Pumps.ProductModel> listPumpsProduct = this.pumpServices.GetPumpsProductData(pumpProductdata[0].ControllerId, EcolabAccountNumber);
            //    foreach (var item in listPumpsProduct)
            //    {
            //        item.LastModifiedTime = DateTime.SpecifyKind(item.LastModifiedTime, DateTimeKind.Utc);
            //    }
            //    pumpsProductContainer.LstProductModel = listPumpsProduct;

            //    Push.PushToQueue(pumpsProductContainer, this.UserId, pumpsProductContainer.LstProductModel[0].PumpsProductId, (int)TcdAdminMessageTypes.TcdAddPumpsProduct, EcolabAccountNumber);

            //    return this.Request.CreateResponse(HttpStatusCode.OK, pumpProductdata);
            //}
            //catch (Exception ex)
            //{
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, string.Empty);
            //}
        }

    }
}