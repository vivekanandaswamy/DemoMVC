﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Controller Setup Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.ControllerSetup;
    using Elmah;
    using Models.ControllerSetup;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Utilities;
    using Controller = Ecolab.Models.ControllerSetup.Controller;
    using ControllerModel = Models.ControllerSetup.ControllerModel;
    using ControllerType = Ecolab.Models.ControllerSetup.ControllerType;
    using EntityConverter = Helper.EntityConverter;

    /// <summary>
    ///     class ControllerSetup Controller
    /// </summary>
    public class ControllerSetupController : BaseApiController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="controllerSetupService">The Controller Setup service.</param>
        public ControllerSetupController(IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService)
            : base(userService, plantService)
        {
            this.controllerSetupService = controllerSetupService;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="controllerSetupService">The Controller Setup service.</param>
        /// <param name="plcService"> PLC service.</param>
        public ControllerSetupController(IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.controllerSetupService = controllerSetupService;
            this.plcService = plcService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get Controller Setup Meta Data
        /// </summary>
        /// <param name="tabId">Tab Id</param>
        /// <param name="controllerModelId">controller Model Id</param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <returns>Returns the Controller Setup Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupMetaData(int tabId, int controllerModelId, int controllerTypeId)
        {
            List<MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadata(tabId, controllerModelId, controllerTypeId, this.RoleId);
            List<MetaDataModel> controllerSetupMetaData = Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
            return controllerSetupMetaData;
        }

        /// <summary>
        ///     Get Controller Setup Meta Data with Values
        /// </summary>
        /// <param name="tabId">Tab Id</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns the Controller Setup Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupMetaDataWithValues(int tabId, int controllerId)
        {
            User user = this.GetUser();
            List<MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(tabId, controllerId, user.EcolabAccountNumber, this.RoleId);
            List<MetaDataModel> controllerSetupMetaData = Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
            foreach (MetaDataModel metaDataModel in controllerSetupMetaData)
            {
                int fieldCount = metaDataModel.FieldGroupInfo.Count();
                for (int i = 0; i < fieldCount; i++)
                {
                    if (metaDataModel.FieldGroupInfo.ElementAt(i).FieldType == "DATETIME")
                    {
                        if (!string.IsNullOrEmpty(metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue))
                        {
                            DateTime installDate = DateTime.ParseExact(metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue, "d", CultureInfo.InvariantCulture);
                            metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue = installDate.ToString("d");
                        }
                    }
                }
            }

            if (controllerSetupService.IsSetupAdvanceDataExist(3, controllerId, EcolabAccountNumber))
            {
                controllerSetupMetaData[0].HasPumps = true;
            }
            return controllerSetupMetaData;
        }

        /// <summary>
        ///     Get Controller Details
        /// </summary>
        /// <returns>Returns the Controller Details</returns>
        public IEnumerable<ControllerModel> GetControllerDetails()
        {
            User user = this.GetUser();
            List<Controller> controllerModel = this.controllerSetupService.GetControllerDetails(user.EcolabAccountNumber).ToList();
            List<ControllerModel> controller = Mapper.Map<List<Controller>, List<ControllerModel>>(controllerModel);
            controller = controller.Where(item => item.IsDelete == false).ToList();
            controller.ForEach(_ => _.InstallDateAsString = _.InstallDate.ToString("d"));
            return controller.OrderBy(x => x.ControllerNumber);
        }

        /// <summary>
        ///     Get Controller Details By Id.
        /// </summary>
        /// <param name="controllerId">ControllerId</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>Controller model</returns>
        public ControllerModel GetControllerDetailById(int controllerId, string ecolabAccountNumber)
        {
            User user = this.GetUser();
            Controller controllerModel = this.controllerSetupService.GetControllerDetailById(controllerId, user.EcolabAccountNumber);
            ControllerModel controller = Mapper.Map<Controller, ControllerModel>(controllerModel);
            controller.InstallDateAsString = controller.InstallDate.ToString("d");
            return controller;
        }

        /// <summary>
        ///     Get Controller Setup Advance Meta Data/Values
        /// </summary>
        /// <param name="tabId">Tab Id</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns the Controller Setup Advance Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupAdvanceMetaData(int tabId, int controllerId)
        {
            User user = this.GetUser();
            List<MetaData> controllerSetupMetaDataModel;
            List<string> tagCollectionList = new List<string>();
            if (controllerSetupService.IsSetupAdvanceDataExist(tabId, controllerId, user.EcolabAccountNumber))
            {
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
                List<OpcTag> tagsList = null;
                List<OpcTag> tags = null;
                TagCollection tagStatus = new TagCollection { Tags = new List<Tag>() };

                controllerSetupMetaDataModel = controllerSetupService.GetControllerSetupAdvanceMetadataWithValues(
                    tabId, controllerId, user.EcolabAccountNumber);

                var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, controllerId);
                bool awea = fieldTags.AWEActive == true ? true : false;
                bool ratioDosing = fieldTags.RatioDosingActive == true ? true : false;

                var aweaFields = controllerSetupMetaDataModel.FirstOrDefault().FieldGroupInfo.Where(x => x.FieldResourceKey.Trim().ToUpper().Equals("AUTOMATIC_WEIGHT_ENABLED"));
                if (aweaFields.Any())
                {
                    aweaFields.FirstOrDefault().FieldDefaultValue = awea.ToString().ToLower();
                }

                var ratioDosingFields = controllerSetupMetaDataModel.FirstOrDefault().FieldGroupInfo.Where(x => x.FieldResourceKey.Trim() == "Ratio_Dosing_Enabled");
                if (ratioDosingFields.Any())
                {
                    ratioDosingFields.FirstOrDefault().FieldDefaultValue = ratioDosing.ToString().ToLower();
                }

                if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 7 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8)
                {
                    foreach (MetaData item in controllerSetupMetaDataModel)
                    {
                        for (int i = 0; i < item.FieldGroupInfo.Count(); i++)
                        {
                            if (item.FieldGroupInfo[0].ControllerModelId == 7)
                            {
                                if (item.FieldGroupInfo[i].FieldDefaultValue == "0" && item.FieldGroupInfo[i].FieldType != "TEXT")
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "false";
                                }
                                if (item.FieldGroupInfo[i].FieldDefaultValue == "1" && item.FieldGroupInfo[i].FieldType != "TEXT")
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "true";
                                }
                            }

                            if (!string.IsNullOrEmpty(item.FieldGroupInfo[i].DataSourceKeyValue) && item.FieldGroupInfo[i].FieldClassName == "DosingLines")
                            {
                                item.FieldGroupInfo[i].DataSourceKeyValue = "0:0;" + item.FieldGroupInfo[i].DataSourceKeyValue;
                                if (item.FieldGroupInfo[i].DataSourceInfo != null)
                                {
                                    FieldSource fs = new FieldSource();
                                    fs.DataSourceId = 7;
                                    fs.Name = "0";
                                    fs.Value = "0";

                                    item.FieldGroupInfo[i].DataSourceInfo.Insert(0, fs);
                                }
                            }
                        }                        
                    }
                }

                IEnumerable<ControllerSetupMetaData> controllerTags =
                    controllerSetupMetaDataModel[0].FieldGroupInfo.Where(
                        _ => !string.IsNullOrWhiteSpace(_.TagDefaultValue));
                tagsList = new List<OpcTag>();
                foreach (ControllerSetupMetaData item in controllerTags)
                {
                    tagsList.Add(new OpcTag { Address = item.TagDefaultValue, Value = item.FieldDefaultValue });
                }

                tags = tagsList.Clone();
                foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                {
                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                        {
                            tagCollectionList.Add(tag.Address);
                        }
                    }
                }
            }
            else
            {
                controllerSetupMetaDataModel = controllerSetupService.GetControllerSetupAdvanceMetadata(tabId,
                    controllerId, EcolabAccountNumber);

                if(controllerSetupMetaDataModel != null && controllerSetupMetaDataModel.Count > 0)
                {
                    if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 7 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8)
                    {
                        foreach (MetaData item in controllerSetupMetaDataModel)
                        {
                            for (int i = 0; i < item.FieldGroupInfo.Count(); i++)
                            {
                                if (!string.IsNullOrEmpty(item.FieldGroupInfo[i].DataSourceKeyValue) && item.FieldGroupInfo[i].FieldClassName == "DosingLines")
                                {
                                    item.FieldGroupInfo[i].DataSourceKeyValue = "0:0;" + item.FieldGroupInfo[i].DataSourceKeyValue;
                                    if (item.FieldGroupInfo[i].DataSourceInfo != null)
                                    {
                                        FieldSource fs = new FieldSource();
                                        fs.DataSourceId = 7;
                                        fs.Name = "0";
                                        fs.Value = "0";

                                        item.FieldGroupInfo[i].DataSourceInfo.Insert(0, fs);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            List<MetaDataModel> controllerSetupMetaData = Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
			if (controllerSetupMetaData != null && controllerSetupMetaData.Count > 0)
			{
				foreach (ControllerSetupMetaDataModel metaData in controllerSetupMetaData[0].FieldGroupInfo)
				{
					foreach (var item in tagCollectionList.Where(item => metaData.TagDefaultValue == item))
					{
						metaData.OverrideValues = true;
					}
				}
				if (controllerSetupService.IsSetupAdvanceDataExist(3, controllerId, EcolabAccountNumber))
				{
					controllerSetupMetaData[0].HasPumps = true;
				} 
			}
            return controllerSetupMetaData;
        }

        /// <summary>
        ///     Get Controller Models Detail
        /// </summary>
        /// <returns>Returns the Controller Models Detail</returns>
        public IEnumerable<ControllerModelModel> GetControllerModelsDetails(int regionId)
        {
            List<Ecolab.Models.ControllerSetup.ControllerModel> controllerModelModel = this.controllerSetupService.GetControllerModelsDetails(regionId).ToList();
            List<ControllerModelModel> controllerModels = Mapper.Map<List<Ecolab.Models.ControllerSetup.ControllerModel>, List<ControllerModelModel>>(controllerModelModel);
            return controllerModels;
        }

        /// <summary>
        ///     Get Controller Type Detail
        /// </summary>
        /// <returns>Returns the Controller Types Detail</returns>
        public IEnumerable<ControllerTypeModel> GetControllerTypesDetails(int controllerModelId)
        {
            List<ControllerType> controllerTypeModel = this.controllerSetupService.GetControllerTypesDetails(controllerModelId).ToList();
            List<ControllerTypeModel> controllerTypes = Mapper.Map<List<ControllerType>, List<ControllerTypeModel>>(controllerTypeModel);
            return controllerTypes;
        }

        /// <summary>
        ///     To update the Controller details
        /// </summary>
        /// <param name="data">Controller data to update</param>
        /// <returns>Returns updated controller data</returns>
        [HttpPost]
        public HttpResponseMessage UpdateControllerDetails(ControllerModel data)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            if (data.ControllerId <= 0)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid Dispenser details.");
            }
            Controller controller = EntityConverter.ConvertToServiceModel(data);
            controller.LastModifiedTimeStamp = DateTime.SpecifyKind(controller.LastModifiedTimeStamp, DateTimeKind.Utc);
            controller.MaxNumberOfRecords = controllerSetupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
            try
            {
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    controllerSetupService.UpdateControllerListData(controller, UserId,
                        user.EcolabAccountNumber, out lastModifiedTimeStamp);
                }
                else
                {
                    int retVal = Push.PushToLocal(controller, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateControllerSetupListing);

                    if (retVal != 0)
                    {
                        if (retVal == 51030)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        }
                        else if (retVal == 60000)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                        else if (retVal == 51060)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        }
                        else
                        {
                            string errorMessage = (retVal == 303)
                                ? "Dispenser Number already exists."
                                : "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
                            return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Logger.Error("Api - Controller - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                    ex.Number == 2627
                        ? "Dispenser Id already exists. Please try again."
                        : "Unable to update the Dispenser. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Delete the Controller
        /// </summary>
        /// <param name="controllerId">Delete the Controller based on ID</param>
        /// <returns>Returns the Controller data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteController(int? controllerId)
        {
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            if (!(controllerId > 0))
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid Dispenser details.");
            }
            try
            {
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                if (isDisconnected)
                {
                    this.controllerSetupService.DeleteControllerListData(controllerId.Value, this.UserId, user.EcolabAccountNumber, out lastModifiedTimeStamp);
                }
                else
                {
                    Controller controllerModel = this.controllerSetupService.GetControllerDetailById(controllerId.Value, user.EcolabAccountNumber);
                    controllerModel.IsDelete = true;
                    controllerModel.LastModifiedTimeStamp = DateTime.SpecifyKind(controllerModel.LastModifiedTimeStamp, DateTimeKind.Utc);
                    controllerModel.MaxNumberOfRecords = controllerSetupService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
                    int retVal = Push.PushToLocal(controllerModel, user.EcolabAccountNumber, user.UserId,
                        (int)TcdAdminMessageTypes.TcdDeleteControllerSetupListing);

                    if (retVal != 0)
                    {
                        if (retVal == 51030)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        }
                        else if (retVal == 60000)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
                        }
                        else if (retVal == 51060)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        }
                        else
                        {
                            string errorMessage = (retVal == 303)
                                ? "Dispenser Number already exists."
                                : "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
                            return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("Api - Formula - Delete Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                    "Unable to delete the Dispenser. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, controllerId);
        }

        /// <summary>
        ///     Delete the Controller data
        /// </summary>
        /// <param name="data">Delete the Controller datas</param>
        /// <returns>Returns the Controller data by Id</returns>
        public HttpResponseMessage DeleteController(ControllerModel data)
        {
            return this.DeleteController(data.ControllerId);
        }

        /// <summary>
        ///     Save the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>Returns Controller Id</returns>
        [HttpPost]
        public HttpResponseMessage SaveControllerSetupData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            int controllerId = 0;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            try
            {
                var user = GetUser();
                bool isDisconnected = PlantService.IsPlantConnected(user.EcolabAccountNumber);
                List<ControllerSetupData> ctrlSetupData =
                    Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);
                if (user != null)
                {
                    if (isDisconnected)
                    {
                        controllerId = this.controllerSetupService.SaveControllerSetupData(ctrlSetupData, user.UserId,
                            out lastModifiedTimeStamp);
                    }
                    else
                    {
                        ControllerSetupData objControllerSetupData = ctrlSetupData.FirstOrDefault();
                        if (objControllerSetupData != null)
                        {
                            ControllerSetupDataDetails ctrlSetupDataDetails = new ControllerSetupDataDetails
                            {
                                ControllerSetupList = ctrlSetupData,
                                ControllerId = controllerId,
                                UserId = user.UserId,
                                EcolabAccountNumber = user.EcolabAccountNumber,
                                LastModifiedTimeStamp = lastModifiedTimeStamp,
                                MaxNumberOfRecords =
                                    this.controllerSetupService.GetMaxNumberOfRecords(user.EcolabAccountNumber)
                            };
                            int retVal = Push.PushToLocal(ctrlSetupDataDetails, ctrlSetupDataDetails.EcolabAccountNumber,
                                user.UserId, (int)TcdAdminMessageTypes.TcdAddController, out controllerId);
                            if (retVal != 0)
                            {
                                if (retVal == 51030 || retVal == 60000)
                                {
                                        return Request.CreateResponse(HttpStatusCode.BadRequest,
                                            "Local plant not in sync with Central. Resync in progress. Please try later.");
                                    }
                                else if (retVal == 51060)
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                                        "Unable to save changes , Connectivity issue, Please try again later.");
                                }
                                else if (retVal == 303)
                                    {
                                        string errorMessage = (retVal == 303)
                                            ? "Dispenser Number already exists."
                                            : "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
                                        return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                                    }
                                else if (retVal == 304)
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "Dispenser Name already exists.");
                                }
                                else if (retVal == 305)
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "IP Address/AMS Net ID Address already exists.");
                                }
                                else
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, 
										"Unable to save the Dispenser Setup Data. Some error has occured. Please try again.");
                                }
                                if (retVal == 304)
                                {
                                    string errorMessage = "Dispenser Name already exists.";
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                            }
                                else
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest,
                                        "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.");
                                }
                        }
                        }
                    }
                    if (controllerId > 0)
                    {
                        List<MetaDataModel> metaDataModel = new List<MetaDataModel>(this.GetControllerSetupAdvanceMetaData(3, controllerId));
                        List<ControllerSetupDataModel> controllerAdvanceData = new List<ControllerSetupDataModel>();
                        if (metaDataModel != null && metaDataModel.Count > 0)
                        {
                            foreach (var item in metaDataModel)
                            {
                                if (item.FieldGroupInfo != null && item.FieldGroupInfo.Count > 0)
                                {
                                    foreach (var fieldGroupInfo in item.FieldGroupInfo)
                                    {
                                        ControllerSetupDataModel advanceData = new ControllerSetupDataModel();
                                        advanceData.FieldGroupId = item.FieldGroupId;
                                        advanceData.EcolabAccountNumber = user.EcolabAccountNumber;
                                        advanceData.FieldId = fieldGroupInfo.FieldId;
                                        advanceData.FieldName = fieldGroupInfo.FieldName;
                                        advanceData.TabId = 3;
                                        advanceData.ControllerId = controllerId;
                                        advanceData.ControllerModelId = fieldGroupInfo.ControllerModelId;
                                        advanceData.ControllerTypeId = fieldGroupInfo.ControllerTypeId;
                                        advanceData.FieldGroupId = fieldGroupInfo.FieldGroupId;
                                        advanceData.FieldName = fieldGroupInfo.FieldName;
                                        advanceData.Value = fieldGroupInfo.FieldDefaultValue;
                                        advanceData.FieldTagAddress = fieldGroupInfo.HasFieldTag;
                                        advanceData.FieldTagValue = fieldGroupInfo.TagDefaultValue;
                                        controllerAdvanceData.Add(advanceData);
                    }
                }
            }
                            this.SaveControllerSetupAdvanceData(controllerAdvanceData);
                    }
                }
            }
            }
            catch (Exception ex)
            {
                //Logger.Error("Api - ControllerSetup - Save ControllerSetup Data  Error :", ex);
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string errorMessage = (ex.Message.IndexOf("303") > -1)
                    ? "Dispenser Number already exists."
                    : "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, controllerId);
        }

        /// <summary>
        ///     Update the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage UpdateControllerSetupData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            User user = this.GetUser();
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);

            try
            {
                List<ControllerSetupData> ctrlSetupData =
                    Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);

                if (user != null)
                {
                    if (isDisconnected)
                    {
                        this.controllerSetupService.UpdateControllerSetupData(ctrlSetupData, this.UserId,
                            out lastModifiedTimeStamp);
                    }
                    else
                    {
                        ControllerSetupData objControllerSetupData = ctrlSetupData.FirstOrDefault();
                        ControllerModel controller = this.GetControllerDetailById(objControllerSetupData.ControllerId,
                            user.EcolabAccountNumber);
                        if (objControllerSetupData != null)
                        {
                            ControllerSetupDataDetails ctrlSetupDataDetails = new ControllerSetupDataDetails
                            {
                                ControllerSetupList = ctrlSetupData,
                                ControllerId = objControllerSetupData.ControllerId,
                                UserId = UserId,
                                EcolabAccountNumber = user.EcolabAccountNumber,
                                LastModifiedTimeStamp =
                                    DateTime.SpecifyKind(controller.LastModifiedTimeStamp, DateTimeKind.Utc),
                                MaxNumberOfRecords =
                                    controllerSetupService.GetMaxNumberOfRecords(user.EcolabAccountNumber)
                            };

                            int retVal = Push.PushToLocal(ctrlSetupDataDetails, user.EcolabAccountNumber, user.UserId,
                                (int)TcdAdminMessageTypes.TcdUpdateController);
                            if (retVal != 0)
                            {
                                if (retVal == 51030 || retVal == 60000)
                                {
									if (retVal == 51030 || retVal == 60000)
									{
										return Request.CreateResponse(HttpStatusCode.BadRequest,
                                        "Local plant not in sync with Central. Resync in progress. Please try later.");
                                }
                                    else if (retVal == 51060)
                                    {
                                        return Request.CreateResponse(HttpStatusCode.BadRequest,
                                            "Unable to save changes , Connectivity issue, Please try again later.");
                                    }
									else
									{
										string errorMessage = (retVal == 303)
											? "Dispenser Number already exists."
											: "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
										return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
									}
								}
								else if (retVal == 303)
								{
									string errorMessage = "Dispenser Number already exists.";
									return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
								}
								else if (retVal == 304)
								{
									string errorMessage = "Dispenser Name already exists.";
									return Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
								}
                                else if (retVal == 305)
                                {
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, "IP Address/AMS Net ID Address already exists.");
                                }
								else
								{
									return Request.CreateResponse(HttpStatusCode.BadRequest,
                                    "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.");
                            }
                        }
                    }
                }
            }
            }
            catch (Exception ex)
            {
                Logger.Error("Api - ControllerSetup - Update ControllerSetup Data  Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return Request.CreateResponse(HttpStatusCode.BadRequest,
                    "Unable to update the Dispenser Setup Data. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK);
        }

        /// <summary>
        ///     Save/Update the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        public HttpResponseMessage SaveControllerSetupAdvanceData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            string returnStatus = string.Empty;

            if (controllerSetupData[0].ControllerModelId == 7 && controllerSetupData[0].ControllerTypeId == 2)
            {
                var i = 0;
                foreach (ControllerSetupDataModel model in controllerSetupData)
                {
                    if (controllerSetupData[i].Value == "false")
                    {
                        controllerSetupData[i].Value = "0";
                    }
                    if (controllerSetupData[i].Value == "true")
                    {
                        controllerSetupData[i].Value = "1";
                    }
                                       
                    i++;
                }
            }
           
            User user = this.GetUser();
            bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
            try
            {
                List<ControllerSetupData> ctrlSetupData = Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);

                ControllerSetupData firstOrDefault = ctrlSetupData.FirstOrDefault();
                if (isDisconnected)
                {
                    DateTime lastModifiedTimeStamp;
                    if (firstOrDefault != null && this.controllerSetupService.IsSetupAdvanceDataExist(firstOrDefault.TabId, firstOrDefault.ControllerId, this.EcolabAccountNumber))
                    {
                        this.controllerSetupService.UpdateControllerSetupAdvanceData(ctrlSetupData, this.UserId, out lastModifiedTimeStamp);
                    }
                    else
                    {
                        this.controllerSetupService.SaveControllerSetupAdvanceData(ctrlSetupData, this.UserId, out lastModifiedTimeStamp);
                    }
                }
                else
                {
                    if (firstOrDefault != null)
                    {
                        ControllerModel controller = this.GetControllerDetailById(firstOrDefault.ControllerId, user.EcolabAccountNumber);
                        int actionType;
                        if (this.controllerSetupService.IsSetupAdvanceDataExist(firstOrDefault.TabId, firstOrDefault.ControllerId, user.EcolabAccountNumber))
                        {
                            actionType = (int)TcdAdminMessageTypes.TcdUpdateControllerAdvanced;
                        }
                        else
                        {
                            actionType = (int)TcdAdminMessageTypes.TcdAddControllerAdvanced;
                        }
                        ControllerSetupDataDetails ctrlSetupDataDetails = new ControllerSetupDataDetails
                        {
                            ControllerSetupList = ctrlSetupData,
                            ControllerId = firstOrDefault.ControllerId,
                            UserId = UserId,
                            LastModifiedTimeStamp = DateTime.SpecifyKind(controller.LastModifiedTimeStamp, DateTimeKind.Utc),
                            EcolabAccountNumber = firstOrDefault.EcolabAccountNumber,
                            MaxNumberOfRecords =
                                  this.controllerSetupService.GetMaxNumberOfRecords(user.EcolabAccountNumber)
                        };

                        int retVal = Push.PushToLocal(ctrlSetupDataDetails, ctrlSetupDataDetails.EcolabAccountNumber, this.UserId, actionType);

                        if (retVal != 0)
                        {
                            if (retVal == 51030 || retVal == 60000)
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Local plant not in sync with Central. Resync in progress. Please try later.");
                            }
                            else if (retVal == 51060)
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest,
                                    "Unable to save changes , Connectivity issue, Please try again later.");
                            }
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.");
                        }
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                //Logger.Error("Api - ControllerSetup - Save ControllerSetup Data  Error :", ex);
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string errorMessage = (ex.Message.IndexOf("303") > -1) ? "Dispenser Number already exists." : "Unable to save the Dispenser Setup Data. Some error has occured. Please try again.";
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
            }
        }

        public int GetMaxInjectionClassesCount(int controllerId, string ecolabAccountNumber)
        {
            return this.controllerSetupService.GetMaxInjectionClassesCount(controllerId, ecolabAccountNumber);
        }
    }
}