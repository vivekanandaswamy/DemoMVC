﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Sockets;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Elmah;
    using Models.UserManagement;
    using Services.Interfaces;
    using Model = Ecolab.Models.PlantSetup.UserManagement;

    /// <summary>
    /// Class for UserManagementController
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Api.BaseApiController" />
    public class UserManagementController : BaseApiController
	{
		/// <summary>
		///     UserManagement Service
		/// </summary>
		private readonly IUserManagementService userManagementService;

		/// <summary>
		///     Parameterized Constructor
		/// </summary>
		/// <param name="userService">User Service</param>
		/// <param name="plantService">Plant Service</param>
		/// <param name="UserManagementService">User Management Service</param>
		public UserManagementController(IUserService userService, IPlantService plantService, IUserManagementService UserManagementService)
			: base(userService, plantService)
		{
			this.userManagementService = UserManagementService;
		}

		/// <summary>
		///     Gets User Management Details
		/// </summary>
		/// <returns>List of UserManagementModel</returns>
		[HttpGet]
		public UserManagementViewModel Fetch()
		{
			IEnumerable<Model.UserManagement> userManagement = this.userManagementService.FetchUserManagementDetails(null, this.EcolabAccountNumber);
			IEnumerable<UserManagementModel> userManagementList = Mapper.Map<IEnumerable<Model.UserManagement>, IEnumerable<UserManagementModel>>(userManagement);
			userManagementList = userManagementList.Where(c => c.IsActive).ToList();

			IEnumerable<UserRoles> userRolesList = this.FetchUserRoles();
			UserManagementViewModel userManagementViewModel = new UserManagementViewModel();
			userManagementViewModel.UserManagementList = userManagementList;
			userManagementViewModel.UserRole = userRolesList;
			return userManagementViewModel;
		}

		/// <summary>
		///     Gets Dictionary of selected userManagement details and IEnumerable of userRoles
		/// </summary>
		/// <param name="id"></param>
		/// <returns>UserManagementViewModel</returns>
		[HttpGet]
		public UserManagementViewModel FetchOnEditClicked(int id)
		{
			User user = this.GetUser();
			Model.UserManagement userManagement = this.userManagementService.FetchUserManagementDetails(id, user.EcolabAccountNumber).FirstOrDefault();
			UserManagementModel userManagementList = Mapper.Map<Model.UserManagement, UserManagementModel>(userManagement);
			IEnumerable<UserRoles> userRolesList = this.FetchUserRoles();

			return new UserManagementViewModel { UserManagement = userManagementList, UserRole = userRolesList };
		}

		/// <summary>
		///     Gets IEnumerable List of UserRoles
		/// </summary>
		/// <returns>IEnumerable UserRoles</returns>
		[HttpGet]
		public IEnumerable<UserRoles> FetchUserRoles()
		{
			List<UserRoles> userRoles = this.UserService.GetAllRoles();
			IEnumerable<UserRoles> userRolesList = Mapper.Map<IEnumerable<Ecolab.Models.UserRoles>, IEnumerable<UserRoles>>(userRoles);
			return userRolesList;
		}

		/// <summary>
		///     Creates new User in User Management
		/// </summary>
		/// <param name="data">Data to create New user</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpPost]
		public HttpResponseMessage Create([FromBody] UserManagementModel data)
		{
			User user = this.GetUser();
			bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			int id = 0;
			Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
			objUserManagement.MaxNumberOfRecords = this.userManagementService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
			objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
			objUserManagement.IsActive = true;
			try
			{
				int result;
				var plantDetails = GetPlantDetails();
				if (plantDetails.CurrencyCode != "select")
				{
					objUserManagement.CurrencyCode = plantDetails.CurrencyCode;
				}
				if (plantDetails.UOMId != 0)
				{
					objUserManagement.UOMId = plantDetails.UOMId;
				}
				if (isDisconnected)
				{
					int userMasterId;
					DateTime lastModifiedTimeStamp;
					string status = this.userManagementService.InsertUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
					return this.Status(status);
				}
				else
				{
					result = Push.PushToLocal(objUserManagement, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdAddUserManagement, out id);
					switch (result)
					{
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 60000:
							return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
						case 51:
							return Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 52:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 501);
						case 302:
							return Request.CreateResponse(HttpStatusCode.BadRequest, 302);
						case 51030:
							return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
						case 1:
							return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to create the User. Some error has occured. Please try again.");
					}
				}
			}
            catch (SocketException socEx)
            {
                return this.Request.CreateResponse(HttpStatusCode.InternalServerError, data); 
            }
            catch (Exception ex)
			{
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to create the User. Some error has occured. Please try again.");
			}
			return this.Request.CreateResponse(HttpStatusCode.OK, data);
		}

		/// <summary>
		///     To update the User Management details
		/// </summary>
		/// <param name="id">User Number</param>
		/// <param name="data">Data to update User Management</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpPut]
		public HttpResponseMessage Put(int? id, UserManagementModel data)
		{
			User user = this.GetUser();
			int outputId = 0;
			bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			try
			{
				Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
				objUserManagement.MaxNumberOfRecords = this.userManagementService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
				objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
				objUserManagement.LastModifiedTime = DateTime.SpecifyKind(objUserManagement.LastModifiedTime, DateTimeKind.Utc);
				objUserManagement.IsActive = true;
				int result;
				if (isDisconnected)
				{
					int userMasterId;
					DateTime lastModifiedTimeStamp;
					string status = this.userManagementService.UpdateUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
					return this.Status(status);
				}
				else
				{
					result = Push.PushToLocal(objUserManagement, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateUserManagement, out outputId);
					if (result == 39)
					{
						switch (id)
						{                            
                            case 60000:
								return Request.CreateResponse(HttpStatusCode.BadRequest, 60000);
							case 301:
								return Request.CreateResponse(HttpStatusCode.BadRequest, 301);
							case 302:
								return Request.CreateResponse(HttpStatusCode.BadRequest, 302);
							case 51030:
								return Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
							case 1:
								return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the User. Please try again.");
						}
                    }
                    else if (result == 51060)
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                    }
				}
			}
			catch (Exception)
			{
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the User. Please try again.");
			}
			return this.Request.CreateResponse(HttpStatusCode.OK, data);
		}

		///// <summary>
		/////     To update the User Management details
		///// </summary>
		///// <param name="data">Data to update User Management</param>
		///// <returns>Returns Success or failure response Messages</returns>
		//[HttpPut]
		//public HttpResponseMessage Put(UserManagementModel data)
		//{
		//    return this.Put(data.UserNumber, data);
		//}

		/// <summary>
		///     To update the User Management details
		/// </summary>
		/// <param name="data">Data to update User Management</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpPut]
		public HttpResponseMessage Put(List<UserManagementModel> data)
		{

			User user = this.GetUser();
			bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			string status = string.Empty;
			Dictionary<string, string> StatusList = new Dictionary<string, string>();

			foreach (UserManagementModel userManagementModel in data)
			{
				status = Save(userManagementModel, user, isDisconnected);
				if (!string.IsNullOrEmpty(status))
					StatusList.Add(userManagementModel.LoginName, status);
			}
			if (StatusList.Count > 0)
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, StatusList);
			else
				return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);
		}

		/// <summary>
		///     Delete the User Management data
		/// </summary>
		/// <param name="data">the User Management data</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpDelete]
		public HttpResponseMessage Delete(UserManagementModel data)
		{
			User user = this.GetUser();
			int result = 0;
			bool isDisconnected = this.PlantService.IsPlantConnected(user.EcolabAccountNumber);
			Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
			objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
			objUserManagement.MaxNumberOfRecords = this.userManagementService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
			objUserManagement.LastModifiedTime = DateTime.SpecifyKind(objUserManagement.LastModifiedTime, DateTimeKind.Utc);
			if (objUserManagement.UserNumber != this.UserId)
			{
				try
				{
					if (isDisconnected)
					{
						DateTime lastModifiedTimeStamp;
						this.userManagementService.DeleteUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp);
						return this.Request.CreateResponse(HttpStatusCode.OK, data);
					}
					else
					{
						result = Push.PushToLocal(objUserManagement, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdDeleteUserManagement);
					}
					switch (result)
					{
                        case 51060:
                            return Request.CreateResponse(HttpStatusCode.BadRequest, 51060);
                        case 51030:
							return Request.CreateResponse(HttpStatusCode.BadRequest, "51030");
						case 60000:
							return Request.CreateResponse(HttpStatusCode.BadRequest, "60000");
						case 1:
							return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the user. Some error has occured. Please try again.");
					}
				}
				catch (Exception)
				{
					return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the user. Some error has occured. Please try again.");
				}
			}
			return this.Request.CreateResponse(HttpStatusCode.OK, data);
		}

		/// <summary>
		///     Returns success or failure Response basing on status code
		/// </summary>
		/// <param name="status">status code from Database</param>
		/// <returns>Success or failure HttpResponseMessage</returns>
		private HttpResponseMessage Status(string status)
		{
			if (string.IsNullOrEmpty(status))
			{
				return this.Request.CreateResponse(HttpStatusCode.OK);
			}
			return this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
		}

		private string Save(UserManagementModel data, User user, bool isDisconnected)
		{

			string status = string.Empty;
			try
			{
				Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
				objUserManagement.MaxNumberOfRecords = this.userManagementService.GetMaxNumberOfRecords(user.EcolabAccountNumber);
				objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
				objUserManagement.LastModifiedTime = DateTime.SpecifyKind(objUserManagement.LastModifiedTime, DateTimeKind.Utc);
				objUserManagement.IsActive = true;
				int result;
				if (isDisconnected)
				{
					int userMasterId;
					DateTime lastModifiedTimeStamp;
					status = this.userManagementService.UpdateUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
					return status;
				}
				else
				{
					result = Push.PushToLocal(objUserManagement, user.EcolabAccountNumber, user.UserId, (int)TcdAdminMessageTypes.TcdUpdateUserManagement);
				}
				switch (result)
				{
					case 60000:
						return "60000";
                    case 51060:
                        return "51060";
                    case 51:
						return "301";
                    case 52:
                        return "501";
					case 302:
						return "302";
					case 51030:
						return "51030";
					case 1:
						return "1";
				}
			}
			catch (Exception)
			{
				return "Unable to update the User. Please try again.";
			}

			return status;
		}

		/// <summary>
		///     Gets User Management Details
		/// </summary>
		/// <returns>List of UserManagementModel</returns>
		[HttpGet]
		public IEnumerable<UserManagementModel> FetchUserList()
		{
			IEnumerable<Model.UserManagement> userManagement = this.userManagementService.FetchUserManagementDetails(null, this.EcolabAccountNumber);
			IEnumerable<UserManagementModel> userManagementList = Mapper.Map<IEnumerable<Model.UserManagement>, IEnumerable<UserManagementModel>>(userManagement);
			userManagementList = userManagementList.Where(c => c.IsActive).ToList();

			return userManagementList;
		}
	}
}