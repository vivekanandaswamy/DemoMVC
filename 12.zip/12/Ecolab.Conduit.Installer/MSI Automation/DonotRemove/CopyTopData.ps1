{"agsecolab220885
USE [master]
GO
CREATE DATABASE ConduitLocal COLLATE Latin1_General_CI_AI
GO
ALTER DATABASE [ConduitLocal] 
MODIFY FILE ( NAME = N'ConduitLocal', 
MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
GO
ALTER DATABASE [ConduitLocal] 
MODIFY FILE ( NAME = N'ConduitLocal_log', 
MAXSIZE = UNLIMITED, FILEGROWTH = 512000KB )
GO

/****** Object:  Login [tcddev]    Script Date: 4/17/2015 5:43:37 PM ******/

IF EXISTS(SELECT NAME FROM MASTER.SYS.SERVER_PRINCIPALS WHERE NAME = 'tcddev')
BEGIN
	DROP LOGIN [tcddev]
END
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [tcddev]    Script Date: 4/17/2015 5:43:37 PM ******/
CREATE LOGIN [tcddev] WITH PASSWORD=N'Agstcd@1', 
DEFAULT_DATABASE=[master], 
DEFAULT_LANGUAGE=[us_english], 
CHECK_EXPIRATION=OFF, 
CHECK_POLICY=ON
GO

ALTER SERVER ROLE [sysadmin] ADD MEMBER [tcddev]
GO

ALTER SERVER ROLE [dbcreator] ADD MEMBER [tcddev]
GO
USE [ConduitLocal]
GO
/****** Object:  User [TCDDEV]    Script Date: 15-07-2015 23:38:34 ******/

/****** Object:  Schema [TCD]    Script Date: 15-07-2015 23:38:35 ******/
agsecolab220885"} >>D:\Projects\DonotRemove\GenerateSQLScript\Result\ps1.sql


