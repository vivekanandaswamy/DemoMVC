﻿using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace ConsolidateDBScriptForWix
{
    public class ConsolidateDBScriptForWix
    {
        private static string path = string.Empty;

        public static void Main(string[] args)
        {
            path = ConfigurationManager.AppSettings["FolderPath"]; 

            CopyTopData();
            CopyMiddleData();
            CopyBottomData();
        }

        private static void CopyBottomData()
        {
            string[] content = File.ReadAllLines(string.Format("{0}{1}", path, "ps3.sql"));
            if (content.Length > 0)
            {
                var foos = new List<string>(content);
                foos.RemoveAt(0);
                foos.RemoveAt(foos.Count - 1);
                content = foos.ToArray();
            }
            File.AppendAllLines(string.Format("{0}{1}", path, "ConduitLocalDB.sql"), content);
        }

        private static void CopyMiddleData()
        {
            string[] content = File.ReadAllLines(string.Format("{0}{1}", path, "ConduitLocalDB1.sql"));
            if (content.Length > 0)
            {
                var foos = new List<string>(content);
                foos.RemoveAt(0);
                foos.RemoveAt(0);
                content = foos.ToArray();
            }
            File.AppendAllLines(string.Format("{0}{1}", path, "ConduitLocalDB.sql"), content);
        }

        private static void CopyTopData()
        {
            string[] content = File.ReadAllLines(string.Format("{0}{1}", path, "ps1.sql"));
            if (content.Length > 0)
            {
                var foos = new List<string>(content);
                foos.RemoveAt(0);
                foos.RemoveAt(foos.Count - 1);
                content = foos.ToArray();
            }
            File.WriteAllLines(string.Format("{0}{1}", path, "ConduitLocalDB.sql"), content);
        }
    }
}