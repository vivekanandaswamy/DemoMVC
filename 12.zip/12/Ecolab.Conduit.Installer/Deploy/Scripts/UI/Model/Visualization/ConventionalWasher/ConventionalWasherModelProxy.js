Ecolab.Model.ConventionalWasherModelProxy = function () {
};

Ecolab.Model.ConventionalWasherModelProxy.prototype =
{
    loadDashboardData: function (data, callBack, errorCallBack) {
        var url = "/Api/Visualization/GetConventionalWasherVisualizationData/?id={id}&typeId={typeId}";
        var requestData = { "id": data.Id, "typeId": data.TypeId };
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ConventionalWasherModelProxy.prototype = $.extend({}, Ecolab.Model.ConventionalWasherModelProxy.prototype, base);
Ecolab.Model.ConventionalWasherModelProxy.prototype.base = base;