﻿Ecolab.Model.ConventionalWasherModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDashboardDataLoad: null,
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ConventionalWasherModelProxy = new Ecolab.Model.ConventionalWasherModelProxy();
};

Ecolab.Model.ConventionalWasherModel.prototype = {
    init: function () {
    },
    loadDashboardData: function (dashboardId) {
        var _this = this;
        this.ConventionalWasherModelProxy.loadDashboardData(dashboardId,function (dashboardData) {
            _this.settings.eventHandlers.onDashboardDataLoad(dashboardData);
        });
    },
};

