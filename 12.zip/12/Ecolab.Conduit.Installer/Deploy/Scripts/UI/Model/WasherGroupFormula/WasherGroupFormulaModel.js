Ecolab.Model.WasherGroupFormulaModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onWasherGroupDataLoad: function () { },
            onFormulaDataLoad: function () { },
            onGetAddFormulaDataRecieved: null,
            onGetEditFormulaDataRecieved: null,
            onFormulaUpdated: null,
            onFormulaCreated: null,
            //onFormulaDataLoad: function () { },
            onWasherGroupFormulaDeleted: function () { },
            onWasherGroupWashStepDeleted: function () { },
            onWasherGroupFormulaDeletionFailed: function () { },
            onWasherGroupCreated: function () { },
            onWasherGroupUpdated: function () { },
            // Wash step call back methods
            onWashStepDataLoad: function () { },
            onCopyWashStepDataLoad: function () { },
            onWashStepCreationSuccess: function () { },
            onWashStepCreationFailed: function () { },
            //Tunnel Wash Step call back methods
            onTunnelWashStepSetData: function () { },
            onTunnelGridViewSetData: function () { },
            onTunnelGridSuccess: function () { },
            onTunnelGridFailed: function () { },
            onWasherDeleted: function () { },
            onWasherDeletionFailed:function () { },
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.WasherGroupFormulaModelProxy = new Ecolab.Model.WasherGroupFormulaModelProxy();
}

Ecolab.Model.WasherGroupFormulaModel.prototype = {
    init: function () { },

    //Passing the data from the model proxy to set the washer groups.
    loadAddEditWasherGroupModelData: function (washergroupId, accountNumber, regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.loadAddEditWasherGroupModelData(washergroupId, accountNumber,regionId,
            function (washergroupData) { // callback method
                _this.settings.eventHandlers.onWasherGroupDataLoad(washergroupData);
            });
    },
    //Passing the data from the model proxy to set the washer groups.
    loadWasherGroupModelData: function (washergroupId, accountNumber) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.loadWasherGroupModelData(washergroupId, accountNumber, function (washergroupsData) { _this.settings.eventHandlers.onFormulaDataLoad(washergroupsData); });
    },
    GetAddFormula: function (ecolabAccountNumber, WasherGroupId) {
        var _this = this;

        this.WasherGroupFormulaModelProxy.GetAddFormula(ecolabAccountNumber, WasherGroupId, function (data) {
            _this.settings.eventHandlers.onGetAddFormulaDataRecieved(data);
        });
    },
    //For Saving New Formula
    createFormula: function (FormulaData) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.createFormula(FormulaData, function (data) {
            var FormulaId = data;
            _this.settings.eventHandlers.onFormulaCreated(FormulaId, FormulaData);
        });
    },
    updateFormula: function (FormulaData) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.updateFormula(FormulaData, function (data) {
            _this.settings.eventHandlers.onFormulaUpdated(data, FormulaData);
        });
    },
    updateInlineFormula: function (FormulaData) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.updateFormula(FormulaData, function (data) {
            _this.settings.eventHandlers.onInlineFormulaUpdated(data);
        });
    },
    //Events is for deleting the washer group.
    onDeleteWasherGroupClicked: function (washerGroupData) {
        var _this = this;
        //passing washergroupId
        this.WasherGroupModelProxy.onDeleteWasherGroupClicked(washerGroupData,
            function (WasherGroupData) { //Callback method
                _this.settings.eventHandlers.onWasherGroupFormulaDeleted(WasherGroupData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
    },
    // Event for saving the washer group data 
    createWasherGroup: function (washergroupData) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.createWasherGroup(washergroupData, function (responseData) {
            _this.settings.eventHandlers.onWasherGroupCreated(responseData);
        });
    },

    // Event for updating the washer group details
    UpdateWasherGroup: function (washergroupData, accountNumber) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.updateWasherGroup(washergroupData, accountNumber, function (responseData) {
            _this.settings.eventHandlers.onWasherGroupUpdated(responseData);
        });
    },

    //Events is for deleting the washer group.
    onDeleteFormulaListClicked: function (FormulaData) {
        var _this = this;
        //passing washergroupId
        this.WasherGroupFormulaModelProxy.onDeleteFormulaListClicked(FormulaData,
            function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onWasherGroupFormulaDeleted(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
    },
    WashStepDelete: function (WashStepData) {
        var _this = this;
        //passing washergroupId
        this.WasherGroupFormulaModelProxy.WashStepDelete(WashStepData,
            function (WashStepDelete) { //Callback method
                _this.settings.eventHandlers.onWasherGroupWashStepDeleted(WashStepDelete);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherGroupFormulaDeletionFailed(error, description);
            });
    },
    GetEditFormula: function (WasherGroupId, id, ecolabAccountNumber) {
        var _this = this;

        this.WasherGroupFormulaModelProxy.GetEditFormula(WasherGroupId, id, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onGetEditFormulaDataRecieved(data);
        });
    },
    GetEditWashStep: function (WasherGroupId, id, FormulaId, ecolabAccountNumber, regionId) {
        var _this = this;

        this.WasherGroupFormulaModelProxy.GetEditWashStep(WasherGroupId, id, FormulaId, ecolabAccountNumber,regionId, function (washSetupData) {
            _this.settings.eventHandlers.onWashStepDataLoad(washSetupData);
        });
    },
    GetCopyWashStep: function (WasherGroupId, id, FormulaId, ecolabAccountNumber, regionId) {
        var _this = this;

        this.WasherGroupFormulaModelProxy.GetEditWashStep(WasherGroupId, id, FormulaId, ecolabAccountNumber, regionId, function (washSetupData) {
            _this.settings.eventHandlers.onCopyWashStepDataLoad(washSetupData);
        });
    },

    //Event for sending request to load wash step data
    loadWashStepModelData: function (washerGroupId, accountNumber, formulaId,regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.loadWashStepModelData(washerGroupId, accountNumber,formulaId,regionId,
            function (washSetupData) { // callback method
                _this.settings.eventHandlers.onWashStepDataLoad(washSetupData);
            });
    },
    saveWashStep: function (washdata) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.saveWashStep(washdata, 
            function (responseData) {
                _this.settings.eventHandlers.onWashStepCreationSuccess(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onWashStepCreationFailed(errorData);
            });
    },
    saveTunnelWashStep: function (washdata, regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.saveTunnelWashStep(washdata, regionId,
            function (responseData) {
                _this.settings.eventHandlers.onTunnelWashStepCreationSuccess(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onTunnelWashStepCreationFailed(errorData);
            });
    },
    loadChemicals: function (request, callBack) {
        this.WasherGroupFormulaModelProxy.loadChemicals(request, callBack);
    },
    loadTunneWashStep: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.loadTunneWashStep(formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId,regionId, 
            function (reponse) { _this.settings.eventHandlers.onTunnelWashStepSetData(reponse); });
    },
    loadTunnelGridViewDetails: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupId, regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.loadTunnelGridViewDetails(formulaId, ecolabAccountNumber, compartmentNumber, washerGroupId, regionId,
            function (reponse) { _this.settings.eventHandlers.onTunnelGridViewSetData(reponse); });
    },
    saveTunnelWashStepGrid :function (washdata, regionId) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.saveTunnelWashStep(washdata, regionId,
            function (responseData) {
                _this.settings.eventHandlers.onTunnelGridSuccess(responseData);
            },
            function (errorData) {
                _this.settings.eventHandlers.onTunnelGridFailed(errorData);
            });
    },
    onDeleteWasher: function (isTunnel, id, ecolabAccountNumber) {
        var _this = this;
        this.WasherGroupFormulaModelProxy.onDeleteWasher(isTunnel, id, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onWasherDeleted(data);
        },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherDeletionFailed(error, description);
            });
    },

}