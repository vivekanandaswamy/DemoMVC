Ecolab.Model.WasherGroupFormulaModelProxy = function () {
};

Ecolab.Model.WasherGroupFormulaModelProxy.prototype = {
    // event is for getting the washer groups from API controller.
    loadWasherGroupModelData: function (washergroupId, accountNumber, callBack) {
        var url = "Api/WasherGroupFormula/GetWasherGroupFormula";

        // Passing parameter  to Api .
        var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": 1};

        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    loadAddEditWasherGroupModelData: function (washergroupId, accountNumber,regionId, callBack) {
        if (washergroupId != null) {
            // Api Url for retrive data.
            var url = "Api/WasherGroupFormula/GetWasherGroupWithWasherDetails";

            // assigning the required data to the Api.
            var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber, "pageNumber": 0, "numberOfRecordsPerpage": 0, "sortColumn": '', "regionId": regionId };

            this.ApiRead("WasherGroup", url, function (response) { callBack(response); }, null, null, requestData);
        }
        else {
            return false;
        }
    },
    //Event for calling the Api method for deleting the washergroup based on the requested id.
    onDeleteWasherGroupClicked: function (washerGroupData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "Api/WasherGroupFormula/DeleteWasherGroupFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupData);
    },
    WashStepDelete: function (WashStepData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "Api/WasherGroupFormula/DeleteWasherGroupFormulaWashStep";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, WashStepData);
    },
    // Event for Api to create a new washer group
    createWasherGroup: function (washerGroupWebData, callBack) {
        var url = "/Api/WasherGroupFormula/CreateWasherGroup";
        //var requestData = {washerGroupWebData,'1' };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, null, null, washerGroupWebData);
    },

    // Event for Api to update the washer group details.
    updateWasherGroup: function (washerGroupWebData, accountNumber, callBack) {
        var url = "/Api/WasherGroupFormula/UpdateWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, null, null, washerGroupWebData);
    },

    //Event for calling the Api method for deleting the washergroup based on the requested id.
    onDeleteFormulaListClicked: function (FormulaData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "Api/WasherGroupFormula/DeleteWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, FormulaData);
    },
    GetAddFormula: function (ecolabAccountNumber, WasherGroupId, callBack) {
        var url = "Api/WasherGroupFormula/GetAddFormulaDetails";
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber, "WasherGroupId": WasherGroupId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    createFormula: function (requestData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/createFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateFormula: function (requestData, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateWasherGroupFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); },null, requestData);
    },
    GetEditFormula: function (WasherGroupId, id,ecolabAccountNumber, callBack) {
            var url = "Api/WasherGroupFormula/GetEditFormulaDetails";
            var requestData = { "washerGroupId": WasherGroupId, "programSetupId": id, "ecolabAccountNumber": ecolabAccountNumber };
            this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetEditWashStep: function (WasherGroupId, id,FormulaId, ecolabAccountNumber,regionId, callBack) {
        var url = "Api/WasherGroupFormula/GetEditFormulaWashStepDetails";
        var requestData = { "washerGroupId": WasherGroupId, "programSetupId": FormulaId, "dosingSetupId": id, "ecolabAccountNumber": ecolabAccountNumber, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },

    //******************************//

    // event is for getting the wash steps data from API controller.
    loadWashStepModelData: function (washergroupId, accountNumber, formulaId, regionId, callBack) {
        var url = "Api/WasherGroupFormula/GetWashStepDetails";

        // Passing parameter  to Api .
        var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber, "formulaId": formulaId,"regionId":regionId };

        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, requestData);
    },

    // Event for saving wash step for a formula
    saveWashStep: function (washerGroupFormulaWashStep, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/SaveWasherGroupFormulaWashSteps";
        //var requestData = { "washerGroupFormulaWashStep": washerGroupFormulaWashStep, "regionId": regionId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (response) { errorCallBack(response); }, null, washerGroupFormulaWashStep);
    },
    // Event for saving wash step for a formula
    saveTunnelWashStep: function (tunnelStepData, regionId, callBack, errorCallBack) {
        var url = "/Api/WasherGroupFormula/UpdateTunnelStep";
        //var requestData = { "tunnelStepData": tunnelStepData, "regionId": regionId };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (response) { errorCallBack(response); }, null, tunnelStepData);
    },
    loadChemicals: function (request, callBack, errorCallBack) {
        var url = "/api/WasherGroupFormula/GetChemicalList";
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, request);
    },
    loadTunneWashStep: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetTunnelDetails";
        var request = { "programSetupId": formulaId, "ecoalabAccountNumber": ecolabAccountNumber, "dosingSetupId": compartmentNumber, "washerGroupId": washerGroupOutPutId, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, request);
    },
    loadTunnelGridViewDetails: function (formulaId, ecolabAccountNumber, compartmentNumber, washerGroupOutPutId, regionId, callBack) {
        var url = "/Api/WasherGroupFormula/GetTunnelGridDetails";
        var request = { "programSetupId": formulaId, "ecoalabAccountNumber": ecolabAccountNumber, "dosingSetupId": compartmentNumber, "washerGroupId": washerGroupOutPutId, "regionId": regionId };
        this.ApiRead("WasherGroupFormula", url, function (response) { callBack(response); }, null, null, request);
    },
    onDeleteWasher: function (isTunnel, id, ecolabAccountNumber, callBack, errorCallBack) {
        var requestData = { "washerId": parseInt(id), "isTunnel": isTunnel, "ecolabAccountNumber": ecolabAccountNumber };
        var url = "Api/Washer/WasherDelete";
        this.ApiRead("Washer", url, function (response) { callBack(response); }, null, null, requestData);
    },
    
}

var base = new Ecolab.Model.Common();
Ecolab.Model.WasherGroupFormulaModelProxy.prototype = $.extend({}, Ecolab.Model.WasherGroupFormulaModelProxy.prototype, base);
Ecolab.Model.WasherGroupFormulaModelProxy.prototype.base = base;