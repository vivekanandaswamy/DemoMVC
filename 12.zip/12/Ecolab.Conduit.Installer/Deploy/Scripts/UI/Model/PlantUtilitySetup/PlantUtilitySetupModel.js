Ecolab.Model.PlantUtilitySetupModel = function (options) {
    //  this.NumberOfItems = 0;
    var defaultOptions = {
        eventHandlers: {
            onPlantUtilitySetupDataLoaded: null,
            onSaved: null,
            onSaveFailed : null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.PlantUtilitySetupModelProxy = new Ecolab.Model.PlantUtilitySetupModelProxy();
};

Ecolab.Model.PlantUtilitySetupModel.prototype = {
    init: function () {

    },
    loadPlantUtilitySetupData: function () {
        var _this = this;
        this.PlantUtilitySetupModelProxy.loadPlantUtilitySetupData(function (plantUtilitySetupData) { _this.onDataLoaded(plantUtilitySetupData); });
    },
    savePlantutilityData:function (data){
        var _this = this;
        this.PlantUtilitySetupModelProxy.savePlantutilityData(data,
            function () { _this.onPlantUtilityDataSaved(); },
            function (data, exception) { _this.onPlantUtilityDataSavedFailed(data, exception); });
    },
    onDataLoaded: function (data) {
        var _this = this;
        if (_this.settings.eventHandlers.onPlantUtilitySetupDataLoaded) {
            _this.settings.eventHandlers.onPlantUtilitySetupDataLoaded(data);
        }
    },
    onPlantUtilityDataSaved: function () {
        var _this = this;
        _this.settings.eventHandlers.onPlantUtilityDataSaved();
    },
    onPlantUtilityDataSavedFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onPlantUtilityDataSavedFailed(data, exception);
    },
    getEnergyContent: function (gasTypeId) {
        var _this = this;
        _this.PlantUtilitySetupModelProxy.getEnergyContent(gasTypeId, function (data) { _this.settings.eventHandlers.setEnergyContentData(data); });
    }
};

