// JavaScript source code
Ecolab.Model.PumpsModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onPumpsDataLoaded: null,
            onProductsLoaded: null,
            onPumpUpdated: null,
            onPumpUpdationFailed: null,
            onPumpUpdatedEdit: null,
            onControllerNameLoaded: null,
            onValidateFailed:null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.PumpsModelProxy = new Ecolab.Model.PumpsModelProxy();
};

Ecolab.Model.PumpsModel.prototype = {
    init: function () {
    },

    loadPumpsData: function (ecoLabAccountNumber, controlNumber) {
        var _this = this;
        _this.PumpsModelProxy.loadPumpsData(ecoLabAccountNumber, controlNumber, "", function (data) {
            _this.settings.eventHandlers.onPumpsDataLoaded(data);
        });
    },
    getControllerName:function(ecoLabAccountNumber, controlNumber){
        var _this = this;
        _this.PumpsModelProxy.getControllerName(ecoLabAccountNumber, controlNumber,function (data) {
            _this.settings.eventHandlers.onControllerNameLoaded(data);
        });
    },
    loadPumpsListOnDropdown: function (ecoLabAccountNumber, controlNumber, option) {
        var _this = this;
        _this.PumpsModelProxy.loadPumpsData(ecoLabAccountNumber, controlNumber, option, function (data) {
            _this.settings.eventHandlers.onPumpsDataLoaded(data);
        });
    },
    loadProducts: function () {
        var _this = this;
        _this.PumpsModelProxy.loadProducts(function (products) {
            _this.settings.eventHandlers.onProductsLoaded(products);
        });
    },
    updatePumpData: function (pumpdata, isInline) {
        var _this = this;
        var localData = pumpdata;
        this.PumpsModelProxy.updatePump(pumpdata, function (data) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdated(data);
            else
                _this.settings.eventHandlers.onPumpUpdatedEdit(localData);
        },
        function (error, description) {
            if (isInline)
                _this.settings.eventHandlers.onPumpUpdationFailed(error, description);
            else
                _this.settings.eventHandlers.onPumpUpdationFailedEdit(error, description, localData);
        });
    },

    ValidateTags: function (pumpData) {
        var _this = this;
        this.PumpsModelProxy.validateTags(pumpData, function (data) {
            _this.settings.eventHandlers.onValidateSuccess(data);
        }, function (error, description) { _this.settings.eventHandlers.onValidateFailed(error, description, pumpData); });
    }
}