Ecolab.Model.ControllerSetupListModelProxy = function () {
};

Ecolab.Model.ControllerSetupListModelProxy.prototype =
{
    ControllerSetupListModelProxy: function (id, callBack, errorCallBack) {
        var url = "ControllerSetupListController/{id}";
        var requestData = { "id": id };
        this.ApiRead("ControllerSetup", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ControllerSetupListModelProxy.prototype = $.extend({}, Ecolab.Model.ControllerSetupListModelProxy.prototype, base);
Ecolab.Model.ControllerSetupListModelProxy.prototype.base = base;