// JavaScript source code
Ecolab.Model.AlarmModelProxy = function () {
};

Ecolab.Model.AlarmModelProxy.prototype =
{
    loadAlarmData: function (callBack, errorCallBack) {
        var url = "/Api/Alarm/FetchAlarmDetails";
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadAlarmCount: function (callBack, errorCallBack) {
        var url = "/Api/Alarm/FetchAlarmCount";
        kendo.ui.progress($('body'), false);
        this.ServerRequest("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null, null, false);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.AlarmModelProxy.prototype = $.extend({}, Ecolab.Model.AlarmModelProxy.prototype, base);
Ecolab.Model.AlarmModelProxy.prototype.base = base;