// JavaScript source code
Ecolab.Model.FinnisherModelProxy = function () {
};

Ecolab.Model.FinnisherModelProxy.prototype =
{
    loadFinnisherGroupData: function (callBack, errorCallBack) {
        var url = "/Api/Finnisher/Get";
        this.ApiRead("Finnisher", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadFinnisherTypes: function (callBack, errorCallBack) {
        var url = "/Api/Finnisher/FetchFinnisherTypes";
        this.ApiRead("Finnisher", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    createFinnisherGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/CreateFinnisherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateFinnisherGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/UpdateFinnisherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteFinnisherGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/DeleteFinnisherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    createFinnisher: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/CreateFinnisher";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateFinnisher: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/UpdateFinnisher";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteFinnisher: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Finnisher/DeleteFinnisher";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
}
var base = new Ecolab.Model.Common();
Ecolab.Model.FinnisherModelProxy.prototype = $.extend({}, Ecolab.Model.FinnisherModelProxy.prototype, base);
Ecolab.Model.FinnisherModelProxy.prototype.base = base;