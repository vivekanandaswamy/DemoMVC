Ecolab.Model.ContactModelProxy = function () {
};

Ecolab.Model.ContactModelProxy.prototype =
{
    loadPositionData: function (callBack, errorCallBack) {
        var url = "/Api/Contact/FetchPlantContactPosition";
        this.ApiRead("Contact", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ContactModelProxy.prototype = $.extend({}, Ecolab.Model.ContactModelProxy.prototype, base);
Ecolab.Model.ContactModelProxy.prototype.base = base;