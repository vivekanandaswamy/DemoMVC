Ecolab.Model.ContactModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onPositionDataLoaded:null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ContactModelProxy = new Ecolab.Model.ContactModelProxy();
};

Ecolab.Model.ContactModel.prototype = {
    init: function () {
    },
    loadPositionData: function (callBackData) {
        var _this = this;
        this.ContactModelProxy.loadPositionData(function (positionData) {
            _this.settings.eventHandlers.onPositionDataLoaded(positionData, callBackData);
        });
    }
};

