Ecolab.Model.WasherGroupModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onWasherGroupDataLoad: function () { },
            onDeleteWasherGroupClicked: function () { },
            onWasherGroupDeleted: function () { },
            onWasherGroupDeletionFailed: function () { },

            //******************************************//
            // Add/Edit Washer Group Events
            //******************************************//
            onAddEditWasherGroupLoad: function () { },
            onWasherGroupCreated: function () { },
            onWasherGroupUpdated: function () { },
            onWasherGroupInlineUpdated: function () { }
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.WasherGroupModelProxy = new Ecolab.Model.WasherGroupModelProxy();
};

Ecolab.Model.WasherGroupModel.prototype = {

    //intialising the model.
    init: function () { },

    //Passing the data from the model proxy to set the washer groups.
    loadWasherGroupModelData: function (accountNumber) {
        var _this = this;
        this.WasherGroupModelProxy.loadWasherGroupModelData(accountNumber, function (washergroupsData) { _this.settings.eventHandlers.onWasherGroupDataLoad(washergroupsData); });
    },

    //Events is for deleting the washer group.
    onDeleteWasherGroupClicked: function (washerGroupData) {
        var _this = this;
        //passing washergroupId
        this.WasherGroupModelProxy.onDeleteWasherGroupClicked(washerGroupData,
            function (WasherGroupData) { //Callback method
                _this.settings.eventHandlers.onWasherGroupDeleted(WasherGroupData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherGroupDeletionFailed(error, description);
        });
    },

    //******************************************//
    // Add/Edit Washer Group Events
    //******************************************//

    //Passing the data to modelproxy 
    loadAddEditWasherGroupModelData: function (washergroupId, accountNumber) {
        var _this = this;
        this.WasherGroupModelProxy.loadAddEditWasherGroupModelData(washergroupId,accountNumber,
            function (washergroupData) { // callback method
                _this.settings.eventHandlers.onAddEditWasherGroupLoad(washergroupData);
            });
    },

    // Event for saving the washer group data 
    createWasherGroup: function (washergroupData) {
        var _this = this;
        this.WasherGroupModelProxy.createWasherGroup(washergroupData, function (responseData) {
            _this.settings.eventHandlers.onWasherGroupCreated(responseData);
        });
    },

    // Event for updating the washer group details
    UpdateWasherGroup: function (washergroupData, accountNumber) {
        var _this = this;
        this.WasherGroupModelProxy.updateWasherGroup(washergroupData,accountNumber, function (responseData) {
            _this.settings.eventHandlers.onWasherGroupUpdated(responseData);
        });
    },
    UpdateInlineWasherGroup: function (washergroupData, accountNumber) {
        var _this = this;
        this.WasherGroupModelProxy.updateWasherGroup(washergroupData, accountNumber, function (responseData) {
            _this.settings.eventHandlers.onWasherGroupInlineUpdated(responseData);
        });
    },


   


}