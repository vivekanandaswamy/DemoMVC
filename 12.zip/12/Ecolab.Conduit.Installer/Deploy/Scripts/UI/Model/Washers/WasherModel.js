// JavaScript source code
Ecolab.Model.WasherModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onGetWasherDetailsReceived: null,
            onWasherDeleted: null,
            onWasherDeletionFailed: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.WasherModelProxy = new Ecolab.Model.WasherModelProxy();
};

Ecolab.Model.WasherModel.prototype = {
    init: function () {
    },
    //getting grid data
    getWasherDetails: function (ecolabAccountNumber,regionId) {
        var _this = this;
        this.WasherModelProxy.getWasherDetails(ecolabAccountNumber, regionId, function (data) {
            _this.onGetWasherDetailsReceived(data);
        });
    },
    onGetWasherDetailsReceived: function (data) {
        var _this = this;
        _this.settings.eventHandlers.onGetWasherDetailsReceived(data);
    },

    //delete functionality
    onDeleteWasher: function (isTunnel, id, ecolabAccountNumber) {
        var _this = this;
        this.WasherModelProxy.onDeleteWasher(isTunnel, id, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onWasherDeleted(data);
        },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onWasherDeletionFailed(error, description);
            });
    },

}