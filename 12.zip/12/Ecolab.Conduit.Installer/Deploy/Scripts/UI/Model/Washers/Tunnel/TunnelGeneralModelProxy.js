// JavaScript source code
Ecolab.Model.TunnelGeneralModelProxy = function () {
};

Ecolab.Model.TunnelGeneralModelProxy.prototype =
{
    loadDropDownsData: function (ecoLabAccountNumber, regionId, washerGroupId, callBack, errorCallBack) {

        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "regionId": regionId, "washerType": "Tunnel", "washerGroupId": washerGroupId };
        var url = "/Api/Tunnel/GetDropDownData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData,false);
    },
    saveTunnelData: function (tunnelData, callBack, errorCallBack) {
        var url = "/Api/Tunnel/SaveTunnelData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, tunnelData);
    },
    updateTunnelData: function (tunnelData, callBack, errorCallBack) {
        var url = "/Api/Tunnel/UpdateTunnelData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, tunnelData);
    },
    getSizeList: function (model, callBack, errorCallBack) {
        var requestData = { "washerModelId": model };
        var url = "/Api/Tunnel/GetSizeList";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getTunnelData: function (id, washerGroupId, ecoLabAccountNo, regionId, callBack, errorCallBack) {
        var requestData = { "id": id, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNo };
        var url = "/Api/Tunnel/GetTunnelData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData,false);
    },
    getWasherModeList: function (controllerId, ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId, "ecoLabAccountNumber": ecoLabAccountNumber };
        var url = "/Api/Conventional/getWasherModeList";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData,false);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.TunnelGeneralModelProxy.prototype = $.extend({}, Ecolab.Model.TunnelGeneralModelProxy.prototype, base);
Ecolab.Model.TunnelGeneralModelProxy.prototype.base = base;