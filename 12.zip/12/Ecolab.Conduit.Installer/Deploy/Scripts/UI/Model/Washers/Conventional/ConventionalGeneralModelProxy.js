// JavaScript source code
Ecolab.Model.ConventionalGeneralModelProxy = function () {
};

Ecolab.Model.ConventionalGeneralModelProxy.prototype =
{
    loadDropDownsData: function (ecoLabAccountNumber, regionId, washerGroupId, callBack, errorCallBack) {

        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "regionId": regionId, "washerGroupId": washerGroupId, "washerType": "Conventional" };
        var url = "/Api/Conventional/GetDropDownData";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getSizeList: function (model,regionId, callBack, errorCallBack) {
        var requestData = { "washerModelName": model, "regionId": regionId, "washerType": "Conventional" };
        var url = "/Api/Conventional/GetSizeList";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getLfsWasherList: function (controllerId, ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId, "ecoLabAccountNumber": ecoLabAccountNumber};
        var url = "/Api/Conventional/GetLfsWasherList";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getWasherModeList: function (controllerId, ecoLabAccountNumber, callBack, errorCallBack) {
        var requestData = { "controllerId": controllerId, "ecoLabAccountNumber": ecoLabAccountNumber };
        var url = "/Api/Conventional/GetWasherModeList";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    saveConventionalData: function (ConventionalData, callBack, errorCallBack) {
        var url = "/Api/Conventional/SaveConventionalData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, ConventionalData);
    },
    updateConventionalData: function (ConventionalData, callBack, errorCallBack) {
        var url = "/Api/Conventional/UpdateConventionalData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, ConventionalData);
    },
    
    getConventionalData: function (id, washerGroupId, ecoLabAccountNo, regionId, callBack, errorCallBack) {
        var requestData = { "id": id, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNo, "regionId": regionId };
        var url = "/Api/Conventional/GetConventionalData";
        this.ApiRead("Conventional", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.ConventionalGeneralModelProxy.prototype = $.extend({}, Ecolab.Model.ConventionalGeneralModelProxy.prototype, base);
Ecolab.Model.ConventionalGeneralModelProxy.prototype.base = base;