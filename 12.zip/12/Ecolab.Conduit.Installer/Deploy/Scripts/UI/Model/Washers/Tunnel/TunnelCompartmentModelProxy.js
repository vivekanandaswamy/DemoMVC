Ecolab.Model.TunnelCompartmentModelProxy = function () {
};
Ecolab.Model.TunnelCompartmentModelProxy.prototype = {
    loadDropDownsData: function (ecoLabAccountNumber, regionId, controllerId, tunnelId, washerGroupId, callBack, errorCallBack) {

        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "regionId": regionId, "controllerId": controllerId, "tunnelId": tunnelId, "washerGroupId": washerGroupId };
        var url = "/Api/Tunnel/GetCompartmentDropDownData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, false);
    },
    saveTunnelData: function (tunnelData, callBack, errorCallBack) {
        var url = "/Api/Tunnel/SaveTunnelCompartmentData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, tunnelData);
    },
    loadCompartmentsModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, callBack, errorCallBack) {
        var requestData = { "id": tunnelId, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber, "compartmentNumber": compartmentNumber };
        var url = "/Api/Tunnel/GetCompartmentData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, false);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.TunnelCompartmentModelProxy.prototype = $.extend({}, Ecolab.Model.TunnelCompartmentModelProxy.prototype, base);
Ecolab.Model.TunnelCompartmentModelProxy.prototype.base = base;