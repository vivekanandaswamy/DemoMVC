Ecolab.Model.FormulaModelProxy = function () {
};

Ecolab.Model.FormulaModelProxy.prototype =
{
    FormulaModelProxy: function (id, callBack, errorCallBack) {
        var url = "FormulaController/{id}";
        var requestData = { "id": id };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadFormulaOnAddNewPopupLoad: function (callBack, errorCallBack) {
        var url = "/Api/PlantFormula/GetFormulaForAdd";
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.FormulaModelProxy.prototype = $.extend({}, Ecolab.Model.FormulaModelProxy.prototype, base);
Ecolab.Model.FormulaModelProxy.prototype.base = base;