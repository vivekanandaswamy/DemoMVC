Ecolab.Model.FormulaModel = function (options) {
    var defaultOptions = {
        eventHandlers: {

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.FormulaModelProxy = new Ecolab.Model.FormulaModelProxy();
};

Ecolab.Model.FormulaModel.prototype = {
    init: function () {
    },
    loadFormulaData: function (pageIndex, callBackData) {
        var _this = this;
        _this.onDataLoaded("data", true);
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onFormulaDataLoaded(data, callBackData);
    },

    loadFormulaOnAddNewPopupLoad: function (callBackData) {
    var _this = this;
    this.FormulaModelProxy.loadFormulaOnAddNewPopupLoad(function (parentData) {
        _this.settings.eventHandlers.onloadFormulaOnAddNewPopupDataLoaded(parentData, callBackData);
    });
}
};

