Ecolab.Model.NavigationMenuModelProxy = function () {
};

Ecolab.Model.NavigationMenuModelProxy.prototype =
{
    loadNavigationMenuList: function (callBack, errorCallBack) {
        var url = "/Api/NavigationMenu/FetchNavigationMenuItems";
        this.ServerRequest("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.NavigationMenuModelProxy.prototype = $.extend({}, Ecolab.Model.NavigationMenuModelProxy.prototype, base);
Ecolab.Model.NavigationMenuModelProxy.prototype.base = base;
