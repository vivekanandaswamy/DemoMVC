Ecolab.Model.NavigationMenuModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.NavigationMenuModelProxy = new Ecolab.Model.NavigationMenuModelProxy();
};

Ecolab.Model.NavigationMenuModel.prototype = {

    init: function () {
    },

    loadNavigationMenuList: function () {
        var _this = this;
        _this.NavigationMenuModelProxy.loadNavigationMenuList(function (data, callBackData) {
            _this.settings.eventHandlers.onNavigationMenuListLoaded(data, callBackData);
        });
    },
};