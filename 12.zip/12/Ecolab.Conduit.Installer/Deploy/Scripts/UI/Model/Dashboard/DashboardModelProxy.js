Ecolab.Model.DashboardModelProxy = function () {
};

Ecolab.Model.DashboardModelProxy.prototype =
{
    loadDashboardList: function (callBack, errorCallBack) {
        var url = "/Api/Dashboard/FetchDashboardList";
        this.ServerRequest("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.DashboardModelProxy.prototype = $.extend({}, Ecolab.Model.DashboardModelProxy.prototype, base);
Ecolab.Model.DashboardModelProxy.prototype.base = base;