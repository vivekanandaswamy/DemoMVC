﻿Ecolab.Model.MonitorSetupModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onMonitorSetupLoaded: null,
            onMonitorSetupUpdated: null,
            onMonitorSetupUpdationFailed: null,
            onWasherFormulaLoaded: null,
            onMonitorSetupFetched: null,
            onWahserGroupLoaded: null,
            onEditDetailsFetched: null,
            onMonitorSetupDeleted:null,
            onMonitorSetupDeletionFailed: null,
            onMonitorsLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.MonitorSetupModelProxy = new Ecolab.Model.MonitorSetupModelProxy();
};

Ecolab.Model.MonitorSetupModel.prototype = {
    init: function () {
    },

    onAddMonitorClicked: function () {
        var _this = this;
        this.MonitorSetupModelProxy.loadMonitorSetup(function (data) {
            _this.settings.eventHandlers.onMonitorSetupLoaded(data);
        });
    },

    fetchWasherGroup: function (data) {
        var _this = this;
        this.MonitorSetupModelProxy.fetchWasherGroup(data,function (data) {
            _this.settings.eventHandlers.onWahserGroupLoaded(data);
        });
    },

    deleteMonitorSetup: function (id) {
        var _this = this;
        this.MonitorSetupModelProxy.deleteMonitorSetup(id, function (data) {
            _this.settings.eventHandlers.onMonitorSetupDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onMonitorSetupDeletionFailed(error, description); });
    },

    updateMonitorSetup: function (data,isInLine) {
        var _this = this;
        this.MonitorSetupModelProxy.updateMonitorSetup(data, function (data) {
            _this.settings.eventHandlers.onMonitorSetupUpdated(data, isInLine);
        }, function (error, description) { _this.settings.eventHandlers.onMonitorSetupUpdationFailed(error, description); });
    },

    FetchDataonDashboardTypeChange: function (id) {
        var _this = this;
        this.MonitorSetupModelProxy.fetchDataonDashboardTypeChange(id, function (data) {
            _this.settings.eventHandlers.onMachinesLoaded(data);
        });
    },

    FetchMonitorSetUpDetails: function () {
        var _this = this;
        this.MonitorSetupModelProxy.fetchMonitorSetUpDetails(function (data) {
            _this.settings.eventHandlers.onMonitorSetupFetched(data);
        });
    },
    FetchMonitors: function () {
        var _this = this;
        this.MonitorSetupModelProxy.FetchMonitors(function (data) {
            _this.settings.eventHandlers.onMonitorsLoaded(data);
        });
    },
    
    onEditClicked: function (id) {
        var _this = this;
        this.MonitorSetupModelProxy.fetchMonitorDetailsToEdit(id,function (data) {
            _this.settings.eventHandlers.onEditDetailsFetched(data);
        });
    }
};

