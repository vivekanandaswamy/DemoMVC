Ecolab.Model.StorageTanksModelProxy = function () {
};

Ecolab.Model.StorageTanksModelProxy.prototype =
{
    
    getStorageTanksDetails: function (ecolabAccountNumber , callBack) {
        var url = "Api/StorageTanks/GetTanksDetails";
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber };
        this.ApiRead("StorageTanks", url, function (response) { callBack(response); }, null, null, requestData);
    },

    DeleteStorageTanks: function (StorageTankData, callBack, errorCallBack) {
        var url = "Api/StorageTanks/DeleteStorageTanks";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, StorageTankData);
      
    },
    AddStorageTanks: function (ecolabAccountNumber , id , callBack) {
        var url = "Api/StorageTanks/GetAddEditStorageTanksDetails";
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber, "id": id };
        this.ApiRead("StorageTanks", url, function (response) { callBack(response); }, null, null, requestData);
    },

    EditStorageTanks: function (id,ecolabAccountNumber, callBack) {
        var url = "Api/StorageTanks/GetAddEditStorageTanksDetails";
        var requestData = { "id": id, "ecolabAccountNumber": ecolabAccountNumber };
        this.ApiRead("StorageTanks", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetControllerDetails: function (callBack) {
        var url = "Api/StorageTanks/GetControllerDetails";
        this.ApiRead("StorageTanks", url, function (response) { callBack(response); }, null, null, null);
    },
   
    CreateStorageTank: function (requestData, callBack, errorCallBack) {
        var url = "/Api/StorageTanks/CreateStorageTank";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    UpdateStorageTank: function (requestData, callBack, errorCallBack) {
        var url = "/Api/StorageTanks/UpdateStorageTank";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    validateTags: function (requestData, callBack, errorCallBack) {
        var url = "/api/StorageTanks/ValidateTags";
        return this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.StorageTanksModelProxy.prototype = $.extend({}, Ecolab.Model.StorageTanksModelProxy.prototype, base);
Ecolab.Model.StorageTanksModelProxy.prototype.base = base;