Ecolab.Model.ManualRewashModelProxy = function () {
};

Ecolab.Model.ManualRewashModelProxy.prototype =
{
    loadManualRewash: function (callBack, errorCallBack) {
        var url = "/Api/ManualRewash/Fetch";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    FetchFormulaByWasherGroup: function (id, callBack, errorCallBack) {
        var url = "/Api/ManualRewash/FetchMiFormulaDetails/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    FetchManualRewash: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualRewash/FetchManualRewash";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },

    deleteManualRewash: function (data, callBack, errorCallBack) {
        var url = "/Api/ManualRewash/DeleteManualRewash";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    },

    updateManualRewash: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualRewash/SaveManualProduction";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ManualRewashModelProxy.prototype = $.extend({}, Ecolab.Model.ManualRewashModelProxy.prototype, base);
Ecolab.Model.ManualRewashModelProxy.prototype.base = base;