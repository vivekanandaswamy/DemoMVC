﻿Ecolab.Model.ProductionDataModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onProductDataLoaded: null,
            onProductDataDeleted: null,
            onProductDataDeletionFailed: null,
            onProductDataUpdated: null,
            onProductDataUpdationFailed: null,
            onWasherFormulaLoaded: null,
            onProductionDataFetched:null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ProductionDataModelProxy = new Ecolab.Model.ProductionDataModelProxy();
};

Ecolab.Model.ProductionDataModel.prototype = {
    init: function () {
    },

    loadProductData: function () {
        var _this = this;
        this.ProductionDataModelProxy.loadProductData(function (ProductData) {
            _this.settings.eventHandlers.onProductDataLoaded(ProductData);
        });
    },

    deleteProductData: function (manualProductionViewModel) {
        var _this = this;
        this.ProductionDataModelProxy.deleteProductData(manualProductionViewModel, function (data) {
            _this.settings.eventHandlers.onProductDataDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataDeletionFailed(error, description); });
    },

    updateProductData: function (manualProductionViewModel) {
        var _this = this;
        this.ProductionDataModelProxy.updateProductData(manualProductionViewModel, function (data) {
            _this.settings.eventHandlers.onProductDataUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataUpdationFailed(error, description); });
    },

    FetchWasherFormulaByWasherGroup: function (groupId) {
        var _this = this;
        this.ProductionDataModelProxy.FetchWasherFormulaByWasherGroup(groupId, function (data) {
            _this.settings.eventHandlers.onWasherFormulaLoaded(data);
        });
    },

    FetchProductionData: function (manualProductionModel) {
        var _this = this;
        this.ProductionDataModelProxy.FetchProductionData(manualProductionModel, function (data) {
            _this.settings.eventHandlers.onProductionDataFetched(data);
        });
    }
};

