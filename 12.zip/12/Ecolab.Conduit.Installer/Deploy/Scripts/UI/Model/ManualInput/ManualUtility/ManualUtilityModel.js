﻿Ecolab.Model.ManualUtilityModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onProductDataLoaded: null,
            onManualUtilityDeleted: null,
            onManualUtilityDeletionFailed: null,
            onManualUtilityUpdated: null,
            onManualUtilityUpdationFailed: null,
            onManualUtilityFetched: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ManualUtilityModelProxy = new Ecolab.Model.ManualUtilityModelProxy();
};

Ecolab.Model.ManualUtilityModel.prototype = {
    init: function () {
    },

    loadManualUtility: function () {
        var _this = this;
        this.ManualUtilityModelProxy.loadManualUtility(function (data) {
            _this.settings.eventHandlers.onManualUtilityLoaded(data);
        });
    },

    deleteManualUtility: function (data) {
        var _this = this;
        this.ManualUtilityModelProxy.deleteManualUtility(data, function (data) {
            _this.settings.eventHandlers.onManualUtilityDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onManualUtilityDeletionFailed(error, description); });
    },

    updateManualUtility: function (data,isInline) {
        var _this = this;
        this.ManualUtilityModelProxy.updateManualUtility(data, function (data) {
            _this.settings.eventHandlers.onManualUtilityUpdated(data,isInline);
        }, function (error, description) { _this.settings.eventHandlers.onManualUtilityUpdationFailed(error, description); });
    },

    FetchFormulaByWasherGroup: function (groupId) {
        var _this = this;
        this.ManualUtilityModelProxy.FetchFormulaByWasherGroup(groupId, function (data) {
            _this.settings.eventHandlers.onFormulaLoaded(data);
        });
    },

    FetchManualUtility: function (manualProductionModel) {
        var _this = this;
        this.ManualUtilityModelProxy.FetchManualUtility(manualProductionModel, function (data) {
            _this.settings.eventHandlers.onManualUtilityFetched(data);
        });
    }
};

