﻿Ecolab.Model.ManualRewashModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onProductDataLoaded: null,
            onProductDataDeleted: null,
            onProductDataDeletionFailed: null,
            onProductDataUpdated: null,
            onProductDataUpdationFailed: null,
            onWasherFormulaLoaded: null,
            onManualRewashFetched: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ManualRewashModelProxy = new Ecolab.Model.ManualRewashModelProxy();
};

Ecolab.Model.ManualRewashModel.prototype = {
    init: function () {
    },

    loadManualRewash: function () {
        var _this = this;
        this.ManualRewashModelProxy.loadManualRewash(function (data) {
            _this.settings.eventHandlers.onManualRewashLoaded(data);
        });
    },

    deleteManualRewash: function (data) {
        var _this = this;
        this.ManualRewashModelProxy.deleteManualRewash(data, function (data) {
            _this.settings.eventHandlers.onManualRewashFetched(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataDeletionFailed(error, description); });
    },

    updateManualRewash: function (data) {
        var _this = this;
        this.ManualRewashModelProxy.updateManualRewash(data, function (data) {
            _this.settings.eventHandlers.onManualRewashFetched(data);
        }, function (error, description) { _this.settings.eventHandlers.onManualRewashUpdationFailed(error, description); });
    },

    FetchFormulaByWasherGroup: function (groupId) {
        var _this = this;
        this.ManualRewashModelProxy.FetchFormulaByWasherGroup(groupId, function (data) {
            _this.settings.eventHandlers.onFormulaLoaded(data);
        });
    },

    FetchManualRewash: function (manualProductionModel) {
        var _this = this;
        this.ManualRewashModelProxy.FetchManualRewash(manualProductionModel, function (data) {
            _this.settings.eventHandlers.onManualRewashFetched(data);
        });
    }
};

