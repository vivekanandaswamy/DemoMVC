Ecolab.Model.LaborDataModelProxy = function () {
};

Ecolab.Model.LaborDataModelProxy.prototype =
{
    getLaborTypeAndLocation: function (callBack, errorCallBack) {
        var url = "/Api/ManualLabor/GetManualLaborDetails";
        var requestData = {"ecolabAccountNumber":1, "regionId":1};
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    SavelaborData: function (reqdata, callBack, errorCallBack) {
        var url = "/Api/ManualLabor/SaveLaborData";

        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, reqdata);
    },
    GetLaborCost: function (ecolabAccountNumber, locationId, manHourTypeId, callBack, errorCallBack) {
        var url = "/Api/ManualLabor/LaborCost";
        var requestData = { "ecolabAccountNumber":ecolabAccountNumber, "locationId":locationId, "manHourTypeId":manHourTypeId };
        this.ApiRead("ManualLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteManualLabor: function (data, callBack, errorCallBack) {
        var url = "/Api/ManualLabor/DeleteManualLabor";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.LaborDataModelProxy.prototype = $.extend({}, Ecolab.Model.LaborDataModelProxy.prototype, base);
Ecolab.Model.LaborDataModelProxy.prototype.base = base;