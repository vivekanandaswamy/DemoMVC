Ecolab.Model.RedFlagModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onRedFlagDataLoaded: null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.RedFlagModelProxy = new Ecolab.Model.RedFlagModelProxy();
};
Ecolab.Model.RedFlagModel.prototype = {
    init: function () {
    },
    loadRedFlagData: function () {
        var _this = this;
        this.RedFlagModelProxy.loadRedFlagData(function (RedFlagData) {
            _this.settings.eventHandlers.onRedFlagDataLoaded(RedFlagData);
        });
    },
    loadItemData: function () {
        var _this = this;
        this.RedFlagModelProxy.loadItemData(function (data) {
            _this.settings.eventHandlers.onAddRedFlagDataLoaded(data);
        });
    },
    loadOnItemChangedData: function (id, itemId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnItemChangedData(id, itemId, function (data) {
            _this.settings.eventHandlers.onItemChangedDataLoaded(data);
        });
    },
    loadOnLocationChangedData: function (id, itemId, locationId) {
        var _this = this;
        this.RedFlagModelProxy.loadOnLocationChangedData(id, itemId, locationId, function (data) {
            _this.settings.eventHandlers.onLocationChangedDataLoaded(data);
        });
    },
    onEditRedFlagClicked: function (id) {
        var _this = this;
        this.RedFlagModelProxy.onEditRedFlagClicked(id, function (data) {
            _this.settings.eventHandlers.onEditRedFlagDataLoaded(data);
        });
    },
    onDeleteRedFlagClicked: function (id) {
        var _this = this;
        this.RedFlagModelProxy.onDeleteRedFlagClicked(id, function (data) {
            _this.settings.eventHandlers.onDeleteRedFlagResponseLoaded(data);
        });
    }

};