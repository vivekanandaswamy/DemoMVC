Ecolab.Model.RedFlagModelProxy = function () {
};

Ecolab.Model.RedFlagModelProxy.prototype =
{
    loadRedFlagData: function (callBack, errorCallBack) {
        var url = "/Api/RedFlag/Get";
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadItemData: function (callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetItemData";
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadOnItemChangedData: function (id, itemId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnItemChange";
        var requestData = { "id": id, "itemId": itemId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadOnLocationChangedData: function (id, itemId, locationId, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnLocationChange";
        var requestData = { "id": id, "itemId": itemId, "locationId": locationId };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    onEditRedFlagClicked: function (id, callBack, errorCallBack) {
        var url = "/Api/RedFlag/GetOnEditClicked";
        var requestData = { "id": id };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    onDeleteRedFlagClicked: function (id, callBack, errorCallBack) {
        var url = "/Api/RedFlag/Delete";
        var requestData = { "id": id };
        this.ApiRead("RedFlag", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

};
var base = new Ecolab.Model.Common();
Ecolab.Model.RedFlagModelProxy.prototype = $.extend({}, Ecolab.Model.RedFlagModelProxy.prototype, base);
Ecolab.Model.RedFlagModelProxy.prototype.base = base;