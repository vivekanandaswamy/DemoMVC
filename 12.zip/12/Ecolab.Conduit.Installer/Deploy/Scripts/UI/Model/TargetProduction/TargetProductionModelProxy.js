Ecolab.Model.TargetProductionModelProxy = function () {
};

Ecolab.Model.TargetProductionModelProxy.prototype =
{
    loadTargetProductionData: function (callBack, errorCallBack) {
        var url = "/Api/TargetProduction/FetchTargetProductionDetails";
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    updateTargetProductionData: function (laborCostViewModel, callBack, errorCallBack) {
        var url = "/Api/TargetProduction/Put";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, laborCostViewModel);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.TargetProductionModelProxy.prototype = $.extend({}, Ecolab.Model.TargetProductionModelProxy.prototype, base);
Ecolab.Model.TargetProductionModelProxy.prototype.base = base;