// JavaScript source code
Ecolab.Model.MyProfileModelProxy = function () {
};

Ecolab.Model.MyProfileModelProxy.prototype =
{
    loadMyProfileData: function (callBack, errorCallBack) {
        var url = "/Api/MyProfile/FetchMyProfileDetails";
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    updateMyProfile: function (requestData, callBack, errorCallBack) {
        var url = "/Api/MyProfile/SaveUserProfile";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updatePassword: function (requestData, callBack, errorCallBack) {
        var url = "/Api/MyProfile/SavePassword";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
   
}
var base = new Ecolab.Model.Common();
Ecolab.Model.MyProfileModelProxy.prototype = $.extend({}, Ecolab.Model.MyProfileModelProxy.prototype, base);
Ecolab.Model.MyProfileModelProxy.prototype.base = base;