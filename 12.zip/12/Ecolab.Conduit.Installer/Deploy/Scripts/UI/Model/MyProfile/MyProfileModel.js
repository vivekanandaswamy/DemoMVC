// JavaScript source code
Ecolab.Model.MyProfileModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            loadMyProfileData: null,
            onMyProfileUpdated: null,
            onMyProfilePasswordUpdated: null,
            onMyProfileDataLoadFailed: null,
            onMyProfileDataUpdationFailed: null,
            onMyProfilePasswordUpdationFailed: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.MyProfileModelProxy = new Ecolab.Model.MyProfileModelProxy();
};

Ecolab.Model.MyProfileModel.prototype = {
    init: function () {
    },

    loadMyProfileData: function () {
        var _this = this;
        _this.MyProfileModelProxy.loadMyProfileData(function (MyProfileData) {
            _this.settings.eventHandlers.onMyProfileDataLoaded(MyProfileData);
        }, function (error, description) { _this.settings.eventHandlers.onMyProfileDataLoadFailed(error, description); });
    },

    updateMyProfile: function (MyProfileData) {
        var _this = this;
        _this.MyProfileModelProxy.updateMyProfile(MyProfileData, function (MyProfileData) {
            _this.settings.eventHandlers.onMyProfileUpdated(MyProfileData);
        }, function (error, description) { _this.settings.eventHandlers.onMyProfileDataUpdationFailed(error, description); });
    },

    updatePassword: function (MyProfileData) {
        var _this = this;
        _this.MyProfileModelProxy.updatePassword(MyProfileData,function (MyProfileData) {
            _this.settings.eventHandlers.onMyProfilePasswordUpdated(MyProfileData);
        }, function (error, description) { _this.settings.eventHandlers.onMyProfilePasswordUpdationFailed(error, description); });
    },


}