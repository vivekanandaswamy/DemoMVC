Ecolab.Presenters.ControllerSetupAdvancePage = function(options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ControllerSetupAdvancePage.prototype = {
    initViews: function() {
        this.base.initViews.call(this);
        this.initControllerSetupTabsView();
        this.initControllerSetupView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function() {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function(modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function(eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function() {
        var _this = this;
        return {
            onGetMetaDataReceived: function(data) { _this.onGetMetaDataReceived(data); },
            onGetMetaDataWithValuesReceived: function(data) { _this.onGetMetaDataWithValuesReceived(data); },
            onMetaDataSaved: function() { _this.onMetaDataSaved(); },
            onMetaDataSavedFailed: function(data, exception) { _this.onMetaDataSavedFailed(data, exception); }
        };
    },
    afterInit: function() {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showControllerBreadCrumb();
    },
    initControllerSetupTabsView: function() {
        var _this = this;
        if (!this.Views.ControllerSetupTabsView) {
            this.Views.ControllerSetupTabsView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function() { _this.loadMetaData(); },
                    advanceTabClicked: function() { _this.onAdvanceTabClicked(); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function() { _this.onSetupTabClicked(); },
                    onBackButtonClick: function() { _this.onBackButtonClick(); }
                }
            });
        }
        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            this.Views.ControllerSetupTabsView.setController(cData);
            _this.findContainer('Controllers', cData.ControllerId);
        }
        this.Views.ControllerSetupTabsView.setData(this.settings.accountInfo);
    },
    initControllerSetupView: function() {
        var _this = this;
        if (!this.Views.ControllerSetupAdvanceView) {
            this.Views.ControllerSetupAdvanceView = new Ecolab.Views.ControllerSetupAdvance({
                containerSelector: '#tabAdvancedContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function() {},
                    onSaveMetaDataInfo: function(dataArr) { _this.onSaveMetaDataInfo(dataArr); },
                    onUpdateMetaDataInfo: function(dataArr) { _this.onUpdateMetaDataInfo(dataArr); },
                    onSavePage: function(message) { _this.confirmationPage(message); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    dynamicRendered: null
                }
            });
        }

    },
    confirmationPage: function(message) {
        if (message != "") {
            var _this = this;
            var cDialog = $('#ConfirmDialog');
            cDialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
                BodyMessage: message, //$.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
                Buttons: {
                    Ok: {
                        Callback: function() {
                            cDialog.addClass('hide');
                            _this.savePage();
                        },
                        CallbackParameters: null
                    },
                    Cancel: {
                        Callback: function() {
                            cDialog.addClass('hide');
                            _this.Views.ControllerSetupAdvanceView.cancelConfirmation();
                            return false;
                        },
                        CallbackParameters: null
                    }
                }
            };
            this.Views.confirmDialog.setData(dialogOptions);
        } else {
            this.savePage();
        }
    },

    savePage: function() {
        var view = this.Views.ControllerSetupAdvanceView;
        if (view) {
            if (view.validate()) {
                if (this.HasDuplicateTags()) {
                    view.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                    return false;
                } else {
                    var dataArr = view.getData();
                    if (this.onSaveMetaDataInfo) {
                        this.onSaveMetaDataInfo(dataArr);
                    }
                    this.isDirty = false;
                }
            } else {
                return false;
            }
        }
    },
    showControllerBreadCrumb: function() {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLERSETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onAdvanceTabClicked: function() {
        this.loadMetaData();
    },
    onSetupTabClicked: function() {
    },
    navigateToConfigPage: function(id) {
    },
    onBackButtonClick: function() {
        this.onControllerSetupClicked();
    },
    loadMetaData: function() {
        if (this.settings.accountInfo.ControllerId != "-1") {
            this.Model.getMetaData(3, this.settings.accountInfo.ControllerId);
        }
    },
    onSaveMetaDataInfo: function(dataArr) {
        this.Model.saveMetaData(dataArr);
    },
    onUpdateMetaDataInfo: function(dataArr) {
        this.Model.updateMetaData(dataArr);
    },
    onGetMetaDataReceived: function(data) {
        this.Views.ControllerSetupAdvanceView.setData(data);
        this.Views.ControllerSetupAdvanceView.setDynamicUI(data);
    },
    onGetMetaDataWithValuesReceived: function(data) {
        this.Views.ControllerSetupAdvanceView.setData(data);
        this.Views.ControllerSetupAdvanceView.setDynamicUI(data);
    },
    onMetaDataSaved: function() {
        this.Views.ControllerSetupAdvanceView.onMetaDataSaved();
    },
    onMetaDataSavedFailed: function(data, exception) {
        this.Views.ControllerSetupAdvanceView.onMetaDataSavedFailed(data, exception);
    },
    openCurrentNav: function(typeName, id) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('open');
        element.children('ul').slideDown();
    },
    findContainer: function(typeName, id) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function() { _this.openCurrentNav(typeName, id); }, 200);
        return;

    }
};