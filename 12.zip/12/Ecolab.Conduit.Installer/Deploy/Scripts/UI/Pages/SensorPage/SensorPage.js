﻿Ecolab.Presenters.SensorPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.SensorPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onSensorDataLoaded: function (data) { _this.onSensorDataLoaded(data); },
            loadUoMCallBack: function (data) { _this.loadUomCallBackLoaded(data); },
            onloadMachineCompartmentByUtilityLocationIdLoaded: function (data) { _this.loadMachineCompartmentDataLoaded(data); },
            loadDefaultDataLoaded: function (data) { _this.loadDefaultDataLoadedCallback(data); },
            loadChemicalforChartLoaded: function (data) { _this.loadChemicalforChartLoadedCallback(data); },
            onloadSensorOnAddNewPopupDataLoaded: function (data) { _this.loadSensorOnAddNewPopupDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.SensorView) {
            this.Views.SensorView = new Ecolab.Views.Sensor(
                        {
                            containerSelector: '#tabSensorContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadSensorData(); },
                                onUtilityTypeChange: function (id) { _this.loadUoM(id); },
                                onUtilityLocationChange: function (id) { _this.loadMachineCompartmentByUtilityLocationId(id); },
                                onMachineChange: function (id) { _this.loadChemicalforChart(id); },
                                onEditSensorPopupLoad: function (id) { _this.loadDefaultData(id) },
                                onAddNewSensorPopupLoad: function () { _this.loadSensorOnAddNewPopupLoad(); },
                                checkDuplicates: function () { return _this.HasDuplicateTags(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
            this.Views.SensorView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadSensorData: function () {
        this.Model.loadSensorData();
    },
    onSensorDataLoaded: function (data) {
        this.Views.SensorView.setSensorData(data);
    },
    loadUoM: function (UtilityId) {
        this.Model.loadUoMModel(UtilityId);
    },
    loadUomCallBackLoaded: function (data) {
        this.Views.SensorView.SetUoMData(data);
    },
    loadMachineCompartmentByUtilityLocationId: function(UtilityLocationId){
        this.Model.loadMachineCompartmentByUtilityLocationId(UtilityLocationId);
    },
    loadMachineCompartmentDataLoaded: function (data) {
        this.Views.SensorView.SetMachineCompartmentData(data);
    },

    loadDefaultData: function (SensorId) {
        this.Model.loadDefaultData(SensorId);
    },
    loadDefaultDataLoadedCallback: function (data) {
        this.Views.SensorView.SetDefaultData(data);
    },
    loadChemicalforChart:function(data){
        this.Model.loadChemicalforChart(data);
    },
    loadChemicalforChartLoadedCallback: function (data) {
        this.Views.SensorView.SetChemicalforChart(data);
    },

    loadSensorOnAddNewPopupLoad: function () {
        this.Model.loadSensorOnAddNewPopupLoad();
    },
    loadSensorOnAddNewPopupDataLoaded: function (data) {
        this.Views.SensorView.SetDefaultDataOnAdd(data);
    },

};