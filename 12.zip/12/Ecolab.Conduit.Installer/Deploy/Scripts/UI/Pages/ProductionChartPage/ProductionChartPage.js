﻿Ecolab.Presenters.ProductionChartPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ProductionChartPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initTrendingView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onTunnelDataLoad: function (data) { _this.onTunnelDataLoaded(data); },
            onParametersDataLoad: function (data) { _this.onParametersDataLoaded(data); },
            // onloadByFiltersLoad: function (data) { _this.onloadByFiltersLoaded(data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initTrendingView: function () {
        var _this = this;
        if (!this.Views.ProductionChartView) {
            this.Views.ProductionChartView = new Ecolab.Views.ProductionChart(
                        {
                            containerSelector: '#visualizationContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadTunnelData(); },
                                loadParameters: function (id, chartId) { _this.loadParametersData(id, chartId); },
                                loadByFilters: function (filters, callBack, current) { _this.loadByFilters(filters, callBack, current); }

                            }
                        });
            this.Views.ProductionChartView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        if (this.getChartTypeId() == 1) {
            breadCrumbData.name = "Production Trend Chart";
            breadCrumbData.url = "/TrendingChart/index?type=1";
        }
        if (this.getChartTypeId() == 2) {
            breadCrumbData.name = "Chemical Injection Chart";
            breadCrumbData.url = "/TrendingChart/index?type=2";
        }
        this.showPlantBreadCrumb("Visualization", breadCrumbData);
    },
    getChartTypeId: function () {
        var _this = this;
        var chartType = 1;
        if (_this.getQueryStringByName('type')) {
            chartType = _this.getQueryStringByName('type');
        }

        return chartType;
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    loadTunnelData: function () {
        this.Model.loadTunnelData();
    },
    onTunnelDataLoaded: function (data) {
        this.Views.ProductionChartView.bindTunnelData(data);
    },
    loadParametersData: function (id, chartId) {
        this.Model.loadParametersData(id, chartId);
    },
    onParametersDataLoaded: function (data) {
        this.Views.ProductionChartView.bindParameterData(data);
    },
    loadByFilters: function (filters, callBack, current) {
        this.Model.loadByFilters(filters, callBack, current);
    },
    //onloadByFiltersLoaded: function (data) {
    //    this.Views.ProductionChartView.onloadByFiltersLoaded(data);
    //},
};