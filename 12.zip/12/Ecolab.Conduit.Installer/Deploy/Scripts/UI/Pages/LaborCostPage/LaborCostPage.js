Ecolab.Presenters.LaborCostPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.LaborCostPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onLaborCostDataLoaded: function (data) { _this.onLaborCostDataLoaded(data); },
            onLaborCostDataUpdated: function (data) { _this.onLaborCostDataUpdated(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadLaborCostData(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.LaborCostView) {
            this.Views.LaborCostView = new Ecolab.Views.LaborCost(
                        {
                            containerSelector: '#tabLaborCostContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onSaveClicked: function (laborCostViewModel) { _this.onSaveClicked(laborCostViewModel); }
                            }
                        });
            //this.Views.LaborCostView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);

    },
    savePage: function () {
        var _this = this;
        var view = this.Views.LaborCostView;
        if (view) {
            if (view.validate()) {
                var data = this.Views.LaborCostView.getNewData();
                this.Model.updateLaborCostData(data);
                this.isDirty = false;
            }
        }
    },
    navigateToConfigPage: function (id) {
    },
    loadLaborCostData: function () {
        this.Model.loadLaborCostData();
    },
    onLaborCostDataLoaded: function (data) {
        this.Views.LaborCostView.setData(data);
    },
    onSaveClicked: function (laborCostViewModel) {
        this.Model.updateLaborCostData(laborCostViewModel);
    },
    onLaborCostDataUpdationFailed: function (data, description) {
        this.Views.LaborCostView.showMessage("501");
    },
    onLaborCostDataUpdated: function (data) {
        this.Views.LaborCostView.showMessage("201");
    },
};