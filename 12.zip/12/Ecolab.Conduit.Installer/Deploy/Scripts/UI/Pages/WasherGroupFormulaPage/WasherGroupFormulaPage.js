Ecolab.Presenters.WasherGroupFormulaPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    var washerGroupOutPutId = 0;
    var FormulaId = 0;
    this.message = "";
    this.washerMessage = "";
    this.listMessage = "";
    this.url = window.location.href;
    this.isDirty = false;
    this.washerGroupTypeId = 0;
    this.washerGroupId = 0;
};

Ecolab.Presenters.WasherGroupFormulaPage.prototype = {
    // initialising the base & view events.
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherGroupFormulaTabsView();
        this.initAddWasherGroupView();
        this.initFormulaView();
        this.initAddEditFormulaView();
        this.initAddWasherStepView();
        this.initTunnelWasherStepView();
        this.initTunnelWasherStepGridView();
        this.initTunnelGridProductListView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();

    },

    // initialising the base & model events.
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },

    // Adding options to the model like pagesize and sort order etc.,
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },

    // event is for adding the event handlers in the model to access them in presenter.
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },

    // calling the callback events from model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onWasherGroupDataLoad: function (WasherGroupData) { _this.onWasherGroupDataLoad(WasherGroupData); }, //Event is used for getting the data from the model.
            onFormulaDataLoad: function (WasherGroupData) { _this.onFormulaDataLoad(WasherGroupData); }, //Event is used for getting the data from the model.
            onWasherGroupCreated: function (washerGroupData) { _this.onWasherGroupCreated(washerGroupData); },
            onWasherGroupUpdated: function (washerGroupData) { _this.onWasherGroupUpdated(washerGroupData); },
            onWasherGroupDeletionFailed: function (error, description) { _this.onWasherGroupDeletionFailed(error, description); }, //Event gets the error with error details.            
            onGetAddFormulaDataRecieved: function (data) { _this.onGetAddFormulaDataRecieved(data); },
            onGetEditFormulaDataRecieved: function (data) { _this.onGetEditFormulaDataRecieved(data); },
            onFormulaCreated: function (FormulaId, FormulaData) { _this.onFormulaCreated(FormulaId, FormulaData); },
            onWasherGroupFormulaDeleted: function (WasherGroupData) { _this.onWasherGroupFormulaDeleted(WasherGroupData); },
            onWasherGroupWashStepDeleted: function (WasherGroupData) { _this.onWasherGroupWashStepDeleted(WasherGroupData); },
            onFormulaUpdated: function (data, FormulaData) { _this.onFormulaUpdated(data, FormulaData); },
            onInlineFormulaUpdated: function (data) { _this.onInlineFormulaUpdated(data); },
            //Wash Step Model events
            onWashStepDataLoad: function (washStepData) { _this.onWashStepDataLoad(washStepData); },
            onCopyWashStepDataLoad: function (washStepData) { _this.onCopyWashStepDataLoad(washStepData); },
            onWashStepCreationSuccess: function (washStepData) { _this.onWashStepCreationSuccess(washStepData); },
            onWashStepCreationFailed: function (errorData) { _this.onWashStepCreationFailed(errorData); },
            onTunnelWashStepCreationSuccess: function (washStepData) { _this.onTunnelWashStepCreationSuccess(washStepData); },
            onTunnelWashStepCreationFailed: function (errorData) { _this.onTunnelWashStepCreationFailed(errorData); },
            //Tunnel Wash Step call back methods
            onTunnelWashStepSetData: function (tunnelWasherData) { _this.onTunnelWashStepSetData(tunnelWasherData); },
            //onTunnelWashStepFailes: function (error, tunnelWashErrorData) { _this.onTunnelWashStepFailes(error,tunnelWashErrorData); }
            onTunnelGridViewSetData: function (tunnelGridViewData) { _this.onTunnelGridViewSetData(tunnelGridViewData); },
            onTunnelGridSuccess: function (responseData) { _this.onTunnelGridSuccess(responseData); },
            onTunnelGridFailed: function (responseData) { _this.onTunnelGridFailed(responseData); },
            onWasherDeleted: function (Data) { _this.onWasherDeleted(Data); },
            onWasherDeletionFailed: function (Data) { _this.onWasherDeletionFailed(Data); },
        };
    },

    // for loading the events after initialising.
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showWasherGroupBreadCrumb();
        this.isDirty = false;
    },


    // initialising the washer group tabs view.
    initWasherGroupFormulaTabsView: function () {
        var _this = this;
        if (!this.Views.WasherGroupFormulaTabsView) {
            this.Views.WasherGroupFormulaTabsView = new Ecolab.Views.WasherGroupFormulaTabs({
                containerSelector: '#tabContainer', // Need to clarify the div id to be assign here
                eventHandlers: {
                    rendered: function () { _this.onTabRendered(); },
                    onFormulaTabClick: function () { _this.onFormulaTabClick(); },
                    onWasherGroupClick: function () { _this.onWasherGroupClick(); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); }
                }
            });

        }

        this.Views.WasherGroupFormulaTabsView.setData(this.settings.accountInfo);
    },

    onWasherGroupClick: function () {
        var _this = this;
        var id = _this.getQueryStringByName('id');
        this.loadAddEditWasherGroupModelData(id);
    },

    initAddWasherGroupView: function () {
        var _this = this;

        var id = _this.getQueryStringByName('id');
        if (!this.Views.AddWasherGroup) {
            this.Views.AddWasherGroup = new Ecolab.Views.AddWasherGroup({
                containerSelector: '#tabAddWasherGroupContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onSavePage: function () { _this.saveWasherGroupPage("WasherGroup"); },
                    onAddNewWasher: function () { _this.onAddNewWasher(); },
                    onWasherDeleteClicked: function (isTunnel, id) { return _this.onWasherDeleteClicked(isTunnel, id) },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        //this.loadAddEditWasherGroupModelData(0);
    },
    initAddEditFormulaView: function () {
        var _this = this;
        if (!this.Views.AddEditFormulaView) {
            this.Views.AddEditFormulaView = new Ecolab.Views.AddFormula({
                containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onrendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSavePage: function () { _this.savePage("Formula"); },
                    onFormulaSaveClicked: function (FormulaData) { return _this.onFormulaSaveClicked(FormulaData); },
                    onWashStepClicked: function () { _this.onWashStepClicked(); },
                    onWashStepDeleteClicked: function (id) { _this.onWashStepDeleteClicked(id); },
                    onUpdateWashStepClicked: function (id) { _this.onUpdateWashStepClicked(id); },
                    onCopyWashStepClicked: function (id) { _this.onCopyWashStepClicked(id); },
                    onTunnelUpdateWashStepClicked: function (id) { _this.onTunnelUpdateWashStepClicked(id); },
                    onFormulaTabClick: function () { _this.onFormulaTabClick(); },
                    onFormulaBackButtonClick: function () { _this.onFormulaBackButtonClick(); },
                }
            });
        }
        //this.loadAddEditWasherGroupModelData(0);
    },
    initFormulaView: function () {
        var _this = this;
        var id = _this.getQueryStringByName('id');
        if (!this.Views.WasherGroupFormulasListView) {
            this.Views.WasherGroupFormulasListView = new Ecolab.Views.WasherGroupFormulasList({
                containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onAddEditFormulaClicked: function () { return _this.onAddEditFormulaClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onDeleteFormulaListClicked: function (Id) { _this.onDeleteFormulaListClicked(Id); },
                    onEditFormulaClicked: function (id) { return _this.onEditFormulaClicked(id) },
                    onFormulaInlineUpdateClicked: function (FormulaData) { return _this.onFormulaInlineUpdateClicked(FormulaData) },
                }
            });
        }
        this.loadAddEditWasherGroupModelData(id);
    },

    onTabRendered: function () {
        var _this = this;

        var id = _this.getQueryStringByName('id');
        var formulaId = _this.getQueryStringByName('formulaId');
        var type = _this.getQueryStringByName('type');
        var path = this.settings.accountInfo.Path;
        if (formulaId > 0) {
            _this.onEditFormulaClicked(formulaId);
            _this.findContainer('Formula', formulaId, id,'Formulas')
        }
        else {
            if (path == null || path == undefined) {
                if (this.settings.accountInfo.WasherGroupId != undefined && id == 0)
                    id = this.settings.accountInfo.WasherGroupId;
                _this.findContainer('Washer Groups', id, 0, 'WasherGroupWashers')
                this.loadAddEditWasherGroupModelData(id);
            }
            else if (path != null) {
                this.settings.accountInfo.WasherGroupId = id;
                this.onFormulaTabClick();
            }
            if(type == "Formulas")
            {
                this.settings.accountInfo.WasherGroupId = id;
                this.onFormulaTabClick();
            }
        }
    },
    showWasherGroupBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERGROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onBackButtonClick: function () {
        this.onWasherGroupClicked();
    },
    loadAddEditWasherGroupModelData: function (washerGroupId) {
        var _this = this;
        var dir = this.isDirty;
        if (!dir) {
            var id = this.settings.accountInfo.WasherGroupId;
            if (id != undefined && id > 0)
                washerGroupId = id;
            this.washerActiveClass();

            this.Model.loadAddEditWasherGroupModelData(washerGroupId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
        } else {
            this.RedirctTab("WasherGroup");
        }


    },

    //gets the data from model and passing to view to bind the data.
    onWasherGroupDataLoad: function (WasherGroupData) {
        if (WasherGroupData.WasherGroupDetails.length == 0) {
            WasherGroupData.WasherGroupDetails[0] = {
                WasherGroupId: 0,
                WasherGroupNumber: 1,
                WasherGroupName: '',
                WasherGroupTypeId: 1
            }
            WasherGroupData.Mode = "Add";

        }
        else {
            this.washerGroupTypeId = WasherGroupData.WasherGroupDetails[0].WasherGroupTypeId;
            this.settings.accountInfo.WasherGroupTypeId = WasherGroupData.WasherGroupDetails[0].WasherGroupTypeId;
            this.settings.accountInfo.WasherGroupId = WasherGroupData.WasherGroupDetails[0].WasherGroupId;
            this.WasherGroupId = WasherGroupData.WasherGroupDetails[0].WasherGroupId;
            WasherGroupData.Mode = "Edit";
        }
        this.settings.accountInfo.FileName = "WasherGroup";
        if (WasherGroupData.WasherGroupDetails[0].WasherGroupTypeId == 2) {
            if (WasherGroupData.WashersList[0] != null) {
                this.settings.accountInfo.Maxload = WasherGroupData.WashersList[0].Maxload;
            }

        }
        WasherGroupData.washerMessage = this.washerMessage;
        this.Views.AddWasherGroup.setData(WasherGroupData);
        this.Views.AddWasherGroup.showMessage(this.message);
    },

    onFormulaTabClick: function () {
        var _this = this;
        var id = this.washerGroupOutPutId;
        if (id == undefined)
            id = this.settings.accountInfo.WasherGroupId;
        if (this.isDirty != true) {
            if (id != undefined && id > 0) {
                this.formulasActiveClass();
                this.Model.loadWasherGroupModelData(id, this.settings.accountInfo.EcolabAccountNumber);

            } else {
                this.washerActiveClass();
                this.onWasherGroupClick();
            }
        }
        else {
            this.RedirctTab("Formula");
        }
    },
    onFormulaDataLoad: function (data) {
        dr = {};
        dr.data = data;
        dr.listMessage = this.listMessage;
        this.listMessage = "";
        this.settings.accountInfo.FileName = "FormulaList";
        if (data.WasherGroupDetails[0].WasherGroupTypeId == 2)
            data.Maxload = this.settings.accountInfo.Maxload;

        this.Views.WasherGroupFormulasListView.setData(dr);
    },
    ////Events is for deleting the washer group based on the washer group id.

    saveWasherGroupPage: function (fileName) {
        this.settings.accountInfo.FileName = fileName;
        this.savePage();
    },


    savePage: function () {
        var _this = this;
        this.isDirty = false;
        this.washerMessage = '';
        var fileName = this.settings.accountInfo.FileName;
        if (fileName == "FormulaList") {
            var view = this.Views.WasherGroupFormulasListView;
            if (view.validateFormula()) {
                view.getInlineData();
            }
        } else if (fileName == "Formula") {
            var AddEditFormulaView = this.Views.AddEditFormulaView;

            if (AddEditFormulaView) {
                if (AddEditFormulaView.validateFormula()) {
                    var FormulaData = this.Views.AddEditFormulaView.getFormulaData();
                    if (FormulaData.Id > 0) {
                        if (this.onFormulaUpdateClicked)
                            this.onFormulaUpdateClicked(FormulaData);
                    } else {

                        if (this.onFormulaSaveClicked) {
                            this.onFormulaSaveClicked(FormulaData);
                        }
                    }
                }
            }
        } else if (fileName == "WasherGroup") {

            var AddWasherGroup = this.Views.AddWasherGroup;
            if (AddWasherGroup) {
                if (AddWasherGroup.validateWasherGroup()) {
                    var washerGroupData = AddWasherGroup.getWasherGroupsData();
                    this.settings.accountInfo.WasherGroupTypeId = washerGroupData.WasherGroupTypeId;
                    if (washerGroupData.WasherGroupId > 0) {
                        this.onWasherGroupUpdateClicked(washerGroupData);
                    } else {
                        this.onWasherGroupSaveClicked(washerGroupData);
                    }
                } else {
                    return false;
                    //this.cancelPage();
                }
            }
        }
        else if (fileName == "WasherWashStep") {
            var washStepView = this.Views.AddWasherStepView;
            if (washStepView) {
                if (washStepView.validate()) {
                    var washStepData = washStepView.getWashStepData();
                    if (this.washerGroupOutPutId == undefined)
                        this.washerGroupOutPutId = _this.getQueryStringByName('id');
                    washStepData.RegionId = this.settings.accountInfo.RegionId;
                    washStepData.WasherGroupId = this.washerGroupOutPutId;
                    this.Model.saveWashStep(washStepData);
                }
            }
        }
        else if (fileName == "TunnelWashStep") {
            var washStepView = this.Views.TunnelWasherStepView;
            if (washStepView) {
                if (washStepView.validateWasherStep()) {
                    var washStepData = washStepView.getWashStepData();
                    if (this.washerGroupOutPutId == undefined)
                        this.washerGroupOutPutId = _this.getQueryStringByName('id');

                    washStepData.WasherGroupId = this.washerGroupOutPutId;
                    this.Model.saveTunnelWashStep(washStepData, this.settings.accountInfo.RegionId);
                }

            }
        }
        else if (fileName == "TunnelWashStepGrid") {
            this.message = "";
            var tunnelWashStepGridView = this.Views.TunnelWashStepGridView;
            if (tunnelWashStepGridView) {
                var tunnelWashStepGridData = tunnelWashStepGridView.getTunnelWashStepGridData();
                if (this.settings.accountInfo.ProductsList != null) {
                    var products = this.settings.accountInfo.ProductsList;
                    for (var i = 0; i < products.length; i++) {
                        var subProducts = [];
                        subProducts = products[i];
                        var index = subProducts[0].CompartmentNumber - 1;
                        tunnelWashStepGridData[index].ProductsList = products[i];
                    }
                }
                this.Model.saveTunnelWashStepGrid(tunnelWashStepGridData, this.settings.accountInfo.RegionId);
            }
        }

    },

    onAddEditFormulaClicked: function () {
        var _this = this;
        var WasherGroupId = this.washerGroupOutPutId;
        if (WasherGroupId == undefined)
            WasherGroupId = _this.getQueryStringByName('id');
        this.Model.GetAddFormula(this.settings.accountInfo.EcolabAccountNumber, WasherGroupId);
    },
    onGetAddFormulaDataRecieved: function (data) {
        this.programId = data.WasherGroupFormulaDetails[0].ProgramId;

        if (data.WashOperationDetails == null) data.WashOperationDetails = 0;
        if (data.WasheStepWaterTypes == null) data.WasheStepWaterTypes = 0;
        if (data.WasherGroupFormulaWashStepModel == null) data.WasherGroupFormulaWashStepModel = 0;
        if (data.WasherGroupDetails[0].WasherGroupTypeId == 2)
            data.Maxload = this.settings.accountInfo.Maxload;
        this.settings.accountInfo.FileName = "Formula";
        this.Views.AddEditFormulaView.setData(data);
        this.Views.AddEditFormulaView.WashStepButtonDisabled();
    },
    onGetEditFormulaDataRecieved: function (data) {

        //this.programId = data.WasherGroupFormulaDetails[0].ProgramId;

        data.message = this.message;
        this.message = "";
        this.settings.accountInfo.FileName = "Formula";
        this.Views.AddEditFormulaView.setData(data);
        this.Views.AddEditFormulaView.WashStepButtonEnabled();
    },
    onWasherGroupUpdateClicked: function (washerGroupData) {
        this.Model.UpdateWasherGroup(washerGroupData);
    },
    onWasherGroupSaveClicked: function (washerGroupData) {
        this.Model.createWasherGroup(washerGroupData);
    },
    onWasherGroupCreated: function (washerGroupId) {
        var _this = this;
        if (washerGroupId == -1) {
            this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
        } else {
            _this.findContainer('Washer Groups', washerGroupId, 0, 'WasherGroupWashers')
            this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPCREATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPCREATEDSUCCESSFULLY', "Washer Group Created successfully.") + '</label>');
            this.washerGroupOutPutId = washerGroupId;
            this.settings.accountInfo.WasherGroupId = washerGroupId;
            this.Views.AddWasherGroup.enableAddWasherButton();
        }
    },
    onWasherGroupUpdated: function (washerGroupId) {
        if (washerGroupId == -1) {
            this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
        } else {
            this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPUPDATEDSUCCESSFULLY', "Washer Group Updated successfully.") + '</label>');
            this.washerGroupOutPutId = washerGroupId;
            this.settings.accountInfo.WasherGroupId = washerGroupId;
        }
    },

    //Events is for deleting the washer group based on the washer group id.
    onDeleteFormulaListClicked: function (Id) {
        this.settings.accountInfo.DeleteStatus = "Formulas";
        this.DeleteConfirmation(Id, '');
    },
    onWashStepDeleteClicked: function (Id) {
        this.settings.accountInfo.DeleteStatus = "WashStep";
        this.DeleteConfirmation(Id, '');
    },

    //Event is for receving the response data after deletion and loading the washer group data.
    onWasherGroupFormulaDeleted: function (WasherGroupData) {
        this.listMessage = '<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETEDSUCCESSFULLY', "Formula deleted successfully.") + '</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.onFormulaTabClick();
    },
    onWasherGroupWashStepDeleted: function (WasherGroupData) {
        this.message = '<label data-localize ="FIELD_WASHSTEPDELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHSTEPDELETEDSUCCESSFULLY', "Wash step deleted successfully.") + '</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.Model.GetEditFormula(this.washerGroupOutPutId, this.FormulaId, this.settings.accountInfo.EcolabAccountNumber);
    },
    //Event is used for handling the error details while deleting the washergroup.
    onWasherGroupDeletionFailed: function (error, description) {
        this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETIONFAILED" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETIONFAILED', "Formula deletion failed.") + '</label>');
    },
    onFormulaSaveClicked: function (FormulaData) {
        var _this = this;
        FormulaData.WasherGroupId = this.washerGroupOutPutId;
        if (FormulaData.WasherGroupId == undefined)
            FormulaData.WasherGroupId = _this.getQueryStringByName('id');
        this.Model.createFormula(FormulaData);
    },
    onFormulaUpdateClicked: function (FormulaData) {
        var _this = this;
        FormulaData.ProgramId = this.programId;
        FormulaData.WasherGroupId = this.washerGroupOutPutId;
        if (FormulaData.WasherGroupId == undefined)
            FormulaData.WasherGroupId = _this.getQueryStringByName('id');
        this.Model.updateFormula(FormulaData);
    },
    onFormulaInlineUpdateClicked: function (FormulaData) {
        var _this = this;
        FormulaData.WasherGroupId = this.washerGroupOutPutId;
        if (FormulaData.WasherGroupId == undefined)
            FormulaData.WasherGroupId = _this.getQueryStringByName('id');
        FormulaData.EcolabAccountNumber = this.settings.accountInfo.EcolabAccountNumber;
        this.Model.updateInlineFormula(FormulaData);
    },
    onFormulaCreated: function (FormulaId, FormulaData) {
        this.FormulaId = FormulaId;
        var id = this.FormulaId;
        var WasherGroupId = this.washerGroupOutPutId;

        if (FormulaData.WasherGroupTypeName == "Conventional") {
            this.Views.AddEditFormulaView.WashStepButtonDisabled();
            // this.onEditFormulaClicked(id);
            if (FormulaId != 51000) {
                //this.message = '<label data-localize ="" class="k-success-message">Formula created successfully<label>';
                this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULACREATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULACREATEDSUCCESSFULLY', "Formula created successfully") + '<label>');
                this.Views.AddEditFormulaView.WashStepButtonEnabled();
            } else {
                //this.message = '<label data-localize ="" class="k-error-message">Formula already exits.<label>';
                this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>');
            }
        } else if (FormulaData.WasherGroupTypeName == "Tunnel")
            this.onTunnelUpdateWashStepClicked(FormulaId);

    },
    onFormulaUpdated: function (data, FormulaData) {
        var id = this.FormulaId;
        var WasherGroupId = this.washerGroupOutPutId;
        if (FormulaData.WasherGroupTypeName == "Conventional") {
            this.message = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully") + '</label>';
            //this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Formula Updated successfully</label>');

            this.Views.AddEditFormulaView.WashStepButtonEnabled();
            this.onEditFormulaClicked(id);
        } else if (FormulaData.WasherGroupTypeName == "Tunnel")
            this.onTunnelUpdateWashStepClicked(id);
    },
    onInlineFormulaUpdated: function (data) {
        var id = this.FormulaId;
        var WasherGroupId = this.washerGroupOutPutId;
        this.listMessage = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully") + '<label>';

        // this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Formula Updated successfully</label>');

        this.onFormulaTabClick();

    },
    onEditFormulaClicked: function (id) {
        var _this = this;
        _this.formulasActiveClass();
        if (this.isDirty == false) {
            this.FormulaId = id;
            var WasherGroupId = this.washerGroupOutPutId;
            if (WasherGroupId == undefined)
                WasherGroupId = _this.getQueryStringByName('id');
            this.Model.GetEditFormula(WasherGroupId, id, this.settings.accountInfo.EcolabAccountNumber);
            _this.findContainer('Formula', id, WasherGroupId, 'Formulas')

        } else {
            this.RedirctTab("washStep");
        }

    },
    onUpdateWashStepClicked: function (id) {
        var _this = this;
        var WasherGroupId = this.washerGroupOutPutId;
        if (WasherGroupId == undefined)
            WasherGroupId = _this.getQueryStringByName('id');
        var FormulaId = this.FormulaId;
        this.Model.GetEditWashStep(WasherGroupId, id, FormulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
    },
    onCopyWashStepClicked: function (id) {
        var _this = this;
        var WasherGroupId = this.washerGroupOutPutId;
        if (WasherGroupId == undefined)
            WasherGroupId = _this.getQueryStringByName('id');
        var FormulaId = this.FormulaId;
        this.Model.GetCopyWashStep(WasherGroupId, id, FormulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
    },

    /******************************************/
    //// Add Washerstep initilize
    initAddWasherStepView: function () {
        var _this = this;
        if (!this.Views.AddWasherStepView) {
            this.Views.AddWasherStepView = new Ecolab.Views.AddWashStep({
                containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onFormulaTabClick: function () { _this.RedirctTab("Back"); },
                    saveWashStep: function () { _this.savePage("WasherWashStep"); },
                    GetWashStepDetails: function (id) { _this.onUpdateWashStepClicked(id); },
                    onChemicalNameChange: function (request, callBack) { _this.loadChemicals(request, callBack); },
                    onFormulaBackButtonClick: function () { _this.onFormulaBackButtonClick(); },
                    madeChangeFalse: function () { _this.madeChangeFalse(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onBackToWashStepsClick: function (Id) { _this.onEditFormulaClicked(Id); }

                }
            });
        }
        //this.loadAddEditWasherGroupModelData(id);
    },
    madeChangeFalse: function () {
        this.isDirty = false;
    },

    //gets the model data for basic wash step details.
    onWashStepClicked: function () {
        this.Model.loadWashStepModelData(this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.EcolabAccountNumber, this.FormulaId, this.settings.accountInfo.RegionId);
    },
    // for setting the wash step basic data
    onWashStepDataLoad: function (washStepData) {
        if (washStepData.WasherGroupFormulaDetails == null) {
            washStepData.WasherGroupFormulaDetails = 1;
        }
        washStepData.FormulaId = this.FormulaId;
        if (washStepData.WasherGroupDetails[0].WasherGroupTypeId == 1) {
            this.settings.accountInfo.FileName = "WasherWashStep";
            this.Views.AddWasherStepView.setData(washStepData);
        } else if (washStepData.WasherGroupDetails[0].WasherGroupTypeId == 2)
            this.Views.TunnelWasherStepView.setData(washStepData);
    },

    onCopyWashStepDataLoad: function (washStepData) {
        if (washStepData.WasherGroupFormulaDetails == null) {
            washStepData.WasherGroupFormulaDetails = 1;
        }
        washStepData.IsCopy = true;
        washStepData.WasherGroupFormulaWashStepModel[0].Id = 0;
        washStepData.WasherGroupFormulaWashStepModel[0].StepNumber = washStepData.WasherGroupFormulaDetails[0].NextAvailableStepNo;
        this.settings.accountInfo.FileName = "WasherWashStep";
        this.Views.AddWasherStepView.setData(washStepData);
    },
    //Event for save wash step details

    onWashStepCreationSuccess: function (response) {

        this.Views.AddWasherStepView.onWashStepCreationSuccess(response);
    },
    onWashStepCreationFailed: function (errorData) {
        this.Views.AddWasherStepView.onWashStepCreationFailed(errorData);
    },

    loadChemicals: function (request, callBack) {

        this.Model.loadChemicals(request, callBack);
    },


    /******************************************/
    //// Tunnel Washerstep initilize
    initTunnelWasherStepView: function () {
        var _this = this;
        if (!this.Views.TunnelWasherStepView) {
            this.Views.TunnelWasherStepView = new Ecolab.Views.TunnelWashStep({
                containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    saveTunnelWashStep: function () { _this.savePage(); },
                    GetCompartmentDetails: function (formulaId, compId, washergroupid) { _this.GetCompartmentDetails(formulaId, compId, washergroupid); },
                    onFormulaTabClick: function () { _this.RedirctTab("Back"); },
                    onGridViewClicked: function (fId, groupId) { _this.onTunnelGridViewClick(fId, groupId); },
                    madeChangeFalse: function () { _this.madeChangeFalse(); },
                    swapView: function () { _this.RedirctTab("Swap"); },
                    onRedirection: function (url) { return _this.RedirctTab("cancel"); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    clearMessage: function () { _this.clearMessage(); }
                }
            });
        }
        //this.loadAddEditWasherGroupModelData(id);
    },
    //gets the model data for basic tunnel wash step details.
    onTunnelUpdateWashStepClicked: function (id) {
        var _this = this;
        if (this.washerGroupOutPutId == undefined)
            this.washerGroupOutPutId = _this.getQueryStringByName('id');
        this.Model.loadTunneWashStep(id, this.settings.accountInfo.EcolabAccountNumber, 0, this.washerGroupOutPutId, this.settings.accountInfo.RegionId);
    },
    // for setting the tunnel wash step basic data
    onTunnelWashStepSetData: function (tunnelWashStepData) {
        this.settings.accountInfo.FileName = "TunnelWashStep";
        tunnelWashStepData.message = this.message;
        this.Views.TunnelWasherStepView.setData(tunnelWashStepData);
    },
    //Event for save wash step details

    onFormulaBackButtonClick: function () {
        this.onFormulaTabClick();
    },
    GetCompartmentDetails: function (formulaId, compId, washergroupid) {
        this.settings.accountInfo.compId = compId;
        this.Model.loadTunneWashStep(formulaId, this.settings.accountInfo.EcolabAccountNumber, compId, washergroupid, this.settings.accountInfo.RegionId);
    },
    onTunnelWashStepCreationSuccess: function (response) {
        this.message = '<label data-localize =FIELD_WASHSTEPSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel WashStep Saved Successfully.</label>';
        this.Views.TunnelWasherStepView.GetCompartmentDetails();
    },
    onTunnelWashStepCreationFailed: function (errorData) {
        this.Views.TunnelWasherStepView.onWashStepCreationFailed(errorData);
    },

    // initialize the Tunnel grid view Mode
    initTunnelWasherStepGridView: function () {
        var _this = this;
        if (!this.Views.TunnelWashStepGridView) {
            this.Views.TunnelWashStepGridView = new Ecolab.Views.TunnelWashStepGridView({
                containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRedirection: function (url) { return _this.RedirctTab(url); },
                    onFormViewClicked: function (id) { _this.onFormViewClicked(id); },
                    onFormulaTabClick: function (url) { return _this.RedirctTab(url); },
                    onCancelclicked: function (url) { return _this.cancelTunnelGridView(url); },
                    saveTunnelWashStepGrid: function () { _this.savePage(); },
                    getProductsList: function (productsList, dosingId) { _this.getProductsList(productsList, dosingId); },
                    onValueChange: function () { _this.madeChange(); },
                    madeChangeFalse: function () { _this.madeChangeFalse(); },
                    swapView: function () { _this.RedirctTab("Grid"); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    clearMessage: function () { _this.clearMessage(); }
                }
            });
        }
    },

    // initialize the Tunnel grid view products list
    initTunnelGridProductListView: function () {
        var _this = this;
        if (!this.Views.ProductsListView) {
            this.Views.ProductsListView = new Ecolab.Views.ProductsList({
                containerSelector: '#tabFormulaAddEditContainer', // Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    updateProducts: function (productsList) { _this.updateProducts(productsList); },
                    onValueChange: function () { _this.madeChange(); },
                }
            });
        }

    },
    cancelTunnelGridView: function (url) {
        if (this.settings.accountInfo.ProductsList && this.settings.accountInfo.ProductsList[0].isDirty)
            this.madeChange();
        else
            this.madeChange();
        return this.RedirctTab(url);
    },


    updateProducts: function (productsList) {
        var prodarr = [];
        if (this.settings.accountInfo.ProductsList == undefined) {
            this.settings.accountInfo.ProductsList = prodarr;
            this.settings.accountInfo.ProductsList[0] = productsList;
        }
        else {
            var leng = this.settings.accountInfo.ProductsList.length;
            this.settings.accountInfo.ProductsList[leng] = productsList;
        }

    },

    //gets the model data for grid tunnel wash step details.
    onTunnelGridViewClick: function (fId, groupId) {
        //this.onTunnelGridViewSetData(id);
        this.Model.loadTunnelGridViewDetails(fId, this.settings.accountInfo.EcolabAccountNumber, 0, groupId, this.settings.accountInfo.RegionId);
    },
    // for setting the tunnel wash step basic data
    onTunnelGridViewSetData: function (tunnelGridViewData) {
        var arr = [];
        var data = [];
        for (var i = 0; i < 10; i++) {
            arr.push(i + 1);
        }
        tunnelGridViewData.arr = arr;
        this.settings.accountInfo.FileName = "TunnelWashStepGrid";
        tunnelGridViewData.message = this.message;
        this.Views.TunnelWashStepGridView.setData(tunnelGridViewData);
    },
    onFormViewClicked: function (id) {
        this.onTunnelUpdateWashStepClicked(id)
    },
    RedirctTab: function (url) {
        var _this = this;
        var washerGroupId = _this.settings.accountInfo.WasherGroupId;
        if (this.isDirty) {
            var Cdialog = $('#ConfirmDialog');
            Cdialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
                BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'Do you want to save changes?'),
                Buttons: {
                    Yes: {
                        Callback: function () {
                            //_this.isDirty = false;
                            Cdialog.addClass('hide');
                            _this.savePage();
                        },
                        CallbackParameters: null
                    },
                    No: {
                        Callback: function () {
                            Cdialog.addClass('hide');
                            switch (url) {
                                case "Back":
                                    _this.onFormulaTabClick();
                                    break;
                                case "Swap":
                                    _this.Views.TunnelWasherStepView.onGridViewClicked();
                                    break;
                                case "Grid":
                                    _this.Views.TunnelWashStepGridView.onFormViewClicked();
                                    break;
                                case "WasherGroup":
                                    _this.isDirty = false;
                                    _this.loadAddEditWasherGroupModelData(washerGroupId);
                                    break;
                                case "Formula":
                                    _this.isDirty = false;
                                    _this.loadAddEditWasherGroupModelData(washerGroupId);
                                    break;
                                case "Cancel":
                                    _this.isDirty = false;
                                    break;
                                default:
                                    _this.onEditFormulaClicked(_this.FormulaId);
                                    break;
                            }
                            _this.isDirty = false;
                        },
                        CallbackParameters: null
                    }
                }

            };
            this.Views.confirmDialog.setData(dialogOptions);
        }
        else {
            if (url == "Back" && _this.isDirty == false) {
                _this.onFormulaTabClick();
            }
            else if (url == "Swap" && _this.isDirty == false) {
                _this.Views.TunnelWasherStepView.onGridViewClicked();
            }
            else if (url == "Grid" && _this.isDirty == false) {
                _this.Views.TunnelWashStepGridView.onFormViewClicked();
            }
            else if (url == "WasherGroup" && _this.isDirty == false) {
                _this.loadAddEditWasherGroupModelData(washerGroupId);
            }
            //else if(url=="WasherWashStep" && _this.isDirty==false){
            //    _this.
            //}
        }
        return false;
    },

    madeChange: function () {
        var _this = this;
        _this.isDirty = true;
        this.message = "";
    },

    onTunnelGridSuccess: function (response) {
        this.message = '<label data-localize ="FIELD_TUNNELWASHSTEPSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel WashSteps Saved Successfully.</label>';
        this.Views.TunnelWasherStepView.onGridViewClicked();

        //this.Views.TunnelWashStepGridView.onWashStepCreationSuccess(response);
    },
    onTunnelGridFailed: function (response) {
        this.Views.TunnelWashStepGridView.onWashStepCreationFailed(response);
    },
    getProductsList: function (productsList, dosingId) {
        this.Views.ProductsListView.setData(productsList, dosingId);
    },

    onAddNewWasher: function () {
        debugger;
        if (this.settings.accountInfo.WasherGroupTypeId == 1) {
            this.RedirectLocation('/ConventionalGeneral' + '?WasherGroupId=' + this.settings.accountInfo.WasherGroupId);
        }
        else {
            this.RedirectLocation('/TunnelGeneral' + '?WasherGroupId=' + this.settings.accountInfo.WasherGroupId + '&WasherGroupTypeId=' + this.settings.accountInfo.WasherGroupTypeId);
        }
    },
    onWasherDeleteClicked: function (isTunnel, id) {
        this.settings.accountInfo.DeleteStatus = "Washers";
        this.DeleteConfirmation(id, isTunnel);
    },
    onWasherDeleted: function (WasherGroupData) {
        this.washerMessage = '<label data-localize ="FIELD_WASHERDELETEDSUCCESSFULLY" class="k-success-message">Washer deleted successfully.</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.loadAddEditWasherGroupModelData(this.washerGroupId);
    },
    onWasherDeletionFailed: function (error, description) {
        this.washerMessage = '<label data-localize ="FIELD_WASHERDELETIONFAILED" class="k-error-message">Washer deletion failed.</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.loadAddEditWasherGroupModelData(this.washerGroupId);
    },
    DeleteConfirmation: function (Id, flag) {
        var _this = this;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISRECORD', 'Are you sure you want to delete this Record?'),
            Buttons: {
                Ok: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.DeleteRecord(Id, flag);
                    },
                    CallbackParameters: null
                },
                Cancel: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return false;
    },
    DeleteRecord: function (Id, flag) {
        var _this = this;
        var pageName = _this.settings.accountInfo.DeleteStatus;
        var accountNumber = _this.settings.accountInfo.EcolabAccountNumber;
        var washerGroupId = _this.settings.accountInfo.WasherGroupId;
        switch (pageName) {
            case "Washers":
                _this.Model.onDeleteWasher(flag, Id, accountNumber);
                break;
            case "Formulas":
                var FormulaData = { WasherGroupId: washerGroupId, Id: Id, EcolabAccountNumber: accountNumber }
                _this.Model.onDeleteFormulaListClicked(FormulaData);
                break;
            case "WashStep":
                var WashStepData = { WasherGroupId: washerGroupId, Id: Id, EcolabAccountNumber: accountNumber }
                _this.Model.WashStepDelete(WashStepData);
                break;
        }
        this.settings.accountInfo.DeleteStatus = '';
    },
    clearMessage: function () {
        var _this = this;
        _this.message = '';
    },

    washerActiveClass: function () {
        var _this = this;
        $('#tabAddWasherGroup').parent().addClass('active');
        $('#tabFormula').parent().removeClass('active');
        $('#tabAddWasherGroupContainer').addClass('in active');
        $('#tabFormulaContainer').removeClass('in active');
        var id = _this.getQueryStringByName('id');
        _this.findContainer('Formula', id, 0, 'Washers')

    },
    formulasActiveClass: function () {
        var _this = this;
        $('#tabAddWasherGroup').parent().removeClass('active');
        $('#tabFormula').parent().addClass('active');
        $('#tabAddWasherGroupContainer').removeClass('in active');
        $('#tabFormulaContainer').addClass('in active');
        var id = _this.getQueryStringByName('id');
        _this.findContainer('Formula', id, 0, 'Formulas')
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    openCurrentNav: function (typeName, id, parentId, subTypeName) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
        if (element.length == 0) {
            element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
            element.addClass('open');
            element.children('ul').slideDown();

            if (subTypeName == "WasherGroupWashers") {

                element = container.find('.cssmenu li a[typename="Formulas"][id=' + id + '][parentid=' + parentId + ']').parent('li');
                element.removeClass('open');
                element.children('ul').slideUp();

                element = container.find('.cssmenu li a[typename="' + subTypeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
                element.addClass('open');
            }
            else if (subTypeName == "Formulas") {
                element = container.find('.cssmenu li a[typename="WasherGroupWashers"][id=' + id + '][parentid=' + parentId + ']').parent('li');
                element.removeClass('open');
                element.children('ul').slideUp();

                element = container.find('.cssmenu li a[typename="' + subTypeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
                element.addClass('open');
            }
            element.children('ul').slideDown();
        }
        else
            element.addClass('active');


        if (typeName == 'Formula') {
            var parentElement = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li').parent('ul').parent('li');
            parentElement.parent('ul').parent('li').addClass('open');
            parentElement.parent('ul').slideDown();
        }
    },
    findContainer: function (typeName, id, parentId, subTypeName) {
        var _this = this;
        _this.loadNavigationMenuListView();
        retryCount = (typeof retryCoutorgaetanksnt == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return;//give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id, parentId, subTypeName); }, 200);
        return;

    }
}
