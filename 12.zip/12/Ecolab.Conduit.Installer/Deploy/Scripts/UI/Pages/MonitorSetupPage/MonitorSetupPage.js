﻿Ecolab.Presenters.MonitorSetupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.MonitorSetupPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initMonitorSetupView();
        this.initMonitorSetupAddEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onMonitorSetupFetched: function (data) { _this.onMonitorSetupFetched(data); },
            onMonitorSetupLoaded: function (data) { _this.onMonitorSetupLoaded(data); },
            onMonitorSetupDeleted: function (data) { _this.onMonitorSetupDeleted(data) },
            onMonitorSetupDeletionFailed: function (error, description) { _this.onMonitorSetupDeletionFailed(error, description); },
            onMonitorSetupUpdated: function (data, isInLine) { _this.onMonitorSetupUpdated(data, isInLine) },
            onMonitorSetupUpdationFailed: function (error, description) { _this.onMonitorSetupUpdationFailed(error, description); },
            onMachinesLoaded: function (data) { _this.onMachinesLoaded(data) },
            onEditDetailsFetched: function (data) { _this.onEditDetailsFetched(data) },
            onMonitorsLoaded: function (data) { _this.onMonitorsLoaded(data) },
        };
    },

    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },

    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.loadMonitorSetup(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },

    initMonitorSetupView: function () {
        var _this = this;
        if (!this.Views.MonitorSetupView) {
            this.Views.MonitorSetupView = new Ecolab.Views.MonitorSetup({
                containerSelector: '#divMonitorSetupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onCancelClicked: function () { _this.onCancelClicked(); },
                    onAddMonitorClicked: function () { _this.onAddMonitorClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onEditClicked: function (id) { _this.onEditClicked(id); },
                    onDeleteClicked: function (id) { _this.onDeleteClicked(id); },
                    onUpdateMonitorInlineClicked: function (data) { _this.onSaveClicked(data,true); }
                }
            });
        }
    },

    initMonitorSetupAddEditView: function () {
        var _this = this;
        if (!this.Views.MonitorSetupAddEditView) {
            this.Views.MonitorSetupAddEditView = new Ecolab.Views.MonitorSetupAddEdit({
                containerSelector: '#addEditMonitorSetupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onAddEditMonitorViewRendered(); },
                    onDashboardTypeChange: function (id) { _this.onDashboardTypeChange(id); },
                    onSaveClicked: function (data) { _this.onSaveClicked(data, false); },
                    onMonitorsChange:function() {_this.onMonitorsChange();}
                }
            });
        }
    },

    onMonitorsChange:function () {
        this.Model.FetchMonitors();
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },

    onAddEditMonitorViewRendered: function () {
        $('#monitorModal').modal({ backdrop: 'static' })
    },

    loadMonitorSetup: function () {
        this.Model.FetchMonitorSetUpDetails();
    },

    //for displaying in grid
    onMonitorSetupFetched: function (data) {
        var data1 = {};
        data1.accountInfo = null;
        data1.DashboardData = data;
        this.Views.MonitorSetupView.setData(data1);
    },

    //for displaying in add new 
    onMonitorSetupLoaded:function(data){
        this.Views.MonitorSetupAddEditView.setData(data);
    },

    fetchWasherGroup: function (data) {
        this.Model.fetchWasherGroup(data);
    },

    onWasherGroupLoaded: function (data) {
        this.Views.MonitorSetupView.LoadWasherGroups(data);
    },

    onDeleteClicked: function (id) {
        var _this = this
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Yes: {
                    Callback: function () {
                        _this.Model.deleteMonitorSetup(id)
                        $('#ConfirmDialog').hide();
                    }
                },

                No: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
              , blockSelector: 'body'
        });

    },

    onMonitorSetupDeleted: function (data) {
        this.Model.FetchMonitorSetUpDetails();
        this.Views.MonitorSetupView.showMessage(data);
    },

    onMonitorSetupDeletionFailed: function (data) {
        this.Views.MonitorSetupView.showMessage(-1);
    },

    onSaveClicked: function (manualProductionViewModel,isInLine) {
        this.Model.updateMonitorSetup(manualProductionViewModel,isInLine)
    },

    onMonitorSetupUpdated: function (data, isInLine) {
        if (data != '701') {
            this.Model.FetchMonitorSetUpDetails();
            if (!isInLine)
                $('#monitorModal').modal('toggle');
            this.Views.MonitorSetupView.showMessage(data);
        }
        else if(!isInLine)
        {
            this.Views.MonitorSetupAddEditView.showMessage(data);
        }
        else
        {
            this.Views.MonitorSetupView.showMessage(data);
        }
    },

    onMonitorSetupUpdationFailed: function (data, description) {
        this.Views.MonitorSetupView.showMessage("301");
    },

    onDashboardTypeChange: function (id) {
        this.Model.FetchDataonDashboardTypeChange(id)
    },

    onAddMonitorClicked: function () {
        this.Model.onAddMonitorClicked()
    },

    onMachinesLoaded: function (data) {
        this.Views.MonitorSetupAddEditView.loadMachines(data);
    },

    onEditClicked: function (id) {
        this.Model.onEditClicked(id);
    },

    onEditDetailsFetched: function (data) {
        this.Views.MonitorSetupAddEditView.setData(data);
    },
    onMonitorsLoaded :function (data) {
        this.Views.MonitorSetupAddEditView.setMonitors(data);
}
};