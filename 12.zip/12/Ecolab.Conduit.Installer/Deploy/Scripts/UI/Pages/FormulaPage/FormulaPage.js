Ecolab.Presenters.FormulaPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.FormulaPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onFormulaDataLoaded: function (data) { _this.onFormulaDataLoaded(data); },
            onloadFormulaOnAddNewPopupDataLoaded: function (data) { _this.loadFormularOnAddNewPopupDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.Model.loadFormulaData();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {

        var _this = this;
        if (!this.Views.PlantSetupView) {
            this.Views.PlantSetupView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onSaveClicked: function (data) { _this.savePlantutilityData(data); }
                            }
                        });
        }
        // region = this.settings.accountInfo.RegionId;
        this.Views.PlantSetupView.setData(this.settings.accountInfo);

    },
    initListView: function () {
        var _this = this;
        if (!this.Views.FormulaView) {
            this.Views.FormulaView = new Ecolab.Views.Formula(
                        {
                            containerSelector: '#tabFormulaContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                                rendered: function () { _this.loadFormulaOnAddNewPopupLoad(); }
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadFormulaDataData: function () {
        this.Model.loadFormulaData();
    },
    onFormulaDataLoaded: function (data) {
        this.Views.FormulaView.setData(this.settings.accountInfo);
    },
    loadFormulaOnAddNewPopupLoad: function(){
        this.Model.loadFormulaOnAddNewPopupLoad();
    },

    loadFormularOnAddNewPopupDataLoaded: function (data) {
        this.Views.FormulaView.setFormulaOnAddNewPopupLoadData(data);
    }
};