Ecolab.Presenters.TunnelCompartmentPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.DropdownData = null;
};

//creating the proto type for Compartment presenter
Ecolab.Presenters.TunnelCompartmentPage.prototype = {
    //initiate the base views for compartments for tunnel.
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initTunnelCompartmentsView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    // initiate the base model for compartments for tunnel.
    initmodel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    // adding the additional model options for the compatments for tunnel.
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    // adding the get model events from model
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    //getting the callback and error call back methods from the model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onSaved: function (data) { _this.onSaved(data); },
            onDropDownDataLoaded: function (data) { _this.onDropDownDataLoaded(data); },
            onSaveFailed: function (description, data) { _this.onSaveFailed(description, data); },
            onComaprtmentsLoad: function (data) { _this.onComaprtmentsLoad(data); },
        }
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () { _this.loadDropDownsData(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },
                }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initTunnelCompartmentsView: function () {
        var _this = this;
        if (!this.Views.TunnelCompartmentView) {
            this.Views.TunnelCompartmentView = new Ecolab.Views.TunnelCompartment({
                containerSelector: '#tabCompartmentsContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    savePage: function () { _this.savePage(); },
                    deleteConformation: function (ddl) { return _this.deleteConformation(ddl); },
                    onCompartmentChange: function (Id) { _this.onCompartmentChange(Id); },
                    CompartmentPrint: function (data) { _this.CompartmentPrint(data); },
                    updateFlag: function () {
                        _this.updateFlag();
                    }
                }
            });
        }
    },
    CompartmentPrint: function (data) {
        this.RedirectLocation(data);
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERGROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },

    ontabFormulaClicked: function () {
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId);
    },
    updateFlag: function () {
        this.isDirty = false;
    },
    loadCompartmentsModelData: function () {
        this.Model.loadCompartmentsModelData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.ControllerId, this.settings.accountInfo.TunnelId, 1)
    },
    //sets the data passing to view for binding.
    onComaprtmentsLoad: function (data) {

        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.Id = this.settings.accountInfo.TunnelId;
        drData.TotalCompartments = this.settings.accountInfo.Compartments;
        drData.ControllerId = this.settings.accountInfo.ControllerId;
        drData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;

        if (drData.CompartmentNumber == 0)
            drData.CompartmentNumber = 1
        if (data.PumpAssociationList.length > 0)
            drData.IsDosagePoint = true;
        else
            drData.IsDosagePoint = false;

        var compartments = [];
        for (var i = 1; i <= this.settings.accountInfo.Compartments; i++) {
            compartments.push({
                Id: i
            })
        }
        drData.Compartments = compartments;
        this.Views.TunnelCompartmentView.setData(drData);
    },
    loadDropDownsData: function () {
        this.Model.loadDropDownsData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId, this.settings.accountInfo.TunnelId, this.settings.accountInfo.WasherGroupId);
    },
    onDropDownDataLoaded: function (data) {
        this.DropdownData = data;
        this.loadCompartmentsModelData();
    },
    savePage: function () {
        var _this = this;
        var view = this.Views.TunnelCompartmentView;
        if (view) {
            if (view.validate()) {
                var tunnelData = this.Views.TunnelCompartmentView.getData();
                _this.Model.save(tunnelData);
            }
        }
    },
    onSaved: function (data) {
        var _this = this;
        this.isDirty = false;
        this.Views.TunnelCompartmentView.onSaved('<label data-localize ="FIELD_TUNNELDETAILSUPDATEDSUCCESSFULLY" class="k-success-message">Tunnel Details Updated successfully.</label>')
        if (data.PumpAssociationList > 0) {
            this.Views.TunnelCompartmentView.updateDosagePoint(true);
        }
        else {
            $.each(data.PumpAssociationList, function (key, value) {
                if (value.IsDeleted == 0) {
                    _this.Views.TunnelCompartmentView.updateDosagePoint(true);
                    return false;
                }
                else {
                    _this.Views.TunnelCompartmentView.updateDosagePoint(false);
                }
            });
        }
        // this.RedirectLocation('/Washer?massage=TunnelUpdated')
    },
    onSaveFailed: function (description, data) {
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.Id = this.settings.accountInfo.TunnelId;
        drData.TotalCompartments = this.settings.accountInfo.Compartments;
        drData.ControllerId = this.settings.accountInfo.ControllerId;
        drData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        if (drData.CompartmentNumber == 0)
            drData.CompartmentNumber = 1
        if (data.PumpAssociationList.length > 0)
            drData.IsDosagePoint = true;
        else
            drData.IsDosagePoint = false;

        var compartments = [];
        for (var i = 1; i <= this.settings.accountInfo.Compartments; i++) {
            compartments.push({
                Id: i
            })
        }
        drData.Compartments = compartments;
        drData.Mode = "Edit";
        if (description == '51001') {
            this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid WasherGroup provided</label>';
        }
        else if (description == '51002') {
            this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number or Name already exists.</label>';
        }
        else if (description == '51003') {
            this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message"> An invalid Controller was provided.</label>';
        }
        else if (description == '51004') {
            this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message"> An associated formula cannot be specified as End-Of-Formula.</label>';
        }
        else if (description == '51005') {
            this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">  An invalid WasherMode was provided.</label>';
        }
        drData.massage = this.message;
        this.Views.TunnelCompartmentView.setData(drData);
    },
    onCompartmentChange: function (Id) {
        this.Model.loadCompartmentsModelData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.ControllerId, this.settings.accountInfo.TunnelId, Id)

    },
    deleteConformation: function (ddl) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are Sure you want to delete Chemical?'),
            Buttons: {
                Ok: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Views.TunnelCompartmentView.onConform(ddl);
                    },
                    CallbackParameters: null
                },
                Cancel: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },
}