// JavaScript source code
Ecolab.Presenters.TunnelGeneralPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.DropdownData = null;
    this.Mode = null;
};
Ecolab.Presenters.TunnelGeneralPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initTunnelGeneralTabsView();
        this.initTunnelGeneralView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDropDownDataLoaded: function (data) { _this.onDropDownDataLoaded(data); },
            onSaved: function (id, data) { _this.onSaved(id, data); },
            onSizeListLoaded: function (data) { _this.onSizeListLoaded(data); },
            onSaveFailed: function (description, data) { _this.onSaveFailed(description, data); },
            onTunnelDataLoaded: function (data) { _this.onTunnelDataLoaded(data); },
            onUpdate: function (data) { _this.onUpdate(data); },
            onUpdateFailed: function (description, data) { _this.onSaveFailed(description, data); },
            onWasherModeListLoaded: function (data) { _this.onWasherModeListLoaded(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },

    initTunnelGeneralTabsView: function () {
        var _this = this;

        if (!this.Views.TunnelTabView) {
            this.Views.TunnelTabView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered();
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function () { _this.onSetupTabClicked(); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },
                }
            });
        }
        this.Views.TunnelTabView.setData(this.settings.accountInfo);
    },

    initTunnelGeneralView: function () {
        var _this = this;
        if (!this.Views.TunnelGeneralView) {
            this.Views.TunnelGeneralView = new Ecolab.Views.TunnelGeneral({
                containerSelector: '#tabGeneralContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    savePage: function () { _this.savePage(); },
                    DeleteConformation: function () { return _this.DeleteConformation(); },
                    getSize: function (model) { _this.getSize(model); },
                    getWasherMode: function (controllerId) { _this.getWasherMode(controllerId); },
                    updateMode: function () { _this.updateMode(); },
                    updateFlag: function () {
                        _this.updateFlag();
                    }

                }
            });
        }
    },

    onTabsRendered: function () {

        this.loadDropDownsData();


    },
    updateFlag: function () {
        this.isDirty = false;
    },
    ontabFormulaClicked: function () {
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId);
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERGROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    loadDropDownsData: function () {
        this.Model.loadDropDownsData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId, this.settings.accountInfo.WasherGroupId);
    },
    savePage: function () {
        var _this = this;
        var view = this.Views.TunnelGeneralView;
        if (view) {
            if (view.validate()) {
                if (this.HasDuplicateTags()) {
                    view.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                    return false;
                } else {
                    var tunnelData = this.Views.TunnelGeneralView.getTunnelData();
                    if ((tunnelData.Id != "")) {
                        _this.Model.update(tunnelData);
                    } else {
                        _this.Model.save(tunnelData);
                    }
                }
            }
        }
    },
    loadTunnelView: function () {
        var _this = this;

        var id = this.settings.accountInfo.TunnelId;
        var washerGroupId = this.settings.accountInfo.WasherGroupId;
        if (id != null && washerGroupId != null) {

            _this.Model.getTunnelData(id, washerGroupId, this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId);
        } else {
            drData = [];
            drData.DropdownData = this.DropdownData;
            drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
            drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
            drData.RegionId = this.settings.accountInfo.RegionId;
            drData.PressExtractor = 1;
            drData.NoofTanks = 0;
            drData.NoofCompartments = 0;
            drData.MaxLoad = 0;
            drData.TransferType = 2;
            drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
            this.Views.TunnelGeneralView.setData(drData);
        }


    },
    onDropDownDataLoaded: function (data) {
        this.DropdownData = data;
        this.loadTunnelView();
    },
    onSaved: function (id, data) {
        this.isDirty = false;
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.Id = id;
        if (id) { this.settings.accountInfo.ReturnTunnelId = id; }
        this.Mode = data.WasherMode;
        drData.Mode = "Edit";
        this.message = '<label data-localize ="FIELD_TUNNELDETAILSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel Details Saved successfully.</label>';
        drData.massage = this.message;
        this.loadNavigationMenuListView();
        this.Views.TunnelGeneralView.enableTabs();
        this.Views.TunnelGeneralView.showMessage(this.message);
        // this.loadDropDownsData();
        this.Views.TunnelGeneralView.setData(drData);


        //this.RedirectLocation('/Washer?massage=TunnelSaved')
    },
    onSaveFailed: function (description, data) {
        //drData = data;
        //drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        this.Mode = data.WasherMode;
        drData.Mode = "Error";
        if (jQuery.type(description) != "object") {
            if (description == '51001') {
                this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid WasherGroup provided</label>';
            } else if (description == '51002') {
                this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number or Name already exists.</label>';
            } else if (description == '51003') {
                this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message"> An invalid Controller was provided.</label>';
            } else if (description == '51004') {
                this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message"> An associated formula cannot be specified as End-Of-Formula.</label>';
            } else if (description == '51005') {
                this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">  An invalid WasherMode was provided.</label>';
            } else if (description == '51008') {
                this.message = '<label data-localize ="FIELD_WASHERGROUPCANHAVEONLYONETUNNEL" class="k-error-message">  Washer Group can have only one Tunnel</label>';
            } else if (description) {
                this.message = ' <label class="k-error-message">' + description + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid') + '</label>';
            } else {
                this.message = '<label data-localize ="FIELD_TUNNELSAVEFAILED" class="k-error-message">  Tunnel save Failed </label>';
            }
        } else {
            if (description.status == 300) {
                this.message = ' <label class="k-error-message">' + description.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'tags already exists in the Machine') + '</label>';
            } else {
                this.message = '<label data-localize ="FIELD_TUNNELSAVEFAILED" class="k-error-message">  Tunnel save failed.</label>';
            }
        }
        this.Views.TunnelGeneralView.showMessage(this.message);
    },

    getSize: function (model) {
        var _this = this;
        _this.Model.getSizeList(model);
    },
    onSizeListLoaded: function (data) {
        this.Views.TunnelGeneralView.LoadSizeDropDown(data);
    },
    getWasherMode: function (controllerId) {
        var _this = this;
        _this.Model.getWasherModeList(controllerId, this.settings.accountInfo.EcoLabAccountNumber);
    },
    onWasherModeListLoaded: function (data) {
        this.Views.TunnelGeneralView.LoadWasherModeDropDown(data, this.Mode);
    },
    onTunnelDataLoaded: function (data) {
        var _this = this;
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.Mode = "Edit";
        this.Mode = data.WasherMode;
        var type = _this.getQueryStringByName('type');
        if (type == "WasherGroup")
            _this.findContainer('Washer', drData.Id);
        else
            _this.findContainer('Washers', drData.Id);
        this.Views.TunnelGeneralView.setData(drData);
    },
    updateMode: function () {
        this.Views.TunnelGeneralView.updateModeId(this.Mode);
    },
    onUpdateFailed: function (description, data) {
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        this.Mode = data.WasherMode;
        drData.Mode = "Error";
        if (jQuery.type(description) != "object") {
            if (description == '51001') {
                this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid WasherGroup provided</label>';
            } else if (description == '51002') {
                this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number or Name already exists.</label>';
            } else if (description == '51003') {
                this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message"> An invalid Controller was provided.</label>';
            } else if (description == '51004') {
                this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message"> An associated formula cannot be specified as End-Of-Formula.</label>';
            } else if (description == '51005') {
                this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">  An invalid WasherMode was provided.</label>';
            } else if (description == '51006') {
                this.message = '<label data-localize ="FIELD_ANINVALIDWASHERIDWASPROVIDEDFORUPDATING" class="k-error-message">   An invalid Washer-ID was provided for Updating.</label>';
            } else if (description) {
                this.message = ' <label class="k-error-message">' + description + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid') + '</label>';
            } else {
                this.message = '<label data-localize ="FIELD_TUNNELSAVEFAILED" class="k-error-message">  Tunnel update Failed </label>';
            }
        } else {
            if (description.status == 300) {
                this.message = ' <label class="k-error-message">' + description.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'tags already exists in the Machine') + '</label>';
                this.Views.ConventionalGeneralView.showMessage(this.message);
            } else {
                this.message = '<label data-localize ="FIELD_TUNNELSAVEFAILED" class="k-error-message">  Tunnel update failed.</label>';
                this.Views.ConventionalGeneralView.showMessage(this.message);
            }
        }
        this.Views.TunnelGeneralView.showMessage(this.message);


    },
    onUpdate: function (data) {
        this.isDirty = false;
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        this.Mode = data.WasherMode;
        if (data.Id) { this.settings.accountInfo.ReturnTunnelId = data.Id; }
        drData.Mode = "Edit";
        this.message = '<label data-localize ="FIELD_TUNNELDETAILSUPDATEDSUCCESSFULLY" class="k-success-message">Tunnel Details Updated successfully.</label>';
        this.Views.TunnelGeneralView.showMessage(this.message);
    },
    DeleteConformation: function () {
        var cDialog = $('#ConfirmDialog');
        cDialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
            Buttons: {
                Ok: {
                    Callback: function () {
                        cDialog.addClass('hide');
                        return true;
                    },
                    CallbackParameters: null
                },
                Cancel: {
                    Callback: function () {
                        cDialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    openCurrentNav: function (typeName, id) {
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('active');
        if (typeName == "Washer") {
            element.parent('ul').parent('li').addClass('open');
            element.parent('ul').parent('li').parent('ul').parent('li').addClass('open');
            element.parent('ul').slideDown();
            element.parent('ul').parent('li').parent('ul').slideDown();
        }
    },
    findContainer: function (typeName, id) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return;
        setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
        return;
    }
};