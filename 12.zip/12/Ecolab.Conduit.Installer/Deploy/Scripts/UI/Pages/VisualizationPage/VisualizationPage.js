﻿Ecolab.Presenters.VisualizationPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.VisualizationPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initDashboardView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDashboardDataLoad: function (data) { _this.onDashboardDataLoaded(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        var dashboardId = this.getDashboardId()
        this.loadDashboardData(dashboardId);
    },
    initDashboardView: function () {
        var _this = this;
        if (!this.Views.VisualizationView) {
            this.Views.VisualizationView = new Ecolab.Views.Visualization(
                        {
                            containerSelector: '#visualizationContainer',
                            eventHandlers: {
                                rendered: function () { },
                                reload: function () { _this.loadDashboardData(dashboardId); },
                            }
                        });
        }
    },
    loadDashboardData: function (dashboardId) {
        var _this = this;
        _this.Model.loadDashboardData(dashboardId);
        (function poll() {
            _this.timer = setTimeout(function () {
                _this.Model.loadDashboardData(dashboardId);
                poll();
            }, 3000);
        })();
    },
    getDashboardId: function () {
        var _this = this;
        var dashboardId;
        if (_this.getQueryStringByName('id')) {
            dashboardId = _this.getQueryStringByName('id');
        }

        return dashboardId;
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    onDashboardDataLoaded: function (data) {
        this.Views.VisualizationView.setData(data);
    }
};