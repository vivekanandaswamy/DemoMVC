﻿Ecolab.Presenters.ManualBatchPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ManualBatchPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initManualBatchView();
        this.initManualBatchAddEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onManualBatchLoaded: function (data) { _this.onManualBatchLoaded(data); },
            onManualBatchDeleted: function (data) { _this.onManualBatchDeleted(data) },
            onManualBatchDeletionFailed: function (error, description) { _this.onManualBatchDeletionFailed(error, description); },
            onManualBatchUpdated: function (data) { _this.onManualBatchUpdated(data) },
            onManualBatchUpdationFailed: function (error, description) { _this.onManualBatchUpdationFailed(error, description); },
            onFormulaLoaded: function (data) { _this.onFormulaLoaded(data); },
            onManualBatchFetched: function (data) { _this.onManualBatchFetched(data); },
            onWahserGroupLoaded: function (data) { _this.onWasherGroupLoaded(data) },
            onBatchDetailsFetched: function (data) { _this.onBatchDetailsFetched(data) },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();

    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ManualInputTabsView) {
            this.Views.ManualInputTabsView = new Ecolab.Views.ManualInputTabs(
                        {
                            containerSelector: '#tabContainer',
                            eventHandlers: {
                                rendered: function () {
                                    _this.loadManualBatch();
                                },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.ManualInputTabsView.setData(this.settings.accountInfo);
    },
    initManualBatchView: function () {
        var _this = this;
        if (!this.Views.ManualBatchView) {
            this.Views.ManualBatchView = new Ecolab.Views.ManualBatch({
                containerSelector: '#divManualBatchContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    fetchWasherGroup: function (data) { _this.fetchWasherGroup(data); },
                    onCancelClicked: function () { _this.onCancelClicked(); },
                    onSaveClicked: function (manualProductionViewModel) { _this.onSaveClicked(manualProductionViewModel); },
                    //onDeleteClicked: function () { _this.onDeleteClicked(); },
                    onWasherGroupChange: function (groupId) { _this.onWasherGroupChange(groupId); },
                    onWasherOrFormulaChange: function (objManualBatch) { _this.onWasherOrFormulaChange(objManualBatch) },
                    onBatchChange: function (objManualBatch) { _this.onBatchChange(objManualBatch) },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
    },

    initManualBatchAddEditView: function () {
        var _this = this;
        if (!this.Views.ManualBatchAddEditView) {
            this.Views.ManualBatchAddEditView = new Ecolab.Views.ManualBatchAddEdit({
                containerSelector: '#manualBatchDataContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onDeleteClicked: function () { _this.onDeleteClicked(); },
                }
            });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_MANUALINPUT', 'Manual Input');
        breadCrumbData.url = "/ManualUtility";
        this.showPlantBreadCrumb("manualInput", breadCrumbData);
    },

    loadManualBatch: function () {
        this.Model.loadManualBatch("1");
    },

    onManualBatchLoaded: function (data) {
        if (typeof (data) == 'undefined')
        {
            data = {};
        }
        var allowEdit = false;
        var level = this.settings.accountInfo.MaxLevel
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        data.AllowEdit = allowEdit;
        this.Views.ManualBatchView.setData(data);
    },

    fetchWasherGroup: function (data) {
        this.Model.fetchWasherGroup(data);
    },

    onWasherGroupLoaded:function(data){
        this.Views.ManualBatchView.LoadWasherGroups(data);
    },

    onDeleteClicked: function () {
        var _this = this
        var data = _this.Views.ManualBatchView.getIdsToLoadProductData();
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Yes: {
                    Callback: function () {
                        _this.Model.deleteManualBatch(data)
                        $('#ConfirmDialog').hide();
                    }
                },

                No: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
              , blockSelector: 'body'
        });

    },

    onManualBatchDeleted: function (data) {
        this.Views.ManualBatchView.setData(data);
        this.Views.ManualBatchView.showMessage(data.Result);
    },

    onManualBatchDeletionFailed: function (data) {
        this.Views.ManualBatchView.showMessage("301");
    },

    onSaveClicked: function (manualProductionViewModel) {
        this.Model.updateManualBatch(manualProductionViewModel)
    },

    onManualBatchUpdated: function (data) {
        this.Views.ManualBatchView.showMessage(data);
    },

    onManualBatchUpdationFailed: function (data, description) {
        this.Views.ManualBatchView.showMessage("301");
    },

    onWasherGroupChange: function (groupId) {
        this.Model.FetchDataOnWasherGroupChange(groupId)
    },

    onFormulaLoaded: function (data) {
        this.Views.ManualBatchView.bindFormulaAndWasherData(data);
    },

    onWasherOrFormulaChange: function (objManualBatch) {
        this.Model.FetchManualBatch(objManualBatch)
    },

    onBatchChange: function (objManualBatch) {
        this.Model.FetchBatchDetails(objManualBatch)
    },

    //For batch dropdown
    onManualBatchFetched: function (data) {
        this.Views.ManualBatchView.LoadBatch(data);
    },

    //for batch data
    onBatchDetailsFetched: function (data) {
        if (typeof (data) == 'undefined') {
            data = {};
        }
        var allowEdit = false;
        var level = this.settings.accountInfo.MaxLevel
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        data.AllowEdit = allowEdit;
        this.Views.ManualBatchAddEditView.setData(data);
    },
    savePage: function () {
        var view = this.Views.ManualBatchView;
        if (view) {
            view.clearMessage();
            if (view.validate()) {
                view.onSaveClicked();
                this.isDirty = false;
            }
        }
    },
};