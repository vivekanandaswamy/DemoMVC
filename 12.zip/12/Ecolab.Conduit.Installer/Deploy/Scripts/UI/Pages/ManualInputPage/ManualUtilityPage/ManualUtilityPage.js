﻿Ecolab.Presenters.ManualUtilityPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ManualUtilityPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initManualUtilityView();
        this.initManualUtilityAddEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onManualUtilityLoaded: function (data) { _this.onManualUtilityLoaded(data); },
            onManualUtilityDeleted: function (data) { _this.onManualUtilityDeleted(data) },
            onManualUtilityDeletionFailed: function (error, description) { _this.onManualUtilityDeletionFailed(error, description); },
            onManualUtilityUpdated: function (data, isInline) { _this.onManualUtilityUpdated(data, isInline) },
            onManualUtilityUpdationFailed: function (error, description) { _this.onManualUtilityUpdationFailed(error, description); },
            onFormulaLoaded: function (data) { _this.onFormulaLoaded(data); },
            onManualUtilityFetched: function (data) { _this.onManualUtilityFetched(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();

    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ManualInputTabsView) {
            this.Views.ManualInputTabsView = new Ecolab.Views.ManualInputTabs(
                        {
                            containerSelector: '#tabContainer',
                            eventHandlers: {
                                rendered: function () {
                                    _this.loadManualUtility();
                                    //_this.onManualUtilityLoaded({});
                                },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.ManualInputTabsView.setData(this.settings.accountInfo);
    },
    initManualUtilityView: function () {
        var _this = this;
        if (!this.Views.ManualUtilityView) {
            this.Views.ManualUtilityView = new Ecolab.Views.ManualUtility({
                containerSelector: '#divManualUtilityContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onCancelClicked: function () { _this.onCancelClicked(); },
                    onSaveClicked: function (manualProductionViewModel) { _this.onSaveClicked(manualProductionViewModel, false); },

                    // onWasherGroupChange: function (groupId) { _this.onWasherGroupChange(groupId); },
                    //onWasherOrFormulaChange: function (manualProductionViewModel) { _this.onWasherOrFormulaChange(manualProductionViewModel) },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    //onUpdateClicked: function (data) { return _this.onUpdateClicked(data) },
                    onUpdateInlineClicked: function (data) { return _this.onSaveClicked(data, false) },
                    onEditManualUtilityClicked: function (data) { _this.onEditManualUtilityClicked(data); }

                }
            });
        }
    },

    initManualUtilityAddEditView: function () {
        var _this = this;
        if (!this.Views.ManualUtilityAddEditView) {
            this.Views.ManualUtilityAddEditView = new Ecolab.Views.ManualUtilityAddEdit({
                containerSelector: '#addEditManualUtilityPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onSaveClicked: function (data) { _this.onSaveClicked(data, true); },
                    onDeleteClicked: function (manualProductionViewModel) { _this.onDeleteClicked(manualProductionViewModel); },
                    reloadManualUtility: function () { _this.loadManualUtility(); }
                }
            });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_MANUALINPUT', 'Manual Input');
        breadCrumbData.url = "/ManualUtility";
        this.showPlantBreadCrumb("manualInput", breadCrumbData);
    },

    loadManualUtility: function () {
        this.Model.loadManualUtility();
    },

    onManualUtilityLoaded: function (data) {
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        utilityData.data = data;
        utilityData.AllowEdit = allowEdit;
        this.Views.ManualUtilityView.setData(utilityData);
    },

    onDeleteClicked: function (data) {
        var _this = this
        _this.Model.deleteManualUtility(data);
        //this.Views.confirmDialog.setData({
        //    HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
        //    BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
        //    Buttons: {
        //        Yes: {
        //            Callback: function () {
        //                $('#ConfirmDialog').hide();
        //                _this.Model.deleteManualUtility(data);

        //            }
        //        },

        //        No: {
        //            Callback: function () {
        //                $('#ConfirmDialog').hide();
        //            }
        //        }
        //    }
        //      , blockSelector: 'body'
        //});
    },

    onManualUtilityDeleted: function (data) {
        //data.isDelete = true;
        //$('#myModal').modal('hide');
        this.Views.ManualUtilityAddEditView.setData(data);
        // $('#myModal').modal('show');
        this.Views.ManualUtilityAddEditView.showMessage('301');
    },

    onManualUtilityDeletionFailed: function (data) {
        this.Views.ManualUtilityView.showMessage("501");
    },

    onSaveClicked: function (manualProductionViewModel, isInline) {
        this.Model.updateManualUtility(manualProductionViewModel, isInline)
    },

    onManualUtilityUpdated: function (data, isInline) {
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        utilityData.data = data;
        utilityData.AllowEdit = allowEdit;
        this.Views.ManualUtilityView.setData(utilityData);
        this.Views.ManualUtilityView.showMessage(data[0].Result);
        if (isInline)
            $('#myModal').modal('toggle');
        $('#myModal').modal('hide');
        $("#myModal").removeClass('fade');
        $(".modal-backdrop").remove();

    },

    onManualUtilityUpdationFailed: function (data, description) {
        this.Views.ManualUtilityView.showMessage("301");
    },

    onManualUtilityFetched: function (data) {
        this.Views.ManualUtilityAddEditView.setData(data);
        $('#myModal').modal('show');
    },

    onEditManualUtilityClicked: function (data) {
        this.Views.ManualUtilityAddEditView.setData(data);
        $('#myModal').modal('show');
    },

    savePage: function () {
        var view = this.Views.ManualUtilityView;
        if (view) {
            view.clearMessage();
            if (view.validate()) {
                view.onSaveTrClicked();
                this.isDirty = false;
            }
        }
    },
};