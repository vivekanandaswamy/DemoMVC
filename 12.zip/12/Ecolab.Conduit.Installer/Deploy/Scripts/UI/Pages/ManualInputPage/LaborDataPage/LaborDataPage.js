﻿Ecolab.Presenters.LaborDataPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.massage = "";
};
Ecolab.Presenters.LaborDataPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initManualInputTabsView();
        this.initLaborDataView();
        this.initAddEditLaborDataView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onTypeAndLocationLoaded: function (laborData) { _this.onTypeAndLocationLoaded(laborData); },
            onSaved: function (data) { _this.onSaved(data); },
            onSaveFailed: function (error, description) { _this.onSaveFailed(error, description); },
            onLaborCostLoad: function (data) { _this.onLaborCostLoad(data); },
            onManualLaborFetched: function (data) { _this.onLaborCostLoad(data); }

        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initManualInputTabsView: function () {
        var _this = this;
        if (!this.Views.ManualInputTabs) {
            this.Views.ManualInputTabs = new Ecolab.Views.ManualInputTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {

                        _this.GetLaborTypeAndLocation();
                    },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.ManualInputTabs.setData(this.settings.accountInfo);
    },
    initLaborDataView: function () {
        var _this = this;
        if (!this.Views.LaborDataView) {
            this.Views.LaborDataView = new Ecolab.Views.LaborData({
                containerSelector: '#tabLabourContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    rendered: function () {
                       // _this.onLaborViewRendered();
                    },
                    SavelaborData: function (data) { _this.SavelaborData(data); },
                    GetLaborCost: function (type, location) { _this.GetLaborCost(type, location); },
                    upDateIsDirty: function () { _this.upDateIsDirty(); },
                    savePage: function () { _this.savePage(); }
                }
            });
        }
    },

    onLaborViewRendered: function () {
        this.trackChanges();
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/ManualInput";
        this.showPlantBreadCrumb("manualInput", breadCrumbData);
    },
    GetLaborTypeAndLocation: function () {
        this.Model.getLaborTypeAndLocation();
    },

    onTypeAndLocationLoaded: function (laborData) {
        var data = {};
        data.labordata = laborData.ManualLaborList;
        data.LaborTypes = laborData.LaborTypes;
        data.Locations = laborData.Locations;
        data.massage = this.massage;
        data.ecoLabAccountNo = this.settings.accountInfo.EcolabAccountNumber;
        this.Views.LaborDataView.setData(data);

    },
    SavelaborData: function (data) {
        this.Model.SavelaborData(data);
    },
    savePage:function(){
        var _this = this;
        var view = this.Views.LaborDataView;
        if (view) {
            if (view.validate()) {
                var data = this.Views.LaborDataView.getLaborData();
                this.Model.SavelaborData(data);
            }
        }
    },
    GetLaborCost: function (type, location)
    {
        this.Model.GetLaborCost(this.settings.accountInfo.EcolabAccountNumber, location, type);
    },
    onLaborCostLoad: function (data) {
        var fetchData = data.ManualLaborList;
        var allowEdit = false;
        var level = this.settings.accountInfo.MaxLevel
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        fetchData.AllowEdit = allowEdit;
        this.Views.LaborDataView.setCostData(data.Cost,this.massage);
        this.Views.AddEditLaborDataView.setData(fetchData);
    },
    onSaved: function (data) {
        this.massage = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
        //this.GetLaborTypeAndLocation();
        this.onLaborCostLoad(data);
        this.isDirty = false;
    },
    onSaveFailed: function (error, desc) {
        this.massage = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
        this.GetLaborTypeAndLocation();
        this.isDirty = false;
    },
    upDateIsDirty: function () {
        this.isDirty = true;
    },

    initAddEditLaborDataView: function () {
        var _this = this;
        if (!this.Views.AddEditLaborDataView) {
            this.Views.AddEditLaborDataView = new Ecolab.Views.AddEditLaborData({
                containerSelector: '#tabLabourRecordContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onDeleteClicked: function () { _this.onDeleteClicked(); }
                }
            });
        }
    },
    onDeleteClicked: function () {
        var _this = this
        var data = this.Views.LaborDataView.getLaborData();
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Ok: {
                    Callback: function () {
                        _this.Model.deleteManualLabor(data)
                        $('#ConfirmDialog').hide();
                    }
                },

                Cancel: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
              , blockSelector: 'body'
        });

    },
};