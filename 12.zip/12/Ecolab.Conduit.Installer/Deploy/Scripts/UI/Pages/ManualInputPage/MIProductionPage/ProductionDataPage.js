﻿Ecolab.Presenters.ProductDataPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ProductDataPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initProductDataView();
        this.initManualProductionAddEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onProductDataLoaded: function (data) { _this.onProductDataLoaded(data); },
            onProductDataDeleted: function (data) { _this.onProductDataDeleted(data) },
            onProductDataDeletionFailed: function (error, description) { _this.onProductDataDeletionFailed(error, description); },
            onProductDataUpdated: function (data) { _this.onProductDataUpdated(data) },
            onProductDataUpdationFailed: function (error, description) { _this.onProductDataUpdationFailed(error, description); },
            onWasherFormulaLoaded: function (data) { _this.onWasherFormulaLoaded(data); },
            onProductionDataFetched: function (data) { _this.onProductionDataFetched(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();

    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ManualInputTabsView) {
            this.Views.ManualInputTabsView = new Ecolab.Views.ManualInputTabs(
                        {
                            containerSelector: '#tabContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadProductData(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.ManualInputTabsView.setData(this.settings.accountInfo);
    },
    initProductDataView: function () {
        var _this = this;
        if (!this.Views.ProductDataView) {
            this.Views.ProductDataView = new Ecolab.Views.MIProduction({
                containerSelector: '#divProductionDataContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onCancelClicked: function () { _this.onCancelClicked(); },
                    onSaveClicked: function (manualProductionViewModel) { _this.onSaveClicked(manualProductionViewModel); },
                    //onDeleteClicked: function (manualProductionViewModel) { _this.onDeleteClicked(manualProductionViewModel); },
                    onWasherGroupChange: function (groupId) { _this.onWasherGroupChange(groupId); },
                    onWasherOrFormulaChange: function (manualProductionViewModel) { _this.onWasherOrFormulaChange(manualProductionViewModel) },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
    },
    initManualProductionAddEditView: function () {
        var _this = this;
        if (!this.Views.ManualProductionAddEditView) {
            this.Views.ManualProductionAddEditView = new Ecolab.Views.ManualProductionAddEdit({
                containerSelector: '#manualProductionDataContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onDeleteClicked: function () { _this.onDeleteClicked(); },
                }
            });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_MANUALINPUT', 'Manual Input');
        breadCrumbData.url = "/ManualUtility";
        this.showPlantBreadCrumb("manualInput", breadCrumbData);
    },

    loadProductData: function () {
        this.Model.loadProductData();
    },

    onProductDataLoaded: function (data) {
        data.hasData = false;
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        data.AllowEdit = allowEdit;
        this.Views.ProductDataView.setData(data);
    },

    onDeleteClicked: function () {
        var _this = this;
        var data = _this.Views.ProductDataView.getIdsToLoadProductData();
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Ok: {
                    Callback: function () {
                        _this.Model.deleteProductData(data)
                        $('#ConfirmDialog').hide();
                    }
                },
                Cancel: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
              , blockSelector: 'body'
        });
    },

    onProductDataDeleted: function (data) {
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        data.AllowEdit = allowEdit;
        this.Views.ManualProductionAddEditView.setData(data);
        //this.Views.ProductDataView.setData(data);
        this.Views.ProductDataView.showMessage(data.Result);
    },

    onProductDataDeletionFailed: function (data) {
        this.Views.ProductDataView.showMessage("301");
    },

    onSaveClicked: function (manualProductionViewModel) {
        this.Model.updateProductData(manualProductionViewModel)
    },

    onProductDataUpdated: function (data) {
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        data.AllowEdit = allowEdit;
        this.Views.ManualProductionAddEditView.setData(data);
        //this.Views.ProductDataView.setData(data);
        this.Views.ProductDataView.showMessage(data.Result);
    },

    onProductDataUpdationFailed: function (data, description) {
        this.Views.ProductDataView.showMessage("301");
    },

    onWasherGroupChange: function (groupId) {
        this.Model.FetchWasherFormulaByWasherGroup(groupId)
    },

    onWasherFormulaLoaded: function (data) {
        data.hasData = false;
        this.Views.ProductDataView.bindFormulaAndWasherData(data);
    },

    onWasherOrFormulaChange: function (manualProductionViewModel) {
        this.Model.FetchProductionData(manualProductionViewModel)
    },

    onProductionDataFetched: function (data) {
        var level = this.settings.accountInfo.MaxLevel
        var allowEdit = false;
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        data.AllowEdit = allowEdit;
        this.Views.ManualProductionAddEditView.setData(data);
        //this.Views.ProductDataView.setData(data);
    },

    savePage: function () {
        var view = this.Views.ProductDataView;
        if (view) {
            view.clearMessage();
            if (view.validate()) {
                 view.onSaveClicked();
                this.isDirty = false;
            }
        }
    },
};