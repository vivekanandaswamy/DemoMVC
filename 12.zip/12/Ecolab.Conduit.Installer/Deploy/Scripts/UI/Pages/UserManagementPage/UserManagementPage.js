// JavaScript source code
Ecolab.Presenters.UserManagementPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.userRoles = null;
};
Ecolab.Presenters.UserManagementPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
        this.initAddEditUserManagementView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onUserManagementDataLoaded: function (data) { _this.onUserManagementDataLoaded(data); },
            onUserManagementEditDataLoaded: function (data, isInline) { _this.onUserManagementEditDataLoaded(data, isInline); },
            onUserRolesLoaded: function (data) { _this.onUserRolesLoaded(data); },
            onUserManagementCreated: function (data) { _this.onUserManagementCreated(data) },
            onUserManagementCreationFailed: function (error, description) { _this.onUserManagementCreationFailed(error, description); },
            onUserManagementUpdated: function (data, isInline) { _this.onUserManagementUpdated(data, isInline) },
            onUserManagementUpdationFailed: function (error, description, isInline) { _this.onUserManagementUpdationFailed(error, description, isInline); },
            onUserManagementDeleted: function (data) { _this.onUserManagementDeleted(data) },
            onUserManagementDeletionFailed: function (error, description) { _this.onUserManagementDeletionFailed(error, description); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.onTabsRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.UserManagementView) {
            this.Views.UserManagementView = new Ecolab.Views.UserManagement({
                containerSelector: '#divUserManagementContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onUserManagementRendered(); },
                    onAddUserManagementClicked: function () { _this.onAddUserManagementClicked(); },
                    onEditUserManagementClicked: function (data) { _this.onEditUserManagementClicked(data); },
                    onInlineEditUserManagementClicked: function (data, isInline) { _this.onUserManagementUpdateClicked(data, isInline); },
                    onInlineEditUserManagementLinkClicked: function (e, data) { _this.onInlineEditUserManagementLinkClicked(e, data); },
                    onDeleteUserManagementClicked: function (id) { _this.onDeleteUserManagementClicked(id); },
                }
            });
        }
    },
    initAddEditUserManagementView: function () {
        var _this = this;
        if (!this.Views.AddEditUserManagementView) {
            this.Views.AddEditUserManagementView = new Ecolab.Views.AddEditUserManagement({
                containerSelector: '#addEditUserManagementPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onUserManagementSaveClicked: function (userManagementData) { _this.onUserManagementSaveClicked(userManagementData); },
                    onUserManagementUpdateClicked: function (userManagementData, isInline) { _this.onUserManagementUpdateClicked(userManagementData, isInline); },
                    onContactChange: function (request, callBack) { _this.loadContacts(request, callBack); }
                }
            });
        }
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function () {
        this.loadUserManagementData();
    },
    onUserManagementRendered: function () {
        if (!this.userRoles)
            this.loadUserRoles();
    },
    onAddUserManagementClicked: function () {
        var data = this.Model.addNewUserManagement();
        data.Roles = this.userRoles;
        this.Views.AddEditUserManagementView.setData(data);
    },
    loadUserManagementData: function () {
        this.Model.loadUserManagementData();
    },
    loadUserRoles: function () {
        this.Model.loadUserRoles();
    },
    onUserManagementDataLoaded: function (data) {
        var drData = {};
        drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
        drData.data = data;
        this.Views.UserManagementView.setData(drData);
    },
    onUserRolesLoaded: function (userRoles) {
        var _this = this;
        this.userRoles = userRoles;
    },

    /////////////UserManagement////////////////
    //onAddUserManagementClicked: function (groupId, units) {
    //    var data = this.Model.addNewUserManagement(groupId, units, this.userRoles);
    //    this.Views.AddEditUserManagementView.setData(data);
    //},

    //Create UserManagement
    onUserManagementSaveClicked: function (userData) {
        this.Model.createUserManagement(userData);
    },
    onUserManagementCreated: function (userData) {
        $('#myModal').modal('hide');
        this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERCREATEDSUCCESSFULLY" class="k-success-message">User created successfully</label>');
        this.loadUserManagementData();
    },
    onUserManagementCreationFailed: function (userManagementData, description) {
        if (description == 301) {
            this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists.Please use a different User Id</label>');
        }
        else if (description == 302) {
            this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_CONTACTALREADYASSOCIATED" class="k-error-message">Contact already associated with a user. Please use a different Contact</label>');
        }
        else {
            this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERCREATIONFAILED" class="k-error-message">User creation failed</label>');
        }
    },
    onInlineEditUserManagementLinkClicked: function (e, data) {
        this.Views.UserManagementView.showEditOnInlineEditLink(e, this.userRoles, data);
    },

    onEditUserManagementClicked: function (data) {
        data.Roles = this.userRoles;
        this.Views.AddEditUserManagementView.setData(data);
    },

    onUserManagementUpdateClicked: function (dryerData, isInline) {
        this.Model.updateUserManagement(dryerData, isInline);
    },
    onUserManagementUpdated: function (dryerData) {
        $('#myModal').modal('hide');
        this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERUPDATEDSUCCESSFULLY" class="k-success-message">User updated successfully</label>');
        this.loadUserManagementData();
    },
    onUserManagementUpdationFailed: function (dryerData, description, isInline) {
        if (description == 301) {
            if (isInline)
                this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists.Please use a different User Id</label>');
            else
                this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists.Please use a different User Id</label>');
        }
        else if (description == 302) {
            this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_NORECORDEXIST" class="k-error-message">No record exists</label>');
        }
        else {
            this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_USERUPDATIONFAILED" class="k-error-message">User updation failed</label>');
        }
    },

    //Delete UserManagement
    onDeleteUserManagementClicked: function (data) {
        var _this = this;
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Yes: {
                    Callback: function () {
                        _this.Model.deleteUserManagement(data);
                        $('#ConfirmDialog').hide();
                    }
                },

                No: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
               , blockSelector: 'body'
        });

    },
    onUserManagementDeleted: function () {
        this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERDELETEDSUCCESSFULLY" class="k-success-message">User deleted successfully</label>');
        this.loadUserManagementData();
    },
    onUserManagementDeletionFailed: function (dryerData, description) {
        this.Views.UserManagementView.showHomePageErrorMessage('<label data-localize ="FIELD_USERDELETIONFAILED" class="k-error-message">User deletion failed</label>');
    },
    loadContacts: function (request, callBack) {
        this.Model.loadContacts(request, callBack);
    }
}