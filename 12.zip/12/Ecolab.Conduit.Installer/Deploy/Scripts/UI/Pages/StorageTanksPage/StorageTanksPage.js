Ecolab.Presenters.StorageTanksPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.e = null;
    this.data = null;
    this.controllersandProducts = null;
    this.message = "";
};
Ecolab.Presenters.StorageTanksPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initStorageTanksTabsView();
        this.initStorageTanksView();
        this.initAddEditStorageTanksView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetStorageTanksDetailsReceived: function (data) { _this.onGetStorageTanksDetailsReceived(data); },
            onGetAddStorageTanksDataRecieved: function (data) { _this.onGetAddStorageTanksDataRecieved(data); },
            onGetEditStorageTanksDataRecieved: function (data) { _this.onGetEditStorageTanksDataRecieved(data); },
            onGetInlineEditStorageTanksDataRecieved: function (data) { _this.onGetInlineEditStorageTanksDataRecieved(data); },
            onGetInlineEditProductDataRecieved: function (data) { _this.onGetInlineEditStorageTanksDataRecieved(data); },
            onStorageTanksDeleted: function (data) { return _this.onStorageTanksDeleted(data); },
            onStorageTanksDeletionFailed: function (error, description) { return _this.onStorageTanksDeletionFailed(error, description); },
            onStorageTankCreated: function (data) { _this.onStorageTankCreated(data); },
            onStorageTankUpdated: function (data) { _this.onStorageTankUpdated(data); },
            onStorageTankUpdatedInline: function (data) { _this.onStorageTankUpdatedInline(data); },
            onStorageTankCreationFailed: function (error, description) { _this.onStorageTankCreationFailed(error, description); },
            onStorageTankUpdationFailed: function (error, description) { _this.onStorageTankUpdationFailed(error, description); },
            onStorageTankDeletionFailed: function (error, description) { _this.onStorageTankDeletionFailed(error, description); },
            onStorageTankInlineUpdationFailed: function (error, description) { _this.onStorageTankInlineUpdationFailed(error, description); },
            onValidateSuccess: function (data) { _this.validateSuccess(data); },
            onValidateFailed: function (error, description) { _this.validateFailed(error, description); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showStorageTanksBreadCrumb();
    },
    initStorageTanksTabsView: function () {

    },
    initStorageTanksView: function () {
        var _this = this;
        if (!this.Views.StorageTanksView) {
            this.Views.StorageTanksView = new Ecolab.Views.StorageTanks({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function () { return _this.getStorageTanksDetails(); },
                    onAddEditStorageTanksClicked: function () { return _this.onAddEditStorageTanksClicked(); },
                    onDeleteStorageTanksClicked: function (id) { return _this.onDeleteStorageTanksClicked(id); },
                    onEditStorageTanksClicked: function (id) { return _this.onEditStorageTanksClicked(id); },
                    onGetInlineEditStorageTanksClicked: function (e, data) { return _this.onGetInlineEditStorageTanksClicked(e, data); },
                    onInlineEditStorageTanksClicked: function (StorageTankData) { return _this.onInlineEditStorageTanksClicked(StorageTankData); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); }
                }
            });
        }
        _this.getStorageTanksDetails();
    },
    initAddEditStorageTanksView: function () {
        var _this = this;
        if (!this.Views.AddEditStorageTanksView) {
            this.Views.AddEditStorageTanksView = new Ecolab.Views.AddEditStorageTanks({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onrendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onStorageTankSaveClicked: function (StorageTanksData) { return _this.onStorageTankSaveClicked(StorageTanksData); },
                    onStorageTankUpdateClicked: function (StorageTanksData) { return _this.onStorageTankUpdateClicked(StorageTanksData); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); },
                    onSavePage: function () { _this.savePage(); },
                }
            });
        }
    },

    showStorageTanksBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_STORAGETANKS', 'Storage Tanks');
        breadCrumbData.url = "/StorageTanks";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onGeneralTabClicked: function () {
        this.loadControllerModelDataData();
    },
    onSetupTabClicked: function () {
    },
    navigateToConfigPage: function (id) {
    },
    getStorageTanksDetails: function () {
        this.Model.getStorageTanksDetails(this.settings.accountInfo.EcolabAccountNumber);
    },
    onGetStorageTanksDetailsReceived: function (data) {
        var _this = this;
        dr = {};
        dr.data = data;
        dr.message = this.message;
        this.settings.accountInfo.FileName = "StorageTanks";
        var tankId = _this.getQueryStringByName('tankId');
        if (tankId > 0) {
            _this.onEditStorageTanksClicked(tankId);
        } else
            this.Views.StorageTanksView.setData(dr);
    },
    onGetAddStorageTanksDataRecieved: function (data) {
        this.settings.accountInfo.FileName = "AddStorageTanks";
        this.Views.AddEditStorageTanksView.setData(data);
    },
    onGetEditStorageTanksDataRecieved: function (data) {
        var _this = this;
        this.settings.accountInfo.FileName = "AddStorageTanks";
        _this.findContainer('Storage Tanks', data[0].TankId);
        this.Views.AddEditStorageTanksView.setData(data);

    },
    onGetInlineEditStorageTanksDataRecieved: function (data) {
        this.controllersandProducts = data;
        this.Views.StorageTanksView.GetInlineControllerDetails(this.e, this.data, this.controllersandProducts);
    },

    onAddEditStorageTanksClicked: function () {
        this.Model.GetAddStorageTanks(this.settings.accountInfo.EcolabAccountNumber);
    },
    onStorageTankCreated: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Storage tanks created successfully</label>';
        this.loadNavigationMenuListView();
        this.Views.AddEditStorageTanksView.showMessage(this.message);
    },
    onStorageTankCreationFailed: function (StorageTankData, description) {
        this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">' + this.buildErrorMessage(description) + '</label>');
    },
    onStorageTankUpdated: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage tanks updated successfully</label>';
        this.Views.AddEditStorageTanksView.showMessage(this.message);
        this.loadNavigationMenuListView();
    },
    onStorageTankUpdatedInline: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage tanks updated successfully</label>';
        this.getStorageTanksDetails();
    },
    onStorageTankUpdationFailed: function (Storagedata, description) {
        this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">' + this.buildErrorMessage(description) + '</label>');
    },
    buildErrorMessage: function (description) {
        var message = '';
        if (jQuery.type(description) == "object") {
            message = $.GetLocaleKeyValue('FIELD_STORAGETANKSUPDATIONFAILED', 'Storage Tank updation failed');
        } else {
            var error = description.split(',');
            var tagLocale = $.GetLocaleKeyValue('FIELD_TAG', 'Tag') + ' - ';
            if (parseInt(error[0]) == 303) {
                message = $.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists.Please use a different name');
            } if (parseInt(error[0]) == 909) {
                message = $.GetLocaleKeyValue('FIELD_INVALIDSERVERCONFIGURATIONFORSELECTEDCONTROLLER', 'Invalid server configuration for selected controller');
            } else if (parseInt(error[0]) == 801 || parseInt(error[0]) == 802 || parseInt(error[0]) == 803) {
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 803) {
                        message = message + $.GetLocaleKeyValue('FIELD_CURRENTLEVEL', 'Current Level') + tagLocale + $('#txtCurrentLevelTag').val();
                    } else if (error[a] == 802) {
                        message = message + $.GetLocaleKeyValue('FIELD_DEVIATION', 'Deviation') + tagLocale + $('#txtDeviationTag').val();
                    } else if (error[a] == 801) {
                        message = message + $.GetLocaleKeyValue('FIELD_SIZE', 'Size') + tagLocale + $('#txtSizeTag').val();
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXIST', 'already exist');
            } else if (parseInt(error[0]) == 804 || parseInt(error[0]) == 805 || parseInt(error[0]) == 806) {
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 804) {
                        message = message + $.GetLocaleKeyValue('FIELD_CURRENTLEVEL', 'Current Level') + tagLocale + $('#txtCurrentLevelTag').val();
                    } else if (error[a] == 805) {
                        message = message + $.GetLocaleKeyValue('FIELD_DEVIATION', 'Deviation') + tagLocale + $('#txtDeviationTag').val();
                    } else if (error[a] == 806) {
                        message = message + $.GetLocaleKeyValue('FIELD_SIZE', 'Size') + tagLocale + $('#txtSizeTag').val();
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid');
            }
        }
        return message;
    },

    onStorageTankInlineUpdationFailed: function (Storagedata, description) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSNAMEALREADYEXIST" class="k-error-message">' + description + '</label>';
        this.getStorageTanksDetails();
    },
    onDeleteStorageTanksClicked: function (id) {
        this.DeleteConformation(id);
    },

    DeleteConformation: function (id) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODDELETETHISSTORAGETANK', 'Are you sure you want to delete this Storage Tank?'),
            Buttons: {
                Ok: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var StorageTankData = { TankId: id, EcolabAccountNumber: _this.settings.accountInfo.EcolabAccountNumber };
                        _this.Model.DeleteStorageTanks(StorageTankData);
                        return true;
                    },
                    CallbackParameters: null
                },
                Cancel: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },


    onEditStorageTanksClicked: function (id) {
        this.Model.EditStorageTanks(id, this.settings.accountInfo.EcolabAccountNumber);
    },
    onGetInlineEditStorageTanksClicked: function (e, data) {
        this.e = e;
        this.data = data;
        var id = data.TankId;
        this.Model.InlineEditStorageTanks(id);

    },
    onInlineEditStorageTanksClicked: function (StorageTankData) {
        this.Model.UpdateStorageTankInline(StorageTankData);
    },
    onStorageTanksDeleted: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSDELETEDSUCCESSFULLY" class="k-success-message">Storage tanks deleted successfully</label>';
        this.loadNavigationMenuListView();
        this.getStorageTanksDetails();
    },
    onStorageTankDeletionFailed: function (dryerGroupData, description) {
        this.message = '<label data-localize ="FIELD_STORAGETANKDELETIONFAILED" class="k-error-message">Storage Tank deletion failed</label>';
        this.getStorageTanksDetails();
    },
    onStorageTankUpdateClicked: function (StorageTankData) {
        this.Model.UpdateStorageTank(StorageTankData);
    },
    onStorageTankSaveClicked: function (StorageTankData) {
        this.Model.createStorageTank(StorageTankData);
    },

    onBackButtonClick: function () {
        this.onStorageTanksClicked();
    },
    savePage: function () {
        var fileName = this.settings.accountInfo.FileName;
        if (fileName == "AddStorageTanks") {
            var view = this.Views.AddEditStorageTanksView;
            if (view) {
            view.clearStatusMessage();
                if (view.validateStorageTanks()) {
                    var storageTanksData = view.getStorageTanksData();
                    if (this.HasDuplicateTags()) {
                        this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                        return false;
                    } else {
                        if (view.options.accountInfo.MaxLevel == 8) {
                            this.Model.ValidateTags(storageTanksData);
                        } else {
                            this.saveData(storageTanksData);
                        }
                        this.isDirty = false;
                    }
                } else {
                    return false;
                }
            }
        } else if (fileName == "StorageTanks") {
            var view = this.Views.StorageTanksView;
            if (view) {
                if (view.validateStorageTank()) {
                    view.onTrSaveClicked();
                    this.isDirty = false;
                }
            }
        }
    },

    validateSuccess: function (data) {
        var storageTankData = this.Views.AddEditStorageTanksView.getStorageTanksData();
        this.saveData(storageTankData);
        },

    validateFailed: function (storagedata, description) {
        if (description.status == 300) {
            this.OverrideConformation(description);
        } else {
            this.onStorageTankUpdationFailed(storagedata, description);
        }
    },

    OverrideConformation: function (description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC Values'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var storageTankData = _this.Views.AddEditStorageTanksView.getStorageTanksData();
                        //$.each(description.PlcTags, function(e, data) {
                        //    if (data.Address == storageTankData.CurrentLevelTag) {
                        //        storageTankData.CurrentLevel = data.Value;
                        //    } else if (data.Address == storageTankData.LevelDeviationTag) {
                        //        storageTankData.LevelDeviation = data.Value;
                        //    } else if (data.Address == storageTankData.SizeTag) {
                        //        storageTankData.Size = data.Value;
                        //    }
                        //});
                        storageTankData.PlcTags = description.PlcTags;
                        storageTankData.OverridePlcValues = true;
                        _this.saveData(storageTankData);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        //var storageTankData = _this.Views.AddEditStorageTanksView.getStorageTanksData();
                        //_this.saveData(storageTankData);
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },

    saveData:function(storageTankData) {
        if (storageTankData.TankId > 0) {
            if (this.onStorageTankUpdateClicked)
                this.onStorageTankUpdateClicked(storageTankData);
        } else {
            if (this.onStorageTankSaveClicked) {
                this.onStorageTankSaveClicked(storageTankData);
            }
        }
    },


    openCurrentNav: function (typeName, id) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('active');
    },
    findContainer: function (typeName, id) {
        var _this = this;
        _this.loadNavigationMenuListView();
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
        return;

    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
};