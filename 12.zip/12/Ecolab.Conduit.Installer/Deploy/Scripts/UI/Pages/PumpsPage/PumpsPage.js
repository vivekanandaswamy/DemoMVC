// JavaScript source code
Ecolab.Presenters.PumpsPage = function(options) {
    this.settings = $.extend(this.defaults, options);
    this.products = null;
    this.evnt = null;
    this.data = null;
    this.massage = null;
    this.controllerName = null;
};
Ecolab.Presenters.PumpsPage.prototype = {
    initViews: function() {
        this.base.initViews.call(this);
        this.initPumpsTabsView();
        this.initPumpsView();
        this.initPumpsEditView();
    },
    initModel: function() {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function(modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function(eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function() {
        var _this = this;
        return {
            onPumpsDataLoaded: function(data) { _this.onPumpsDataLoaded(data); },
            onProductsLoaded: function(products) { _this.onProductsLoaded(products); },
            onPumpUpdated: function(data) { _this.onPumpUpdated(data); },
            onPumpUpdatedEdit: function(data) { _this.onPumpUpdatedEdit(data); },
            onPumpUpdationFailed: function(error, description) { _this.onPumpUpdationFailed(error, description); },
            onPumpUpdationFailedEdit: function(error, description, data) { _this.onPumpUpdationFailedEdit(error, description, data); },
            onControllerNameLoaded: function(name) { _this.onControllerNameLoaded(name); },
            upDateIsDirty: function() { _this.upDateIsDirty(); },
            onValidateSuccess: function(data) { _this.validateSuccess(data); },
            onValidateFailed: function (error, description, localData) { _this.validateFailed(error, description, localData); },
        };
    },
    afterInit: function() {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },

    initPumpsTabsView: function() {
        var _this = this;

        if (!this.Views.PumpsTabView) {
            this.Views.PumpsTabView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function() {
                        _this.onTabsRendered(); //_this.loadControllerModelDataData(_this.settings.accountInfo.RegionId);
                    },
                    generalTabClicked: function() { _this.onGeneralTabClicked(); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function() { _this.onSetupTabClicked(); },
                    onBackButtonClick: function() { _this.onBackButtonClick(); }
                }
            });
        }
        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            _this.findContainer('Controllers', cData.ControllerId, 0);
            this.Views.PumpsTabView.setController(cData);
        }
        this.Views.PumpsTabView.setData(this.settings.accountInfo);
    },

    initPumpsView: function() {
        var _this = this;
        if (!this.Views.PumpsViews) {
            this.Views.PumpsViews = new Ecolab.Views.Pumps({
                containerSelector: '#tabPumpListContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function() {},
                    onDropDownChange: function(option) { _this.onDropDownChange(option); },
                    onEditPumpClicked: function(e, data) { _this.onEditPumpClicked(e, data); },
                    onPumpsInlineEditClicked: function(data, isInline) { _this.onPumpsInlineEditClicked(data, isInline); },
                    onEditClicked: function(data) { _this.onEditClicked(data); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    savePage: function() { _this.savePage(); }
                }
            });
        }
    },

    initPumpsEditView: function() {
        var _this = this;
        if (!this.Views.PumpsEdit) {
            this.Views.PumpsEdit = new Ecolab.Views.PumpsEdit({
                containerSelector: '#tabPumpListContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function() { _this.onEditViewRendered(); },
                    onPumpsEditClicked: function(data, isInline) { _this.onPumpsInlineEditClicked(data, isInline); },
                    onClancelClicked: function() { _this.onClancelClicked(); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    upDateIsDirty: function() { _this.upDateIsDirty(); },
                    savePage: function() { _this.savePage(); }
                }
            });
        }
    },

    onEditViewRendered: function() {
        this.trackChanges();
    },

    onPumpsDataLoaded: function(data) {
        var _this = this;
        var drData = {};
        var count = data.length;
        drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
        drData.massage = this.massage;
        drData.count = count;
        drData.controllerName = this.controllerName;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.data = data;
        var pumpId = _this.getQueryStringByName('PumpId');
        this.Views.PumpsViews.setData(drData);
        if (pumpId > 0) {
            _this.editPump(pumpId);
        }
    },
    displayBreadCrumb: function() {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLERSETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function() {
        this.getControllerName();
        this.loadProducts();
        this.loadPumpsData();
    },

    getControllerName: function() {
        this.Model.getControllerName(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId);
    },
    loadPumpsData: function() {
        this.Model.loadPumpsData(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId);
    },

    onDropDownChange: function(option) {
        this.Model.loadPumpsListOnDropdown(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId, option);
    },

    onEditPumpClicked: function(e, data) {
        this.evnt = e;
        this.data = data;
        this.loadProducts();
    },
    loadProducts: function() {
        this.Model.loadProducts();
    },

    onProductsLoaded: function(products) {
        var _this = this;
        this.products = products;
        this.Views.PumpsViews.showEditOnInlineEditLink(this.evnt, this.products, this.data);
    },
    onPumpsInlineEditClicked: function(pumpData, isInline) {
        //if (!isInline) {
        //    var view = this.Views.PumpsEdit;
        //    if (view) {
        //        if (view.validate()) {
        //            this.Model.updatePumpData(pumpData, isInline);
        //        }
        //    }
        //}

        this.Model.updatePumpData(pumpData, isInline);
    },
    onPumpUpdated: function(data) {
        this.massage = '<label data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully") + '</label>';
        this.loadPumpsData();
    },
    onPumpUpdatedEdit: function(data) {
        this.reLoadEditPage(data);
    },
    onGeneralTabClicked: function() {
        this.loadPumpsData();
    },
    onEditClicked: function(data) {
        var _this = this;
        var drData = {};
        drData.data = data;
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.ControllerName = this.controllerName;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.Products = this.products;
        this.Views.PumpsEdit.setData(drData);
        _this.findContainer('Pumps', drData.data.ControllerEquipmentId, drData.data.ControllerId);

        this.trackChanges();
    },

    savePage: function(data, isInline) {
        var _this = this;
        var view = this.Views.PumpsEdit;
        if (view) {
            if (view.validate()) {
                if (this.HasDuplicateTags()) {
                    this.Views.PumpsEdit.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                    return false;
                } else {
                    var pumpData = this.Views.PumpsEdit.getPumpData();
                    if (!isInline && view.options.accountInfo.MaxLevel == 8) {
                        this.Model.ValidateTags(pumpData);
                    } else {
                        _this.Model.updatePumpData(pumpData, isInline);
                    }
                }
            }
        }
    },

    validateSuccess: function (data) {
        var _this = this;
        var pumpData = this.Views.PumpsEdit.getPumpData();
        _this.Model.updatePumpData(pumpData, false);
    },

    validateFailed: function (data, description, localData) {
        if (description.status == 300) {
            this.OverrideConformation(description);
        } else {
            this.onPumpUpdationFailedEdit(data, description, localData);
        }
    },
    OverrideConformation: function(description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC Values'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function() {
                        dialog.addClass('hide');
                        var pumpData = _this.Views.PumpsEdit.getPumpData();
                        pumpData.PlcTags = description.PlcTags;
                        pumpData.OverridePlcValues = true;
                        _this.Model.updatePumpData(pumpData, false);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function() {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },

    reLoadEditPage: function(data) {
        var drData = {};
        drData.data = data;
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.ControllerName = this.controllerName;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.massage = '<label data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully") + '</label>';
        drData.Products = this.products;
        this.Views.PumpsEdit.setData(drData);
        this.isDirty = false;
    },
    onPumpUpdationFailed: function(error, description) {
        this.massage = '<label class="k-error-message">' + this.buildErrorMessage(description) + '</label>';
        this.loadPumpsData();
        this.isDirty = false;
    },
    onPumpUpdationFailedEdit: function(error, description, data) {
        var drData = {};
        drData.data = data;
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.ControllerName = this.controllerName;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.massage = '<label class="k-error-message">' + this.buildErrorMessage(description) + '</label>';
        drData.Products = this.products;
        this.Views.PumpsEdit.setData(drData);
    },
    buildErrorMessage: function(description) {
        var message = '';
        if (jQuery.type(description) == "object") {
            message = $.GetLocaleKeyValue('FIELD_PUMPSUPDATEFAILED', "Pump details update failed");
        } else {
            var error = description.split(',');
            var tagLocale = $.GetLocaleKeyValue('FIELD_TAG', 'Tag') + ' - ';
            //if (parseInt(error[0]) == 303) {
            //    message = $.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists.Please use a different name');
            //} else 
            if (parseInt(error[0]) == 801 || parseInt(error[0]) == 802 || parseInt(error[0]) == 803) {
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 801) {
                        message = message + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + $('#txtLfsChemicalNameTag').val();
                    } else if (error[a] == 802) {
                        message = message + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + $('#txtKfactorTag').val();
                    } else if (error[a] == 803) {
                        message = message + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + $('#txtPumpCalibrationTag').val();
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXIST', 'already exist');
            } else if (parseInt(error[0]) == 804 || parseInt(error[0]) == 805 || parseInt(error[0]) == 806) {
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 804) {
                        message = message + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + $('#txtLfsChemicalNameTag').val();
                    } else if (error[a] == 805) {
                        message = message + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + $('#txtKfactorTag').val();
                    } else if (error[a] == 806) {
                        message = message + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + $('#txtPumpCalibrationTag').val();
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid');
            } else {
                message = $.GetLocaleKeyValue('FIELD_PUMPSUPDATEFAILED', "Pump details update failed");
            }
        }
        return message;
    },
    onClancelClicked: function() {
        this.massage = "";
        this.Views.PumpsEdit.redirectToPumpsList(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
    },
    onControllerNameLoaded: function(data) {
        this.controllerName = data.ControllerName;
    },
    onBackButtonClick: function() {
        this.onControllerSetupClicked();
    },
    upDateIsDirty: function() {
        this.isDirty = false;
    },
    editPump: function(id) {
        var _this = this;
        var controllerId = _this.getQueryStringByName('ControllerId');
        var container = $(this.Views.PumpsViews.options.containerSelector);
        var element = container.find('span[control-eqpid=' + id + '][controlid=' + controllerId + '].lnkUpdatePump ');
        _this.onEditClicked(this.Views.PumpsViews.getPumpData(element));
    },
    openCurrentNav: function(typeName, id, parentId) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');

        if (typeName == "Pumps") {
            element.addClass('active');
            element.parent('ul').parent('li').addClass('open');
            element.parent('ul').parent('li').parent('ul').parent('li').addClass('open');
            element.parent('ul').slideDown();
            element.parent('ul').parent('li').parent('ul').slideDown();
        }
        if (typeName == "Controllers") {
            element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
            element.addClass('open');
            element.children('ul').children('li').addClass('open');
            element.children('ul').slideDown();
            element.children('ul').children('li').children('ul').slideDown();
        }
    },
    findContainer: function(typeName, id, parentId) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function() { _this.openCurrentNav(typeName, id, parentId); }, 200);
        return;

    },
    getQueryStringByName: function(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
};