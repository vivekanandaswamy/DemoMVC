Ecolab.Presenters.DashboardPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.DashboardPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDashboardListLoaded: function (data) { _this.onDashboardListLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
        this.loadDashboardList();
    },

    initListView: function () {
        var _this = this;
        if (!this.Views.DashboardView) {
            this.Views.DashboardView = new Ecolab.Views.Dashboard(
                        {
                            containerSelector: '#divDashboardContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function () { },
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_Dashboards', 'Dashboards');
        breadCrumbData.url = "/Dashboard";
        this.showPlantBreadCrumb("Dashboards", breadCrumbData);
    },

    loadDashboardList: function () {

        this.Model.loadDashboardList();
    },
    onDashboardListLoaded: function (data) {
        this.Views.DashboardView.setData(data);
    },
};