Ecolab.Presenters.WasherGroupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.message = "";
};

Ecolab.Presenters.WasherGroupPage.prototype = {
    // initialising the base & view events.
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherGroupTabsView();
        this.initWasherGroupView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },

    // initialising the base & model events.
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },

    // Adding options to the model like pagesize and sort order etc.,
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
      },

    // event is for adding the event handlers in the model to access them in presenter.
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },

    // calling the callback events from model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            // Washer Group Grid events
            onWasherGroupDataLoad: function (WasherGroupData) { _this.onWasherGroupDataLoad(WasherGroupData); },//Event is used for getting the data from the model.
            onWasherGroupDeleted: function (WasherGroupData) { _this.onWasherGroupDeleted(WasherGroupData); },//Event gets the response data from the model.
            onWasherGroupDeletionFailed: function (error, description) { _this.onWasherGroupDeletionFailed(error, description); }, //Event gets the error with error details.

            // Add/Edit Washer Group events
            onAddEditWasherGroupLoad: function (addEditWasherGroupData) { _this.onAddEditWasherGroupLoad(addEditWasherGroupData); }, // Event is used for getting the dta from model to add or edit.
            onWasherGroupCreated: function (washerGroupData) { _this.onWasherGroupCreated(washerGroupData); },
            onWasherGroupUpdated: function (washerGroupData) { _this.onWasherGroupUpdated(washerGroupData); },
            onWasherGroupInlineUpdated: function (washerGroupData) { _this.onWasherGroupInlineUpdated(washerGroupData); }
        };
    },

    // for loading the events after initialising.
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showWasherGroupBreadCrumb();
    },

    // initialising the washer group tabs view.
    initWasherGroupTabsView: function () {
        var _this = this;
        if (!this.Views.WasherGroupTabsView) {
            this.Views.WasherGroupTabsView = new Ecolab.Views.WasherGroupTabs({
                containerSelector: '#tabContainer',// Need to clarify the div id to be assign here
                eventHandlers: {
                    rendered: function () { _this.loadWasherGroupModelData(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        // setting the data in tabs js passing from mvc view.
        this.Views.WasherGroupTabsView.setData(this.settings.accountInfo);
    },

    // initalising the washer group view.
    initWasherGroupView: function () {
        var _this = this;
        if (!this.Views.WasherGroupView) {
            this.Views.WasherGroupView = new Ecolab.Views.WasherGroup({
                containerSelector: '#tabWashergroupContainer',// Need to give the div id based on the html
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onDeleteWasherGroupClicked: function (washerGroupId) { _this.onDeleteWasherGroupClicked(washerGroupId); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onAddEditWasherGroupLoad: function (washerGroupId) { _this.loadAddEditWasherGroupModelData(washerGroupId); },
                    onInlineWasherGroupUpdate: function (washerGroupData) { _this.onInlineWasherGroupUpdate(washerGroupData); }
                }
            });
        }
        this.loadWasherGroupModelData();
    },

    showWasherGroupBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERGROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
   
    //clicking on the tab to load the get the data from model.
    onWashergroupTabClicked: function () {
        _this.loadWasherGroupModelData();
    },

    //gets the data from model to load.
    loadWasherGroupModelData: function () {
        this.Model.loadWasherGroupModelData(this.settings.accountInfo.EcolabAccountNumber);
    },

    //gets the data from model and passing to view to bind the data.
    onWasherGroupDataLoad: function (WasherGroupData) {
        WasherGroupData.message = this.message;
        this.Views.WasherGroupView.setData(WasherGroupData);
    },
    
    //Events is for deleting the washer group based on the washer group id.
    onDeleteWasherGroupClicked: function (washerGroupId) {
        this.DeleteGroup(washerGroupId);
    },

    //Event is for receving the response data after deletion and loading the washer group data.
    onWasherGroupDeleted: function (WasherGroupData) {
        this.loadWasherGroupModelData();
        this.loadNavigationMenuListView();
        this.message = '<label data-localize ="FIELD_WASHERGROUPDELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPDELETEDSUCCESSFULLY', "Washer Group deleted successfully.") + '</label>';
    },

    //Event is used for handling the error details while deleting the washergroup.
    onWasherGroupDeletionFailed: function (error, description) {
        this.message = '<label data-localize ="FIELD_WASHERGROUPDELETIONFAILED" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPDELETIONFAILED', "Washer Group deletion failed.") + '</label>';
        
    },

    //loading the washer group data to add/edit.
    loadAddEditWasherGroupModelData: function (washerGroupId) {
        this.RedirectLocation('/WasherGroupFormula?id='+washerGroupId);
    },

    //Setting the washer group data in view.
    onAddEditWasherGroupLoad: function (WasherGroupData) {
        if (WasherGroupData.length == 0) {
            WasherGroupData[0] = {
                WasherGroupId: 0,
                WasherGroupNumber: 0,
                WasherGroupName: '',
                WasherGroupTypeId: 1
            }
        }
        this.Views.AddEditWasherGroupView.setData(WasherGroupData);
    },
      
    onInlineWasherGroupUpdate: function (washerGroupData) {
        this.settings.accountInfo.FileName = "Washergroup";
        this.Model.UpdateInlineWasherGroup(washerGroupData, this.settings.accountInfo.EcolabAccountNumber);
        //this.savePage(washerGroupData);
    },

    onWasherGroupInlineUpdated: function (washerGroupData) {
        this.loadWasherGroupModelData();
        if (washerGroupData != -1) {
            this.message = '<label data-localize ="FIELD_WASHERGROUPUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPUPDATEDSUCCESSFULLY', "Washer Group Updated successfully.") + '</label>';
        }
        else {
            this.message = '<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>';
        }


    },
    savePage: function () {
        var view = this.Views.WasherGroupView;
        if (view) {
            if (view.validate()) {
                view.onSaveTrClicked();
                this.isDirty = false;
            }
        }
    },

    onBackButtonClick: function () {
        this.onWasherGroupClicked();
    },
    
    DeleteGroup: function (washerGroupId) {
        var _this = this;
            var Cdialog = $('#ConfirmDialog');
            Cdialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
                BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
                Buttons: {
                    Ok: {
                        Callback: function () {
                            Cdialog.addClass('hide');
                            var washerGroupData = { WasherGroupId: washerGroupId, EcolabAccountNumber: _this.settings.accountInfo.EcolabAccountNumber }
                            _this.Model.onDeleteWasherGroupClicked(washerGroupData);
                        },
                        CallbackParameters: null
                    },
                    Cancel: {
                        Callback: function () {
                           Cdialog.addClass('hide');
                        },
                        CallbackParameters: null
                    }
                }

            };
            this.Views.confirmDialog.setData(dialogOptions);
        return false;
    },

   
}