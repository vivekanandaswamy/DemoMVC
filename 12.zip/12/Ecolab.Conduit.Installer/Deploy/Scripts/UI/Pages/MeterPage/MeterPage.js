﻿Ecolab.Presenters.MeterPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.MeterPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onMeterDataLoaded: function (data) { _this.onMeterDataLoaded(data); },
            onloadUtilityLocationByUtilityIdLoaded: function (data) { _this.loadUtilityLocationDataLoaded(data); },
            onloadOnUtilityLocationChangeDataLoaded: function (data) { _this.loadOnUtilityLocationChangeDataLoaded(data); },
            //onloadParentDataByMeterIdLoaded: function (data) { _this.loadParentDataLoaded(data); },
            onloadMeterOnAddNewPopupDataLoaded: function (data) { _this.loadMeterOnAddNewPopupDataLoaded(data); },
            onloadUOMDataLoaded: function (data) { _this.loadUOMDataLoaded(data); },
            onloadMeterOnEditPopupDataLoaded: function (data) { _this.loadMeterOnEditPopupDataLoaded(data) },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.MeterView) {
            this.Views.MeterView = new Ecolab.Views.Meter(
                        {
                            containerSelector: '#tabMeterContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadMeterData(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onUtilityTypeChange: function (id) { _this.loadUOMByUtilityTypeId(id); },
                                onUtilityLocationChange: function (id) { _this.loadOnUtilityLocationChange(id); },
                                onAddNewMeterPopupLoad: function () { _this.loadMeterOnAddNewPopupLoad(); },
                                onMeterEditPopupLoad: function (id) { _this.loadMeterOnEditPopupLoad(id); }
                            }
                        });
            this.Views.MeterView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadMeterData: function () {

        this.Model.loadMeterData();
    },
    onMeterDataLoaded: function (data) {
        this.Views.MeterView.setMeterData(data);
    },
    loadOnUtilityLocationChange: function (UtilityLocationId) {
        this.Model.loadOnUtilityLocationChange(UtilityLocationId);
    },
    loadOnUtilityLocationChangeDataLoaded: function (data) {
        this.Views.MeterView.SetOnUtilityLocationChangedData(data);
    },

    loadMeterOnAddNewPopupLoad: function () {
        this.Model.loadMeterOnAddNewPopupLoad();
    },
    loadMeterOnAddNewPopupDataLoaded: function (data) {
        this.Views.MeterView.setMeterOnAddNewPopupLoadData(data);
    },

    loadUOMByUtilityTypeId: function (id) {
        this.Model.loadUOMByUtilityTypeId(id);
    },
    loadUOMDataLoaded: function (data) {
        this.Views.MeterView.SetUOMData(data);
    },

    loadMeterOnEditPopupLoad: function (meterId) {
        this.Model.loadMeterOnEditPopupLoad(meterId);
    },
    loadMeterOnEditPopupDataLoaded: function (data) {
        this.Views.MeterView.SetMeterOnEditPopupLoad(data);
    }
};