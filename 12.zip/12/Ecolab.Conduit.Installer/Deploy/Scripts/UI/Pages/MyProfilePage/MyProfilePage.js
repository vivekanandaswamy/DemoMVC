// JavaScript source code
Ecolab.Presenters.MyProfilePage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.userRoles = null;
};

Ecolab.Presenters.MyProfilePage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initListView();
        this.initChangePasswordView();
    },

    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },

    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },

    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },

    getModelEventHandlers: function () {
        var _this = this;
        return {
            onMyProfileDataLoaded: function (data) { _this.onMyProfileDataLoaded(data); },
            onMyProfileUpdated: function (data) { _this.onMyProfileUpdated(data); },
            onMyProfilePasswordUpdated: function (data) { _this.onMyProfilePasswordUpdated(data); },
            onMyProfilePasswordUpdationFailed: function (data) { _this.onMyProfilePasswordUpdationFailed(data); },
            onMyProfileDataUpdationFailed: function (data) { _this.onMyProfileDataUpdationFailed(data); },
        };
    },

    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
        this.loadMyProfileData();
    },

    initListView: function () {
        var _this = this;
        if (!this.Views.MyProfileView) {
            this.Views.MyProfileView = new Ecolab.Views.MyProfile({
                containerSelector: '#pageContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url) },
                    onChangePasswordClicked: function (data) { _this.onChangePasswordClicked(data); },
                    onSaveClicked: function (data) { _this.onUpdateProfileClicked(data); }
                }
            });
        }
    },

    initChangePasswordView: function () {
        var _this = this;
        if (!this.Views.ChangePasswordView) {
            this.Views.ChangePasswordView = new Ecolab.Views.ChangePassword({
                containerSelector: '#addEditMyProfilePopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onUpdatePasswordClicked: function (data) { _this.onUpdatePasswordClicked(data) }
                }
            });
        }
    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_MYPROFILE', 'My Profile')
        breadCrumbData.url = "/MyProfile";
        this.showPlantBreadCrumb("Home", breadCrumbData);
    },

    savePage: function () {
        var _this = this;
        var view = this.Views.MyProfileView;
        if (view) {
            if (view.validateMyProfile()) {
                var data = this.Views.MyProfileView.getProfileData();
                this.Model.updateMyProfile(data);
            }
        }
    },

    loadMyProfileData: function () {
        this.Model.loadMyProfileData();
    },

    onMyProfileDataLoaded: function (data) {
        this.Views.MyProfileView.setData(data);
    },

    onChangePasswordClicked: function (data) {
        this.Views.ChangePasswordView.setData(data);
    },

    onUpdatePasswordClicked: function (data) {
        this.Model.updatePassword(data);
    },

    onMyProfilePasswordUpdated: function (data) {
        $('#myModal').modal('toggle');
        this.Views.MyProfileView.setData(data);
        this.Views.MyProfileView.showMessage(data.Result);
        
    },

    onMyProfilePasswordUpdationFailed: function (data) {
        $('#myModal').modal('toggle');
        this.Views.MyProfileView.setData(data);
        this.Views.MyProfileView.showMessage(data.Result);
        
    },

    onUpdateProfileClicked: function (data) {
        this.Model.updateMyProfile(data);
    },

    onMyProfileUpdated: function (Result) {
        sessionStorage.localizeData ='';
        window.localeData='';
        this.Views.MyProfileView.showMessage(Result);
    },

    onMyProfileDataUpdationFailed: function (Result) {
        this.Views.MyProfileView.showMessage(Result);
    }
}