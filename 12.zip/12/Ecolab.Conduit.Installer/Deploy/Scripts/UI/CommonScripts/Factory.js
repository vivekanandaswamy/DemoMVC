﻿Ecolab.Common.Factory = function () {
    this.modelBuilder = new Ecolab.Common.ModelBuilder();
    this.presenterBuilder = new Ecolab.Common.PresenterBuilder();
    this.widgetBuilder = new Ecolab.Common.WidgetBuilder();
};

Ecolab.Common.Factory.prototype = {
    createPresenter: function (presenter, presenterOptions) {
        return this.presenterBuilder.buildPresenter(presenter, presenterOptions);
    },

    createModel: function (model, modelOptions) {
        return this.modelBuilder.buildModel(model, modelOptions);
    },

    createWidget: function (widget, widgetOptions) {
        return this.widgetBuilder.buildWidget(widget, widgetOptions);
    }

};

Ecolab.Common.PresenterBuilder = function () { };
Ecolab.Common.PresenterBuilder.prototype = {
    buildPresenter: function (presenterType, presenterOptions) {
        var base = new Ecolab.Presenters.BasePresenter();
        var presenter = new Ecolab.Presenters[presenterType](presenterOptions);
        var combinedPresenter = $.extend(true, {}, base, presenter);
        combinedPresenter.base = base;

        return combinedPresenter;
    }
};

Ecolab.Common.ModelBuilder = function () { };
Ecolab.Common.ModelBuilder.prototype = {
    buildModel: function (modelType, modelOptions) {
        var base = new Ecolab.Model.BaseModel(modelOptions);
        var model = new Ecolab.Model[modelType](modelOptions);
        var combinedModel = $.extend({}, base, model);
        combinedModel.base = base;
        return combinedModel;
    }
};

Ecolab.Common.WidgetBuilder = function () { };

Ecolab.Common.WidgetBuilder.prototype = {
    buildWidget: function (widgetType, widgetOptions) {
        var base = new Ecolab.Widgets.BaseWidget(widgetOptions);
        var widget = new Ecolab.Widgets[widgetType].Widget(widgetOptions);
        var combinedWidget = $.extend({}, base, widget);
        combinedWidget.base = base;

        return combinedWidget;
    }

};

