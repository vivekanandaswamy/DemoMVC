Ecolab.Views.Chemical = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onChemicalNameChange: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Chemical/ChemicalList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
};

Ecolab.Views.Chemical.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
    },
    attachEvents: function () {
        $("#frmChemical").kendoValidator();
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel != 4 && this.data.MaxLevel != 5 && this.data.MaxLevel != 3);
        //debugger
        var wnd, detailsTemplate;
        var trIndex = null;
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/PlantChemical/GetPlantChemical",
                    dataType: "json"
                },
                create: {
                    url: "/api/PlantChemical/CreateChemical",
                    dataType: "json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALADDEDSUCCESSFULLY" class="k-success-message">Chemical Added Successfully</label>');
                            Window.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALADDITIONFAILED" class="k-error-message">Chemical Addition Failed</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/PlantChemical/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALUPDATEDSUCCESSFULLY" class="k-success-message">Chemical Updated Successfully</label>');
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALUPDATIONFAILED" class="k-error-message">Chemical Updation Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/PlantChemical/DeleteChemical",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALDELETEDSUCCESSFULLY" class="k-success-message">Chemical Deleted Successfully</label>');
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALDELETIONFAILED" class="k-error-message">Chemical Deletion Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                }
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "ProductId",
                    fields: {
                        ProductId: { editable: false, type: "number", nullable: false },
                        Name: { editable: false },
                        SKU: { editable: false },
                        Cost: {
                            editable: isInRole,
                            type: "text", validation: {
                                required: true,
                                maxlength: function (input) {
                                    if (input.is("[name='Cost']")) {
                                        input.attr("data-maxlength-msg", "cost is not valid");
                                        var pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,2})?$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else { return false; }
                                    }
                                    return true;
                                }
                            },
                        },
                        DensityFactor: { editable: false },
                        AcceptedDeviation: { editable: false },
                        ProductCategoryId: { editable: false },
                        Type: { editable: false },
                        Supplier: { editable: false },
                        IncludeinCI: { editable: true, type: "boolean" },
                        PackagingSize: { editable: false },
                        Weight: { editable: false },
                        Volume: { editable: false },
                        IsDeleted: { editable: false },
                        ProductcategoryName: { editable: false }
                    }
                }
            }
        });
        var addNew;
        if (_this.allowEdit) {
            Command = [
                       //define the commands here
                       { name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }];
            addNew = [{ text: "<span data-localize='FIELD_ADDCHEMICAL'>Add Chemical</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];

        }
        else {
            Command = [{ name: "view", text: "" }];
        }

        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        if (container.find('#gridChemical').data().kendoGrid)
            container.find('#gridChemical').data().kendoGrid.destroy();

        container.find("#gridChemical").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                  { command: Command, width: "90px", attributes: { "class": "align-center" } },
                  { field: "SKU", title: "<span data-localize='FIELD_SKUNUMBER'>SKU Number</span>", width: "15%" },
                  { field: "Name", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "19%" },
                  { field: "ProductcategoryName", title: "<span data-localize='FIELD_CATEGORY'>Category</span>", width: "16%" },
                  { field: "Cost", title: "<span data-localize='FIELD_PRICE'>Price</span> (<span data-localize='DOLLAR'>$</span>)", format: "{0:0.00}", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" }, width: "9%" },
                  { field: "PackagingSize", title: "<span data-localize='FIELD_PACKAGINGSIZE'>Packaging Size</span>", attributes: { "class": "grid_numbers" }, width: "15%" },
                  { field: "Supplier", title: "<span data-localize='FIELD_SUPPLIER'>Supplier</span>", width: "9%" },
            { field: "IncludeinCI", title: "<span data-localize='FIELD_INCLUDEINCI'>Include in C&I</span>", width: "12%" },
            ],
            editable: "inline"
        });
        function onEdit(e) { clearStatusMessage(); }

        wnd = $("#details")
                        .kendoWindow({
                            title: $.GetLocaleKeyValue("FIELD_EDITCHEMICAL", 'Edit Chemical'),
                            modal: true,
                            visible: false,
                            resizable: false,
                            width: "373px",
                            height: "auto",
                            activate: function (e) {
                                _this.tm.Localize();
                            }
                        }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editChemical").html());
        var isInRole = false;
        if (_this.data != null) {
            //if (_this.data.Roles.indexOf("TMA") > -1)
            isInRole = true;
        }

        function showDetails(e) {
            e.preventDefault();
            clearStatusMessage();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var Chemical = dataSource.get(uid);
                    Chemical.set("IncludeinCI", $("#cbIncludeinCI")[0].checked);
                    Chemical.set("Cost", $("#txtCost").val());
                });
                var grid = $("#gridChemical").data("kendoGrid");
                grid.saveChanges();
                wnd.close();
            }
            else {
                return false;
            }
        });

        var Window, grid;
        $("#gridChemical a.grid-add-new-record").unbind("click");
        $("#gridChemical a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            var dataSource = $("#gridChemical").data("kendoGrid").dataSource;
            Window = $("<div id='popupEditor'>")
               .appendTo($("body"))
               .kendoWindow({
                   title: $.GetLocaleKeyValue("FIELD_ADDCHEMICAL", 'Add Chemical'),
                   modal: true,
                   resizable: false,
                   visible: false,
                   width: "373px",
                   height: "auto",
                   close: onClose,
                   content: {
                       //sets window template
                       template: kendo.template($("#addChemical").html())
                   },
                   activate: function (e) {
                       _this.tm.Localize();
                   }
               }).data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});

            //binds the editing window to the form
            kendo.bind(window.element, model);

            $('#txtNameAdd').autocomplete({
                autoFocus: true,
                minLength: 2,
                delay: 500,
                open: function () { $('.ui-autocomplete').width($(".ui-autocomplete-input").width()); },
                source:
                    function (request, response) {
                        if (_this.options.eventHandlers.onChemicalNameChange)
                            _this.options.eventHandlers.onChemicalNameChange(request, chemicalsLoaded);

                        function chemicalsLoaded(data) {
                            response($.map(data, function (item) {
                                return { label: item.Name, value: item.Name, chemicalId: item.ProductId, cost: item.Cost, includeInCI: item.IncludeinCI }
                            }));
                        }
                    },
                select: function (event, ui) {
                    $("#txtNameAdd").attr("chemicalId", ui.item.chemicalId);
                    $("#txtCostAdd").val(ui.item.cost);
                    $("#cbIncludeinCIAdd").attr("checked", ui.item.includeInCI);
                    $('#btnUpdate').prop('disabled', false);
                },
                focus: function (e, ui) {
                    return false;
                },
                close: function () {
                    $("#txtNameAdd").select();
                }

            }).autocomplete("widget").addClass("autoComplete");

            function _OnTransportRead(e) {
                var text = $.trim(e.data.filter.filters[0].value);

            }

            //initialize the validator
            var validator = $(Window.element).kendoValidator().data("kendoValidator")
            Window.element.find('#btnUpdate').unbind("click");
            Window.element.find('#btnUpdate').click(function (e) {
                if (validator.validate() == true) {
                        dataSource._data[0].ProductId = $("#txtNameAdd").attr('chemicalId');
                        dataSource._data[0].Cost = parseInt($("#txtCostAdd").val().trim());
                        dataSource._data[0].IncludeinCI = $("#cbIncludeinCIAdd")[0].checked;

                        dataSource.sync(); //sync changes

                        grid = $("#gridChemical").data("kendoGrid");
                }
                else {
                    return false;
                }

            });

            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                Window.close();
                Window = null;
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                Window.element.remove();
                Window.destroy();

            }
        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }

    },

};