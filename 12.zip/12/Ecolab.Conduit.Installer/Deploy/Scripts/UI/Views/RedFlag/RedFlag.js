Ecolab.Views.RedFlag = function(options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onAddRedFlagClicked: null,
            onDeleteRedFlagClicked: null,
            onEditRedFlagClicked: null,
            onItemChanged: null,
            onLocationChanged: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/RedFlag/RedFlag.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function() { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;
};
Ecolab.Views.RedFlag.prototype = {
    setData: function(data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function() {
        var _this = this;
        this.attachEvents();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');
        //if (this.options.eventHandlers.rendered)
        //    this.options.eventHandlers.rendered();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    SetOnAddRedFlagDataLoaded: function(data) {
        var _this = this;

        var ddlItemAdd = $('#ddlItemAdd');
        ddlItemAdd.empty();
        ddlItemAdd.append('<option value="">-- Select --</option>');
        if (data.length > 0) {
            $.each(data, function() {
                ddlItemAdd.append('<option value="' + this.ItemId + '" uom = "' + this.UOM + '">' + this.ItemName + '</option>');
            });
        }
        $('#ddlMachinesAdd').multiselect({ nonSelectedText: '-- Select --', disableIfEmpty: true });
        $(".multiselect-custom .multiselect").css("width", $(".input-group").width() + 2 + 'px');
    },
    SetOnItemChangedDataLoaded: function(data) {
        var _this = this;
        if (_this.isEdit == true) {
            var ddlLocation = $('#ddlLocation');
            ddlLocation.html('<option value="">-- Select --</option>');
            if (data.length > 0) {
                $.each(data, function() {
                    ddlLocation.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '">' + this.GroupDescription + '</option>');
                });
            }
        } else if (_this.isEdit == false) {
            var ddlLocationAdd = $('#ddlLocationAdd');
            ddlLocationAdd.html('<option value="">-- Select --</option>');
            if (data.length > 0) {
                $.each(data, function() {
                    ddlLocationAdd.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '">' + this.GroupDescription + '</option>');
                });
            }
        }
    },
    SetOnLocationChangedDataLoaded: function(data) {
        var _this = this;
        var ddlMachines;
        if (_this.isEdit == true) {
            ddlMachines = $('#ddlMachines');
            ddlMachines.empty();
            if (data.length > 0) {
                $.each(data, function() {
                    ddlMachines.append('<option value="' + this.MachineID + '">' + this.MachineName + '</option>');
                });
            }
            multiSelect($('#ddlMachines'), null);
        } else if (_this.isEdit == false) {
            ddlMachines = $('#ddlMachinesAdd');
            ddlMachines.empty();
            if (data.length > 0) {
                $.each(data, function() {
                    ddlMachines.append('<option value="' + this.MachineID + '">' + this.MachineName + '</option>');
                });
            }
            multiSelect($('#ddlMachinesAdd'), null);
        }
        $(".multiselect-custom .multiselect").css("width", $(".input-group").width() + 2 + 'px');
    },

    SetOnEditRedFlagDataLoaded: function(data) {

        var ddlItem = $('#ddlItem');
        ddlItem.html('<option value="">-- Select --</option>');
        if (data.Item.length > 0) {
            $.each(data.Item, function() {
                ddlItem.append('<option value="' + this.ItemId + '" uom = "' + this.UOM + '">' + this.ItemName + '</option>');
            });
            ddlItem.val(data.RedFlag.ItemId);
        }

        var ddlLocation = $('#ddlLocation');
        ddlLocation.html('<option value="">-- Select --</option>');
        if (data.Location.length > 0) {
            $.each(data.Location, function() {
                ddlLocation.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '">' + this.GroupDescription + '</option>');
            });
            ddlLocation.val(data.RedFlag.LocationId);
        }

        var ddlMachines = $('#ddlMachines');
        ddlMachines.empty();
        if (data.Machines.length > 0) {
            $.each(data.Machines, function() {
                ddlMachines.append('<option value="' + this.MachineID + '">' + this.MachineName + '</option>');
            });
        }
        if (data.RedFlag.ItemId != 6 && data.RedFlag.ItemId != 7 && data.RedFlag.ItemId != 8 && data.RedFlag.ItemId != 9) {
            multiSelect(ddlMachines, null);
            $('.ddlMachines').hide();
        } else {
            if ($('#ddlLocation option:selected').data('type') == 'Plant') {
                multiSelect(ddlMachines, null);
                $('.ddlMachines').hide();
                //ddlMachines.attr('required', false);
            } else {
                $('.ddlMachines').show();
                //ddlMachines.attr('required', true);
                multiSelect($('#ddlMachines'), data.RedFlag.MachineIds);
            }
        }

    },

    attachEvents: function() {

        //$("#tabRedFlagContainer").addClass("active");
        //$("#tabRedFlag").parent("li").addClass("active");

        var _this = this;
        var wnd, detailsTemplate, detailsTemplateView;
        var container = $(this.options.containerSelector);

        //Set allow edit on role level
        _this.allowEdit = (this.data.MaxLevel >= 7);

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');


        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/RedFlag/Get",
                    dataType: "json"
                },
                create: {
                    url: "/api/RedFlag/Create",
                    dataType: "json",
                    type: "POST",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_REDFLAGADDEDSUCCESSFULLY" class="k-success-message">Red Flag Added Successfully</label>');
                            window.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        } else if (jqXhr.responseText != '' && JSON.parse(jqXhr.responseText) == '401') {
                            $("#errorMessageAdd").show();
                            $("#errorMessageAdd").html('<span data-localize ="FIELD_DUPLICATEREDFLAG">Duplicate Red Flag found</span>');
                            //dataSource.cancelChanges();
                            //window.close();
                        } else {
                            $("#errorDiv").html('<span data-localize ="FIELD_REDFLAGADDITIONFAILED" class="k-error-message">Red Flag Addition Failed</span>');
                            dataSource.cancelChanges();
                            window.close();
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/RedFlag/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<span data-localize ="FIELD_REDFLAGUPDATEDSUCCESSFULLY" class="k-success-message">Red Flag Updated Successfully</span>');
                            wnd.close();
                            if (!grid)
                                grid = $("#gridRedFlag").data("kendoGrid");
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        } else if (jqXhr.responseText != '' && JSON.parse(jqXhr.responseText) == '401') {
                            $("#errorMessage").show();
                            $("#errorMessage").html('<span data-localize ="FIELD_DUPLICATEREDFLAG">Duplicate Red Flag found</span>');
                            //dataSource.cancelChanges();
                            //window.close();
                        } else {
                            $("#errorDiv").html('<span data-localize ="FIELD_REDFLAGUPDATIONFAILED" class="k-error-message">Red Flag Updation Failed</span>');
                            dataSource.cancelChanges();
                            wnd.close();
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/RedFlag/Delete",
                    dataType: "json",
                    type: "DELETE",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<span data-localize ="FIELD_REDFLAGDELETEDSUCCESSFULLY" class="k-success-message">Red Flag Deleted Successfully</span>');
                        } else {
                            $("#errorDiv").html('<span data-localize ="FIELD_REDFLAGDELETIONFAILED" class="k-error-message">Red Flag Deletion Failed</span>');
                            dataSource.cancelChanges();
                        }
                        _this.tm.Localize();
                    }
                }
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "Id",
                    fields: {
                        ItemName: { editable: false },
                        UOM: { editable: false },
                        MinimumRange: {
                            editable: true,
                            validation: {
                                required: true,
                                validationMessage: $.GetLocaleKeyValue('FIELD_MINIMUMRANGEREQUIRED',"Minimum Range required"),
                                maxLength: function(input) {
                                    if (input.is("[name='MinimumRange']")) {
                                        if (input.val()) {
                                            var pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                                            if (!isNaN(input.val()) && pattern.test(input.val())) {
                                                var maxRange = input.parent().parent().find("[name='MaximumRange']");
                                                if (maxRange.val().length > 0) {
                                                    if (parseInt(input.val()) < parseInt(maxRange.val())) {
                                                        return true;
                                                    } else {
                                                        input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_MINIMUMRANGEMUSTBELESSTHANMAXIMUMMRANGE', "Minimum range must be less than maximum range"));
                                                        return false;
                                                    }
                                                } else {
                                                    return true;
                                                }
                                            } else {
                                                input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_SHOULDBEANUMBERWITH3DECIMALS', "Should be a number with maximum 3 decimals"));
                                                return false;
                                            }
                                        } else {
                                            input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_MINIMUMRANGEREQUIRED', "Minimum range required"));
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }
                        },
                        MaximumRange: {
                            editable: true,
                            validation: {
                                required: true,
                                validationMessage: $.GetLocaleKeyValue('FIELD_MAXIMUMRANGEREQUIRED', "Maximum range required"),
                                maxLength: function(input) {
                                    if (input.is("[name='MaximumRange']")) {
                                        if (input.val()) {
                                            var pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                                            if (!isNaN(input.val()) && pattern.test(input.val())) {
                                                var minRange = input.parent().parent().find("[name='MinimumRange']");
                                                if (minRange.val().length > 0) {
                                                    if (parseInt(input.val()) > parseInt(minRange.val())) {
                                                        return true;
                                                    } else {
                                                        input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_MAXIMUMRANGEMUSTBEGREATERTHANMINIMUMMRANGE', "Maximum range must be greater than minimum range"));
                                                        return false;
                                                    }
                                                } else {
                                                    return true;
                                                }
                                            } else {
                                                input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_SHOULDBEANUMBERWITH3DECIMALS', "Should be a number with maximum 3 decimals"));
                                                return false;
                                            }
                                        } else {
                                            input.attr("validationmessage", $.GetLocaleKeyValue('FIELD_MAXIMUMRANGEREQUIRED', "Maximum range required"));
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }
                        },
                        LocationName: { editable: false },
                        MachineName: { editable: false }
                    }
                }
            }
        });


        var addNew, commands, editTitle;
        if (_this.allowEdit) {
            commands = [{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }];
            addNew = [{ text: $.GetLocaleKeyValue("FIELD_ADDREDFLAG","Add Red Flag"),  className: "btn btn-sm btn-primary grid-add-new-record" }];
            editTitle = "Edit Red Flag";
        } else {
            commands = [{ name: "view", text: "", click: showDetails }];
            addNew = "";
            editTitle = "View Red Flag";
        }

        function onEdit(e) { clearStatusMessage(); }

        function onDataBound(arg) {
            _this.tm.Localize();
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
        }

        if (container.find('#gridRedFlag').data().kendoGrid)
            container.find('#gridRedFlag').data().kendoGrid.destroy();
        container.find("#gridRedFlag").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                { command: commands, width: "80px", attributes: { "class": "align-center" } },
                { field: "ItemName", width: "17%", title: "<span data-localize='FIELD_REDFLAGITEM'>Red Flag Item</span>" },
                { field: "UOM", width: "10%", title: "<span data-localize='FIELD_UOM'>UOM</span>" },
                { field: "MinimumRange", width: "7%", title: "<span data-localize='FIELD_MINIMUMRANGE'>Min</span>", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" } },
                { field: "MaximumRange", width: "7%", title: "<span data-localize='FIELD_MAXIMUMRANGE'>Max</span>", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" } },
                { field: "LocationName", width: "15%", title: "<span data-localize='FIELD_LOCATION'>Location</span>" },
                { field: "MachineName", title: "<span data-localize='FIELD_MACHINES'>Machines</span>" }
            ],
            editable: "inline"
        });

        wnd = $("#details")
            .kendoWindow({
                title: editTitle,
                modal: true,
                visible: false,
                resizable: false,
                width: "373px",
                height: "auto",
                open: onOpen,
                activate: function(e) {
                    _this.tm.Localize();
                }
            }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editRedFlag").html());
        detailsTemplateView = kendo.template($("#editRedFlagView").html());

        //Impliment Cascading population of dropdowns here
        function onOpen(e) {
            if (_this.options.eventHandlers.onEditRedFlagClicked)
                _this.options.eventHandlers.onEditRedFlagClicked(parseInt($('#lblRedFlagId').text()));

            $('#ddlItem').change(function() {
                _this.isEdit = true;
                var itemId = $(this).val();
                var ddlMachines = $('#ddlMachines');
                ddlMachines.empty();
                multiSelect(ddlMachines, null);
                (itemId == 6 || itemId == 7 || itemId == 8 || itemId == 9) ? $('.ddlMachines').show() : $('.ddlMachines').hide();
                $('#ddlLocation').html('<option value="">-- Select --</option>');
                if (itemId != '') {
                    $('.tbUOM').text($("#ddlItem option:selected").attr('uom'));
                    if (_this.options.eventHandlers.onItemChanged)
                        _this.options.eventHandlers.onItemChanged(parseInt($('#lblRedFlagId').text()), itemId);
                }
            });
            $('#ddlLocation').change(function() {
                _this.isEdit = true;
                var itemId = $('#ddlItem').val();
                var ddlMachines = $('#ddlMachines');
                ddlMachines.empty();
                multiSelect(ddlMachines, null);
                $('.ddlMachinesAdd').hide();

                if ($('#ddlLocation option:selected').data('type') != 'Plant' && (itemId == 6 || itemId == 7 || itemId == 8 || itemId == 9)) {
                    $('.ddlMachines').show();

                    if ($(this).val() != '') {
                        if (_this.options.eventHandlers.onLocationChanged)
                            _this.options.eventHandlers.onLocationChanged($('#lblRedFlagId').text(), itemId, $(this).val());
                    }
                }
            });
        }

        var grid;

        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            //dataItem.MeterDataToLoadDropdown = _this.meterData;

            //Set RoleBased editing here
            if (_this.allowEdit) {
                wnd.content(detailsTemplate(dataItem));
            } else {
                wnd.content(detailsTemplateView(dataItem));
            }
            wnd.center().open();
            wnd.element.find(".editRowPopup").unbind("click");
            wnd.element.find(".editRowPopup").click(function() {
                var validator = $(wnd.element).kendoValidator({
                    messages: {
                        matches: function(input) {
                            return input.data("matchesMsg");
                        },
                    },
                    rules: {
                        matches: function(input) { return validateRange(input); }
                    }
                }).data("kendoValidator");

                var uid = $('#lblRedFlagId').text();
                if (validator.validate()) {
                    dataSource.fetch(function() {
                        var redFlag = dataSource.get(uid);
                        redFlag.set("ItemId", $("#ddlItem").val().trim());
                        redFlag.set("MinimumRange", $("#txtMinimumRange").val().trim());
                        redFlag.set("MaximumRange", $("#txtMaximumRange").val().trim());
                        redFlag.set("LocationId", $("#ddlLocation").val().trim());
                        redFlag.set("UOM", $("#ddlItemAdd option:selected").attr('uom'));
                        var selected = [];
                        $('#ddlMachines option:selected').each(function(index, machine) {
                            selected.push([$(this).val()]);
                        });
                        redFlag.set("MachineIds", selected.join(","));
                    });
                    grid = $("#gridRedFlag").data("kendoGrid");
                    grid.saveChanges();
                } else return false;
            });
        }

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function() {
            wnd.close();
        });

        var window;
        $("#gridRedFlag a.grid-add-new-record").unbind("click");
        $("#gridRedFlag a.grid-add-new-record").on("click", function(e) {
            clearStatusMessage();
            var dataSource = $("#gridRedFlag").data("kendoGrid").dataSource;
            window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDREDFLAG", "Add Red Flag"),
                    modal: true,
                    resizable: false,
                    visible: false,
                    width: "373px",
                    height: "auto",
                    open: onAddNewOpen,
                    close: onClose,
                    content: { template: kendo.template($("#newRedFlag").html()) },
                    activate: function(e) {
                        _this.tm.Localize();
                    }
                })
                .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);

            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});

            //binds the editing window to the form
            kendo.bind(window.element, model);

            //initialize the validator
            var validator = $(window.element).kendoValidator({
                messages: {
                    matches: function(input) {
                        return input.data("matchesMsg");
                    },
                },
                rules: {
                    matches: function(input) { return validateRange(input); }
                }
            }).data("kendoValidator");
            window.element.find('#btnUpdate').unbind("click");
            window.element.find('#btnUpdate').click(function(e) {
                if (validator.validate() == true) {
                    dataSource._data[0].ItemId = $("#ddlItemAdd").val().trim();
                    dataSource._data[0].MinimumRange = $("#txtMinimumRangeAdd").val().trim();
                    dataSource._data[0].MaximumRange = $("#txtMaximumRangeAdd").val().trim();
                    dataSource._data[0].LocationId = $("#ddlLocationAdd").val().trim();
                    dataSource._data[0].UOM = $("#ddlItemAdd option:selected").attr('uom');
                    var selected = [];
                    $('#ddlMachinesAdd option:selected').each(function(index, machine) {
                        selected.push([$(this).val()]);
                    });
                    dataSource._data[0].MachineIds = selected.join(",");
                    dataSource.sync();
                    grid = $("#gridRedFlag").data("kendoGrid");
                } else {
                    return false;
                }
            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function(e) {
                dataSource.cancelChanges(model);
                window.close();
                window = null;
            });

            function onClose(e) {
                dataSource.cancelChanges(model);
                window.element.remove();
                window.destroy();
            }
        });

        function onAddNewOpen() {
            if (_this.options.eventHandlers.onAddRedFlagClicked)
                _this.options.eventHandlers.onAddRedFlagClicked();
            $('#ddlItemAdd').change(function() {
                _this.isEdit = false;
                var itemId = $(this).val();
                var ddlMachinesAdd = $('#ddlMachinesAdd');
                ddlMachinesAdd.empty();
                multiSelect(ddlMachinesAdd, null);
                (itemId == 6 || itemId == 7 || itemId == 8 || itemId == 9) ? $('.ddlMachinesAdd').show() : $('.ddlMachinesAdd').hide();

                $('#ddlLocationAdd').html('<option value="">-- Select --</option>');
                if ($(this).val() != '') {
                    $('.tbUOMAdd').text($("#ddlItemAdd option:selected").attr('uom'));
                    if (_this.options.eventHandlers.onItemChanged)
                        _this.options.eventHandlers.onItemChanged(null, itemId);
                }
            });
            $('#ddlLocationAdd').change(function() {
                _this.isEdit = false;
                var itemId = $('#ddlItemAdd').val();
                var ddlMachinesAdd = $('#ddlMachinesAdd');
                ddlMachinesAdd.empty();
                multiSelect(ddlMachinesAdd, null);
                $('.ddlMachinesAdd').hide();

                if ($('#ddlLocationAdd option:selected').data('type') != 'Plant' && (itemId == 6 || itemId == 7 || itemId == 8 || itemId == 9)) {
                    $('.ddlMachinesAdd').show();

                    if ($(this).val() != '') {
                        if (_this.options.eventHandlers.onLocationChanged)
                            _this.options.eventHandlers.onLocationChanged(null, itemId, $(this).val());
                    }
                }
            });
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }

        function validateRange(input) {
            var matches = input.data('matches');
            if (matches) {
                var pattern;
                if (input.is("[name='Minimum Range']")) {
                    pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                    if (!isNaN(input.val()) && pattern.test(input.val())) {
                        var maxRangeTb = $('#' + matches);
                        if (maxRangeTb.val().length > 0) {
                            if (parseInt(input.val()) < parseInt(maxRangeTb.val())) {
                                input.siblings("span.k-tooltip-validation").hide();
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return true;
                        }
                    }
                } else if (input.is("[name='Maximum Range']")) {
                    pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                    if (!isNaN(input.val()) && pattern.test(input.val())) {
                        var minRangeTb = $('#' + matches);
                        if (minRangeTb.val().length > 0) {
                            if (parseInt(input.val()) > parseInt(minRangeTb.val())) {
                                input.siblings("span.k-tooltip-validation").hide();
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return true;
                        }
                    }
                }
            } else {
                return true;
            }
        }
    },
};

function buildTreeViewJSON(data) {
    var locations = [];
    for (var i = 0; i < data.length; i++) {
        var location = {};
        var machines = [];
        if (data[i].Machines) {
            for (var j = 0; j < data[i].Machines.length; j++) {
                var machineLevel = {};
                machineLevel.MachineId = data[i].Machines[j].MachineId;
                machineLevel.MachineName = data[i].Machines[j].MachineName;
                machineLevel.checked = data[i].Machines[j].IsChecked;
                machines.push(machineLevel);
            }
        }
        location.items = machines;
        location.LocationId = data[i].LocationId;
        location.LocationName = data[i].LocationName;
        locations.push(location);
    }
    return locations;
}

function multiSelect(ddlMachines, selectData) {
    ddlMachines.multiselect("destroy").multiselect({
        nonSelectedText: '-- Select --',
        numberDisplayed: 1,
        disableIfEmpty: true,
        onChange: function(option, checked) {
            if (checked) {

                //if (option.val() == -1) {
                //    ddlMachines.find(":selected").removeAttr("selected");
                //    ddlMachines.multiselect('select', -1);
                //    ddlMachines.multiselect("refresh");
                //}
                //else if (option.val() > -1) {
                //    ddlMachines.multiselect('deselect', -1);
                //    ddlMachines.multiselect("refresh");
                //}

                var selected = [];
                $(ddlMachines).find(":selected").each(function(index, machine) {
                    selected.push([$(this).val()]);
                });
            }
        }
    });
    //Selecting the dropdown
    if (selectData) {
        var dataarray = selectData.split(",");
        ddlMachines.multiselect('select', dataarray);
    }
    ddlMachines.multiselect("refresh");
}