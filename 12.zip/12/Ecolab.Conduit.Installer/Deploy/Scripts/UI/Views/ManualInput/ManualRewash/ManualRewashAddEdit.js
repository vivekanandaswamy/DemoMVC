﻿Ecolab.Views.ManualRewashAddEdit = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDeleteClicked: null,
            onWasherGroupChange: null,
            onFormulaChange: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualRewash/ManualRewashAddEdit.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualRewashAddEdit.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        //if (this.options.eventHandlers.rendered)
        //    this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('.datetimepicker').datetimepicker({
            pickTime: false,
        });
        container.find('.datetimepicker').data("DateTimePicker").setMaxDate(container.find(".recordingDate").val());
        container.find('.newDatetime').data("DateTimePicker").setMaxDate(container.find("#txtNewDate").val());

        container.find('.datetimepicker').live('dp.show', function () {
            var _cal = this;
            container.find('.datetimepicker').each(function () {
                if (this !== _cal) {
                    $(this).data("DateTimePicker").hide()
                }
            });
        });

        //Resetting validation messages
        container.find("#btnCancel").click(function () {
            $("#frmProductionData").validate().resetForm();
        });
       

        container.find(".btnDelete").click(function () {
            _this.onDeleteClicked();
        });

        
    },

  

    onDeleteClicked: function () {
       // this.clearMessage();
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked();
    },

   
}