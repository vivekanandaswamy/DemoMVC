﻿Ecolab.Views.ManualUtilityAddEdit = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDeleteClicked: null,
            onWasherGroupChange: null,
            onFormulaChange: null,
            reloadManualUtility: null,
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualUtility/ManualUtilityAddEdit.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualUtilityAddEdit.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "101":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "301":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEFAILED', 'Deletion failed') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.userErrorMsg');
        messageDiv.html(errLabel);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        $('#myModal').modal('show');

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
        
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('.datetimepicker').datetimepicker({
            pickTime: false,
            defaultDate: new Date()
        });
        container.find('.datetimepicker').data("DateTimePicker").setMinDate(container.find(".recordingDate").val());
        container.find('.newDatetime').data("DateTimePicker").setMinDate(container.find("#txtNewDate").val());

        container.find('.datetimepicker').on('dp.show', function () {
            var _cal = this;
            container.find('.datetimepicker').each(function () {
                if (this !== _cal) {
                    $(this).data("DateTimePicker").hide()
                }
            });
        });

        container.find(".btnCancel,.close").click(function () {
            _this.clearMessage();
            $('#myModal').modal('hide');
            $("#myModal").removeClass('fade');
            $(".modal-backdrop").remove();
            //window.location = "/ManualUtility";
            _this.reloadManualUtility();


        })

        container.find("#btnUpdate").click(function () {
            var maxLimit = parseInt(container.find('.trrecording').attr('data-maxvaluelimt'));
            var value1 = 0;
            var value2 = 0;
            value2 = parseInt(container.find('#txtNewValue').val());
            value1 = parseInt(container.find('#txtLastValue').val());
            var isValid = true;
            if (!isNaN(value1)) {
                if (value1 > maxLimit)
                    isValid = false;
            }
            if (!isNaN(value2)) {
                if (value2 > maxLimit)
                    isValid = false;
            }
            if (isValid)
                _this.onSaveClicked();
            else {
                container.find('#errorMaxLimit').text('Reached maximum roll over point: ' + maxLimit);
                return false;
            }
            
        });

        container.find(".btnDelete").click(function () {
            _this.onDeleteClicked();
        });

        container.find(".recordingValue").keyup(function () {
            var tr = $(this).parents('.trrecording').first();
            _this.calculateUsage(tr);
            var tr2 = $(this).parents('.trrecording').siblings();
            _this.calculateUsage(tr2);
        })

        container.find(".usage").keyup(function () {
            var tr = $(this).parents('.trrecording').first();
            _this.calculateValue(tr);
            var tr2 = $(this).parents('.trrecording').siblings();
            _this.calculateValue(tr2);
        })

    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );
        var v1 = container.find('#frmAddEditManual').validate({
            rules: {
                txtNewUsage: {
                    regex: pattern1,
                },
                txtNewValue: {
                    regex: pattern1,
                },
                LastValue: {
                    regex: pattern1,
                },
                txtUsage: {
                    regex: pattern1,
                }
            },
            messages: {
                txtNewUsage: {
                    regex: "*",
                },
                txtNewValue: {
                    regex: "*",
                },
                LastValue: {
                    regex: "*"
                },
                txtUsage: {
                    regex: "*"
                },
            },
           
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find('span.errorMsg'));
            }
        });

        var v2 = container.find('#frmAddEditManual').valid();
        return v2;
    },

    onDeleteClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked(this.getUtilityData());

        var container = $(this.options.containerSelector);
        $(container).empty();
        $('#myModal').modal('hide');
    },

    onSaveClicked: function () {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(this.getUtilityData());
            }
            else {
                return false;
            }
        }
    },
    //getting tr values to save inline
    getUtilityData: function () {

        var container = $(this.options.containerSelector);
        var tr = container.find('.trrecording')
        var ManualUtilityViewModel = {};
        var Utility = [];
        ManualUtilityViewModel.MeterId = $(tr).find("#txtNewValue").attr("data-meterid");
        for (var i = 0; i < tr.length; i++) {
            var objManualUtilityModel = {};
            objManualUtilityModel.RecordedDate = $(tr).find(".recordingDate")[i].value;
            objManualUtilityModel.Value = $(tr).find(".recordingValue")[i].value;
            objManualUtilityModel.Usage = $(tr).find(".usage")[i].value;
            objManualUtilityModel.id = $(tr).find(".recordingValue")[i].attributes["data-id"].value;
            Utility.push(objManualUtilityModel);
        }
        ManualUtilityViewModel.Utility = Utility;
        return ManualUtilityViewModel;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.userErrorMsg').html('');
    },

    reloadManualUtility: function () {
        if (this.options.eventHandlers.reloadManualUtility) {
            this.options.eventHandlers.reloadManualUtility();
        }
    },

    calculateUsage: function (tr) {
        var container = $(this.options.containerSelector);
        //var tr = container.find('.trrecording')
        var maxVal = $(tr).attr("data-maxvaluelimt");
        var currentUsage = 0;
        var prevUsage = 0;
        var currValue = 0;
        var prevValue = 0;
        var usage = 0;
        currentUsage = parseInt($(tr).find(".usage").val());
        currValue = parseInt($(tr).find(".recordingValue").val());
        //if (currValue > maxVal) {
        //    var length = maxVal.toString().length;
        //    $(tr).find(".recordingValue").attr("maxlength", length);
        //}
        if (tr.hasClass('current')) {
            prevUsage = parseInt($(tr).attr("data-prevusage"));
            prevValue = parseInt($(tr).attr("data-prevvalue"));
        }
        else {
            if ($(tr).parent().find('.trrecording').length != 0) {
                prevUsage = parseInt(container.find("#txtUsage").val());
                prevValue = parseInt(container.find("#txtLastValue").val());
            }
            else {
                prevUsage = parseInt($(tr).attr("data-prevusage"));
                prevValue = parseInt($(tr).attr("data-prevvalue"));
            }
        }
        if ($(tr).parent().find('.trrecording').length == 1) {
            if (!isNaN(currValue)) {
                $(tr).find('.usage').val(currValue);
            }
        }
        else {
            if (currValue < prevValue) {
                usage = (maxVal - prevValue) + currValue;
            }
            else {
                usage = currValue - prevValue;
            }

            if (!isNaN(usage)) {
                if (currValue >= 0)
                    $(tr).find('.usage').val(usage);
            }

            if (isNaN(currValue)) {
                $(tr).find('.usage').val('');
            }
        }
    },

    calculateValue: function (tr) {
        var container = $(this.options.containerSelector);
        var maxVal = $(tr).first().attr("data-maxvaluelimt");
        var currentUsage = 0;
        var prevUsage = 0;
        var currValue = 0;
        var prevValue = 0;
        var value = 0;
        currentUsage = parseInt($(tr).find(".usage").val());
        currValue = parseInt($(tr).find(".recordingValue").val());

        //if (currValue > maxVal || currentUsage > currValue) {
        //    var length = maxVal.toString().length;
        //    $(tr).find(".recordingValue").attr("maxlength", length);
        //    $(tr).find(".usage").attr("maxlength", length);
        //}
        if (tr.hasClass('current')) {
            prevUsage = parseInt($(tr).attr("data-prevusage"));
            prevValue = parseInt($(tr).attr("data-prevvalue"));
        }
        else {
            if ($(tr).parent().find('.trrecording').length != 0) {
                prevUsage = parseInt(container.find("#txtUsage").val());
                prevValue = parseInt(container.find("#txtLastValue").val());
            }
            else {
                prevUsage = parseInt($(tr).attr("data-prevusage"));
                prevValue = parseInt($(tr).attr("data-prevvalue"));
            }
        }
        if ($(tr).parent().find('.trrecording').length == 1) {
            if (!isNaN(currentUsage)) {
                $(tr).find('.value').val(currentUsage);
            }
        }
        else {
            value = currentUsage + prevValue;
            if (value > maxVal) {
                value = value - maxVal;
            }

            if (!isNaN(value)) {
                //if (currValue >= 0)
                $(tr).find('.value').val(value);
            }
            if (isNaN(currentUsage)) {
                $(tr).find('.value').val('');
            }
        }
    }
}