﻿Ecolab.Views.LaborData = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.cost = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/ManualInput/LaborData/LaborData.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.LaborData.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }

            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#tblManualLabor').tablesorter({
            headers: {
            }
        });
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find(".ddl").change(function () {
            var location = container.find("#ddlLocation").val();
            var type = container.find("#ddlLaborTypes").val();
            if (type != '') {
                _this.GetLaborCost(type,location);
            } else {
                container.find('#txtLaborCost').val('');
            }

            if (location != '' && type != '') {
                _this.clearStatusMessage();
                container.find(".divHours").removeClass("hide");
                // container.find("#btnSave").prop("disabled", false);
            }
            else {
                container.find(".divHours").addClass("hide");
                //container.find("#btnSave").prop("disabled", true);
            }
        });
        container.find('.datetimepicker').datetimepicker({
            pickTime: false,
        }).live('change', function (en) {
            _this.updateFlag();
        });
        container.find('#btnSave').click(function () {
            _this.clearStatusMessage();
            if (_this.validate()) {
                _this.SavelaborData(_this.getLaborData());
            }
        });
        container.find('#btnCancel').click(function () {
            _this.clearStatusMessage();
            _this.CancelClicked();

        });
      
    },
    getLaborData: function () {
       
        var container = $(this.options.containerSelector);
        var ManualLaborModel = {};
        var InputLabor = [];
        for (var i = 0; i < container.find("tr.recording").length ; i++) {
            var ManualLabor = {};
            ManualLabor.LocationId = container.find('#ddlLocation').val();
            ManualLabor.ManHourTypeId = container.find('#ddlLaborTypes').val();
            ManualLabor.LaborCost = container.find('#txtLaborCost').val();
            ManualLabor.AllocatedManHours = container.find('.alloacatedValue')[i].value;
            ManualLabor.ecolabAccNum = this.options.accountInfo.EcolabAccountNumber;
            ManualLabor.Id = container.find("tr.recording")[i].attributes["data-id"].value;
            ManualLabor.StartDate = container.find(".startDate")[i].value;
            ManualLabor.EndDate = container.find('.endDate')[i].value;
            InputLabor.push(ManualLabor);
        }
        ManualLaborModel.ManualLaborList = InputLabor;
        return ManualLaborModel;
    },

    UpdateCost: function (data) {
        var container = $(this.options.containerSelector);
        container.find('#txtLaborCost').val(data);
       
    },
    clearStatusMessage: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        var messageDiv = container.find("#successMsg");
        messageDiv.text('');
    },
    SavelaborData: function (data) {
        this.clearStatusMessage();
        if (this.options.eventHandlers.savePage)
            this.options.eventHandlers.savePage();
    },

    GetLaborCost: function (type,location) {
        if (this.options.eventHandlers.GetLaborCost)
            this.options.eventHandlers.GetLaborCost(type, location);
    },
    CancelClicked: function () {
        this.clearStatusMessage();
        var retVal = this.options.eventHandlers.onRedirection('./ManualInputLabor');
        return retVal;
    },
    updateFlag: function () {
        if (this.options.eventHandlers.upDateIsDirty)
            this.options.eventHandlers.upDateIsDirty();
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;

        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );

        $.validator.addMethod("rangeDate", function (value, element, params) {
            try {
                var beforedate = $.datepicker.parseDate("mm/dd/yy", $(params[0]).val());
                var afterdate = $.datepicker.parseDate("mm/dd/yy", $(params[1]).val());
                return (beforedate < afterdate);
            } catch (err) {
                return false;
            }
        }, function (params) {
            return $.GetLocaleKeyValue('FIELD_STARTDATESHOULDBELESSTHANENDDATE', "Start date should be less than End date");
        });


        var v1 = container.find('#frmLaborData').validate({
            rules: {
                txtAllocatedManHours: {
                    regex: decimalPattern,
                    required: true,
                },
                txtStartDate: {
                    required: true,
                },
                txtEndDate: {
                    required: true,
                    rangeDate: ["#txtStartDate", "#txtEndDate"]
                },
                ddlLocation: { required: true, },
                ddlLaborTypes: { required: true, },

            },
            messages: {
                txtAllocatedManHours: {
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERALLOCATEDMANHOURS', 'Please Enter Allocated Man Hours')
                },
                txtStartDate: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTSTARTDATE', 'Please Select Start Date')
                },
                txtEndDate: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTENDDATE', 'Please Select End Date')
                },
                ddlLocation: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTLOCATION', 'Please Select Location')
                },
                ddlLaborTypes: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTLABOURTYPE', 'Please Select Labour Type')
                },

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
            }
        });
        var v2 = container.find('#frmLaborData').valid();
        return v2;
    },
    setCostData: function (data,msg) {
        $("#txtLaborCost").val(data);
        $("#successMsg").html(msg);
    }
}