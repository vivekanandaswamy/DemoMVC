﻿Ecolab.Views.MIProduction = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDeleteClicked: null,
            onWasherGroupChange: null,
            onWasherOrFormulaChange: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/MIProduction/ProductionData.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.MIProduction.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "101":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "301":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEFAILED', 'Deletion failed') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.divErrorMsg');
        messageDiv.html(errLabel);
    },
    onRendered: function () {
        var _this = this;
        $('.main-menu-item').removeClass('active');
        $('.main-menu-item-Manual').addClass('active');
        $('.tabProductionData').addClass('active');
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent('.select-wrapper').width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);


        //Event when cancel button clicked
        container.find(".btnCancel").click(function () {
            //Reset old data
            _this.clearMessage();
        })

        //Event for updating data
        container.find(".btnSave").click(function () {
            //Fetch prod data values
            _this.onSaveClicked();
        });

        //Event for deleting LastRecording data
        container.find(".btnDelete").click(function () {
            //Fetch prod data values
            _this.onDeleteClicked();
        });

        //Event to bind data on washergroup change
        container.find(".ddlWasherGroup").change(function () {
            _this.onWasherGroupChange(container.find(".ddlWasherGroup").val());
        });

        //Event to bind data on washer change
        container.find(".ddlWasher").change(function () {
            _this.onWasherOrFormulaChange();
        });

        //Event to bind data on formula change
        container.find(".ddlFormula").change(function () {
            _this.onWasherOrFormulaChange();
        });

        //Resetting validation messages
        container.find("#btnCancel").click(function () {
            window.location = '/MIProduction';
            //_this.cancelClicked()
        });
    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "Please check your input."
       );
        var v1 = container.find('#frmProductionData').validate({
            rules: {
                txtLastValue: {
                    required: true,
                    regex: pattern1
                },
                txtNewValue: {
                    regex: pattern1
                },
                ddlWasherGroup: {
                    required: true
                },
                ddlWasher: {
                    required: true
                },
                ddlFormula: {
                    required: true
                },
            },
            messages: {
                ddlWasherGroup: {
                    required: "Please select WasherGroup",
                },
                ddlWasher: {
                    required: "Please select Washer",
                },
                ddlFormula: {
                    required: "Please select Formula",
                },
                txtLastValue: {
                    required: "*",
                    regex: "*"
                },
                txtNewValue: {
                    regex: "*"
                }

            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parents('div').first().find("span.errorMsg"));
                if (element.hasClass('recordingValue')) {
                    error.appendTo(element.parent().next('span.errorMsg'));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }
        });

        var v2 = container.find('#frmProductionData').valid();
        return v2;
    },

    onDeleteClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked(this.getIdsToLoadProductData());
    },

    onSaveClicked: function () {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(this.getIdsToLoadProductData());
            }
            else {
                return false;
            }
        }
    },

    onWasherGroupChange: function (groupId) {
        var container = $(this.options.containerSelector);
        container.find('#manualProductionDataContainer').empty();
        this.disableButtons();
        this.clearMessage();

        if (container.find(".ddlWasherGroup").val() != "") {
            if (this.options.eventHandlers.onWasherGroupChange) {
                this.options.eventHandlers.onWasherGroupChange(groupId);
            }
        } else {
            var data = {};
            data.Formulas = [];
            data.Washers = [];
            this.bindFormulaAndWasherData(data);
        }
    },

    bindFormulaAndWasherData: function (data) {
        var container = $(this.options.containerSelector);

        var ddlFormula = $(container).find('#ddlFormula');
        ddlFormula.empty();
        ddlFormula.append('<option value="">-- Select --</option>');
        ddlFormula.next('.holder').html('-- select --');

        $.each(data.Formulas, function () {
            ddlFormula.append('<option value="' + this.ProgramNumber + '">' + this.Description + '</option>');
        });

        var ddlWasher = $(container).find('#ddlWasher');
        ddlWasher.empty();
        ddlWasher.append('<option value="">-- Select --</option>');
        ddlWasher.next('.holder').html('-- select --');
        $.each(data.Washers, function () {
            ddlWasher.append('<option value="' + this.MachineID + '">' + this.MachineName + '</option>');
        });
    },

    disableButtons: function () {
        var container = $(this.options.containerSelector);
        container.find('#btnCancel').attr('disabled', 'disabled');
        container.find('#btnSave').attr('disabled', 'disabled');

    },

    onWasherOrFormulaChange: function () {
        this.clearMessage();
        this.disableButtons();
        var container = $(this.options.containerSelector);
        container.find('#manualProductionDataContainer').empty();
        if (container.find(".ddlWasher").val() != "" && container.find(".ddlFormula").val() != "") {
            if (this.options.eventHandlers.onWasherOrFormulaChange) {
                this.options.eventHandlers.onWasherOrFormulaChange(this.getSelectedIds());
            }
        }
    },

    getSelectedIds: function () {
        var container = $(this.options.containerSelector);

        var objManualProductionModel = {};
        objManualProductionModel.WasherGroupId = container.find("#ddlWasherGroup").val();
        objManualProductionModel.WasherId = container.find("#ddlWasher").val();
        objManualProductionModel.FormulaId = container.find("#ddlFormula").val();

        return objManualProductionModel;
    },

    getIdsToLoadProductData: function () {
        var container = $(this.options.containerSelector);
        var ManualProductionViewModel = {};
        var manualProductionModel = [];
        for (var i = 0; i < container.find("tr.recording").length ; i++) {
            var objManualProductionModel = {};
            objManualProductionModel.WasherGroupId = container.find("#ddlWasherGroup").val();
            objManualProductionModel.WasherId = container.find("#ddlWasher").val();
            objManualProductionModel.FormulaId = container.find("#ddlFormula").val();
            objManualProductionModel.RecordedDate = container.find(".recordingDate")[i].value;
            objManualProductionModel.Value = container.find(".recordingValue")[i].value;
            objManualProductionModel.id = container.find("tr.recording")[i].attributes["data-id"].value;
            manualProductionModel.push(objManualProductionModel);
        }
        ManualProductionViewModel.ProductionData = manualProductionModel;
        return ManualProductionViewModel;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.divErrorMsg').html('');
    },

    cancelClicked: function () {
        var retVal = this.options.eventHandlers.onRedirection('/MIProduction');
        return retVal;
    },
}