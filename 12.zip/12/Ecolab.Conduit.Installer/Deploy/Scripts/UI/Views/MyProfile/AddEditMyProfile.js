﻿Ecolab.Views.ChangePassword = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onUpdatePasswordClicked: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditMyProfile',
        templateUri: '/Scripts/UI/Views/MyProfile/AddEditMyProfile.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    
};
var oldPasswordMismatch = false;
    var comparePasswordsMismatch = false;
Ecolab.Views.ChangePassword.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('#myModal').modal({ backdrop: 'static' })
    },

    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveUser').click(function () {
            _this.onUpdatePasswordClicked();
        });

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },

    getMyProfileData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            Password: container.find('#txtConfirmPassword').val(),
        };
    },

    validateMyProfile: function () {
        _this = this;
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmChangePassword').validate({
            rules: {
                txtOldPassword: {
                    required: true,
                },
                txtNewPassword: {
                    required: true,
                },
                txtConfirmPassword: {
                    required: true,
                },
            },
            messages: {
                txtOldPassword: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTEROLDPASSWORD', 'Please enter old password')
                },
                txtNewPassword: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNEWPASSWORD', 'Please enter new password')
                },
                txtConfirmPassword: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERCONFIRMPASSWORD', 'Please enter confirm password')
                },
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmChangePassword').valid();
        return v2;
    },

    onUpdatePasswordClicked: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var passwordsMathced = false;
        passwordsMathced = _this.comparePasswords();
        var formValidated = false;
        formValidated = _this.validateMyProfile();
        if (this.options.eventHandlers.onUpdatePasswordClicked) {
            if (formValidated && passwordsMathced) {
                _this.isDirty = false;
                this.options.eventHandlers.onUpdatePasswordClicked(_this.getMyProfileData());
            } else {
                if (formValidated && !passwordsMathced) {
                    if (!comparePasswordsMismatch)
                        container.find('#userErrorMsg').text($.GetLocaleKeyValue('FIELD_PASSWORDSDIDNOTMATCH', 'Passwords you entered did not match'));
                    if (!oldPasswordMismatch)
                        container.find('#userErrorMsg').text($.GetLocaleKeyValue('FIELD_OLDPASSWORDINCORRECT', 'Old password incorrect'));
                }
                else {
                    container.find('#userErrorMsg').text('');
                }
                return false;
            }
        }
    },

    comparePasswords: function () {
        _this = this;
        var container = $(this.options.containerSelector);
        var oldPassword = container.find('#btnSaveUser').attr('data-pwd').trim();
        var existingPassword = container.find('#txtOldPassword').val();
        var newPassword = container.find('#txtNewPassword').val();
        var commpareNewPassword = container.find('#txtConfirmPassword').val();
        comparePasswordsMismatch = newPassword == commpareNewPassword;
        oldPasswordMismatch = oldPassword == existingPassword;
        return (oldPassword == existingPassword) && (newPassword == commpareNewPassword);
    }

}