﻿Ecolab.Views.StorageTanks = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { },
            onAddEditStorageTanksClicked : null
        },
        Controllers: null,
        ecolabaccountnumber: null,
        maxlevel: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/StorageTanks/StorageTanks.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
}
    
    Ecolab.Views.StorageTanks.prototype = {
        setData: function (data) {
            this.data = data;
            maxlevel = this.options.accountInfo;
            this.tm.Render(data,maxlevel, this);
            ecolabaccountnumber = this.options.accountInfo.EcolabAccountNumber;
        },

        onRendered: function () {
            var _this = this;
            this.attachEvents();

            $('.tabStorageTanks').addClass('active');
            $('#tblStorageTanks').tablesorter({
                headers: {
                    0: {
                        sorter: false
                    }
                }
            });
  
            if (this.options.eventHandlers.rendered)
                _this.options.eventHandlers.rendered();
        },

        attachEvents: function () {
            var _this = this;
            var container = $(this.options.containerSelector);

            container.find('#btnStorageTanksPrint').click(function () {
                var data = {
                    EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                    PageTitle: "Storage Tanks"
                };
                var data = JSON.stringify(data);
                var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
                return retVal;
            });

            container.find("#btnAddStorageTanks").click(function () {
                _this.clearStatusMessage();
                _this.onAddEditStorageTanksClicked();
            });
            container.find(".deleteStorageTank").click(function () {
                _this.clearStatusMessage();
                _this.onDeleteStorageTanksClicked($(this).attr('tank-tankid'));
            });
            container.find(".updateStorageTank").click(function () {
                _this.clearStatusMessage();
                var tr = $(this).parents('.trEditable').first();
                var StorageTanksData = _this.getStorageTanksData(this, tr);
                var id = StorageTanksData.TankId;
                
                    _this.onEditStorageTanksClicked(id);
            });

            container.find('.editStorageTank').click(function () {
                _this.clearStatusMessage();
                var tr = $(this).parents('.trEditable').first().addClass('dirty');
                var StorageTanksData = _this.getStorageTanksData(this, tr);
                _this.onGetInlineEditStorageTanksClicked(this, StorageTanksData);
                tr.find(".noneditable").hide();
                tr.find(".editable").show();
                

            });
            container.find('.updateStorageTankInline').click(function () {
                _this.clearStatusMessage();
                _this.onTrSaveClicked();
               
            });

            container.find(".cancelStorageTankInline").click(function () {
                _this.clearStatusMessage();
                container.find(".noneditable").show();
                container.find(".editable, .error").hide();
                var tr = $(this).parents('.trEditable').first().removeClass('dirty');
                _this.restoreData(tr);
            });
        },
        onTrSaveClicked: function () {
            var tr = $('.table-striped').find('.dirty');
            var StorageTanksData = this.getStorageTanksData($(tr).find('.updateStorageTankInline'), tr);
            if (this.validateStorageTank()) {
                this.onInlineEditStorageTanksClicked(StorageTanksData);
            }
        },
        restoreData: function (tr) {
            var ControllerName = ($(tr).find("#ddlContName").text()).trim();
            var ProductName = ($(tr).find("#ddlProdName").text()).trim();
            
            var InputType = ($(tr).find("#ddlInputType").text()).trim();

            $(tr).find(".ddlContName  option:contains(" + ControllerName + ")").attr('selected', 'selected');
            $(tr).find(".ddlProdName  option:contains(" + ProductName + ")").attr('selected', 'selected');
            //$(tr).find(".ddlInType  option:contains(" + InputType + ")").attr('selected', 'selected');

            $(tr).find("#ddlInputType").val("--Select--");
            $(tr).find(".txtTankName").val($(tr).find("#lblTnkName").text().trim());
            $(tr).find(".txtEmptyLevel").val($(tr).find("#lblEmptyLevel").text().trim());
            $(tr).find(".txtLowLevel").val($(tr).find("#lblLowLevel").text().trim());
            $(tr).find(".txtCallibrationLevel").val($(tr).find("#lblCallibrationLevel").text().trim());
        },
        onAddEditStorageTanksClicked: function () {
           
            if (this.options.eventHandlers.onAddEditStorageTanksClicked)
                this.options.eventHandlers.onAddEditStorageTanksClicked();
        },

        onDeleteStorageTanksClicked: function (id) {
          
            if (this.options.eventHandlers.onDeleteStorageTanksClicked)
                this.options.eventHandlers.onDeleteStorageTanksClicked(id);
        },
        onGetInlineEditStorageTanksClicked: function (e, StorageTanksData) {
          
            if (this.options.eventHandlers.onGetInlineEditStorageTanksClicked)
                this.options.eventHandlers.onGetInlineEditStorageTanksClicked(e, StorageTanksData);
        },
        onEditStorageTanksClicked :function (id) {
            if (this.options.eventHandlers.onEditStorageTanksClicked)
                this.options.eventHandlers.onEditStorageTanksClicked(id);
        },
        onInlineEditStorageTanksClicked: function (StorageTankData) {
            
            if (this.options.eventHandlers.onInlineEditStorageTanksClicked)
                this.options.eventHandlers.onInlineEditStorageTanksClicked(StorageTankData);
        },
        getStorageTanksData: function (element, tr) {
            return {
                TankId: $(element).attr('tank-tankid'),
                TankName: $(tr).find('.txtTankName').val(),
                ControllerId: $(tr).find('.ddlControllerName').val(),
                ControllerName: $(tr).find('.ddlControllerName').text(),
                ProductId: $(tr).find('.ddlProductName').val(),
                ProductName: $(tr).find('.ddlProductName').text(),
                Emptylevel: $(tr).find('.txtEmptyLevel').val(),
                LowLevel: $(tr).find('.txtLowLevel').val(),
                CallibrationLevel: $(tr).find('.txtCallibrationLevel').val(),
                InputType: $(tr).find('.ddlInputType').val(),
                Size:$(element).attr('tank-size'),
                SizeTag:$(element).attr('tank-sizetag'),
                LevelDeviation:$(element).attr('tank-deviation'),
                LevelDeviationTag:$(element).attr('tank-deviationtag'),
                CurrentLevel:$(element).attr('tank-currentlevel'),
                CurrentLevelTag:$(element).attr('tank-currentleveltag'),
                EcolabAccountNumber: ecolabaccountnumber
            };
        },

        GetInlineControllerDetails: function (e, data, controllersproducts) {
            var tr = $(e).parents('.trEditable').first();

            var ddlControllerName = $(tr).find('.ddlControllerName');
            var ddlInputType = $(tr).find('.ddlInputType');
            var controllers;
            var products;
            $.each(controllersproducts, function () {
                controllers = this.Controllers;
                products = this.Products;
            });
           
            ddlControllerName.empty();
            ddlControllerName.append('<option value="">-- Select --</option>');
            $.each(controllers, function () {
                ddlControllerName.append('<option value="' + this.ControllerId + '">' + this.ControllerName + '</option>');
            });
           
            

            var ddlProductName = $(tr).find('.ddlProductName');
            ddlProductName.empty();
           
            ddlProductName.append('<option value="">-- Select --</option>');
            $.each(products, function () {
                ddlProductName.append('<option value="' + this.Id + '">' + this.Name + '</option>');
            });
            
            if (controllersproducts != null) {

                ddlProductName.val(controllersproducts[0].ProductId);
                ddlControllerName.val(controllersproducts[0].ControllerId);
                ddlInputType.val(controllersproducts[0].InputType);
            }

            $(tr).find('.txtTankName').val(data.TankName);
            $(tr).find('.txtEmptyLevel').val(data.Emptylevel);
            $(tr).find('.txtLowLevel').val(data.LowLevel);
            $(tr).find('.txtCallibrationLevel').val(data.CallibrationLevel);

            tr.find(".noneditable").hide();
            tr.find(".editable").show();

            
        },
        clearStatusMessage: function () {
            $("#errordiv").html('');
        },
        validateStorageTank: function () {
            var _this = this;
            var container = $(this.options.containerSelector);
            var v1 = container.find('#frmStorage').validate({
                rules: {
                    txtTankName: { required: true },
                    ddlControllerName: { required: true },
                    ddlProductName: {
                        required: true,
                    },
                    txtEmptyLevel: {
                        required: true
                    },
                    txtLowLevel: { required: true },
                    txtCallibrationLevel: { required: true },
                    ddlInputType: { required: true },
                },
                messages: {
                    txtTankName: {
                        required:'<span class="k-error-message"><label data-localize ="FIELD_TANKNAMECANNOTBEEMPTY" class="error">Tank Name cannot be Empty.</label></span>'
                    },
                    ddlControllerName: { required: $.GetLocaleKeyValue('FIELD_CONTROLLERNAMECANNOTBEEMPTY','Controller Name cannot be Empty.') },
                    ddlProductName: { required: $.GetLocaleKeyValue('FIELD_PRODUCTNAMECANNOTBEEMPTY','Product Name cannot be Empty') },
                    txtEmptyLevel: { required: $.GetLocaleKeyValue('FIELD_EMPTYLEVELCANNOTBEEMPTY','Empty Level cannot be Empty.') },
                    txtLowLevel: { required: $.GetLocaleKeyValue('FIELD_LOWLEVELCANNOTBEEMPTY','Low Level cannot be Empty') },
                    txtCallibrationLevel: { required: $.GetLocaleKeyValue('FIELD_CALLIBRATIONLEVELCANNOTBEEMPTY','Callibration Level cannot be Empty') },
                    ddlInputType: { required: $.GetLocaleKeyValue('FIELD_INPUTTYPECANNOTBEEMPTY','Input Type cannot be Empty') }
                }
            });

            var v2 = container.find('#frmStorage').valid();
            return v2;
        },
    };


