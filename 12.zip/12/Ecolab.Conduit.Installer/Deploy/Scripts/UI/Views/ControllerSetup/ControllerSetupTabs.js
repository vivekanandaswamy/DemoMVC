Ecolab.Views.ControllerSetupTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.ControllerData = null;
    this.tm = new TemplateManager({
        templateName: 'ControllerSetupTabs',
        templateUri: './Scripts/UI/Views/ControllerSetup/ControllerSetupTabs.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.ControllerSetupTabs.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    setController: function (controllerData) {
        this.ControllerData = controllerData;
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    resetGrids: function () {
        var container = $(this.options.containerSelector);
        /*Handle Controller Setup List grid*/
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-Setup').addClass('active');
        

        if (_this.data != null) {
            $('#' + _this.data.TabToSelect).parent().addClass('active');
            $('#' + _this.data.TabToSelect + 'Container').addClass('active');
        }

        container.find('#btnControllerSetupPrint').click(function () {
            var data = {
                TabId: 1,
                RegionId: _this.data.RegionId,
                EcolabAccountNumber: _this.data.EcolabAccountNumber,
                PageTitle: "Controller Setup",
                ControllerId: _this.data.ControllerId,
                ControllerModelId: _this.data.ControllerModelId,
                ControllerTypeId: _this.data.ControllerTypeId
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.data.PrintAction + "?data=" + data);
            return retVal;
        });

        container.find('#tabGeneral').click(function () {
            var url = "/ControllerSetup";
            //container.find('.ControllerSetupdtls_tabs,.tab-pane').removeClass('active');
            //container.find('#tabGeneralContainer').html('').addClass('in active');
            _this.onGeneralTabClicked();

            if (_this.ControllerData && _this.ControllerData.ControllerId != -1) {
                url = "/ControllerSetup?ControllerId=" + _this.ControllerData.ControllerId + "&ControllerModelId=" + _this.ControllerData.ControllerModelId + "&ControllerTypeId=" + _this.ControllerData.ControllerTypeId;
            }

            var retVal = _this.options.eventHandlers.onRedirection(url);
            return retVal;
        });
        container.find('#tabAdvanced').click(function () {
            var retVal = null;
            if (_this.ControllerData.ControllerModelId != 5) {
                retVal = _this.options.eventHandlers.onRedirection('/ControllerSetupAdvance?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                return retVal;
            }
        });
        container.find('#tabPumpList').click(function () {
            var retVal = null;
            if (_this.ControllerData.ControllerModelId != 5) {
                retVal = _this.options.eventHandlers.onRedirection('/Pumps?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                return retVal;
            }
        });

        container.find("#bckbutton").click(function () {
            _this.onBackButtonClicked();
        });

        //var isInRole = false;
        //if (_this.data != null) {
        //    if (_this.data.Roles.indexOf("TMA") > -1)
        //        isInRole = true;
        //}
    },

    onGeneralTabClicked: function () {
        if (this.options.eventHandlers.generalTabClicked)
            this.options.eventHandlers.generalTabClicked();
    },
    onBackButtonClicked: function () {
        this.options.eventHandlers.onBackButtonClick();
    }
};
function localize() {
    var opts = { language: "en-EN", pathPrefix: "Miscellaneous/GetLocalizationData" };
    $("[data-localize]").localize("local", opts);
}

//container.find('select').kendoDropDownList();
//container.find("#Input_Control_4_18, #Input_Control_4_20").kendoMobileSwitch({ onLabel: "YES", offLabel: "NO" });