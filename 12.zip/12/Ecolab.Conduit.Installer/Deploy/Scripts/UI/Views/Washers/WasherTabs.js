Ecolab.Views.WasherTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: { onRedirection: function () { } },
        accountInfo: null,
        drdata: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'WasherTabs',
        templateUri: '/Scripts/UI/Views/Washers/WasherTabs.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.WasherTabs.prototype = {
    // sets the tunnel compartments data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.drdata = data;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        if (_this.data != null) {
            $('#' + _this.data.TabToSelect).parent().addClass('active');
            $('#' + _this.data.TabToSelect + 'Container').addClass('active');
        }
        container.find('#tabGeneral').click(function () {
            if ($(this).parent('li').first().hasClass('active'))
                return false;
            _this.onTabGeneralClicked();
        });
        container.find('#tabFormula').click(function () {
            _this.ontabFormulaClicked();
        });
        container.find('#tabCompartments').click(function () {
            if ($(this).parent('li').first().hasClass('active'))
                return false;
            if (_this.data.TunnelId != '') {
                _this.onCompartmentClicked(_this.data.TunnelId);
            }
        });
        container.find('#tabHoldCondition').click(function () {
            if ($(this).parent('li').first().hasClass('active'))
                return false;
            var tunnelId = container.find('#hTunnelId').val();
            var washerId = container.find('#hConventionalId').val();
            if (tunnelId != null) {
                if (tunnelId != '') {
                    _this.onHoldConditionClicked();
                }
            }
            else {
                if (washerId != '') {
                    _this.onHoldConditionClicked();
                }
            }
        });
        $('#bckbutton').click(function () {
            _this.onBackButtonClicked();
        });
        $('#bckWasherbutton').click(function () {
            _this.onBackWasherButtonClicked();
        });

    },
    onFormulasClicked: function () {
    },
    onBackButtonClicked: function () {
        var retval = this.options.eventHandlers.onRedirection('/WasherGroup');
        return retval;
    },
    onBackWasherButtonClicked: function () {
        var container = $(this.options.containerSelector);
        var washerGroupId = container.find('#hWashergroupId').val();
       this.options.eventHandlers.onRedirection('./WasherGroupFormula?' + 'id=' + washerGroupId + "&data=List");
    },
    onTabGeneralClicked: function () {
        var container;
        var washerGroupId;
        var washerGroupTypeId;
        var retval;
        if (this.drdata.WasherGroupTypeId == 1) {
            container = $(this.options.containerSelector);
            var conventionalId = container.find('#hTunnelId').val();
            washerGroupId = container.find('#hWashergroupId').val();
            washerGroupTypeId = container.find('#hWashergroupTypeId').val();
            if (conventionalId != '') {
                if (conventionalId != null) {
                    retval = this.options.eventHandlers.onRedirection('/ConventionalGeneral' + '?WasherGroupId=' + washerGroupId + '&WasherId=' + conventionalId + '&WasherGroupTypeId=' + washerGroupTypeId);
                    return retval;
                }
                else {
                    retval = this.options.eventHandlers.onRedirection('/ConventionalGeneral' + '?WasherGroupId=' + washerGroupId);
                    return retval;
                }
            }
            else {
                retval = this.options.eventHandlers.onRedirection('/ConventionalGeneral' + '?WasherGroupId=' + washerGroupId + '&WasherId=' + conventionalId);
                return retval;
            }
           
        }
        else {
            container = $(this.options.containerSelector);
            var tunnelId = container.find('#hTunnelId').val();
            var controllerId = container.find('#ddlController').val();
            if (controllerId == null) {
                controllerId = container.find('#hControllerId').val();
            }
            washerGroupId = container.find('#hWashergroupId').val();
            washerGroupTypeId = 2;
            if (tunnelId != '') {
                if (tunnelId != null) {
                    retval = this.options.eventHandlers.onRedirection('/TunnelGeneral' + '?WasherGroupId=' + washerGroupId + '&WasherId=' + tunnelId + '&WasherGroupTypeId=' + washerGroupTypeId + '&ControllerId=' + controllerId);
                    return retval;
                }
                else {
                    retval = this.options.eventHandlers.onRedirection('/TunnelGeneral' + '?WasherGroupId=' + washerGroupId + '&WasherGroupTypeId=' + washerGroupTypeId);
                    return retval;
                }
            }
            else {
                retval = this.options.eventHandlers.onRedirection('/TunnelGeneral' + '?WasherGroupId=' + washerGroupId + '&WasherGroupTypeId=' + washerGroupTypeId);
                return retval;
            }
        }
    },
    onCompartmentClicked: function (id) {
        var container = $(this.options.containerSelector);
        var tunnelId;
        var controllerId = container.find('#ddlController').val();
        if (controllerId == null) {
            controllerId = container.find('#hControllerId').val();
        }
        if (id)
            tunnelId = id;
        else if (this.options.accountInfo.ReturnTunnelId)
            tunnelId = this.options.accountInfo.ReturnTunnelId;
       
        var washerGroupId = container.find('#hWashergroupId').val();
        var noofCompartments = container.find('#txtNoOfCompartments').val();
        if (noofCompartments == null) {
            noofCompartments = container.find('#hNoofCompartments').val();
        }
        var controllerTypeId = container.find('#ddlController option:selected').attr('controllertypeid');
        if (controllerTypeId == null) {
            controllerTypeId = container.find('#hControllerTypeId').val();
        }
        var controllermodelid = container.find('#ddlController option:selected').attr('controllermodelid');
        if (controllermodelid == null) {
            controllermodelid = container.find('#hControllerModelId').val();
        }
        if (parseInt(noofCompartments) > 0) {
            var retval = this.options.eventHandlers.onRedirection('/TunnelCompartment?TunnelId=' + tunnelId + '&WasherGroupId=' + washerGroupId + '&ControllerId=' + controllerId + '&Compartments=' + noofCompartments + '&ControllerTypeId=' + controllerTypeId + '&ControllerModelId=' + controllermodelid);
            return retval;
        }
    },
    onHoldConditionClicked: function () {
        var container = $(this.options.containerSelector);
        var controllerTypeId;
        var controllermodelid;
        var retval;
        if (this.drdata.WasherGroupTypeId == 1) {
            var controllerId=this.drdata.ControllerId;
            controllerTypeId = container.find('#ddlController option:selected').attr('controllertypeid');
            if (controllerTypeId == null) {
                controllerTypeId = container.find('#hControllerTypeId').val();
            }
            controllermodelid = container.find('#ddlController option:selected').attr('controllermodelid');
            if (controllermodelid == null) {
                controllermodelid = container.find('#hControllerModelId').val();
            }
            var lfsWasherNumber = container.find('#ddlLfsWasher option:selected').val();
            if (lfsWasherNumber == null) {
                lfsWasherNumber = container.find('#ddlLfsWasher').val();
            }
            var conventionalId = container.find('#hConventionalId').val();

            retval = this.options.eventHandlers.onRedirection('/HoldCondition?ControllerModelId=' + controllermodelid + '&ControllerTypelId=' + controllerTypeId + '&MachineNumber=' + lfsWasherNumber + '&WashergroupId=' + this.drdata.WasherGroupId + '&WashergroupTypeId=' + this.drdata.WasherGroupTypeId + '&TunnelId=' + conventionalId + '&ControllerId=' + controllerId);
            return retval;
        }
        else {
            var washerGroupId = container.find('#hWashergroupId').val();
            var tunnelId = container.find('#hTunnelId').val();
            var noofCompartments = container.find('#txtNoOfCompartments').val();
            if (noofCompartments == null) {
                noofCompartments = container.find('#hNoofCompartments').val();
            }
            var washergroupTypeId = container.find('#hWashergroupTypeId').val();
            controllermodelid = container.find('#ddlController option:selected').attr('controllermodelid');
            if (controllermodelid == null) {
                controllermodelid = container.find('#hControllerModelId').val();
            }
            controllerTypeId = container.find('#ddlController option:selected').attr('controllertypeid');
            if (controllerTypeId == null) {
                controllerTypeId = container.find('#hControllerTypeId').val();
            }
            var controllerId = container.find('#ddlController').val();
            if (controllerId == null) {
                controllerId = container.find('#hController').val();
            }
            retval = this.options.eventHandlers.onRedirection('/HoldCondition?ControllerModelId=' + controllermodelid + '&ControllerTypelId=' + controllerTypeId + '&MachineNumber=0&WashergroupId=' + washerGroupId + '&NoofCompartments=' + noofCompartments + '&TunnelId=' + tunnelId + '&WashergroupTypeId=' + washergroupTypeId + '&ControllerId=' + controllerId);
            return retval;
        }
    },
    ontabFormulaClicked: function () {
        if (this.options.eventHandlers.ontabFormulaClicked)
            this.options.eventHandlers.ontabFormulaClicked();
    },

}