﻿Ecolab.Views.BreadCrumb = function (options) {
    var _this = this;

    var defaults = {
        eventHandlers: {
        },

        containerSelector: '#breadCrumbContainer'
    };

    this.settings = $.extend(defaults, options);

    //creating the template manager
    this.tm = new TemplateManager({
        templateName: 'BreadCrumb',
        templateUri: '/Scripts/UI/Views/BreadCrumb/BreadCrumb.html',
        parameters: [],
        containerElement: this.settings.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.BreadCrumb.prototype = {

    setData: function (data) {
        this.tm.Render(data, this);
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        container.find('#breadCrumb .link').click(function (event) {
            event.preventDefault();
            if (_this.settings.eventHandlers.breadCrumbLinkClicked)
                _this.settings.eventHandlers.breadCrumbLinkClicked(this.href);            
        });

    },

    onRendered: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        this.attachEvents();
        var lastbrcdm = $(".breadcrumb li:last-child a").text();
        $(".breadcrumb li:last-child").html(lastbrcdm);
    }
};
