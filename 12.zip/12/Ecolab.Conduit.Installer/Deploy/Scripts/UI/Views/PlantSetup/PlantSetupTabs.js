Ecolab.Views.PlantSetupTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { },
            onRedirection: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'PlantSetupTabsList',
        templateUri: './Scripts/UI/Views/PlantSetup/PlantSetupTabs.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.PlantSetupTabs.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling by venkat
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-Setup').addClass('active');

        if (_this.data != null) {
            $('#' + _this.data.TabToSelect).parent().addClass('active');
            $('#' + _this.data.TabToSelect + 'Container').addClass('active');
        }
        container.find('#tabGeneral, #tabPlantSetup').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/PlantSetup');
            return retVal;
        });

        container.find('#tabContacts').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Contact');
            return retVal;
        });

        container.find('#tabCustomer').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Customer');
            return retVal;
        });

        container.find('#tabChemicals').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Chemical');
            return retVal;
        });

        container.find('#tabMeter').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Meter');
            return retVal;
        });

        container.find('#tabDevice').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Utility');
            return retVal;
        });

        container.find('#tabSensor').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Sensor');
            return retVal;
        });
        container.find('#tabRedFlag').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/RedFlag');
            return retVal;
        });
        container.find('#tabUtilities, #tabUtilitySetup').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/PlantUtilitySetup');
            return retVal;
        });

        container.find('#tabFormula').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Formula');
            return retVal;
        });

        container.find('#tabShiftLabor').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/ShiftLabor');
            return retVal;
        });

        container.find('#tabCleanSide').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Dryer');
            return retVal;
        });

        container.find('#tabDryerContainer').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Dryer');
            return retVal;
        });

        container.find('#tabFinnisherContainer').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Finnisher');
            return retVal;
        });

        container.find('#tabUserManagement').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/UserManagement');
            return retVal;
        });

        container.find('#btnPlantSetupPrint').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection(_this.data.PrintAction + "?page=" + _this.data.PageName);
            return retVal;
        });

        container.find('#tabLaborCost').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/LaborCost');
            return retVal;
        });

        container.find('#tabMonitorSetup').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/MonitorSetUp');
            return retVal;
        });

        container.find('#tabTargetProd').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/TargetProduction');
            return retVal;
        });
    },

    onGeneralTabClicked: function () {
        if (this.options.eventHandlers.generalTabClicked)
            this.options.eventHandlers.generalTabClicked();
    },
    onCustomerTabClicked: function () {
        if (this.options.eventHandlers.customerTabClicked)
            this.options.eventHandlers.customerTabClicked();
    }
};