﻿Ecolab.Views.Visualization = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/Visualization/Visualization.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.Visualization.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.css({"width":"100%", "height": "100%"});
        container.find(".header-right .number").fitText(0, { minFontSize: '38px', maxFontSize: '40px' });
        container.find(".header-right .label").fitText(1.4, { minFontSize: '16px', maxFontSize: '24px' });
        container.find(".other-info span").fitText(0, { minFontSize: '16px', maxFontSize: '24px' });
    }
};