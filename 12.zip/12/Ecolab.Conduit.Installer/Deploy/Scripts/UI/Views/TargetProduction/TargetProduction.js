﻿Ecolab.Views.TargetProduction = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onCancelClicked: null,
            onSaveClicked:null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    var index = null;
    this.tm = new TemplateManager({
        templateName: 'TargetProduction',
        templateUri: './Scripts/UI/Views/TargetProduction/TargetProduction.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};
Ecolab.Views.TargetProduction.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        $("#tabGeneralContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");
        $('.tabTargetProd').addClass('active');

        container.find("#btnTargetProdUpdate").click(function () {
            _this.onSaveClicked();
        })

        container.find("#btnCancel").click(function (e) {
            _this.onCancelClicked(e);
        });

        $('.targetProd').on('keydown', function () {
            $(this).addClass('isdirty');
        })

        function centerModal() {
            $("#targetProdModal").css('display', 'block');
            var $dialog = $("#laborModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },

    onCancelClicked: function () {       
        var retVal = this.options.eventHandlers.onRedirection('/TargetProduction');
        return retVal;
    },
   
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );
        var v1 = container.find('#frmEditTargetProd').validate({
            onsubmit: true,
            onkeyup: false,
            focusInvalid: true,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });


        container.find("input.targetProd").each(function () {
            $(this).rules('add', {
                required: true,
                regex:pattern1,
                messages: {
                    required: "*",
                    regex:"*"
                }
            });
        });

        var v2 = container.find('#frmEditTargetProd').valid();
        return v2;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('#successMsg').html('');
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved Successfully') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
            default:
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('#successMsg');
        messageDiv.html(errLabel);
    },

    onSaveClicked: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                _this.isDirty = false;
                this.options.eventHandlers.onSaveClicked(_this.getTargetProdData());
                container.find('input').removeClass('isdirty');
            } else {
                return false;
            }
        }
    },

    getTargetProdData: function () {
        var container = $(this.options.containerSelector);
        var targetProdViewModel = {};
        var targetProdModel = [];
        var content = container.find("input.isdirty");
        for (var i = 0; i < content.length ; i++) {
            var objtargetProdModel = {};
            objtargetProdModel.ShiftId = $(content[i]).data('shiftid');
            objtargetProdModel.DayId = $(content[i]).data('dayid');
            objtargetProdModel.TargetProd = $(content[i]).val();
            targetProdModel.push(objtargetProdModel);
        }
        targetProdViewModel.LaborCostModel = targetProdModel;
        return targetProdModel;
    },

    showErrorMessage: function (error, description) {
    },
}