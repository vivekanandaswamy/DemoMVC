Ecolab.Views.Utility = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onloadDeviceModelByDeviceTypeId: null,
            onAddNewUtilityPopupLoad: null,
            onUtilityEditLoad: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.isEdit = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Utility/Utility.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.deviceData = null;
    this.allowEdit = false;
};

Ecolab.Views.Utility.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
    },
    setDeviceData: function (data) {
        var _this = this;
        this.deviceData = data;
    },
    setDeviceTypeData: function (data) {
        var _this = this;
        var ddlDeviceType = $('#ddlDeviceType');
        ddlDeviceType.empty();
        ddlDeviceType.append('<option value=""></option>');
        $.each(data.DeviceType, function () {
            ddlDeviceType.append('<option value="' + this.ddlDeviceTypeId + '">' + this.Description + '</option>');
        });
    },
    setDeviceModelData: function (data) {
        var _this = this;
        if (_this.isEdit == true) {
            var ddlDeviceModel = $('#ddlDeviceModel');
            ddlDeviceModel.empty();
            ddlDeviceModel.append('<option value=""></option>');
            $.each(data, function () {
                ddlDeviceModel.append('<option value="' + this.DeviceModelId + '">' + this.Description + '</option>');
            });
        } else if (_this.isEdit == false) {
            var ddlDeviceModel = $('#ddlDeviceModelAddNew');
            ddlDeviceModel.empty();
            ddlDeviceModel.append('<option value=""></option>');
            $.each(data, function () {
                ddlDeviceModel.append('<option value="' + this.DeviceModelId + '">' + this.Description + '</option>');
            });
        }
    },
    setUtilityOnAddNewPopupLoadData: function (data) {
        var _this = this;
        var ddlDeviceType = $('#ddlDeviceTypeAddNew');
        ddlDeviceType.empty();
        ddlDeviceType.append('<option value="">-- Select --</option>');
        if (data.DeviceType.length > 0) {
            $.each(data.DeviceType, function () {
                ddlDeviceType.append('<option value="' + this.DeviceTypeId + '">' + this.Description + '</option>');
            });
        }
        $('#installDate').kendoDatePicker({ value: new Date(), parseFormats: ["MM/dd/yyyy"] }).data("kendoDatePicker");
    },
    SetUtilityOnEditPopupLoad: function (data) {
        var _this = this;

        var ddlDeviceType = $('#ddlDeviceType');
        ddlDeviceType.empty();
        ddlDeviceType.append('<option value="">-- Select --</option>');
        if (data.DeviceType.length > 0) {
            $.each(data.DeviceType, function () {
                ddlDeviceType.append('<option value="' + this.DeviceTypeId + '">' + this.Description + '</option>');
            });
            ddlDeviceType.val(data.Utility.DeviceTypeId);
        }
        var _this = this;
        var ddlDeviceModel = $('#ddlDeviceModel');
        ddlDeviceModel.empty();
        ddlDeviceModel.append('<option value="">-- Select --</option>');
        if (data.DeviceModel.length > 0) {
            $.each(data.DeviceModel, function () {
                ddlDeviceModel.append('<option value="' + this.DeviceModelId + '">' + this.Description + '</option>');
            });
            ddlDeviceModel.val(data.Utility.DeviceModelId);
        }
        var ddlDeviceTypetxt = $("#ddlDeviceType option:selected").text().trim();
        var ddlDeviceModeltxt = $("#ddlDeviceModel option:selected").text().trim();
        $('#txtDeviceNoteDesc').val(ddlDeviceTypetxt + " / " + ddlDeviceModeltxt);
    },

    attachEvents: function () {

        $("#tabUtilitiesContainer").addClass("active");
        $("#tabUtilities").parent("li").addClass("active");

        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        //Set allow edit on role level
        _this.allowEdit = (this.data.MaxLevel >= 7);

        //var opts = { language: "sp-SP", pathPrefix: "Miscellaneous/GetLocalizationData" };
        //$("[data-localize]").localize("local", opts);
        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Utility/GetUtility",
                    dataType: "json"
                },
                create: {
                    url: "/api/Utility/CreateUtility",
                    dataType: "json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYADDEDSUCCESSFULLY" class="k-success-message">Device Added Successfully</label>');
                            if (window != null) {
                                window.close();
                                window.element.remove();
                            }
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else {
                            dataSource.cancelChanges();
                            var code = JSON.parse(jqXhr.responseText);
                            if (code == '401') {
                                $("#errorDiv").html('<label data-localize ="FIELD_DEVICEWEEXISTS" class="k-error-message">Device name can not be duplicate for a device type and device model</label>');

                            } else {
                                $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYADDITIONFAILED" class="k-error-message">Device Addition Failed</label>');
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/Utility/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYUPDATEDSUCCESSFULLY" class="k-success-message">Device Updated Successfully</label>');
                            wnd.close();
                            if (grid && grid.dataSource) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        }
                        else {
                            var code = JSON.parse(jqXhr.responseText);
                            if (code == '401') {
                                $("#errorDiv").html('<label data-localize ="FIELD_DEVICEWEEXISTS" class="k-error-message">Device name can not be duplicate for a device type and device model</label>');
                            }
                            else {
                                $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYUPDATIONFAILED" class="k-error-message">Device Updation Failed</label>');
                            }
                            dataSource.cancelChanges();
                            
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Utility/DeleteUtility",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYDELETEDSUCCESSFULLY" class="k-success-message">Device Deleted Successfully</label>');
                        }
                        else {
                            $("#errorDiv").html('<label data-localize ="FIELD_WATERANDENERGYDELETIONFAILED" class="k-error-message">Device Deletion Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                parameterMap: function (data, type) {
                    if (type != "read" && type != "destroy") {
                        data.InstallDate = fixDateFormat(data.InstallDate);
                    }
                    return data;

                }
            },
            requestStart: function (e) {
                var gridUtility = $("#gridUtility");
                gridUtility.data("kendoGrid").hideColumn("Comment");
                gridUtility.data("kendoGrid").hideColumn("DeviceNumber");
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "DeviceNumber",
                    fields: {
                        DeviceNumber: { editable: false, type: "number" },
                        DeviceName: { editable: true, validation: { required: true, validationMessage: "Device Name required" } },
                        DeviceTypeDesc: { editable: false },
                        DeviceModelDesc: { editable: false },
                        InstallDate: { editable: true, validation: { required: true, validationMessage: "Install Date required" } },
                        DeviceNoteDesc: { editable: true },
                        Comment: { editable: true }
                    }
                }
            }
        });
        function fixDateFormat(date) {
            var formatted;
            var setDate = new Date(date);
            if (date != null) {
                formatted = ('0' + (setDate.getMonth() + 1)).slice(-2) + '/'
             + ('0' + setDate.getDate()).slice(-2) + '/'
             + setDate.getFullYear();
            }
            return formatted;
        }

        var addNew, commands, editTitle;
        if (_this.allowEdit) {
            commands = [{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }];
            addNew = [{ text: "<span data-localize='FIELD_ADDWEDEVICE'>Add W&E Device</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
            editTitle = $.GetLocaleKeyValue("FIELD_EDITWEDEVICE", 'Edit W&E Device');
        } else {
            commands = [{ name: "view", text: "", click: showDetails }];
            addNew = "";
            editTitle = $.GetLocaleKeyValue("FIELD_EDITWEDEVICE", 'Edit W&E Device');
        }

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        if (container.find('#gridUtility').data().kendoGrid)
            container.find('#gridUtility').data().kendoGrid.destroy();
        container.find("#gridUtility").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [{ command: commands, width: "90px", attributes: { "class": "align-center" } },
            { field: "DeviceNumber", title: "<span data-localize='FIELD_NUMBER'>Number</span>", headerAttributes: { "class": "align-center" }, attributes: { "class": "align-center" }, width: "10%" },
            { field: "DeviceName", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "16%" },
            { field: "DeviceModelDesc", title: "<span data-localize='FIELD_MODEL'>Model</span>", width: "18%" },
            { field: "DeviceTypeDesc", title: "<span data-localize='FIELD_TYPE'>Type</span>", width: "21%" },
            {
                field: "InstallDate", title: "<span data-localize='FIELD_INSTALLDATE'>Install Date</span>", format: "{0:MM/dd/yyyy}", width: "13%",
                editor: function (container, options) {
                    $('<input data-text-field="' + options.field + '" data-value-field="' + options.field + '" data-bind="value:' + options.field + '" data-format="' + options.format + '"/>')
            .appendTo(container)
            .kendoDatePicker({});
                }
            },
            { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" }, width: "17%" }
            ],
            editable: "inline"
        });
        function onEdit(e) { $("#errorDiv").html(''); }

        wnd = $("#details")
                       .kendoWindow({
                           title: editTitle,
                           modal: true,
                           visible: false,
                           resizable: false,
                           width: "375px",
                           height: "auto",
                           open: onOpen,
                           activate: function (e) {
                               _this.tm.Localize();
                           }
                       }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editUtility").html());
        detailsTemplateView = kendo.template($("#editUtilityView").html());

        //Impliment Cascading population of dropdowns here
        var element;
        function onOpen(e) {
            if (_this.allowEdit) {
                element = wnd.element.find('#txtInstallDate');
                var date = kendo.parseDate(element.val(), "ddd MMM dd yyyy HH:mm:ss 'GMT'");
                element.kendoDatePicker({
                    value: kendo.parseDate(date, "MM/dd/yyyy")
                }).data("kendoDatePicker");

                if (_this.options.eventHandlers.onUtilityEditLoad)
                    _this.options.eventHandlers.onUtilityEditLoad(parseInt($('#txtDeviceNumber').text()));
                $('#ddlDeviceType').change(function () {
                    _this.isEdit = true;
                    if (_this.options.eventHandlers.onloadDeviceModelByDeviceTypeId)
                        _this.options.eventHandlers.onloadDeviceModelByDeviceTypeId($('#ddlDeviceType').val());
                });
                $('#ddlDeviceModel').change(function () {
                    var ddlDeviceType = $("#ddlDeviceType option:selected").text().trim();
                    var ddlDeviceModel = $("#ddlDeviceModel option:selected").text().trim();
                    $('#txtDeviceNoteDescOld').val(ddlDeviceType + " / " + ddlDeviceModel);
                });
            }
        }
        var grid;
        function showDetails(e) {
            $("#errorDiv").html('');
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.DeviceData = _this.deviceData;
            //Set RoleBased editing here
            if (_this.allowEdit) {
                wnd.content(detailsTemplate(dataItem));
            } else {
                wnd.content(detailsTemplateView(dataItem));
            }
            wnd.center().open();
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            $("#errorDiv").html('');
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var Contact = dataSource.get(uid);
                    Contact.set("DeviceNumber", $("#txtDeviceNumber").val().trim());
                    Contact.set("DeviceName", $("#txtDeviceName").val().trim());
                    Contact.set("DeviceTypeId", $("#ddlDeviceType").val().trim());
                    Contact.set("DeviceModelId", $("#ddlDeviceModel").val().trim());
                    Contact.InstallDate = kendo.parseDate($('#txtInstallDate').val(), "MM/dd/yyyy");
                    Contact.set("DeviceNoteDesc", $("#txtDeviceNoteDescOld").val().trim());
                    Contact.set("Comment", $("#txtComment").val().trim());
                });
                grid = $("#gridUtility").data("kendoGrid");
                grid.saveChanges()
                wnd.close();
            }
            else {
                return false;
            }
        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });
        var window;
        $("#gridUtility a.grid-add-new-record").unbind("click");
        $("#gridUtility a.grid-add-new-record").on("click", function (e) {
            $("#errorDiv").html('');
            var dataSource = $("#gridUtility").data("kendoGrid").dataSource;
            window = $("<div id='popupEditor'>")
               .appendTo($("body"))
               .kendoWindow({
                   title: $.GetLocaleKeyValue("FIELD_ADDWEDEVICE", 'Add W&E Device'),
                   modal: true,
                   resizable: false,
                   visible: false,
                   width: "375px",
                   height: "auto",
                   open: onAddNewOpen,
                   close: onClose,
                   content: {
                       //sets window template
                       template: kendo.template($("#newUtility").html())
                   },
                   activate: function (e) {
                       _this.tm.Localize();
                   }
               })
               .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});
            var data = {};
            data.DeviceData = _this.deviceData;
            detailsTemplate1 = kendo.template($("#newUtility").html());
            window.content(detailsTemplate1(data));
            //binds the editing window to the form
            kendo.bind(window.element, model);

            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator")
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    var ddlDeviceTypeAddNew = $("#ddlDeviceTypeAddNew").val().trim();
                    dataSource._data[0].DeviceTypeId = ddlDeviceTypeAddNew;
                    dataSource._data[0].DeviceName = $('#txtDeviceNameAddNew').val().trim();;
                    var ddlDeviceModelAddNew = $("#ddlDeviceModelAddNew").val().trim();
                    dataSource._data[0].DeviceModelId = parseInt(ddlDeviceModelAddNew);
                    dataSource._data[0].Comment = $('#txtCommentAdd').val().trim();
                    dataSource._data[0].DeviceNoteDesc = $('#txtDeviceNoteDesc').val().trim();
                    //dataSource._data[0].InstallDate = kendo.format("{0:MM/dd/yyyy hh:mm:ss tt}", $("#installDate").val());
                    dataSource._data[0].InstallDate = kendo.parseDate($('#installDate').val(), "MM/dd/yyyy");
                    //dataSource.sync(); //sync changes                   
                    grid = $("#gridUtility").data("kendoGrid");
                    grid.saveChanges();
                    window.close();
                    window.element.remove();
                }
                else {
                    return false;
                }
            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                window.close();
                window.element.remove();
            });

            function onAddNewOpen(e) {
                if (_this.options.eventHandlers.onAddNewUtilityPopupLoad)
                    _this.options.eventHandlers.onAddNewUtilityPopupLoad();
            }
            //Cascading data for Device model  basing on device Type
            $('#ddlDeviceTypeAddNew').change(function () {
                _this.isEdit = false;
                if (_this.options.eventHandlers.onloadDeviceModelByDeviceTypeId)
                    _this.options.eventHandlers.onloadDeviceModelByDeviceTypeId($(this).val());
            });
            $('#ddlDeviceModelAddNew').change(function () {
                var ddlDeviceTypeAddNew = $("#ddlDeviceTypeAddNew option:selected").text().trim();
                var ddlDeviceModelAddNew = $("#ddlDeviceModelAddNew option:selected").text().trim();
                $('#txtDeviceNoteDesc').val(ddlDeviceTypeAddNew + " / " + ddlDeviceModelAddNew);
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                window.element.remove();
            }

        });
    }
};