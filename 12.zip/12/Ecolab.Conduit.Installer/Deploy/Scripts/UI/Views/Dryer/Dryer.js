// JavaScript source code
Ecolab.Views.Dryer = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onAddDryerGroupClicked: null,
            onEditDryerGroupClicked: null,
            onDeleteDryerGroupClicked: null,
            onEditDryerClicked: null,
            onDeleteDryerClicked: null,
            onInlineEditDryerLinkClicked: null,
            onInlineEditDryerClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Dryer/Dryer.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.Dryer.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();

        $('.tabDryerGroup').addClass('active');
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#addDryerGroup").click(function () {
            _this.clearStatusMessage();
            _this.onAddDryerGroupClicked();
        });

        container.find(".editDryerGroup").click(function () {
            _this.clearStatusMessage();
            _this.onEditDryerGroupClicked(_this.getDryerGroupData(this));
        });

        container.find(".deleteDryerGroup").click(function () {
            _this.clearStatusMessage();
            var dryerGroupData = _this.getDryerGroupData(this);
            _this.onDeleteDryerGroupClicked($(this).attr('dryer-groupid'), dryerGroupData);
        });

        container.find(".btnAddDryer").click(function () {
            _this.clearStatusMessage();
            _this.onAddDryerClicked($(this).attr('dryer-groupid'), $(this).attr('dryer-desiredunits'));
        });

        container.find(".lnkUpdateDryer").click(function () {
            _this.clearStatusMessage();
            _this.onEditDryerClicked(_this.getDryerData(this));
        });

        container.find(".lnkDeleteDryer").click(function () {
            _this.clearStatusMessage();
            var dryerData = _this.getDryerData(this);
            _this.onDeleteDryerClicked($(this).attr('dryer-id'), dryerData);
        });

        container.find(".editDryerInline").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            var dryerData = _this.getDryerData(this);
            _this.onInlineEditDryerLinkClicked(this, dryerData);
        });

        container.find(".updateDryerInline").click(function () {
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate() == true) {
                _this.isDirty = false;
                _this.onSaveTrClicked(this, tr);
            } else {
                return false;
            }
        });

        container.find(".cancelDryerInline").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            $(this).parents('.trEditable').first().removeClass('dirty');
        });

    },
    onSaveTrClicked: function (e,tr) {
        var _this = this;
        _this.clearStatusMessage();
        //var tr = $('.table-striped').find('dirty');
       // if (_this.validate()) {
            var dryerData = _this.getInlineDryerData(e, tr);
            _this.onInlineEditDryerClicked(dryerData);
        //}
    },
    showEditOnInlineEditLink: function (e, dryerTypes, data) {
        var tr = $(e).parents('.trEditable').first();
        var ddlType = $(tr).find('.ddlType');
        ddlType.empty();
        ddlType.append('<option value="">-- Select --</option>');
        $.each(dryerTypes, function () {
            ddlType.append('<option value="' + this.Id + '">' + this.Name + '</option>');
        });

        $(tr).find('.txtName').val(data.Name),
            $(tr).find('.txtNominalload').val(data.Nominalload),
            ddlType.val(data.DryerTypeId);
        tr.find(".noneditable").hide();
        tr.find(".editable").show();
    },
    inlineEditFailed: function () {
        $('dryerErrorMsgDiv').html('Update failed');
    },
    getInlineDryerData: function (ele, tr) {
        return {
            GroupId: $(ele).attr('dryer-groupid'),
            Id: $(ele).attr('dryer-id'),
            Number: $(tr).find('.txtNumber').val(),
            Name: $(tr).find('.txtName').val(),
            Nominalload: $(tr).find('.txtNominalload').val(),
            DryerType: {
                Id: $(tr).find('.ddlType').val()
            }
        };
    },
    showSucessMessage: function (message) {
        var _this = this;
        var messageDiv = $("#dryerErrorMsgDiv");
        messageDiv.html(message);
    },
    showErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#dryerErrorMsg");
        messageDiv.html(message);
    },
    showHomePageErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#dryerErrorMsgDiv");
        messageDiv.html(message);
    },
    getDryerGroupData: function (element) {
        return {
            DryerGroupId: $(element).attr('dryer-groupid'),
            DryerGroupName: $(element).attr('dryer-groupname')
        };
    },
    getDryerData: function (element) {
        return {
            GroupId: $(element).attr('dryer-groupid'),
            Id: $(element).attr('dryer-id'),
            Number: $(element).attr('dryer-number'),
            Name: $(element).attr('dryer-name'),
            Nominalload: $(element).attr('dryer-nominalload'),
            DesiredUnits: $(element).attr('dryer-desiredUnits'),
            DryerTypeId: $(element).attr('dryer-type')
        };
    },
    onAddDryerGroupClicked: function () {
        if (this.options.eventHandlers.onAddDryerGroupClicked)
            this.options.eventHandlers.onAddDryerGroupClicked();
    },
    onEditDryerGroupClicked: function (data) {
        if (this.options.eventHandlers.onEditDryerGroupClicked)
            this.options.eventHandlers.onEditDryerGroupClicked(data);
    },
    onDeleteDryerGroupClicked: function (id, dryerGroupData) {
        if (this.options.eventHandlers.onDeleteDryerGroupClicked)
            this.options.eventHandlers.onDeleteDryerGroupClicked(id, dryerGroupData);
    },
    onAddDryerClicked: function (id,units) {
        if (this.options.eventHandlers.onAddDryerClicked)
            this.options.eventHandlers.onAddDryerClicked(id,units);
    },
    onEditDryerClicked: function (data) {
        if (this.options.eventHandlers.onEditDryerClicked)
            this.options.eventHandlers.onEditDryerClicked(data);
    },
    onDeleteDryerClicked: function (id, dryerData) {
        if (this.options.eventHandlers.onDeleteDryerClicked)
            this.options.eventHandlers.onDeleteDryerClicked(id, dryerData);
    },
    onInlineEditDryerClicked: function (data) {
        if (this.options.eventHandlers.onInlineEditDryerClicked)
            this.options.eventHandlers.onInlineEditDryerClicked(data, true);
    },
    onInlineEditDryerLinkClicked: function (e, data) {
        if (this.options.eventHandlers.onInlineEditDryerLinkClicked)
            this.options.eventHandlers.onInlineEditDryerLinkClicked(e, data);
    },
    validate: function () {
        _this = this;
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;
        var numberPattern = '^[0-9]*$';
        $.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                var check = false;
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "*"
        );

        var v1 = container.find('#frmDryer').validate({
            rules: {
                txtNumber: {
                    required: true,
                    regex: numberPattern
                },
                txtName: {
                    required: true,
                },
                txtNominalload: {
                    required: true,
                    regex: decimalPattern
                },
                ddlDryerType: {
                    required: function () {
                        if ($('#ddlDryerType').val() == "Select") {
                            return false;
                        }
                        return true;
                    }
                }
            },
            messages: {
                txtNumber: {
                    required: "*",
                    regex: "*"
                },
                txtName: {
                    required: "*"
                },
                txtNominalload: {
                    required: "*",
                    regex: "*"
                },
                ddlDryerType: {
                    required: "*"
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmDryer').valid();
        return v2;
    },
    clearStatusMessage: function () {
        $("#dryerErrorMsgDiv").html('');
    }
};