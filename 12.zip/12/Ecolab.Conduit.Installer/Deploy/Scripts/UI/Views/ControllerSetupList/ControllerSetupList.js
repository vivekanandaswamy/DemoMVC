﻿Ecolab.Views.ControllerSetupList = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { },
            onRedirection: function () { },
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/ControllerSetupList/ControllerSetupList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
};

Ecolab.Views.ControllerSetupList.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');
        
    },
    localize: function (cache) {
        //var opts = { language: "en-EN", pathPrefix: "Miscellaneous/GetLocalizationData" };
        //  $("[data-localize]").localize("local", opts);
    },
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel != 6);
        _this.RegionId = (this.data.RegionId);
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        // main - menu - item - ControllerSetupLists

        container.find('#btnControllerSetupListPrint').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection(_this.data.PrintAction + "?page=" + _this.data.PageName);
            return retVal;
        });

        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/ControllerSetup/GetControllerDetails",
                    dataType: "json"
                },
                update: {
                    url: "/api/ControllerSetup/UpdateControllerDetails",
                    dataType: "json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {

                        if (textStatus == 'success') {

                            $("#gridControllerSetupList").data("kendoGrid").dataSource._destroyed = [];
                            $("#gridControllerSetupList").data("kendoGrid").dataSource.read();
                            $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERUPDATEDSUCCESSFULLY" class="k-success-message">Controller Updated Successfully</label>');
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERUPDATIONFAILED" class="k-error-message">Controller Updation Failed</label>');
                            $('#gridControllerSetupList').data('kendoGrid').refresh();
                        }
                        _this.localize();
                    }
                },

                destroy: {
                    url: "/api/ControllerSetup/DeleteController",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERDELETEDSUCCESSFULLY" class="k-success-message">Controller Deleted Successfully</label>');
                            $('#gridControllerSetupList').data('kendoGrid').refresh();
                            _this.options.eventHandlers.loadNavigationMenuListView();
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERDELETIONFAILED" class="k-error-message">Controller Deletion Failed</label>');
                            $('#gridControllerSetupList').data('kendoGrid').refresh();
                        }
                        _this.localize();
                    }
                },
                complete: function () {

                },
            },



            pageSize: 12,
            schema: {
                model: {
                    id: "ControllerId", // needed in edit button
                    fields: {
                        ControllerId: { editable: false, type: "number" },
                        ControllerTypeId: { editable: false, type: "number" },
                        ControllerNumber: { editable: false },
                        ControllerType: { editable: false },
                        ControllerModelName: { editable: false },
                        ControllerVersion: { editable: false },
                        InstallDateAsString: { editable: true }
                    }
                }
            }

        });
        var addNew;
        if (_this.allowEdit && this.data.MaxLevel !=8) {
            Command = [{ name: "edit", text: { edit: "", cancel: "", update: "", click: onEdit } }, { name: "destroy", text: " ", click: onEdit }, { name: "update", text: "", click: newWindow }];

        }
        else if (_this.allowEdit && this.data.MaxLevel ==8) {
            addNew = [{ text: "Add Controller", className: "btn btn-sm btn-primary grid-add-new-record" }];
            Command = [{ name: "edit", text: { edit: "", cancel: "", update: "", click: onEdit } }, { name: "destroy", text: " ", click: onEdit }, { name: "update", text: "", click: newWindow }];
        }
        else {
            Command = [{ name: "view", text: "", click: newWindow }];
        }
        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.localize();
        }
        function clearStatusMessage() {
            $("#controllerErrorDiv").html('');
        }
        function onEdit() { clearStatusMessage(); }
        if (container.find('#gridControllerSetupList').data().kendoGrid)
            container.find('#gridControllerSetupList').data().kendoGrid.destroy();

        container.find("#gridControllerSetupList").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable:true,
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                {command: Command, attributes: { "class": "align-center" }, width: "78px"},
                { field: "ControllerNumber", title: "Number", headerAttributes: { "data-localize": "FIELD_CONTROLLER_ControllerNumber", "class": "align-center" }, attributes: { "class": "align-center" }, width: "100px" },
                { field: "ControllerModelName", title: "Model", headerAttributes: { "data-localize": "FIELD_CONTROLLER_ControllerModel" }, width: "180px" },
                { field: "ControllerType", title: "Type", headerAttributes: { "data-localize": "FIELD_CONTROLLERTYPE" }, width: "150px" },
                { field: "InstallDateAsString", title: "Install Date", headerAttributes: { "data-localize": "FIELD_CONTROLLER_InstallDate" }, editor: dateTimeEditor, width: "160px" },
                { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" } }
            ],
            editable: "inline"

        });

        $("#gridControllerSetupList a.grid-add-new-record").unbind("click");
        $("#gridControllerSetupList a.grid-add-new-record").on("click", function (e) {

            window.location.href = "./ControllerSetup";
        });


        function newWindow(e) {
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            var controllerId = dataItem.ControllerId;
            var controllerTypeId = dataItem.ControllerTypeId;
            var controllerModelId = dataItem.ControllerModelId;
            window.location.href = "./ControllerSetup" + '?ControllerId=' + controllerId + '&ControllerTypeId=' + controllerTypeId + '&ControllerModelId=' + controllerModelId;
        }


        function dateTimeEditor(container, options) {

            var dtPicker = $('<input name="' + options.field + '"/>').appendTo(container)
            dtPicker.kendoDatePicker({
                        format: "dd/MM/yyyy",
                        parseFormats: ["dd/MM/yyyy"]

            });

            dtPicker.prop("readonly", true);

        }


}



};