﻿Ecolab.Views.PlantUtilitySetup = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onSaveClicked: null,
            onCancelClicked: null,
            onRedirection: function () { },
            savePage: function () { },
            onCancelPage: function () { },
            getEnergyContent: function () { }
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'PlantUtilitySetup',
        templateUri: './Scripts/UI/Views/PlantUtilitySetup/PlantUtilitySetup.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    //this.isDirty = true;


};
Ecolab.Views.PlantUtilitySetup.prototype = {
    setData: function (data) {
        this.utilData = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    /******************************************************************************************
    Event handling
    ******************************************************************************************/

    onRendered: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('select').kendoDropDownList();
        container.find("#chkSteam").kendoMobileSwitch({
            onLabel: "YES", offLabel: "NO",
            change: function () {
               // _this.isDirty = true;
                container.find('#btnSave').removeAttr('disabled');
                container.find('#btnCancel').removeAttr('disabled');
            }
        });
      
        this.showHideControlByRegion();
        this.attachEvents();       
    },
    showHideControlByRegion: function () {
        var container = $(this.options.containerSelector);
        if (this.options.accountInfo.RegionId == 1) // NA
        {
            container.find("[data-factor='ColdSoft'],[data-factor='HotSoft'],[data-factor='HotHard'],[data-factor='ColdHard']").hide();
        }
        if (this.options.accountInfo.RegionId == 2) // Europe
        {
            container.find("[data-factor='Cold'],[data-factor='Hot']").hide();
        }
    },
    regionValidate: function () {
        required: true;
        digits: true;
    },
    validate: function () {
        var v1 = $('#frmUtility').validate({
            rules: {

                txtColdSoftTemp: { required: true, number: true, greaterThanZero: true },
                txtColdSoftPrice: { required: true, number: true, greaterThanZero: true },
                txtColdHardTemp: { required: true, number: true, greaterThanZero: true },
                txtColdHardPrice: { required: true, number: true, greaterThanZero: true },
                txtHotSoftTemp: { required: true, number: true, greaterThanZero: true },
                txtHotSoftPrice: { required: true, number: true, greaterThanZero: true },
                txtHotHardTemp: { required: true, number: true, greaterThanZero: true },
                txtHotHardPrice: { required: true, number: true, greaterThanZero: true },

                txtColdTemp: { required: true, number: true, greaterThanZero: true },
                txtColdPrice: { required: true, number: true, greaterThanZero: true },
                txtHotTemp: { required: true, number: true, greaterThanZero: true },
                txtHotPrice: { required: true, number: true, greaterThanZero: true },
                txtTemperedTemp: { required: true, number: true, greaterThanZero: true },
                txtTemperedPrice: { required: true, number: true, greaterThanZero: true },
                txtWastePrice: { required: true, number: true, greaterThanZero: true },
                txtFreeWater1Temp: { required: true, number: true, greaterThanZero: true },
                txtFreeWater1Price: { required: true, number: true, greaterThanZero: true },
                txtFreeWater2Temp: { required: true, number: true, greaterThanZero: true },
                txtFreeWater2Price: { required: true, number: true, greaterThanZero: true },
                txtFreeWater3Temp: { required: true, number: true, greaterThanZero: true },
                txtFreeWater3Price: { required: true, number: true, greaterThanZero: true },
                txtEnergy: { required: true, number: true, greaterThanZero: true },
                txtGasPrice: { required: true, number: true, greaterThanZero: true },
                txtElectricityTarrif: { required: true, number: true, greaterThanZero: true },
                txtRewashFactor: { required: true, number: true, greaterThanZero: true },
                txtSteamPercentage: { required: true, number: true, greaterThanZero: true },
                txtBoilerPercentage: { required: true, number: true, greaterThanZero: true },
                txtStackPercentage: { required: true, number: true, greaterThanZero: true },
                txtEvaporationFactor: { required: true, number: true, greaterThanZero: true },
                ddlGasType: { required: true}
            //$("#ddlGasType option:not(.empty):selected").text()
            },
            messages: {
                //Europe location start
                txtColdSoftTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASEENTERCOLDSOFTTEMPERATURE", "Please enter Cold Soft Temperature") },
                txtColdSoftPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHECOLDSOFTPRICE", "Please enter the Cold Soft Price")},
                txtColdHardTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHECOLDHARDTEMPERATURE", "Please enter the Cold Hard Temperature")},
                txtColdHardPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTSOFTPRICE", "Please enter the Hot Soft Price") },
                txtHotSoftTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTSOFTTEMPERATURE", "Please enter the Hot Soft Temperature") },
                txtHotSoftPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTSOFTPRICE", "Please enter the Hot Soft Price")},
                txtHotHardTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTHARDTEMPERATURE", "Please enter the Hot Hard Temperature") },
                txtHotHardPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTHARDPRICE", "Please enter the Hot Hard Price") },
                //Europe location end

                //NA location start
                txtColdTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHECOLDTEMPERATURE", "Please enter the Cold Temperature") },
                txtColdPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHECOLDPRICE", "Please enter the Cold Price") },
                txtHotTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTTEMPERATURE", "Please enter the Hot Temperature") },
                txtHotPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEHOTPRICE", "Please enter the Hot Price") },
                // NA location end

                txtTemperedTemp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHETEMPEREDTEMPERATURE", "Please enter the Tempered Temperature") },
                txtTemperedPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHETEMPEREDPRICE", "Please enter the Tempered Price") },
                txtWastePrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEWASTEWATERPRICE", "Please enter the Waste Water Price") },
                txtFreeWater1Temp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE1TEMPERATURE", "Please enter the Free1 Temperature") },
                txtFreeWater1Price: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE1PRICE", "Please enter the Free1 Price") },
                txtFreeWater2Temp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE2TEMPERATURE", "Please enter the Free2 Temperature") },
                txtFreeWater2Price: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE2PRICE", "Please enter the Free2 Price") },
                txtFreeWater3Temp: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE3TEMPERATURE", "Please enter the Free3 Temperature") },
                txtFreeWater3Price: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEFREE3PRICE", "Please enter the Free3 Price") },
                txtEnergy: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEENERGY", "Please enter the Energy") },
                txtGasPrice: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEGASOILPRICE", "Please enter the Gas/Oil Price") },
                txtElectricityTarrif: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEELECTRICTARIFF", "Please enter the Electric Tarriff") },
                txtRewashFactor: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEREWASHFACTOR", "Please enter the Rewash Factor") },
                txtSteamPercentage: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHESTEAMPERCENTAGE", "Please enter the Steam Percentage") },
                txtBoilerPercentage: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEBOILERPERCENTAGE", "Please enter the Boiler Percentage") },
                txtStackPercentage: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHESTACKPERCENTAGE", "Please enter the Stack Percentage") },
                txtEvaporationFactor:{required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEEVAPORATIONFACTOR", "Please enter the Evaporation Factor")},
                ddlGasType: { required: $.GetLocaleKeyValue("FIELD_PLEASENTERTHEGASOILTYPE", "Please select Gas/Oil type") }

            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().next("span.k-error-message"));
                }
            }
        });

        var v2 = $('#frmUtility').valid();
        if ($("#ddlGasType").val() == "") {
            $('#spanGasType').text('Please select Gas/Oil type');
            v2 = false;
            return v2;
        }
        else {
            return v2;
        }
            
        
    },
    resetErrors: function () {
        var container = $(this.options.containerSelector);
        container.find("span.error").text("");
        container.find('#errorCon').hide();
    },
    verifyChanges: function (isRedirect) {
        var retVal = this.options.eventHandlers.onRedirection('./Home');
        return retVal;
    },
    saveChanges: function (isRedirect) {
        var _this = this;
        _this.onSaveClicked($(this).parent().attr('ruleId'), isRedirect);
    },
    attachEvents: function () {
        $("#tabUtilitiesContainer, #tabUtilitiesSetupContainer").addClass("active");
        $("#tabUtilitySetup").parent("li").addClass("active");
        $("#tabUtilities").parent("li").addClass("active");
        var _this = this;
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.utilData != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.utilData.accountInfo.SelectedMenuItem).addClass('active');

        var container = $(this.options.containerSelector);
        $('#tabUtilitySetup').click(function () {
            return _this.options.eventHandlers.onRedirection('/PlantUtilitySetup');
        });
        $('#btnCancel').click(function () { _this.onCancelClicked(); });
        $('#ddlGasType').change(function () {
            if ($("#ddlGasType").val() != "") {
                $('#spanGasType').hide();
                _this.getEnergyContent($("#ddlGasType").val());
            }
            else if ($("#ddlGasType").val() == "") {
                $('#spanGasType').show();
                $("#txtEnergy").val('');
                $("#spanEnergyContentUnit").text('');
            }

        });
        container.find('#btnSave').unbind("click");
        container.find('#btnSave').click(function () {
            _this.saveChanges();
        });
    },
    onSaveClicked: function (id, isRedirect) {
        var _this = this;
        window.localeData = '';
        this.options.eventHandlers.onSavePage();
    },
    getData: function () {
        var container = $(this.options.containerSelector);
        var plantUtility = {
            ColdTemp: container.find("#txtColdTemp").val(),
            ColdPrice: container.find("#txtColdPrice").val(),
            HotTemp: container.find("#txtHotTemp").val(),
            HotPrice: container.find("#txtHotPrice").val(),
            TemperedTemp: container.find("#txtTemperedTemp").val(),
            TemperedPrice: container.find("#txtTemperedPrice").val(),
            WasteWaterPrice: container.find("#txtWastePrice").val(),
            Free1Temp: container.find("#txtFreeWater1Temp").val(),
            Free1Price: container.find("#txtFreeWater1Price").val(),
            Free2Temp: container.find("#txtFreeWater2Temp").val(),
            Free2Price: container.find("#txtFreeWater2Price").val(),
            Free3Temp: container.find("#txtFreeWater3Temp").val(),
            Free3Price: container.find("#txtFreeWater3Price").val(),
            Energy: container.find("#txtEnergy").val(),
            GasPrice: container.find("#txtGasPrice").val(),
            ElectricityTarrif: container.find("#txtElectricityTarrif").val(),
            RewashFactor: container.find("#txtRewashFactor").val(),
            BoilerSteam: this.getSwitchValue(),
            BoilerType: $('#boilerType option:selected').val(),
            SteamPercentage: container.find("#txtSteamPercentage").val(),
            BoilerPercentage: container.find("#txtBoilerPercentage").val(),
            StackPercentage: container.find("#txtStackPercentage").val(),
            ColdSoftTemp: container.find("#txtColdSoftTemp").val(),
            ColdSoftPrice: container.find("#txtColdSoftPrice").val(),
            ColdHardTemp: container.find("#txtColdHardTemp").val(),
            ColdHardPrice: container.find("#txtColdHardPrice").val(),
            HotSoftTemp: container.find("#txtHotSoftTemp").val(),
            HotSoftPrice: container.find("#txtHotSoftPrice").val(),
            HotHardTemp: container.find("#txtHotHardTemp").val(),
            HotHardPrice: container.find("#txtHotHardPrice").val(),
            Free1FactorType: $("#ddlFreeWater1 option:not(.empty):selected").text(),
            Free2FactorType: $("#ddlFreeWater2 option:not(.empty):selected").text(),
            Free3FactorType: $("#ddlFreeWater3 option:not(.empty):selected").text(),
            GasOilType: $("#ddlGasType option:not(.empty):selected").text(),
            EnergyContentUnit: $("#spanEnergyContentUnit").text(),
            EnergyPriceUnit: $("#ddlEnergyPriceUnit option:not(.empty):selected").text(),
            EvaporationFactor: $("#txtEvaporationFactor").val()
        };
        return plantUtility;
    },
    getSwitchValue:function(){
        var switchSteam = $("#chkSteam").data("kendoMobileSwitch");
        var checked = switchSteam.check();
        return checked;
    },
    onCancelClicked: function () {
        
        var _this = this;
        _this.verifyChanges();
        //this.options.eventHandlers.onCancelPage();
    },
    getEnergyContent: function (gasTypeId) {
        this.options.eventHandlers.getEnergyContent(gasTypeId);
    },
    setEnergydata: function (data) {
        if (data != null) {
            $("#txtEnergy").val(data.defaultValue);
            $("#spanEnergyContentUnit").text(data.uomCode);
        }

    }
};

// custom code to for greater than

jQuery.validator.addMethod("greaterThanZero", function (value, element) {
    //    var field = element.id.replace('txt', '');
    return this.optional(element) || (parseFloat(value) > 0);
}, $.GetLocaleKeyValue("FIELD_VALUESHOULDBEGREATERTHANZERO", "Value should be greater than zero"));

jQuery.validator.addMethod("defaultValue", function (value, element, param) {
    
    return this.optional(element) || value !== param;
}, $.GetLocaleKeyValue("FIELD_PLEASCHOOSEAVALUE", "Please choose a value"));