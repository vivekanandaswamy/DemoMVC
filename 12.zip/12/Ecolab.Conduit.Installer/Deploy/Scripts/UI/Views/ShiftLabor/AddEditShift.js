﻿Ecolab.Views.AddEditShift = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onCancelClicked: null,
            onSaveClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    var index = null;
    this.tm = new TemplateManager({
        templateName: 'AddEditShift',
        templateUri: './Scripts/UI/Views/ShiftLabor/AddEditShift.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
    this.initValidate();
};
Ecolab.Views.AddEditShift.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find("#btnUpdate").click(function () { _this.onSaveClicked(); })
        container.find("#btnCancel").click(function (e) { _this.onCancelClicked(e); })
        container.find("#addBreak").click(function () { _this.addBreak(); });
        $(".deleteBreakEdit").die('click');
        $(".deleteBreakEdit").live('click', function () {
            if (window.confirm($.GetLocaleKeyValue("FIELD_AREYOUSUREYPUWANTTODELETETHISBREAK", "Are you sure you want to delete this break?"))) {
                if (this.parentElement.attributes["data-shiftid"].value > 0) {
                    this.parentElement.attributes["data-isdeleted"].value = true;
                    this.parentElement.style.display = "none";
                }
                else
                    $(this).parents('.divBreaksContainer').first().remove();
            }
        });
        $('.datetimepicker').datetimepicker({
            pickDate: false,
            change: function () {
            }
        });
        //This code is ti hide other datetimepickers on open
        $('.datetimepicker').live('dp.show', function () {
            var _cal = this;
            container.find('.datetimepicker').each(function () {
                if (this !== _cal) {
                    $(this).data("DateTimePicker").hide()
                }
            });
        });

        $('.datetimepicker').live('dp.change', function (e) {
            var frmElem = $(this).parents('.divBreaksContainer').first().find('.fromTime');
            if ($(frmElem).hasClass('fromBreak')) {
                var elem = $(this).parents('.divBreaksContainer').first().find('.toTime');
                elem.val(new Date("01/01/001 " + $(frmElem).val()).add('m', 15).format('hh:mm a'));
            }
        });

        container.find('input[type="checkbox"].chkDays').change(function (e) {
            $(this).parent()
                    .toggleClass("btn-default")
                    .toggleClass("btn-primary");
        });

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getShiftData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var shiftModel = {};
        var breakArr = [];
        for (var i = 0; i < container.find("input.checkBreak").length ; i++) {
            var breakData = {};
            breakData.StartTime = container.find("input.checkBreak")[i].value;
            breakData.EndTime = container.find("input.checkBreak")[++i].value;
            breakData.BreakId = container.find("input.checkBreak")[i].parentElement.parentElement.parentElement.attributes["data-breakid"].value;
            //breakData.ShiftId = container.find("input.checkBreak")[i].parentElement.attributes["data-shiftid"].value;
            //breakData.DayId = container.find("input.checkBreak")[i].parentElement.attributes["data-dayid"].value;
            breakData.ShiftId = container.find("#shiftName")[0].parentElement.attributes["data-shiftid"].value;
            breakData.DayId = container.find("#shiftName")[0].parentElement.attributes["data-dayid"].value;
            breakData.IsDeleted = container.find("input.checkBreak")[i].parentElement.parentElement.parentElement.attributes["data-isdeleted"].value;
            breakArr.push(breakData);
        }
        shiftModel.ShiftBreaks = breakArr;
        shiftModel.DayId = container.find("#shiftName")[0].parentElement.attributes["data-dayid"].value;
        shiftModel.ShiftId = container.find("#shiftName")[0].parentElement.attributes["data-shiftid"].value;
        shiftModel.ShiftName = container.find("#shiftName").val();
        shiftModel.StartTime = container.find("#timepickerShiftfromtime").val();
        shiftModel.EndTime = container.find("#timepickerShifttotime").val();
        shiftModel.TargetProduction = container.find("#targetProduction").val();
        //for editing these fields will be unavailable
        if (shiftModel.ShiftId == 0) {
            shiftModel.IsMonday = container.find("#cbMonday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsTuesday = container.find("#cbTueday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsWednesday = container.find("#cbWedday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsThursday = container.find("#cbThuday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsFriday = container.find("#cbFriday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsSaturday = container.find("#cbSatday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
            shiftModel.IsSunday = container.find("#cbSunday")[0].parentElement.className.indexOf('active') > 0 ? true : false;
        }
        else {
            switch (parseInt(container.find("#shiftName")[0].parentElement.attributes["data-dayid"].value)) {
                case 1:
                    shiftModel.IsSunday = true;
                    break;
                case 2:
                    shiftModel.IsMonday = true;
                    break;
                case 3:
                    shiftModel.IsTuesday = true;
                    break;
                case 4:
                    shiftModel.IsWednesday = true;
                    break;
                case 5:
                    shiftModel.IsThursday = true;
                    break;
                case 6:
                    shiftModel.IsFriday = true;
                    break;
                case 7:
                    shiftModel.IsSaturday = true;
                    break;
            }
        }
        return shiftModel;
    },
    ConvertTODate: function (time) {
        return new Date('01/01/2001 ' + time + ' /');
    },
    initValidate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        //Validation for Target production
        var pattern1 = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               $.GetLocaleKeyValue("FIELD_PLEASECHECKYOURINPUT", "Please check your input.")
       );

        //validation for breaks
        $.validator.addMethod("breakValidator", function (value, element) {
            var shiftStartTime = _this.ConvertTODate(container.find("#timepickerShiftfromtime").val());
            var shiftEndTime = _this.ConvertTODate(container.find("#timepickerShifttotime").val());
            var breakStartTime = _this.ConvertTODate(value);
            var breakEndTime = _this.ConvertTODate(element.nextElementSibling.value);
            container.find(".addEditPopupContainer").find('input').css('border-color', '');
            var status = true;
            container.find(".divBreaksContainer").each(function () {
                var _currentDiv = this;
                if (this.attributes["data-isdeleted"].value == "false") {
                    var frTime = _this.ConvertTODate($(this).find('.fromTime').val());
                    var toTime = _this.ConvertTODate($(this).find('.toTime').val());

                    if (!frTime.isBetween(shiftStartTime, shiftEndTime)) {
                        status = false;
                    }
                    else if (!toTime.isBetween(shiftStartTime, shiftEndTime)) {
                        status = false;
                    } else if (frTime.isAfter(toTime)) {
                        status = false;
                    }

                    if (!status) {
                        // $(_currentDiv).find('input').css('border-color', 'red');
                        $('#errorMsgBreaks').html('Breaks overlapping');
                        return false;
                    } else {
                        //$(_currentDiv).find('input').css('border-color', '');
                        $('#errorMsgBreaks').empty();
                    }
                }
            });

            if (!status) {
                // alert('failed top');
                return false;
            }

            container.find(".divBreaksContainer").each(function () {
                var _parent = this;
                var parentFrTime = _this.ConvertTODate($(_parent).find('.fromTime').val());
                var parentToTime = _this.ConvertTODate($(_parent).find('.toTime').val());
                container.find(".divBreaksContainer").each(function () {
                    var _child = this;
                    if (this !== _parent) {
                        if (this.attributes["data-isdeleted"].value == "false") {
                            var frTime = _this.ConvertTODate($(_child).find('.fromTime').val());
                            var toTime = _this.ConvertTODate($(_child).find('.toTime').val());

                            if (frTime.isBetween(parentFrTime, parentToTime)) {
                                status = false;
                            }
                            else if (toTime.isBetween(parentFrTime, parentToTime)) {
                                status = false;
                            }
                            if (!status) {
                                //$(_child).find('input').css('border-color', 'red');
                                $('#errorMsgBreaks').html('Breaks overlapping');
                                return false;
                            } else {
                                //$(_child).find('input').css('border-color', '');
                                $('#errorMsgBreaks').empty();
                            }
                        }
                    }
                });
            });

            if (!status) {
                //alert('failed bottom');
                return false;
            }
            return true;
        },
               $.GetLocaleKeyValue("FIELD_ALREADYEXISTS", "Overlapping Shift breaks.")
       );
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        //Validation for Target production
        var pattern1 = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;
        var v1 = container.find('#frmAddEditLabor').validate({
            rules: {
                chkDay: {
                    required: true,
                },
                ShiftName: {
                    required: true,
                },
                targetProduction: {
                    required: true,
                    regex: pattern1
                },
                timepickerShiftfromtime: {
                    required: function () {
                        if ($('#timepickerShiftfromtime').val() == "") {
                            $('#timepickerShiftfromtime').css('border-color', 'red');
                            return false;
                        }
                        else {
                            $('#timepickerShiftfromtime').css('border-color', '');
                            return true;
                        }
                    }
                },
                timepickerShifttotime: {
                    required: function () {
                        if ($('#timepickerShifttotime').val() == "") {
                            $('#timepickerShifttotime').css('border-color', 'red');
                            return false;
                        }
                        else {
                            $('#timepickerShifttotime').css('border-color', '');
                            return true;
                        }
                    }
                },
            },
            messages: {
                chkDay: {
                    required: $.GetLocaleKeyValue("FIELD_ONEOPTIONPLEASE", "One Option please")
                },
                ShiftName: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERSHIFTNAME", "Please enter Shift Name"),
                },
                targetProduction: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERTARGETPRODUCTION", "Please enter Target Production"),
                    regex: $.GetLocaleKeyValue("FIELD_ENTERONLYNUMBERS", "Enter only numbers")
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
                if (element.hasClass('chkDays'))
                    error.appendTo(element.parents('.dayscheckbox').find("span.errorMsg"));
                if (element.hasClass('recordingValue')) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }

            }
        });
        container.find(".checkBreak").each(function () {
            $(this).rules('add', {
                required: true,
                breakValidator: true
            });
        });
        //container.find(".chkDays").each(function () {
        //    $(this).rules('add', {
        //        required: function () {
        //            return container.find(".chkDays").is(':checked');
        //        },
        //        messages: "Please select day"
        //    });
        //});

        var v2 = container.find('#frmAddEditLabor').valid();
        return v2;
    },

    onCancelClicked: function () {
        if (this.options.eventHandlers.onCancelClicked) {
            this.options.eventHandlers.onCancelClicked();
        }
    },
    checkDays: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        if (container.find("#shiftName").parent().attr("data-shiftid") != "0") {
            return true;
        }
        else {
            return container.find(".chkDays").parent().hasClass('active');
        }
    },
    onSaveClicked: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        if (_this.checkDays()) {
            container.find('#errorDivLabor').html('');
            if (this.options.eventHandlers.onSaveClicked) {
                if (_this.validate() == true) {
                    _this.isDirty = false;
                    this.options.eventHandlers.onSaveClicked(_this.getShiftData());
                } else {
                    return false;
                }
            }
        }
        else {
            container.find('#errorDivLabor').html('<label data-localize ="FIELD_SHIFTOVERLAPPINGWITH" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_ONEOPTIONPLEASE", "One Option please") + '</label>');
        }
    },
    showErrorMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var messageDiv = $("#errorDivLabor");
        messageDiv.html('<label data-localize ="FIELD_SHIFTOVERLAPPINGWITH" class="k-error-message">' + message + '</label>');
    },
    showSuccessMessage: function () {

    },
    showShiftSucessMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var messageDiv = $("#errorDivLabor");
        messageDiv.html('<label data-localize ="FIELD_SHIFTBREAKDELETEDSUCCESSFULLY" class="k-success-message">' + message + '</label>');
    },

    addBreak: function () {
        var container = $(this.options.containerSelector);

        var divElement = "<div data-container-for='ShiftTime' class='k-edit-field input-append bootstrap-timepicker trackChange divBreaksContainer' data-breakid='0' data-shiftid='0' data-dayid='0'  data-isdeleted='false'>" +
            "<div class='form-group col-sm-6'>" +
            " <div class='input-group date datetimepicker'>" +
                               "<input id='timepickerBreakfromtime' name='timepickerBreakfromtime' value='12:00 AM' style='font-weight:normal' class='form-control k-input k-textbox checkBreak fromTime fromBreak' />" +
                               "<span class='input-group-addon'>" +
                                   "<span class='glyphicon glyphicon-time'></span>" +
                               "</span>" +
        "</div>" +
        "</div>" +
    "<div class='form-group col-sm-6'>" +
            "<div class='input-group date datetimepicker'>" +
                           "<input id='timepickerBreaktotime' name='timepickerBreaktotime' value='12:00 AM' style='font-weight:normal' class='form-control k-input k-textbox checkBreak toTime toBreak' />" +
                "<span class='input-group-addon'>" +
                    "<span class='glyphicon glyphicon-time'></span>" +
                "</span> </div>" +
            "</div>" +
            "<span id='deleteBreakEdit' href='javascript:void(0);' class='k-icon k-delete k-margin-top trackChange deleteBreakEdit'></span>" +
           "</div>";
        $(divElement).insertBefore(container.find("#addBreak").parent());
        container.find('.datetimepicker').datetimepicker({
            pickDate: false
        });

    },
}