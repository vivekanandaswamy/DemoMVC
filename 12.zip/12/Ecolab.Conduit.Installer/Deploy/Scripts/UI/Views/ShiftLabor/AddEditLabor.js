﻿Ecolab.Views.AddEditLabor = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onCancelClicked: null,
            onLaborSaveClicked: null,
            onLaborTypeChanged: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    var index = null;
    this.tm = new TemplateManager({
        templateName: 'AddEditLabor',
        templateUri: './Scripts/UI/Views/ShiftLabor/AddEditLabor.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
    //Add dropdown variables
};
Ecolab.Views.AddEditLabor.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find("#btnLaborUpdate").click(function () { _this.onSaveClicked(); })
        container.find("#btnCancel").click(function (e) { _this.onCancelClicked(e); })
        container.find("#ddlLaborType").change(function (e) { _this.onLaborTypeChange(e); })

        function centerModal() {
            $("#laborModal").css('display', 'block');
            var $dialog = $("#laborModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getLaborData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var laborModel = {};
        laborModel.DayId = container.find("#btnLaborUpdate")[0].attributes["data-dayid"].value;
        laborModel.ShiftId = container.find("#btnLaborUpdate")[0].attributes["data-shiftid"].value;
        laborModel.LaborId = container.find("#btnLaborUpdate")[0].attributes["data-laborid"].value;
        laborModel.LaborTypeId = container.find("#ddlLaborType").val();
        laborModel.LaborTypeName = container.find("#ddlLaborType option:selected").text().trim();
        laborModel.LocationId = container.find("#ddlLaborLocation").val();
        laborModel.LoactionName = container.find("#ddlLaborLocation option:selected").text().trim();
        laborModel.LaborHours = container.find("#manHours").val();
        laborModel.PricePerHr = container.find("#avgPricePerHr").val();
        return laborModel;
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               $.GetLocaleKeyValue("FIELD_PLEASECHECKYOURINPUT", "Please check your input.")
       );
        var v1 = container.find('#frmAddEditLabor').validate({
            rules: {
                ManHours: {
                    required: true,
                    regex: pattern1
                },
                Location: {
                    required: function () {
                        if ($('#ddlLaborLocation').val() == " ") {
                            return false;
                        }
                        return true;
                    },
                },
                LaborType: {
                    required: function () {
                        if ($('#ddlLaborType').val() == " ") {
                            return false;
                        }
                        return true;
                    },
                }
            },
            messages: {
                ManHours: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERMANHOURS", "Please enter Man Hours"),
                        regex: $.GetLocaleKeyValue("FIELD_ENTERONLYNUMBERS", "Enter only numbers")
                },
                Location: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERLOCATION", "Please enter Location"),
                },
                LaborType: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERLABORTYPE", "Please enter LaborType"),
                }
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });
        var v2 = container.find('#frmAddEditLabor').valid();
        return v2;
    },

    onCancelClicked: function () {
        if (this.options.eventHandlers.onCancelClicked) {
            this.options.eventHandlers.onCancelClicked();
        }
    },
    onSaveClicked: function () {
        var _this = this;

        if (this.options.eventHandlers.onLaborSaveClicked) {
            if (_this.validate() == true) {
                _this.isDirty = false;
                this.options.eventHandlers.onLaborSaveClicked(_this.getLaborData());
            } else {
                return false;
            }
        }
    },
    showErrorMessage: function (error, description) {
        _this = this
        var container = $(this.options.containerSelector);
        container.find('#errorDivLabor').html(description);
    },
    onLaborTypeChange: function (e) {
        if (this.options.eventHandlers.onLaborTypeChanged) {
            if ($.isNumeric($(e.currentTarget).val())) {
                this.options.eventHandlers.onLaborTypeChanged(parseInt($(e.currentTarget).val()));
            } else {
                $(this.options.containerSelector).find('#avgPricePerHr').val('');
            }
        }
    },
    setCost: function (cost) {
        $(this.options.containerSelector).find('#avgPricePerHr').val(cost);
    }
}