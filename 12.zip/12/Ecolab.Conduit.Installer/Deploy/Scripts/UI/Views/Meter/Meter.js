﻿Ecolab.Views.Meter = function(options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onUtilityTypeChange: null,
            onUtilityLocationChange: null,
            onAddNewMeterPopupLoad: null,
            onMeterEditPopupLoad: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Meter/Meter.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function() { _this.onRendered(); } }
    });
    this.initValidator();
    this.meterData = null;
    this.isEdit = null;
    this.allowEdit = false;
    this.controllerCount = 0;
};

Ecolab.Views.Meter.prototype = {
    setData: function(data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function() {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    setMeterData: function(data) {
        var _this = this;
        this.meterData = data;
    },
    setMeterOnAddNewPopupLoadData: function(data) {
        var _this = this;

        var ddlUtilityType = $('#ddlUtilityTypeAdd');
        ddlUtilityType.empty();
        ddlUtilityType.append('<option value="">-- Select --</option>');
        if (data.UtilityType.length > 0) {
            $.each(data.UtilityType, function() {
                ddlUtilityType.append('<option value="' + this.ResourceId + '">' + this.Name + '</option>');
            });
        }

        var ddlUtilityLocationAdd = $('#ddlUtilityLocationAdd');
        ddlUtilityLocationAdd.empty();
        ddlUtilityLocationAdd.append('<option value="">-- Select --</option>');
        if (data.UtilityLocation.length > 0) {
            $.each(data.UtilityLocation, function() {
                ddlUtilityLocationAdd.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '" >' + this.GroupDescription + '</option>');
            });
        }

        var ddlParent = $('#ddlParentAdd');
        ddlParent.empty();
        ddlParent.append('<option value="">-- Select --</option>');
        if (data.Parent.length > 0) {
            $.each(data.Parent, function() {
                ddlParent.append('<option value="' + this.MeterId + '">' + this.Description + '</option>');
            });
        }

        var ddlControllerAdd = $('#ddlControllerAdd');
        ddlControllerAdd.empty();
        ddlControllerAdd.append('<option value="">-- Select --</option>');
        if (data.Controller.length > 0) {
            $.each(data.Controller, function() {
                ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '">' + this.Name + '</option>');
            });
        }

        $('#ddlAllowManualEntry').attr("checked", false);
    },

    SetMeterOnEditPopupLoad: function(data) {
        var _this = this;
        var ddlUtilityType = $('#ddlUtilityType');
        ddlUtilityType.empty();
        ddlUtilityType.append('<option value="">-- Select --</option>');
        if (data.UtilityType.length > 0) {
            $.each(data.UtilityType, function() {
                ddlUtilityType.append('<option value="' + this.ResourceId + '">' + this.Name + '</option>');
            });
            ddlUtilityType.val(data.Meter.MeterType);
            if ((data.Meter.MeterType) == 1) {
                $('.ufactor').show();
                $('#txtUsageFactor').prop("required", true);
            } else {
                $('#txtUsageFactor').removeAttr("required");
                $('.ufactor').hide();
            }
        }

        var ddlUtilityLocation = $('#ddlUtilityLocation');
        ddlUtilityLocation.empty();
        ddlUtilityLocation.append('<option value="">-- Select --</option>');
        if (data.UtilityLocation.length > 0) {
            $.each(data.UtilityLocation, function() {
                ddlUtilityLocation.append('<option value="' + this.GroupTypeId + '"data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '">' + this.GroupDescription + '</option>');
            });
            ddlUtilityLocation.val(data.Meter.UtilityId);
            var lblMachineCompartment = $('#lblMachineCompartment');
            var ddlLocation = $("#ddlUtilityLocation option:selected");
            if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                lblMachineCompartment.removeAttr('data-localize');
            } else {
                lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                lblMachineCompartment.removeAttr('data-localize');
            }
        }

        var ddlMachineCompartment = $('#ddlMachineCompartment');
        ddlMachineCompartment.empty();
        ddlMachineCompartment.append('<option value="">-- Select --</option>');
        if (data.MachineCompartment.length > 0) {
            $.each(data.MachineCompartment, function() {
                ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
            });
            ddlMachineCompartment.val(data.Meter.MachineId);
        }

        var ddlParent = $('#ddlParent');
        ddlParent.empty();
        ddlParent.append('<option value="">-- Select --</option>');
        if (data.Parent.length > 0) {
            $.each(data.Parent, function() {
                ddlParent.append('<option value="' + this.MeterId + '">' + this.Description + '</option>');
            });
            ddlParent.val(data.Meter.ParentId);
        }

        var ddlUOM = $('#ddlUOM');
        ddlUOM.empty();
        ddlUOM.append('<option value="">-- Select --</option>');
        if (data.UOM.length > 0) {
            $.each(data.UOM, function() {
                ddlUOM.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
            });
            ddlUOM.val(data.Meter.MeterTickUnit);
            ddlUOM.prop("required", true);
        } else {
            ddlUOM.removeAttr('required');
        }

        if (data.Meter.ControllerName != null) {
            if ( data.Meter.ControllerRegionId == 1 || data.Meter.ControllerModelId == 5) {
                $('.DigitalInputNumber').show();
                //$('#txtDigitalInputNumber').prop("required", true);
            } else {
                //$('#txtDigitalInputNumber').removeAttr("required");
                $('.DigitalInputNumber').hide();
            }
        }

        $('#ddlAllowManualEntry').attr("checked", data.Meter.AllowManualEntry);

    },


    //Setting cascading data for Machine/compartment basing on Utility Location
    SetOnUtilityLocationChangedData: function(data) {
        var _this = this;
        var ddlMachineCompartment;
        if (_this.isEdit == true) {
            ddlMachineCompartment = $('#ddlMachineCompartment');
            ddlMachineCompartment.empty();
            ddlMachineCompartment.append('<option value="">-- Select --</option>');
            if (data.MachineCompartment.length > 0) {
                $.each(data.MachineCompartment, function() {
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
            }
        } else if (_this.isEdit == false) {
            ddlMachineCompartment = $('#ddlMachineCompartmentAdd');
            ddlMachineCompartment.empty();
            ddlMachineCompartment.append('<option value="">-- Select --</option>');
            if (data.MachineCompartment.length > 0) {
                $.each(data.MachineCompartment, function() {
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
            }
        }

        if (_this.isEdit == false) {
            var ddlControllerAdd = $('#ddlControllerAdd');
            ddlControllerAdd.empty();
            ddlControllerAdd.append('<option value="">-- Select --</option>');
            if (data.Controller.length > 0)
                $.each(data.Controller, function() {
                    ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '">' + this.Name + '</option>');
                });
        }
    },

    SetUOMData: function(data) {
        var _this = this;
        if (_this.isEdit == true) {
            var ddlUOM = $('#ddlUOM');
            ddlUOM.empty();
            ddlUOM.append('<option value="">-- Select --</option>');
            if (data.length > 0) {
                $.each(data, function() {
                    ddlUOM.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
                ddlUOM.prop("required", true);
            } else {
                ddlUOM.removeAttr('required');
            }
        } else if (_this.isEdit == false) {
            var ddlUOMAdd = $('#ddlUOMAdd');
            ddlUOMAdd.empty();
            ddlUOMAdd.append('<option value="">-- Select --</option>');
            if (data.length > 0) {
                $.each(data, function() {
                    ddlUOMAdd.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
                ddlUOMAdd.prop("required", true);
            } else {
                ddlUOMAdd.removeAttr('required');
            }
        }
    },

    initValidator: function() {
        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var check = false;
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Please check your input."
        );
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    attachEvents: function() {

        $("#tabUtilitiesContainer").addClass("active");
        $("#tabUtilities").parent("li").addClass("active");

        $("#frmMeter").kendoValidator();
        var _this = this;
        var wnd, detailsTemplate, detailsTemplateView;
        var trIndex = null;
        var container = $(this.options.containerSelector);
        _this.controllerCount = this.data.ControllerCount;

        //Set allow edit on role level
        _this.allowEdit = (this.data.MaxLevel >= 8);

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');

        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Meter/GetMeter",
                    dataType: "json"
                },
                create: {
                    url: "/api/Meter/CreateMeter",
                    dataType: "json",
                    type: "POST",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERADDEDSUCCESSFULLY" class="k-success-message">Meter Added Successfully</label>');
                            kendoWindow.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split(",");
                            if (parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 101 || parseInt(code[0]) == 401 || parseInt(code[0]) == 501 || parseInt(code[0]) == 601 || parseInt(code[0]) == 701 || parseInt(code[0]) == 801 || parseInt(code[0]) == 802) {
                                var errorMessage = '';
                                for (var a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (parseInt(code[a]) == 101) {
                                        errorMessage = '<span>Maximum 6 Water meters can be connected to the same Washter-Tunnel</span>';
                                    } else if (parseInt(code[a]) == 201) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMTWOWATERMETERSCANBECONNECTEDTOTHESAMEWASHER-CONVENTIONAL">Maximum two Water meters can be connected to the same Washer-Conventional</span>';
                                    } else if (parseInt(code[a]) == 301) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMONEMETERWITHTHESAMEUTILITYCANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one meter with the same utility can be connected to one Machine / Compartement</span>';
                                    } else if (parseInt(code[a]) == 401) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLERCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Controller can not be empty when Utility Location is selected</span>';
                                    } else if (parseInt(code[a]) == 501) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MACHINE/COMPARTMENTCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Machine/Compartment can not be empty when Utility Location is selected</span>';
                                    } else if (parseInt(code[a]) == 601) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_UTILITYLOCATION&MACHINE/COMPARTMENTCANNOTBEEMPTYWHENCONTROLLERISNOTUTILITYLOGGER">Utility Location & Machine/Compartment can not be empty when Controller is not UtilityLogger</span>';
                                    } else if (parseInt(code[a]) == 701) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLEROFTYPEUTILITYLOGGERISUNAVAILABLE">Controller of type UtilityLogger is unavailable</span>';
                                    } else if (parseInt(code[a]) == 801) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDMETERTAG">Invalid Meter Tag</span>';
                                    } else if (parseInt(code[a]) == 802) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_METERTAGALREADYEXISTS">Meter Tag already exists</span>';
                                    }
                                }
                                var errorMessageAdd = $('#errorMessageAdd');
                                errorMessageAdd.show();
                                errorMessageAdd.html('');
                                errorMessageAdd.html(errorMessage);
                                //dataSource.cancelChanges();
                            } else {
                                $("#errorDiv").html('<label data-localize ="FIELD_METERADDITIONFAILED" class="k-error-message">Meter Addition Failed</label>');
                                dataSource.cancelChanges();
                                kendoWindow.close();
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/Meter/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERUPDATEDSUCCESSFULLY" class="k-success-message">Meter Updated Successfully</label>');
                            wnd.close();
                            if (grid) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split(",");
                            if (parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 101 || parseInt(code[0]) == 501 || parseInt(code[0]) == 601 || parseInt(code[0]) == 801 || parseInt(code[0]) == 802) {
                                var errorMessage = '';
                                for (var a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (parseInt(code[a]) == 101) {
                                        errorMessage = '<span data-localize ="FIELD_MAXIMUM6WATERMETERSCANBECONNECTEDTOTHESAMEWASHTER-TUNNEL">Maximum 6 Water meters can be connected to the same Washter-Tunnel</span>';
                                    } else if (parseInt(code[a]) == 201) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMTWOWATERMETERSCANBECONNECTEDTOTHESAMEWASHER-CONVENTIONAL">Maximum two Water meters can be connected to the same Washer-Conventional</span>';
                                    } else if (parseInt(code[a]) == 301) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMONEMETERWITHTHESAMEUTILITYCANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one meter with the same utility can be connected to one Machine / Compartement</span>';
                                    } else if (parseInt(code[a]) == 501) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MACHINE/COMPARTMENTCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Machine/Compartment can not be empty when Utility Location is selected</span>';
                                    } else if (parseInt(code[a]) == 601) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_UTILITYLOCATION&MACHINE/COMPARTMENTCANNOTBEEMPTYWHENCONTROLLERISNOTUTILITYLOGGER">Utility Location & Machine/Compartment can not be empty when Controller is not UtilityLogger</span>';
                                    } else if (parseInt(code[a]) == 801) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDMETERTAG">Invalid Meter Tag</span>';
                                    } else if (parseInt(code[a]) == 802) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_METERTAGALREADYEXISTS">Meter Tag already exists</span>';
                                    }
                                }
                                var errorMessageDiv = $('#errorMessage');
                                errorMessageDiv.show();
                                errorMessageDiv.html('');
                                errorMessageDiv.html(errorMessage);
                                dataSource.cancelChanges();
                            } else {
                                $("#errorDiv").html('<label data-localize ="FIELD_METERUPDATIONFAILED" class="k-error-message">Meter Updation Failed</label>');
                                dataSource.cancelChanges();
                                wnd.close();
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Meter/DeleteMeter",
                    dataType: "json",
                    type: "DELETE",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERDELETEDSUCCESSFULLY" class="k-success-message">Meter Deleted Successfully</label>');
                        } else {
                            dataSource.cancelChanges();
                            var code = JSON.parse(jqXhr.responseText);
                            if (code == '404') {
                                $("#errorDiv").html('<label data-localize ="FIELD_UNABLETODELETEPARENTMETERWHENCHILDMETEREXISTS" class="k-error-message">Unable to delete parent meter when child meter exists</label>');
                            } else {
                                $("#errorDiv").html('<label data-localize ="FIELD_METERDELETIONFAILED" class="k-error-message">Meter Deletion Failed</label>');
                            }
                        }
                        _this.tm.Localize();
                    }
                },
            },
            requestStart: function(e) {
                var gridMeter = $("#gridMeter");
                gridMeter.data("kendoGrid").hideColumn("ParentName");
                gridMeter.data("kendoGrid").hideColumn("UsageFactor");
                gridMeter.data("kendoGrid").hideColumn("ControllerName");
                gridMeter.data("kendoGrid").hideColumn("DigitalInputNumber");
                gridMeter.data("kendoGrid").hideColumn("AllowManualEntry");
                gridMeter.data("kendoGrid").hideColumn("MaxValueLimit");

            },
            pageSize: 12,
            schema: {
                model: {
                    id: "MeterId",
                    fields: {
                        MeterId: { editable: false, type: "number" },
                        Description: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_NAME", 'Name')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MeterTypeName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UTILITY-TYPE", 'Utility-Type')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        UtilityLocation: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UTILITYLOCATION", 'Utility Location')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MachinecompartmentName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_MACHINECOMPARTMENT", 'Machine/Compartment')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        ParentName: { editable: false },
                        Calibration: { editable: true, defaultValue: 0, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CALIBRATION", 'Calibration')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MeterTickUnit: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UOM", 'UOM')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        UsageFactor: { editable: true, defaultValue: 1, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UFACTOR", 'U-Factor')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        ControllerName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CONTROLLER", 'Controller')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        DigitalInputNumber: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_DIGITALINPUTNUMBER", 'Digital Input Number')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        AllowManualEntry: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_ALLOWMANUALENTRY", 'Allow Manual Entry')+' '+$.GetLocaleKeyValue("FIELD_REQUIRED", 'required')} },
                        MaxValueLimit: {
                            editable: true,
                            defaultValue: 10000,
                            validation: {
                                required: true,
                                validationMessage: "Meter Rollover Point required",
                                maxLength: function(input) {
                                    var pattern;
                                    if (input.is("[name='MaxValueLimit']") && input.val() != "") {
                                        input.attr("validationmessage", "Only numeric values are accepted");
                                        pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        } else {
                                            return false;
                                        }
                                    } else if (input.is("[name='Calibration']") || input.is("[name='UsageFactor']") && input.val() != "") {
                                        input.attr("validationmessage", "Should be a number with maximum 3 decimal places");
                                        pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        } else {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "78px";
        if (_this.controllerCount > 0) {
            if (_this.allowEdit) {
                commands = [{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }];
                addNew = [{ text: "<span data-localize='FIELD_ADDMETER'>Add Meter</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
                editTitle = $.GetLocaleKeyValue("FIELD_EDITMETER", 'Edit Meter');
            } else {
                commands = [{ name: "view", text: "", click: showDetails }];
                addNew = "";
                customWidth = "55px";
                editTitle = "View Meter";
            }
        } else {
            addNew = '<div class="grid-add-new-record">Please add a Controller before adding a meter.</div>';
        }

        function onEdit(e) { clearStatusMessage(); }

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        if (container.find('#gridMeter').data().kendoGrid)
            container.find('#gridMeter').data().kendoGrid.destroy();
        container.find("#gridMeter").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                { command: commands, width: "78px", attributes: { "class": "align-center" } },
                { field: "MeterId", width: "10%", title: "<span data-localize='FIELD_NUMBER'>Number</span>", format: "{0:0}", attributes: { "class": "align-center" }, headerAttributes: { "class": "align-center" } },
                { field: "Description", width: "10%", title: "<span data-localize='FIELD_NAME'>Name</span>" },
                { field: "MeterTypeName", width: "13%", title: "<span data-localize='FIELD_UTILITYTYPE'>Utility-Type</span>" },
                { field: "UtilityLocation", width: "14%", title: "<span data-localize='FIELD_UTILITYLOCATION'>Utility Location</span>" },
                { field: "MachinecompartmentName", width: "18%", title: "<span data-localize='FIELD_MACHINECOMPARTMENT'>Machine/Compartment</span>" },
                { field: "ParentName", width: "10%", hidden: true, title: "<span data-localize='FIELD_PARENT'>Parent</span>" },
                { field: "Calibration", width: "10%", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" }, title: "<span data-localize='FIELD_CALIBRATION'>Calibration</span>" },
                {
                    field: "MeterTickUnit",
                    width: "16%",
                    title: "<span data-localize='FIELD_UOM'>UOM</span>",
                    template: function(data) { return data.MeterTickUnit != null ? $.GetLocaleKeyValue(data.MeterTickUnit, data.MeterTickUnit) : ''; },
                    editor: function(container, options) { container.append($.GetLocaleKeyValue(options.model.MeterTickUnit, options.model.MeterTickUnit)); }
                },
                { field: "UsageFactor", width: "10%", hidden: true, title: "U-factor" + "<br />" + "(Compression factor)", headerAttributes: { "data-localize": "FIELD_UFACTORCOMPRESSIONFACTOR" } },
                { field: "ControllerName", width: "10%", hidden: true, title: "Controller", headerAttributes: { "data-localize": "FIELD_CONTROLLER" } },
                { field: "DigitalInputNumber", width: "10%", hidden: true, title: "Digital" + "<br />" + "Input Number", headerAttributes: { "data-localize": "FIELD_DIGITALINPUTNUMBER" } },
                { field: "AllowManualEntry", width: "10%", hidden: true, title: "Allow" + "<br />" + "Manual Entry", headerAttributes: { "data-localize": "FIELD_ALLOWMANUALENTRY" } },
                { field: "MaxValueLimit", width: "10%", hidden: true, title: "Meter" + "<br />" + "Roll-over Point", headerAttributes: { "data-localize": "FIELD_METERROLLOVERPOINT" } }
            ],
            editable: "inline",
        });

        wnd = $("#details")
            .kendoWindow({
                title: editTitle,
                modal: true,
                visible: false,
                resizable: false,
                width: "373px",
                height: "auto",
                open: onOpen,
                activate: function(e) {
                    _this.tm.Localize();
                }
            }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editMeter").html());
        detailsTemplateView = kendo.template($("#editMeterView").html());

        //Impliment Cascading population of dropdowns here
        function onOpen(e) {
            if (_this.options.eventHandlers.onMeterEditPopupLoad)
                _this.options.eventHandlers.onMeterEditPopupLoad($('#txtMeterId').text());

            $('#ddlUtilityType').change(function() {
                _this.isEdit = true;
                if ($(this).val() != '') {
                    if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val());
                }

                if ($('#ddlUtilityType').val() == 1) {
                    $('.ufactor').show();
                    $('#txtUsageFactor').prop("required", true);
                } else {
                    $('#txtUsageFactor').removeAttr("required");
                    $('.ufactor').hide();
                }
            });
            //Cascading data for Machine/Compartment basing on Utility Location
            $('#ddlUtilityLocation').change(function() {
                _this.isEdit = true;
                $('#ddlMachineCompartment').html('<option value="">-- Select --</option>');

                if ($(this).val() != '') {
                    var lblMachineCompartment = $('#lblMachineCompartment');
                    var ddlLocation = $("#ddlUtilityLocation option:selected");
                    if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                        lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                        lblMachineCompartment.removeAttr('data-localize');
                    } else {
                        lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                        lblMachineCompartment.removeAttr('data-localize');
                    }
                    if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
                }
            });
            /*
                $('#ddlMachineCompartment').change(function () {
                $('#ddlController').val($(this).find('option:selected').attr('data-controllerid'));
            });*/
        }

        var grid;

        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.MeterDataToLoadDropdown = _this.meterData;
            dataItem.maxRole = _this.data.MaxLevel;

            //Set RoleBased editing here
            if (_this.allowEdit) {
                wnd.content(detailsTemplate(dataItem));
            } else {
                wnd.content(detailsTemplateView(dataItem));
            }
            wnd.center().open();

            wnd.element.find(".editRowPopup").unbind("click");
            wnd.element.find(".editRowPopup").click(function() {
                var validator = $(wnd.element).kendoValidator().data("kendoValidator");
                var uid = eval($(".uid").attr("id"));

                if (validator.validate()) {
                    dataSource.fetch(function() {
                        var meter = dataSource.get(uid);
                        meter.set("MeterId", $("#txtMeterId").text());
                        meter.set("Description", $("#txtDescription").val());

                        meter.set("MeterType", $("#ddlUtilityType").val().trim());
                        meter.set("UtilityId", $("#ddlUtilityLocation").val().trim());
                        meter.set("MachineId", $("#ddlMachineCompartment").val().trim());
                        meter.set("Calibration", $("#txtCalibration").val().trim());
                        meter.set("ParentId", $("#ddlParent").val().trim());
                        meter.set("MeterTickUnit", $("#ddlUOM").val().trim());
                        meter.set("UsageFactor", $("#txtUsageFactor").val().trim());
                        //meter.set("ControllerId", $("#ddlController").val().trim());
                        meter.set("DigitalInputNumber", $("#txtDigitalInputNumber").val().trim());
                        meter.set("AllowManualEntry", $("#ddlAllowManualEntry")[0].checked);
                        meter.set("MaxValueLimit", $("#txtMaxValueLimit").val().trim());
                    });
                    grid = $("#gridMeter").data("kendoGrid");
                    grid.saveChanges();
                } else return false;
            });
        }

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function() {
            dataSource.cancelChanges(); //cancel changes
            wnd.close();
        });
        window.userMaxRole = _this.data.MaxLevel;
        var kendoWindow;
        $("#gridMeter a.grid-add-new-record").unbind("click");
        $("#gridMeter a.grid-add-new-record").on("click", function(e) {
            clearStatusMessage();
            var data = $("#gridMeter").data("kendoGrid").dataSource;
            kendoWindow = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDMETER", 'Add Meter'),
                    modal: true,
                    resizable: false,
                    visible: false,
                    width: "373px",
                    height: "auto",
                    open: onAddNewOpen,
                    close: onClose,
                    content: {
                        //sets kendoWindow template
                        template: kendo.template($("#newMeter").html())
                    },
                    activate: function(e) {
                        _this.tm.Localize();
                    }
                })
                .data("kendoWindow").center().open();
            var index = data.indexOf((data.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the data
            var model = data.insert(index, {});

            //binds the editing kendoWindow to the form
            kendo.bind(kendoWindow.element, model);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator
            var validator = $(kendoWindow.element).kendoValidator().data("kendoValidator");
            kendoWindow.element.find('#btnUpdate').unbind("click");
            kendoWindow.element.find('#btnUpdate').click(function(e) {
                if (validator.validate() == true) {
                    data._data[0].MeterType = $("#ddlUtilityTypeAdd").val().trim();
                    data._data[0].UtilityId = parseInt($("#ddlUtilityLocationAdd").val().trim());
                    data._data[0].MachineId = parseInt($("#ddlMachineCompartmentAdd").val().trim());
                    data._data[0].ParentId = parseInt($("#ddlParentAdd").val().trim());
                    data._data[0].MeterTickUnit = $("#ddlUOMAdd").val().trim();
                    data._data[0].ControllerId = $("#ddlControllerAdd").val().trim();
                    data._data[0].ControllerModelId = $("#ddlControllerAdd option:selected").attr('data-typeid');
                    data._data[0].ControllerType = $("#ddlControllerAdd option:selected").attr('data-type');

                    data._data[0].AllowManualEntry = $("#ddlAllowManualEntryAdd")[0].checked;

                    data.sync(); //sync changes

                    grid = $("#gridMeter").data("kendoGrid");
                } else {
                    return false;
                }

            });

            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function(e) {
                data.cancelChanges(model); //cancel changes
                kendoWindow.close();
                kendoWindow = null;
            });

            function onClose(e) {
                data.cancelChanges(model); //cancel changes
                kendoWindow.element.remove();
                kendoWindow.destroy();

            }
        });

        function onAddNewOpen() {
            if (_this.options.eventHandlers.onAddNewMeterPopupLoad)
                _this.options.eventHandlers.onAddNewMeterPopupLoad();

            //Cascading data for Utility Location basing on Utility Type
            $('#ddlUtilityTypeAdd').change(function() {
                _this.isEdit = false;
                if ($(this).val() != '') {
                    if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val());
                }
                if ($('#ddlUtilityTypeAdd').val() == 1) {
                    $('.ufactor').show();
                    $('#txtUsageFactorAdd').prop("required", true);
                } else {
                    $('#txtUsageFactorAdd').removeAttr("required");
                    $('.ufactor').hide();
                }
            });

            //Cascading data for Machine/Compartment basing on Utility Location
            $('#ddlUtilityLocationAdd').change(function() {
                _this.isEdit = false;
                $('#ddlMachineCompartmentAdd').html('<option value="">-- Select --</option>');
                if ($(this).val() != '') {
                    var lblMachineCompartmentAdd = $('#lblMachineCompartmentAdd');
                    var ddlLocationAdd = $("#ddlUtilityLocationAdd option:selected");
                    if (ddlLocationAdd.data('type') == "WasherGroup" && ddlLocationAdd.data('istunnel') == true) {
                        lblMachineCompartmentAdd.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                        lblMachineCompartmentAdd.removeAttr('data-localize');
                    } else {
                        lblMachineCompartmentAdd.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                        lblMachineCompartmentAdd.removeAttr('data-localize');
                    }
                    if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
                }
            });
            $('#ddlMachineCompartmentAdd').change(function() {
                var controllerAdd = $('#ddlControllerAdd');
                controllerAdd.val($(this).find('option:selected').attr('data-controllerid'));
                controllerAdd.trigger('change');
            });

            $('#ddlControllerAdd').change(function() {
                var option = $(this).find('option:selected');
                if (option.attr('data-regionid') == null || option.attr('data-regionid') == 1 || option.attr('data-typeid') == 5) {
                    $('.DigitalInputNumber').show();
                    //$('#txtDigitalInputNumberAdd').prop("required", true);
                } else {
                    //$('#txtDigitalInputNumberAdd').removeAttr("required");
                    $('.DigitalInputNumber').hide();
                }
            });
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
    }
};