﻿Ecolab.Views.Home = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'Home',
        templateUri: '/Scripts/UI/Views/Home/Home.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.Home.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
        this.setIframe(data);
    },

    setIframe: function (data) {
        var _this = this;
        var container = $(_this.options.containerSelector);
        var dashboards = data;
        var length = dashboards.length;
        var index = 0;
        var url = window.location.href;
        //var url = _this.options.accountInfo.VisualizationUrl;
        if (length > 0) {
            container.find('#iframeDashboard').attr('src', url + 'visualization/index?id=' + dashboards[0].DashboardId + '&typeId=' + dashboards[0].TypeId + '');
            
            if (length > 1) {
                // init timer and stores it's identifier so it can be unset later
                var timer = setInterval(replaceIFrame, 10000);
            }
            function replaceIFrame() {
                container.find('#imgDashboard').attr('style', 'display:none');
                container.find('#iframeDashboard').attr('src', url + 'visualization/index?id=' + dashboards[index].DashboardId + '&typeId=' + dashboards[index].TypeId + '');
                index++;
                // Set index to 0 after all items
                if (index >= length) {
                    index = 0;
                }
            }
        }
        else {
            container.find('#iframeDashboard').attr('style', 'display:none');
            container.find('#imgDashboard').attr('style', 'display:block');
            container.find('#imgDashboard').attr('src', '/images/washergroup.jpg');
        }
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('#iframeDashboard').css('height', $(window).height());
        $('footer').hide();
        $('.pad_10t').hide();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
    },
}