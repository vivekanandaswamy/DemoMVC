Ecolab.Views.AddWasherGroup = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { },
            validateWasherGroup: function () { }
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'AddWasherGroup',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/AddWasherGroup.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.AddWasherGroup.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        this.disableTabs();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $("#btnAddWasherGroup").attr("disabled");

        if (this.data.WasherGroupDetails[0].WasherGroupId > 0) {
            $("#ddlWasherGroupType").attr("disabled", "disabled");
        }
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        

    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.options.accountInfo.MaxLevel >= 6);
        var container = $(this.options.containerSelector);
        $('#btnAddEditWasherGroup').click(function () { _this.onAddEditClicked(); });
        $('#btnAddNewWasher').click(function () { _this.onAddNewWasherClicked(); });
        container.find(".deleteWashers").click(function () {
            _this.onWasherDeleteClicked($(this).attr('washertype'), $(this).attr('washers-id'));
        });

        container.find(".updateWashers").click(function () {

            _this.redirect($(this).attr('washertype'), $(this).attr('washers-id'), $(this).attr('washergroup-id'));
        });

        container.find('#btnWasherGroupwithWashersPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                PageTitle: "WasherGroup",
                WasherGroupId: _this.options.accountInfo.WasherGroupId
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

    },
    // Event is for redirecting to Add/Edit washer group.
    onAddEditClicked: function () {
        var _this = this;
        if (this.options.eventHandlers.onSavePage) {
            this.options.eventHandlers.onSavePage();
        }
    },
    onAddNewWasherClicked: function () {
        var _this = this;
        if (this.options.eventHandlers.onAddNewWasher)
            this.options.eventHandlers.onAddNewWasher();
    },
    validateWasherGroup: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmAddEditWasherGroup').validate({
            rules: {
                txtGroupName: { required: true },
                txtGroupNumber: { required: true, digits: true, greaterThanZero: true }
            },
            messages: {
                txtGroupName: { required: $.GetLocaleKeyValue('FIELD_GROUPNAMECANNOTBEEMPTY', 'Group Name cannot be Empty.') },
                txtGroupNumber: { required: $.GetLocaleKeyValue('FIELD_GROUPNUMBERCANNOTBEEMPTY', 'Group Number cannot be Empty.') }
            }
        });

        var v2 = container.find('#frmAddEditWasherGroup').valid();
        return v2;
    },
    //Gets the data to pass
    getWasherGroupsData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var washerGroupData = {
            WasherGroupId: container.find("#txtGroupNumber").attr("washergroupid"),
            WasherGroupName: container.find("#txtGroupName").val(),
            WasherGroupTypeId: container.find("#ddlWasherGroupType").val(),
            WasherGroupTypeName: container.find("#ddlWasherGroupType option:not(.empty):selected").text(),
            WasherGroupNumber: container.find("#txtGroupNumber").val(),
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber
        };
        return washerGroupData;
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#divMessage");
        messageDiv.html(message);

    },
    disableTabs: function () {
        var container = $(this.options.containerSelector);
        var WasherGroupId = container.find("#txtGroupNumber").attr("washergroupid");
        if (WasherGroupId == 0 ||  this.data.WashersList.length == 0) {
            $('.new_tabs li.tab').not('.active').addClass('disabled');
            $('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
            $('.new_tabs li.disabled').children('a').click(function (e) {
                e.preventDefault();
            });
        }
       
    },
    onWasherDeleteClicked: function (isTunnel, id) {
        if (this.options.eventHandlers.onWasherDeleteClicked)
            this.options.eventHandlers.onWasherDeleteClicked(isTunnel, id);
    },
    redirect: function (washerType, washersId, washergroupId) {
        if (washerType == 'true') {
            var retval = this.options.eventHandlers.onRedirection('./TunnelGeneral?WasherId=' + washersId + '&WasherGroupId=' + washergroupId + '&WasherGroupTypeId=' + $('#hWasherGroupTypeId').val());
            return retval;
        }
        else {
            var retval = this.options.eventHandlers.onRedirection('./ConventionalGeneral?WasherId=' + washersId + '&WasherGroupId=' + washergroupId);
            return retval;
        }
    },
    enableAddWasherButton: function () {
        var container = $(this.options.containerSelector);
        $("#btnAddNewWasher").removeAttr('disabled');
    },

}
jQuery.validator.addMethod("greaterThanZero", function (value, element) {
    //    var field = element.id.replace('txt', '');
    return this.optional(element) || (parseFloat(value) > 0);
}, $.GetLocaleKeyValue('FIELD_VALUESHOULDBEGREATERTHANZERO', 'Value should be greater than zero'));