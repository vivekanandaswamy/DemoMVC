﻿Ecolab.Views.AddFormula = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }      
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    
    this.tm = new TemplateManager({
        templateName: 'AddFormula',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/AddFormula.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.AddFormula.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        if (data.WasherGroupFormulaWashStepModel == null || data.WasherGroupFormulaWashStepModel.length == 0 || data.WasherGroupFormulaWashStepModel == 0 ) {
            data.Mode = "Add";
            data.waterType = "";
        }
        else {
            if (data.WasherGroupFormulaWashStepModel != 0) {
                data.waterType = this.waterType();
            }
        }
    
        this.data = data;

        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $("#spanRunTime").mask("00:00");
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('#btnSave').click(function () {
            _this.onSaveFormulaClicked();
        });
        //Print Button
        container.find('#btnFormulaWashStepPrint').click(function () {
            var data = {
                RegionId: _this.options.accountInfo.RegionId,
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                WasherGroupId: _this.options.accountInfo.WasherGroupId,
                PageTitle: "Formula WashStep List",
                ProgramSetupId: _this.data.WasherGroupFormulaDetails[0].Id,
                WasherId: _this.options.accountInfo.washerId == null ? 0 : _this.options.accountInfo.washerId,
                DosingSetupId: _this.options.accountInfo.id
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

        container.find("#btnAddWashStep").click(function () {
            _this.onWashStepClicked();
        });
        container.find("#btnTunnelWashStep").click(function () {
            _this.onTunnelUpdateWashStepClicked(container.find("#txtNumber").attr("formula-id"));
        });
        
        container.find(".updateWashStepList").click(function () {
            _this.onUpdateWashStepClicked($(this).attr('formulasteps-id'));
        });
        container.find(".copyWashStepList").click(function () {
            _this.onCopyWashStepClicked($(this).attr('formulasteps-id'));
        });
        container.find(".deleteWashStepList").click(function () {
            _this.onWashStepDeleteClicked($(this).attr('formulasteps-id'));
        });
        container.find(".updateTunnelWashStepList").click(function () {
            _this.onTunnelUpdateWashStepClicked($(this).attr('formulasteps - id'));
        });
        container.find("#bckToFormula").click(function () {
            _this.onBackToFormulasClicked();
        });
        container.find(".viewFormulaStepDetails").click(function () {
            _this.onUpdateWashStepClicked($(this).attr('formulasteps-id'));
        });
    },

    validateFormula: function () {
        _this = this;
        var container = $(this.options.containerSelector);

        var minValue = (25 / 100) * this.options.accountInfo.Maxload;
        var maxValue = (200 / 100) * this.options.accountInfo.Maxload;

        var v1 = container.find('#frmAddEditFormula').validate({
            rules: {
                txtNumber: {
                    required: true, greaterThanZero: true,max:127,number:true
                },
                ddlFormulaName: {
                    required: true,
                },
                txtNominalLoadConventional: {
                    required: true, digits: true, min: 25, max: 200
                },
                txtLoadsPerMonth: {
                    required: true, number: true
                },
                txtExtraTime: {
                    required: true, max: 10000, number: true
                },
                txtNominalLoadTunnel: {
                    min: minValue,
                    max: maxValue,
                    digits: true
                }
            },
            messages: {
                txtNumber: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERFORMULANUMBER','Please enter Formula Number'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY','Please Enter numerics only'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO127','Please enter between 1 to 127.')
                },
                ddlFormulaName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERFORMULANAME','Please enter Formula Name'),
                },
                txtLoadsPerMonth: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERLOADSPERMONTH','Please enter Loads Per Month'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY','Please Enter numerics only'),
                },
                txtExtraTime: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTEREXTRATIME','Please enter Extra Time'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtNominalLoadConventional: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNOMINALLOAD','Please enter Nominal Load'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO100', 'Value should be between 25 - 200 %'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO100', 'Value should be between 25 - 200 %'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtNominalLoadTunnel: {
                    min: $.GetLocaleKeyValue('FIELD_VALUESNEEDTOBECALCULATEDDEPENDINGONTHEMAXLOAD', 'Values need to be calculated depending on the max. load'),
                    max: $.GetLocaleKeyValue('FIELD_VALUESNEEDTOBECALCULATEDDEPENDINGONTHEMAXLOAD', 'Values need to be calculated depending on the max. load'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().find("span.errorMsg"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().parent().find("span.errorMsg"));
                }

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().parent().find("span.errorMsg"));
                }

            }
        });
        var v2 = container.find('#frmAddEditFormula').valid();
        return v2;
    },
    onSaveFormulaClicked: function () {
        return this.options.eventHandlers.onSavePage();
    },
    getFormulaData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            Id: container.find("#txtNumber").attr("formula-id"),
            WasherGroupId: this.data.WasherGroupDetails[0].WasherGroupId,
            WasherGroupTypeName: container.find("#lblWasherGroupType").text(),
            ProgramNumber: container.find("#txtNumber").val(),
            ProgramId: container.find("#ddlFormulaName").val(),
            NominalLoad: _this.getNominalLoad(),
            LoadsPerMonth: container.find("#txtLoadsPerMonth").val(),
            ExtraTime: container.find("#txtExtraTime").val(),
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber
        };
},
getNominalLoad:function(){
    if(this.data.WasherGroupDetails[0].WasherGroupTypeId==1){ 
        return $("#txtNominalLoadConventional").val();
    }else{
        return $("#txtNominalLoadTunnel").val();
    }
},
    onWashStepClicked: function () {
        if (this.options.eventHandlers.onWashStepClicked)
            this.options.eventHandlers.onWashStepClicked();
    },
    //onTunnelWashStepClicked: function (id) {
    //    if (this.options.eventHandlers.onTunnelUpdateWashStepClicked)
    //        this.options.eventHandlers.onTunnelUpdateWashStepClicked(id);
    //},
    
    WashStepButtonEnabled: function () {
        var container = $(this.options.containerSelector);
        $("#btnAddWashStep").removeAttr('disabled');
        
        //this.container.find("#btnAddWashStep").removeAttr('disabled');
    },
    WashStepButtonDisabled: function () {
        var container = $(this.options.containerSelector);
        $('#btnAddWashStep').prop("disabled", true);
        
    },
    onWashStepDeleteClicked: function (id) {
        debugger;
        if (this.options.eventHandlers.onWashStepDeleteClicked)
            this.options.eventHandlers.onWashStepDeleteClicked(id);
    },
    onUpdateWashStepClicked: function (id) {
        if (this.options.eventHandlers.onUpdateWashStepClicked)
            this.options.eventHandlers.onUpdateWashStepClicked(id);
    },
    onCopyWashStepClicked: function (id) {
        if (this.options.eventHandlers.onCopyWashStepClicked)
            this.options.eventHandlers.onCopyWashStepClicked(id);
    },
    onTunnelUpdateWashStepClicked: function (id) {
        if (this.options.eventHandlers.onTunnelUpdateWashStepClicked)
            this.options.eventHandlers.onTunnelUpdateWashStepClicked(id);
    },
    onBackToFormulasClicked: function () {
        if (this.options.eventHandlers.onFormulaBackButtonClick) {
            this.options.eventHandlers.onFormulaBackButtonClick();
        }
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#divFormulaMessage");
        messageDiv.html(message);
    },
    waterType: function () {
        var waterTypes = {
            1: { value: 1, name: "Cold" },
            2: { value: 2, name: "Hot" },
            3: { value: 3, name: "Tempered" },
            4: { value: 4, name: "Waste" }

        };
        return waterTypes;
        
    }
    
}
jQuery.validator.addMethod("greaterThanZero", function (value, element) {
    //    var field = element.id.replace('txt', '');
    return this.optional(element) || (parseFloat(value) > 0);
}, $.GetLocaleKeyValue('FIELD_VALUESHOULDBEGREATERTHANZERO','Value should be greater than zero.'));


