Ecolab.Views.ProductsList = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.productData = null;
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'TunnelWashStepGridView',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/ProductsList.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.ProductsList.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data,dosingId) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.dosingId = dosingId;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('#myModal').modal('show');
       
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
        container.find("#btnSaveProducts").click(function () {
            _this.onValueChange();
            var productsList = _this.getProductsData();
            _this.updateProducts(productsList);
        });
        container.find(".quantity").change(function () {
            //var Id = $(this).attr('eqid');
            //if ($("#txtQuantity_" + Id).val() > 0) {
            //    $("#txtDelayTime_" + Id).removeAttr("disabled");
            //}
            //else {
            //    $("#txtDelayTime_" + Id).attr("disabled", "disabled");
            //}
        });
        container.find(".madeChange").change(function () {
            _this.onValueChange();
        });
    },
    getProductsData: function () {
        var loopTableBody = $("#tblAddWashstepProducts tbody");
        var trLength = loopTableBody.find('tr').length;
        var dataObject = this.data;
        var dosingId= this.dosingId;
        loopTableBody.find('tr').each(function (c, el) {
            var $tds = $(this).find('td');
            CompartmentNumber = $tds.eq(0).find('span').attr('cmptno');
            Quantity = $tds.eq(1).find('input[type=text]').val();
            DelayTime = $tds.eq(2).find('input[type=text]').val();
            dataObject[c].Quantity = Quantity;
            dataObject[c].DelayTime = DelayTime;
            dataObject[c].TunnelDosingSetupId = dosingId;
            dataObject.isDirty = true;
        });

        return dataObject;
    },
    updateProducts: function (productsList) {
        if (this.validateWasherStep()) {
            if (this.options.eventHandlers.updateProducts) {
                this.options.eventHandlers.updateProducts(productsList);
            }
            $('#myModal').modal('hide');
        }
    },
    validateWasherStep: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmProducstsList').validate({
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });

        var v2 = container.find('#frmProducstsList').valid();
        return v2;
    },
    onValueChange: function () {
        if (this.options.eventHandlers.onValueChange)
            this.options.eventHandlers.onValueChange();
    },
}
$.validator.addMethod("RequiredFields", $.validator.methods.required, $.GetLocaleKeyValue('FIELD_QUANTITYCANNOTBEEMPTY', 'Quantity cannot be Empty.'));
$.validator.addMethod("RequiredFieldsNumber", $.validator.methods.number, "Enter only numbers.");
$.validator.addClassRules("RequiredValidation", { RequiredFields: true, RequiredFieldsNumber: true });

$.validator.addMethod("DelayRequiredFields", $.validator.methods.required, "Delay Time Cannnot be Empty.");
$.validator.addMethod("DelayRequiredFieldsNumber", $.validator.methods.digits, "Enter only numbers.");
$.validator.addClassRules("DelayRequiredValidation", { DelayRequiredFields: true, DelayRequiredFieldsNumber: true });

