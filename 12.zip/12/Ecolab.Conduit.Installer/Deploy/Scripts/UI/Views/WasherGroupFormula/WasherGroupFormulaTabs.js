Ecolab.Views.WasherGroupFormulaTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'WasherGroupFormulaTabs',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/WasherGroupFormulaTabs.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.WasherGroupFormulaTabs.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
      
        container.find("#tabAddWasherGroup").click(function () {
            _this.onWasherGroupClicked();
        });
        container.find("#tabFormula").click(function () {
          if(!$('.new_tabs li.tab').hasClass('disabled')){
              _this.onFormulasClicked();
            }
        });
        container.find("#bckbutton").click(function () {
            _this.onBackButtonClicked();
        });
    },
    onFormulasClicked: function () {
        if (this.options.eventHandlers.onFormulaTabClick) {
            this.options.eventHandlers.onFormulaTabClick();
        }
    },
    onWasherGroupClicked: function () {
        if (this.options.eventHandlers.onWasherGroupClick) {
            this.options.eventHandlers.onWasherGroupClick();
        }
    },
    onBackButtonClicked: function () {
        this.options.eventHandlers.onBackButtonClick();
    }
}
