Ecolab.Views.AddWashStep = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.productData = null;
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'AddWashStep',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/AddWashStep.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.AddWashStep.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        if (data.WasherGroupFormulaWashStepModel) {
            data.Mode = "Edit";
            data.drainType = this.draindestinations(data.WasherGroupFormulaWashStepModel[0].DrainDestinationId);
            data.waterType = (data.WasherGroupFormulaWashStepModel[0].WaterType!='')? this.waterType(parseInt(data.WasherGroupFormulaWashStepModel[0].WaterType)):0;
        }
        else
            data.Mode = "Add";

        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#ddlWashoperation').trigger('change');
        if (this.options.eventHandlers.madeChangeFalse) {
            this.options.eventHandlers.madeChangeFalse();
            $("#btnSaveWashStep").attr("disabled", "disabled");
           
        }
        $('.RequiredValidation').trim();
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel >= 6);
        var container = $(this.options.containerSelector);
        var ProductId = 0;
        var ProductName = null; var quantity = null;
        var count = $("#tblAddWashstepProducts tbody tr").length;
        if (count > 0) {
            count = count + 1;
        } else if (count == 0) {
            count = 1;
        }
        container.find("#btnSaveWashStep").click(function () {
            _this.clearMessage();
            if (_this.validate()) {
                _this.saveWashStep();
            }
        });
        container.find("#back").click(function () {
            _this.onBackToFormulasClicked();
        });
        container.find("#backWashSteps").click(function () {
            _this.onBackToWashStepsClicked();
        });
        container.find("#lnkPrev").click(function () {
            _this.GetPrevStep();
        });
        container.find("#lnkNext").click(function () {
            _this.GetNextStep();
        });
        $(".deleteWashStep").live("click", function () {
            var val = $(this);
            _this.clearMessage();
            $("#btnSaveWashStep").prop("disabled", false);
            $(this).parent().parent().remove();
        });
        container.find("#ddlWashoperation").change(function () {
            if ($("#ddlWashoperation option:not(.empty):selected").text().toLocaleUpperCase() == "DRAIN") {
                $("#ddlDrainDestination").removeAttr("disabled");
                $("#ddlDrainDestination").parent('.select-wrapper').removeClass("disabled");

            }
            else {
                $("#ddlDrainDestination").attr('disabled', 'disabled');
                $("#ddlDrainDestination").val(1);
                $("#ddlDrainDestination").parent('.select-wrapper').addClass("disabled");

            }
        });
        container.find("#ddlWashSteps").change(function () {
            _this.GetWashStepDetails($(this).val());
        });
        container.find("#ddlWashoperation").change(function () {
            var text = $(this).find(":selected").text();
            if (text.toUpperCase() == "DRAIN") {
                $("#ddlWaterTypes").attr('disabled', 'disabled');
                $("#ddlWaterTypes").parent('.select-wrapper').addClass("disabled");
                $("#divProduct").hide();
                $("#divTemperature").hide(); $("#divWaterLevel").hide();
            }
            else {
                $("#ddlWaterTypes").attr('disabled', false);
                $("#ddlWaterTypes").parent('.select-wrapper').removeClass("disabled");
                $("#divProduct").show();
            }
        })

        $("#btnAddWashStep").click(function () {
            $('#ddlChemicals option[value="0"]').attr("selected", "selected");
            $('#ddlChemicals').next(".holder").text('Select Product');
            $('#ddlChemicals option[value='+ProductId +']').attr("selected", "selected");
            if (ProductId != '' && ProductName != '') {
                var rows = _this.dynamicTable(ProductId, ProductName, count);
                count = count + 1;
                ProductId = ProductName = '';
            }

            return false;
        });
        container.find("#btnCancel").click(function () {
            _this.onCancelClicked();
        });

        container.find('#ddlChemicals').change(function () {
            ProductId = $('#ddlChemicals option:selected').val();
            ProductName = $('#ddlChemicals option:selected').text();
            
        });
      
      },
    validate: function () {
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;

        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               $.GetLocaleKeyValue('FIELD_PLEASECHECKYOURINPUT','Please check your input.')
       );
        var timeFormat = /^(?:[0-9]?[0-9]):[0-9][0-9]$/;
        $("#txtRunTime").mask('00:00');
       
        var v1 = $('#frmWashStep').validate({
            rules: {
                txtWaterLevel: { required: true, number: true },
                txtRunTime: { required: true,regex:timeFormat },
                txtTemperature: { required: true, number: true, min: 0, max: 200 },
                oper: {
                    required: true
                },
                txtQuantity: { required: true },
                water: {
                    required: true
                },
            },
            messages: {
                txtWaterLevel: {
                    required: $.GetLocaleKeyValue('FIELD_WATERLEVELCANNOTBEEMPTY','Water level cannot be empty.'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO200','Please enter  between 0 to 200'),
                        max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO200','Please enter  between 0 to 200'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERVALIDNUMBER','Please enter valid number')

                },
                txtRunTime: { required: $.GetLocaleKeyValue('FIELD_RUNTIMECANNOTBEEMPTY', 'Runtime cannot be Empty.'), regex: 'Enter runtime in mm:ss format' },
                txtTemperature: { required: $.GetLocaleKeyValue('FIELD_TEMPERATURECANNOTBEEMPTY', 'Temperature cannot be Empty.') },
                txtTemperature: { required: $.GetLocaleKeyValue('FIELD_TEMPERATURECANNOTBEEMPTY', 'Temperature cannot be Empty.') },
                oper: { required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWASHOPERATION','Please select Wash operation') },
                water: { required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWATERTYPE', 'Please select Water Type') },
                txtQuantity: { required: $.GetLocaleKeyValue('FIELD_QUANTITYCANNOTBEEMPTY', 'Quantity cannot be Empty.') },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });
        var v2 = $('#frmWashStep').valid();
        return v2;
    },
    onBackToFormulasClicked: function () {
        if (this.options.eventHandlers.onFormulaTabClick) {
            this.options.eventHandlers.onFormulaTabClick();
        }
    },

    onBackToWashStepsClicked: function () {
        if (this.options.eventHandlers.onBackToWashStepsClick) {
            this.options.eventHandlers.onBackToWashStepsClick(this.data.WasherGroupFormulaDetails[0].Id);
        }
    },
    getWashStepData: function () {
        var container = $(this.options.containerSelector);
        var table = $("#tblAddWashstepProducts tbody");
        var tablearr = [];
        var Id = 0;
        if (this.data.Mode == "Edit")
            Id = this.data.WasherGroupFormulaWashStepModel[0].Id;
        var formulaId = this.data.WasherGroupFormulaDetails[0].Id;
        var _this = this;
        table.find('tr').each(function (i, el) {
            var $tds = $(this).find('td');
            InjectionNumber = $tds.eq(1).text();
            ProductName = $tds.eq(2).text();
            ProductId = $tds.eq(2).find('span').attr('chem-id');
            Quantity = $tds.eq(3).find('input[type=text]').val();
            if (ProductName != "" || Quantity != "") {
                tablearr.push({
                    InjectionNumber: InjectionNumber,
                    ProductId: ProductId,
                    ProductName: ProductName,
                    EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                    Quantity: Quantity,
                    WasherDosingSetupId: Id
                });
            }

        });

        var runtime = container.find("#txtRunTime").val();
        var times = []; var minutes = 0; var seconds = 0; var runTimeFormat = 0;
        times = runtime.split(':');
        minutes = parseInt(times[0] * 60);
        seconds = parseInt(times[1]);
        runTimeFormat = minutes + seconds;
        runtime = runTimeFormat;

        var WasherFormulaWashStepModel = {
            Id: Id,
            ProgramSetupId: formulaId,
            StepNumber: container.find("#txtWashStepNumber").val(),
            WashOperationId: container.find("#ddlWashoperation").val(),
            RunTime: runtime,
            Temperature: container.find("#txtTemperature").val(),
            WaterType: container.find("#ddlWaterTypes").val(),
            WaterLevel: container.find("#txtWaterLevel").val(),
            DrainDestinationId: container.find("#ddlDrainDestination").val(),
            Note: container.find("#txtNotes").val(),
            PHLevel: 2,
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber,
            WasherDosingProducts: tablearr
        }

        return WasherFormulaWashStepModel;
    },
    saveWashStep: function () {
        if (this.options.eventHandlers.saveWashStep)
            this.options.eventHandlers.saveWashStep();
    },
    GetWashStepDetails: function (id) {
        if (this.options.eventHandlers.GetWashStepDetails)
            this.options.eventHandlers.GetWashStepDetails(id);
    },
    GetNextStep: function () {
        var id = $('#ddlWashSteps option:selected').next('option').val();
        if (id) {
            if (this.options.eventHandlers.GetWashStepDetails)
                this.options.eventHandlers.GetWashStepDetails(id);
        }
    },
    GetPrevStep: function () {
        var id = $('#ddlWashSteps option:selected').prev('option').val();
        if (id) {
            if (this.options.eventHandlers.GetWashStepDetails)
                this.options.eventHandlers.GetWashStepDetails(id);
        }
    },
    onWashStepCreationSuccess: function (data) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_WASHSTEPSAVEDSUCCESSFULLY", 'WashStep Saved Successfully'));
    },
    onWashStepCreationFailed: function (exception) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception);
    },
    dynamicTable: function (ProductId, ProductName, count) {

        var rows = "<tr>"
                            + "<td class=\"tableRows  align-center\"> <a class=\"deleteWashStep\"  chem-id=" + count + "><span chem-id=" + count + " class='k-icon k-delete noneditable'></span></a></td>"
                            + "<td class=\"tableRows align-left\"> <span chem-id=" + ProductId + ">" + count + "</span></td>"
                            + "<td class=\"tableRows\"><span chem-id=" + ProductId + " >" + ProductName + "</span></td>"
                            + "<td class=\"tableRows\"><input type='text' value=\"0 \" class='form-control k-input k-textbox trackChange quantity RequiredValidation' id='txtQuantity_" + count + " name='txtQuantity_" + count + " /><span class='k-error-message'></span></td>"
                            + "</tr>";
        $("#tblAddWashstepProducts tbody").append(rows);
        rows = ProductId = ProductName = '';

        $("#txtProduct").val('');
        return rows;
    },
    draindestinations: function (id) {
        var drainTypes = {
            0: { value: 0, name: "Blank" },
            1: { value: 1, name: "Reused" },
            2: { value: 2, name: "Recycled" },
            3: { value: 2, name: "Sewer" }
        };
        return (id != 'undefined' || id != 'NaN') ? drainTypes[id].name : 0;
    },
    waterType: function (id) {
        if (id) {
            var waterTypes = {
                1: { value: 1, name: "Cold" },
                2: { value: 2, name: "Hot" },
                3: { value: 3, name: "Tempered" },
                4: { value: 4, name: "Waste" }

            };
            return (id != 'undefined' || id != 'NaN') ? waterTypes[id].name : 0;
        }
        else {
            return (id == 'undefined' || id == 'NaN') ? waterTypes[1].name : 0; 
        }
        
    },
    onCancelClicked: function () {
        if (this.options.eventHandlers.onFormulaBackButtonClick)
            this.options.eventHandlers.onFormulaBackButtonClick();
    },
    clearMessage: function () {
        $("#errorDiv_msg").empty();
    }

}
$.validator.addMethod("RequiredFields", $.validator.methods.required, $.GetLocaleKeyValue('FIELD_QUANTITYCANNOTBEEMPTY', 'Quantity cannot be Empty.'));
$.validator.addMethod("RequiredFieldsNumber", $.validator.methods.number, "Enter only numbers.");
$.validator.addClassRules("RequiredValidation", { RequiredFields: true, RequiredFieldsNumber: true });
