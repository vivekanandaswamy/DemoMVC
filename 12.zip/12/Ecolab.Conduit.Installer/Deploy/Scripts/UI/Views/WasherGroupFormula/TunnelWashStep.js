Ecolab.Views.TunnelWashStep = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.productData = null;
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'TunnelWashStep',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/TunnelWashStep.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.TunnelWashStep.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        if (data.TunnelWashStepsModel == null)
            data.TunnelWashStepsModel = 0;
        this.data = data;
        this.tm.Render(data, this);
        if (data.TunnelWashStepsModel[0].WaterInletDrain == 'Drain') {
            $("#ddlWashoperation option:contains(Drain)").attr('selected', 'selected');
            $('#ddlWashoperation').trigger('change');
            $("#ddlWashoperation").attr("disabled", "disabled");
            $("#ddlWashoperation").parent(".select-wrapper").addClass('disabled');
        }
        else {
            $("#ddlWashoperation").removeAttr("disabled");
            $("#ddlWashoperation").parent(".select-wrapper").removeClass('disabled');
        }

    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#ddlWashoperation').trigger('change');
        $('.qunatity').trigger('change');
        if (this.options.eventHandlers.madeChangeFalse) {
            this.options.eventHandlers.madeChangeFalse();
            
        }
        $(".buttonTrack").attr("disabled", "disabled");
       // $('.placeholder').mask("00/00/0000", { placeholder: "__/__/____" });
        $("#txtRunTime").mask('00:00', { placeholder: "__:__" });
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#back").click(function () {
            _this.clearStatusMessage();
            _this.onBackToFormulasClicked();
        });

                container.find('#btnTunnelWashStepPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                WasherGroupId: _this.options.accountInfo.WasherGroupId,
                PageTitle: "Tunnel Compartment List",
                ProgramSetupId: _this.data.WasherGroupFormulaDetails[0].Id,
                CompartmentNumber: container.find("#ddlTunnelStep option:selected").text() == "" ? 0 : container.find("#ddlTunnelStep option:selected").text(),
                RegionId: _this.data.accountInfo.RegionId,
                NumberOfCompartments: _this.options.accountInfo.Compartments == null ? 0 : _this.options.accountInfo.NoofCompartments
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });
        container.find("#btnSaveWashStep").click(function () {
            _this.clearStatusMessage();
            if (_this.validateWasherStep()) {
                _this.saveWashStep();
            }
        });
        container.find("#lnkPrev").click(function () {
            _this.clearStatusMessage();
            _this.GetPrevStep();
        });

        container.find("#lnkNext").click(function () {
            _this.clearStatusMessage();
            _this.GetNextStep();
        });
        container.find("#ddlWashoperation").change(function () {
            if ($("#ddlWashoperation option:not(.empty):selected").text() == "Drain") {
                container.find("#divWaterTypes span").addClass("disabled");
                container.find("#ddlWaterTypes").attr("disabled", "disabled");
                $("#divtblQuantity").hide();
            }
            else {
                container.find("#divWaterTypes span").removeClass("disabled");
                container.find("#ddlWaterTypes").removeAttr("disabled");
                $("#divtblQuantity").show();
            }
           // _this.clearStatusMessage();
        });
        container.find("#ddlTunnelStep").change(function () {
            //_this.clearStatusMessage();
            var wgid = $("lblwgId").attr("wgid");
            _this.GetCompartmentDetails($("#ddlTunnelStep").val());
        });
        container.find("#lnkGridView").click(function () {
            _this.clearStatusMessage();
            _this.swapView();
        });
        container.find(".inActiveComp").click(function () {
            _this.clearStatusMessage();
            var washStepId = $(this).attr("wgId");
            _this.GetCompartmentDetails(washStepId);
        });
        container.find(".quantity").change(function () {
            ////_this.clearStatusMessage();
            //var Id = $(this).attr('id');
            //Id = Id.replace("txtQuantity_", "");
            //if ($("#txtQuantity_" + Id).val() > 0) {
            //    $("#txtDelayTime_" + Id).removeAttr("disabled");
            //}
            //else {
            //    $("#txtDelayTime_" + Id).attr("disabled", "disabled");
            //}
        });
        container.find("#btnCancel").click(function () {
            _this.clearStatusMessage();
            _this.CancelPage();
        });
    },

    onBackToFormulasClicked: function () {
        if (this.options.eventHandlers.onFormulaTabClick) {
            this.options.eventHandlers.onFormulaTabClick();
        }
    },
    getWashStepData: function () {
        var container = $(this.options.containerSelector);
        var table = $("#tblAddWashstepProducts tbody");
        var tablearr = [];
        var washStepDataArr = [];
        var Id = this.data.TunnelWashStepsModel[0].Id;
        var formulaId = this.data.WasherGroupFormulaDetails[0].Id;
        var groupId = this.data.WasherGroupDetails[0].WasherGroupId;
        var _this = this;

        var runtime = container.find("#txtRunTime").val();
        var times = []; var minutes = 0; var seconds = 0; var runTimeFormat = 0;
        times = runtime.split(':');
        minutes =parseInt(times[0] * 60);
        seconds = parseInt(times[1]);
        runTimeFormat = minutes + seconds;
        runtime = runTimeFormat;
        
        table.find('tr').each(function (i, el) {
            var $tds = $(this).find('td');
            ProductName = $tds.eq(0).text();
            ProductId = $tds.eq(0).find('span').attr('chem-id');
            Quantity = $tds.eq(1).find('input[type=text]').val();
            DelayTime = 0;// $tds.eq(2).find('input[type=text]').val();
            controllerequipmentsetupid = $tds.eq(0).find('span').attr('ctrl-setupid');
            if (ProductName != "" || Quantity != "") {
                tablearr.push({
                    InjectionNumber: 0,
                    ProductId: ProductId,
                    ProductName: ProductName,
                    EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                    Quantity: Quantity,
                    GroupId: groupId,
                    CompartmentNumber: container.find("#ddlTunnelStep option:selected").text(),
                    TunnelDosingProductMappingId: 0,
                    controllerequipmentsetupid: controllerequipmentsetupid,
                    TunnelDosingSetupId: Id,
                    DelayTime: DelayTime
                });
            }

        });
       
        washStepDataArr.push({
            TunnelDosingSetupId: Id,
            //ProgramNumber: 1,
            TunnelProgramSetupId: formulaId,
            GroupId: groupId,
            CompartmentNumber: container.find("#ddlTunnelStep option:selected").text(),
            StepTypeId: container.find("#ddlWashoperation").val(),
            //WashOperation: "",
            StepRunTime: runtime,
            Temperature: container.find("#txtTemperature").val(),
            WaterType: container.find("#ddlWaterTypes").val(),
            WaterLevel: container.find("#txtWaterLevel").val(),
            WaterInletDrain: container.find("#spanWaterInlet").text(),
            //DrainDestinationId: container.find("#ddlDrainDestination").val(),
            //DrainDestination:"Sewer",
            Notes: container.find("#txtNotes").val(),
            PHLevel: 2,
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber,
            ProductsList: tablearr
        });
         var WasherFormulaWashStepModel = washStepDataArr;
        return WasherFormulaWashStepModel;
    },
    saveWashStep: function () {
        if (this.options.eventHandlers.saveTunnelWashStep)
            this.options.eventHandlers.saveTunnelWashStep();
    },
    validateWasherStep: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var timeFormat = /^(?:[0-9]?[0-9]):[0-9][0-9]$/;

        $.validator.addMethod(
              "regex",
              function (value, element, regExp) {
                  var check = false;
                  var re = new RegExp(regExp);
                  return this.optional(element) || re.test(value);
              },
              "Please check your input."
      );
        var v1 = container.find('#frmTunnelWashStep').validate({
            rules: {
                txtTemperature: { required: true, min: 0, max: 200 },   
                txtWaterInlet: { required: true, digits: true },
                txtRunTime: { required: true,regex:timeFormat },
                txtWaterLevel: { required: true },
                txtQuantity: { required: true },
                washoprn: { required: true },
                watertype: { required: true },
            },
            messages: {
                txtTemperature: {
                    required: $.GetLocaleKeyValue('FIELD_TEMPERATURECANNOTBEEMPTY', 'Temperature cannot be Empty.'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO200', 'Please enter  between 0 to 200'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO200', 'Please enter  between 0 to 200')
                },
                txtWaterInlet: { required: $.GetLocaleKeyValue('FIELD_WATERINLETCANNOTBEEMPTY', 'Water Inlet cannot be Empty.') },
                txtRunTime: { required: $.GetLocaleKeyValue('FIELD_RUNTIMECANNOTBEEMPTY', 'Runtime cannot be Empty.'),regex:'Enter runtime in mm:ss format' },
                txtWaterLevel: { required: $.GetLocaleKeyValue('FIELD_WATERLEVELCANNOTBEEMPTY', 'Water level cannot be Empty.') },
                txtQuantity: { required: $.GetLocaleKeyValue('FIELD_QUANTITYCANNOTBEEMPTY', 'Quantity cannot be Empty.') },
                washoprn: { required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWASHOPERATION', 'Please Select Wash Operation.') },
                watertype: { required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWATERTYPE', 'Please Select Water Type.') }
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });

        var v2 = container.find('#frmTunnelWashStep').valid();
        return v2;
    },
    onWashStepCreationSuccess: function (data) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_WASHSTEPSAVEDSUCCESSFULLY", 'WashStep Saved Successfully'));
    },
    onWashStepCreationFailed: function (exception) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append($.GetLocaleKeyValue("FIELD_WASHSTEPSAVEFAILED", 'WashStep Save Failed'));
    },
    GetNextStep: function () {
        var id = $('#ddlTunnelStep option:selected').next('option').val();
        if (id) {
            this.GetCompartmentDetails(id);
        }
    },
    GetPrevStep: function () {
        var id = $('#ddlTunnelStep option:selected').prev('option').val();
        if (id) {
            this.GetCompartmentDetails(id);
        }
    },
    saveTunnelWashStep: function () {
        if (this.options.eventHandlers.saveTunnelWashStep) {
            this.options.eventHandlers.saveTunnelWashStep();
        }
    },

    GetCompartmentDetails: function (compId) {
        if (compId == undefined) { compId = $("#ddlTunnelStep option:selected").val(); }
        if (compId) {
            var washergroupId = this.data.WasherGroupDetails[0].WasherGroupId;
            var formulaId = this.data.WasherGroupFormulaDetails[0].Id;
            if (this.options.eventHandlers.GetCompartmentDetails)
                this.options.eventHandlers.GetCompartmentDetails(formulaId, compId, washergroupId);
        }
    },
    onGridViewClicked: function () {
        if (this.options.eventHandlers.onGridViewClicked) {
            var fId = this.data.WasherGroupFormulaDetails[0].Id;
            var groupId = this.data.WasherGroupDetails[0].WasherGroupId;
            this.options.eventHandlers.onGridViewClicked(fId, groupId);
        }
    },
    swapView: function () {
        if (this.options.eventHandlers.swapView)
            this.options.eventHandlers.swapView();
    },
    CancelPage: function () {
        if (this.options.eventHandlers.onRedirection)
            this.options.eventHandlers.onRedirection();
    },
    clearStatusMessage: function () {
        //$("#errorDiv_msg").empty();
        if (this.options.eventHandlers.clearMessage)
            this.options.eventHandlers.clearMessage();
    },



}
$.validator.addMethod("RequiredFields", $.validator.methods.required, $.GetLocaleKeyValue('FIELD_QUANTITYCANNOTBEEMPTY', 'Quantity cannot be Empty.'));
$.validator.addMethod("RequiredFieldsNumber", $.validator.methods.number, "Enter only numbers.");
$.validator.addClassRules("RequiredValidation", { RequiredFields: true, RequiredFieldsNumber: true });

$.validator.addMethod("DelayRequiredFields", $.validator.methods.required, "Delay Time Cannnot be Empty.");
$.validator.addMethod("DelayRequiredFieldsNumber", $.validator.methods.digits, "Enter only numbers.");
$.validator.addClassRules("DelayRequiredValidation", { DelayRequiredFields: true, DelayRequiredFieldsNumber: true });
