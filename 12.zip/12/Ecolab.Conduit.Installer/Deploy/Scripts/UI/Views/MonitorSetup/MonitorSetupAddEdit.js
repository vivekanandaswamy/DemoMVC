﻿Ecolab.Views.MonitorSetupAddEdit = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDashboardTypeChange: null,
            onMonitorsChange: null,
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/MonitorSetup/MonitorSetupAddEdit.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    var isEdit = false;
};

Ecolab.Views.MonitorSetupAddEdit.prototype = {

    setData: function (data) {
        this.data = data;
        isEdit = false;
        this.tm.Render(data, this);
        if (data.Machines != null) {
            this.loadMachines(data.Machines);
        }
        if (data.Displays!= null) {
            this.loadMonitors(data.Displays);
        }
        if (data.DashboardId > 0) {
            isEdit = false;
            this.selectDefaults(data);
        }
    },

    loadMonitors: function (data) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var ddlMonitorName = container.find('#ddlMonitorName');
        ddlMonitorName.empty();
        if (data.length > 0) {
            $.each(data, function () {
                ddlMonitorName.append('<option value="' + this.MonitorId + '">' + this.MonitorName + '</option>');
            });
        }
        _this.multiSelect(ddlMonitorName, null);
        $(".multiselect-custom .multiselect").css("width", $(".select-wrapper").width() + 2 + 'px');
       
         },
    //for editing
    selectDefaults: function (data) {
        var ddlMachineName = $('#ddlMachineName');
        var dataarray = [];
        $.each(data.SelectedMachines, function (index, machine) {
            dataarray.push(machine.MachineId);
        })
        ddlMachineName.multiselect('select', dataarray);
        ddlMachineName.multiselect("refresh");

        var ddlMonitorName = $('#ddlMonitorName');
        var dataarray = [];
        $.each(data.SelectedDisplays, function (index, monitor) {
            dataarray.push(monitor.MonitorId);
        })
        ddlMonitorName.multiselect('select', dataarray);
        ddlMonitorName.multiselect("refresh");
        if ($('#ddlDashboardType').val() == '2') {
            if ($('#ddlMachineName').val().length >= 3) {
                $('#cbEnableParameter').attr('checked', false);
                $('#cbEnableParameter').attr('disabled', 'disabled');
            }
            else {
                $('#cbEnableParameter').removeAttr('disabled');
            }
        }
    },

    loadMachines: function (data) {
        var _this = this;
        var ddlMachineName = $('#ddlMachineName');
        ddlMachineName.empty();
        if (data.length > 0) {
            $.each(data, function () {
                ddlMachineName.append('<option value="' + this.MachineId + '">' + this.MachineName + '</option>');
            });
        }
        _this.multiSelect(ddlMachineName, null);
        $(".multiselect-custom .multiselect").css("width", $(".select-wrapper").width() + 2 + 'px');
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        var container = $(this.options.containerSelector);
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $(".multiselect-custom .multiselect").css("width", $(".select-wrapper").width() + 2 + 'px');
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        function centerModal() {
            $("#monitorModal").css('display', 'block');
            var $dialog = $("#monitorModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        container.find('#ddlMachineName').multiselect({ nonSelectedText: '--select--' });
        container.find('#ddlMonitorName').multiselect({ nonSelectedText: '--select--' });
        container.find('#ddlMachineName').multiselect().end();
        container.find('#ddlMonitorName').multiselect().end();

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });

        //Cascading data for Machine/Compartment basing on Dashboard type
        container.find("#ddlDashboardType").change(function () {
            if (container.find("#ddlDashboardType").val().trim() != "") {
                _this.onDashboardTypeChange(container.find("#ddlDashboardType").val());
            }
        });

        //To save data
        container.find("#btnUpdate").click(function () {
            _this.onSaveClicked();
        });

        container.find("#btnCancel").click(function () {
            $("#monitorModal").modal('toggle');
        });

        container.find("#monitorsDiv").find('button').click(function () {
            if (container.find('#ddlMonitorName').find('option').length == 0) {
                _this.getMonitorsonAdd();
            }
        });

        container.find('#ddlMachineName').change(function () {
            if (container.find('#ddlDashboardType').val() == '2') {
                if (container.find('#ddlMachineName').val().length >= 3) {
                    container.find('#cbEnableParameter').attr('checked', false);
                    container.find('#cbEnableParameter').attr('disabled', 'disabled');
                }
                else {
                    container.find('#cbEnableParameter').removeAttr('disabled');
                }
            }
        })
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        $('.divMsg').html('');
    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmAddEditMonitor').validate({
            rules: {
                txtDashboardName: {
                    required: true,
                },

                ddlDashboardType: {
                    required: true,
                },

                'machine name': {
                    required: true,
                },

                'monitor name': {
                    required: true
                }

            },

            messages: {
                txtDashboardName: {
                    required: "Please enter dashboard name"
                },

                ddlDashboardType: {
                    required: "Please select dashboard type"
                },

                'machine name': {
                    required: "Please select a machine"
                },

                'monitor name': {
                    required: "Please select a monitor"
                }
            },

            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },

            onsubmit: true,
            onkeyup: true,
            focusInvalid: false,
            ignore: ':hidden:not("#ddlMonitorName,#ddlMachineName")',
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }

            }
        });

        var v2 = container.find('#frmAddEditMonitor').valid();
        return v2;

    },

    onDashboardTypeChange: function (id) {
        var _this = this;
        var container = $(this.options.containerSelector);
        $(container).find('#ddlMachineName').empty();
        container.find("#ddlMachineName").next('.holder').html('-- select --');
        if (_this.options.eventHandlers.onDashboardTypeChange) {
            _this.options.eventHandlers.onDashboardTypeChange(id);
        }
    },

    onSaveClicked: function () {
        var _this = this;
        if (_this.validate() == true) {
            if (typeof (_this.checkLimits()) === 'undefined') {
                if (this.options.eventHandlers.onSaveClicked) {
                    this.options.eventHandlers.onSaveClicked(this.getMonitorSetupData());
                }
            }
            else {
                var messageDiv = $('.divMsg');
                messageDiv.html(_this.checkLimits());
                return false;
            }
        }
        else {
            return false;
        }

    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        if (message == "701") {
            errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DASHBOARDNAMEALREADYEXISTS', 'Dashboard name already exists') + '</label>';
        }
        var messageDiv = $('.divMsg');
        messageDiv.html(errLabel);
    },

    getMonitorSetupData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var lstMonitorSetupModel = [];

        var ddlMachineName = container.find('#ddlMachineName').val();
        var ddlMonitorName = container.find('#ddlMonitorName').val();
        $.each(ddlMachineName, function (index, data) {
            $.each(ddlMonitorName, function (index, monitorData) {
                var monitorSetupModel = {};
                monitorSetupModel.IsEdit = isEdit;
                monitorSetupModel.IsDeleteMapping = true;
                monitorSetupModel.DashboardId = container.find('#btnUpdate').attr('data-dashboardid');
                monitorSetupModel.Id = container.find('#btnUpdate').attr('data-id');
                monitorSetupModel.DashboardName = container.find('#txtDashboardName').val();
                monitorSetupModel.WasherGroupTypeId = container.find('#ddlDashboardType').val();
                monitorSetupModel.WasherGroupTypeName = container.find('#ddlDashboardType option:selected').text().trim();
                monitorSetupModel.WasherId = data;
                monitorSetupModel.MonitorId = monitorData;
                monitorSetupModel.IsEnableParameter = container.find('#cbEnableParameter').is(':checked');
                monitorSetupModel.Customer = container.find('#cbCustomer').is(':checked');
                monitorSetupModel.Formula = container.find('#cbFormula').is(':checked');
                monitorSetupModel.Load = container.find('#cbLoad').is(':checked');
                monitorSetupModel.DisplayOnLogin = container.find('#cbDisplayonLogin').is(':checked');
                lstMonitorSetupModel.push(monitorSetupModel);
            });

        })
        return lstMonitorSetupModel;
    },

    multiSelect: function (ddlMachines, selectData) {
        ddlMachines.multiselect("destroy").multiselect({
            nonSelectedText: '-- select --',
            numberDisplayed: 1,
            disableIfEmpty: true,
            autoOpen:true,
            onChange: function (option, checked) {
                if (checked) {
                    var selected = [];
                    $(ddlMachines).find(":selected").each(function (index, machine) {
                        selected.push([$(this).val()]);
                    });
                }
            }
        });
        //Selecting the dropdown
        if (selectData) {
            var dataarray = selectData.split(",");
            ddlMachines.multiselect('select', dataarray);
            ddlMachines.multiselect("refresh");
        }

    },

    //Function to check maximum Conventional/Tunnel limits(3 Tunnels and 12 conventionals is the maximum limit)
    checkLimits: function () {
        var container = $(this.options.containerSelector);
        if (container.find('#ddlDashboardType').val() == '2') {
            if (container.find('#ddlMachineName').val().length > 3) {
                return '<label class=k-error-message>' + 'Maximum 3 tunnels can be connected to dashboard' + '</label>';
            }
        }
        else {
            if (container.find('#ddlMachineName').val().length > 12) {
                return '<label class=k-error-message>' + 'Maximum 12 conventionals can be connected to dashboard' + '</label>';
            }
        }
    },

    getMonitorsonAdd: function () {
        if (this.options.eventHandlers.onMonitorsChange)
            this.options.eventHandlers.onMonitorsChange();
    }
}

