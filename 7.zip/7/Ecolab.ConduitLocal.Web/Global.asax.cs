﻿// -----------------------------------------------------------------------
// <copyright file="Global.asax.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WebApiApplication object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web
{
    using System;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;
    using System.Web.Script.Serialization;
    using System.Web.Security;
    using Controllers;
    using Infra;
    using Services;

    // Note: For instructions on enabling IIS6 or IIS7 classic mode,
    // visit http://go.microsoft.com/?LinkId=9394801

    /// <summary>
    ///     Class WebApiApplication
    /// </summary>
    public class WebApiApplication : HttpApplication
    {
        /// <summary>
        ///     To start an appliaction
        /// </summary>
        protected void Application_Start()
        {
            Bootstrapper.Bootstrap();
        }

        /// <summary>
        ///     Handles the AuthenticateRequest event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
            if (HttpContext.Current.User == null || !HttpContext.Current.User.Identity.IsAuthenticated || !(HttpContext.Current.User.Identity is FormsIdentity))
            {
                return;
            }
            HttpCookie authCookie = this.Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                if (authTicket != null)
                {
                    CustomPrincipalSerializeModel serializeModel = serializer.Deserialize<CustomPrincipalSerializeModel>(authTicket.UserData);
                    CustomPrincipal customPrincipal = new CustomPrincipal(authTicket.Name) { UserId = serializeModel.UserId, UserName = serializeModel.UserName, UserRoles = serializeModel.UserRoles, UserRoleIds = serializeModel.UserRoleIds, EcolabAccountNumber = serializeModel.EcolabAccountNumber, RegionId = serializeModel.RegionId, LanguageId = serializeModel.LanguageId, Locale = serializeModel.Locale };
                    HttpContext.Current.User = customPrincipal;
                    HttpCookie userCookie = new HttpCookie("UserCokkie") { Value = Convert.ToString(customPrincipal.UserId) };
                    this.Response.Cookies.Add(userCookie);
                }
            }
        }

        /// <summary>
        ///     Handles the Error event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = this.Server.GetLastError();
            //// Log the exception.
            this.Response.Clear();

            HttpException httpException = exception as HttpException;

            RouteData routeData = new RouteData();
            routeData.Values.Add("controller", "Error");

            if (httpException == null)
            {
                routeData.Values.Add("action", "Index");
            }
            else
            {
                ////It's an Http Exception, Let's handle it.
                switch (httpException.GetHttpCode())
                {
                    case 404:
                        //// Page not found.
                        routeData.Values.Add("action", "HttpError404");
                        break;

                    case 505:
                        //// Server error.
                        routeData.Values.Add("action", "HttpError505");
                        break;

                    //// Here you can handle Views to other error codes.
                    //// I choose a General error template
                    default:
                        routeData.Values.Add("action", "Index");
                        break;
                }
            }

            //// Pass exception details to the target error View.
            routeData.Values.Add("error", exception);

            //// Clear the error on server.
            this.Server.ClearError();

            //// Call target Controller and pass the routeData.
            IController errorController = new ErrorController();
            errorController.Execute(new RequestContext(new HttpContextWrapper(this.Context), routeData));
        }

        /// <summary>
        ///     Handles the Begin Request of the Application.
        /// </summary>
        protected void Application_BeginRequest()
        {
            if (this.Request.IsLocal)
            {
                //MiniProfiler.Start();
            }
        }

        /// <summary>
        ///     Handles the End Request of the Application.
        /// </summary>
        protected void Application_EndRequest()
        {
            //MiniProfiler.Stop();
        }

        /// <summary>
        ///     Handles the End event of the Session control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        protected void Session_End(object sender, EventArgs e)
        {
        }
    }
}