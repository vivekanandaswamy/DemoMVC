﻿// -----------------------------------------------------------------------
// <copyright file="RouteConfig.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RouteConfig object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web
{
    using System.Web.Http;
    using System.Web.Mvc;
    using System.Web.Routing;

    /// <summary>
    ///     Class RouteConfig
    /// </summary>
    public class RouteConfig
    {
        /// <summary>
        ///     The Register Routes
        /// </summary>
        /// <param name="routes">The route path</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapHttpRoute("DefaultApi", "api/{controller}/{action}/{id}", new { id = RouteParameter.Optional });

            routes.MapRoute("Default", "{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = UrlParameter.Optional });
        }
    }
}