﻿// -----------------------------------------------------------------------
// <copyright file="WebApiConfig.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WebApiConfig object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web
{
    /// <summary>
    ///     Class WebApiConfig
    /// </summary>
    public class WebApiConfig
    {
    }
}