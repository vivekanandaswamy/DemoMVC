﻿// -----------------------------------------------------------------------
// <copyright file="HomeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The HomeModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     class HomeModel
    /// </summary>
    public class HomeModel
    {
        /// <summary>
        ///     Gets or sets Language
        /// </summary>
        /// <value>Language</value>
        public LanguageModel Language { get; set; }

        /// <summary>
        ///     Gets or sets LogOnModel
        /// </summary>
        /// <value>Log On Model</value>
        public LogOnModel LogOnModel { get; set; }

        /// <summary>
        ///     Gets or sets UserProfile
        /// </summary>
        /// <value>User Profile</value>
        public UserProfileModel UserProfile { get; set; }

        /// <summary>
        ///     Gets or sets LanguageId
        /// </summary>
        /// <value>Language Id</value>
        public int LanguageId { get; set; }
    }
}