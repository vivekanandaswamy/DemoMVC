﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Contact Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     class PlantContactModel
    /// </summary>
    public class PlantContactModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// ///
        /// <value> Plant contact Id.</value>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets  ContactFirstName
        /// </summary>
        /// <value> Contact First Name </value>
        public string ContactFirstName { get; set; }

        /// <summary>
        ///     Gets or sets ContactLastName
        /// </summary>
        /// <value> Contact Larst Name </value>
        public string ContactLastName { get; set; }

        /// <summary>
        ///     Gets or sets ContactTitle
        /// </summary>
        /// <value> Contact Title </value>
        public string ContactTitle { get; set; }

        /// <summary>
        ///     Gets or sets ContactPosition
        /// </summary>
        /// <value> Contact Position </value>
        public int ContactPositionId { get; set; }

        /// <summary>
        ///     Gets or sets ContactPosition
        /// </summary>
        /// <value> Contact Position </value>
        public string ContactPositionName { get; set; }

        /// <summary>
        ///     Gets or sets ContactEmailAdresss
        /// </summary>
        /// <value> Contact Email Adresss </value>
        public string ContactEmailAdresss { get; set; }

        /// <summary>
        ///     Gets or sets ContactOfficePhone
        /// </summary>
        /// <value> Contact Office Phone </value>
        public string ContactOfficePhone { get; set; }

        /// <summary>
        ///     Gets or sets ContactMobilePhone
        /// </summary>
        /// <value> Contact Mobile Phone </value>
        public string ContactMobilePhone { get; set; }

        /// <summary>
        ///     Gets or sets ContactFaxNumber
        /// </summary>
        /// <value> Contact Fax Number </value>
        public string ContactFaxNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Action type
        /// </summary>
        /// <value>ActionType</value>
        public int ActionType { get; set; }

        /// <summary>
        ///     Gets or sets the Ecolab Account Number
        /// </summary>
        /// <value>EcolabAccountNumber</value>
        public string EcolabAccountNumber { get; set; }

        #endregion
    }
}