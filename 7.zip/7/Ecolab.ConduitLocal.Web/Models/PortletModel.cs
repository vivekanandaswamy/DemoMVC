﻿// -----------------------------------------------------------------------
// <copyright file="PortletModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Portlet Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Class Portlet
    /// </summary>
    public class PortletModel
    {
        /// <summary>
        ///     Gets or sets the PortletId.
        /// </summary>
        /// <value>The PortletId field</value>
        public int PortletId { get; set; }

        /// <summary>
        ///     Gets or sets the ReportId.
        /// </summary>
        /// <value>The ReportId field</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value>The Name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder.
        /// </summary>
        /// <value>The DisplayOrder. field</value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the IsEnabled.
        /// </summary>
        /// <value>The IsEnabled. field</value>
        public bool IsEnabled { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }
    }
}