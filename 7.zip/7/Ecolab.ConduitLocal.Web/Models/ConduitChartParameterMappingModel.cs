﻿// -----------------------------------------------------------------------
// <copyright file="ConduitChartParameterMappingModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConduitChartParameterMappingModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model for ConduitChartParameterMapping
    /// </summary>
    public class ConduitChartParameterMappingModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets ParameterId
        /// </summary>
        /// <value> ParameterId .</value>
        public int ParameterId { get; set; }

        /// <summary>
        ///     Gets or sets ParameterName
        /// </summary>
        /// <value>Parameter Name.</value>
        public string ParameterName { get; set; }

        /// <summary>
        ///     Gets or sets MinValue
        /// </summary>
        /// <value> Min Value. </value>
        public int MinValue { get; set; }

        /// <summary>
        ///     Gets or sets MaxValue
        /// </summary>
        /// <value> Max Value. </value>
        public int MaxValue { get; set; }

        #endregion
    }
}