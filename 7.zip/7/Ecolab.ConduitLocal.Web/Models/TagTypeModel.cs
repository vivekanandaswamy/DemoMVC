﻿// -----------------------------------------------------------------------
// <copyright file="TagTypeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Type Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     class TagTypeModel
    /// </summary>
    public class TagTypeModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets  TagTypeId
        /// </summary>
        /// <value>TagTypeId</value>
        public int TagTypeId { get; set; }

        /// <summary>
        ///     Gets or sets  TagType
        /// </summary>
        /// <value>TagType</value>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or sets  TagDescription
        /// </summary>
        /// <value>TagDescription</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///     Gets or sets  DataType
        /// </summary>
        /// <value>DataType</value>
        public string DataType { get; set; }

        /// <summary>
        ///     Gets or sets  Active
        /// </summary>
        /// <value>Active</value>
        public bool Active { get; set; }
    }
}