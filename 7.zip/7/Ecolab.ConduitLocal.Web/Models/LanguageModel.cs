﻿// -----------------------------------------------------------------------
// <copyright file="LanguageModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LanguageModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System.Collections.Generic;
    using System.Web.Mvc;

    /// <summary>
    ///     class LanguageModel
    /// </summary>
    public class LanguageModel
    {
        /// <summary>
        ///     Gets or sets Languages
        /// </summary>
        /// <value>Languages </value>
        public List<SelectListItem> Languages { get; set; }
    }
}