﻿// -----------------------------------------------------------------------
// <copyright file="TextileCategoryModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Currency Master </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model for TextileCategoryModel
    /// </summary>
    public class TextileCategoryModel
    {
        /// <summary>
        ///     Gets or sets TextileId
        /// </summary>
        /// <value> Textile Id.</value>
        public int TextileId { get; set; }

        /// <summary>
        ///     Gets or sets CategoryName
        /// </summary>
        /// <value> Category Name.</value>
        public string CategoryName { get; set; }
    }
}