﻿// -----------------------------------------------------------------------
// <copyright file="ErrorModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ErrorModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     class ErrorModel
    /// </summary>
    public class ErrorModel
    {
        /// <summary>
        ///     Gets or sets the error message.
        /// </summary>
        /// <value>The error message.</value>
        public string Message { get; set; }
    }
}