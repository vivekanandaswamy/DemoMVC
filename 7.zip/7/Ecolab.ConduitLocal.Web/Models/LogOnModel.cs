﻿// -----------------------------------------------------------------------
// <copyright file="LogOnModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LogOnModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System.ComponentModel.DataAnnotations;

    /// <summary>
    ///     class LogOnModel
    /// </summary>
    public class LogOnModel
    {
        /// <summary>
        ///     Gets or sets the UserName.
        /// </summary>
        /// <value>The name of the user.</value>
        [Required(ErrorMessage = "Please enter user name.")]
        [Display(Name = "Username")]
        public string UserName { get; set; }

        /// <summary>
        ///     Gets or sets the password
        /// </summary>
        /// <value>The password.</value>
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether to Remember the credentials.
        /// </summary>
        /// <value><c>true</c> if [remember me]; otherwise, <c>false</c>.</value>
        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }
}