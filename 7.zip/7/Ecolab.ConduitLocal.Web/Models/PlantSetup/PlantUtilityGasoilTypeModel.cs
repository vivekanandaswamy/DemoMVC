﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityGasoilTypeModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilityGasoilTypeModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    public class PlantUtilityGasoilTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets WaterTypeId
        /// </summary>
        /// <value>Water Type Id.</value>
        public int GasoilTypeId { get; set; }

        /// <summary>
        ///     Gets or sets WaterTypeName
        /// </summary>
        /// <value>Water Type Name.</value>
        public string GasoilTypeName { get; set; }

        #endregion
    }
}