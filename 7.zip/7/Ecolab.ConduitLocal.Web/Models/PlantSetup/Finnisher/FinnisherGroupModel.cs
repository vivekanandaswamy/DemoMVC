﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherGroupModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherGroupModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.Finnisher
{
    using System;
    using System.Collections.Generic;

    public class FinnisherGroupModel
    {
        public FinnisherGroupModel()
        {
            Finnishers = new List<FinnisherModel>();
        }

        /// <summary>
        ///     Gets or sets the FinnisherGroupId.
        /// </summary>
        /// <value> FinnisherGroupId. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherGroupName.
        /// </summary>
        /// <value> FinnisherGroupName. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Finnisher.
        /// </summary>
        /// <value> Finnisher. </value>
        public virtual FinnisherModel Finnisher { get; set; }

        /// <summary>
        ///     Gets or sets the value Finnisher Model List
        /// </summary>
        /// <value>Finnisher Model List</value>
        public List<FinnisherModel> Finnishers { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher Group
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisherGroup</value>
        public DateTime LastModifiedTimeStampFinnisherGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisher</value>
        public DateTime LastModifiedTimeStampFinnisher { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}