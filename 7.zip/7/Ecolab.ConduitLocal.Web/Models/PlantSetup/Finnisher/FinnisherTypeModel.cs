﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherTypeModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherType Model Class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.Finnisher
{
    public class FinnisherTypeModel
    {
        /// <summary>
        ///     Gets or sets the FinnisherType Id.
        /// </summary>
        /// <value> FinnisherType Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherType Name.
        /// </summary>
        /// <value> FinnisherType Name. </value>
        public string Name { get; set; }
    }
}