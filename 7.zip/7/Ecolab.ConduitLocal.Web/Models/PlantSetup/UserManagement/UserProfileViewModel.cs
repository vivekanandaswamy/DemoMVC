﻿// -----------------------------------------------------------------------
// <copyright file="UserProfileViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Profile View Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.UserManagement
{
    using System.Collections.Generic;

    /// <summary>
    ///     Model class UserProfileViewModel
    /// </summary>
    public class UserProfileViewModel
    {
        /// <summary>
        ///     Gets or sets UserManagementModel Object UserProfile
        /// </summary>
        /// <value>The UserManagement.</value>
        public UserManagementModel UserManagement { get; set; }

        /// <summary>
        ///     Gets or sets List of Languages
        /// </summary>
        /// <value>The Languages.</value>
        public List<LanguageMasterModel> Languages { get; set; }

        /// <summary>
        ///     Gets or sets the list of CurrencyCodes.
        /// </summary>
        /// <value> The CurrencyCodes.</value>
        public List<CurrencyMasterModel> CurrencyCodes { get; set; }

        /// <summary>
        ///     Gets or sets the list of Units of measures.
        /// </summary>
        /// <value> The measures.</value>
        public List<DimensionalUnitSystemsModel> Uoms { get; set; }

        /// <summary>
        ///     Gets or sets Result
        /// </summary>
        /// <value>The Result.</value>
        public string Result { get; set; }
    }
}