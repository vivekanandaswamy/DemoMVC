﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityDimesionTypesModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilityDimesionTypesModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    public class PlantUtilityDimesionTypesModel
    {
        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> The Price value.</value>
        public string Price { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value> The SubUnit.</value>
        public string ElectricPrice { get; set; }

        /// <summary>
        ///     Gets or sets the OrderID.
        /// </summary>
        /// <value> The OrderID.</value>
        public string GasPrice { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Unit System Id.</value>
        public string Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Unit System Id.</value>
        public string EnergyContent { get; set; }
    }
}