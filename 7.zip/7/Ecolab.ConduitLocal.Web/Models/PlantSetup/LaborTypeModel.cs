﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborType </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Web model class for LaborType
    /// </summary>
    public class LaborTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the LaborTypeId.
        /// </summary>
        /// <value> Labor TypeId.</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Labor type name.</value>
        public string Description { get; set; }

        #endregion
    }
}