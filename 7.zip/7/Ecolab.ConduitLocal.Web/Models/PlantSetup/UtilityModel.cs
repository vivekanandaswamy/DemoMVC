﻿// -----------------------------------------------------------------------
// <copyright file="UtilityModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Utility </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model class for UtilityModel(Water and Energy)
    /// </summary>
    public class UtilityModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceNumber.
        /// </summary>
        /// <value> Device Number.</value>
        public int? DeviceNumber { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceName.
        /// </summary>
        /// <value>The Parameter Device Name.</value>
        public string DeviceName { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Device Type.</value>
        public int DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceTypeDesc.
        /// </summary>
        /// <value> Device Type Name.</value>
        public string DeviceTypeDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModel.
        /// </summary>
        /// <value> Device Model.</value>
        public int DeviceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModelDesc.
        /// </summary>
        /// <value> Device Model Name.</value>
        public string DeviceModelDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceNote.
        /// </summary>
        /// <value> Device Note.</value>
        public string DeviceNoteDesc { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Comment.
        /// </summary>
        /// <value> The Comment.</value>
        public string Comment { get; set; }

        /// <summary>
        ///     Gets or sets the InstallDate.
        /// </summary>
        /// <value> Install Date.</value>
        public string InstallDate { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustWtrEnrgDvcGUID
        /// </summary>
        /// <value>MyServiceCustWtrEnrgDvcGUID</value> 
        public Guid MyServiceCustWtrEnrgDvcGUID { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Device Id.</value>
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Region Id
        /// </summary>
        /// <value>Region Id</value>
        public int RegionId { get; set; }

        #endregion
    }
}