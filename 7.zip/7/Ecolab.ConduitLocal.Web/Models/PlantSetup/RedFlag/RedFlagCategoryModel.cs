﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagCategoryModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagCategoryModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.RedFlag
{
    public class RedFlagCategoryModel
    {
      
            /// <summary>
            ///     Gets or sets the RedFlagCategoryId
            /// </summary>
            public int RedFlagCategoryId { get; set; }

            /// <summary>
            ///     Gets or sets the Name
            /// </summary>
            public string Name { get; set; }
       
    }
}