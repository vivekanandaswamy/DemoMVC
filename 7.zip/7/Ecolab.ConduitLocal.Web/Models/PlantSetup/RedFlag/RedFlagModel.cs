﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.RedFlag
{
    using System;

    /// <summary>
    ///     Class for RedFlag
    /// </summary>
    public class RedFlagModel
    {
        /// <summary>
        ///     Gets or sets the Id
        /// </summary>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets ItemId
        /// </summary>
        public int ItemId { get; set; }

        /// <summary>
        ///     Gets or sets ItemName
        /// </summary>
        public string ItemName { get; set; }

        /// <summary>
        ///     Gets or sets UOM
        /// </summary>
        public string UOM { get; set; }

        /// <summary>
        ///     Gets or sets MinRange
        /// </summary>
        public decimal MinimumRange { get; set; }

        /// <summary>
        ///     Gets or setsMaxRange
        /// </summary>
        public decimal MaximumRange { get; set; }

        /// <summary>
        ///     Gets or sets MinRange
        /// </summary>
        public string MinimumRangeAsString { get; set; }

        /// <summary>
        ///     Gets or setsMaxRange
        /// </summary>
        public string MaximumRangeAsString { get; set; }

        /// <summary>
        ///     Gets or sets LocaionId
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets LocationName
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets comma seperated Machine Id
        /// </summary>
        public string MachineIds { get; set; }

        /// <summary>
        ///     Gets or sets comma seperated Machine Name
        /// </summary>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the Mapping Id
        /// </summary>
        public int? MappingId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber
        /// </summary>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsSelected.
        /// </summary>
        /// <value> Is Selected. </value>
        public bool IsSelected { get; set; }

        /// <summary>
        ///     Gets or sets the MachineID.
        /// </summary>
        /// <value> Machine Id. </value>
        public int? MachineId { get; set; }

        /// <summary>
        ///     Gets or sets IsDirty
        /// </summary>
        public bool IsDirty { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets RedFlag Category Id
        /// </summary>
        /// <value> Red Flag Category Id </value>
        public int CategoryId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaCategoryId
        /// </summary>
        /// <value> FormulaCategoryId </value>
        public int? FormulaCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaId
        /// </summary>
        /// <value> FormulaId </value>
        public int? FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets ProductName
        /// </summary>
        /// <value> ProductName </value>
        public string FormulaName { get; set; }
        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> ProductId </value>
        public int? ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductName
        /// </summary>
        /// <value> ProductName </value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets MeterId
        /// </summary>
        /// <value> MeterId </value>
        public int? MeterId { get; set; }

        /// <summary>
        ///     Gets or sets MeterName
        /// </summary>
        /// <value> MeterName </value>
        public string MeterName { get; set; }

        /// <summary>
        ///     Gets or sets SensorId
        /// </summary>
        /// <value> SensorId </value>
        public int? SensorId { get; set; }

    }
}