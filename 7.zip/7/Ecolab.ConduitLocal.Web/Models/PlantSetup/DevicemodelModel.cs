﻿// -----------------------------------------------------------------------
// <copyright file="DevicemodelModel.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Devicemodel Model</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model calss for DevicemodelModel
    /// </summary>
    public class DevicemodelModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceModelId.
        /// </summary>
        /// <value> Device model id.</value>
        public int DeviceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Device model name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceTypeId.
        /// </summary>
        /// <value> Device type id.</value>
        public Int16 DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the RegionCode.
        /// </summary>
        /// <value> Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWtrEnrgDvcId.
        /// </summary>
        /// <value> MyServiceWtrEnrgDvcId.</value>
        public int MyServiceWtrEnrgDvcId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}