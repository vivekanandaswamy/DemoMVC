﻿// -----------------------------------------------------------------------
// <copyright file="UOMSensorModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The UOMSensorModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model  Entity class for SensorOutPutType
    /// </summary>
    public class UOMSensorModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> The Unit value.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value>The SubUnit.</value>
        public string SubUnit { get; set; }

        #endregion
    }
}