﻿// -----------------------------------------------------------------------
// <copyright file="FormulaSegmentModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>TheFormula Segment Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     class ProductMasterModel
    /// </summary>
    public class FormulaSegmentModel
    {
        #region "Properties"

        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        #endregion
    }
}