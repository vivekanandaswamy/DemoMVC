﻿// -----------------------------------------------------------------------
// <copyright file="UsageFactorModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Utility Setup </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     model class for UsageFactor
    /// </summary>
    public class UsageFactorModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the UsageTypeId.
        /// </summary>
        /// <value> Usage Type Id.</value>
        public int UsageTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the UsageDescription.
        /// </summary>
        /// <value> Usage Description.</value>
        public string UsageDescription { get; set; }

        #endregion
    }
}