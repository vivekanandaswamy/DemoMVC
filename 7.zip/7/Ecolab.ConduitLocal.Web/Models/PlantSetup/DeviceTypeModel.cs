﻿// -----------------------------------------------------------------------
// <copyright file="DeviceTypeModel.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Type Model </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model calss DeviceTypeModel
    /// </summary>
    public class DeviceTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceTypeId.
        /// </summary>
        /// <value> Device type id.</value>
        public int DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Device type name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the Region Code.
        /// </summary>
        /// <value>The Region Code.</value>
        public int RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is Deleted. </value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceDeviceTypeId.
        /// </summary>
        /// <value>MyServiceDeviceTypeId. </value>
        public Int16 MyServiceDeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the last synch time.
        /// </summary>
        /// <value>The last synch time.</value>
        public DateTime MyServiceModDtTm { get; set; }

        #endregion
    }
}