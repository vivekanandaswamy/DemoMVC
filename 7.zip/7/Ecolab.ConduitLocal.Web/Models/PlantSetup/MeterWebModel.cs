﻿// -----------------------------------------------------------------------
// <copyright file="MeterWebModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Meter Web Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    ///     Model class for Meter
    /// </summary>
    public class MeterWebModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the MeterId.
        /// </summary>
        /// <value> Meter Id.</value>
        public int? MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Meter Name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the MeterType.
        /// </summary>
        /// <value> Uitiliy Type.</value>
        public string MeterType { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTypeName.
        /// </summary>
        /// <value> Uitiliy Type Name.</value>
        public string MeterTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityId.
        /// </summary>
        /// <value> UtilityId.</value>
        public int? UtilityId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityLocation.
        /// </summary>
        /// <value> UtilityLocation.</value>
        public string UtilityLocation { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value> Group Id.</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineID.
        /// </summary>
        /// <value> Machine ID.</value>
        public int? MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the MachinecompartmentName.
        /// </summary>
        /// <value> MachinecompartmentName.</value>
        public string MachinecompartmentName { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId.
        /// </summary>
        /// <value> Controller Id.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerName.
        /// </summary>
        /// <value> Controller Name.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value> Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Region Id
        /// </summary>
        /// <value> Controller Region Id</value>
        public int ControllerRegionId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type Id
        /// </summary>
        /// <value> Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type
        /// </summary>
        /// <value> Controller Type</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the Parent.
        /// </summary>
        /// <value> Parent.</value>
        public int? ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the Parent.
        /// </summary>
        /// <value> Parent.</value>
        public string ParentName { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration.
        /// </summary>
        /// <value> Calibration.</value>
        public decimal Calibration { get; set; }

        /// <summary>
        ///     Gets or sets the CalibrationOverride.
        /// </summary>
        /// <value> Calibration Override.</value>
        public bool CalibrationOverride { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration.
        /// </summary>
        /// <value> Calibration.</value>
        public string CalibrationAsString { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTickUnit.
        /// </summary>
        /// <value> UOF for Calibration.</value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        ///     Gets or sets the MeterName.
        /// </summary>
        /// <value> Usage Factor.</value>
        public decimal UsageFactor { get; set; }

        /// <summary>
        ///     Gets or sets the DigitalInputNumber.
        /// </summary>
        /// <value> Digital Input Number.</value>
        public string DigitalInputNumber { get; set; }

        /// <summary>
        ///     Gets or sets the AllowManualentry.
        /// </summary>
        /// <value> Allow manual entry.</value>
        public bool AllowManualEntry { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Meter roll out point.</value>
        public long MaxValueLimit { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Meter roll out point.</value>
        public string MaxValueLimitAsString { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets  LastSyncTime
        /// </summary>
        /// <value>lastsynctime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }
        /// <summary>
        ///     Gets or sets MyServiceMeterGuid
        /// </summary>
        /// <value>MyServiceMeterGuid</value>
        public Guid? MyServiceMeterGuid { get; set; }
        /// <summary>
        /// Gets or Sets the CounterNum
        /// </summary>
        /// <value>The CounterNum </value>
        public int CounterNum { get; set; }
        /// <summary>
        /// Gets or Sets the CounterUsage
        /// </summary>
        /// <value>The CounterUsage value</value>
        public bool CounterUsage { get; set; }
        /// <summary>
        /// Gets or Sets the RunningTimeUsage 
        /// </summary>
        /// <value>The RunningTimeUsage value</value>
        public bool RunningTimeUsage { get; set; }
        /// <summary>
        /// Gets or Sets the CounterAlarmValue
        /// </summary>
        /// <value>The CounterAlarmValue value</value>
        public int CounterAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the WaterType
        /// </summary>
        /// <value>The WaterType value</value>
        public int? WaterType { get; set; }
        /// <summary>
        /// Gets or Sets the WaterTypeFromFormulaSetup Counter
        /// </summary>
        /// <value>The WaterTypeFromFormulaSetup Counter value</value>
        public bool WaterTypeFromFormulaSetup { get; set; }
        /// <summary>
        /// Gets or Sets the RunningTimeAlarmValue Counter
        /// </summary>
        /// <value>The RunningTimeAlarmValue Counter value</value>
        public int RunningTimeAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or Sets ExternalCounter
        /// </summary>
        /// <value>The ExternalCounter value</value>
        public int ExternalCounter { get; set; }
        /// <summary>
        /// Gets or Sets LfsWasherNumber
        /// </summary>
        /// <value>The LfsWasherNumber value</value>
        public int LfsWasherNumber { get; set; }
        /// <summary>
        /// Gets or Sets IsTunnel
        /// </summary>
        /// <value>The IsTunnel Value</value>
        public bool IsTunnel { get; set; }

        /// <summary>
        /// Gets or Sets the Include In Operation Report
        /// </summary>
        /// <value>
        /// The Include In Operation Report
        /// </value>
        public bool IncludeInOperationReport { get; set; }
        #endregion
    }
}