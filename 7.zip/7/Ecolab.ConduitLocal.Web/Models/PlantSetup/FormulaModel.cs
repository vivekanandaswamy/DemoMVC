﻿// -----------------------------------------------------------------------
// <copyright file="FormulaModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Master Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     class ProductMasterModel
    /// </summary>
    public class FormulaModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the ProgramId.
        /// </summary>
        /// <value> Ecoalab ProgramId.</value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> The Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces.</value>
        public int? Pieces { get; set; }
        /// <summary>
        /// Gets or sets the plant chain identifier.
        /// </summary>
        /// <value>The plant chain identifier.</value>
        public int PlantChainId { get; set; }

        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces.</value>
        public int? EcolabTextileId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value> The Ecolab Textile Category Id.</value>
        public string EcolabTextileCategoryName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value> The Ecolab Textile Category Id.</value>
        public int? EcolabSaturationId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabSaturationId.
        /// </summary>
        /// <value> The Ecolab Saturation Id.</value>
        public string EcolabSaturationName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabSaturationId.
        /// </summary>
        /// <value> The Ecolab Saturation Id.</value>
        public int? PlantProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the PlantProgramId.
        /// </summary>
        /// <value> The Plant Program Id.</value>
        public string PlantProgramName { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public int? ChainTextileId { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public string ChainTextileCategory { get; set; }
        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int? FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        /// <summary>
        /// Gets or sets the formula category.
        /// </summary>
        /// <value>The formula category.</value>
        public int FormulaCategory { get; set; }
        /// <summary>
        /// Gets or sets the name of the formula category.
        /// </summary>
        /// <value>The name of the formula category.</value>
        public string FormulaCategoryName { get; set; }
        /// <summary>
        ///     Gets or sets the Rewash.
        /// </summary>
        /// <value> The Rewash.</value>
        public bool Rewash { get; set; }

        /// <summary>
        ///     Gets or sets the Weight.
        /// </summary>
        /// <value> The Weight.</value>
         [UsageKeyAttribute("Mass_CommonUse_TCD", "WeightDisplay")]
        public decimal? Weight { get; set; }

        /// <summary>
        ///     Gets or sets the Weight.
        /// </summary>
        /// <value> The Parameter  Weight.</value>
        public decimal WeightDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the PieceWeight.
        /// </summary>
        /// <value> The Piece Weight.</value>
        public decimal PieceWeight { get; set; }

        /// <summary>
        ///     Gets or sets the PieceWeight.
        /// </summary>
        /// <value> The Piece Weight.</value>
        public string PieceWeightAsString { get; set; }

        /// <summary>
        ///     Gets or sets the UserId.
        /// </summary>
        /// <value> TheUserId.</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the TotalCount.
        /// </summary>
        /// <value> TotalCount.</value>
        public long TotalCount { get; set; }

        /// <summary>
        ///     Gets or sets the UserId.
        /// </summary>
        /// <value> TheUserId.</value>
        public int? CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets the CustomerId.
        /// </summary>
        /// <value> Parameter  CustomerId</value>
        public string CustomerName { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        #endregion
    }
}