﻿// -----------------------------------------------------------------------
// <copyright file="SensorTypeModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The SensorType class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model entity for SensorType
    /// </summary>
    public class SensorTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the SensorTypeId.
        /// </summary>
        /// <value> Sensor Type Id.</value>
        public int SensorTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor Type Name.</value>
        public string Description { get; set; }

        #endregion
    }
}