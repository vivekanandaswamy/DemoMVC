﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityWaterTypeMasterModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilityWaterTypeMasterModel </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    public class PlantUtilityWaterTypeMasterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets WaterTypeId
        /// </summary>
        /// <value>Water Type Id.</value>
        public int WaterTypeId { get; set; }

        /// <summary>
        ///     Gets or sets WaterTypeName
        /// </summary>
        /// <value>Water Type Name.</value>
        public string WaterTypeName { get; set; }

        /// <summary>
        ///     Gets or sets RegionCode
        /// </summary>
        /// <value>Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilTypeCode
        /// </summary>
        /// <value>MyService UtilTypeCode.</value>
        public string MyServiceUtilTypeCode { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilId
        /// </summary>
        /// <value>MyServiceUtilId.</value>
        public Int32 MyServiceUtilId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}