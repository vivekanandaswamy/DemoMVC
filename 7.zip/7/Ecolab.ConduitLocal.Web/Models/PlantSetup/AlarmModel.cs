﻿// -----------------------------------------------------------------------
// <copyright file="AlarmModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm object</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model class for Alarm
    /// </summary>
    public class AlarmModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public string StartDateFormatted { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value>Machine Name</value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmDescription
        /// </summary>
        /// <value>AlarmDescription</value>
        public string AlarmDescription { get; set; }

        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public int AlarmCode { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value>ControllerId</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId
        /// </summary>
        /// <value>GroupId</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineInternalId
        /// </summary>
        /// <value>MachineInternalId</value>
        public int MachineInternalId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId
        /// </summary>
        /// <value>ProgramId</value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the MENumber
        /// </summary>
        /// <value>MENumber</value>
        public int MENumber { get; set; }

        /// <summary>
        ///     Gets or sets the BatchId
        /// </summary>
        /// <value>BatchId</value>
        public int BatchId { get; set; }

        /// <summary>
        ///     Gets or sets the Valve
        /// </summary>
        /// <value>Valve</value>
        public int Valve { get; set; }

        /// <summary>
        ///     Gets or sets the InjectionNumber
        /// </summary>
        /// <value>InjectionNumber</value>
        public int InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets the MachineId
        /// </summary>
        /// <value>MachineId</value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive
        /// </summary>
        /// <value>IsActive</value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the EndDate
        /// </summary>
        /// <value>EndDate</value>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///     Gets or sets the DesiredQuatity
        /// </summary>
        /// <value>DesiredQuatity</value>
        public int DesiredQuatity { get; set; }

        /// <summary>
        ///     Gets or sets the MeasuredQuantity
        /// </summary>
        /// <value>MeasuredQuantity</value>
        public int MeasuredQuantity { get; set; }

        /// <summary>
        ///     Gets or sets the TempStatus
        /// </summary>
        /// <value>TempStatus</value>
        public int TempStatus { get; set; }

        /// <summary>
        ///     Gets or sets the ProbeNumber
        /// </summary>
        /// <value>ProbeNumber</value>
        public int ProbeNumber { get; set; }

        /// <summary>
        ///     Gets or sets the UserId
        /// </summary>
        /// <value>UserId</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the StepId
        /// </summary>
        /// <value>StepId</value>
        /// 
        public string StepId { get; set; }
    }
}