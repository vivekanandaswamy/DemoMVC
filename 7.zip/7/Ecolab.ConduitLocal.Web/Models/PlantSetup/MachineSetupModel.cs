﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetupModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Machine Setup Model
    /// </summary>
    public class MachineSetupModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value> controller id</value>
        public int MachineID { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value> Machine Name </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets Controller Id
        /// </summary>
        /// <value> Controller Id</value>
        public int ControllerId { get; set; }

		/// <summary>
		/// Gets or Sets the Plant Washer Number
		/// </summary>
		/// <value>
		/// The Plant Washer Number
		/// </value>
		public int PlantWasherNumber { get; set; }

        #endregion
    }
}