﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilitySetupModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    ///     Plant Utility Setup Model
    /// </summary>
    public class PlantUtilitySetupModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Cold Temperature value for the plant utility.
        /// </summary>
        /// <value>Gets Cold Temperature value.</value>
        public decimal ColdTemp { get; set; }

        /// <summary>
        ///     Gets or sets the Cold Price value for the plant utility.
        /// </summary>
        /// <value> Cold price value.  </value>
        public decimal ColdPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Hot Temperature value for the plant utility.
        /// </summary>
        /// <value> Hot Temperature value.</value>
        public decimal HotTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotPrice value for the plant utility.
        /// </summary>
        /// <value>Hot Price Value.</value>
        public decimal HotPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Tempered Temperature for plant utility.
        /// </summary>
        /// <value>Tempered Temperature value.</value>
        public decimal TemperedTemp { get; set; }

        /// <summary>
        ///     Gets or sets the Tempered price for plant utility.
        /// </summary>
        /// <value>Tempered price value.</value>
        public decimal TemperedPrice { get; set; }

        /// <summary>
        ///     Gets or sets the waste water price for plant utility.
        /// </summary>
        /// <value>Waste water price value.</value>
        public decimal WasteWaterPrice { get; set; }

        /// <summary>
        ///     Gets or sets the free1 water type temperature for plant utility.
        /// </summary>
        /// <value>Free1 water type temperature value.</value>
        public decimal Free1Temp { get; set; }

        /// <summary>
        ///     Gets or sets the free1 water type price for plant utility.
        /// </summary>
        /// <value>Free1 water type price value.</value>
        public decimal Free1Price { get; set; }

        /// <summary>
        ///     Gets or sets the Free2Temp for plant utility.
        /// </summary>
        /// <value>Free2 water type temperature.</value>
        public decimal Free2Temp { get; set; }

        /// <summary>
        ///     Gets or sets the Free2Price for plant utility.
        /// </summary>
        /// <value>Free2 water type price value.</value>
        public decimal Free2Price { get; set; }

        /// <summary>
        ///     Gets or sets the Free3Temp for plant utility.
        /// </summary>
        /// <value>Free3 water type temperature.</value>
        public decimal Free3Temp { get; set; }

        /// <summary>
        ///     Gets or sets the Free3Price for plant utility.
        /// </summary>
        /// <value>Free3 water type price value.</value>
        public decimal Free3Price { get; set; }

        /// <summary>
        ///     Gets or sets the Energy for plant utility.
        /// </summary>
        /// <value>Energy Value.</value>
        public decimal Energy { get; set; }

        /// <summary>
        ///     Gets or sets the GasPrice for plant utility.
        /// </summary>
        /// <value>Gas Price value.</value>
        public decimal GasPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Electricity price for plant utility.
        /// </summary>
        /// <value>Electricity Price value.</value>
        public decimal ElectricityTarrif { get; set; }

        /// <summary>
        ///     Gets or sets the Location for plant utility.
        /// </summary>
        /// <value>Location value.</value>
        public string Location { get; set; }

        /// <summary>
        ///     Gets or sets the ColdSoftTemp for plant utility.
        /// </summary>
        /// <value>Cold Soft Temperature value.</value>
        public decimal ColdSoftTemp { get; set; }

        /// <summary>
        ///     Gets or sets the ColdSoftPrice for plant utility.
        /// </summary>
        /// <value>Cold Soft Price value.</value>
        public decimal ColdSoftPrice { get; set; }

        /// <summary>
        ///     Gets or sets the HotSoftTemp for plant utility.
        /// </summary>
        /// <value>Hot soft temperature value.</value>
        public decimal HotSoftTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotSoftPrice for plant utility.
        /// </summary>
        /// <value>Hot Soft Price value.</value>
        public decimal HotSoftPrice { get; set; }

        /// <summary>
        ///     Gets or sets the ColdHardTemp for plant utility.
        /// </summary>
        /// <value>Cold Hard Temperature value.</value>
        public decimal ColdHardTemp { get; set; }

        /// <summary>
        ///     Gets or sets the ColdHardPrice for plant utility.
        /// </summary>
        /// <value>Cold Hard Price value.</value>
        public decimal ColdHardPrice { get; set; }

        /// <summary>
        ///     Gets or sets the HotHardTemp for plant utility.
        /// </summary>
        /// <value>Hot Hard Temperature value.</value>
        public decimal HotHardTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotHardPrice for plant utility.
        /// </summary>
        /// <value>Hot Hard Price value.</value>
        public decimal HotHardPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Free1FactorType for plant utility.
        /// </summary>
        /// <value> The Free1 Factor Type value.</value>
        public string Free1FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Free2FactorType for plant utility.
        /// </summary>
        /// <value> The Free2 Factor type value.</value>
        public string Free2FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Free3FactorType for plant utility.
        /// </summary>
        /// <value> The Free3 factor type value.</value>
        public string Free3FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the GasOilType for plant utility.
        /// </summary>
        /// <value> The Gas Oil Type value.</value>
        public string GasOilType { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityType for plant utility.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityType { get; set; }

        /// <summary>
        ///     Gets or sets the FactorType for plant utility.
        /// </summary>
        /// <value> The Factor Type.</value>
        public string FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature for plant utility.
        /// </summary>
        /// <value> The Temperature.</value>
        public decimal Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Energy Content for plant utility.
        /// </summary>
        /// <value> The Energy content.</value>
        public decimal EnergyContent { get; set; }

        /// <summary>
        ///     Gets or sets the Price for plant utility.
        /// </summary>
        /// <value> The Price.</value>
        public decimal Price { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether the boiler steam is required or not.
        /// </summary>
        /// <value> The Boiler Steam.</value>
        public bool BoilerSteam { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType for plant utility.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int BoilerType { get; set; }

        /// <summary>
        ///     Gets or sets the Steam for plant utility.
        /// </summary>
        /// <value> The Steam percentage.</value>
        public decimal SteamPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Boiler for plant utility.
        /// </summary>
        /// <value> The Boiler percentage.</value>
        public decimal BoilerPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Stack for plant utility.
        /// </summary>
        /// <value> The Stack percentage.</value>
        public decimal StackPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the RewashFactor for plant utility.
        /// </summary>
        /// <value> The Rewash Factor percentage.</value>
        public decimal RewashFactor { get; set; }

        /// <summary>
        ///     Gets or sets the energy content unit for plant utility.
        /// </summary>
        /// <value> The Energy Content Unit.</value>
        public string EnergyContentUnit { get; set; }

        /// <summary>
        ///     Gets or sets the energy price unit for plant utility.
        /// </summary>
        /// <value> The Energy Price Unit.</value>
        public string EnergyPriceUnit { get; set; }

        /// <summary>
        ///     Gets or sets the evaporation factor for plant utility.
        /// </summary>
        /// <value> The evaporation factor.</value>
        public decimal EvaporationFactor { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        #endregion
    }
}