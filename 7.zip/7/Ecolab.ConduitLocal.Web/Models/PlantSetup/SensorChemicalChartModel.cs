﻿// -----------------------------------------------------------------------
// <copyright file="SensorChemicalChartModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The SensorChemicalChart class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model Entity class for SensorChemicalChart
    /// </summary>
    public class SensorChemicalChartModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Sensor chemical chart Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor chemical chart Name.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public byte PumpNumber { get; set; }
        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public byte PumpType { get; set; }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Sensor chemical chart Id.</value>
        public int ControllerModelId { get; set; }
        #endregion
    }
}