﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborCostModel object </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.ShiftLabor
{
    using System;

    /// <summary>
    ///     Model class for LaborCostModel
    /// </summary>
    public class LaborCostModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the LaborTypeId
        /// </summary>
        /// <value>Labor Type Id</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value>Description</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the Cost
        /// </summary>
        /// <value>The Cost value</value>
        [UsageKeyAttribute("Price_Tcd", "CostDisplay")]
        public decimal Cost { get; set; }

        /// <summary>
        ///     Gets or sets the CostDisplay
        /// </summary>
        /// <value>The Parameter CostDisplay</value>
        public decimal CostDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the Cost
        /// </summary>
        /// <value>The Cost value</value>
        public string CostAsString { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the Is Delete
        /// </summary>
        /// <value>
        /// IsDelete for LaborCostModel
        /// </value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}