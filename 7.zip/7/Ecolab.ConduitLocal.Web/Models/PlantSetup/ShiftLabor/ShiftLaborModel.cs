﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftLaborModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    public class ShiftLaborModel
    {
        /// <summary>
        /// Gets or sets the ShiftId.
        /// </summary>
        /// <value>
        /// The labour Id.
        /// </value>
        public int? LaborId { get; set; }

        /// <summary>
        /// Gets or sets the ShiftId.
        /// </summary>
        /// <value>
        /// The Shift Id.
        /// </value>
        public short ShiftId { get; set; }

        /// <summary>
        /// Gets or sets the DayId.
        /// </summary>
        /// <value>
        /// The Day Id value.
        /// </value>
        public int DayId { get; set; }

        /// <summary>
        /// Gets or sets the LaborTypeId.
        /// </summary>
        /// <value>
        /// Labor Type Id.
        /// </value>
        public int LaborTypeId { get; set; }

        /// <summary>
        /// Gets or sets the LaborTypeName.
        /// </summary>
        /// <value>
        /// Labor Type Name.
        /// </value>
        public string LaborTypeName { get; set; }

        /// <summary>
        /// Gets or sets the LocationId.
        /// </summary>
        /// <value>
        /// Location Id.
        /// </value>
        public int LocationId { get; set; }

        /// <summary>
        /// Gets or sets the LoactionName.
        /// </summary>
        /// <value>
        /// Loaction Name.
        /// </value>
        public string LoactionName { get; set; }

        /// <summary>
        /// Gets or sets the LaborHours.
        /// </summary>
        /// <value>
        /// The Man Labor Hours.
        /// </value>
        public int LaborHours { get; set; }

        /// <summary>
        /// Gets or sets the LaborHours.
        /// </summary>
        /// <value>
        /// Labor Hours As String.
        /// </value>
        public string LaborHoursAsString { get; set; }

        /// <summary>
        /// Gets or sets the LaborCount.
        /// </summary>
        /// <value>
        /// The Labor Count.
        /// </value>
        public int LaborCount { get; set; }

        /// <summary>
        /// Gets or sets the PricePerHr.
        /// </summary>
        /// <value>
        /// Price Per Hr decimal value.
        /// </value>
        [UsageKeyAttribute("Price_Tcd", "PricePerHrAsString")]
        public decimal PricePerHr { get; set; }

        /// <summary>
        /// Gets or sets the PricePerHr.
        /// </summary>
        /// <value>
        /// Price Per Hr AsString.
        /// </value>
        public string PricePerHrAsString { get; set; }

        /// <summary>
        /// Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>
        /// Ecolab Account Number.
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Locations
        /// </summary>
        /// <value>
        /// Locations for ShiftLaborModel.
        /// </value>
        public List<GroupTypeModel> Locations { get; set; }

        /// <summary>
        /// Gets or sets the Locations
        /// </summary>
        /// <value>
        /// LaborTypes for ShiftLaborModel.
        /// </value>
        public List<LaborTypeModel> LaborTypes { get; set; }

        /// <summary>
        /// Gets or sets the LastSyncTime
        /// </summary>
        /// <value>
        /// LastSyncTime for ShiftLaborModel
        /// </value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets Max Number Of Records
        /// </summary>
        /// <value>
        /// Max Number Of Records
        /// </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>
        /// LastModifiedTimeStamp
        /// </value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the Is Delete
        /// </summary>
        /// <value>
        /// IsDelete for ShiftLaborModel
        /// </value>
        public bool IsDelete { get; set; }
    }
}