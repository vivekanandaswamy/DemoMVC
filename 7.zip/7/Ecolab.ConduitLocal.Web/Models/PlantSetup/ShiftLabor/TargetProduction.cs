﻿// -----------------------------------------------------------------------
// <copyright file="TargetProduction.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TargetProduction class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.TargetProduction
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Model Entity class for TargetProduction
    /// </summary>
    public class TargetProduction : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the DayId
        /// </summary>
        /// <value> Parameter DayId</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the DayName
        /// </summary>
        /// <value> Parameter DayName</value>
        public string DayName { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName
        /// </summary>
        /// <value> Parameter ShiftName </value>
        public string ShiftName { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId
        /// </summary>
        /// <value> Parameter ShiftId </value>
        public int ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProd
        /// </summary>
        /// <value> Parameter TargetProd</value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "TargetProdDisplay")]
        public decimal? TargetProd { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProdDisplay
        /// </summary>
        /// <value> Parameter TargetProdDisplay</value>
        public decimal? TargetProdDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProd
        /// </summary>
        /// <value> Parameter TargetProd</value>
        public string TargetProdAsstring { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime
        /// </summary>
        /// <value> Parameter StartTime</value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the EndTime
        /// </summary>
        /// <value> Parameter EndTime</value>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate
        /// </summary>
        /// <value> Parameter RecordedDate</value>
        public DateTime RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the IsEditable 
        /// </summary>
        /// <value> Parameter IsEditable </value>
        public bool IsEditable { get; set; }
    }
}