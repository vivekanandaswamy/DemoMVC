﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeCostModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborTypeCostModel object </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Labor Type Cost Model
    /// </summary>
    public class LaborTypeCostModel
    {
        /// <summary>
        /// Gets or sets the Cost
        /// </summary>
        /// <value>
        /// The Cost Value for LaborTypeCostModel
        /// </value>
        [UsageKeyAttribute("Price_Tcd", "CostDisplay")]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets the CostDisplay.
        /// </summary>
        /// <value>
        /// Cost Display for LaborTypeCostModel.
        /// </value>
        public decimal CostDisplay { get; set; }
    }
}