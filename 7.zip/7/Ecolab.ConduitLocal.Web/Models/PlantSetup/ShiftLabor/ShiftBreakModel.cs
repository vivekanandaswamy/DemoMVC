﻿// -----------------------------------------------------------------------
// <copyright file="ShiftBreakModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftBreakModel object </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.ShiftLabor
{
    /// <summary>
    ///     Model class for ShiftBreakModel
    /// </summary>
    public class ShiftBreakModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the BreakId.
        /// </summary>
        /// <value>The BreakId. </value>
        public int BreakId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value>The Shift Id. </value>
        public int ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value>The Day Id value.</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> Break Start Time.</value>
        public string StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the EndTime.
        /// </summary>
        /// <value> Break End Time.</value>
        public string EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted. </value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value>The Desired units.</value>
        public string DesiredUnits { get; set; }

        #endregion
    }
}