﻿// -----------------------------------------------------------------------
// <copyright file="ShiftModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     enum for shift week days
    /// </summary>
    public enum Days
    {
        /// <summary>
        ///     Enum Sunday
        /// </summary>
        Sunday = 1,

        /// <summary>
        ///     Enum Monday
        /// </summary>
        Monday = 2,

        /// <summary>
        ///     Enum Tuesday
        /// </summary>
        Tuesday = 3,

        /// <summary>
        ///     Enum Wednesday
        /// </summary>
        Wednesday = 4,

        /// <summary>
        ///     Enum Thursday
        /// </summary>
        Thursday = 5,

        /// <summary>
        ///     Enum Friday
        /// </summary>
        Friday = 6,

        /// <summary>
        ///     Enum Saturday
        /// </summary>
        Saturday = 7
    }

    /// <summary>
    ///     Model class for ShiftModel
    /// </summary>
    public class ShiftModel
    {
        public ShiftModel()
        {
            ShiftBreaks = new List<ShiftBreakModel>();
            ShiftLabors = new List<ShiftLaborModel>();
        }

        #region

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value>The Id value. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value>The Shift Id. </value>
        public int? ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName.
        /// </summary>
        /// <value> Shift Name.</value>
        public string ShiftName { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value>The Day Id value.</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the DayName.
        /// </summary>
        /// <value>The Day Name.</value>
        public string DayName { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> Start Time.</value>
        public string StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the EndTime.
        /// </summary>
        /// <value>The End Time.</value>
        public string EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProduction.
        /// </summary>
        /// <value> Target Production. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "TargetProductionDisplay")]
        public decimal TargetProduction { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProdDisplay
        /// </summary>
        /// <value> Parameter TargetProdDisplay</value>
        public decimal? TargetProductionDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProduction.
        /// </summary>
        /// <value> Target Production. </value>
        public string TargetProductionAsString { get; set; }

        /// <summary>
        ///     Gets or sets the List of ShiftBreakModel
        /// </summary>
        public List<ShiftBreakModel> ShiftBreaks { get; set; }

        /// <summary>
        ///     Gets or sets the  ShiftBreakModel
        /// </summary>
        public ShiftBreakModel ShiftBreak { get; set; }

        /// <summary>
        ///     Gets or sets the List of  ShiftLaborModel
        /// </summary>
        public List<ShiftLaborModel> ShiftLabors { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftLaborModel
        /// </summary>
        public virtual ShiftLaborModel ShiftLabor { get; set; }

        /// <summary>
        ///     Gets or sets the IsMonday.
        /// </summary>
        /// <value> Is Monday.</value>
        public bool IsMonday { get; set; }

        /// <summary>
        ///     Gets or sets the IsTuesday.
        /// </summary>
        /// <value> Is Tuesday.</value>
        public bool IsTuesday { get; set; }

        /// <summary>
        ///     Gets or sets the IsWednesday.
        /// </summary>
        /// <value> Is Wednesday.</value>
        public bool IsWednesday { get; set; }

        /// <summary>
        ///     Gets or sets the IsThursday.
        /// </summary>
        /// <value> Is Thursday.</value>
        public bool IsThursday { get; set; }

        /// <summary>
        ///     Gets or sets the IsFriday.
        /// </summary>
        /// <value> Is Friday.</value>
        public bool IsFriday { get; set; }

        /// <summary>
        ///     Gets or sets the IsSaturday.
        /// </summary>
        /// <value> Is Saturday.</value>
        public bool IsSaturday { get; set; }

        /// <summary>
        ///     Gets or sets the IsSunday.
        /// </summary>
        /// <value> Is Sunday.</value>
        public bool IsSunday { get; set; }

        /// <summary>
        ///     Gets or sets the Count
        /// </summary>
        public int Count { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value>The Desired units Value. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        #endregion
    }
}