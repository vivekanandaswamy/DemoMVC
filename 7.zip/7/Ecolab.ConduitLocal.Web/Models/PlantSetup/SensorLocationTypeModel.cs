﻿// -----------------------------------------------------------------------
// <copyright file="SensorLocationTypeModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The SensorLocationType class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model Entity class for SensorLocationType
    /// </summary>
    public class SensorLocationTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the SensorTypeLocId.
        /// </summary>
        /// <value> Sensor Type loc Id.</value>
        public int SensorTypeLocId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor Type Name.</value>
        public string Description { get; set; }

        #endregion
    }
}