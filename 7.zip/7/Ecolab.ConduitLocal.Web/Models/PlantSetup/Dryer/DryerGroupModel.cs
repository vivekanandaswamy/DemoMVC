﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroupModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerGroupModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.Dryer
{
    using System;
    using System.Collections.Generic;

    public class DryerGroupModel
    {
        public DryerGroupModel()
        {
            Dryers = new List<DryerModel>();
        }

        /// <summary>
        ///     Gets or sets the DryerGroupId.
        /// </summary>
        /// <value> DryerGroupId. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the DryerGroupName.
        /// </summary>
        /// <value> DryerGroupName. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the ActualUnits.
        /// </summary>
        /// <value> ActualUnits.</value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer.
        /// </summary>
        /// <value> Dryer. </value>
        public virtual DryerModel Dryer { get; set; }

        public List<DryerModel> Dryers { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimeStampDryerGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimeStampDryer { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}