﻿// -----------------------------------------------------------------------
// <copyright file="DryerSearchParamsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerSearchParamsModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.Dryer
{
    public class DryerSearchParamsModel //: SearchParamsModel
    {
    }
}