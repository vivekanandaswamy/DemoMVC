﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroupCollectionModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerGroupCollectionModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup.Dryer
{
    using System.Collections.Generic;

    public class DryerGroupCollectionModel
    {
        /// <summary>
        ///     Populates only filtered records
        /// </summary>
        public List<DryerGroupModel> DryerGroups { get; set; }

        public int NumberOfRecordsMatched { get; set; }
    }
}