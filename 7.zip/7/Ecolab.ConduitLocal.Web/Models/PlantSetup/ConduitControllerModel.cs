﻿// -----------------------------------------------------------------------
// <copyright file="ConduitControllerModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Conduit Controller Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model class for ConduitController
    /// </summary>
    public class ConduitControllerModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value> controller id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value> controller name</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value> Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Name
        /// </summary>
        /// <value> Controller Model Name</value>
        public string ControllerModelName { get; set; }

        /// <summary>
        ///     Gets or Sets the controller region Id
        /// </summary>
        /// <value>Controller Region Id</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value> Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type
        /// </summary>
        /// <value> Controller Type</value>
        public string ControllerType { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }
        #endregion
    }
}