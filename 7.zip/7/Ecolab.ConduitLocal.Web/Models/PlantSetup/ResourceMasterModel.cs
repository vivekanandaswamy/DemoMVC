﻿// -----------------------------------------------------------------------
// <copyright file="ResourceMasterModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Master </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     class for ResourceMaster
    /// </summary>
    public class ResourceMasterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the ResourceId.
        /// </summary>
        /// <value> ResourceId.</value>
        public int ResourceId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> Name.</value>
        public string Name { get; set; }

        #endregion
    }
}