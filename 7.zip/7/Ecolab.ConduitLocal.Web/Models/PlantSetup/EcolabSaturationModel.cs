﻿// -----------------------------------------------------------------------
// <copyright file="EcolabSaturationModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Ecolab Saturation Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.PlantSetup
{
    /// <summary>
    ///     class EcolabSaturationModel
    /// </summary>
    public class EcolabSaturationModel
    {
        /// <summary>
        ///     Gets or sets  EcolabSaturationId
        /// </summary>
        /// <value> EcolabSaturationId </value>
        public int EcolabSaturationId { get; set; }

        /// <summary>
        ///     Gets or sets  EcolabSaturationName
        /// </summary>
        /// <value> EcolabSaturationName </value>
        public string EcolabSaturationName { get; set; }
    }
}