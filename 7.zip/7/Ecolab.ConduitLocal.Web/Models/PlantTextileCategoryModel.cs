﻿// -----------------------------------------------------------------------
// <copyright file="PlantTextileCategoryModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantTextileCategoryModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    public class PlantTextileCategoryModel
    {
        /// <summary>
        /// Gets or sets TextileId
        /// </summary>
        /// <value> Textile Id.</value>
        public int TextileId { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        /// <value> Name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets EcolabTextileCategoryId
        /// </summary>
        /// <value> EcolabTextileCategoryId.</value>
        public int EcolabTextileCategoryId { get; set; }
    }
}