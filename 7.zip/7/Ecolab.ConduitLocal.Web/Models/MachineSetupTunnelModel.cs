﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetupTunnelModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup Tunnel Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model for MachineSetupTunnel
    /// </summary>
    public class MachineSetupTunnelModel
    {
        /// <summary>
        ///     Gets or sets GroupId
        /// </summary>
        /// <value> GroupId </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets MachineInternalId
        /// </summary>
        /// <value> MachineInternalId </value>
        public int MachineInternalId { get; set; }

        /// <summary>
        ///     Gets or sets MachineName
        /// </summary>
        /// <value> MachineName </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets NumberOfcompartmentals
        /// </summary>
        /// <value> NumberOfcompartmentals </value>
        public int NumberOfcompartmentals { get; set; }
    }
}