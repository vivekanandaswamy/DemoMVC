﻿// -----------------------------------------------------------------------
// <copyright file="TunnelReadingModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel Reading Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     Model for TunnelReading
    /// </summary>
    public class TunnelReadingModel
    {
        /// <summary>
        ///     Gets or sets the GroupId
        /// </summary>
        /// <value> The Group Id. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the CompartmentId
        /// </summary>
        /// <value> CompartmentId </value>
        public int CompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the TimeStamp
        /// </summary>
        /// <value> Time Stamp </value>
        public DateTime TimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the ParamterName
        /// </summary>
        /// <value> ParamterName </value>
        public string ParamterName { get; set; }

        /// <summary>
        ///     Gets or sets the Actual
        /// </summary>
        /// <value> The Actual . </value>
        /// >
        public string Actual { get; set; }

        /// <summary>
        ///     Gets or sets the Desired
        /// </summary>
        /// <value>The Desired. </value>
        public string Desired { get; set; }
    }
}