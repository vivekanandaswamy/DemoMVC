﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetupModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Monitor Setup Model For Dashboard configuration</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.Monitor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Web Model for Dashboard Setup
    /// </summary>
    public class MonitorSetupModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the List of Machines for a Washer Group Type
        /// </summary>
        /// <value> The Machines</value>
        public List<MachinesForWasherGroupType> Machines { get; set; }

        /// <summary>
        ///     Gets or sets the List of Washer Group Types
        /// </summary>
        /// <value>WasherGroupTypes</value>
        public List<WasherGroupType> WasherGroupTypes { get; set; }

        /// <summary>
        ///     Gets or sets the List of Displays Connected to the CPU
        /// </summary>
        public List<MonitorDetails> Displays { get; set; }

        /// <summary>
        ///     Gets or sets the List of Machines for a Washer Group Type
        /// </summary>
        /// <value>SelectedMachines</value>
        public List<MachinesForWasherGroupType> SelectedMachines { get; set; }

        /// <summary>
        ///     Gets or sets the List of Displays Connected to the CPU
        /// </summary>
        /// <value>SelectedDisplays</value>
        public List<MonitorDetails> SelectedDisplays { get; set; }

        /// <summary>
        ///     Gets or sets the DashboardId
        /// </summary>
        /// <value>Dashboard Id</value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the DashboardName
        /// </summary>
        /// <value>Dashboard Name</value>
        public string DashboardName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherId
        /// </summary>
        /// <value>Washer Id(Machine Id) </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeId
        /// </summary>
        /// <value>Washer GroupTypeId </value>
        public Int16 WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeName
        /// </summary>
        /// <value>Washer GroupType Name </value>
        public string WasherGroupTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value>Machine Name </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the MonitorId
        /// </summary>
        /// <value>MonitorId.</value>
        public string MonitorId { get; set; }

        /// <summary>
        ///     Gets or sets the IsEnableParameter
        /// </summary>
        /// <value>Is Enable Parameters </value>
        public bool IsEnableParameter { get; set; }

        /// <summary>
        ///     Gets or sets the IsEdit
        /// </summary>
        /// <value>The IsEdit. </value>
        public bool IsEdit { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleteMapping
        /// </summary>
        /// <value>IsDeleteMapping </value>
        public bool IsDeleteMapping { get; set; }

        /// <summary>
        ///     Gets or sets the Customer
        /// </summary>
        /// <value>Customer is enable or not</value>
        public bool Customer { get; set; }

        /// <summary>
        ///     Gets or sets the Formula
        /// </summary>
        /// <value>Formula is enable or not</value>
        public bool Formula { get; set; }

        /// <summary>
        ///     Gets or sets the Load
        /// </summary>
        /// <value>Load is enable or not</value>
        public bool Load { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOnLogin
        /// </summary>
        /// <value>DisplayOnLogin is enable or not</value>
        public bool DisplayOnLogin { get; set; }

        /// <summary>
        ///     Gets or sets the TimelineHours
        /// </summary>
        /// <value>No of hours to display on Timeline</value>
        public int TimelineHours { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayType
        /// </summary>
        /// <value>FormulaDisplayType</value>
        public int FormulaDisplayType { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayTypeName
        /// </summary>
        /// <value>FormulaDisplayTypeName</value>
        public string FormulaDisplayTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the EfficiencyCalcType
        /// </summary>
        /// <value>EfficiencyCalcType</value>
        public int EfficiencyCalcType { get; set; }

        /// <summary>
        ///     Gets or sets the EfficiencyCalcTypeName
        /// </summary>
        /// <value>EfficiencyCalcTypeName</value>
        public string EfficiencyCalcTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the SlideDuration
        /// </summary>
        /// <value>SlideDuration</value>
        public int SlideDuration { get; set; }

        /// <summary>
        ///     Gets or sets the MachineNameDispalyType 
        /// </summary>
        /// <value>Machine Name Dispaly Type  </value>
        public short MachineNameDispalyType { get; set; }
    }
}