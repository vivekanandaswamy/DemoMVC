﻿// -----------------------------------------------------------------------
// <copyright file="MonitorDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>External Displays Connected to the CPU</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.Monitor
{
    /// <summary>
    ///     Web Model for External Displays
    /// </summary>
    public class MonitorDetails : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the Monotor Id
        /// </summary>
        /// <value>It contains MonitorId</value>
        public string MonitorId { get; set; }

        /// <summary>
        ///     Gets or sets MonitorName
        /// </summary>
        /// <value>The Parameter Monitor Name</value>
        public string MonitorName { get; set; }
    }
}