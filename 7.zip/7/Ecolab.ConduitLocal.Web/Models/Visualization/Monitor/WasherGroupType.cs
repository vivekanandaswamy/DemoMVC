﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Washer Group Type class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.Monitor
{
    using System;

    /// <summary>
    ///     Wb Model for WasherGroupType
    /// </summary>
    public class WasherGroupType
    {
        /// <summary>
        ///     Id of Washer Group Type
        /// </summary>
        public Int16 WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Name of Washer Group Type
        /// </summary>
        public string WasherGroupTypeName { get; set; }
    }
}