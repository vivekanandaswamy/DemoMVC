﻿// -----------------------------------------------------------------------
// <copyright file="MachinesForWasherGroupType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machines For Wash Group Type class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.Monitor
{
    /// <summary>
    ///     Web Model for MachinesForWasherGroupType
    /// </summary>
    public class MachinesForWasherGroupType
    {
        /// <summary>
        ///     Id of Machine
        /// </summary>
        /// <value>The Parameter Machine Id</value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Name of Machine
        /// </summary>
        /// <value>The Parameter Machine Name</value>
        public string MachineName { get; set; }
    }
}