﻿// -----------------------------------------------------------------------
// <copyright file="BatchDetailsViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>BatchDetails ViewModel Class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.ConventionalWasher
{
    using System.Collections.Generic;

    /// <summary>
    ///     BatchDetailsViewModel class
    /// </summary>
    public class BatchDetailsViewModel
    {
        /// <summary>
        ///     Gets or sets the List of BatchDetailsModel.
        /// </summary>
        /// <value> BatchDetailsModel List. </value>
        public BatchDetailsModel BatchData { get; set; }

        /// <summary>
        ///     Gets or sets the Standard TurnTime InMinutes.
        /// </summary>
        /// <value> StandardTurnTimeInMinutes. </value>
        public List<int> StandardTurnTime { get; set; }

        /// <summary>
        ///     Gets or sets the Actual TurnTime InMinutes.
        /// </summary>
        /// <value> ActualTurnTimeInMinutes. </value>
        public List<int> ActualTurnTime { get; set; }

        /// <summary>
        ///     Gets or sets the Progress Width.
        /// </summary>
        /// <value> ProgressWidth. </value>
        public int ProgressWidth { get; set; }

        /// <summary>
        ///     Gets or sets the Text Width.
        /// </summary>
        /// <value> TextWidth. </value>
        public int TextWidth { get; set; }
    }
}