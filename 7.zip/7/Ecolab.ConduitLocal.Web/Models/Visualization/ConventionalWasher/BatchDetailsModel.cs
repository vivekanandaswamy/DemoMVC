﻿// -----------------------------------------------------------------------
// <copyright file="BatchDetailsModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Batch Details Class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.ConventionalWasher
{
    /// <summary>
    ///     BatchDetails
    /// </summary>
    public class BatchDetailsModel
    {
        /// <summary>
        ///     Gets or sets the Group Id.
        /// </summary>
        /// <value> The GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Machine Id.
        /// </summary>
        /// <value> MachineId. </value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the Batch Id.
        /// </summary>
        /// <value>The BatchId. </value>
        public int BatchId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId.
        /// </summary>
        /// <value> ProgramId. </value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the Program Name.
        /// </summary>
        /// <value> ProgramName. </value>
        public string ProgramName { get; set; }

        /// <summary>
        ///     Gets or sets the Batch StartTime InSeconds.
        /// </summary>
        /// <value> BatchStartTimeInSeconds. </value>
        public int BatchStartTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Batch Standard EndTime InSeconds.
        /// </summary>
        /// <value> BatchStandardEndTimeInSeconds. </value>
        public int BatchStandardEndTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Batch ActualEndTime InSeconds.
        /// </summary>
        /// <value> BatchActualEndTimeInSeconds. </value>
        public int BatchActualEndTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Standard TurnTime InSeconds.
        /// </summary>
        /// <value> StandardTurnTimeInSeconds. </value>
        public int StandardTurnTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Actual TurnTime InSeconds.
        /// </summary>
        /// <value> ActualTurnTimeInSeconds. </value>
        public int ActualTurnTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Value Running Status.
        /// </summary>
        /// <value> RunningStatus. </value>
        public bool RunningStatus { get; set; }

        /// <summary>
        ///     Gets or sets the Time Efficiency.
        /// </summary>
        /// <value> TimeEfficiency. </value>
        public double TimeEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the Progress Width.
        /// </summary>
        /// <value> ProgressWidth. </value>
        public int ProgressWidth { get; set; }

        /// <summary>
        ///     Gets or sets the Additional Width.
        /// </summary>
        /// <value> AdditionalWidth. </value>
        public int AdditionalWidth { get; set; }

        /// <summary>
        ///     Gets or sets the TurnTime ProgressWidth.
        /// </summary>
        /// <value> TurnTimeProgressWidth. </value>
        public int TurnTimeProgressWidth { get; set; }

        /// <summary>
        ///     Gets or sets the TurnTime Additional Width.
        /// </summary>
        /// <value> TurnTimeAdditionalWidth. </value>
        public int TurnTimeAdditionalWidth { get; set; }

        /// <summary>
        ///     Gets or sets the OtherTurnTime Width.
        /// </summary>
        /// <value> OtherTurnTimeWidth. </value>
        public int OtherTurnTimeWidth { get; set; }

        /// <summary>
        ///     Gets or sets the Text Width.
        /// </summary>
        /// <value> TextWidth. </value>
        public int TextWidth { get; set; }

        /// <summary>
        ///     Gets or sets the TurnTime Color.
        /// </summary>
        /// <value> TurnTimeColor. </value>
        public string TurnTimeColor { get; set; }

        /// <summary>
        ///     Gets or sets the IsLastBatch.
        /// </summary>
        /// <value>The Parameter IsLastBatch. </value>
        public bool IsLastBatch { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayFormula.
        /// </summary>
        /// <value>The Parameter DisplayFormula. </value>
        public bool DisplayFormula { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramNumber.
        /// </summary>
        /// <value>The Parameter ProgramNumber. </value>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayType
        /// </summary>
        /// <value>FormulaDisplayType</value>
        public int FormulaDisplayType { get; set; }
    }
}