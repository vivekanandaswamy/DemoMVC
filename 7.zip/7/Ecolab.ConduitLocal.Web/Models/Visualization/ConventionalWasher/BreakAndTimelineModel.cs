﻿// -----------------------------------------------------------------------
// <copyright file="BreakAndTimelineModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Break And Timeline </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.ConventionalWasher
{
    /// <summary>
    ///     BreakAndTimeline
    /// </summary>
    public class BreakAndTimelineModel
    {
        /// <summary>
        ///     Gets or sets the Type Break / Timeline.
        /// </summary>
        /// <value> The Type value. </value>
        public string Type { get; set; }

        /// <summary>
        ///     Gets or sets the FromTime InSeconds.
        /// </summary>
        /// <value> FromTime InSeconds. </value>
        public int FromTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the ToTime InSeconds.
        /// </summary>
        /// <value> ToTimeInSeconds. </value>
        public int ToTimeInSeconds { get; set; }
    }
}