﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalWasher class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.ConventionalWasher
{
    using System.Collections.Generic;

    /// <summary>
    ///     ConventionalWasher
    /// </summary>
    public class ConventionalWasherModel
    {
        /// <summary>
        ///     Gets or sets the Group Id.
        /// </summary>
        /// <value>The Group Id. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Id.
        /// </summary>
        /// <value> The Washer Id. </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Name.
        /// </summary>
        /// <value> The Washer Name. </value>
        public string WasherName { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Number.
        /// </summary>
        /// <value>The Parameter WasherNumber. </value>
        public int WasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal Load.
        /// </summary>
        /// <value> NominalLoad. </value>
        public double NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load.
        /// </summary>
        /// <value> ActualLoad. </value>
        public double ActualLoad { get; set; }

        /// <summary>
        ///     Gets or sets the LoadEfficiency.
        /// </summary>
        /// <value> Parameter LoadEfficiency. </value>
        public double LoadEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the TimeEfficiency.
        /// </summary>
        /// <value> Parameter TimeEfficiency. </value>
        public double TimeEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Load.
        /// </summary>
        /// <value>The Lost Load. </value>
        public double LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Alarm.
        /// </summary>
        /// <value> The Alarm value. </value>
        public bool Alarm { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmDescription.
        /// </summary>
        /// <value> Parameter AlarmDescription. </value>
        public string AlarmDescription { get; set; }

        /// <summary>
        ///     Gets or sets the Status.
        /// </summary>
        /// <value>The Status value. </value>
        public string Status { get; set; }

        /// <summary>
        ///     Gets or sets the startTime
        /// </summary>
        /// <value>The start time.</value>
        public int startTime { get; set; }

        public int TargetTurnTime { get; set; }
        public int DefaultIdleTime { get; set; }
        /// <summary>
        ///     Gets or sets the List of ConventionalWasherBatchDetailsModel.
        /// </summary>
        /// <value> ConventionalWasherBatchDetailsModel List. </value>
        public List<BatchDetailsModel> BatchDetails { get; set; }
        public bool IsPLCConnected { get; set; }
        /// <summary>
        /// Gets or Sets The Dispenser Name
        /// </summary>
        public string DispenserName { get; set; }
        /// <summary>
        /// Get or sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Get or sets AverageEfficiency
        /// </summary>
        public int AverageEfficiency { get; set; }

        /// <summary>
        /// Gets or Sets CurrentBatchLoadEfficiency
        /// </summary>
        public int CurrentBatchLoadEfficiency { get; set; }
    }
}