﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>ConventionalWasher ViewModel Class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization.ConventionalWasher
{
    using System.Collections.Generic;

    /// <summary>
    ///     ConventionalWasherViewModel class
    /// </summary>
    public class ConventionalWasherViewModel
    {
        /// <summary>
        ///     Gets or sets the Actual Load.
        /// </summary>
        /// <value> ActualLoad. </value>
        public string ActualLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load Decimal
        /// </summary>
        /// <value> Actual Load Decimal. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "ActualLoadConverted")]
        public decimal ActualLoadDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load Converted.
        /// </summary>
        /// <value> Actual Load Converted. </value>
        public decimal ActualLoadConverted { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Load.
        /// </summary>
        /// <value>The LostLoad. </value>
        public string LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Load Decimal
        /// </summary>
        /// <value> Lost Load Decimal. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "LostLoadConverted")]
        public decimal LostLoadDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Load Converted.
        /// </summary>
        /// <value> Lost Load Converted. </value>
        public decimal LostLoadConverted { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value> Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the PlantLogo.
        /// </summary>
        /// <value>PlantLogo.</value>
        public string PlantLogo { get; set; }

        /// <summary>
        ///     Gets or sets the List of ConventionalWasherBatchDetailsModel.
        /// </summary>
        /// <value> ConventionalWasherBatchDetailsModel List. </value>
        public List<ConventionalWasherModel> ConventionalWashers { get; set; }

        public List<BreakAndTimelineModel> BreakAndTimelineDetails { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Color.
        /// </summary>
        /// <value> Weight Color. </value>
        public string WeightColor { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Level.
        /// </summary>
        /// <value> WeightLevel. </value>
        public string WeightLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency Color.
        /// </summary>
        /// <value> Efficiency Color. </value>
        public string EfficiencyColor { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency Level.
        /// </summary>
        /// <value> EfficiencyLevel. </value>
        public string EfficiencyLevel { get; set; }

        /// <summary>
        ///     Gets or sets the time in the Timeline
        /// </summary>
        public List<int> Time { get; set; }

        /// <summary>
        ///     Gets or sets the pixel value for each minute
        /// </summary>
        public double Pixel { get; set; }

        /// <summary>
        ///     Gets or sets the HoursToDisplay to base time line
        /// </summary>
        public int HoursToDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the Current time in Seconds
        /// </summary>
        public int CurrentTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the End time in Seconds
        /// </summary>
        public int EndTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the startTime
        /// </summary>
        public int startTime { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmWasherName.
        /// </summary>
        /// <value>The AlarmWasherName value. </value>
        public List<string> AlarmWasherName { get; set; }

        /// <summary>
        ///     Gets or sets the TimeLineWidth.
        /// </summary>
        /// <value>The TimeLineWidth. </value>
        public bool TimeLineWidth { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayFormula.
        /// </summary>
        /// <value>The DisplayFormula. </value>
        public bool DisplayFormula { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayType.
        /// </summary>
        /// <value>The FormulaDisplayType. </value>
        public int FormulaDisplayType { get; set; }
        /// <summary>
        /// get set the UOM
        /// </summary>
        public string UOM { get; set; }
        /// <summary>
        /// get set UOM Id
        /// </summary>
        public int UOMId { get; set; }
        /// <summary>
        /// Get or sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }
        
        /// <summary>
        /// Get or set region Id
        /// </summary>
        public int RegionId { get; set; }
    }
}