﻿// -----------------------------------------------------------------------
// <copyright file="TunnelModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel class </summary>

namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    using System.Collections.Generic;

    public class TunnelModel
    {
        /// <summary>
        ///     Gets or sets the Tunnel Id.
        /// </summary>
        /// <value>The TunnelId. </value>
        public int TunnelId { get; set; }

        /// <summary>
        ///     Gets or sets the Tunnel Name.
        /// </summary>
        /// <value> TunnelName. </value>
        public string TunnelName { get; set; }

        /// <summary>
        ///     Gets or sets the List of Compartments.
        /// </summary>
        /// <value> Compartments. </value>
        public List<CompartmentModel> Compartments { get; set; }

        /// <summary>
        ///     Gets or sets the Empty Pocket Count.
        /// </summary>
        /// <value> EmptyPocketCount. </value>
        public int EmptyPocketCount { get; set; }

        /// <summary>
        ///     Gets or sets the Transfer Rate.
        /// </summary>
        /// <value> TransferRate. </value>
        public int TransferRate { get; set; }

        /// <summary>
        ///     Gets or sets the Transfer Percent.
        /// </summary>
        /// <value> TransferPercent. </value>
        public double TransferPercent { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Status.
        /// </summary>
        /// <value> SignalStatus. </value>
        public int SignalStatus { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal Load.
        /// </summary>
        /// <value> NominalLoad. </value>
        public double NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load.
        /// </summary>
        /// <value> ActualLoad. </value>
        public double ActualLoad { get; set; }

        /// <summary>
        ///     Gets or sets the ActualLoadDecimal.
        /// </summary>
        /// <value> ActualLoadDecimal. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "ActualLoadConverted")]
        public decimal ActualLoadDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the ActualLoadConverted.
        /// </summary>
        /// <value> ActualLoadConverted. </value>
        public decimal ActualLoadConverted { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Weight.
        /// </summary>
        /// <value> ActualWeight. </value>
        public string ActualWeight { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value> Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the LostWeight.
        /// </summary>
        /// <value> LostWeight. </value>
        public double LostWeight { get; set; }

        /// <summary>
        ///     Gets or sets the WeightVarience.
        /// </summary>
        /// <value> WeightVarience. </value>
        public double WeightVarience { get; set; }

        /// <summary>
        ///     Gets or sets the Alarm to True/False.
        /// </summary>
        /// <value>The Alarm value. </value>
        public bool Alarm { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula.
        /// </summary>
        /// <value> EndOfFormula. </value>
        public int EndOfFormula { get; set; }

        /// <summary>
        ///      Gets or sets the EndOfFormula.
        /// </summary>
        /// <value> DisplayCustomer. </value>
        public bool DisplayCustomer { get; set; }
        /// <summary>
        /// get set the WasherNumber
        /// </summary>
        public int WasherNumber { get; set; }

        public double LoadEfficiency { get; set; }

        /// <summary>
        /// Gets or Sets the IsPLCConnected
        /// </summary>
        /// <value>Flag shows whether PLC is Connected</value>
        public bool IsPLCConnected { get; set; }
        /// <summary>
        /// Gets or Sets The Dispenser Name
        /// </summary>
        public string DispenserName{ get; set; }
        /// <summary>
        /// Get or sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Get or sets the AverageEfficiency
        /// </summary>
        public int AverageEfficiency { get; set; }
    }
}