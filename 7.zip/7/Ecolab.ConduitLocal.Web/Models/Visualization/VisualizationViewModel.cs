﻿// -----------------------------------------------------------------------
// <copyright file="VisualizationViewModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The VisualizationViewModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    using System.Collections.Generic;

    public class VisualizationViewModel
    {
        /// <summary>
        ///     Gets or sets the List of Tunnels.
        /// </summary>
        /// <value>The Tunnels. </value>
        public List<TunnelViewModel> Tunnels { get; set; }

        /// <summary>
        ///     Gets or sets the Total Weight.
        /// </summary>
        /// <value> TotalWeight. </value>
        public string TotalWeight { get; set; }

        /// <summary>
        ///     Gets or sets the Total Weight Decimal.
        /// </summary>
        /// <value> TotalWeight Decimal. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "TotalWeightConverted")]
        public decimal TotalWeightDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the Total Weight Converted.
        /// </summary>
        /// <value> TotalWeight Converted. </value>
        public decimal TotalWeightConverted { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> DesiredUnits. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value> Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the LostWeight.
        /// </summary>
        /// <value> LostWeight. </value>
        public string LostWeight { get; set; }

        /// <summary>
        ///     Gets or sets the LostWeight Decimal.
        /// </summary>
        /// <value> LostWeight Decimal. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "LostWeightConverted")]
        public decimal LostWeightDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the LostWeight Converted.
        /// </summary>
        /// <value> LostWeight Converted. </value>
        public decimal LostWeightConverted { get; set; }

        /// <summary>
        ///     Gets or sets the PlantLogo.
        /// </summary>
        /// <value>PlantLogo.</value>
        public string PlantLogo { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Color.
        /// </summary>
        /// <value> Weight Color. </value>
        public string WeightColor { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Level.
        /// </summary>
        /// <value> WeightLevel. </value>
        public string WeightLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency Color.
        /// </summary>
        /// <value> Efficiency Color. </value>
        public string EfficiencyColor { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency Level.
        /// </summary>
        /// <value> EfficiencyLevel. </value>
        public string EfficiencyLevel { get; set; }

        /// <summary>
        /// Gets or sets the UOM
        /// </summary>
        /// <value> UOM </value>
        public string UOM { get; set; }

        /// <summary>
        /// Gets or sets the UOM Id
        /// </summary>
        /// <value> UOM Id </value>
        public int UOMId { get; set; }
        /// <summary>
        /// Get or sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Get or set region Id
        /// </summary>
        public int RegionId { get; set; }
    }
}