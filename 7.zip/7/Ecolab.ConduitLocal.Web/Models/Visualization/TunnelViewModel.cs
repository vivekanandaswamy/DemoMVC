﻿// -----------------------------------------------------------------------
// <copyright file="TunnelViewModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelViewModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    public class TunnelViewModel
    {
        /// <summary>
        ///     Gets or sets the Tunnel details
        /// </summary>
        public TunnelModel Tunnel { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Color.
        /// </summary>
        /// <value> Weight Color. </value>
        public string WeightColor { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Level.
        /// </summary>
        /// <value> WeightLevel. </value>
        public string WeightLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Transfers Color.
        /// </summary>
        /// <value> Transfers Color. </value>
        public string TransferColor { get; set; }

        /// <summary>
        ///     Gets or sets the Transfers Level.
        /// </summary>
        /// <value> TransfersLevel. </value>
        public string TransferLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Conveyor Customer Id.
        /// </summary>
        /// <value> ConveyorCustomerId. </value>
        public int ConveyorCustomerId { get; set; }
        /// <summary>
        /// Get or sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Gets or sets the color of the transfer rate.
        /// </summary>
        /// <value>
        /// The color of the transfer rate.
        /// </value>
        public string TransferRateColor { get; set; }
    }
}