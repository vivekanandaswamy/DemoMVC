﻿// -----------------------------------------------------------------------
// <copyright file="CompartmentModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Compartment class </summary>

namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    using Common;

    public class CompartmentModel
    {
        /// <summary>
        ///     Gets or sets the Compartment Id.
        /// </summary>
        /// <value> CompartmentId. </value>
        public string CompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the Customer Id.
        /// </summary>
        /// <value> CustomerId. </value>
        public string CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> FormulaId. </value>
        public string ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the WeightLoaded.
        /// </summary>
        /// <value> WeightLoaded. </value>
        
        public double WeightLoaded { get; set; }

        /// <summary>
        ///     Gets or sets the WeightLoadedDecimal.
        /// </summary>
        /// <value> WeightLoadedDecimal. </value>
        /// 
        [UsageKeyAttribute("Mass_CommonUse_TCD", "WeightLoadedConverted")]
        public decimal WeightLoadedDecimal { get; set; }

        /// <summary>
        ///     Gets or sets the WeightLoadedConverted.
        /// </summary>
        /// <value> WeightLoadedConverted. </value>
        ///
        public decimal WeightLoadedConverted { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Expected.
        /// </summary>
        /// <value> WeightExpected. </value>
        public double WeightExpected { get; set; }

        /// <summary>
        ///     Gets or sets the Is Empty Pocket to True / False.
        /// </summary>
        /// <value> IsEmptyPocket. </value>
        public bool IsEmptyPocket { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value> The GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Expected.
        /// </summary>
        /// <value> WeightExpected. </value>
        public string WeightColor { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature.
        /// </summary>
        /// <value>  Parameter Temperature. </value>
        public double Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Conductivity.
        /// </summary>
        /// <value>  Parameter Conductivity. </value>
        public double Conductivity { get; set; }

        /// <summary>
        ///     Gets or sets the Ph.
        /// </summary>
        /// <value>  Parameter Ph. </value>
        public double Ph { get; set; }

        /// <summary>
        ///     Gets or sets the Status.
        /// </summary>
        /// <value> Status. </value>
        public int Status { get; set; }

        /// <summary>
        ///     Gets or sets the State of the Compartment.
        /// </summary>
        /// <value> CompartmentState. </value>
        public Enums.CompartmentState CompartmentState { get; set; }
    }
}