﻿// -----------------------------------------------------------------------
// <copyright file="DashboardsForHome.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DashboardsForHome class </summary>

namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    /// <summary>
    ///     DashboardsForHome Class
    /// </summary>
    public class DashboardsForHome
    {
        /// <summary>
        ///     Gets or sets the DashboardId .
        /// </summary>
        /// <value>  Parameter DashboardId. </value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeId.
        /// </summary>
        /// <value>  Parameter TypeId. </value>
        public int TypeId { get; set; }
    }
}