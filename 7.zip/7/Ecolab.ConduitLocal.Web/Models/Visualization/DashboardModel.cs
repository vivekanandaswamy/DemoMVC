﻿// -----------------------------------------------------------------------
// <copyright file="Dashboard.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dashboard class </summary>
namespace Ecolab.ConduitLocal.Web.Models.Visualization
{
    using System.Collections.Generic;
    public class DashboardModel
    {
        /// <summary>
        /// Gets or sets the Dashboard Id.
        /// </summary>
        /// <value> DashboardId. </value>
        public int DashboardId { get; set; }

        /// <summary>
        /// Gets or sets the List of Tunnels.
        /// </summary>
        /// <value> Tunnels. </value>
        public List<TunnelModel> Tunnels { get; set; }

        /// <summary>
        /// Gets or sets the Total Weight.
        /// </summary>
        /// <value> TotalWeight. </value>
        public double TotalWeight { get; set; }

        /// <summary>
        /// Gets or sets the Desired Units.
        /// </summary>
        /// <value> DesiredUnits. </value>
        public string DesiredUnits { get; set; }

        // <summary>
        /// Gets or sets the Efficiency.
        /// </summary>
        /// <value> Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        /// Gets or sets the LostWeight.
        /// </summary>
        /// <value> LostWeight. </value>
        public double LostWeight { get; set; }

    }
}
