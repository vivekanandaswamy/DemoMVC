﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupCompareModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherGroupCompareModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ecolab.ConduitLocal.Web.Models.ControllerSetup;
using Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps;
using Ecolab.ConduitLocal.Web.Models.Washers;

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
	///     Washer group Compare Model class consists of all entities for washer group formula.
	/// </summary>
    public class WasherGroupCompareModel
    {
        /// <summary>
        /// Gets or sets Washer group class consisting of all entities for washer group.
        /// </summary>
        public WasherGroup WasherGroupDetails { get; set; }

        /// <summary>
        /// Gets or sets list of the Washer Group Formula model for the washer group.
        /// </summary>
        public List<WasherGroupFormulaModel> WasherGroupFormulaDetailsList { get; set; }

        /// <summary>
        /// Gets or sets list of the Controller model for the washer group.
        /// </summary>
        public List<ControllerModel> DispenserSetupDetailsList { get; set; }

        /// <summary>
        /// Gets or sets list of the Injections details for the washer group.
        /// </summary>
        public List<InjectionData> InjectionDetailsList { get; set; }

        /// <summary>
        /// Gets or sets list of the Washers with details for the washer group.
        /// </summary>
        public List<WashersModel> WasherDetailsList { get; set; }

        /// <summary>
        /// Gets or sets list of the Pumps Details for the controller with in washer group.
        /// </summary>
        public List<PumpsModel> PumpsDetailsList { get; set; }

        /// <summary>
        ///     Gets or sets the Formula Id value.
        /// </summary>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the Dispenser Id value.
        /// </summary>
        public int DispenserId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Id value.
        /// </summary>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the Max Injection Count value.
        /// </summary>
        public int MaxInjectionCount { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Id value.
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal Load value.
        /// </summary>
        public int NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Injections Class value.
        /// </summary>
        public string InjectionClass { get; set; }

        /// <summary>
        ///     Gets or sets the Operation Class value.
        /// </summary>
        public int OperationClass { get; set; }

        /// <summary>
        ///     Gets or sets the Max Load value.
        /// </summary>
        public int MaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Injection Ratio value.
        /// </summary>
        public string InjectionRatio { get; set; }

        /// <summary>
        ///     Gets or sets the Error Message value.
        /// </summary>
        public string ErrorMsg { get; set; }

        /// <summary>
        ///     Gets or sets Whether Error is Controller Context.
        /// </summary>
        public bool IsError { get; set; }

        /// <summary>
        ///     Gets or sets Whether Error is from PLC.
        /// </summary>
        public bool IsPLCError { get; set; }
    }
}