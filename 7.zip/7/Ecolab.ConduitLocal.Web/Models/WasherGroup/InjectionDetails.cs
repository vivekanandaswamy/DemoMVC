﻿// -----------------------------------------------------------------------
// <copyright file="InjectionDetails.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The InjectionDetails </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    /// Class for InjectionDetails
    /// </summary>
    public class InjectionDetails
    {
        /// <summary>
        /// Gets or sets the washer dosing setup identifier.
        /// </summary>
        /// <value>
        /// The washer dosing setup identifier.
        /// </value>
        public short NominalLoad { get; set; }

        /// <summary>
        /// Gets or sets the washer dosing setup identifier.
        /// </summary>
        /// <value>
        /// The washer dosing setup identifier.
        /// </value>
        public int WasherDosingSetupId { get; set; }
        /// <summary>
        /// Gets or sets the program identifier.
        /// </summary>
        /// <value>
        /// The program identifier.
        /// </value>
        public int ProgramId { get; set; }

        /// <summary>
        /// Gets or sets the washer group number.
        /// </summary>
        /// <value>
        /// The washer group number.
        /// </value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        /// Gets or sets the injection number.
        /// </summary>
        /// <value>
        /// The injection number.
        /// </value>
        public short InjectionNumber { get; set; }

        /// <summary>
        /// Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>
        /// The controller equipment identifier.
        /// </value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name for Injection details.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>
        /// The quantity.
        /// </value>
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets the reference load.
        /// </summary>
        /// <value>
        /// The reference load.
        /// </value>
        public int ReferenceLoad { get; set; }

        /// <summary>
        /// Gets or sets the step number.
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets the wash operation identifier.
        /// </summary>
        /// <value>
        /// The wash operation identifier.
        /// </value>
        public int WashOperationId { get; set; }

        /// <summary>
        /// Gets or sets the wash operation.
        /// </summary>
        /// <value>
        /// The wash operation.
        /// </value>
        public string WashOperation { get; set; }

        /// <summary>
        /// Gets or sets the injection class.
        /// </summary>
        /// <value>
        /// The injection class.
        /// </value>
        public string InjectionClass { get; set; }

        /// <summary>
        /// Gets or sets the type of the controller.
        /// </summary>
        /// <value>
        /// The type of the controller.
        /// </value>
        public int ControllerType { get; set; }
        /// <summary>
        /// Gets or sets the controller identifier.
        /// </summary>
        /// <value>
        /// The controller identifier.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the total quantity.
        /// </summary>
        /// <value>
        /// The total quantity.
        /// </value>
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [PLC over ridden].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [PLC over ridden]; otherwise, <c>false</c>.
        /// </value>
        public bool PLCOverRidden { get; set; }
        /// <summary>
        /// Gets or sets the  WasherProgramSetupId.
        /// </summary>
        /// <value>
        /// The  WasherProgramSetupId.
        /// </value>
        public int WasherProgramSetupId { get; set; }

        /// <summary>
        /// Gets or sets CoolDownStep
        /// </summary>
        /// <value>
        /// The cool down step.
        /// </value>
        public int CoolDownStep { get; set; }

        /// <summary>
        /// Gets or sets the Water Type
        /// </summary>
        /// <value>
        /// The type of the water.
        /// </value>
        public string WaterType { get; set; }

        /// <summary>
        /// Gets or sets the Water Level
        /// </summary>
        /// <value>
        /// The water level.
        /// </value>
        public decimal? WaterLevel { get; set; }

        /// <summary>
        /// Gets or sets the WaterInlet/Drain
        /// </summary>
        /// <value>
        /// The water inlet drain.
        /// </value>
        public string WaterInletDrain { get; set; }

        /// <summary>
        /// Gets or sets the Temperature
        /// </summary>
        /// <value>
        /// The temperature.
        /// </value>
        public int Temperature { get; set; }

        /// <summary>
        /// Gets or sets the TotalRunTime
        /// </summary>
        /// <value>
        /// The total run time.
        /// </value>
        public int TotalRunTime { get; set; }

        /// <summary>
        /// Gets or sets the ExtraTime
        /// </summary>
        /// <value>
        /// The extra time.
        /// </value>
        public int ExtraTime { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer group.
        /// </summary>
        /// <value>
        /// The name of the washer group.
        /// </value>
        public string WasherGroupName { get; set; }

        /// <summary>
        /// Gets or sets WashStepNumber
        /// </summary>
        /// <value>
        /// The wash step number.
        /// </value>
		public int WashStepNumber { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public int EcolabTextileCategoryID { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public short Delay { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public int NoOfWashSteps { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public short LoadsPerMonth { get; set; }

        /// <summary>
        /// Gets or sets the TunnelDosing SetupId
        /// </summary>
        /// <value>
        /// The tunnel dosing setup identifier.
        /// </value>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        /// Gets or sets the Product Name
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the Program Number
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        public short ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets RunTime
        /// </summary>
        /// <value>
        /// The run time.
        /// </value>
        public int RunTime { get; set; }

        /// <summary>
        /// Gets or sets Drain Destination
        /// </summary>
        /// <value>
        /// The drain destination.
        /// </value>
        public int DrainDestination { get; set; }

        /// <summary>
        /// Gets or sets Washer Dosing Number
        /// </summary>
        /// <value>
        /// The washer dosing number.
        /// </value>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Gets or sets Washer Dosing Product Mapping Id
        /// </summary>
        /// <value>
        /// The washer dosing product mapping identifier.
        /// </value>
        public int WasherDosingProductMappingId { get; set; }

        /// <summary>
        /// Gets or sets Dosing Point Number
        /// </summary>
        /// <value>
        /// The dosing point number.
        /// </value>
        public byte DosingPointNumber { get; set; }

        /// <summary>
        /// Gets or sets Valve Number
        /// </summary>
        /// <value>
        /// The valve number.
        /// </value>
        public byte ValveNumber { get; set; }

        /// <summary>
        /// Gets or sets Is Direct Dosing
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is direct dosing; otherwise, <c>false</c>.
        /// </value>
        public bool IsDirectDosing { get; set; }
    }
}