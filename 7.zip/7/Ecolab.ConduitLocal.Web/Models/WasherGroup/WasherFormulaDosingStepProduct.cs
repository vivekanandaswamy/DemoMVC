﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaDosingStepProduct.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaDosingStepProduct class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Washer Formula Dosing Step Products
    /// </summary>
    public class WasherFormulaDosingStepProduct
    {
        /// <summary>
        /// Gets or sets Delay
        /// </summary>
        /// <value>
        /// The delay value.
        /// </value>
        public short Delay { get; set; }

        /// <summary>
        /// Gets or sets Product Id
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets Product Name
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        /// <value>
        /// The quantity value.
        /// </value>
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Step Number
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets Equipment Number
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public byte EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Dosing Point Number
        /// </summary>
        /// <value>
        /// The dosing point number.
        /// </value>
        public byte DosingPointNumber { get; set; }

        /// <summary>
        /// Gets or sets Injection Number
        /// </summary>
        /// <value>
        /// The injection number.
        /// </value>
        public short InjectionNumber { get; set; }

        /// <summary>
        /// Gets or sets Valve Number
        /// </summary>
        /// <value>
        /// The valve number.
        /// </value>
        public byte ValveNumber { get; set; }

        /// <summary>
        /// Gets or sets Is Direct Dosing
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is direct dosing; otherwise, <c>false</c>.
        /// </value>
        public bool IsDirectDosing { get; set; }
    }
}