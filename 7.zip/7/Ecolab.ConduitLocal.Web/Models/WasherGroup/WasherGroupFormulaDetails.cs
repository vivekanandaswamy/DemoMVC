﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaDetails.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherGroupFormulaDetails </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;
    using Ecolab.Models.WasherGroup;

    /// <summary>
    /// Washer Group Formula Details
    /// </summary>
    /// <remarks>
    /// This Class is useful to build structure for Washer Group Formula Setting for writing to MyControl PLC
    /// </remarks>
    public class WasherGroupFormulaDetails
    {
        /// <summary>
        /// Gets or sets Washer Group Type Id
        /// </summary>
        /// <value>
        /// The washer group type identifier.
        /// </value>
        public int WasherGroupTypeId { get; set; }

        /// <summary>
        /// Gets or sets Use Group1 Formula Used For Group2 For PLCXL
        /// </summary>
        /// <value>
        /// <c>true</c> if [use group1 formula used for group2 for PLCXL]; otherwise, <c>false</c>.
        /// </value>
        public bool UseGroup1FormulaUsedForGroup2ForPLCXL { get; set; }

        /// <summary>
        /// Gets or sets Washer Group Formulas
        /// </summary>
        /// <value>
        /// The washer group formulas.
        /// </value>
        public List<WasherFormula> WasherGroupFormulas { get; set; }

        /// <summary>
        /// Gets or sets Washer Group Deleted Formulas
        /// </summary>
        /// <value>
        /// The washer group Deleted formulas.
        /// </value>
        public List<WasherGroupFormula> WasherGroupDeletedFormulas { get; set; }

        /// <summary>
        /// Gets or sets Washer Dosing Number
        /// </summary>
        /// <value>
        /// The Washer Dosing Number.
        /// </value>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Are All Formulas Sent
        /// </summary>
        /// <value>
        /// Are All Formulas Sent TO PLC.
        /// </value>
        public bool AreSendAllFormulasToPLC { get; set; }
    }
}