﻿// -----------------------------------------------------------------------
// <copyright file="WashStepModel.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WashStep is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    ///     WashStep class consists of all entities WashStep.
    /// </summary>
    public class WashStepModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets and Sets the Step Id
        /// </summary>
        public int StepId { get; set; }

        /// <summary>
        ///     Gets and Sets the Step Name
        /// </summary>
        public string StepName { get; set; }

        /// <summary>
        ///     Gets or sets the RegionCode
        /// </summary>
        /// <value>The Parameter RegionCode</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the IsTunnel
        /// </summary>
        /// <value>The Parameter IsTunnel</value>
        public bool IsTunnel { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive
        /// </summary>
        /// <value>The Parameter IsActive</value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWshOpTypCd
        /// </summary>
        /// <value>The Parameter MyServiceWshOpTypCd</value>
        public string MyServiceWshOpTypCd { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWshOpId
        /// </summary>
        /// <value>The Parameter MyServiceWshOpId</value>
        public Int16 MyServiceWshOpId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}