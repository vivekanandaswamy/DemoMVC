﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalAnalogControl.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalAnalogueControl </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{

    /// <summary>
    /// Class for Conventional Analogue Control
    /// </summary>
    /// <seealso cref="Ecolab.ConduitLocal.Web.Models.BaseViewModel" />
    public class ConventionalAnalogueControl : BaseViewModel
    {
        /// <summary>
        /// Gets or Sets the Washer Dosing Setup Id
        /// </summary>
        /// <value>
        /// The Washer Dosing Setup Id
        /// </value>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        /// Gets or Sets the Temperature Set Point
        /// </summary>
        /// <value>
        /// The Temperature Set Point
        /// </value>
        public decimal TempSetPoint { get; set; }

        /// <summary>
        /// Gets or Sets the Minnimum Time
        /// </summary>
        /// <value>
        /// The Minimum Time
        /// </value>
        public int MinTime { get; set; }

        /// <summary>
        /// Gets or Sets the Start Delay
        /// </summary>
        /// <value>
        /// The Start Delay
        /// </value>
        public int StartDelay { get; set; }

        /// <summary>
        /// Gets or Sets the Accepted Delay
        /// </summary>
        /// <value>
        /// The Accepted Delay
        /// </value>
        public int AcceptedDelay { get; set; }

        /// <summary>
        /// Gets or Sets the Product Check
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public int ProductCheck { get; set; }

        /// <summary>
        /// Gets or Sets the PhControl During Drain
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public bool? PhControlDuringDrain { get; set; }

        /// <summary>
        /// Gets or Sets the PhDelay Time
        /// </summary>
        /// <value>
        /// The PhDelay Time
        /// </value>
        public int? PhDelayTime { get; set; }

        /// <summary>
        /// Gets or Sets the PhMeasuring Time
        /// </summary>
        /// <value>
        /// The PhMeasuring Time
        /// </value>
        public int? PhMeasuringTime { get; set; }

        /// <summary>
        /// Gets or Sets the PhMininum
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public decimal PhMininum { get; set; }

        /// <summary>
        /// Gets or Sets the PhMaximum
        /// </summary>
        /// <value>
        /// The Ph Maximum
        /// </value>
        public decimal PhMaximum { get; set; }

        /// <summary>
        /// Gets or Sets the Conventional Washer Id
        /// </summary>
        /// <value>
        /// The Conventional Washer Id
        /// </value>
        public int ConventionalWasherId { get; set; }
    }

}
