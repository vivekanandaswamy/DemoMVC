﻿// -----------------------------------------------------------------------
// <copyright file="ConductivityAnalogueControlStep.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConductivityAnalogueControlStep class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Conductivity Analogue Control Step
    /// </summary>
    public class ConductivityAnalogueControlStep
    {
        /// <summary>
        /// Gets or sets Compartment Number
        /// </summary>
        /// <value>
        /// The compartment number.
        /// </value>
        public int CompartmentNumber { get; set; }
        /// <summary>
        /// Gets or sets the conductivity delay time.
        /// </summary>
        /// <value>
        /// The conductivity delay time.
        /// </value>
        public int ConductivityDelayTime { get; set; }
        /// <summary>
        /// Gets or sets the conductivity maximum.
        /// </summary>
        /// <value>
        /// The conductivity maximum.
        /// </value>
        public decimal ConductivityMaximum { get; set; }
        /// <summary>
        /// Gets or sets the conductivity measuring time.
        /// </summary>
        /// <value>
        /// The conductivity measuring time.
        /// </value>
        public int ConductivityMeasuringTime { get; set; }
        /// <summary>
        /// Gets or sets the conductivity minimum.
        /// </summary>
        /// <value>
        /// The conductivity minimum.
        /// </value>
        public decimal ConductivityMinimum { get; set; }

        /// <summary>
        /// Gets or sets Conductivity Regulation Level
        /// </summary>
        /// <value>
        /// The conductivity regulation level.
        /// </value>
        public int ConductivityRegulationLevel { get; set; }

        /// <summary>
        /// Conductivity Probe Number
        /// </summary>
        /// <value>
        /// Conductivity Probe Number.
        /// </value>
        public int ProbeNumber { get; set; }
    }
}