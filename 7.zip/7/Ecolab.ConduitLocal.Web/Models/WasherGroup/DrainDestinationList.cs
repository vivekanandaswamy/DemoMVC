﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Gets or sets the types of drain destination List values.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    /// Properties for drain destination model
    /// </summary>
    public class DrainDestinationList : BaseViewModel
    {
        #region Properties

        /// <summary>
        ///     Gets or sets DrainDestinationId
        /// </summary>
        /// <value> Parameter DrainDestinationId</value>
        public int DrainDestinationId { get; set; }

        /// <summary>
        ///     Gets or sets DrainDestinationName
        /// </summary>
        /// <value> Parameter DrainDestinationName</value>
        public string DrainDestinationName { get; set; }

        #endregion
    }
}
