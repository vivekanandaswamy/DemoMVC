﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaTunnelAnalogueControl.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaTunnelAnalogueControl </summary>
// -----------------------------------------------------------------------
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    /// Washer Formula Tunnel Analogue Control
    /// </summary>
    public class WasherFormulaTunnelAnalogueControl
    {
        /// <summary>
        /// Washer Dosing Number
        /// </summary>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Program Number
        /// </summary>
        public int ProgramNumber { get; set; }

        /// <summary>
        /// Probe Number
        /// </summary>
        public int ProbeNumber { get; set; }

        /// <summary>
        /// Compartment Number
        /// </summary>
        public int CompartmentNumber { get; set; }

        /// <summary>
        /// Machine Compartment
        /// </summary>
        public int MachineCompartment { get; set; }

        /// <summary>
        /// Set Point Temparature
        /// </summary>
        public double SetPointTemparature { get; set; }

        /// <summary>
        /// Minimum Time
        /// </summary>
        public int MinimumTime { get; set; }

        /// <summary>
        /// Start Delay
        /// </summary>
        public int StartDelay { get; set; }

        /// <summary>
        /// Accepted Delay
        /// </summary>
        public int AcceptedDelay { get; set; }

        /// <summary>
        /// Product Check
        /// </summary>
        public bool ProductCheck { get; set; }

        /// <summary>
        /// PH Regulation Level
        /// </summary>
        public int PHRegulationLevel { get; set; }

        /// <summary>
        /// PH Monitoring Level
        /// </summary>
        public int PHMonitoringLevel { get; set; }

        /// <summary>
        /// PH Minimum
        /// </summary>
        public decimal PHMinimum { get; set; }

        /// <summary>
        /// PH Maximum
        /// </summary>
        public decimal PHMaximum { get; set; }

        /// <summary>
        /// Delay Time
        /// </summary>
        public int DelayTime { get; set; }

        /// <summary>
        /// Measuring Time
        /// </summary>
        public int MeasuringTime { get; set; }

        /// <summary>
        /// Conductivity Regulation Level
        /// </summary>
        public int ConductivityRegulationLevel { get; set; }

        /// <summary>
        /// Conductivity Mininum
        /// </summary>
        public decimal ConductivityMininum { get; set; }

        /// <summary>
        /// Conductivity Maximum
        /// </summary>
        public decimal ConductivityMaximum { get; set; }

        /// <summary>
        /// Conductivity Delay Time
        /// </summary>
        public int ConductivityDelayTime { get; set; }

        /// <summary>
        /// Conductivity Measuring Time
        /// </summary>
        public int ConductivityMeasuringTime { get; set; }

        /// <summary>
        /// Sensor Type
        /// </summary>
        public int SensorType { get; set; }
    }
}