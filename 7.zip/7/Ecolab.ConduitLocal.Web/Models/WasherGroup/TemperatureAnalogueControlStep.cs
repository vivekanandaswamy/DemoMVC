﻿// -----------------------------------------------------------------------
// <copyright file="TemperatureAnalogueControlStep.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TemperatureAnalogueControlStep class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Temperature Analogue Control Step
    /// </summary>
    public class TemperatureAnalogueControlStep
    {
        /// <summary>
        /// Gets or sets The Step Number
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets Equipment Number
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public byte EquipmentNumber { get; set; }

        /// <summary>
        /// Minimum Time
        /// </summary>
        public short MinimumTime { get; set; }

        /// <summary>
        /// Gets or sets The Start Delay
        /// </summary>
        /// <value>
        /// The start delay.
        /// </value>
        public short StartDelay { get; set; }

        /// <summary>
        /// Gets or sets The Accepted Delay
        /// </summary>
        /// <value>
        /// The accepted delay.
        /// </value>
        public short AcceptedDelay { get; set; }

        /// <summary>
        /// Gets or sets The Product Id
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets Set Point Temperature
        /// </summary>
        /// <value>
        /// The set point temperature.
        /// </value>
        public decimal SetPointTemperature { get; set; }

        /// <summary>
        /// Gets or sets The Product Check
        /// </summary>
        /// <value>
        ///   <c>true</c> if [product check]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductCheck { get; set; }

        /// <summary>
        /// Gets or sets Compartment Number
        /// </summary>
        /// <value>
        /// The compartment number.
        /// </value>
        public int CompartmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Accepted Delay
        /// </summary>
        /// <value>
        /// The tunnel accepted delay.
        /// </value>
        public int TunnelAcceptedDelay { get; set; }

        /// <summary>
        /// Gets or sets The Minimum Time
        /// </summary>
        /// <value>
        /// The tunnel minimum time.
        /// </value>
        public int TunnelMinimumTime { get; set; }

        /// <summary>
        /// Gets or sets The Start Delay
        /// </summary>
        /// <value>
        /// The tunnel start delay.
        /// </value>
        public int TunnelStartDelay { get; set; }

        /// <summary>
        /// Gets or sets Set Point Temperature
        /// </summary>
        /// <value>
        /// The tunnel set point temperature.
        /// </value>
        public double TunnelSetPointTemperature { get; set; }

        /// <summary>
        /// Temperature Probe Number
        /// </summary>
        /// <value>
        /// Temperature Probe Number.
        /// </value>
        public int ProbeNumber { get; set; }
    }
}