﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaLists.cs" company="Ecolab">
// Gets the list of detalis of the washergroupformula for WasherGroupFormulaController Controller class.
// </copyright>
// <summary>The methods for washer group formula setup.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;
    using PlantSetup;
    using PlantSetup.Chemical;
    using Washers;

    public class WasherGroupFormulaLists
    {
        /// <summary>
        ///     Gets or sets the list of washer group details.
        /// </summary>
        public IEnumerable<WasherGroup> WasherGroupDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washer group formula items.
        /// </summary>
        public List<WasherGroupFormulaModel> WasherGroupFormulaDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washer step items.
        /// </summary>
        public List<WashStepModel> WashOperationDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of free water types  for plant utility setup.
        /// </summary>
        public List<PlantUtilityWaterTypeMasterModel> WasheStepWaterTypes { get; set; }

        /// <summary>
        ///     Gets or sets the list of all wash steps.
        /// </summary>
        public List<WasherFormulaWashStepModel> WasherGroupFormulaWashStepModel { get; set; }

        /// <summary>
        ///     Gets or sets the list of all wash steps with Dosing.
        /// </summary>
        public List<KeyValuePair<int, int>> WashStepsWithDosing { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washers Model details.
        /// </summary>
        public IEnumerable<WashersModel> WashersList { get; set; }

        /// <summary>
        ///     Gets or sets the list of Chemicals for washer.
        /// </summary>
        public IEnumerable<ChemicalsModel> GetChemicalList { get; set; }

        /// <summary>
        /// Gets or sets the list of drain destination items.
        /// </summary>
        public List<DrainDestinationList> GetDrainDestinationsList { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washer group formula items.
        /// </summary>
        public List<WasherGroupFormulaModel> WasherGroupFormulaNumbers { get; set; }

        /// <summary>
        /// Default Drain Destination ID
        /// </summary>
        public int DefaultDrainDestination { get; set; }

		/// <summary>
		/// Gets or sets NextAvailableWasherGroupNumber
		/// </summary>
		public int NextAvailableWasherGroupNumber { get; set; }
       
        /// <summary>
        /// RegionId
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        /// SensorAttached
        /// </summary>
        public string SensorAttached { get; set; }
    }
}