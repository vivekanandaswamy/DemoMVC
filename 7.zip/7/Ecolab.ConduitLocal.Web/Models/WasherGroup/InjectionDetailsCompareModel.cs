﻿// -----------------------------------------------------------------------
// <copyright file="InjectionDetailsCompareModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The InjectionDetailsCompareModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    public class InjectionDetailsCompareModel
    {
        public int Quantity { get; set; }

        public int TotalQuantity { get; set; }

        public bool PLCOverriden { get; set; }
    }
}