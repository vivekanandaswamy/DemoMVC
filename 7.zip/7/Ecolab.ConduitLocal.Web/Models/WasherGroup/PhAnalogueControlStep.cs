﻿// -----------------------------------------------------------------------
// <copyright file="PhAnalogueControlStep.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PhAnalogueControlStep class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Ph Analogue Control Step
    /// </summary>
    public class PhAnalogueControlStep
    {
        /// <summary>
        /// Gets or sets The Step Number
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets Ph Control During Drain
        /// </summary>
        /// <value>
        /// <c>true</c> if [ph control during drain]; otherwise, <c>false</c>.
        /// </value>
        public bool PhControlDuringDrain { get; set; }

        /// <summary>
        /// Gets or sets Ph Delay Time
        /// </summary>
        /// <value>
        /// The ph delay time.
        /// </value>
        public int PhDelayTime { get; set; }

        /// <summary>
        /// Gets or sets Ph Measuring Time
        /// </summary>
        /// <value>
        /// The ph measuring time.
        /// </value>
        public int PhMeasuringTime { get; set; }

        /// <summary>
        /// Gets or sets The Ph Maximum
        /// </summary>
        /// <value>
        /// The ph maximum.
        /// </value>
        public decimal PhMaximum { get; set; }

        /// <summary>
        /// Gets or sets The Ph Mininum
        /// </summary>
        /// <value>
        /// The ph minimum.
        /// </value>
        public decimal PhMinimum { get; set; }

        /// <summary>
        /// Gets or sets Compartment Number
        /// </summary>
        /// <value>
        /// The compartment number.
        /// </value>
        public int CompartmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Ph Regulation Level
        /// </summary>
        /// <value>
        /// The ph regulation level.
        /// </value>
        public int PhRegulationLevel { get; set; }

        /// <summary>
        /// Gets or sets Ph Monitoring Level
        /// </summary>
        /// <value>
        /// The ph monitoring level.
        /// </value>
        public int PhMonitoringLevel { get; set; }

        /// <summary>
        /// Ph Probe Number
        /// </summary>
        /// <value>
        /// Ph Probe Number.
        /// </value>
        public int ProbeNumber { get; set; }
    }
}