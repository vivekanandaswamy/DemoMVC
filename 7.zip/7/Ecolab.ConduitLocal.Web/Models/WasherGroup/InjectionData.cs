﻿// -----------------------------------------------------------------------
// <copyright file="InjectionData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The InjectionData </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    public class InjectionData : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the washer identifier.
        /// </summary>
        /// <value>
        /// The washer identifier.
        /// </value>
        public int WasherId { get; set; }
        /// <summary>
        /// Gets or sets the washer group number.
        /// </summary>
        /// <value>
        /// The washer group number.
        /// </value>
        public string WasherGroupNumber { get; set; }
        /// <summary>
        /// Gets or sets the injection class.
        /// </summary>
        /// <value>
        /// The injection class.
        /// </value>
        public string InjectionClass { get; set; }
        /// <summary>
        /// Gets or sets the controller identifier.
        /// </summary>
        /// <value>
        /// The controller identifier.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the reference load.
        /// </summary>
        /// <value>
        /// The reference load.
        /// </value>
        public int ReferenceLoad { get; set; }

        /// <summary>
        /// Gets or sets the injection class tag.
        /// </summary>
        /// <value>
        /// The injection class tag.
        /// </value>
        public string InjectionClassTag { get; set; }
        /// <summary>
        /// Gets or sets the injection ratio tag.
        /// </summary>
        /// <value>
        /// The injection ratio tag.
        /// </value>
        public string InjectionRatioTag { get; set; }
        /// <summary>
        /// Gets or sets the capacity.
        /// </summary>
        /// <value>
        /// The capacity.
        /// </value>
        public short Capacity { get; set; }
    }
}