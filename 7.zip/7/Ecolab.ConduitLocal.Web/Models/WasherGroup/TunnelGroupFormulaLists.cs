﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGroupFormulaLists.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The TunnelGroupFormulaLists Model is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;
    using PlantSetup;

    /// <summary>
    ///     /// TunnelGroupFormulaLists class consists of all entities Tunnel.
    /// </summary>
    public class TunnelGroupFormulaLists
    {
        /// <summary>
        ///     Gets or sets the list of washer group details.
        /// </summary>
        public List<WasherGroup> WasherGroupDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washer group formula items.
        /// </summary>
        public List<WasherGroupFormulaModel> WasherGroupFormulaDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of Washer step items.
        /// </summary>
        public List<WashStepModel> WashOperationDetails { get; set; }

        /// <summary>
        ///     Gets or sets the list of free water types  for plant utility setup.
        /// </summary>
        public List<PlantUtilityWaterTypeMasterModel> WasheStepWaterTypes { get; set; }

        /// <summary>
        ///     Gets or sets the wash step.
        /// </summary>
        public List<TunnelWashStepModel> TunnelWashStepsModel { get; set; }

        /// <summary>
        ///     Gets or sets the list of all wash steps with Dosing.
        /// </summary>
        public List<KeyValuePair<int, int>> WashStepsWithDosing { get; set; }

        /// <summary>
        ///     Gets or sets the list of Tunnel Products With Injection Count items.
        /// </summary>
        public List<TunnelWashStepProductsModel> TunnelProductsWithInjectionCount { get; set; }
    }
}