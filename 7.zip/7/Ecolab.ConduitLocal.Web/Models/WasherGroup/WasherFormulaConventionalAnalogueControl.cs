﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaConventionalAnalogueControl.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaConventionalAnalogueControl </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    /// Washer Formula Conventional Analogue Control
    /// </summary>
    public class WasherFormulaConventionalAnalogueControl : BaseViewModel
    {
        #region Properties

        /// <summary>
        /// Washer Dosing Number
        /// </summary>
        public int WasherDosingNumber { get; private set; }

        /// <summary>
        /// Program Number
        /// </summary>
        public short ProgramNumber { get; set; }

        /// <summary>
        /// Step Number
        /// </summary>
        public int StepNumber { get; set; }

        /// <summary>
        /// Washer Dosing Setup Id
        /// </summary>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        /// Equipment Number
        /// </summary>
        public byte EquipmentNumber { get; set; }

        /// <summary>
        /// Minimum Time
        /// </summary>
        public short MinimumTime { get; set; }

        /// <summary>
        /// Start Delay
        /// </summary>
        public short StartDelay { get; set; }

        /// <summary>
        /// Accepted Delay
        /// </summary>
        public short AcceptedDelay { get; set; }

        /// <summary>
        /// Product Id
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Set Point Temperature
        /// </summary>
        public decimal SetPointTemperature { get; set; }

        /// <summary>
        /// Ph control during drain
        /// </summary>
        public bool PhControlDuringDrain { get; set; }

        /// <summary>
        /// Phdelaytime
        /// </summary>
        public short PhDelayTime { get; set; }

        /// <summary>
        /// Phmeasuringtime
        /// </summary>
        public short PhMeasuringTime { get; set; }

        /// <summary>
        /// Ph maximum
        /// </summary>
        public decimal PhMaximum { get; set; }

        /// <summary>
        /// Ph mininum
        /// </summary>
        public decimal PhMininum { get; set; }

        /// <summary>
        /// Product Check
        /// </summary>
        public bool ProductCheck { get; set; }

        /// <summary>
        /// Sensor Number
        /// </summary>
        public int SensorNum { get; set; }

        /// <summary>
        /// Sensor Type
        /// </summary>
        public int SensorType { get; set; }

        #endregion
    }
}