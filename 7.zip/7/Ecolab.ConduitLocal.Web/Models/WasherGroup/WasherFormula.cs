﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormula.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormula class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Washer Formula
    /// </summary>
    public class WasherFormula
    {
        /// <summary>
        /// Gets or sets Cool Down Step
        /// </summary>
        /// <value>
        /// The cool down step.
        /// </value>
        public int CoolDownStep { get; set; }

        /// <summary>
        /// Gets or sets Ecolab Textile Category
        /// </summary>
        /// <value>
        /// The ecolab textile category identifier.
        /// </value>
        public int EcolabTextileCategoryID { get; set; }

        /// <summary>
        /// Gets or sets The Extra Time
        /// </summary>
        /// <value>
        /// The extra time.
        /// </value>
        public int ExtraTime { get; set; }

        /// <summary>
        /// Gets or sets Nominal Load
        /// </summary>
        /// <value>
        /// The nominal load.
        /// </value>
        public short NominalLoad { get; set; }

        /// <summary>
        /// Gets or sets The Program Id
        /// </summary>
        /// <value>
        /// The program identifier.
        /// </value>
        public int ProgramId { get; set; }

        /// <summary>
        /// Gets or sets Program Number
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        public int ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets The Total RunTime
        /// </summary>
        /// <value>
        /// The total run time.
        /// </value>
        public int TotalRunTime { get; set; }

        /// <summary>
        /// Gets or sets Wash Steps Count
        /// </summary>
        /// <value>
        /// The wash steps count.
        /// </value>
        public int WashStepsCount { get; set; }

        /// <summary>
        /// Gets or sets The Step Number
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets Washer Dosing Number
        /// </summary>
        /// <value>
        /// The washer dosing number.
        /// </value>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Gets or sets Washer Formula Dosing Steps
        /// </summary>
        /// <value>
        /// The washer formula dosing steps.
        /// </value>
        public List<WasherFormulaDosingStep> WasherFormulaDosingSteps { get; set; }

        /// <summary>
        /// Gets or sets Washer Formula Temperature Analogue Control Steps
        /// </summary>
        /// <value>
        /// The washer formula temperature analogue control steps.
        /// </value>
        public List<TemperatureAnalogueControlStep> washerFormulaTemperatureAnalogueControlSteps { get; set; }

        /// <summary>
        /// Gets or sets Washer Formula Ph Analogue Control Steps
        /// </summary>
        /// <value>
        /// The washer formula ph analogue control steps.
        /// </value>
        public List<PhAnalogueControlStep> washerFormulaPhAnalogueControlSteps { get; set; }

        /// <summary>
        /// Gets or sets Washer Formula Ph Analogue Control Steps
        /// </summary>
        /// <value>
        /// The washer formula conductivity analogue control steps.
        /// </value>
        public List<ConductivityAnalogueControlStep> washerFormulaConductivityAnalogueControlSteps { get; set; }
    }
}