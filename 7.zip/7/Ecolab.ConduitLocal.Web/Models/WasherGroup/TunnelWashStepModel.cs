﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWashStepModel.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The Tunnel Model is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;

    /// <summary>
    ///     /// Tunnel class consists of all entities Tunnel.
    /// </summary>
    public class TunnelWashStepModel : BaseViewModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Program Number
        /// </summary>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Group Id
        /// </summary>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Step Type Id
        /// </summary>
        public int StepTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Step RunTime
        /// </summary>
        public int StepRunTime { get; set; }

        /// <summary>
        ///     Gets or sets the Compartment Number
        /// </summary>
        public int CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature
        /// </summary>
        public int Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the TunnelDosing SetupId
        /// </summary>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the Water Type
        /// </summary>
        public string WaterType { get; set; }

        /// <summary>
        ///     Gets or sets the Water Level
        /// </summary>
        public decimal? WaterLevel { get; set; }

        /// <summary>
        ///     Gets or sets the WaterInlet/Drain
        /// </summary>
        public string WaterInletDrain { get; set; }

        /// <summary>
        ///     Gets or sets the Note
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        ///     Gets or sets the Tunnel Program SetupId
        /// </summary>
        public int TunnelProgramSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the RunTime
        /// </summary>
        public string RunTime { get; set; }

        /// <summary>
        ///     /Gets or sets ProductsList
        /// </summary>
        public List<TunnelWashStepProductsModel> ProductsList { get; set; }
        
        /// <summary>
        /// Gets or sets the Water flow value.
        /// </summary>
        /// <value>The parameter value of Waterflow.</value>
        public string WaterFlow { get; set; }

        /// <summary>
        /// Gets or Sets the Tunnel Analogue Control
        /// </summary>
        /// <value>The Tunnel Analogue Control</value>
        public TunnelAnalogueControlModel TunnelAnalogueControl { get; set; }

        /// <summary>
        /// Gets or Sets sensor types attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Sensor types attached to the particular compartment</value>
        public string SensorTypeAttached { get; set; }

        /// <summary>
        /// Gets or Sets Probe/Sensor number attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Probe/Sensor Number attached to the particular compartment</value>
        public int Probenumber { get; set; }
        /// <summary>
        /// Gets or Sets Ph Sensor number attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Ph Sensor number number attached to the particular compartment</value>
        public int PhSensorNumber { get; set; }

        #endregion "Properties"
    }
}