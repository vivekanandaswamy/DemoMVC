﻿// -----------------------------------------------------------------------
// <copyright file="CopyFormulaContainerModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CopyFormulaContainerModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Ecolab.ConduitLocal.Web.Models.PlantSetup.Chemical;
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
	public class CopyFormulaContainerModel : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<CopyFormula> FormulaList { get; set; }

		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<SubstituteChemicalModel> MissingChemicalList { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedTimestampAtCentral
		/// </summary>
		/// <value>LastModifiedTimestampAtCentral</value>
		public DateTime? LastModifiedTimestampAtCentral { get; set; }

		/// <summary>
		/// Gets or sets MaxNumberOfRecords
		/// </summary>
		public int MaxNumberOfRecords { get; set; }
	}
}