﻿// -----------------------------------------------------------------------
// <copyright file="TunnelAnalogueControlModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelAnalogueControlModel </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
	public class TunnelAnalogueControlModel : BaseViewModel
	{
        /// <summary>
        /// Gets or Sets the Temperature Set Point
        /// </summary>
        /// <value>The Temperature Set Point</value>
        public double TempSetPoint { get; set; }
        /// <summary>
        /// Gets or Sets the Minnimum Time
        /// </summary>
        /// <value>The Minimum Time</value>
        public int MinTime { get; set; }
        /// <summary>
        /// Gets or Sets the Start Delay
        /// </summary>
        /// <value>The Start Delay</value>
        public int StartDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Accepted Delay
        /// </summary>
        /// <value>The Accepted Delay</value>
        public int AcceptedDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Product Check
        /// </summary>
        /// <value>The Product Check</value>
        public bool? ProductCheck { get; set; }
        /// <summary>
        /// The PH Regulation Level
        /// </summary>
        /// <value>The PH Regulation Level</value>
        public int? PhRegulationLevel { get; set; }
        /// <summary>
        /// The Monitoring Level
        /// </summary>
        /// <value>The Monitoring Level</value>
        public int? MonitoringLevel { get; set; }
        /// <summary>
        /// The Conductivity Regulation Level
        /// </summary>
        /// <value>The Conductivity Regulation Level</value>
        public int? ConductivityRegulationLevel { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Program Setup Id
        /// </summary>
        /// <value>The Tunnel Program Setup Id</value>
        public int TunnelprogramSetupId { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Compartment Number
        /// </summary>
        /// <value>The Tunnel Compartment Number</value>
        public int TunnelCompartmentNumber { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Washer Id
        /// </summary>
        /// <value>The Tunnel Washer Id</value>
        public int TunnelWasherId { get; set; }

        /// <summary>
        /// pH Min
        /// </summary>
        public decimal pHMin { get; set; }

        /// <summary>
        /// pH Max
        /// </summary>
        public decimal pHMax { get; set; }

        /// <summary>
        /// pH Start Delay
        /// </summary>
        public int pHStartDelay { get; set; }

        /// <summary>
        /// pH Measuring Time
        /// </summary>
        public int pHMeasTime { get; set; }

        /// <summary>
        /// Conductivity Min
        /// </summary>
        public decimal ConductivityMin { get; set; }

        /// <summary>
        /// Conductivity Max
        /// </summary>
        public decimal ConductivityMax { get; set; }

        /// <summary>
        /// Conductivity Delay Time
        /// </summary>
        public int ConductivityDelayTime { get; set; }

        /// <summary>
        /// Conductivity Measuring Time
        /// </summary>
        public int ConductivityMeasTime { get; set; }
    }
}