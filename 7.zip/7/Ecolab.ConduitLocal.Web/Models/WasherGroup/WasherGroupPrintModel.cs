﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupPrintModel.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherGroup PrintModel is for printing the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;
    using WebModel = Models.WasherGroup;

    /// <summary>
    ///     Class WasherGroupPrintModel
    /// </summary>
    public class WasherGroupPrintModel
    {
        /// <summary>
        ///     Gets or sets the value WasherGroupList
        /// </summary>
        /// <value>List of all WasherGroups</value>
        public IEnumerable<WasherGroup> WasherGroupList { get; set; }

        /// <summary>
        ///     Gets or sets the value WasherGroupWithWashers
        /// </summary>
        /// <value> List of all WasherGroups with washers</value>
        public List<WasherGroupFormulaLists> WasherGroupWithWashers { get; set; }
    }
}