﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaDosingStep.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaDosingStep class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Washer Formula Dosing Step
    /// </summary>
    public class WasherFormulaDosingStep
    {
        /// <summary>
        /// Gets or sets Compartment Number Or Wash Step Number
        /// </summary>
        /// <value>
        /// The compartment number or wash step number.
        /// </value>
        public int CompartmentNumberOrWashStepNumber { get; set; }

        /// <summary>
        /// Gets or sets Dosage Step Number
        /// </summary>
        /// <value>
        /// The dosage step number.
        /// </value>
        public int DosageStepNumber { get; set; }

        /// <summary>
        /// Gets or sets Drain Destination
        /// </summary>
        /// <value>
        /// The drain destination.
        /// </value>
        public int DrainDestination { get; set; }

        /// <summary>
        /// Gets or sets The Run Time
        /// </summary>
        /// <value>
        /// The run time.
        /// </value>
        public int RunTime { get; set; }

        /// <summary>
        /// Gets or sets The Temparature Value
        /// </summary>
        /// <value>
        /// The temparature.
        /// </value>
        public int Temparature { get; set; }

        /// <summary>
        /// Gets or sets Wash Operations
        /// </summary>
        /// <value>
        /// The wash operations.
        /// </value>
        public string WashOperations { get; set; }

        /// <summary>
        /// Gets or sets Water Inlet Or Drain
        /// </summary>
        /// <value>
        /// The water inlet drain.
        /// </value>
        public string WaterInletDrain { get; set; }

        /// <summary>
        /// Gets or sets The Water Level
        /// </summary>
        /// <value>
        /// The water level.
        /// </value>
        public decimal? WaterLevel { get; set; }

        /// <summary>
        /// Gets or sets The Water Type
        /// </summary>
        /// <value>
        /// The type of the water.
        /// </value>
        public string WaterType { get; set; }

        /// <summary>
        /// Gets or sets Controller Equipment Id
        /// </summary>
        /// <value>
        /// The controller equipment identifier.
        /// </value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets Washer Formula Dosing Step Products
        /// </summary>
        /// <value>
        /// The washer formula dosing step products.
        /// </value>
        public List<WasherFormulaDosingStepProduct> WasherFormulaDosingStepProducts { get; set; }
    }
}