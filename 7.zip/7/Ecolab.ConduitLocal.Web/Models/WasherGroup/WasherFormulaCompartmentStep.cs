﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    /// <summary>
    /// Washer Formula Compartment Step
    /// </summary>
    public class WasherFormulaCompartmentStep
    {
        /// <summary>
        /// Gets or sets Compartment Number Or Wash Step Number
        /// </summary>
        /// <value>
        /// The compartment number or wash step number.
        /// </value>
        public int CompartmentNumberOrWashStepNumber { get; set; }

        /// <summary>
        /// Gets or sets Temparature Control SetPoint
        /// </summary>
        /// <value>
        /// The temparature control set point.
        /// </value>
        public double TemparatureControlSetPoint { get; set; }

        /// <summary>
        /// Gets or sets Temparature Control Start Delay
        /// </summary>
        /// <value>
        /// The temparature control start delay.
        /// </value>
        public int TemparatureControlStartDelay { get; set; }

        /// <summary>
        /// Gets or sets Temparature Control Minimum Time
        /// </summary>
        /// <value>
        /// The temparature control minimum time.
        /// </value>
        public int TemparatureControlMinimumTime { get; set; }

        /// <summary>
        /// Gets or sets Temparature Control Accepted Delay
        /// </summary>
        /// <value>
        /// The temparature control accepted delay.
        /// </value>
        public int TemparatureControlAcceptedDelay { get; set; }

        /// <summary>
        /// Gets or sets Temparature Control Product Check
        /// </summary>
        /// <value>
        /// The temparature control product check.
        /// </value>
        public bool? TemparatureControlProductCheck { get; set; }
    }
}