﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaWashStepModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
    using System.Collections.Generic;

    public class WasherFormulaWashStepModel : BaseViewModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets and sets the ProgramNumber
        /// </summary>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets and sets the ProgramSetupId
        /// </summary>
        public int ProgramSetupId { get; set; }

        /// <summary>
        ///     Gets and sets the WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets and sets the StepNumber
        /// </summary>
        public int StepNumber { get; set; }

        /// <summary>
        ///     Gets and sets the WashOperationId
        /// </summary>
        public int WashOperationId { get; set; }

        /// <summary>
        ///     Gets and sets the WashOperation
        /// </summary>
        public string WashOperation { get; set; }

        /// <summary>
        ///     Gets and sets the RunTime
        /// </summary>
        public int RunTime { get; set; }

        /// <summary>
        ///     Gets and sets the Temperature
        /// </summary>
        public int Temperature { get; set; }

        /// <summary>
        ///     Gets and sets the WaterType
        /// </summary>
        public string WaterType { get; set; }

        /// <summary>
        ///     Gets and sets the WaterLevel
        /// </summary>
        public decimal WaterLevel { get; set; }

        /// <summary>
        ///     Gets and sets the DrainDestinationId
        /// </summary>
        public short DrainDestinationId { get; set; }

        /// <summary>
        ///     Gets and sets the DrainDestination
        /// </summary>
        public string DrainDestination { get; set; }

        /// <summary>
        ///     Gets and sets the pHLevel
        /// </summary>
        public short PHLevel { get; set; }

        /// <summary>
        ///     Gets and sets the Note
        /// </summary>
        public string Note { get; set; }

        /// <summary>
        ///     Gets and sets the RegionId
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Note
        /// </summary>
        /// <value>The Parameter Note</value>
        public string StepRunTime { get; set; }

        /// <summary>
        ///     Gets or sets WasherDosingProductModel
        /// </summary>
        public List<WasherDosingProductModel> WasherDosingProducts { get; set; }

        /// <summary>
        ///     Gets or sets ConventionalAnalogueModel
        /// </summary>
        public Ecolab.Models.WasherGroup.ConventionalAnalogueControl  ConventionalAnalogue { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> MyServiceModDtTm</value>
        public int CurrentWashStep { get; set; }

        /// <summary>
        /// Gets or sets theSensorAttached.
        /// </summary>
        /// <value>The SensorAttached.</value>
        public string SensorAttached { get; set; }

        /// <summary>
        /// Gets or sets Trackasdosingstep.
        /// </summary>
        /// <value>The Trackasdosingstep.</value>
        public bool Trackasdosingstep { get; set; }

        #endregion
    }
}