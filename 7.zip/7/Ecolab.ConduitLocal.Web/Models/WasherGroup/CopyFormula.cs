﻿// -----------------------------------------------------------------------
// <copyright file="CopyFormula.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CopyFormula </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.WasherGroup
{
	public class CopyFormula : BaseViewModel
	{
		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public int FromWasherGroupId { get; set; }

		/// <summary>
		/// Gets or sets the ToWasherGroupId 
		/// </summary>
		/// <value>
		/// The ToWasherGroupId
		/// </value>
		public int ToWasherGroupId { get; set; }

		/// <summary>
		/// Gets or sets WasherProgramSetupId
		/// </summary>
		/// <value>
		/// The WasherProgramSetupId
		/// </value>
		public int WasherProgramSetupId { get; set; }

		/// <summary>
		/// Gets or sets the ProgramId identifier.
		/// </summary>
		/// <value>
		/// The ProgramId identifier.
		/// </value>
		public int ProgramId { get; set; }

		/// <summary>
		/// Gets or sets the ProgramNumber
		/// </summary>
		/// <value>
		/// The ProgramNumber
		/// </value>
		public int ProgramNumber { get; set; }

		/// <summary>
		/// Gets or sets WasherGroupTypeName
		/// </summary>
		public string WasherGroupTypeName { get; set; }

		/// <summary>
		/// Gets or sets MaxNumberOfRecords
		/// </summary>
		public int MaxNumberOfRecords { get; set; }
	}
}