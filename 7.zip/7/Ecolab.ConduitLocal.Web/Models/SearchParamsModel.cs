﻿// -----------------------------------------------------------------------
// <copyright file="SearchParamsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SearchParamsModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    public class SearchParamsModel
    {
        public int PageNo { get; set; }
        public int ItemsPerPage { get; set; }
        public string SortColumn { get; set; }
        public char SortDirection { get; set; }
        public string SearchColumn { get; set; }
        public string SearchTerm { get; set; }
    }
}