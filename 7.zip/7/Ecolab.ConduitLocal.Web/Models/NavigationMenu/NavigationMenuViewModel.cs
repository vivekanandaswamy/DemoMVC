﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu ViewModel</summary>
// ----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.NavigationMenu
{
    using System.Collections.Generic;

    /// <summary>
    ///     The NavigationMenuViewModel class
    /// </summary>
    public class NavigationMenuViewModel
    {
        /// <summary>
        ///     Gets or sets the Main Menu
        /// </summary>
        /// <value> The Main menu item.</value>
        public NavigationMenuModel MainMenu { get; set; }

        /// <summary>
        ///     Gets or sets the Menu items
        /// </summary>
        /// <value> The menu items.</value>
        public List<MenuViewModel> Menus { get; set; }
    }
}