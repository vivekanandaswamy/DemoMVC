﻿// -----------------------------------------------------------------------
// <copyright file="SubMenuViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SubMenu ViewModel</summary>
// ----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.NavigationMenu
{
    /// <summary>
    ///     The SubMenuViewModel class
    /// </summary>
    public class SubMenuViewModel
    {
        /// <summary>
        ///     Gets or sets the sub Menu
        /// </summary>
        /// <value> The Sub Menu.</value>
        public NavigationMenuModel SubMenu { get; set; }
    }
}