﻿// -----------------------------------------------------------------------
// <copyright file="UserAuditModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UserAuditModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     User Audit Model
    /// </summary>
    public class UserAuditModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the user identifier.
        /// </summary>
        /// <value>
        ///     The user identifier.
        /// </value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the ip address.
        /// </summary>
        /// <value>
        ///     The ip address.
        /// </value>
        public string IPAddress { get; set; }

        /// <summary>
        ///     Gets or sets the user activity.
        /// </summary>
        /// <value>
        ///     The user activity.
        /// </value>
        public byte UserActivity { get; set; }
    }
}