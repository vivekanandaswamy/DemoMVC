﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Master Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     class ProductMasterModel
    /// </summary>
    public class ProductMasterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Product Id.</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// <value> Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets SKU
        /// </summary>
        /// <value> SKU.</value>
        public string SKU { get; set; }

        /// <summary>
        ///     Gets or sets  Name
        /// </summary>
        /// <value> Name </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets Cost
        /// </summary>
        /// <value> Cost of chemical </value>
        [UsageKeyAttribute("Price_Tcd")]
        public double Cost { get; set; }

        /// <summary>
        ///     Gets or sets CostAsString
        /// </summary>
        /// <value> Cost of chemical </value>
        public string CostAsString { get; set; }

        /// <summary>
        ///     Gets or sets DensityFactor
        /// </summary>
        /// <value> Density Factor </value>
        public decimal DensityFactor { get; set; }

        /// <summary>
        ///     Gets or sets AcceptedDeviation
        /// </summary>
        /// <value>Accepted Deviation </value>
        public decimal AcceptedDeviation { get; set; }

        /// <summary>
        ///     Gets or sets ProductCategoryId
        /// </summary>
        /// <value> Product Category Id </value>
        public int ProductCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets ContactOfficePhone
        /// </summary>
        /// <value> Contact Office Phone </value>
        public string Type { get; set; }

        /// <summary>
        ///     Gets or sets Supplier
        /// </summary>
        /// <value> Supplier </value>
        public string Supplier { get; set; }

        /// <summary>
        ///     Gets or sets IncludeinCI
        /// </summary>
        /// <value> Includein CI </value>
        public bool IncludeinCI { get; set; }

        /// <summary>
        ///     Gets or sets Description
        /// </summary>
        /// <value> Description </value>
        public string PackagingSize { get; set; }

        /// <summary>
        ///     Gets or sets Weight
        /// </summary>
        /// <value> Weight </value>
        public string Weight { get; set; }

        /// <summary>
        ///     Gets or sets Volume
        /// </summary>
        /// <value> Volume </value>
        public string Volume { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value> Is Deleted </value>
        public bool IsSelected { get; set; }

        /// <summary>
        ///     Gets or sets ProductcategoryName
        /// </summary>
        /// <value> Product Category Name </value>
        public string ProductcategoryName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> The DesiredUnits. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or Sets InventoryExpense
        /// </summary>
        /// <value>InventoryExpense</value>
        public string InventoryExpense { get; set; }

        /// <summary>
        /// Gets or sets PackageSizeId
        /// </summary>
        /// <value>PackageSizeId</value>
        public int? PackageSizeId { get; set; }

        /// <summary>
        ///     Gets or Sets UnitPerPackage
        /// </summary>
        /// <value>UnitPerPackage</value>
        public int? UnitPerPackage { get; set; }

        /// <summary>
        ///     Gets or Sets UnitWeightVolume
        /// </summary>
        /// <value>UnitWeightVolume</value>
        public Decimal? UnitWeightVolume { get; set; }

        /// <summary>
        ///     Gets or Sets UnitWeightVolumeUOMCode
        /// </summary>
        /// <value>UnitWeightVolumeUOMCode</value>
        public string UnitWeightVolumeUOMCode { get; set; }
        #endregion
    }
}