﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewashViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualRewashViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Rewash
{
    using System.Collections.Generic;
    using PlantSetup;
    using MIWebModel = ManualInput;
    using WebModel = Models;

    /// <summary>
    ///     Model class for Manual Rewash View
    /// </summary>
    public class ManualRewashViewModel
    {
        /// <summary>
        ///     Gets or sets List of washer groups
        /// </summary>
        /// <value>The washer groups</value>
        public List<GroupTypeModel> WasherGroups { get; set; }

        /// <summary>
        ///     Gets or sets List of formulas
        /// </summary>
        /// <value>The Formulas.</value>
        public List<WashProgramSetupModel> Formulas { get; set; }

        /// <summary>
        ///     Gets or sets List of Rewash Reasons
        /// </summary>
        /// <value>The RewashReason.</value>
        public List<RewashReason> RewashReason { get; set; }

        /// <summary>
        ///     Gets or sets List of rewash
        /// </summary>
        /// <value>The Rewash.</value>
        public List<ManualRewash> Rewash { get; set; }

        /// <summary>
        ///     Gets or sets the result
        /// </summary>
        /// <value>The Result value.</value>
        public string Result { get; set; }
    }
}