﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewash.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Rewash
{
    /// <summary>
    ///     Model class for ManualRewash
    /// </summary>
    public class ManualRewash : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value> Washer Group Id. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> Formula Id. </value>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the RewashReasonId.
        /// </summary>
        /// <value> RewashReasonId. </value>
        public int RewashReasonId { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value> Recorded Date. </value>
        public string RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value> The double Value. </value>
        public double Value { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> The Desired units. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the result
        /// </summary>
        /// <value> The result value. </value>
        public string Result { get; set; }
    }
}