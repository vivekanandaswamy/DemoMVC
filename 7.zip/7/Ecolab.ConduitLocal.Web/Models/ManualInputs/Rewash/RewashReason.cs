﻿// -----------------------------------------------------------------------
// <copyright file="RewashReason.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Rewash Reason Class.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Rewash
{
    /// <summary>
    ///     Model class for RewashReason
    /// </summary>
    public class RewashReason
    {
        /// <summary>
        ///     Gets or sets the RewashReasonId.
        /// </summary>
        /// <value> rewash reason id.</value>
        public int RewashReasonId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> rewash description.</value>
        public string Description { get; set; }
    }
}