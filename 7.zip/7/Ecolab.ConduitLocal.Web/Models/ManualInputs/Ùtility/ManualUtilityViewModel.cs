﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtilityViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualUtilityViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Utility
{
    using System;
    using System.Collections.Generic;
    using MIWebModel = ManualInput;

    public class ManualUtilityViewModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the MeterId.
        /// </summary>
        /// <value>The Meter Id.</value>
        public int MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> meter description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTickUnit.
        /// </summary>
        /// <value> meter tick unit.</value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityTypeId.
        /// </summary>
        /// <value> meter utility type id.</value>
        public string UtilityTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value> meter group id.</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityTypeName.
        /// </summary>
        /// <value> meter utility type name.</value>
        public string UtilityTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the LocationName.
        /// </summary>
        /// <value> meter location name.</value>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets List of production data
        /// </summary>
        /// <value>The Utility value.</value>
        public List<ManualUtilityModel> Utility { get; set; }

        /// <summary>
        ///     Gets or sets result
        /// </summary>
        /// <value>The result value.</value>
        public string Result { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Max Value Limit.</value>
        public long MaxValueLimit { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime.
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceMeterGuid
        /// </summary>
        /// <value>The Parameter MyServiceMeterGuid.</value>
        public Guid MyServiceMeterGuid { get; set; }
    }
}