﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtilityModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualUtilityModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Utility
{
    using ConduitLocal.Models;

    /// <summary>
    ///     Entity class for ManualUtility
    /// </summary>
    public class ManualUtilityModel : BaseModel
    {
        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value> manual recorded date.</value>
        public string RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value> manual utility value.</value>
        public double Value { get; set; }

        /// <summary>
        ///     Gets or sets the Usage.
        /// </summary>
        /// <value> manual utility value usage.</value>
        public double Usage { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether [first record].
		/// </summary>
		/// <value>
		///   <c>true</c> if [first record]; otherwise, <c>false</c>.
		/// </value>
		public bool FirstRecord { get; set; }
    }
}