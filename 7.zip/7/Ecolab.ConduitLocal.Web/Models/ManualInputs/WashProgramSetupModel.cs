﻿// -----------------------------------------------------------------------
// <copyright file="WashProgramSetupModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WashProgramSetup class </summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.ManualInput
{
    /// <summary>
    ///     Model class for WashProgramSetup
    /// </summary>
    public class WashProgramSetupModel
    {
        /// <summary>
        ///     Gets or sets the ProgramNumber.
        /// </summary>
        /// <value> Program Number.</value>
        public Int16 ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Description.</value>
        public string Description { get; set; }

		/// <summary>
		/// Gets or sets the program ID
		/// </summary>
		/// <value>The programId</value>
		public int ProgramId { get; set; }

        /// <summary>
        /// Gets or sets the IsVisibleForFormula
        /// </summary>
        /// <value>IsVisibleForFormula</value>
        public bool IsVisibleForFormula { get; set; }
    }
}