﻿// -----------------------------------------------------------------------
// <copyright file="ManualLaborListDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Labor class lists. </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInputs.Labor
{
    using System.Collections.Generic;
    using ManualLabor;
    using PlantSetup;

    /// <summary>
    ///     Model class for ManualLaborListDetails
    /// </summary>
    public class ManualLaborListDetails
    {
        /// <summary>
        ///     Gets or sets the Locations.
        /// </summary>
        public IEnumerable<GroupTypeModel> Locations { get; set; }

        /// <summary>
        ///     Gets or sets the Labor Types.
        /// </summary>
        public IEnumerable<LaborTypeModel> LaborTypes { get; set; }

        /// <summary>
        ///     Gets or sets the Manual labor details.
        /// </summary>
        public IEnumerable<ManualLabor> ManualLaborList { get; set; }

        /// <summary>
        ///     Gets or sets the cost of the man hours type.
        /// </summary>
        public decimal Cost { get; set; }
    }
}