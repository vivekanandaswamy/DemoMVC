﻿// -----------------------------------------------------------------------
// <copyright file="ManualLabor.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Labor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInputs.ManualLabor
{
    using System;

    /// <summary>
    ///     Model class for ManualLabor
    /// </summary>
    public class ManualLabor : BaseViewModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets Location Id
        /// </summary>
        /// <value>The location identifier.</value>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets ManHourType Id
        /// </summary>
        /// <value>The man hour type identifier.</value>
        public int ManHourTypeId { get; set; }

        /// <summary>
        ///     Gets or sets Start Date
        /// </summary>
        /// <value>The start date.</value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets End Date
        /// </summary>
        /// <value>The end date.</value>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///     Gets or sets the Labor Cost
        /// </summary>
        /// <value>The labor cost.</value>
        public decimal LaborCost { get; set; }

        /// <summary>
        ///     Gets or sets Allocated Man Hours
        /// </summary>
        /// <value>The allocated man hours.</value>
        public int AllocatedManHours { get; set; }

        /// <summary>
        ///     Gets or sets Ecolab Account Number
        /// </summary>
        /// <value>The ecolab acc number.</value>
        public string ecolabAccNum { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime.
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }

        #endregion "Properties"
    }
}