﻿// -----------------------------------------------------------------------
// <copyright file="ProductionViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductionViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Model = Ecolab.Models.ManualInput.Production;
    using WebModel = Ecolab.ConduitLocal.Web.Models;
    using MIWebModel = Ecolab.ConduitLocal.Web.Models.ManualInput;

    /// <summary>
    /// Model class for ProductionView
    /// </summary>
    public class ManualProductionViewModel 
    {
        /// <summary>
        /// List of washer groups
        /// </summary>
        public List<WebModel.PlantSetup.GroupTypeModel> WasherGroups { get; set; }

        /// <summary>
        /// List of Washers
        /// </summary>
        public List<WebModel.PlantSetup.MachineSetupModel> Washers { get; set; }

        /// <summary>
        /// List of formulas
        /// </summary>
        public List<MIWebModel.WashProgramSetupModel> Formulas { get; set; }

        /// <summary>
        ///List of production data
        /// </summary>
        public List<MIWebModel.Production.ManualProductionModel> ProductionData { get; set; }

        /// <summary>
        /// result
        /// </summary>
        public string Result { get; set; }

    }
}
