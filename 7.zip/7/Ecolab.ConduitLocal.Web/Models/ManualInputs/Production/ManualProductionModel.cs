﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionModel.cs" company="Ecolab">
// This class is for fetching the values and saving the values to database.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Production
{
    /// <summary>
    ///     Model class for ManualProductionModel
    /// </summary>
    public class ManualProductionModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value> Washer Group Id. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherId.
        /// </summary>
        /// <value>The Washer Id. </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> Formula Id. </value>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value> Recorded Date. </value>
        public string RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value>returns the Value. </value>
        public double Value { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> The desired units </value>
        public string DesiredUnits { get; set; }

		/// <summary>
		/// Gets or sets the New Date
		/// </summary>
		/// <value>the new Date</value>
		public DateTime ProductionDate { get; set; }

		/// <summary>
		/// Gets or sets the FormulaName
		/// </summary>
		/// <value>the FormulaName</value>
		public string FormulaName { get; set; }

        /// <summary>
        /// Gets or sets the ProductionId
        /// </summary>
        /// <value>the ProductionId</value>
        public int ProductionId { get; set; }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>TotalRows</value>
        public int TotalRows { get; set; }
	}
}