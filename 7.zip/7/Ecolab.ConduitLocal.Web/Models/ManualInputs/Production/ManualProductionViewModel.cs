﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductionViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput
{
	using System;
    using System.Collections.Generic;
    using PlantSetup;
    using Production;
    using MIWebModel = ManualInput;
    using WebModel = Models;

    /// <summary>
    /// Model class for ProductionView
    /// </summary>
    public class ManualProductionViewModel
    {
        /// <summary>
        /// Gets or sets List of washer groups
        /// </summary>
        /// <value>
        /// List WebModel.PlantSetup.GroupTypeModel
        /// </value>
        public List<GroupTypeModel> WasherGroups { get; set; }

        /// <summary>
        /// Gets or sets List of Washers
        /// </summary>
        /// <value>
        /// List WebModel.PlantSetup.MachineSetupModel
        /// </value>
        public List<MachineSetupModel> Washers { get; set; }

        /// <summary>
        /// Gets or sets List of formulas
        /// </summary>
        /// <value>
        /// List MIWebModel.WashProgramSetupModel
        /// </value>
        public List<WashProgramSetupModel> Formulas { get; set; }

        /// <summary>
        /// Gets or sets List of production data
        /// </summary>
        /// <value>
        /// List MIWebModel.Production.ManualProductionModel
        /// </value>
        public List<ManualProductionModel> ProductionData { get; set; }

        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        /// <value>
        /// The result value
        /// </value>
        public string Result { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the washer group identifier.
        /// </summary>
        /// <value>
        /// The washer group identifier.
        /// </value>
        public string[] WasherGroupId { get; set; }

        /// <summary>
        /// Gets or sets the washerId
        /// </summary>
        /// <value>
        /// the washer id
        /// </value>
        public int WasherId { get; set; }

        /// <summary>
        /// Gets or sets the programId
        /// </summary>
        /// <value>
        /// the program ID
        /// </value>
        public int ProgramId { get; set; }

        /// <summary>
        /// Gets or sets production data
        /// </summary>
        /// <value>
        /// List MIWebModel.Production.ManualProductionModel
        /// </value>
        public ManualProductionModel ManualProductionData { get; set; }

        /// <summary>
        /// Gets or sets the Date
        /// </summary>
        /// <value>
        /// the Datetime Date
        /// </value>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets ProductList
        /// </summary>
        /// <value>
        /// List of Product
        /// </value>
        public List<ManualProductionModel> ProductionList { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime StartDate { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the production identifier to delete.
        /// </summary>
        /// <value>
        /// The production identifier to delete.
        /// </value>
        public int ProductionIdToDelete { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets a value indicating whether [production data add mode].
        /// </summary>
        /// <value>
        /// <c>true</c> if [production data add mode]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductionDataAddMode { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the page number.
        /// </summary>
        /// <value>
        /// The page number.
        /// </value>
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or sets RowsCount
        /// </summary>
        /// <value>
        /// List of RowsCount
        /// </value>
        public int RowsCount { get; set; }

        /// <summary>
        /// Gets or sets ErrorMessage
        /// </summary>
        /// <value>
        /// List of ErrorMessage
        /// </value>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets List of washer groups
        /// </summary>
        /// <value>
        /// List WebModel.PlantSetup.GroupTypeModel
        /// </value>
        public List<Models.WasherGroup.WasherGroup> WasherGroupList { get; set; }

        /// <summary>
        /// Gets or sets the WasherList
        /// </summary>
        /// <value>
        /// the washer list
        /// </value>
        public List<Models.Washers.WashersModel> WasherList { get; set; }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>
        /// TotalRows
        /// </value>
        public int TotalRows { get; set; }

        /// <summary>
        /// Gets or sets the New Date
        /// </summary>
        /// <value>
        /// the new Date
        /// </value>
        public DateTime ProductionDate { get; set; }

        /// <summary>
        /// Gets or sets the programId
        /// </summary>
        /// <value>
        /// the program ID
        /// </value>
        public int ProgramIdToAdd { get; set; }

        /// <summary>
        /// Gets or sets the Value.
        /// </summary>
        /// <value>
        /// returns the Value.
        /// </value>
        public double ProductionValueToAdd { get; set; }
        /// <summary>
        /// Gets or Sets the ProductionDate in string format
        /// </summary>
        /// <value>
        /// The Production Date in string
        /// </value>
        public string ProductionDateText { get; set; }

        /// <summary>
        /// Getst or sets the Start Date in string Format
        /// </summary>
        /// <value>
        /// The Start Date in string
        /// </value>
        public string StartDateText { get; set; }

        /// <summary>
        /// Gets or sets the region identifier.
        /// </summary>
        /// <value>
        /// The region identifier.
        /// </value>
        public int RegionId { get; set; }
    }
}