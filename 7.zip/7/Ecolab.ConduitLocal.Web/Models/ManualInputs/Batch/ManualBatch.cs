﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatch.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Batch
{
    using System;

    /// <summary>
    ///     Model class for ManualBatch
    /// </summary>
    public class ManualBatch : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value> Washer Group Id. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherId.
        /// </summary>
        /// <value>The Washer Id. </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> Formula Id. </value>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the StartDate.
        /// </summary>
        /// <value> Start Date. </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> Start Time. </value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the ActualLoad.
        /// </summary>
        /// <value> Actual Load . </value>
        public int RecordingValue { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> The Desired units Value. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the result
        /// </summary>
        /// <value> The result value. </value>
        public string Result { get; set; }

		/// <summary>
		/// Gets or sets ActualWeight
		/// </summary>
		/// <value>ActualWeight</value>
		public int ActualWeight { get; set; }
    }
}