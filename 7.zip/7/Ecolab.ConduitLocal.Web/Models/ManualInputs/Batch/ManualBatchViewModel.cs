﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchViewModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualBatchViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Batch
{
	using System;
    using System.Collections.Generic;
    using PlantSetup;
    using MIWebModel = ManualInput;
    using WebModel = Models;

    /// <summary>
    ///     Model class for Manual Batch View
    /// </summary>
    public class ManualBatchViewModel
    {
        /// <summary>
        ///     Gets or sets List of washer groups
        /// </summary>
        /// <value>List WebModel.PlantSetup.GroupTypeModel</value>
        public List<GroupTypeModel> WasherGroups { get; set; }

		/// <summary>
		///     Gets or sets the Washer GroupId value for the washer groups.
		/// </summary>
		/// <value>Gets Washer GroupId value.</value>
		public string[] WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets List of Washers
        /// </summary>
        /// <value>List WebModel.PlantSetup.MachineSetupModel</value>
        public List<MachineSetupModel> Washers { get; set; }

		/// <summary>
		///     Gets or sets the Washer GroupId value for the washer groups.
		/// </summary>
		/// <value>Gets Washer GroupId value.</value>
		public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets List of formulas
        /// </summary>
        /// <value>List MIWebModel.WashProgramSetupModel</value>
        public List<WashProgramSetupModel> Formulas { get; set; }

        /// <summary>
        ///     Gets or sets the Batch
        /// </summary>
        /// <value>MIWebModel.Batch.ManualBatch</value>
        public ManualBatch Batch { get; set; }

        /// <summary>
        ///     Gets or sets the result
        /// </summary>
        /// <value>result value.</value>
        public string Result { get; set; }

		/// <summary>
		/// Gets or sets the GroupId
		/// </summary>
		/// <value>The group Id</value>
		public string GroupId { get; set; }

		/// <summary>
		/// Gets or sets the Program id
		/// </summary>
		/// <value>comma seprated formulas selected</value>
		public int ProgramId { get; set; }

		/// <summary>
		/// Gets or sets the start Date
		/// </summary>
		/// <value>start date of batches</value>
		public DateTime StartDate { get; set; }

		/// <summary>
		/// Gets or sets BatchList
		/// </summary>
		/// <value>List of batches</value>
		public List<ManualBatchDataModel> BatchList { get; set; }

		/// <summary>
		///     Gets or sets List of washer groups
		/// </summary>
		/// <value>List WebModel.PlantSetup.GroupTypeModel</value>
		public List<Models.WasherGroup.WasherGroup> WasherGroupList { get; set; }

		/// <summary>
		/// Gets or sets the WasherList
		/// </summary>
		/// <value>the washer list</value>
		public List<Models.Washers.WashersModel> WasherList { get; set; }

		/// <summary>
		/// Gets or sets the WasherList
		/// </summary>
		/// <value>the washer list</value>
		public List<Models.WasherGroup.WasherGroupFormulaModel> WasherGroupFormula { get; set; }

        /// <summary>
        /// Gets or sets the PageNumber
        /// </summary>
        /// <value>PageNumber</value>
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or sets the RowsCount
        /// </summary>
        /// <value>RowsCount</value>
        public int RowsCount { get; set; }

        /// <summary>
        /// Gets or sets the ErrorMessage
        /// </summary>
        /// <value>ErrorMessage</value>
		public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>TotalRows</value>
        public int TotalRows { get; set; }

		/// <summary>
		/// Gets or Sets the Start Date string.
		/// </summary>
		/// <value>The Start Date in string Format.</value>
		public string StartDateText { get; set; }
    }
}