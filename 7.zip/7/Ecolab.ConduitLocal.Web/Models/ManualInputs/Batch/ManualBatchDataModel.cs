﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchDataModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualBatchData class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ManualInput.Batch
{
	using System;
    using ConduitLocal.Models;

    /// <summary>
    ///     Entity class for ManualBatchData
    /// </summary>
    public class ManualBatchDataModel : BaseModel
    {
        /// <summary>
        ///     Gets or sets the StartDate.
        /// </summary>
        /// <value> Start Date. </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> Start Time. </value>
        public string StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the ActualLoad.
        /// </summary>
        /// <value> Actual Load . </value>
        public double RecordingValue { get; set; }

        /// <summary>
        ///     Gets or sets the desired units.
        /// </summary>
        /// <value> Desired Units. </value>
        public string DesiredUnits { get; set; }

		/// <summary>
		/// Gets or sets ActualWeight
		/// </summary>
		/// <value>ActualWeight</value>
		public int ActualWeight { get; set; }

		/// <summary>
		/// Gets or sets ProgramId
		/// </summary>
		/// <value>Program Id.</value>
		public int ProgramId { get; set; }

		/// <summary>
		/// Gets or sets the formula name	
		/// </summary>
		/// <value>FormulaName</value>
		public string FormulaName { get; set; }

		/// <summary>
		/// Gets or sets the batch Start date
		/// </summary>
		/// <value>BatchStartDate</value>
		public string BatchStartDate { get; set; }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>TotalRows</value>
        public int TotalRows { get; set; }

        /// <summary>
        /// Gets or sets the EcolabWasherId
        /// </summary>
        /// <value>EcolabWasherId</value>
        public int EcolabWasherId { get; set; }
    }
}