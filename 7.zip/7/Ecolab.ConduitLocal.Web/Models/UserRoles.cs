﻿// -----------------------------------------------------------------------
// <copyright file="UserRoles.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Role object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     UserRoles Class
    /// </summary>
    public class UserRoles
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the RoleId.
        /// </summary>
        /// <value>
        ///     The Parameter RoleId.
        /// </value>
        public int RoleId { get; set; }

        /// <summary>
        ///     Gets or sets the Role name.
        /// </summary>
        /// <value>
        ///     The Parameter RoleName.
        /// </value>
        public string RoleName { get; set; }

        /// <summary>
        ///     Gets or sets the Code.
        /// </summary>
        /// <value>
        ///     The Parameter Code.
        /// </value>
        public string Code { get; set; }

        #endregion
    }
}