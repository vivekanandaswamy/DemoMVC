﻿// -----------------------------------------------------------------------
// <copyright file="UserProfileModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Profile Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;
    using Entities;

    /// <summary>
    ///     class UserProfileModel
    /// </summary>
    public class UserProfileModel
    {
        private readonly UserProfile userProfile;

        /// <summary>
        ///     User Profile Model
        /// </summary>
        public UserProfileModel()
        {
            userProfile = new UserProfile();
        }

        /// <summary>
        ///     Gets or sets the UserId.
        /// </summary>
        /// <value>
        ///     The User Id value.
        /// </value>
        public int UserId
        {
            get { return userProfile.UserId; }
            set { userProfile.UserId = value; }
        }

        /// <summary>
        ///     Gets or sets the FirstName.
        /// </summary>
        /// <value>
        ///     The FirstName value.
        /// </value>
        public string FirstName
        {
            get { return userProfile.FirstName; }
            set { userProfile.FirstName = value; }
        }

        /// <summary>
        ///     Gets or sets the LastName.
        /// </summary>
        /// <value>
        ///     The LastName value.
        /// </value>
        public string LastName
        {
            get { return userProfile.LastName; }
            set { userProfile.LastName = value; }
        }

        /// <summary>
        ///     Gets or sets the FullName.
        /// </summary>
        /// <value>
        ///     The Full Name value.
        /// </value>
        public string FullName
        {
            get { return userProfile.FullName; }
            set { userProfile.FullName = value; }
        }

        /// <summary>
        ///     Gets or sets the LoginName.
        /// </summary>
        /// <value>
        ///     LoginName.
        /// </value>
        public string LoginName
        {
            get { return userProfile.LoginName; }
            set { userProfile.LoginName = value; }
        }

        /// <summary>
        ///     Gets or sets the LanguageId.
        /// </summary>
        /// <value>
        ///     LanguageId.
        /// </value>
        public int LanguageId
        {
            get { return userProfile.LanguageId; }
            set { userProfile.LanguageId = value; }
        }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value>
        ///     The Name value.
        /// </value>
        public string Name
        {
            get { return userProfile.Name; }
            set { userProfile.Name = value; }
        }

        /// <summary>
        ///     Gets or sets the Phone.
        /// </summary>
        /// <value> The Phone value .</value>
        public string Phone
        {
            get { return userProfile.Phone; }
            set { userProfile.Phone = value; }
        }

        /// <summary>
        ///     Gets or sets the UOMIs.
        /// </summary>
        /// <value>
        ///     The UOMId value.
        /// </value>
        public int UOMId
        {
            get { return userProfile.UomId; }
            set { userProfile.UomId = value; }
        }

        /// <summary>
        ///     Gets or sets the Email.
        /// </summary>
        /// <value>
        ///     The Email value.
        /// </value>
        public string Email
        {
            get { return userProfile.Email; }
            set { userProfile.Email = value; }
        }

        /// <summary>
        ///     Gets or sets the IsActive.
        /// </summary>
        /// <value>
        ///     The IsActive value.
        /// </value>
        public bool IsActive
        {
            get { return userProfile.IsActive; }
            set { userProfile.IsActive = value; }
        }

        /// <summary>
        ///     Gets or sets the ErrorMessage.
        /// </summary>
        /// <value>
        ///     ErrorMessage.
        /// </value>
        public string ErrorMessage
        {
            get { return userProfile.ErrorMessage; }
            set { userProfile.ErrorMessage = value; }
        }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>
        ///     EcolabAccountNumber.
        /// </value>
        public string EcolabAccountNumber
        {
            get { return userProfile.EcolabAccountNumber; }
            set { userProfile.EcolabAccountNumber = value; }
        }

        /// <summary>
        ///     Gets or sets the RegionId.
        /// </summary>
        /// <value>
        ///     The RegionId.
        /// </value>
        public Int16 RegionId
        {
            get { return userProfile.RegionId; }
            set { userProfile.RegionId = value; }
        }
    }
}