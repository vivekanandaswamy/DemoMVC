﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models
{
    public class Address
    {
        public string ADDR_LN_1 { get; set; }
        public string ADDR_LN_2 { get; set; }
        public string ADDR_LN_3 { get; set; }
        public string CTY_NM { get; set; }
        public string POST_CD { get; set; }
        public string CNTRY_ID { get; set; }
    }
}