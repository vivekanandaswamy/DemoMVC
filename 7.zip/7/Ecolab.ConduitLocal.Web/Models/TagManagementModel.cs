﻿// -----------------------------------------------------------------------
// <copyright file="TagManagementModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Management Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;
    using System.Collections.Generic;
    using Ecolab.Dcs.Entities;

    /// <summary>
    ///     class TagManagement
    /// </summary>
    public class TagManagementModel : BaseViewModel
    {
        /// <summary>
        ///  Gets or sets  Tag Address
        /// </summary>
        /// <value>Tag Address</value>
        public string TagAddress { get; set; }

        /// <summary>
        ///     Gets or sets  Tag Description
        /// </summary>
        /// <value>Tag Description</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///  Gets or sets  Quality
        /// </summary>
        /// <value>Quality</value>
        public string Quality { get; set; }

        /// <summary>
        ///  Gets or sets  Conduit Value
        /// </summary>
        /// <value>Conduit Value</value>
        public string ConduitValue { get; set; }

        /// <summary>
        ///  Gets or sets  PLC Value
        /// </summary>
        /// <value>PLC Value</value>
        public string PLCValue { get; set; }

        /// <summary>
        ///  Gets or sets  Conduit TimeStamp
        /// </summary>
        /// <value>Conduit TimeStamp</value>
        public DateTime ConduitTimeStamp { get; set; }

        /// <summary>
        ///  Gets or sets  PLCTimeStamp
        /// </summary>
        /// <value>PLC TimeStamp</value>
        public DateTime PLCTimeStamp { get; set; }

        /// <summary>
        /// Gets the tagDetails from DB.
        /// </summary>
        public List<TagManagementModel> tagManagementWebModel { get; set; }

        /// <summary>
        /// Gets or sets the PLC values.
        /// </summary>
        public bool overRideValues { get; set; }

        /// <summary>
        ///     Gets or sets the PLC Tags
        /// </summary>
        public List<OpcTag> PlcTags { get; set; }

        /// <summary>
        ///     Gets or sets the controller Id
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets  ColoumnName
        /// </summary>
        /// <value>ColoumnName</value>
        public string ColoumnName { get; set; }

        /// <summary>
        ///     Gets or sets  HasPumps
        /// </summary>
        /// <value>HasPumps</value>
        public bool HasPumps { get; set; }

        /// <summary>
        ///     Gets or sets  DataType
        /// </summary>
        /// <value>DataType</value>
        public string DataType { get; set; }

        /// <summary>
        /// Gets or sets the name of the original column.
        /// </summary>
        /// <value>
        /// The name of the original column.
        /// </value>
        public string OriginalColumnName { get; set; }

        /// <summary>
        /// Gets or sets the type of the entity.
        /// </summary>
        /// <value>
        /// The type of the entity.
        /// </value>
        public string EntityType { get; set; }

        /// <summary>
        /// Gets or sets the type of the tag.
        /// </summary>
        /// <value>
        /// The type of the tag.
        /// </value>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int PlcParentEntityType { get; set; }

        /// <summary>
        ///     Gets or sets Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int PlcEntityType { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Id
        /// </summary>
        /// <value>The ParentEntityId .</value>
        public int PlcParentEntityId { get; set; }

        /// <summary>
        ///     Gets or sets Entity Id
        /// </summary>
        /// <value>The EntityId .</value>
        public int PlcEntityId { get; set; }
    }
}