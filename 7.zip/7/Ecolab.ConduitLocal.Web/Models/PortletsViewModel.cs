﻿// -----------------------------------------------------------------------
// <copyright file="PortletsViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PortletsViewModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System.Collections.Generic;

    /// <summary>
    ///     PortletsViewModel class
    /// </summary>
    public class PortletsViewModel
    {
        /// <summary>
        ///     Gets or sets the PlantName.
        /// </summary>
        /// <value>The PlantName field</value>
        public string PlantName { get; set; }

        /// <summary>
        ///     Gets or sets the PlantId.
        /// </summary>
        /// <value>The PlantId field</value>
        public string PlantId { get; set; }

        /// <summary>
        ///     Gets or sets the TotalLoad.
        /// </summary>
        /// <value>The TotalLoad field</value>
        public string TotalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the LostLoad.
        /// </summary>
        /// <value>The LostLoad field</value>
        public string LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value>The Efficiency field</value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the List of portlets
        /// </summary>
        public List<PortletModel> Portlets { get; set; }

        /// <summary>
        ///     Gets or sets the Weight FontColor.
        /// </summary>
        /// <value> FontColor. </value>
        public string FontColor { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName.
        /// </summary>
        /// <value>The ShiftName field</value>
        public string ShiftName { get; set; }
    }
}