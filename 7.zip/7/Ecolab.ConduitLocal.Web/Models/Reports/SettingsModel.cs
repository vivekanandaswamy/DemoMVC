﻿// -----------------------------------------------------------------------
// <copyright file="SettingsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SettingsModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class SettingsModel
    {
        /// <summary>
        /// Gets or sets TableColumns Collection
        /// </summary>
        /// <value>Contains Collection of TableColumn</value>
        public List<TableColumn> TableColumns { get; set; }
    }
}