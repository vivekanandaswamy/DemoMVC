﻿// -----------------------------------------------------------------------
// <copyright file="ReportFilterModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportFilterModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportFilterModel
    {
        /// <summary>
        /// Gets or sets the FilterId
        /// </summary>
        /// <value>Report Filter Id.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the FilterName
        /// </summary>
        /// <value>Report Filter Name.</value>
        public string FilterName { get; set; }
    }
}