﻿// -----------------------------------------------------------------------
// <copyright file="ReportSubCategories.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSubCategories class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Wb Model for ReportSubCategories
    /// </summary>
    public class ReportSubCategories
    {
        /// <summary>
        ///     Get or sets ReportCategoryId
        /// </summary>
        /// <value>This Conatins ReportCategoryId</value>
        public int ReportCategoryId { get; set; }

        /// <summary>
        ///     Get or sets ReportSubCategoryId
        /// </summary>
        /// <value>This Conatins ReportSubCategoryId</value>
        public int ReportSubCategoryId { get; set; }

        /// <summary>
        ///     Get or sets SubCategoryName
        /// </summary>
        /// <value>This Conatins SubCategoryName</value>
        public string SubCategoryName { get; set; }

        /// <summary>
        ///     Get or sets ReportName
        /// </summary>
        /// <value>This Conatins ReportName</value>
        public string ReportName { get; set; }
    }
}