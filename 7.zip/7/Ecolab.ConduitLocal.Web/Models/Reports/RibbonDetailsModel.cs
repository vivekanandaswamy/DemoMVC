﻿// -----------------------------------------------------------------------
// <copyright file="RibbonDetailsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RibbonDetailsModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class RibbonDetailsModel
    {
        /// <summary>
        /// Get or set the ReportId
        /// </summary>
        /// <value>ReportId value.</value>
        public int ReportId { get; set; }

        /// <summary>
        /// Get or set the SwitchModes
        /// </summary>
        /// <value>SwitchModes value.</value>
        public List<ReportSwitchModeModel> SwitchModes { get; set; }

        /// <summary>
        /// Get or set the ChartDisplayMode
        /// </summary>
        /// <value>ChartDisplayMode value.</value>
        public List<ReportChartDisplayModes> ChartDisplayMode { get; set; }

        /// <summary>
        /// Get or set the AllColumns
        /// </summary>
        /// <value>AllColumns value.</value>
        public List<ReportAllColumnsModel> AllColumns { get; set; }

        /// <summary>
        /// Get or set the Filters
        /// </summary>
        /// <value>Filters value.</value>
        public List<ReportFilterModel> Filters { get; set; }

        /// <summary>
        /// Get or set the Views
        /// </summary>
        /// <value>Views value.</value>
        public List<ReportViewModel> ViewMode { get; set; }

        /// <summary>
        /// Get or set the standard and custom filter
        /// </summary>
        /// <value>StandardAndCustom  value.</value>
        public bool StandardAndCustom { get; set; }

        /// <summary>
        /// Get or set the AsOnToday 
        /// </summary>
        /// <value>AsOnToday value.</value>
        public bool AsOnToday { get; set; }

        public List<ReportSubView> TimeLineSubView { get; set; }
    }
}