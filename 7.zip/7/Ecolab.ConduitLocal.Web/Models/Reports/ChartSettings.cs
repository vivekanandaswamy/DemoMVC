﻿// -----------------------------------------------------------------------
// <copyright file="ChartSettings.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ChartSettings </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ChartSettings
    {
        /// <summary>
        /// Gets or Sets XAxis Model
        /// </summary>
        /// <value>Contains the XAxis Type</value>
        public XAxis XAxis { get; set; }

        /// <summary>
        /// Gets or Sets AvarageValue for the XAxis
        /// </summary>
        /// <value>Contains the Avarage Value</value>
        public int AvarageValue { get; set; }

        /// <summary>
        /// Gets or Sets Yaxis Lable
        /// </summary>
        /// <value>Contains the value for YAxis label</value>
        public string YaxisLable { get; set; }

        /// <summary>
        /// Gets or Sets HideAverage  Lable
        /// </summary>
        /// <value>Contains the value for HideAverage label</value>
        public bool HideAverage { get; set; }

        /// <summary>
        /// Gets or Sets LastLevel   Lable
        /// </summary>
        /// <value>Contains the value for LastLevel  label</value>
        public bool LastLevel { get; set; }
    }
}