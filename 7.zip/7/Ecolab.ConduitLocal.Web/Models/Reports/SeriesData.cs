﻿// -----------------------------------------------------------------------
// <copyright file="SeriesData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SeriesData </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class SeriesData
    {
        /// <summary>
        /// Gets or Sets Series Name
        /// </summary>
        /// <value>Contains the Name for Series</value>
        public string name { get; set; }

        /// <summary>
        /// Gets or Sets Y-axis value
        /// </summary>
        /// 
        /// <value>Contains the Y-axis for Series</value>
        public decimal y { get; set; }

        /// <summary>
        /// Gets or Sets Color for the Series
        /// </summary>
        /// <value>Contains color value</value>
        public string color { get; set; }

        /// <summary>
        /// Gets or Sets Data Collection for Series.
        /// </summary>
        /// <value>Contains Data Collection for the sereis.</value>
        public List<Data> data { get; set; }
    }
}