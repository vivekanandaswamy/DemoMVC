﻿// -----------------------------------------------------------------------
// <copyright file="ReportSubcategoryModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSubcategoryModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Wb Model for ReportSubcategoryModel
    /// </summary>
    public class ReportSubcategoryModel : BaseViewModel
    {
        /// <summary>
        ///     Get or sets the SubCategoryId
        /// </summary>
        /// <value>Report Sub Category Id</value>
        public int SubCategoryId { get; set; }

        /// <summary>
        ///     Get or sets the SubCategoryName
        /// </summary>
        /// <value>Report Sub Category Name</value>
        public string SubCategoryName { get; set; }

        /// <summary>
        ///     Get or sets the ReportId
        /// </summary>
        /// <value>parameter Report Id</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Get or sets the ReportName
        /// </summary>
        /// <value>parameter Report Name</value>
        public string ReportName { get; set; }
    }
}