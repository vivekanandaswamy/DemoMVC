﻿// -----------------------------------------------------------------------
// <copyright file="NavigationModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationModel class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    using System.Collections.Generic;

    /// <summary>
    /// Web Model for NavigationModel
    /// </summary>
    public class NavigationModel
    {
        /// <summary>
        /// Gets or sets the current options list.
        /// </summary>
        /// <value>
        /// The current options list.
        /// </value>
        public List<OptionsList> CurrentOptionsList { get; set; }

        /// <summary>
        /// Gets or sets the previous options list.
        /// </summary>
        /// <value>
        /// The previous options list.
        /// </value>
        public List<OptionsList> PreviousOptionsList { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is updated.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is updated; otherwise, <c>false</c>.
        /// </value>
        public bool IsUpdated { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is last.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is last; otherwise, <c>false</c>.
        /// </value>
        public bool IsLast { get; set; }

        /// <summary>
        /// Gets or sets the index.
        /// </summary>
        /// <value>
        /// The index.
        /// </value>
        public int Index { get; set; }

        /// <summary>
        /// Gets or sets the current viewing.
        /// </summary>
        /// <value>
        /// The current viewing.
        /// </value>
        public List<string> CurrentViewing { get; set; }

        /// <summary>
        /// Gets or sets the selected option.
        /// </summary>
        /// <value>
        /// The selected option.
        /// </value>
        public string SelectedOption { get; set; }
    }
}