﻿// -----------------------------------------------------------------------
// <copyright file="Data.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Data class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Web Model for Data
    /// </summary>
    public class Data
    {
        /// <summary>
        ///     Gets or sets y-axis value for Sereis.
        /// </summary>
        /// <value>Contains value for Sereis.</value>
        public decimal y { get; set; }

        /// <summary>
        ///     Gets or sets Color value for the series.
        /// </summary>
        /// <value>Contains value for Color.</value>
        public string color { get; set; }
    }
}