﻿// -----------------------------------------------------------------------
// <copyright file="ReportSettingsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSettingsModel </summary>
// -----------------------------------------------------------------------

using System;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportSettingsModel
    {
        /// <summary>
        /// Get or sets the Corporate
        /// </summary>
        /// <value> Corporate value</value>
        public string Corporate { get; set; }

        /// <summary>
        /// Get or sets the Country
        /// </summary>
        /// <value> Country value</value>
        public string Country { get; set; }

        /// <summary>
        /// Get or sets the Region
        /// </summary>
        /// <value> Region value</value>
        public string Region { get; set; }

        /// <summary>
        /// Get or sets the Controller
        /// </summary>
        /// <value> Controller value</value>
        public string Controller { get; set; }

        /// <summary>
        /// Get or sets the Machine
        /// </summary>
        /// <value> Machine value</value>
        public string Machine { get; set; }

        /// <summary>
        /// Get or sets the MachineGroup
        /// </summary>
        /// <value> MachineGroup value</value>
        public string MachineGroup { get; set; }

        /// <summary>
        /// Get or sets the Formula
        /// </summary>
        /// <value> Formula value</value>
        public string Formula { get; set; }

        /// <summary>
        /// Get or sets the MachineType
        /// </summary>
        /// <value> MachineType value</value>
        public string MachineType { get; set; }

        /// <summary>
        /// Get or sets the Alarm
        /// </summary>
        /// <value> Alarm value</value>
        public string Alarm { get; set; }

        /// <summary>
        /// Get or sets the FromDate
        /// </summary>
        /// <value> FromDate value</value>

        public DateTime FromDate { get; set; }

        /// <summary>
        /// Get or sets the ToDate
        /// </summary>
        /// <value> ToDate value</value>

        public DateTime ToDate { get; set; }

        /// <summary>
        /// Get or sets the GroupId
        /// </summary>
        /// <value> GroupId value</value>
        public string GroupId { get; set; }

        /// <summary>
        /// Get or sets the MachineInternalId
        /// </summary>
        /// <value> MachineInternalId value</value>
        public string MachineInternalId { get; set; }

        /// <summary>
        /// Get or sets the Category
        /// </summary>
        /// <value> Category value</value>
        public string Category { get; set; }

        /// <summary>
        /// Get or sets the Customer
        /// </summary>
        /// <value> Customer value</value>
        public string Customer { get; set; }

        /// <summary>
        /// Get or sets the DayWise
        /// </summary>
        /// <value> DayWise value</value>
        public bool IsDayWise { get; set; }

        /// <summary>
        /// Get or sets the WeekWise
        /// </summary>
        /// <value> WeekWise value</value>
        public bool IsWeekWise { get; set; }

        /// <summary>
        /// Get or sets the MonthWise
        /// </summary>
        /// <value> MonthWise value</value>
        public bool IsMonthWise { get; set; }

        /// <summary>
        /// Get or sets the QuarterWise
        /// </summary>
        /// <value> QuarterWise value</value>
        public bool IsQuarterWise { get; set; }

        /// <summary>
        /// Get or sets the IsYear
        /// </summary>
        /// <value> IsYear value</value>
        public bool IsYearWise { get; set; }

        /// <summary>
        /// Get or sets the FormulaWise
        /// </summary>
        /// <value> FormulaWise value</value>
        public bool IsFormulaWise { get; set; }

        /// <summary>
        /// Get or sets the EcolabTextileWise
        /// </summary>
        /// <value> EcolabTextileWise value</value>
        public bool IsEcolabTextileWise { get; set; }

        /// <summary>
        /// Get or sets the PlantTextileWise
        /// </summary>
        /// <value> PlantTextileWise value</value>
        public bool IsPlantTextileWise { get; set; }

        /// <summary>
        /// Get or sets the PlantFormulaWise
        /// </summary>
        /// <value> PlantFormulaWise value</value>
        public bool IsPlantFormulaWise { get; set; }

        /// <summary>
        /// Get or sets the IsViewByPlantWise
        /// </summary>
        /// <value> IsViewByPlantWise value</value>
        public bool IsViewByPlantWise { get; set; }

        /// <summary>
        /// Get or sets the DrillDownMachineGroupId
        /// </summary>
        /// <value> DrillDownMachineGroupId value</value>
        public int DrillDownMachineGroupId { get; set; }

        /// <summary>
        /// Get or sets the ReportId
        /// </summary>
        /// <value> ReportId value</value>
        public int ReportId { get; set; }

        /// <summary>
        /// Get or Set the DisplayTopRecordsCount
        /// </summary>
        /// <value>DisplayTopRecordsCount value</value>
        public int DisplayTopRecordsCount { get; set; }

        /// <summary>
        /// Get or Set the ShowOthers
        /// </summary>
        /// <value>ShowOthers value</value>
        public bool ShowOthers { get; set; }

        /// <summary>
        /// Get or Set the ShowTotal
        /// </summary>
        /// <value>ShowTotal value</value>
        public bool ShowTotal { get; set; }

        /// <summary>
        /// Get or sets the ChartDisplayId
        /// </summary>
        /// <value> ChartDisplayId value</value>
        public int ChartDisplayId { get; set; }

        /// <summary>
        /// Get or sets the ViewModeId
        /// </summary>
        /// <value> ViewModeId value</value>
        public int ViewModeId { get; set; }

        /// <summary>
        /// Get or sets the SwitchModeId
        /// </summary>
        /// <value> SwitchModeId value</value>
        public int SwitchModeId { get; set; }

        /// <summary>
        /// Gets or sets the users.
        /// </summary>
        /// <value> The users. </value>
        public string Users { get; set; }

        /// <summary>
        /// Get or sets the UserId
        /// </summary>
        /// <value> Login UserId value</value>
        public int UserId { get; set; }

        /// <summary>
        /// Get or sets the ReportName
        /// </summary>
        /// <value> ReportName value</value>
        public string ReportName { get; set; }

        /// <summary>
        /// Get or sets the ChartType
        /// </summary>
        /// <value> ChartType value</value>
        public string ChartType { get; set; }

        /// <summary>
        /// Get or sets the SortColumnId
        /// </summary>
        /// <value> SortColumnId value</value>
        public int SortColumnId { get; set; }

        /// <summary>
        /// Get or sets the SortDirection
        /// </summary>
        /// <value> SortDirection value</value>
        public string SortDirection { get; set; }

        /// <summary>
        /// Get or sets the PageSize
        /// </summary>
        /// <value> PageSize value</value>
        public int PageSize { get; set; }

        /// <summary>
        /// Get or sets the PageCount
        /// </summary>
        /// <value> PageCount value</value>
        public int PageCount { get; set; }

        /// <summary>
        /// Get or sets the CurrentPageIndex
        /// </summary>
        /// <value> CurrentPageIndex value</value>
        public int CurrentPageIndex { get; set; }

        /// <summary>
        /// Gets or sets the production mix identifier.
        /// </summary>
        /// <value>
        /// The production mix identifier.
        /// </value>
        public int? ProductionMixId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is drill down.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is drill down; otherwise, <c>false</c>.
        /// </value>
        public bool IsDrillDown { get; set; }

        /// <summary>
        /// Get or sets the IsViewByTime
        /// </summary>
        /// <value> ViewByTime Type value</value>
        public bool IsViewByTime { get; set; }

        /// <summary>
        /// Get or sets the ActionType
        /// </summary>
        /// <value> Action Type value</value>
        public string ActionType { get; set; }

        /// <summary>
        /// Get or sets the SortFeild
        /// </summary>
        /// <value> SortFeild value</value>
        public string SortFeild { get; set; }

        /// <summary>
        /// Get or sets the Roleld
        /// </summary>
        /// <value> Role ld value</value>
        public int RoleId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is first level.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is first level; otherwise, <c>false</c>.
        /// </value>
        public bool IsFirstLevel { get; set; }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public string SelectedItem { get; set; }

        /// <summary>
        /// Gets or sets the NeedCurrent.
        /// </summary>
        /// <value>
        /// NeedCurrent value .
        /// </value>
        public bool NeedCurrent { get; set; }

        /// <summary>
        /// Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>
        /// EcolabAccountNumber value .
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the ViewType.
        /// </summary>
        /// <value>
        /// ViewType value .
        /// </value>
        public string ViewType { get; set; }

        /// <summary>
        /// Gets or sets the Subview.
        /// </summary>
        /// <value>
        /// Subview value .
        /// </value>
        public string SubView { get; set; }

        /// <summary>
        /// Gets or sets the Plant.
        /// </summary>
        /// <value>
        /// Plant value .
        /// </value>
        public string Plant { get; set; }

        /// <summary>
        /// Gets or sets the DrillValue.
        /// </summary>
        /// <value>
        /// DrillValue value .
        /// </value>
        public string DrillValue { get; set; }

        /// <summary>
        /// Gets or sets the DrillDownId.
        /// </summary>
        /// <value>
        /// DrillDownId value .
        /// </value>
        public int DrillDownId { get; set; }

        /// <summary>
        /// Gets or sets the UserRegion.
        /// </summary>
        /// <value>
        /// UserRegion value .
        /// </value>
        public int UserRegion { get; set; }

        /// <summary>
        /// Gets or sets the UserCountry.
        /// </summary>
        /// <value>
        /// UserCountry value .
        /// </value>
        public int UserCountry { get; set; }

        /// <summary>
        /// Gets or sets the UserCulture.
        /// </summary>
        /// <value>
        /// UserCulture value .
        /// </value>
        public string UserCulture { get; set; }

        /// <summary>
        /// Gets or sets the UserLanguageId.
        /// </summary>
        /// <value>
        /// UserLanguageId value .
        /// </value>
        public int UserLanguageId { get; set; }

        /// <summary>
        /// Gets or sets the UserCurrency.
        /// </summary>
        /// <value>
        /// UserCurrency value .
        /// </value>
        public string UserCurrency { get; set; }

        /// <summary>
        /// Gets or Sets DrilldownChartColor
        /// </summary>
        /// <value>Drilldown Chart Color value</value>
        public string DrilldownChartColor { get; set; }

        /// <summary>
        /// Gets or sets the chain category.
        /// </summary>
        /// <value>
        /// The chain category.
        /// </value>
        public string ChainCategory { get; set; }

        /// <summary>
        /// Gets or sets the chain formula.
        /// </summary>
        /// <value>
        /// The chain formula.
        /// </value>
        public string ChainFormula { get; set; }

        /// <summary>
        /// Gets or sets the drilldown sub view identifier.
        /// </summary>
        /// <value>
        /// The drilldown sub view identifier.
        /// </value>
        public int DrilldownSubViewId { get; set; }

        /// <summary>
        /// Gets or Sets DrillupSubViewId
        /// </summary>
        /// <value>DrillupSubViewId value</value>
        public int DrillupSubViewId { get; set; }

        /// <summary>
        /// Gets or Sets SubViewId
        /// </summary>
        /// <value>SubViewId value</value>
        public int SubViewId { get; set; }

        /// <summary>
        /// Gets or Sets IsLast
        /// </summary>
        /// <value>IsLast value</value>
        public bool IsLast { get; set; }

        /// <summary>
        /// Gets or sets the ecolab category.
        /// </summary>
        /// <value>
        /// The ecolab category.
        /// </value>
        public string EcolabCategory { get; set; }

        /// <summary>
        /// Gets or sets the plant formula.
        /// </summary>
        /// <value>
        /// The plant formula.
        /// </value>
        public string PlantFormula { get; set; }

        /// <summary>
        ///     Gets or Sets HasGroupBy
        /// </summary>
        /// <value>Has GeoupBy value</value>
        public bool HasGroupBy { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is linking report.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is linking report; otherwise, <c>false</c>.
        /// </value>
        public bool IsLinkingReport { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether custom dates are selected.
        /// </summary>
        /// <value>
        /// <c>true</c> if custom dates are selected; otherwise, <c>false</c>.
        /// </value>
        public bool IsCustom { get; set; }
        /// <summary>
        /// Gets or Sets FromDateDisplay
        /// </summary>
        /// <value>FromDateDisplay value</value>
        public string FromDateDisplay { get; set; }
        /// <summary>
        /// Gets or Sets ToDateDisplay
        /// </summary>
        /// <value>ToDateDisplay value</value>
        public string ToDateDisplay { get; set; }
        /// <summary>
		///     Gets or sets PrevCurrentStandardId
		/// </summary>
		/// <value>PrevCurrentStandardId value</value>
		public int PrevCurrentStandardId { get; set; }
        /// <summary>
		///     Gets or sets StandardTimeLineId
		/// </summary>
		/// <value>StandardTimeLineId value</value>
		public int StandardTimeLineId { get; set; }
        /// <summary>
        /// Gets or Sets OptionalFiltersSelect
        /// </summary>
        /// <value>OptionalFiltersSelect value</value>
        public string OptionalFiltersSelect { get; set; }
        /// <summary>
        /// Gets or Sets IsFilterApplied
        /// </summary>
        /// <value>IsFilterApplied value</value>
        public bool IsFilterApplied { get; set; }
    }
}