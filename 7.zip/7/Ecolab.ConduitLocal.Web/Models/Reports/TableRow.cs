﻿// -----------------------------------------------------------------------
// <copyright file="TableRow.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TableRow </summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class TableRow
    {
        /// <summary>
        /// Gets or sets Row Cells 
        /// </summary>
        /// <value>Contains Cells Collection</value>
        public List<TableCells> Cells { get; set; }
    }
}