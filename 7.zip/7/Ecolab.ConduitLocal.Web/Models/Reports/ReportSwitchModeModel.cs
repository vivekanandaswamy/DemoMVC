﻿// -----------------------------------------------------------------------
// <copyright file="ReportSwitchModeModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSwitchModeModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportSwitchModeModel
    {
        /// <summary>
        /// Get or set the ColumnName
        /// </summary>
        /// <value>Report column name.</value>
        public int Id { get; set; }

        /// <summary>
        /// Get or set the ColumnName
        /// </summary>
        /// <value>Report column name.</value>
        public string SwitchName { get; set; }

        /// <summary>
        /// Get or set the IsSelected
        /// </summary>
        /// <value>IsSelected.</value>
        public bool IsSelected { get; set; }
    }
}