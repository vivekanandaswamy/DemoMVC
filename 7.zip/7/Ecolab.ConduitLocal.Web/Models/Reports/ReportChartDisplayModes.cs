﻿// -----------------------------------------------------------------------
// <copyright file="ReportChartDisplayModes.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportChartDisplayModes </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportChartDisplayModes
    {
        /// <summary>
        /// Get or set the ChartDisplayId
        /// </summary>
        /// <value>ChartDisplayId value.</value>
        public int ChartDisplayId { get; set; }

        /// <summary>
        /// Get or set the ChartDisplayMode
        /// </summary>
        /// <value>ChartDisplayMode value.</value>
        public string ChartDisplayMode { get; set; }

        /// <summary>
        /// Get or set the IsSelected
        /// </summary>
        /// <value>IsSelected value.</value>
        public bool IsSelected { get; set; }
    }
}