﻿// -----------------------------------------------------------------------
// <copyright file="Series.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Series </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class Series
    {
        /// <summary>
        /// Gets or sets Series Data Collection
        /// </summary>
        /// <value>Contains SeriesData Collection </value>
        public List<SeriesData> seriesData { get; set; }

        /// <summary>
        /// Gets or sets Series Has Average flag.
        /// </summary>
        /// <value>Contains boolen value if series has average.</value>
        public bool hasAvg { get; set; }
    }
}