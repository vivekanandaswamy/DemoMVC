﻿// -----------------------------------------------------------------------
// <copyright file="ReportFilterListModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Filter List class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Entity class for ReportFilterListModel
    /// </summary>
    public class ReportFilterListModel : BaseViewModel
    {
        /// <summary>
        ///  Initializes a new instance of the ReportFilterListModel
        /// </summary>
        /// <param name="id">report filter id.</param>
        /// <param name="filterName">report filter name.</param>
        public ReportFilterListModel(int id, string filterName)
        {
            Id = id;
            FilterName = filterName;
        }

        /// <summary>
        ///  Initializes a new instance of the ReportFilterListModel
        /// </summary>
        public ReportFilterListModel()
        {
        }

        /// <summary>
        ///  Gets or sets the FilterName
        /// </summary>
        /// <value>Filter Name.</value>
        public string FilterName { get; set; }
    }
}