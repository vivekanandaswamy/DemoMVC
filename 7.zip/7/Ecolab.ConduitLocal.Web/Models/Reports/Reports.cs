﻿// -----------------------------------------------------------------------
// <copyright file="Reports.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Reports class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Wb Model for LocalReports
    /// </summary>
    public class Reports
    {
        /// <summary>
        ///     Get or sets ReportSubCategoryId
        /// </summary>
        /// <value>This Conatins ReportSubCategoryId</value>
        public int ReportSubCategoryId { get; set; }

        /// <summary>
        ///     Get or sets ReportName
        /// </summary>
        /// <value>This Contains ReportId</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Get or sets ReportName
        /// </summary>
        /// <value>This Contains ReportName</value>
        public string ReportName { get; set; }

        /// <summary>
        ///     Get or Set the DisplayTopRecordsCount
        /// </summary>
        /// <value>DisplayTopRecordsCount value</value>
        public int DisplayTopRecordsCount { get; set; }

        /// <summary>
        ///     Get or Set the ShowOthers
        /// </summary>
        /// <value>ShowOthers value</value>
        public bool ShowOthers { get; set; }

        /// <summary>
        ///     Get or Set the ShowTotal
        /// </summary>
        /// <value>ShowTotal value</value>
        public bool ShowTotal { get; set; }

        /// <summary>
        ///     Get or sets the ChartType
        /// </summary>
        /// <value> ChartType value</value>
        public string ChartType { get; set; }

        /// <summary>
        ///     Get or Set the isPaging
        /// </summary>
        /// <value>IsPaging value</value>
        public bool IsPaging { get; set; }

        /// <summary>
        ///     Get or Set the PageSize
        /// </summary>
        /// <value>PageSize value</value>
        public int PageSize { get; set; }
    }
}