﻿// -----------------------------------------------------------------------
// <copyright file="ChartData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ChartData </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ChartData
    {
        /// <summary>
        /// Gets or Sets ChartTitle
        /// </summary>
        /// <value>Contains ChartTitle Value</value>
        public string ChartTitle { get; set; }

        /// <summary>
        /// Gets or Sets ChartType
        /// </summary>
        /// <value>Contains ChartType Value</value>
        public string ChartType { get; set; }

        /// <summary>
        /// Gets or Sets Series Model
        /// </summary>
        /// <value>Contains Series Type Value</value>
        public Series series { get; set; }
    }
}