﻿// -----------------------------------------------------------------------
// <copyright file="XAxis.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XAxis </summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    /// Web Model for XAxisModel
    /// </summary>
    public class XAxis
    {
        /// <summary>
        /// Gets or sets Categories for XAxis
        /// </summary>
        /// <value>Contains the Categories Collection</value>
        public List<string> Categories { get; set; }
    }
}