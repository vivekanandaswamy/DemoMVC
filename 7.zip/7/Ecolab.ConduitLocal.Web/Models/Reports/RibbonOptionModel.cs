﻿// -----------------------------------------------------------------------
// <copyright file="RibbonOptionModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RibbonOptionModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class RibbonOptionModel
    {
        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        /// <value>Ribbon option id.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        /// <value>Ribbon option name.</value>
        public string Name { get; set; }
    }
}