﻿// -----------------------------------------------------------------------
// <copyright file="ReportTable.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportTable </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportTable
    {
        /// <summary>
        /// Gets or Sets Show Total  
        /// </summary>
        /// <value>Contains boolean value for ShowTotal</value>
        public bool ShowTotal { get; set; }

        /// <summary>
        /// Gets or Sets Show Others  
        /// </summary>
        /// <value>Contains boolean value for ShowOthers</value>
        public bool ShowOthers { get; set; }

        /// <summary>
        /// Gets or Sets Sort Field On Table
        /// </summary>
        /// <value>Contains Sort Field of Table</value>
        public int SortField { get; set; }

        /// <summary>
        /// Gets or Sets Sort Direction On Table
        /// </summary>
        /// <value>Contains Sort Direction of Table</value>
        public string SortDirection { get; set; }

        /// <summary>
        /// Gets or Sets Page Size for the Table
        /// </summary>
        /// <value>Contains PageSize value</value>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or Sets Page Count for the Table
        /// </summary>
        /// <value>Contains PageCount value</value>
        public int PageCount { get; set; }

        /// <summary>
        /// Gets or Sets CurrentPageIndex of the Table
        /// </summary>
        /// <value>Contains the CurrentPageIndex Value</value>
        public int CurrentPageIndex { get; set; }

        /// <summary>
        /// Gets or Sets OtherRows Collection
        /// </summary>
        /// <value>Contains OtherRows Collection</value>
        public List<TableRow> OtherRows { get; set; }

        /// <summary>
        /// Gets or Sets TotalRow 
        /// </summary>
        /// <value>Conatains Row values for the TotalRow </value>
        public TableRow TotalRow { get; set; }

        /// <summary>
        /// Gets or Sets OtherRow 
        /// </summary>
        /// <value>Conatains Row values for the OtherRow </value>
        public TableRow OtherRow { get; set; }

        /// <summary>
        /// Gets or Sets Rows
        /// </summary>
        /// <value>Contains Rows for the table</value>
        public List<TableRow> Rows { get; set; }

        /// <summary>
        /// Gets or Sets Columns
        /// </summary>
        /// <value>Contains Columns for the table</value>
        public List<TableColumn> Columns { get; set; }

        /// <summary>
        /// Gets or Sets Sorting And Paging Details of the table.
        /// </summary>
        /// <value>Contains Sorting And Paging Details</value>
        public SortingPagingInfo SortingPagingInfo { get; set; }

        /// <summary>
        /// Gets or Sets IsFirstLevel.
        /// </summary>
        /// <value>Contains IsFirstLevel</value>
        public bool IsFirstLevel { get; set; }

        /// <summary>
        /// Gets or Sets ReportId.
        /// </summary>
        /// <value>Contains ReportId</value>
        public int ReportId { get; set; } 
    }
}