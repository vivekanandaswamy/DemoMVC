﻿// -----------------------------------------------------------------------
// <copyright file="ReportChartModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportChartModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportChartModel
    {
        /// <summary>
        ///Gets or Sets ChartType Model 
        /// </summary>
        /// <value>The ChartType Type</value>
        public ChartType ChartType { get; set; }

        /// <summary>
        /// Gets or Sets ChartData Model 
        /// </summary>
        /// <value>The ChartData Type</value>
        public ChartData ChartData { get; set; }

        /// <summary>
        /// Gets or Sets ChartSettings Model 
        /// </summary>
        /// <value>The ChartSettings Type</value>
        public ChartSettings ChartSettings { get; set; }

        public bool IsFirstLevel { get; set; }
    }
}