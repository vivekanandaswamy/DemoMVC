﻿// -----------------------------------------------------------------------
// <copyright file="ReportTableAndChartModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportTableAndChartModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using Ecolab.Models.Reports;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{

    /// <summary>
    /// Chart Type Enum
    /// </summary>
    public enum ChartType
    {
        /// <summary>
        /// The Chart Type pie
        /// </summary>
        Pie,
        /// <summary>
        /// The Chart Type do nut
        /// </summary>
        DoNut,
        /// <summary>
        /// The Chart Type column
        /// </summary>
        Column,
        /// <summary>
        /// The Chart Type line
        /// </summary>
        Line
    }

    /// <summary>
    /// Report Filters Enum
    /// </summary>
    public enum ReportFilterEnum
    {
        /// <summary>
        /// The Report Filter Enum corporate
        /// </summary>
        Corporate = 1,
        /// <summary>
        /// The Report Filter Enum country
        /// </summary>
        Country = 2,
        /// <summary>
        /// The Report Filter Enum region
        /// </summary>
        Region = 3,
        /// <summary>
        /// The Report Filter Enum plant
        /// </summary>
        Plant = 4,
        /// <summary>
        /// The Report Filter Enum machine group
        /// </summary>
        MachineGroup = 5,
        /// <summary>
        /// The Report Filter Enum machine
        /// </summary>
        Machine = 6,
        /// <summary>
        /// The Report Filter Enum category
        /// </summary>
        Category = 7,
        /// <summary>
        /// The Report Filter Enum machine types
        /// </summary>
        MachineTypes = 8,
        /// <summary>
        /// The Report Filter Enum customer
        /// </summary>
        Customer = 9,
        /// <summary>
        /// The Report Filter Enum formula
        /// </summary>
        Formula = 10,
        /// <summary>
        /// The Report Filter Enum controller dispencer
        /// </summary>
        ControllerDispencer = 11,
        /// <summary>
        /// The Report Filter Enum alarm
        /// </summary>
        Alarm = 12,
        /// <summary>
        /// The Report Filter Enum dryer group
        /// </summary>
        DryerGroup = 13,
        /// <summary>
        /// The Report Filter Enum dryer
        /// </summary>
        Dryer = 14,
        /// <summary>
        /// The Report Filter Enum finisher
        /// </summary>
        Finisher = 15,
        /// <summary>
        /// The Report Filter Enum finisher group
        /// </summary>
        FinisherGroup = 16,
        /// <summary>
        /// The Report Filter Enum water and energyrecovering unit
        /// </summary>
        WaterAndEnergyrecoveringUnit = 17,
        /// <summary>
        /// The Report Filter Enum meter
        /// </summary>
        Meter = 18,
        /// <summary>
        /// The Report Filter Enum boiler
        /// </summary>
        Boiler = 19,
        /// <summary>
        /// The water and energy system
        /// </summary>
        WaterAndEnergySystem = 20,
        /// <summary>
        /// The Report Filter Enum user
        /// </summary>
        User = 21,
        /// <summary>
        /// The Report Filter Enum action type
        /// </summary>
        ActionType = 22
    }

    /// <summary>
    /// Report ViewBy Enum
    /// </summary>
    public enum ReportViewByEnum
    {
        /// <summary>
        /// The Report ViewBy Enum time
        /// </summary>
        Time = 1,
        /// <summary>
        /// The Report ViewBy Enum location
        /// </summary>
        Location = 2,
        /// <summary>
        /// The Report ViewBy Enum eco lab category
        /// </summary>
        EcoLabCategory = 3,
        /// <summary>
        /// The Report ViewBy Enum textile category
        /// </summary>
        TextileCategory = 4,
        /// <summary>
        /// The Report ViewBy Enum chain category
        /// </summary>
        ChainCategory = 5,
        /// <summary>
        /// The Report ViewBy Enum customer
        /// </summary>
        Customer = 6,
        /// <summary>
        /// The Report ViewBy Enum formula
        /// </summary>
        Formula = 7,
        /// <summary>
        /// The Report ViewBy Enum view by machine
        /// </summary>
        ViewByMachine = 8,
        /// <summary>
        /// The Report ViewBy Enum view by plant
        /// </summary>
        ViewByPlant = 9,

    }

    /// <summary>
    /// The Report Enum
    /// </summary>
    public enum ReportEnum
    {
        /// <summary>
        /// The production summary
        /// </summary>
        ProductionSummary = 1,
        /// <summary>
        /// The production mix
        /// </summary>
        ProductionMix = 2,
        /// <summary>
        /// The period production
        /// </summary>
        PeriodProduction = 4,
        /// <summary>
        /// The chemical consumption
        /// </summary>
        ChemicalConsumption = 5,
        /// <summary>
        /// The chemical inventory
        /// </summary>
        ChemicalInventory = 6,
        /// <summary>
        /// The operations summary
        /// </summary>
        OperationsSummary = 10,
        /// <summary>
        /// The alarm summary
        /// </summary>
        AlarmSummary = 12,
        /// <summary>
        /// The alarm details
        /// </summary>
        AlarmDetails = 13,
        /// <summary>
        /// The Report Enum user log
        /// </summary>
        UserLog = 30,
        /// <summary>
        /// The rejected loads
        /// </summary>
        RejectedLoads = 7,
        /// <summary>
        /// The Report Enum rewash
        /// </summary>
        Rewash = 20,
    }

    /// <summary>
    /// Quarters Enum
    /// </summary>
    public enum QuartersEnum
    {
        /// <summary>
        /// The Quarters Enum Q1
        /// </summary>
        Q1 = 1,
        /// <summary>
        /// The Quarters Enum Q2
        /// </summary>
        Q2 = 2,
        /// <summary>
        /// The Quarters Enum Q3
        /// </summary>
        Q3 = 3,
        /// <summary>
        /// The Quarters Enum Q4
        /// </summary>
        Q4 = 4
    }

    /// <summary>
    /// Report Columns Enum
    /// </summary>
    public enum ReportColumnsEnum
    {
        /// <summary>
        /// The actiondescription
        /// </summary>
        Actiondescription = 1,
        /// <summary>
        /// The actual chem perload
        /// </summary>
        ActualChemPerload = 3,
        /// <summary>
        /// The actual energy
        /// </summary>
        ActualEnergy = 7,
        /// <summary>
        /// The actual energyperload
        /// </summary>
        ActualEnergyperload = 8,
        /// <summary>
        /// The actual waterperload
        /// </summary>
        ActualWaterperload = 10,
        /// <summary>
        /// The actual waterusage
        /// </summary>
        ActualWaterusage = 11,
        /// <summary>
        /// The alarm description
        /// </summary>
        AlarmDescription = 13,
        /// <summary>
        /// The alarm duration
        /// </summary>
        Alarmduration = 14,
        /// <summary>
        /// The average consumption
        /// </summary>
        AverageConsumption = 16,
        /// <summary>
        /// The average daily consumption
        /// </summary>
        AverageDailyConsumption = 17,
        /// <summary>
        /// The average runtime cycle
        /// </summary>
        AverageRuntimeCycle = 18,
        /// <summary>
        /// The averageturn time
        /// </summary>
        AverageturnTime = 19,
        /// <summary>
        /// The average daily cost ytd
        /// </summary>
        AvgDailyCostYTD = 20,
        /// <summary>
        /// The average daily costload ytd
        /// </summary>
        AvgDailyCostloadYTD = 21,
        /// <summary>
        /// The chem targetper load
        /// </summary>
        ChemTargetperLoad = 43,
        /// <summary>
        /// The chemicalcostperload
        /// </summary>
        Chemicalcostperload = 45,
        /// <summary>
        /// The chemical name
        /// </summary>
        ChemicalName = 47,
        /// <summary>
        /// The conductivity
        /// </summary>
        Conductivity = 51,
        /// <summary>
        /// The consumptionperload
        /// </summary>
        Consumptionperload = 54,
        /// <summary>
        /// The Report Columns Enum cost
        /// </summary>
        Cost = 56,
        /// <summary>
        /// The cost excess
        /// </summary>
        Costexcess = 57,
        /// <summary>
        /// The cost per load
        /// </summary>
        Costperload = 58,
        /// <summary>
        /// The Report Columns Enum cycle
        /// </summary>
        Cycle = 62,
        /// <summary>
        /// The Report Columns Enum date
        /// </summary>
        Date = 63,
        /// <summary>
        /// The Report Columns Enum difference
        /// </summary>
        Difference = 66,
        /// <summary>
        /// The disinfectionstatus
        /// </summary>
        Disinfectionstatus = 67,
        /// <summary>
        /// The energyperload
        /// </summary>
        Energyperload = 76,
        /// <summary>
        /// The energy targetperload
        /// </summary>
        EnergyTargetperload = 77,
        /// <summary>
        /// The Report Columns Enum fireball3
        /// </summary>
        Fireball3 = 82,
        /// <summary>
        /// The formula category
        /// </summary>
        FormulaCategory = 84,
        /// <summary>
        /// The formula name
        /// </summary>
        FormulaName = 85,
        /// <summary>
        /// The laborcostper load
        /// </summary>
        LaborcostperLoad = 114,
        /// <summary>
        /// The laborcostper pieces
        /// </summary>
        LaborcostperPieces = 115,
        /// <summary>
        /// The load efficiency
        /// </summary>
        LoadEfficiency = 119,
        /// <summary>
        /// The actualproductionhour
        /// </summary>
        Actualproductionhour = 120,
        /// <summary>
        /// The Report Columns Enum location
        /// </summary>
        Location = 121,
        /// <summary>
        /// The Report Columns Enum mix
        /// </summary>
        Mix = 127,
        /// <summary>
        /// The numberof alarms
        /// </summary>
        NumberofAlarms = 131,
        /// <summary>
        /// The Report Columns Enum noofloads
        /// </summary>
        Noofloads = 133,
        /// <summary>
        /// The numberof pieces
        /// </summary>
        NumberofPieces = 135,
        /// <summary>
        /// The ordersreceived
        /// </summary>
        Ordersreceived = 138,
        /// <summary>
        /// The product name
        /// </summary>
        ProductName = 144,
        /// <summary>
        /// The production mix
        /// </summary>
        ProductionMix = 146,
        /// <summary>
        /// The resetuser name
        /// </summary>
        ResetuserName = 155,
        /// <summary>
        /// The Report Columns Enum rewash
        /// </summary>
        Rewash = 156,
        /// <summary>
        /// The start date time
        /// </summary>
        StartDateTime = 168,
        /// <summary>
        /// The target cons perload
        /// </summary>
        TargetConsPerload = 176,
        /// <summary>
        /// The targetconsumption
        /// </summary>
        Targetconsumption = 177,
        /// <summary>
        /// The targetproduction
        /// </summary>
        Targetproduction = 181,
        /// <summary>
        /// The targetproductionhour
        /// </summary>
        Targetproductionhour = 182,
        /// <summary>
        /// The Report Columns Enum time
        /// </summary>
        Time = 195,
        /// <summary>
        /// The totalconsumption
        /// </summary>
        Totalconsumption = 198,
        /// <summary>
        /// The actualproduction
        /// </summary>
        Actualproduction = 200,
        /// <summary>
        /// The washer name
        /// </summary>
        Washername = 212,
        /// <summary>
        /// The washer tunnelname
        /// </summary>
        WasherTunnelname = 213,
        /// <summary>
        /// The watertargetperload
        /// </summary>
        Watertargetperload = 225,
        /// <summary>
        /// The actual consumption per load
        /// </summary>
        ActualConsumptionPerLoad = 274,

        /// <summary>
        /// Category Name
        /// </summary>
        CategoryName = 281,

        /// <summary>
        /// category Cost
        /// </summary>
        CategoryCost = 282,

        /// <summary>
        /// The Actual Category cost
        /// </summary>
        ActualCategoryCost = 283
    }

    /// <summary>
    ///Ribbon Options Enum
    /// </summary>
    public enum RibbonOptionsEnum
    {
        /// <summary>
        /// The switch category
        /// </summary>
        SwitchCategory = 1,
        /// <summary>
        /// The Ribbon Options Enum All columns
        /// </summary>
        AllColumns = 2,
        /// <summary>
        /// The chart display mode
        /// </summary>
        ChartDisplayMode = 3,
        /// <summary>
        /// The Ribbon Options Enum filter
        /// </summary>
        Filter = 4,
        /// <summary>
        /// The standard and custom
        /// </summary>
        StandardAndCustom = 5,
        /// <summary>
        /// The Ribbon Options Enum view by
        /// </summary>
        ViewBy = 6,
        /// <summary>
        /// The Ribbon Options Enum As on today
        /// </summary>
        AsOnToday = 7
    }

    /// <summary>
    /// The Months Enum
    /// </summary>
    public enum MonthsEnum
    {
        /// <summary>
        /// The Months Enum jan
        /// </summary>
        Jan = 1,
        /// <summary>
        /// The Months Enum feb
        /// </summary>
        Feb = 2,
        /// <summary>
        /// The Months Enum mar
        /// </summary>
        Mar = 3,
        /// <summary>
        /// The Months Enum apr
        /// </summary>
        Apr = 4,
        /// <summary>
        /// The Months Enum may
        /// </summary>
        May = 5,
        /// <summary>
        /// The Months Enum jun
        /// </summary>
        Jun = 6,
        /// <summary>
        /// The Months Enum jul
        /// </summary>
        Jul = 7,
        /// <summary>
        /// The Months Enum aug
        /// </summary>
        Aug = 8,
        /// <summary>
        /// The Months Enum sep
        /// </summary>
        Sep = 9,
        /// <summary>
        /// The Months Enum oct
        /// </summary>
        Oct = 10,
        /// <summary>
        /// The Months Enum nov
        /// </summary>
        Nov = 11,
        /// <summary>
        /// The Months Enum dec
        /// </summary>
        Dec = 12
    }

    /// <summary>
    /// Report Sub View Type Enum
    /// </summary>
    public enum ReportSubViewByEnum
    {
        /// <summary>
        /// The Report Sub View Type year
        /// </summary>
        Year = 1,
        /// <summary>
        /// The Report Sub View Type quarter
        /// </summary>
        Quarter = 2,
        /// <summary>
        /// The Report Sub View Type month
        /// </summary>
        Month = 3,
        /// <summary>
        /// The Report Sub View Type week
        /// </summary>
        Week = 4,
        /// <summary>
        /// The Report Sub View Type day
        /// </summary>
        Day = 5,
        /// <summary>
        /// The Report Sub View Type shift
        /// </summary>
        Shift = 6,
        /// <summary>
        /// The Report Sub View Type region country
        /// </summary>
        RegionCountry = 7,
        /// <summary>
        /// The Report Sub View Type plant
        /// </summary>
        Plant = 9,
        /// <summary>
        /// The Report Sub View Type washer group
        /// </summary>
        WasherGroup = 10,
        /// <summary>
        /// The Report Sub View Type washer
        /// </summary>
        Washer = 11,
        /// <summary>
        /// The Report Sub View Type eco lab category
        /// </summary>
        EcoLabCategory = 12,
        /// <summary>
        /// The Report Sub View Type customer
        /// </summary>
        Customer = 13,
        /// <summary>
        /// The Report Sub View Type formula
        /// </summary>
        Formula = 14,
        /// <summary>
        /// The Report Sub View Type textile category
        /// </summary>
        TextileCategory = 15,
        /// <summary>
        /// The Report Sub View Type chain category
        /// </summary>
        ChainCategory = 16
    }

    public class ReportTableAndChartModel
    {
        /// <summary>
        /// Gets or sets the test propery.
        /// </summary>
        /// <value>
        /// The test propery.
        /// </value>
        public string TestPropery { get; set; }

        /// <summary>
        /// Gets or Sets Chart Model        
        /// </summary>
        /// <value>The ChartModel Type</value>
        public ReportChartModel ChartModel { get; set; }

        /// <summary>
        /// Gets or Sets Settings Model 
        /// </summary>
        /// <value>The SettingsModel Type</value>
        public SettingsModel SettingsModel { get; set; }

        /// <summary>
        /// Gets or Sets Table Model 
        /// </summary>
        /// <value>The TableModel Type</value>
        public ReportTable ReportTable { get; set; }

        /// <summary>
        /// Gets or Sets ColumIds
        /// </summary>
        /// <value>The ColumIds Type</value>
        public List<ColumIds> ColumIds { get; set; }
    }
}