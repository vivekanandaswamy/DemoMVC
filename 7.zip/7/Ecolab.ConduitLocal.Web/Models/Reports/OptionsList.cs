﻿// -----------------------------------------------------------------------
// <copyright file="OptionsList.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The OptionsList class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Web Model for OptionsList
    /// </summary>
    public class OptionsList
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name for OptionsList.
        /// </value>
        public object Name { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier for OptionsList.
        /// </value>
        public object Id { get; set; }
    }
}