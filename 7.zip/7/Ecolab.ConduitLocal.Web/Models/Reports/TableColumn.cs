﻿// -----------------------------------------------------------------------
// <copyright file="TableColumn.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TableColumn </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class TableColumn
    {
        /// <summary>
        /// Gets or Sets HeaderName of the Column
        /// </summary>
        /// <value>Contains HeaderName of the Column</value>
        public string HeaderName { get; set; }

        /// <summary>
        /// Gets or Sets IsSortable 
        /// </summary>
        /// <value>Contains IsSortable value for Column </value>
        public bool IsSortable { get; set; }

        /// <summary>
        /// Gets or Sets ResKey 
        /// </summary>
        /// <value>Contains value for ResKey</value>
        public string ResKey { get; set; }

        /// <summary>
        /// Gets or Sets IsVisible
        /// </summary>
        /// <value>Contains the value for IsVisible</value>
        public bool IsVisible { get; set; }

        /// <summary>
        /// Gets or Sets ColumnId 
        /// </summary>
        /// <value>Contains ColumnId value. </value>
        public int ColumnId { get; set; }

        /// <summary>
        /// Gets or Sets SortDirection 
        /// </summary>
        /// <value>Contains SortDirection value</value>
        public string SortDirection { get; set; }

        /// <summary>
        /// Gets or Sets PageNumber 
        /// </summary>
        /// <value>Page Number value</value>
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or Sets Localized UOM 
        /// </summary>
        /// <value>The Localized UOM value</value>
        public string LocalizedUom { get; set; }

        /// <summary>
        /// Gets or Sets Precision
        /// </summary>
        /// <value>The Decimals to be shown</value>
        public int Precision { get; set; }

        /// <summary>
        /// Gets or Sets Table Column Hide 
        /// </summary>
        public bool IsHide { get; set; }
        /// <summary>
        /// Gets or Sets IsLinkable 
        /// </summary>
        /// <value>IsLinkable value</value>
        public bool IsLinkable { get; set; }
        /// <summary>
        /// Gets or Sets LinkedReportId 
        /// </summary>
        /// <value>LinkedReportId value</value>
        public int LinkedReportId { get; set; }
    }
}