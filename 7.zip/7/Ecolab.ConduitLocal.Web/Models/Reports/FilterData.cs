﻿// -----------------------------------------------------------------------
// <copyright file="FilterData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FilterData class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Web Model for FilterData
    /// </summary>
    public class FilterData
    {
        /// <summary>
        ///     Get or sets the Id
        /// </summary>
        /// <value> Id value</value>
        public int Id { get; set; }

        /// <summary>
        ///     Get or sets the Name
        /// </summary>
        /// <value> Name value</value>
        public string Name { get; set; }

        /// <summary>
        ///     Get or sets the FilterId
        /// </summary>
        /// <value> FilterId value</value>
        public int FilterId { get; set; }

        /// <summary>
        ///     Get or sets the FilterName
        /// </summary>
        /// <value> FilterName value</value>
        public string FilterName { get; set; }
    }
}