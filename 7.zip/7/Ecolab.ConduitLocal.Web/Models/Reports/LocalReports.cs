﻿// -----------------------------------------------------------------------
// <copyright file="LocalReports.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LocalReports class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    using System.Collections.Generic;

    /// <summary>
    ///     Wb Model for LocalReports
    /// </summary>
    public class LocalReports
    {
        /// <summary>
        /// Get or sets  ReportCategories
        /// </summary>
        /// <value>This Contains List of ReportCategories</value>
        public List<ReportCategoriesModel> ReportCategories { get; set; }

        /// <summary>
        /// Get or sets  ReportSubCategories
        /// </summary>
        /// <value>This Contains List of ReportSubCategories</value>
        public List<ReportSubCategoriesModel> ReportSubCategories { get; set; }

        /// <summary>
        /// Get or sets  Reports
        /// </summary>
        /// <value>This Contains List of Reports</value>
        public List<ReportLayoutModel> Reports { get; set; }
    }
}