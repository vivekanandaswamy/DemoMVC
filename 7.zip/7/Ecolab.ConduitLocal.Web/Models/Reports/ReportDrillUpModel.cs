﻿// -----------------------------------------------------------------------
// <copyright file="ReportDrillUpModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportDrillUpModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportDrillUpModel
    {
        /// <summary>
        /// Get or sets the DayWise
        /// </summary>
        /// <value> DayWise value</value>
        public bool IsDayWise { get; set; }

        /// <summary>
        /// Get or sets the WeekWise
        /// </summary>
        /// <value> WeekWise value</value>
        public bool IsWeekWise { get; set; }

        /// <summary>
        /// Get or sets the MonthWise
        /// </summary>
        /// <value> MonthWise value</value>
        public bool IsMonthWise { get; set; }

        /// <summary>
        /// Get or sets the QuarterWise
        /// </summary>
        /// <value> QuarterWise value</value>
        public bool IsQuarterWise { get; set; }

        /// <summary>
        /// Get or sets the IsYear
        /// </summary>
        /// <value> IsYear value</value>
        public bool IsYearWise { get; set; }

        /// <summary>
        ///     Gets or sets the value From Date
        /// </summary>
        /// <value>From Date value</value>
        public DateTime FromDate { get; set; }

        /// <summary>
        ///     Gets or sets the value To Date
        /// </summary>
        /// <value>From To value</value>
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Get or sets the ViewModeId
        /// </summary>
        /// <value> ViewModeId value</value>
        public int ViewModeId { get; set; }
        /// <summary>
        /// Gets or sets the options list.
        /// </summary>
        /// <value>
        /// The options list.
        /// </value>
        public List<OptionsList> OptionsList { get; set; }
        /// <summary>
        /// Gets or sets the current viewing.
        /// </summary>
        /// <value>
        /// The current viewing.
        /// </value>
        public List<string> CurrentViewing { get; set; }
        /// <summary>
        /// Gets or sets the selected option.
        /// </summary>
        /// <value>
        /// The selected option.
        /// </value>
        public string SelectedOption { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is first level.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is first level; otherwise, <c>false</c>.
        /// </value>
        public bool IsFirstLevel { get; set; }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>
        /// The selected item.
        /// </value>
        public string SelectedItem { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is drill down.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is drill down; otherwise, <c>false</c>.
        /// </value>
        public bool IsDrillDown { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int? ProductId { get; set; }

        /// <summary>
        /// Gets or sets the DrillDownId.
        /// </summary>
        /// <value>
        /// DrillDownId value .
        /// </value>
        public int DrillDownId { get; set; }   
    }
}