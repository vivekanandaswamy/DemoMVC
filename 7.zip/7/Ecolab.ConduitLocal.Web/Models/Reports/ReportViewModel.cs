﻿// -----------------------------------------------------------------------
// <copyright file="ReportViewModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportViewModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportViewModel
    {
        /// <summary>
        /// Get or set the ViewModeId
        /// </summary>
        /// <value>ViewModeId .</value>
        public int ViewModeId { get; set; }

        /// <summary>
        /// Get or set the ViewModeName
        /// </summary>
        /// <value>ViewModeName.</value>
        public string ViewModeName { get; set; }

        /// <summary>
        /// Get or set the IsSelected
        /// </summary>
        /// <value>IsSelected.</value>
        public bool IsSelected { get; set; }

        /// <summary>
        /// Get or Set the SubViewName
        /// </summary>
        /// <value> SubViewName value </value>
        public string SubViewName { get; set; }

        /// <summary>
        /// Get or Set the SubViewId
        /// </summary>
        /// <value> SubViewId value </value>
        public int SubViewId { get; set; }

        /// <summary>
        /// Get or Set the ChartType
        /// </summary>
        /// <value> ChartType value </value>
        public string ChartType { get; set; }
    }
}