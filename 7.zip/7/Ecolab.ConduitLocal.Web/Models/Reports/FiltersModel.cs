﻿// -----------------------------------------------------------------------
// <copyright file="FiltersModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FiltersModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class FiltersModel
    {
        public List<FilterModel> ReportFilters { get; set; }
    }
}