﻿// -----------------------------------------------------------------------
// <copyright file="ReportCategories.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportCategories </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     Wb Model for ReportCategories
    /// </summary>
    public class ReportCategories
    {
        /// <summary>
        ///     Get or sets ReportCategoryId
        /// </summary>
        /// <value>This Conatins Report CategoryId</value>
        public int ReportCategoryId { get; set; }

        /// <summary>
        ///     Get or sets Report CategoryName
        /// </summary>
        /// <value>This Conatins Report Category Name</value>
        public string CategoryName { get; set; }
    }
}