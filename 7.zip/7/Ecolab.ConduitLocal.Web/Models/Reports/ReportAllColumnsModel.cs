﻿// -----------------------------------------------------------------------
// <copyright file="ReportAllColumnsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportAllColumnsModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportAllColumnsModel
    {
        /// <summary>
        ///     Gets or sets the Id
        /// </summary>
        /// <value>Id value.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>Report column name.</value>
        public string ColumnName { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder
        /// </summary>
        /// <value>DisplayOrder value.</value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsSortable value.</value>
        public bool IsSortable { get; set; }

        /// <summary>
        ///     Gets or sets the ViewModeId
        /// </summary>
        /// <value>ViewModeId value.</value>
        public int ViewModeId { get; set; }

        /// <summary>
        ///     Gets or sets the SwitchModeId
        /// </summary>
        /// <value>SwitchModeId value.</value>
        public int SwitchModeId { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsVisible { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsChartDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the Localized UOM.
        /// </summary>
        /// <value>
        ///     The localized UOM.
        /// </value>
        public string LocalizedUom { get; set; }

        /// <summary>
        /// Gets or Sets Precision
        /// </summary>
        /// <value>The Decimals to be shown</value>
        public int Precision { get; set; }
        /// <summary>
        /// Gets or sets the name of the localized.
        /// </summary>
        /// <value>
        /// The name of the localized.
        /// </value>
        public string LocalizedName { get; set; }
        /// <summary>
        /// Gets or Sets IsLinkable 
        /// </summary>
        /// <value>IsLinkable value</value>
        public bool IsLinkable { get; set; }
        /// <summary>
        /// Gets or Sets LinkedReportId 
        /// </summary>
        /// <value>LinkedReportId value</value>
        public int LinkedReportId { get; set; }
    }
}