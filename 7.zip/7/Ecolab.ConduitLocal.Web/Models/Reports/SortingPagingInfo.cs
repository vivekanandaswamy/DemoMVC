﻿// -----------------------------------------------------------------------
// <copyright file="SortingPagingInfo.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SortingPagingInfo </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class SortingPagingInfo
    {
        /// <summary>
        /// Gets or Sets SortField Name
        /// </summary>
        /// <value>Contains SortField value</value>
        public string SortField { get; set; }

        /// <summary>
        /// Gets or Sets Sort Direction 
        /// </summary>
        /// <value>Contains SortDirection Value</value>
        public string SortDirection { get; set; }

        /// <summary>
        /// Gets or Sets Page Size for the Table
        /// </summary>
        /// <value>Contains PageSize value</value>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or Sets Page Count for the Table
        /// </summary>
        /// <value>Contains PageCount value</value>
        public int PageCount { get; set; }

        /// <summary>
        /// Gets or Sets CurrentPageIndex of the Table
        /// </summary>
        /// <value>Contains the CurrentPageIndex Value</value>
        public int CurrentPageIndex { get; set; }
    }
}