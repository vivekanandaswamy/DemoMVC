﻿// -----------------------------------------------------------------------
// <copyright file="ReportSubView.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSubView </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportSubView
    {
        /// <summary>
        /// Gets or Sets SubViewId value
        /// </summary>
        /// <value>Contains SubViewId value</value>
        public int SubViewId { get; set; }

        /// <summary>
        /// Gets or Sets DrilldownSubViewName value
        /// </summary>
        /// <value>Contains DrilldownSubViewName value</value>
        public string SubViewName { get; set; }

		/// <summary>
        /// Gets or Sets DrilldownSubViewId value
        /// </summary>
        /// <value>Contains DrilldownSubViewId value</value>
        public int DrilldownSubViewId { get; set; }

		/// <summary>
        /// Gets or Sets DrillupSubViewId value
        /// </summary>
        /// <value>Contains DrillupSubViewId value</value>
        public int DrillupSubViewId { get; set; }

        /// <summary>
        /// Gets or Sets IsLast value
        /// </summary>
        /// <value>Contains IsLast value</value>
        public bool IsLast { get; set; }

        /// <summary>
        /// Gets or sets the name of the localized.
        /// </summary>
        /// <value>
        /// The name of the localized.
        /// </value>
        public string LocalizedName { get; set; }
             
    }
}