﻿// -----------------------------------------------------------------------
// <copyright file="ReportRibbonOptionsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportRibbonOptionsModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportRibbonOptionsModel
    {
        /// <summary>
        /// Get or Set the IsChartDisplay
        /// </summary>
        /// <value> Is Chart Display value </value>
        public bool IsChartDisplay { get; set; }

        /// <summary>
        /// Get or Set the SwitchModeId
        /// </summary>
        /// <value> Switch ModeId value </value>
        public int SwitchModeId { get; set; }

        /// <summary>
        /// Get or Set the SwitchName
        /// </summary>
        /// <value>SwitchName value </value>
        public string SwitchName { get; set; }

        /// <summary>
        /// Get or Set the ColumnId
        /// </summary>
        /// <value> ColumnId value </value>
        public int ColumnId { get; set; }

        /// <summary>
        /// Get or Set the ColumnName
        /// </summary>
        /// <value> ColumnName value </value>
        public string ColumnName { get; set; }

        /// <summary>
        /// Get or Set the ReportFilterId
        /// </summary>
        /// <value> ReportFilterId value </value>
        public int ReportFilterId { get; set; }

        /// <summary>
        /// Get or Set the FilterName
        /// </summary>
        /// <value> FilterName value </value>
        public string FilterName { get; set; }

        /// <summary>
        /// Get or Set the DisplayOrder
        /// </summary>
        /// <value> DisplayOrder value </value>
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Get or Set the ViewModeId
        /// </summary>
        /// <value> ViewModeId value </value>
        public int ViewModeId { get; set; }

        /// <summary>
        /// Get or Set the ViewModeName
        /// </summary>
        /// <value> ViewModeName value </value>
        public string ViewModeName { get; set; }

        /// <summary>
        /// Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsVisible { get; set; }

        /// <summary>
        /// Get or Set the SubViewName
        /// </summary>
        /// <value> SubViewName value </value>
        public string SubViewName { get; set; }

        /// <summary>
        /// Get or Set the SubViewId
        /// </summary>
        /// <value> SubViewId value </value>
        public int SubViewId { get; set; }

        /// <summary>
        /// Get or Set the ChartType
        /// </summary>
        /// <value> ChartType value </value>
        public string ChartType { get; set; }

        /// <summary>
        /// Get or Set the IsDefault
        /// </summary>
        /// <value> IsDefault value </value>
        public bool IsDefault { get; set; }

        /// <summary>
        ///     Gets or Sets HasGroupBy
        /// </summary>
        /// <value>Has GeoupBy value</value>
        public bool HasGroupBy { get; set; }
    }
}