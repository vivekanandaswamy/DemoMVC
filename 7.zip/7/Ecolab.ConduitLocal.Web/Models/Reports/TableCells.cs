﻿// -----------------------------------------------------------------------
// <copyright file="TableCells.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TableCells </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class TableCells
    {
        /// <summary>
        /// Gets or Sets HeaderName for the Cell
        /// </summary>
        public string HeaderName { get; set; }

        /// <summary>
        /// Cell Value
        /// </summary>
        /// <value>Contains Cell Value</value>
        public string Value { get; set; }

        /// <summary>
        /// Cell Format
        /// </summary>
        /// <value>Contains Cell Format</value>
        public string Format { get; set; }

        /// <summary>
        /// Gets or Sets IsVisible
        /// </summary>
        /// <value>Contains IsVisible value</value>
        public bool IsVisible { get; set; }

        /// <summary>
        /// Gets or Sets ColumnId
        /// </summary>
        /// <value>Contains ColumnId value</value>
        public int ColumnId { get; set; }
        /// <summary>
        /// Gets or Sets IsLinkable 
        /// </summary>
        /// <value>IsLinkable value</value>
        public bool IsLinkable { get; set; }
        /// <summary>
        /// Gets or Sets LinkedReportId 
        /// </summary>
        /// <value>LinkedReportId value</value>
        public int LinkedReportId { get; set; }
        /// <summary>
        /// Gets or Sets LinkedValue 
        /// </summary>
        /// <value>LinkedValue value</value>
        public string LinkedValue { get; set; }
        /// <summary>
        /// Gets or Sets LinkedFromDate 
        /// </summary>
        /// <value>LinkedFromDate value</value>
        public DateTime LinkedFromDate { get; set; }
        /// <summary>
        /// Gets or Sets LinkedToDate 
        /// </summary>
        /// <value>LinkedToDate value</value>
        public DateTime LinkedToDate { get; set; }
        /// <summary>
        /// Gets or Sets LinkedId 
        /// </summary>
        /// <value>LinkedId value</value>
        public string LinkedId { get; set; }
    }
}