﻿// -----------------------------------------------------------------------
// <copyright file="ReportModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Model class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    /// <summary>
    ///     ReportModel Model
    /// </summary>
    public class ReportModel
    {
        public LocalReports ReportLayoutModel { get; set; }
        public RibbonDetailsModel RibbonDetailsModel { get; set; }
        public NavigationModel NavigationModelSettings { get; set; }
        public ReportTableAndChartModel ReportGridAndChartModel { get; set; }
        public ReportSettingsModel ReportSettingsModel { get; set; }
        public FiltersModel Filters { get; set; }
    }

}