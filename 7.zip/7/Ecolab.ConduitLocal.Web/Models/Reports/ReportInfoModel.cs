﻿// -----------------------------------------------------------------------
// <copyright file="ReportLayoutModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportLayoutModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Reports
{
    public class ReportLayoutModel
    {
        /// <summary>
        /// Get or Set the ReportCategoryId
        /// </summary>
        /// <value>Report Category Id</value>
        public int ReportCategoryId { get; set; }

        /// <summary>
        /// Get or Set the ReportCategoryName
        /// </summary>
        /// <value>Report Category Name</value>
        public string ReportCategoryName { get; set; }

        /// <summary>
        /// Get or Set the SubCategoryId
        /// </summary>
        /// <value>Report Sub Category Id</value>
        public int SubCategoryId { get; set; }

        /// <summary>
        /// Get or Set the SubCategoryName
        /// </summary>
        /// <value>Report Sub Category Name</value>
        public string SubCategoryName { get; set; }

        /// <summary>
        /// Get or Set the ReportId
        /// </summary>
        /// <value>parameter Report Id</value>
        public int ReportId { get; set; }

        /// <summary>
        /// Get or Set the ReportName
        /// </summary>
        /// <value>parameter Report Name</value>
        public string ReportName { get; set; }

        /// <summary>
        /// Get or Set the DisplayTopRecordsCount
        /// </summary>
        /// <value>DisplayTopRecordsCount value</value>
        public int DisplayTopRecordsCount { get; set; }

        /// <summary>
        /// Get or Set the ShowOthers
        /// </summary>
        /// <value>ShowOthers value</value>
        public bool ShowOthers { get; set; }

        /// <summary>
        /// Get or Set the ShowTotal
        /// </summary>
        /// <value>ShowTotal value</value>
        public bool ShowTotal { get; set; }

        /// <summary>
        /// Get or Set the ChartType
        /// </summary>
        /// <value>ChartType Name</value>
        public string ChartType { get; set; }

        /// <summary>
        /// Get or Set the isPaging
        /// </summary>
        /// <value>IsPaging value</value>
        public bool IsPaging { get; set; }

        /// <summary>
        /// Get or Set the PageSize
        /// </summary>
        /// <value>PageSize value</value>
        public int PageSize { get; set; }
    }
}