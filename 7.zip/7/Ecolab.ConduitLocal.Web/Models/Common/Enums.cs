﻿// -----------------------------------------------------------------------
// <copyright file="Enums.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Enums class </summary>

namespace Ecolab.ConduitLocal.Web.Models.Common
{
    /// <summary>
    ///     Class for Enums which can be used commonly.
    /// </summary>
    public class Enums
    {
        /// <summary>
        ///     Enum for State of the compartment
        /// </summary>
        public enum CompartmentState
        {
            Empty = 0,
            Processing = 1,
            Transferring = 2,
            Stopped = 3
        }
    }
}