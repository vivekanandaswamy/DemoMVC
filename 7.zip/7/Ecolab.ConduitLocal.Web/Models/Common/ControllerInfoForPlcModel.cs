﻿// -----------------------------------------------------------------------
// <copyright file="ControllerInfoForPlcModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Info For Plc Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Common
{
    /// <summary>
    ///     Entity class for ControllerInfoForPlcModel
    /// </summary>
    public class ControllerInfoForPlcModel
    {
        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value> controller id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value> controller name</value>
        public string TopicName { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type Name
        /// </summary>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Model Id
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Model Name
        /// </summary>
        public string ControllerModel { get; set; }

        /// <summary>
        ///     Gets or sets the OPC Server
        /// </summary>
        /// <value> The OPC Server</value>
        public string Value { get; set; }
    }
}