﻿// -----------------------------------------------------------------------
// <copyright file="PLCDiscrepancyModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PLC Discrepancy Model Model</summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Common
{
    public class PLCDiscrepancyModel
    {
        /// <summary>
        ///     Gets or sets Parent Entity 
        /// </summary>
        /// <value>The ParentEntity .</value>
        public int ParentEntity { get; set; }

        /// <summary>
        ///     Gets or sets Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int Entity { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Id
        /// </summary>
        /// <value>The ParentEntityId .</value>
        public int ParentEntityId { get; set; }

        /// <summary>
        ///     Gets or sets Entity Id
        /// </summary>
        /// <value>The EntityId .</value>
        public int EntityId { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Name
        /// </summary>
        /// <value>The ParentEntityName .</value>
        public string ParentEntityName { get; set; }

        /// <summary>
        ///     Gets or sets Entity Name
        /// </summary>
        /// <value>The EntityName.</value>
        public string EntityName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating Whether it is Central 
        /// </summary>
        /// <value>The IsCentral .</value>
        public bool IsCentral { get; set; }

        /// <summary>
        ///     Gets or sets Controller Id of the Entity
        /// </summary>
        /// <value>The ControllerId .</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets Controller number.
        /// </summary>
        /// <value>The ControllerNumber .</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets Controller number.
        /// </summary>
        /// <value>The ControllerNumber .</value>
        public int ControllerNumber { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating Whether it is an error from PLC 
        /// </summary>
        /// <value>The IsPLCError .</value>
        public bool IsPLCError { get; set; }

        /// <summary>
        ///     Gets or sets User Id
        /// </summary>
        /// <value>The UserId .</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets User Name
        /// </summary>
        /// <value>The UserName.</value>
        public string UserName { get; set; }

        /// <summary>
        ///     Gets or sets Id of User performing sync on entities 
        /// </summary>
        /// <value>The ParentEntity .</value>
        public int LastModifiedUserId { get; set; }
        /// <summary>
        ///     Gets or sets the washer group type
        /// </summary>
        /// <value>The Washer group type</value>
        public byte WasherGroupType { get; set; }
    }
}