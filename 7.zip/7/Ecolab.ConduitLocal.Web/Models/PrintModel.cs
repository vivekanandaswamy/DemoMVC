﻿// -----------------------------------------------------------------------
// <copyright file="PrintModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Print Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Class PrintModel.
    /// </summary>
    public class PrintModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the PageTitle.
        /// </summary>
        /// <value>PageTitle. </value>
        public string PageTitle { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId.
        /// </summary>
        /// <value>RegionId. </value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value>WasherGroupId. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the value Storage Tank Id
        /// </summary>
        /// <value>The Parameter Storage Tank Id</value>
        public int StorageTankId { get; set; }

        /// <summary>
        ///     Gets or sets the value Washer id
        /// </summary>
        /// <value>The Parameter Washer id</value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the value Controller Id
        /// </summary>
        /// <value>The Parameter Controller Id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the value Machine Number
        /// </summary>
        /// <value>The Parameter Machine Number</value>
        public int MachineNumber { get; set; }

        /// <summary>
        ///     Gets or sets the value Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the value Controller Model Id
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the value Number Of compartments
        /// </summary>
        public int NumberOfCompartments { get; set; }

        /// <summary>
        ///     Gets or sets the value Program Setup Id
        /// </summary>
        public int ProgramSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the value Compartment Number
        /// </summary>
        public int CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the value Dosing Setup Id
        /// </summary>
        /// <value>Dosing Setup Id integer</value>
        public int DosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the value Tab Id
        /// </summary>
        /// <value>Tab Id</value>
        public int TabId { get; set; }
        
        /// <summary>
        ///     Gets or sets the value Tab Id
        /// </summary>
        /// <value>Tab Id</value>
        public int WasherGroupTypeId { get; set; }
        
    }
}