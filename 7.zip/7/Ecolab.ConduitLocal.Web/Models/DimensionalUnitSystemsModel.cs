﻿// -----------------------------------------------------------------------
// <copyright file="DimensionalUnitSystemsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DimensionalUnitSystemsModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model for DimensionalUnitSystems
    /// </summary>
    public class DimensionalUnitSystemsModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets Unit System Id
        /// </summary>
        /// <value>Unit System Id</value>
        public int UnitSystemId { get; set; }

        /// <summary>
        ///     Gets or sets UnitSystem
        /// </summary>
        /// <value>Unit System</value>
        public string UnitSystem { get; set; }

        #endregion
    }
}