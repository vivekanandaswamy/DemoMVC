﻿// -----------------------------------------------------------------------
// <copyright file="ControllerModelModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerModelModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup
{
    /// <summary>
    ///     class ControllerModelModel
    /// </summary>
    public class ControllerModelModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets and sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///     Gets and sets the Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///     Gets and sets the RegionId
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets and sets the Version
        /// </summary>
        public int Version { get; set; }

        /// <summary>
        ///  Gets or sets the Display Order
        /// </summary>
        /// /// <value>The Parameter Display Order</value>
        public int DisplayOrder { get; set; }

        #endregion
    }
}