﻿// -----------------------------------------------------------------------
// <copyright file="FieldSourceModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FieldSource object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup
{
    /// <summary>
    ///     class FieldSourceModel
    /// </summary>
    public class FieldSourceModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the data source id.
        /// </summary>
        /// <value>The data source id.</value>
        public int DataSourceId { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public string Value { get; set; }

        #endregion
    }
}