﻿// -----------------------------------------------------------------------
// <copyright file="MetaDataModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MetaData object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup
{
    using System.Collections.Generic;

    /// <summary>
    /// Class MetaDataModel
    /// </summary>
    public class MetaDataModel
    {
        /// <summary>
        /// Gets or sets the Field Group Id
        /// </summary>
        /// <value>
        /// The field group identifier.
        /// </value>
        public int FieldGroupId { get; set; }

        /// <summary>
        /// Gets or sets the Field Group Type
        /// </summary>
        /// <value>
        /// The type of the field group.
        /// </value>
        public string FieldGroupType { get; set; }

        /// <summary>
        /// Gets or sets the Field Group Info
        /// </summary>
        /// <value>
        /// The field group information.
        /// </value>
        public List<ControllerSetupMetaDataModel> FieldGroupInfo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has pumps.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance has pumps; otherwise, <c>false</c>.
        /// </value>
        public bool HasPumps { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message for Metadata.
        /// </value>
        public string message { get; set; }
    }
}