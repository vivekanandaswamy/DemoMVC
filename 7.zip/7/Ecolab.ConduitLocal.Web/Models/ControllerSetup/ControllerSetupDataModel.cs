﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupDataModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerSetupData object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup
{
    using System.Collections.Generic;
    using Dcs.Entities;

    /// <summary>
    ///     class ControllerSetupDataModel
    /// </summary>
    public class ControllerSetupDataModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Tab Id
        /// </summary>
        public int TabId { get; set; }

        /// <summary>
        ///     Gets or sets the Ecolab Account Number
        /// </summary>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Id
        /// </summary>
        public int FieldGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Id
        /// </summary>
        public int FieldId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Name
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public string FieldTagValue { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public string FieldTagAddress { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public List<OpcTag> PlcTagModelTags { get; set; }

        /// <summary>
        ///     Gets or sets the role of the logged user.
        /// </summary>
        public int Role { get; set; }

        /// <summary>
        ///  Gets or sets the OverridePlcValues.
        /// </summary>
        public bool OverridePlcValues { get; set; }

        #endregion
    }
}