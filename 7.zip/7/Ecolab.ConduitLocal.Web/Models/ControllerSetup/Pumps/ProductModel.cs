﻿// -----------------------------------------------------------------------
// <copyright file="ProductModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Model object for ProductModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class ProductModel.
    /// </summary>
    public class ProductModel
    {
        /// <summary>
        ///     Gets or sets the Product Id.
        /// </summary>
        /// <value>Product Id.</value>
        public int Id { get; set; }

        /// <summary>
        /// PumpsProductId
        /// </summary>
        public int PumpsProductId { get; set; }

        /// <summary>
        /// ControllerId
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        /// ChemicalNumber
        /// </summary>
        public int ChemicalNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name.
        /// </summary>
        /// <value>Product Name.</value>
        public string Name { get; set; }

        /// <summary>
        /// LowLevelAlarm
        /// </summary>
        public bool LowLevelAlarm { get; set; }

        /// <summary>
        /// WeightControlledDosage
        /// </summary>
        public bool WeightControlledDosage { get; set; }

        /// <summary>
        /// ControllerEquipmentSetupId
        /// </summary>
        public int ControllerEquipmentSetupId { get; set; }
    }
}