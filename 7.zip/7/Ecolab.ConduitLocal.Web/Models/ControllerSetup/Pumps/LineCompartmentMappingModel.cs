﻿// -----------------------------------------------------------------------
// <copyright file="LineCompartmentMappingModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Line Compartment Mapping Model object</summary>
// -----------------------------------------------------------------------

using System;

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class Line Compartment Mapping Model.
    /// </summary>
    public class LineCompartmentMappingModel
    {
        /// <summary>
        ///     Gets or sets the TunnelCompartmentEquipmentValveMappingId
        /// </summary>
        /// <value>The Tunnel Compartment Equipment Valve Mapping Id</value>
        public int TunnelCompartmentEquipmentValveMappingId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerEquipmentId
        /// </summary>
        /// <value>The Controller Equipment Id</value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerID
        /// </summary>
        /// <value>The Controller ID</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineInternalId
        /// </summary>
        /// <value>The Machine Internal Id</value>
        public int TunnelNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LineNumber
        /// </summary>
        /// <value>The Line Number</value>
        public byte LineNumber { get; set; }

        /// <summary>
        ///     Gets or sets the DosingPointNumber
        /// </summary>
        /// <value>The Dosing Point Number</value>
        public byte DosingPointNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerEquipmentValveId
        /// </summary>
        /// <value>The Controller Equipment Valve Id</value>
        public byte ValveNumber { get; set; }

        /// <summary>
        ///     Gets or sets the TunnelCompartmentId
        /// </summary>
        /// <value>The Tunnel Compartment Id</value>
        public byte CompartmentNumber { get; set; }

        /// <summary>
        /// Gets or Sets the DirectDosingFlag
        /// </summary>
        /// <value>The Direct Dosing Flag</value>
        public bool DirectDosingFlag { get; set; }

        /// <summary>
        /// TunnelCompartmentNumber
        /// </summary>
        public int TunnelCompartmentNumber { get; set; }

        /// <summary>
        /// WasherExtractorNumber
        /// </summary>
        public int WasherNumber { get; set; }

        /// <summary>
        /// ControllerEquipmentSetupId
        /// </summary>
        public Int16 ControllerEquipmentSetupId { get; set; }

        /// <summary>
        /// ControllerEquipmentTypeId
        /// </summary>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedDate
        /// </summary>
        /// <value>The Last Modified Date</value>
        public DateTime LastModifiedDate { get; set; }
    }
}