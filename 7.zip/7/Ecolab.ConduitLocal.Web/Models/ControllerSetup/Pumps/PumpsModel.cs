﻿// -----------------------------------------------------------------------
// <copyright file="PumpsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Pumps Model object for PumpsModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using Dcs.Entities;
    using Ecolab.ConduitLocal.Web.Models.WasherGroup;
    using Ecolab.Models.Common;
    /// <summary>
    /// Pumps Model Class
    /// </summary>
    public class PumpsModel
    {
        /// <summary>
        /// Gets or sets the controller equipment Setup identifier.
        /// </summary>
        /// <value>
        /// The controller equipment Setup identifier.
        /// </value>
        public int ControllerEquipmentSetupId { get; set; }

        /// <summary>
        /// Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>
        /// The controller equipment identifier.
        /// </value>
        public int ControllerEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>
        /// The controller equipment type identifier.
        /// </value>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int? ProductId { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether it will Override Plc Values or not.
        /// </summary>
        /// <value>
        /// <c>true</c> if [product name override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductNameOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the pump calibration.
        /// </summary>
        /// <value>
        /// The pump calibration.
        /// </value>
        public decimal PumpCalibration { get; set; }

        /// <summary>
        /// Gets or sets the pump calibration.
        /// </summary>
        /// <value>
        /// The pump calibration.
        /// </value>
        public string PumpCalibrationAsString { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [flow meter switch flag].
        /// </summary>
        /// <value>
        ///   <c>null/true/false</c>.
        /// </value>
        public bool? FlowMeterSwitchFlag { get; set; }

        /// <summary>
        /// Gets or sets the maximum dosing time.
        /// </summary>
        /// <value>
        /// The maximum dosing time.
        /// </value>
        public Int16? MaximumDosingTime { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether it will Override Plc Values
        /// </summary>
        /// <value>
        /// The MaximumDosingTime.
        /// </value>
        public bool MaximumDosingTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the FactorFM_B_FM.
        /// </summary>
        /// <value>
        /// The FactorFM_B_FM.
        /// </value>
        public short? FactorFM_B_FM { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether it will Override Plc Values or not.
        /// </summary>
        /// <value>
        /// The MaximumDosingTime.
        /// </value>
        public bool FactorFM_B_FMOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow switch time out.
        /// </summary>
        /// <value>
        /// The flow switch time out.
        /// </value>
        public decimal? FlowSwitchTimeOut { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether it will Override Plc Values or not.
        /// </summary>
        /// <value>
        /// The flow switch time out.
        /// </value>
        public bool FlowSwitchTimeOutOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the eco lab account number.
        /// </summary>
        /// <value>
        /// The eco lab account number.
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the controller identifier.
        /// </summary>
        /// <value>
        /// The controller identifier.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the ControllerModelId identifier.
        /// </summary>
        /// <value>
        /// The ControllerModelId identifier.
        /// </value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the controller name.
        /// </summary>
        /// <value>The controller name.</value>
        public string ControllerTopicName { get; set; }

        /// <summary>
        /// Gets or sets the controller Type Id
        /// </summary>
        /// <value>
        /// The controller type id
        /// </value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets the Lfs Chemical Name
        /// </summary>
        /// <value>
        /// The Lfs Chemical Name
        /// </value>
        public string LfsChemicalName { get; set; }

        /// <summary>
        /// Gets or sets the K-Factor
        /// </summary>
        /// <value>
        /// The K-Factor value
        /// </value>
        public decimal KFactor { get; set; }

        /// <summary>
        /// Gets or sets the K-Factor
        /// </summary>
        /// <value>
        /// The K-Factor value
        /// </value>
        public string KFactorAsString { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Tunnel hold having a value or not.
        /// </summary>
        /// <value>
        /// The Tunnel hold value
        /// </value>
        public bool TunnelHold { get; set; }

        /// <summary>
        /// Gets or sets Flow Detector Type
        /// </summary>
        /// <value>
        /// The Flow Detector Type
        /// </value>
        public int FlowDetectorType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Flow Switch alarm is sets or not.
        /// </summary>
        /// <value>
        /// The Flow Switch alarm value
        /// </value>
        public bool FlowSwitchAlarm { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Flow Meter Alarm is sets or not.
        /// </summary>
        /// <value>
        /// The flow meter alarm
        /// </value>
        public bool FlowMeterAlarm { get; set; }

        /// <summary>
        /// Gets or sets the Flow Meter Type
        /// </summary>
        /// <value>
        /// The Flow Meter Type
        /// </value>
        public int FlowMeterType { get; set; }

        /// <summary>
        /// Gets or sets the Flow Alarm Delay Time
        /// </summary>
        /// <value>
        /// The Flow Alarm Delay Time in seconds
        /// </value>
        public decimal FlowAlarmDelay { get; set; }

        /// <summary>
        /// Gets or sets the Flow Meter Pump Delay Time
        /// </summary>
        /// <value>
        /// The Flow Meter Pump Delay Time in seconds
        /// </value>
        public decimal FlowMeterPumpDelay { get; set; }

        /// <summary>
        /// Gets or sets the Flow Meter Alarm Delay Time
        /// </summary>
        /// <value>
        /// The Flow Meter Alarm Delay Time in seconds
        /// </value>
        public decimal FlowMeterAlarmDelay { get; set; }

        /// <summary>
        /// Gets or sets the Lfs Chemical Name Tag
        /// </summary>
        /// <value>
        /// The Lfs Chemical Name Tag
        /// </value>
        public string LfsChemicalNameTag { get; set; }

        /// <summary>
        /// Gets or sets the K-Factor Tag
        /// </summary>
        /// <value>
        /// The K-Factor Tag
        /// </value>
        public string KfactorTag { get; set; }

        /// <summary>
        /// Gets or sets the Calibration Tag
        /// </summary>
        /// <value>
        /// The Calibration Tag
        /// </value>
        public string CalibrationTag { get; set; }

        /// <summary>
        /// Gets or sets the ControllerEquipmentTypeModelId
        /// </summary>
        /// <value>
        /// The Controller Equipment Type Model Id
        /// </value>
        public int ControllerEquipmentTypeModelId { get; set; }

        /// <summary>
        /// Gets or sets the ConventionalWasherGroupConnection
        /// </summary>
        /// <value>
        /// The Conventional Washer Group Connection
        /// </value>
        public bool ConventionalWasherGroupConnection { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether ConventionalWasherGroupConnection Override values or not.
        /// </summary>
        /// <value>
        /// The Conventional Washer Group Connection Override value
        /// </value>
        public bool ConventionalWgConnOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the AxillaryPumpCalibration
        /// </summary>
        /// <value>
        /// The Axillary Pump Calibration
        /// </value>
        public short AxillaryPumpCalibration { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [axillary pump calibration override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool AxillaryPumpCalibrationOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the FlowmeterSwitchActivated
        /// </summary>
        /// <value>
        /// The Flowmeter Switch Activated
        /// </value>
        public bool FlowmeterSwitchActivated { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flowmeter switch activated override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowmeterSwitchActivatedOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the FlushWhileDosing
        /// </summary>
        /// <value>
        /// The Flush While Dosing
        /// </value>
        public bool FlushWhileDosing { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flush while dosing override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlushWhileDosingOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the WeightControlledDosage
        /// </summary>
        /// <value>
        /// The Weight Controlled Dosage
        /// </value>
        public bool WeightControlledDosage { get; set; }
        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [weight controlled dosage override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool WeightControlledDosageOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the EquipmentDoseAlone
        /// </summary>
        /// <value>
        /// The Equipment Dose Alone
        /// </value>
        public bool EquipmentDoseAlone { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [equipment dose alone override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool EquipmentDoseAloneOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the LowLevelAlarm
        /// </summary>
        /// <value>
        /// The Low Level Alarm
        /// </value>
        public bool LowLevelAlarm { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [low level alarm override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool LowLevelAlarmOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the LeakageAlarm
        /// </summary>
        /// <value>
        /// The Leakage Alarm
        /// </value>
        public bool LeakageAlarm { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [leakage alarm override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool LeakageAlarmOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the FlushTime
        /// </summary>
        /// <value>
        /// The Flush Time
        /// </value>
        public short FlushTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flush time override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlushTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the PumpingTime
        /// </summary>
        /// <value>
        /// The Pumping Time
        /// </value>
        public short PumpingTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [pumping time override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool PumpingTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the PreFlushTime
        /// </summary>
        /// <value>
        /// The Pre Flush Time
        /// </value>
        public short PreFlushTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [pre flush time override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool PreFlushTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the NightFlushPauseTime
        /// </summary>
        /// <value>
        /// The Night Flush Pause Time
        /// </value>
        public short NightFlushPauseTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [night flush pause time override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool NightFlushPauseTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the NightFlushTime
        /// </summary>
        /// <value>
        /// The Night Flush Time
        /// </value>
        public short NightFlushTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [night flush time override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool NightFlushTimeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the AcceptedDeviation
        /// </summary>
        /// <value>
        /// The Accepted Deviation
        /// </value>
        public short AcceptedDeviation { get; set; }

        /// <summary>
        /// Gets or Sets the LineNumber
        /// </summary>
        /// <value>
        /// The line number.
        /// </value>
        public byte LineNumber { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [line number override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool LineNumberOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the DirectDosingFlag
        /// </summary>
        /// <value>
        /// The Direct Dosing Flag
        /// </value>
        public bool DirectDosingFlag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [direct dosing flag override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool DirectDosingFlagOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the DirectDosingMachineInternalId
        /// </summary>
        /// <value>
        /// The Direct Dosing Machine Internal Id
        /// </value>
        public int DirectDosingMachineInternalId { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [direct dosing machine internal identifier override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool DirectDosingMachineInternalIdOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the DirectDosingTunnelCompartmentId
        /// </summary>
        /// <value>
        /// The Direct Dosing Tunnel Compartment Id
        /// </value>
        public int DirectDosingTunnelCompartmentId { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [direct dosing tunnel compartment identifier override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool DirectDosingTunnelCompartmentIdOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets Washer Group Number
        /// </summary>
        /// <value>
        /// The washer group number.
        /// </value>
        public int WasherGroupNumber { get; set; }

        /// <summary>
        /// Gets or sets Washer Group TypeId
        /// </summary>
        /// <value>
        /// The washer group type identifier.
        /// </value>
        public int WasherGroupTypeId { get; set; }

        /// <summary>
        ///  Gets or sets No Of Compartments
        /// </summary>
        /// <value>
        /// The no of compartments.
        /// </value>
        public int NoOfCompartments { get; set; }

        /// <summary>
        ///  Gets or sets flush Valve Number
        /// </summary>
        /// <value>
        /// The flush valve number.
        /// </value>
        public short? FlushValveNumber { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flush valve number override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlushValveNumberOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets calibration Conduct SS_Tank
        /// </summary>
        /// <value>
        /// The calibration conduct s s_ tank.
        /// </value>
        public Decimal? CalibrationConductSS_Tank { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [calibration conduct s s_ tank override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool CalibrationConductSS_TankOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets BackFlowControl
        /// </summary>
        /// <value>
        ///   <c>true</c> if [back flow control]; otherwise, <c>false</c>.
        /// </value>
        public bool BackFlowControl { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [back flow control override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool BackFlowControlOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets AcceptedDeviationRingLine
        /// </summary>
        /// <value>
        /// The accepted deviation ring line.
        /// </value>
        public short? AcceptedDeviationRingLine { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [accepted deviation ring line override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool AcceptedDeviationRingLineOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets UsePumpOfGroup1ForTunnel
        /// </summary>
        /// <value>
        /// <c>true</c> if [use pump of group1 for tunnel]; otherwise, <c>false</c>.
        /// </value>
        public bool UsePumpOfGroup1ForTunnel { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [use pump of group1 for tunnel override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool UsePumpOfGroup1ForTunnelOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets pH Sensor Enabled
        /// </summary>
        /// <value>
        ///   <c>true</c> if [p h sensor enabled]; otherwise, <c>false</c>.
        /// </value>
        public bool pHSensorEnabled { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [p h sensor enabled override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool pHSensorEnabledOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets Concentration
        /// </summary>
        /// <value>
        /// The concentration.
        /// </value>
        public int Concentration { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [concentration override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool ConcentrationOverridePlcValues { get; set; }

        /// <summary>
        ///  Gets or sets StockSolutionDeadEnd
        /// </summary>
        /// <value>
        /// <c>true</c> if [stock solution dead end]; otherwise, <c>false</c>.
        /// </value>
        public bool StockSolutionDeadEnd { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [stock solution dead end override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool StockSolutionDeadEndOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or Sets the LineCompartmentMappings
        /// </summary>
        /// <value>
        /// List of LineCompartmentMappingModel
        /// </value>
        public List<LineCompartmentMappingModel> LineCompartmentMappings { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        ///   <c>true</c> if [override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool OverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the PLC Tags
        /// </summary>
        /// <value>
        /// The PLC tag values.
        /// </value>
        public List<OpcTag> PlcTags { get; set; }

        /// <summary>
        /// Gets or sets the LastSyncTime
        /// </summary>
        /// <value>
        /// Last Sync Time
        /// </value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>
        /// LastModifiedTimeStampDryerGroup
        /// </value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [LFS override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool LfsOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [k factor override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool KFactorOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [calibration override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool CalibrationOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow detector type tag.
        /// </summary>
        /// <value>
        /// The flow detector type tag.
        /// </value>
        public string FlowDetectorTypeTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow detector type override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowDetectorTypeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow switch alarm tag.
        /// </summary>
        /// <value>
        /// The flow switch alarm tag.
        /// </value>
        public string FlowSwitchAlarmTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow switch alarm override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowSwitchAlarmOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow meter alarm tag.
        /// </summary>
        /// <value>
        /// The flow meter alarm tag.
        /// </value>
        public string FlowMeterAlarmTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow meter alarm override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowMeterAlarmOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow meter type tag.
        /// </summary>
        /// <value>
        /// The flow meter type tag.
        /// </value>
        public string FlowMeterTypeTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow meter type override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowMeterTypeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow alarm delay tag.
        /// </summary>
        /// <value>
        /// The flow alarm delay tag.
        /// </value>
        public string FlowAlarmDelayTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow alarm delay override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowAlarmDelayOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow meter pump delay tag.
        /// </summary>
        /// <value>
        /// The flow meter pump delay tag.
        /// </value>
        public string FlowMeterPumpDelayTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow meter pump delay override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowMeterPumpDelayOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the flow meter alarm delay tag.
        /// </summary>
        /// <value>
        /// The flow meter alarm delay tag.
        /// </value>
        public string FlowMeterAlarmDelayTag { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [flow meter alarm delay override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool FlowMeterAlarmDelayOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the dispenser injection details list.
        /// </summary>
        /// <value>
        /// The dispenser injection details list.
        /// </value>
        public List<InjectionDetails> DispenserInjectionDetailsList { get; set; }

        /// <summary>
        /// Gets or sets the envision injection details list.
        /// </summary>
        /// <value>
        /// The envision injection details list.
        /// </value>
        public List<InjectionDetails> EnvisionInjectionDetailsList { get; set; }

        /// <summary>
        /// Gets or sets the HTTP status code.
        /// </summary>
        /// <value>
        /// The HTTP status code.
        /// </value>
        public int HttpStatusCode { get; set; }

        /// <summary>
        /// Gets or sets the eorror.
        /// </summary>
        /// <value>
        /// The eorror Value.
        /// </value>
        public String Eorror { get; set; }

        /// <summary>
        /// Gets or sets the eorror list.
        /// </summary>
        /// <value>
        /// The eorror list.
        /// </value>
        public Dictionary<string, object> EorrorList { get; set; }

        /// <summary>
        /// Gets or sets Module Tags
        /// </summary>
        /// <value>
        /// The module tags.
        /// </value>
        public List<ModuleTagsModel> ModuleTags { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is inline edit.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is inline edit; otherwise, <c>false</c>.
        /// </value>
        public bool IsInlineEdit { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// The tunnel compartment override PLC values.
        /// </value>
        public string TunnelCompartmentOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets the Override Plc Values
        /// </summary>
        /// <value>
        /// <c>true</c> if [me type override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool METypeOverridePlcValues { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [valve output as tom].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [valve output as tom]; otherwise, <c>false</c>.
        /// </value>
        public bool ValveOutputAsTom { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [valve output as tom override PLC values].
        /// </summary>
        /// <value>
        /// <c>true</c> if [valve output as tom override PLC values]; otherwise, <c>false</c>.
        /// </value>
        public bool ValveOutputAsTomOverridePLCValues { get; set; }

    }
}