﻿// -----------------------------------------------------------------------
// <copyright file="SetupDosingLineModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SetupDosingLineModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Class for Setup Dosing Line Model
    /// </summary>
    public class SetupDosingLineModel
    {
        /// <summary>
        /// DosingLineMode
        /// </summary>
        public int DosingLineMode { get; set; }

        /// <summary>
        /// EnableAuxiliary
        /// </summary>
        public int EnableAuxiliary { get; set; }
    }
}