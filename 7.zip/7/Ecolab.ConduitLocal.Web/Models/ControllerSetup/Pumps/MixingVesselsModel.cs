﻿// -----------------------------------------------------------------------
// <copyright file="MixingVesselsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Model object for MixingVesselsModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    public class MixingVesselsModel
    {
        /// <summary>
        ///     Gets or sets the MixingVessels Id.
        /// </summary>
        /// <value>MixingVesselsId.</value>
        public int MixingVesselsId { get; set; }

        /// <summary>
        /// EcoLabAccountNumber
        /// </summary>
        public string EcoLabAccountNumber { get; set; }

        /// <summary>
        /// ControllerId
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        /// Minimum Level
        /// </summary>
        public int MinimumLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Flush Time.
        /// </summary>
        /// <value>Flush Time.</value>
        public short FlushTime { get; set; }

        /// <summary>
        /// PumpingTime
        /// </summary>
        public short PumpingTime { get; set; }

        /// <summary>
        /// MaxTimeWaterValve
        /// </summary>
        public int MaxTimeWaterValve { get; set; }

        /// <summary>
        /// MaxEmtyingTime
        /// </summary>
        public int MaxEmtyingTime { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration Scale.
        /// </summary>
        /// <value>Calibration Scale.</value>
        public int CalibrationScale { get; set; }

        /// <summary>
        /// Maximum Vessel Capacity
        /// </summary>
        public int MaximumVesselCapacity { get; set; }

        /// <summary>
        /// Weight Cell
        /// </summary>
        public bool WeightCell { get; set; }

        /// <summary>
        /// Direct Dose
        /// </summary>
        public bool DirectDose { get; set; }

        /// <summary>
        /// MixingVessel Number
        /// </summary>
        public int MixingVesselNumber { get; set; }
    }
}