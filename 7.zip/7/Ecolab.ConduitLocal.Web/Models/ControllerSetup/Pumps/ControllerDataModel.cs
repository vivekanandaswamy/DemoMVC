﻿// -----------------------------------------------------------------------
// <copyright file="ControllerDataModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Data Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class Controller Data Model.
    /// </summary>
    public class ControllerDataModel
    {
        /// <summary>
        /// Gets or Sets the Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// gets or sets the label
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// Gets or Sets the Value
        /// </summary>
        public int Value { get; set; }
    }
}