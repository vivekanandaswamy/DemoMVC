﻿// -----------------------------------------------------------------------
// <copyright file="ControllerModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.ControllerSetup
{
    using System;

    /// <summary>
    ///     class ControllerModel
    /// </summary>
    public class ControllerModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        /// <value>The Parameter Controller Id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value>The Parameter Controller model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Name
        /// </summary>
        /// <value>The Parameter Controller Model Name</value>
        public string ControllerModelName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Name
        /// </summary>
        /// <value>The Parameter Controller Name</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Number
        /// </summary>
        /// <value>The Parameter Controller Number</value>
        public int ControllerNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type
        /// </summary>
        /// <value>The Parameter Controller Type</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Version Id
        /// </summary>
        /// <value>The Parameter Controller Version Id</value>
        public int ControllerVersionId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Version
        /// </summary>
        /// <value>The Parameter Controller Version</value>
        public string ControllerVersion { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Name
        /// </summary>
        /// <value>The Parameter Install Date</value>
        public DateTime InstallDate { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Install Date as string form
        /// </summary>
        /// <value>The Parameter Install Date as String</value>
        public string InstallDateAsString { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Topic Name
        /// </summary>
        /// <value>Topic Name</value>
        public string TopicName { get; set; }
        /// <summary>
        /// WasherExtractorCount
        /// </summary>
        public byte WasherExtractorCount { get; set; }
        /// <summary>
        /// MaxTunnelCount
        /// </summary>
        public byte MaxTunnelCount { get; set; }

        #endregion
    }
}