﻿// -----------------------------------------------------------------------
// <copyright file="PlcTagModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PLC Tag Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     PLC Tag model class
    /// </summary>
    public class PlcTagModel
    {
        /// <summary>
        ///     Gets or Sets the PLC Tag name
        /// </summary>
        public string TagName { get; set; }

        /// <summary>
        ///     Gets or Sets the PLC Tag Value
        /// </summary>
        public decimal TagValue { get; set; }

        /// <summary>
        ///     Gets or Sets the PLC Tag type
        /// </summary>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or Sets the PLC Tag validation status
        /// </summary>
        public bool IsValidTag { get; set; }

        /// <summary>
        ///     Gets or Sets the Validation exception code
        /// </summary>
        public string ExceptionCode { get; set; }

        /// <summary>
        ///     Gets or Sets the Time stamp of PLC tag
        /// </summary>
        public DateTime TimeStamp { get; set; }
    }
}