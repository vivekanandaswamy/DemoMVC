﻿// -----------------------------------------------------------------------
// <copyright file="ProductModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.StorageTanks
{
    public class ProductModel
    {
        /// <summary>
        ///     Gets or sets the Product Id.
        /// </summary>
        /// <value> Product Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name.
        /// </summary>
        /// <value> Product Name. </value>
        public string Name { get; set; }
    }
}