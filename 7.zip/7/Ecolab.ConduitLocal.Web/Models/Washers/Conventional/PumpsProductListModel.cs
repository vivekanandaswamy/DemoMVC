﻿// <copyright file="PumpsProductListModel.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Pumps Product List</summary>
// ***********************************************************************

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    /// <summary>
    ///     Class PumpsProductList.
    /// </summary>
    public class PumpsProductListModel
    {
        /// <summary>
        ///     Gets or sets the controller equipment setup identifier.
        /// </summary>
        /// <value>The controller equipment setup identifier.</value>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public byte ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller equipment setup identifier.
        /// </summary>
        /// <value>The name of the controller equipment setup identifier.</value>
        public string ControllerEquipmentSetupIdName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }
    }
}