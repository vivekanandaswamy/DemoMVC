﻿// -----------------------------------------------------------------------
// <copyright file="WasherModeListModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModeList Model object for WasherMode List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    /// <summary>
    ///     Class WasherModeListModel.
    /// </summary>
    public class WasherModeListModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name value.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the ResourceKey.
        /// </summary>
        /// <value>The Parameter Resource Key.</value>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModeNumber.
        /// </summary>
        /// <value>The Parameter WasherModeNumber.</value>
        public string WasherModeNumber { get; set; }
    }
}