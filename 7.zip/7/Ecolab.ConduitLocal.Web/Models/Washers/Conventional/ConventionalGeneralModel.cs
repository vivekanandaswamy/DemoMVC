﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneralModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel General object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using Dcs.Entities;

    /// <summary>
    /// Class ConventionalGeneralModel.
    /// </summary>
    /// <seealso cref="Ecolab.ConduitLocal.Web.Models.BaseViewModel" />
    public class ConventionalGeneralModel : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name value.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the modelName.
        /// </summary>
        /// <value>
        /// The modelName.
        /// </value>
        public string ModelName { get; set; }

        /// <summary>
        /// Gets or sets the sizeId.
        /// </summary>
        /// <value>
        /// The Conventional General Model size Id.
        /// </value>
        public int SizeId { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>
        /// The size value.
        /// </value>
        public string Size { get; set; }

        /// <summary>
        /// Gets or sets the controller.
        /// </summary>
        /// <value>
        /// The Conventional General Model controller.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the name of the controller.
        /// </summary>
        /// <value>
        /// The name of the controller.
        /// </value>
        public string ControllerName { get; set; }

        /// <summary>
        /// Gets or sets the WasherModeId.
        /// </summary>
        /// <value>
        /// The Washer Mode Id.
        /// </value>
        public Int16 WasherModeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the WasherMode.
        /// </summary>
        /// <value>
        /// The name of the WasherMode.
        /// </value>
        public string WasherModeName { get; set; }

        /// <summary>
        /// Gets or sets the WasherModelId.
        /// </summary>
        /// <value>
        /// The Washer Model Id.
        /// </value>
        public Int16 WasherModelId { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer model.
        /// </summary>
        /// <value>
        /// The name of the washer model.
        /// </value>
        public string WasherModelName { get; set; }

        /// <summary>
        /// Gets or sets the LfsWasher.
        /// </summary>
        /// <value>
        /// The Lfs Washer.
        /// </value>
        public int LfsWasher { get; set; }

        /// <summary>
        /// Gets or sets the EndOfFormula .
        /// </summary>
        /// <value>
        /// End of Formula.
        /// </value>
        public Int16 EndOfFormula { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value>
        ///   <c>true/false for Awe</c>.
        /// </value>
        public bool AweActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value>
        /// true/false for HoldSignal.
        /// </value>
        public bool HoldSignal { get; set; }

        /// <summary>
        /// Gets or sets the Hold Delay.
        /// </summary>
        /// <value>
        /// The Hold Delay.
        /// </value>
        public int HoldDelay { get; set; }

        /// <summary>
        /// Gets or sets the TargetTurnTime.
        /// </summary>
        /// <value>
        /// The Target Turn Time.
        /// </value>
        public int TargetTurnTime { get; set; }

        /// <summary>
        /// Gets or sets the PlantWasherNumber.
        /// </summary>
        /// <value>
        /// The Plant Washer Number.
        /// </value>
        public Int16 PlantWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets the MaxLoad.
        /// </summary>
        /// <value>
        /// The Maximum Load efficiency.
        /// </value>
        public Int16 MaxLoad { get; set; }

        /// <summary>
        /// Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>
        /// Water Flush Time.
        /// </value>
        public int WaterFlushTime { get; set; }

        /// <summary>
        /// Gets or sets InjectionRatio
        /// </summary>
        /// <value>
        /// The injection ratio.
        /// </value>
        public decimal InjectionRatio { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description Value.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the washer group identifier.
        /// </summary>
        /// <value>
        /// The washer group identifier.
        /// </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        /// Gets or sets the washer group identifier.
        /// </summary>
        /// <value>
        /// The washer group identifier.
        /// </value>
        public int WasherGroupIdNew { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer type.
        /// </summary>
        /// <value>
        /// The name of the washer type.
        /// </value>
        public string WasherTypeName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value>
        ///   <c>true/false for Washer Type Flag</c>.
        /// </value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        /// Gets or sets the region identifier.
        /// </summary>
        /// <value>
        /// The region identifier.
        /// </value>
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets the role.
        /// </summary>
        /// <value>
        /// The role of logged user.
        /// </value>
        public int Role { get; set; }

        /// <summary>
        /// Gets or sets the tags list for conventional.
        /// </summary>
        /// <value>
        /// Returns the list of tags.
        /// </value>
        public IEnumerable<ConventionalTagModel> ConventionalWasherTagList { get; set; }

        /// <summary>
        /// Gets or sets the Controller Data
        /// </summary>
        /// <value>
        /// The Parameter Controller Data
        /// </value>
        public List<OpcTag> PlcWasherTagModelTags { get; set; }

        /// <summary>
        /// Gets or sets the LastSyncTime
        /// </summary>
        /// <value>
        /// Last Sync Time
        /// </value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets Max Number Of Records
        /// </summary>
        /// <value>
        /// Max Number Of Records
        /// </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>
        /// Last Modified Time Stamp
        /// </value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the Is Delete
        /// </summary>
        /// <value>
        /// Is Delete will return true or false
        /// </value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGrpGuid for Washer group
        /// </summary>
        /// <value>
        /// My Service CustMchGrpGuid
        /// </value>
        public Guid MyServiceCustMchGrpGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGuid for washer
        /// </summary>
        /// <value>
        /// My Service CustMchGuid
        /// </value>
        public Guid MyServiceCustMchGuid { get; set; }

        /// <summary>
        /// Gets or sets the MyService Id.
        /// </summary>
        /// <value>
        /// The MyService Id..
        /// </value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        /// Gets or sets the  IsValueDiffforEOF
        /// </summary>
        /// <value>
        /// Is Value Diff for EOF
        /// </value>
        public bool IsValueDiffforEOF { get; set; }

        /// <summary>
        /// Gets or sets the IsValueDiffforMode
        /// </summary>
        /// <value>
        /// Is Value Diff for Mode
        /// </value>
        public bool IsValueDiffforMode { get; set; }

        /// <summary>
        /// Gets or sets the Is Delete
        /// </summary>
        /// <value>
        /// Is Value Diff for Hold Delay
        /// </value>
        public bool IsValueDiffforHoldDelay { get; set; }

        /// <summary>
        /// Gets or sets the IsValueDifffor Water Flush
        /// </summary>
        /// <value>
        /// Is Value Diff for Water Flush
        /// </value>
        public bool IsValueDiffforWaterFlush { get; set; }

        /// <summary>
        /// Gets or sets the IsValueDifffor Ratio dosing Active
        /// </summary>
        /// <value>
        /// Is Value Diff for RatiodosingActive
        /// </value>
        public bool IsValueDiffforRatiodosingActive { get; set; }

        /// <summary>
        /// Gets or sets the IsValueDifffor AWEActive
        /// </summary>
        /// <value>
        /// IsValueDiffforAWEActive
        /// </value>
        public bool IsValueDiffforAWEActive { get; set; }

        /// <summary>
        /// Gets or sets the IsValueDifffor HoldSignal
        /// </summary>
        /// <value>
        /// IsValueDiffforHoldSignal
        /// </value>
        public bool IsValueDiffforHoldSignal { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value>
        ///   <c>true/false for RatioDosingActive</c>.
        /// </value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        /// Gets or sets the Min Machine Load
        /// </summary>
        /// <value>
        /// Min Machine Load
        /// </value>
		public short MinMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Max Machine Load
        /// </summary>
        /// <value>
        /// Max Machine Load
        /// </value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Program Selection By Time
        /// </summary>
        /// <value>
        ///   <c>true/false for ProgramSelectionByTime</c>.
        /// </value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        /// Gets or sets the Override Program Selection By Time
        /// </summary>
        /// <value>
        ///   <c>true/false for IsValueDiffForProgramSelectionByTime</c>.
        /// </value>
		public bool IsValueDiffForProgramSelectionByTime { get; set; }

        /// <summary>
        /// Gets or sets FlowSwitchNumber
        /// </summary>
        /// <value>
        /// Flow Switch Number
        /// </value>
        public int FlowSwitchNumber { get; set; }

        /// <summary>
        /// Gets or sets washerStopExternalSignal
        /// </summary>
        /// <value>
        /// washerStopExternalSignal
        /// </value>
        public bool WasherStopExternalSignal { get; set; }

        /// <summary>
        /// Gets or sets the WasherOnHoldSignalDelay
        /// </summary>
        /// <value>
        /// Washer on hold signal delay
        /// </value>
        public int WasherOnHoldSignalDelay { get; set; }

        /// <summary>
        /// Gets or sets the Value Outputs Used As TOM Signal
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool ValveOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        /// Gets or sets the WE In TOM Mode
        /// </summary>
        /// <value>
        ///   <c>true/false for WeInTomMode</c>.
        /// </value>
        public bool WeInTomMode { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L1
        /// </summary>
        /// <value>
        /// true/false for L1 dosing line mode
        /// </value>
        public bool L1 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L2
        /// </summary>
        /// <value>
        /// true/false for L2 dosing line mode
        /// </value>
        public bool L2 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L3
        /// </summary>
        /// <value>
        /// true/false for L3 dosing line mode
        /// </value>
        public bool L3 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L4
        /// </summary>
        /// <value>
        /// true/false for L4 dosing line mode
        /// </value>
        public bool L4 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L5
        /// </summary>
        /// <value>
        /// true/false for L5 dosing line mode
        /// </value>
        public bool L5 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L6
        /// </summary>
        /// <value>
        /// true/false for L6 dosing line mode
        /// </value>
        public bool L6 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L7
        /// </summary>
        /// <value>
        /// true/false for L7 dosing line mode
        /// </value>
        public bool L7 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L8
        /// </summary>
        /// <value>
        /// true/false for L8 dosing line mode
        /// </value>
        public bool L8 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L9
        /// </summary>
        /// <value>
        /// true/false for L9 dosing line mode
        /// </value>
        public bool L9 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L10
        /// </summary>
        /// <value>
        /// true/false for L10 dosing line mode
        /// </value>
        public bool L10 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L11
        /// </summary>
        /// <value>
        /// true/false for L11 dosing line mode
        /// </value>
        public bool L11 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L12
        /// </summary>
        /// <value>
        /// true/false for L12 dosing line mode
        /// </value>
        public bool L12 { get; set; }

        /// <summary>
        /// Gets or sets the ManiFold Flush Time
        /// </summary>
        /// <value>
        /// Mani fold flush time
        /// </value>
        public int ManifoldFlushTime { get; set; }

        /// <summary>
        /// Gets or sets OnHoldWESignalActive
        /// </summary>
        /// <value>
        /// OnHoldWESignalActive
        /// </value>
        public bool OnHoldWESignalActive { get; set; }

        /// <summary>
        /// Gets or sets the controller model id
        /// </summary>
        /// <value>
        /// Controller model id
        /// </value>
        public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value>
        ///   <c>true/false for IsPony</c>.
        /// </value>
        public bool IsPony { get; set; }

        /// <summary>
        /// Gets or sets the controller type id
        /// </summary>
        /// <value>
        /// Controller type id
        /// </value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets UseMe1OfGroup
        /// </summary>
        /// <value>
        /// The use me1 of group.
        /// </value>
        public byte? UseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UseMe2OfGroup
        /// </summary>
        /// <value>
        /// The use me2 of group.
        /// </value>
        public byte? UseMe2OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UsePumpOfGroup
        /// </summary>
        /// <value>
        /// The use pump of group.
        /// </value>
        public byte? UsePumpOfGroup { get; set; }

        /// <summary>
        /// Gets or sets WasherStopUseFinalExtracting
        /// </summary>
        /// <value>
        /// The washer stop use final extracting.
        /// </value>
        public bool? WasherStopUseFinalExtracting { get; set; }

        /// <summary>
        /// Gets or sets TemperatureAlarmYesNo
        /// </summary>
        /// <value>
        /// The temperature alarm yes no.
        /// </value>
        public bool? TemperatureAlarmYesNo { get; set; }

        /// <summary>
        /// Gets or sets PhProbe
        /// </summary>
        /// <value>
        /// The ph probe number.
        /// </value>
        public bool? PhProbe { get; set; }

        /// <summary>
        /// Gets or sets WeightCell
        /// </summary>
        /// <value>
        /// The weight cell value.
        /// </value>
        public bool? WeightCell { get; set; }

        /// <summary>
        /// Gets or sets Temperature
        /// </summary>
        /// <value>
        /// The temperature value.
        /// </value>
        public bool? Temperature { get; set; }

        /// <summary>
        /// Gets or sets WaterCounter
        /// </summary>
        /// <value>
        /// The water counte valuer.
        /// </value>
        public bool? WaterCounter { get; set; }

        /// <summary>
        /// Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>
        /// Date An dTime When Batch Ejects
        /// </value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix After
        /// </value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix 1 For
        /// </value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix 2 For
        /// </value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 1
        /// </value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 2
        /// </value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 3
        /// </value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        /// <summary>
        /// Gets or sets the DefaultIdleTime
        /// </summary>
        /// <value>
        /// Default Idle Time
        /// </value>
        public int DefaultIdleTime { get; set; }

        /// <summary>
        /// Gets or sets the ETechWasherNumber
        /// </summary>
        /// <value>
        /// ETech Washer Number
        /// </value>
        public int ETechWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>
        /// Signal Acceptance Time
        /// </value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        /// Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>
        /// Is Value Diff For Signal Acceptance Time
        /// </value>
        public bool IsValueDiffForSignalAcceptanceTime { get; set; }

        /// <summary>
        /// Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>
        /// KannegiesserDosageInPreparationTankMode
        /// </value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        /// Gets or sets the BatchOk
        /// </summary>
        /// <value>
        /// Batch Ok Value
        /// </value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for washer stop external signal.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for washer stop external signal; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForWasherStopExternalSignal { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for we in tom mode.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for we in tom mode; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForWeInTomMode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for on hold we signal active.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for on hold we signal active; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForOnHoldWESignalActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for valve outputs used as tom signal.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for valve outputs used as tom signal; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForValveOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for maximum machine load.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for maximum machine load; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForMaxMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for minimum machine load.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for minimum machine load; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForMinMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for washer on hold signal delay.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for washer on hold signal delay; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForWasherOnHoldSignalDelay { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for flow switch number.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for flow switch number; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForFlowSwitchNumber { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is value difference for manifold flush time.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is value difference for manifold flush time; otherwise, <c>false</c>.
        /// </value>
        public bool IsValueDiffForManifoldFlushTime { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L1
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL1
        /// </value>
        public bool IsValueDiffForL1 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L2
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL2
        /// </value>
        public bool IsValueDiffForL2 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L3
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL3
        /// </value>
        public bool IsValueDiffForL3 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L4
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL4
        /// </value>
        public bool IsValueDiffForL4 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L5
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL5
        /// </value>
        public bool IsValueDiffForL5 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L6
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL6
        /// </value>
        public bool IsValueDiffForL6 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L7
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL7
        /// </value>
        public bool IsValueDiffForL7 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L8
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL8
        /// </value>
        public bool IsValueDiffForL8 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L9
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL9
        /// </value>
        public bool IsValueDiffForL9 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L10
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL10
        /// </value>
        public bool IsValueDiffForL10 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L11
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL11
        /// </value>
        public bool IsValueDiffForL11 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L12
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForL12
        /// </value>
        public bool IsValueDiffForL12 { get; set; }

        /// <summary>
        /// Gets or sets the Use Me 1 Of Group
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForUseMe1OfGroup
        /// </value>
        public bool IsValueDiffForUseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets the Use Me 2 Of Group
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForUseMe2OfGroup
        /// </value>
        public bool IsValueDiffForUseMe2OfGroup { get; set; }

        /// <summary>
        /// Gets or sets the Use Pump Of Group
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForUsePumpOfGroup
        /// </value>
        public bool IsValueDiffForUsePumpOfGroup { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Yes No
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForTemperatureAlarmYesNo
        /// </value>
        public bool IsValueDiffForTemperatureAlarmYesNo { get; set; }

        /// <summary>
        /// Gets or sets the Washer Mode Id
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForWasherModeId
        /// </value>
        public bool IsValueDiffForWasherModeId { get; set; }

        /// <summary>
        /// Gets or sets the Washer Stop Use Final Extracting
        /// </summary>
        /// <value>
        /// true/false for IsValueDiffForWasherStopUseFinalExtracting
        /// </value>
        public bool IsValueDiffForWasherStopUseFinalExtracting { get; set; }

        /// <summary>
        /// Gets or sets the name of the Washer Group Type Name.
        /// </summary>
        /// <value>
        /// The name of the Washer Group Type Name.
        /// </value>
        public string WasherGroupTypeName { get; set; }

        /// <summary>
        /// Gets or sets the Add Extracting Time To EOF Signal.
        /// </summary>
        /// <value>
        /// The name of the Add Extracting Time To EOF Signal.
        /// </value>
        public bool ExtractTimeForEOFSignal { get; set; }
    }
}