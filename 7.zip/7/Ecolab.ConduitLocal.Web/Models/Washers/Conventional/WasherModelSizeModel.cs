﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModel Size Model object for WasherModelSize List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    using System;

    /// <summary>
    ///     Class WasherModelSizeModel.
    /// </summary>
    public class WasherModelSizeModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public short WasherModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherModelName { get; set; }

        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherSize { get; set; }

        /// <summary>
        ///     Gets or sets the Model Type Id of the washer.
        /// </summary>
        /// <value>The Model Type Id of the washer.</value>
        public Int16 ModelTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        ///     Gets or sets the Region Code.
        /// </summary>
        /// <value>The Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the last synch time.
        /// </summary>
        /// <value>The last synch time.</value>
        public DateTime MyServiceModDtTm { get; set; }
    }
}