﻿// -----------------------------------------------------------------------
// <copyright file="ConventionGeneralPrintModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionGeneral Print Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    using System.Collections.Generic;
    using ControllerSetup;
    using WasherGroup;

    /// <summary>
    ///     Class ConventionGeneralPrintModel.
    /// </summary>
    public class ConventionGeneralPrintModel
    {
        /// <summary>
        ///     Gets or sets the value the Conventional General Data
        /// </summary>
        public ConventionalGeneralModel ConventionalGeneralData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washer Group Data
        /// </summary>
        public IEnumerable<WasherGroup> WasherGroupData { get; set; }

        /// <summary>
        ///     Gets or sets the value Controller Setup Data
        /// </summary>
        public IEnumerable<ControllerModel> ControllerSetupData { get; set; }

        /// <summary>
        ///     Gets or sets the value Hold Conditions Data
        /// </summary>
        public AlarmsData HoldConditionData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washer Mode List
        /// </summary>
        /// <value>List of Washer Modes</value>
        public IEnumerable<WasherModeListModel> WasherModeList { get; set; }

        /// <summary>
        ///     Gets or sets the value WasherGroup Formula Lists
        /// </summary>
        public WasherGroupFormulaLists FormulaData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washergroup with Washers
        /// </summary>
        /// <value>Washer Group With Washers</value>
        public WasherGroupPrintModel WasherGroupWithWashers { get; set; }
       
        /// <summary>
        /// Gets or Sets the value of FlushTimeAndSetupTomData
        /// </summary>
        /// 
        public FlushTimesAndSetupTom FlushTimesAndSetupTomData { get; set; }

        /// <summary>
        /// Gets or Sets the value of ProductDeviation
        /// </summary>
        public WasherProductDeviationModel ProductDeviationPrintData { get; set; }

        /// <summary>
        /// get or set region id
        /// </summary>
        public int RegionId { get; set; }

    }
}