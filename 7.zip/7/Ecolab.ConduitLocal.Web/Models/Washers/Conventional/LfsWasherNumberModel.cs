﻿// -----------------------------------------------------------------------
// <copyright file="LfsWasherNumberModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModel Size Model object for WasherModelSize List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Conventional
{
    using System;

    /// <summary>
    ///     Class LfsWasherNumberModel.
    /// </summary>
    public class LfsWasherNumberModel
    {
        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public Int16 LfsWasherMaxNumber { get; set; }
    }
}