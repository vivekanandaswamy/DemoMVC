﻿// -----------------------------------------------------------------------
// <copyright file="WashersModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The Washers is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
    using System;

    /// <summary>
    ///     Class WashersModel.
    /// </summary>
    public class WashersModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the WasherNumber
        /// </summary>
        /// <value>The washer number.</value>
        public short WasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the WasherName
        /// </summary>
        /// <value>The name of the washer.</value>
        public string WasherName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherType
        /// </summary>
        /// <value>The type of the washer.</value>
        public string WasherType { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModel
        /// </summary>
        /// <value>The washer model.</value>
        public string WasherModel { get; set; }

        /// <summary>
        ///     Gets or sets the Size
        /// </summary>
        /// <value>The size value.</value>
        public string Size { get; set; }

        /// <summary>
        ///     Gets or sets the Controller
        /// </summary>
        /// <value>The name of the controller.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the controller Type Id.
        /// </summary>
        /// <value>The Parameter controller Type id.</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller type.
        /// </summary>
        /// <value>The name of the controller type.</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the controller Model Id.
        /// </summary>
        /// <value>The Parameter controller Model id.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller model.
        /// </summary>
        /// <value>The name of the controller model.</value>
        public string ControllerModel { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the washer controller identifier.
        /// </summary>
        /// <value>The washer controller identifier.</value>
        public int WasherControllerId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the Maxload
        /// </summary>
        /// <value>The Max load.</value>
        public short Maxload { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Number Of Compartments Conveyor Belt
        /// </summary>
        /// <value>Number Of Compartments Conveyor Belt</value>
        public short NumberOfCompartmentsConveyorBelt { get; set; }

        /// <summary>
        ///     Gets or sets the Min Machine Load
        /// </summary>
        /// <value>Min Machine Load</value>
        public short MinMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Max Machine Load
        /// </summary>
        /// <value>Max Machine Load</value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Program Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Analog Input
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByAnalogInput { get; set; }

        /// <summary>
        ///     Gets or sets the TUN In TOM Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool TunInTomMode { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Stop TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalStopTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Ejection TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalEjectionTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Delay Time For TUN Washing Programs
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool DelayTimeForTunWashingPrograms { get; set; }

        /// <summary>
        ///     Gets or sets the Kannegiesser Press Special Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool KannegiesserPressSpecialMode { get; set; }

        /// <summary>
        ///     Gets or sets the Value Outputs Used As TOM Signal
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ValueOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        ///     Gets or sets the Extended Clock Or Data Protocol
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ExtendedClockOrDataProtocol { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Correction (F.C.C)
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightCorrectionFcc { get; set; }

        /// <summary>
        ///     Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>DateAndTimeWhenBatchEjects</value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>Auto Rinse Desamix After</value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>Auto Rinse Desamix 1 For</value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>Auto Rinse Desamix 2 For</value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>Temperature Alarm Probe 1</value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>Temperature Alarm Probe 2</value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>Temperature Alarm Probe 3</value>
        public bool? TemperatureAlarmProbe3 { get; set; }
        /// <summary>
        ///     Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>SignalAcceptanceTime</value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        ///     Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>KannegiesserDosageInPreparationTankMode</value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        ///     Gets or sets the BatchOk
        /// </summary>
        /// <value>BatchOk</value>
        public bool BatchOk { get; set; }

    }
}