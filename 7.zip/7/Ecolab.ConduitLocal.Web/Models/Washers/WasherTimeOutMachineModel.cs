﻿// -----------------------------------------------------------------------
// <copyright file="WasherTimeOutMachineModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The WasherTimeOutMachineModel is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
    using System;

    /// <summary>
    ///     Class WasherTimeOutMachineModel.
    /// </summary>
    public class WasherTimeOutMachineModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the washerId
        /// </summary>
        /// <value>The washer Id</value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the signalNumber
        /// </summary>
        /// <value>The Signal Number</value>
        public byte SignalNumber { get; set; }

        /// <summary>
        ///     Gets or sets the equipmentNumber
        /// </summary>
        /// <value>The Equipment Number</value>
        public int EquipmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the equipmentNumber
        /// </summary>
        /// <value>The Equipment Number</value>
        public bool IsValueDiffForEquipmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypelId { get; set; }

        /// <summary>
        ///     Gets or sets the dosingPointNumber
        /// </summary>
        /// <value>The Dosing Point Number</value>
        public int DosingPointNumber { get; set; }

        /// <summary>
        ///     Gets or sets the dosingPointNumber
        /// </summary>
        /// <value>The Dosing Point Number</value>
        public bool IsValueDiffForDosingPointNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>The Last Modified Time</value>
        public DateTime LastModifiedTime { get; set; }

		/// <summary>
		///  Gets or sets EquipmentCount
		/// </summary>
		/// <value>EquipmentCount</value>
		public byte EquipmentCount { get; set; }

		/// <summary>
		///  Gets or sets DosingPointCount
		/// </summary>
		/// <value>DosingPointCount</value>
		public byte DosingPointCount { get; set; }

    }
}