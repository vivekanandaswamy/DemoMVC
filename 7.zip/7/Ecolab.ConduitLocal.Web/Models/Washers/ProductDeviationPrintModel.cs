﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationPrintModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductDeviationPrintModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    ///     The Product Deviation PrintModel Class
    /// </summary>
    public class ProductDeviationPrintModel
    {
        /// <summary>
        ///     Gets or sets the value WasherProductDeviationModel
        /// </summary>
        public WasherProductDeviationModel WasherProductDeviationModel { get; set; }
    }
}