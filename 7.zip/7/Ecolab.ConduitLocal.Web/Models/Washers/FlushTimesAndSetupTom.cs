﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTom.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The FlushTimesAndSetupTom is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
    /// <summary>
    ///     Class FlushTimesAndSetupTom.
    /// </summary>
    public class FlushTimesAndSetupTom : BaseViewModel
    {
        /// <summary>
        /// Gets or Sets the machine Id
        /// </summary>
        public int MachineId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Id
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Model Id
        /// </summary>
		public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or Sets the WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherFlushTime
        /// </summary>
        /// <value>The Washer Flush Time</value>
        public List<WasherFlushTimeModel> WasherFlushTime { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTime for pumps
		/// </summary>
		/// <value>The Washer Flush Time for pumps</value>
		public List<WasherFlushTimeModel> Pumps { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTime for pumps
		/// </summary>
		/// <value>The Washer Flush Time for pumps</value>
		public List<WasherFlushTimeModel> Air { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTime for pumps
		/// </summary>
		/// <value>The Washer Flush Time for pumps</value>
		public List<WasherFlushTimeModel> Water { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTime for main equipment
		/// </summary>
		/// <value>The Washer Flush Time for main equipment</value>
		public List<WasherFlushTimeModel> MainEquipment { get; set; }

        /// <summary>
        ///     Gets or sets the WasherTimeOutMachine
        /// </summary>
        /// <value>The Washer Time Out Machine</value>
        public List<WasherTimeOutMachineModel> WasherTimeOutMachine { get; set; }

		/// <summary>
		///     Gets or sets the WasherTimeOutMachine
		/// </summary>
		/// <value>The Washer Time Out Machine</value>
		public List<WasherTimeOutMachineModel> DosingPointTom { get; set; }

		/// <summary>
		///     Gets or sets the WasherTimeOutMachine
		/// </summary>
		/// <value>The Washer Time Out Machine</value>
		public List<WasherTimeOutMachineModel> EquipmentTom { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Number value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Number value.</value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Name value for the washer groups.
        /// </summary>
        /// <value> Washer Group Name value.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Type Id value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Type Id value.</value>
        public byte WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Type Name value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Type Name value.  </value>
        public string WasherGroupType { get; set; }

		/// <summary>
		///     Gets or sets the MachineNumber
		/// </summary>
		/// <value>Gets MachineNumber.  </value>
		public int MachineNumber { get; set; }

		/// <summary>
		///     Gets or sets the NoOfCompartments
		/// </summary>
		/// <value>Gets NoOfCompartments.  </value>
		public int NoOfCompartments { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value>Gets MachineName.  </value>
        public string MachineName { get; set; }
    }
}