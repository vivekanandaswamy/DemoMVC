﻿// -----------------------------------------------------------------------
// <copyright file="AlarmsData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmsData </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
	using System;
	using System.Collections.Generic;
	using WasherGroup;

    /// <summary>
    ///     Alarms Data
    /// </summary>
    public class AlarmsData
    {
        public IEnumerable<AlarmsModel> AlarmsModel { get; set; }
        public IEnumerable<WasherGroup> WasherGroupList { get; set; }
		/// <summary>
		///     Gets or sets the Last Modified Time Stamp
		/// </summary>
		/// <value>LastModifiedTimeStamp</value>
		public DateTime? LastModifiedTimeStamp { get; set; }
    }
}