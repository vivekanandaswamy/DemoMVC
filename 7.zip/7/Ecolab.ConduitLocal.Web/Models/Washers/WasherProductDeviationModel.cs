﻿// -----------------------------------------------------------------------
// <copyright file="WasherProductDeviationModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherProductDeviationModel </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.ConduitLocal.Web.Models.Washers
{
    public class WasherProductDeviationModel
    {
        /// <summary>
        /// Gets or Sets the machine Id
        /// </summary>
        public int MachineId { get; set; }

        /// <summary>
        /// Gets or Sets the machine Number
        /// </summary>
        public int MachineNumber { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Id
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Model Id
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or Sets the WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the productDeviationdata
        /// </summary>
        /// <value>The product Deviation data</value>
        public List<ProductDeviationModel> ProductDeviationdata { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Number value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Number value.</value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Name value for the washer groups.
        /// </summary>
        /// <value> Washer Group Name value.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName value for the washer.
        /// </summary>
        /// <value> MachineName value.</value>
        public string MachineName { get; set; }
        
        /// <summary>
        ///     Gets or sets the Washer Group Type Id value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Type Id value.</value>
        public byte WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Group Type Name value for the washer groups.
        /// </summary>
        /// <value>Gets Washer Group Type Name value.  </value>
        public string WasherGroupType { get; set; }

        /// <summary>
        ///     Gets or sets the pumpsAndMECount
        /// </summary>
        /// <value>The pumps And MECount</value>
        public PumpsAndMECountModel PumpsAndMECount { get; set; }
        /// <summary>
		/// Gets or sets WasherDosingNumber
		/// </summary>
		public int WasherDosingNumber { get; set; }
    }
}