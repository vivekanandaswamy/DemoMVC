﻿// <copyright file="TunnelConnections.cs" company="Ecolab">
//     Copyright (c) Ecolab Company. All rights reserved.
// </copyright>
// <summary>The Tunnel Connections Class</summary>
// ***********************************************************************
namespace Ecolab.ConduitLocal.Web.Models.Washers.Tunnel
{
	#region Usings
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;
	#endregion

	/// <summary>
	/// Tunnel Connections Class
	/// </summary>
	public class TunnelConnections : BaseViewModel
	{
		/// <summary>
		/// Gets or Sets The ControllerId.
		/// </summary>
		/// <value>The Controller Identifier.</value>
		public int ControllerId { get; set; }
		/// <summary>
		/// The Dosing Line Number
		/// </summary>
		/// <value>The Dosing Line Number</value>
		public int DosingLineNumber { get; set; }
		/// <summary>
		/// Dosing Point Number
		/// </summary>
		/// <value>The Dosing Point Number</value>
		public int DosingPointNumber { get; set; }
		/// <summary>
		/// Gets or Sets the Machine Internal Id
		/// </summary>
		/// <value>The Machine Internal Id</value>
		public int MachineInternalId { get; set; }
		/// <summary>
		/// The Valve Number
		/// </summary>
		/// <value>The Valve Number</value>
		public int ValveNumber { get; set; }
		/// <summary>
		/// Tunnel Compartment Number
		/// </summary>
		/// <value>The Tunnel Compartment Number</value>
		public int TunnelCompartmentNumber { get; set; }		
		/// <summary>
		/// Gets or Sets the Washer group Id.
		/// </summary>
		/// <value>The Washer Identifier.</value>
		public int WasherGroupId { get; set; }
		/// <summary>
		/// Gets or Sets the ControllerModel Identifier
		/// </summary>
		/// <value>The ControllerModel Identifier</value>
		public int ControllerModelId { get; set; }
		/// <summary>
		/// Gets or Sets the ControllerEquipmentType
		/// </summary>
		/// <value>The ControllerEquipmentType</value>
		public string ControllerEquipmentType { get; set; }
	}
}