﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModel Size Model object for WasherModelSize List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Washers.Tunnel
{
    /// <summary>
    ///     Class WasherModelSizeModel.
    /// </summary>
    public class WasherModelSizeModel
    {
        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherSize { get; set; }
    }
}