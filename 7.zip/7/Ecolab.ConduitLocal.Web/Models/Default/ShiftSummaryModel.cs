﻿// -----------------------------------------------------------------------
// <copyright file="ShiftSummaryModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftSummaryModel object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models.Default
{
    /// <summary>
    ///     ShiftSummaryModel class
    /// </summary>
    public class ShiftSummaryModel
    {
        /// <summary>
        ///     Gets or sets the TotalLoad.
        /// </summary>
        /// <value>The TotalLoad field</value>
        public double TotalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the LostLoad.
        /// </summary>
        /// <value>The LostLoad field</value>
        public double LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value>The Efficiency field</value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName.
        /// </summary>
        /// <value>The ShiftName field</value>
        public string ShiftName { get; set; }
    }
}