﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMasterModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LanguageMaster object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    /// <summary>
    ///     Model for LanguageMaster
    /// </summary>
    public class LanguageMasterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets LanguageId
        /// </summary>
        /// <value>LanguageId .</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets Name
        /// </summary>
        /// <value>Language Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets Locale
        /// </summary>
        /// <value>Language Locale.</value>
        public string Locale { get; set; }

        #endregion
    }
}