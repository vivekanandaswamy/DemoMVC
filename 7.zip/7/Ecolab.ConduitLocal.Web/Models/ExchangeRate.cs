﻿// -----------------------------------------------------------------------
// <copyright file="ExchangeRate.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Exchange Rate </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Models
{
    using System;

    /// <summary>
    ///     class ExchangeRate
    /// </summary>
    public class ExchangeRate
    {
        /// <summary>
        ///     Gets or sets ExchangeRate Id
        /// </summary>
        /// <value>The ExchangeRate Id .</value>
        public int ExchangeRateId { get; set; }

        /// <summary>
        ///     Gets or sets CurrencyCode
        /// </summary>
        /// <value>The CurrencyCode .</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets Rate
        /// </summary>
        /// <value>The Rate .</value>
        public double Rate { get; set; }

        /// <summary>
        ///     Gets or sets TargetCurrencyCode
        /// </summary>
        /// <value>The TargetCurrencyCode .</value>
        public string TargetCurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets EffectiveExchangeRateDate
        /// </summary>
        /// <value>The EffectiveExchangeRateDate .</value>
        public DateTime EffectiveExchangeRateDate { get; set; }

        /// <summary>
        ///     Gets or sets CreatedDate
        /// </summary>
        /// <value>The CreatedDate .</value>
        public DateTime CreatedDate { get; set; }

    }
}
