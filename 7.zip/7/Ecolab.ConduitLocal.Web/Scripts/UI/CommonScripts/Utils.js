﻿; (function ($) {
    Ecolab.Common.Utils = function () {

    }

    /// <summary>
    /// Filters a list by the passed in values
    /// </summary>
    /// <param name="list">The list of objects to filter</param>
    /// <param name="filters">the array of filter values</param>
    /// <param name="filterField">The name of the property used to filter</param>
    /// <param name="keepFilteredItems">when true the items matching the filters will be returned, when false items not in the filters array will be returned</param>
    /// <returns>The filtered list</returns>
    Ecolab.Common.Utils.filterList = function (list, filters, filterField, keepFilteredItems) {
        if (typeof keepFilteredItems == 'undefined') keepFilteredItems = true;

        if (typeof filters == 'undefined')
            return jQuery.grep(list, function (a, b) { return true; });

        var filteredList = jQuery.grep(list, function (item) {
            if ($.isArray(filters)) {
                for (var filterItem in filters) {
                    if (filters[filterItem] == item[filterField])
                        return true;
                }
            }
            else {
                return item[filterField] == filters;
            }

            return false;
        }, !keepFilteredItems);
        return filteredList;

    }


    Ecolab.Common.Utils.findInList = function (list, conditionEvaluator) {
        for (var idx in list) {
            var item = list[idx];

            if (conditionEvaluator(item))
                return item;
        }

        return null;
    };

    Ecolab.Common.Utils.findAllInList = function (list, conditionEvaluator) {
        var result = [];

        for (var idx in list) {
            var item = list[idx];

            if (conditionEvaluator(item))
                result.push(item);
        }

        return result.length == 0 ? null : result;
    };

    Ecolab.Common.Utils.replaceInList = function (list, newValue, conditionEvaluator) {
        for (var idx in list) {
            var item = list[idx];

            if (conditionEvaluator(item)) {
                list.splice(idx, 1);
                list.push(newValue);
                return;
            }
        }
    };

    Ecolab.Common.Utils.removeFromList = function (list, conditionEvaluator) {
        for (var idx in list) {
            var item = list[idx];

            if (conditionEvaluator(item)) {
                list.splice(idx, 1);
                return;
            }
        }
    };

    /// <summary>
    /// Filters a list by the passed in values
    /// </summary>
    /// <param name="list">The list of objects to filter</param>
    /// <param name="filters">the array of filter values</param>
    /// <param name="filterField">The name of the property used to filter</param>
    /// <param name="keepFilteredItems">when true the items matching the filters will be returned, when false items not in the filters array will be returned</param>
    /// <returns>The filtered list</returns>
    Ecolab.Common.Utils.getUniqueArray = function (array) {
        var result = [];

        for (var item in array) {
            if ($.inArray(array[item], result) == -1) {
                result.push(array[item]);
            }
        }

        return result;
    }

    /// <summary>
    /// Converts a list object into an array that can be used to fill drop downs
    /// </summary>
    /// <param name="list">The list of objects</param>
    /// <param name="IdFieldName">The name of the property to use for the id/value</param>
    /// <param name="TextFieldName">The name of the property to use for the displayed text</param>
    /// <returns>An array of id/text pairs</returns>
    Ecolab.Common.Utils.convertObjectsToDropDownArray = function (list, IdFieldName, TextFieldName) {
        var ar = [];
        for (var item in list) {
            ar[list[item][IdFieldName]] = list[item][TextFieldName];
        }
        return ar;
    }

    /// <summary>
    /// Clones an array
    /// </summary>
    /// <param name="arrayToClone">The array to clone</param>
    /// <returns>The cloned array</returns>
    Ecolab.Common.Utils.cloneArray = function (arrayToClone, shallow) {
        var newArray = new Array();

        if (typeof (shallow) == 'undefined')
            shallow = false;

        for (var i = 0; i < arrayToClone.length; i++) {
            if (shallow)
                newArray.push(arrayToClone[i]);
            else
                newArray.push(Ecolab.Common.Utils.clone(arrayToClone[i]));
        }

        return newArray;
    }

    /// <summary>
    /// Clones an object
    /// </summary>
    /// <param name="objectToClone">The object to clone</param>
    /// <returns>The cloned object</returns>
    Ecolab.Common.Utils.clone = function (objectToClone, shallow) {

        if (typeof (objectToClone) == 'number' || typeof (objectToClone) == 'string')
            return objectToClone;

        if (typeof (shallow) == 'undefined')
            shallow = false;

        if ($.isArray(objectToClone))
            return Ecolab.Common.Utils.cloneArray(objectToClone, shallow);

        var clone = {};
        for (var prop in objectToClone) {
            if (shallow) {
                clone[prop] = objectToClone[prop];
            } else if ($.isArray(objectToClone[prop])) {
                clone[prop] = Ecolab.Common.Utils.cloneArray(objectToClone[prop]);
            } else if (typeof (objectToClone[prop]) == "object" && objectToClone[prop] != null && typeof (objectToClone[prop].clearTime) == "undefined") {
                clone[prop] = Ecolab.Common.Utils.clone(objectToClone[prop]);
            } else {
                clone[prop] = objectToClone[prop];
            }
        }
        return clone;
    }

    /// <summary>
    /// merge the second list object into the first
    /// </summary>
    /// <param name="first">The first list (will include the values from the second after the merge)</param>
    /// <param name="second">The second list (will be merged into the first list)</param>
    /// <returns>There's no returned object, the first list passed in to this function will become the merged list</returns>    
    Ecolab.Common.Utils.merge = function (first, second) {
        var pos = 0;
        for (var itemIndex in first) {
            pos = parseInt(itemIndex) + 1;
        }
        for (var itemIndex in second) {
            var item = Ecolab.Common.Utils.clone(second[itemIndex]);
            first[pos++] = item;
        }
    }

    ///<summa
    Ecolab.Common.Utils.convertObjectToArray = function (objectToConvert) {
        var dataArray = [];

        for (var itemIndex in objectToConvert) {
            dataArray.push(objectToConvert[itemIndex]);
        }

        return dataArray;
    }

    Ecolab.Common.Utils.stretchLayout = function (selector) {

        var elementsToStretch = selector ? $(selector).find('.stretch:visible') : $('.stretch:visible');

        elementsToStretch.height(1);

        elementsToStretch.each(function (index) {
            var _this = $(this);

            var siblingsHeight = 0;
            _this.siblings(':visible').each(function (idx) { siblingsHeight += $(this).outerHeight(true); });

            var parentsPaddingTop = parseInt(_this.parent().css('padding-top'));
            var parentsPaddingBottom = parseInt(_this.parent().css('padding-bottom'));

            if (isNaN(parentsPaddingTop))
                parentsPaddingTop = 0;

            if (isNaN(parentsPaddingBottom))
                parentsPaddingBottom = 0;

            var parentPadding = parentsPaddingBottom + parentsPaddingTop;

            var height = ((_this.parent().innerHeight() - siblingsHeight) - parentPadding) - (_this.outerHeight(true) - _this.height());
            _this.height(height);
        });
    }

    Ecolab.Common.Utils.centerLayoutTimer = null;

    Ecolab.Common.Utils.centerLayout = function (selector, relativeSelector) {

        var centerLayoutInternal = function (selector, relativeSelector) {
            var itemsToBeCentered = $(selector);
            var relativeElement = $(relativeSelector);
            var relativeOffset = relativeElement.offset();
            var relativeDimensions = { height: relativeElement.height(), width: relativeElement.width() };

            itemsToBeCentered.each(function (idx) {
                var top, left, marginLeft = 0, marginTop = 0;
                var element = $(this);
                var dimensions = { height: element.height(), width: element.width() };
                var offset = element.offset();
                var position = element.position();

                top = (relativeDimensions.height - dimensions.height + (element.outerHeight(true) - element.height())) / 2;
                left = (relativeDimensions.width - dimensions.width + (element.outerWidth(true) - element.width())) / 2;

                top += position.top - offset.top;
                left += position.left - offset.left;

                if (top < 0) {
                    marginTop = top;
                    top = 0;
                }

                if (left < 0) {
                    marginLeft = left;
                    left = 0;
                }

                element.css({
                    top: top + 'px',
                    left: left + 'px',
                    marginLeft: marginLeft + 'px',
                    marginTop: marginTop + 'px'
                });
            });

            Ecolab.Common.Utils.currentTimer = null;
        }

        if (Ecolab.Common.Utils.centerLayoutTimer != null) {
            clearTimeout(Ecolab.Common.Utils.centerLayoutTimer);
        }

        Ecolab.Common.Utils.centerLayoutTimer = setTimeout(function () { centerLayoutInternal(selector, relativeSelector); }, 100);
    };

    Ecolab.Common.Utils.injectBlockUI = function (selector, relativeSelector) {
        var fullBlock = $.blockUI;
        var elementBlock = $.fn.block;

        $.blockUI = function (opts) {
            fullBlock(opts);
            Ecolab.Common.Utils.centerLayout(selector, relativeSelector);

        };

        for (var member in fullBlock) {
            $.blockUI[member] = fullBlock[member];
        }

        $.fn.block = function (opts) {
            elementBlock.call(this, opts);
            Ecolab.Common.Utils.centerLayout(selector, relativeSelector);
        };
    };

    Ecolab.Common.Utils.showErrors = function (validation) {

        validation.currentElements.each(function () {
            //hides all error labels
            var rule = validation.settings.messages[$(this).attr('name')];

            for (var message in rule) {
                var item = rule[message];
                $(item.container)
                .text('')
                .hide();
            }
        });

        //shows those which failed
        $.each(validation.errorList, function (index) {
            var item = this.message;
            $(item.container)
                .text(item.text)
                .show();
        });
    };

    Ecolab.Common.Utils.declareNamespace = function (ns) {
        var nameSpaceParts = ns.split('.');
        var currentNameSpace = window;

        for (var nameSpacePart in nameSpaceParts) {
            nameSpacePart = nameSpaceParts[nameSpacePart];

            if (currentNameSpace[nameSpacePart] === undefined) {
                currentNameSpace[nameSpacePart] = {};
            }

            currentNameSpace = currentNameSpace[nameSpacePart];
        }
    };

    Ecolab.Common.Utils.nullOrNotSet = function (object) {
        return object == null || object == undefined;
    };

    Ecolab.Common.Utils.prefixHttp = function (str) {
        if (!str.startsWith('http')) {
            return 'http://' + str;
        }
        return str;
    };

    String.prototype.bool = function () {
        return (/^true$/i).test(this);
    };

    String.prototype.capitalize = function () {
        return this.replace(/(^|\s)([a-z])/g, function (m, p1, p2) { return p1 + p2.toUpperCase(); });
    };

    Array.prototype.arrHasDupes = function () {                          // finds any duplicate array elements using the fewest possible comparison
        var i, j, n;
        var A = this;
        n = A.length;
        // to ensure the fewest possible comparisons
        for (i = 0; i < n; i++) {                        // outer loop uses each item i at 0 through n
            for (j = i + 1; j < n; j++) {              // inner loop only compares items j at i+1 to n
                if (A[i] == A[j]) return true;
            }
        }
        return false;
    };

})(jQuery);
