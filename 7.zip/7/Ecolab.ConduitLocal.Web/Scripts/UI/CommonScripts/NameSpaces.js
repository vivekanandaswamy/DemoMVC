﻿;var Ecolab = {
    Model: {},
    Views: {},
    Presenters: {},
    Common: {}
};

