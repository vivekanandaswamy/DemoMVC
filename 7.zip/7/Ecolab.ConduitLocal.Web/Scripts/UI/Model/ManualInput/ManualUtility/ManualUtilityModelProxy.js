Ecolab.Model.ManualUtilityModelProxy = function () {
};

Ecolab.Model.ManualUtilityModelProxy.prototype =
{
    loadManualUtility: function (callBack, errorCallBack) {
        var url = "/Api/ManualUtility/FetchManualUtilities";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    FetchFormulaByWasherGroup: function (id, callBack, errorCallBack) {
        var url = "/Api/ManualUtility/FetchMiFormulaDetails/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    FetchManualUtility: function (manualUtilityViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualUtility/FetchManualUtility";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualUtilityViewModel);
    },

    deleteManualUtility: function (data, callBack, errorCallBack) {
        var url = "/Api/ManualUtility/DeleteManualUtility";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    },

    updateManualUtility: function (manualUtilityViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualUtility/SaveManualUtility";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualUtilityViewModel);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ManualUtilityModelProxy.prototype = $.extend({}, Ecolab.Model.ManualUtilityModelProxy.prototype, base);
Ecolab.Model.ManualUtilityModelProxy.prototype.base = base;