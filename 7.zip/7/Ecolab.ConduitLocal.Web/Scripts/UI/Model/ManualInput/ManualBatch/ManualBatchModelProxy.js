Ecolab.Model.ManualBatchModelProxy = function () {
};

Ecolab.Model.ManualBatchModelProxy.prototype =
{
    fetchWasherGroup: function (data, callBack, errorCallBack) {
        var url = "/Api/ManualBatch/FetchWasherGroups/?data={data}";
        var requestData = { "data": data};
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    FetchDataOnWasherGroupChange: function (id, callBack, errorCallBack) {
        var url = "/ManualBatch/FetchWashers";
        var requestData = { "groupIds": id };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    FetchManualBatch: function (objManualBatch, callBack, errorCallBack) {
        var url = "/Api/ManualBatch/FetchBatchByGroupId";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, objManualBatch);
    },

    FetchBatchDetails: function (objManualBatch, callBack, errorCallBack) {
        var url = "/Api/ManualBatch/FetchBatchDetailsByBatchId";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, objManualBatch);
    },

    updateManualBatch: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualBatch/UpdateManualBatch";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },
    loadManualBatch: function (Id, callBack, errorCallBack) {
        var url = "/Api/ManualBatch/FetchBatchData";
        var requestData = { "Id": Id };
        this.ApiRead("ManualBatch", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    FetchFormulasOnWasherSelect: function (id, callBack, errorCallBack) {
        var url = "/ManualBatch/FetchWasherGroupFormulasOnWasherChange";
        var requestData = { "groupIds": id }
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ManualBatchModelProxy.prototype = $.extend({}, Ecolab.Model.ManualBatchModelProxy.prototype, base);
Ecolab.Model.ManualBatchModelProxy.prototype.base = base;