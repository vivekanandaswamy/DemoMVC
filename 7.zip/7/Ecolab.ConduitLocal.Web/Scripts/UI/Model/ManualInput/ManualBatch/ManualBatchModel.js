﻿Ecolab.Model.ManualBatchModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onProductDataLoaded: null,
            onProductDataDeleted: null,
            onProductDataDeletionFailed: null,
            onManualBatchUpdated: null,
            onManualBatchUpdationFailed: null,
            onWasherFormulaLoaded: null,
            onManualBatchFetched: null,
            onWahserGroupLoaded: null,
            onBatchDetailsFetched: null,
            FetchFormulasOnWasherChange: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ManualBatchModelProxy = new Ecolab.Model.ManualBatchModelProxy();
};

Ecolab.Model.ManualBatchModel.prototype = {
    init: function () {
    },

    loadManualBatch: function (id) {
        var _this = this;
        this.ManualBatchModelProxy.loadManualBatch(id, function (data) {
            _this.settings.eventHandlers.onManualBatchLoaded(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataDeletionFailed(error, description); });
    },

    fetchWasherGroup: function (data) {
        var _this = this;
        this.ManualBatchModelProxy.fetchWasherGroup(data,function (data) {
            _this.settings.eventHandlers.onWahserGroupLoaded(data);
        });
    },

    deleteManualBatch: function (data) {
        var _this = this;
        this.ManualBatchModelProxy.deleteManualBatch(data, function (data) {
            _this.settings.eventHandlers.onManualBatchFetched(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataDeletionFailed(error, description); });
    },

    updateManualBatch: function (data) {
        var _this = this;
        this.ManualBatchModelProxy.updateManualBatch(data, function (data) {
            _this.settings.eventHandlers.onManualBatchUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onManualBatchUpdationFailed(error, description); });
    },

    FetchDataOnWasherGroupChange: function (groupId) {       
        var _this = this;
        this.ManualBatchModelProxy.FetchDataOnWasherGroupChange(groupId, function (data) {
            _this.settings.eventHandlers.onFormulaLoaded(data);
        }, function (error, description) {
            //_this.settings.eventHandlers.onManualBatchUpdationFailed(error, description);
        });
        
    },

    FetchManualBatch: function (objManualBatch) {
        var _this = this;
        this.ManualBatchModelProxy.FetchManualBatch(objManualBatch, function (data) {
            _this.settings.eventHandlers.onManualBatchFetched(data);
        });
    },
    FetchFormulasOnWasherChange: function (groupId) {
        var _this = this;
        this.ManualBatchModelProxy.FetchFormulasOnWasherSelect(groupId, function (data) {
            _this.settings.eventHandlers.onFormulaFetched(data);
        });
    },

    

    FetchBatchDetails: function (objManualBatch) {
        var _this = this;
        this.ManualBatchModelProxy.FetchBatchDetails(objManualBatch, function (data) {
            _this.settings.eventHandlers.onBatchDetailsFetched(data);
        });
    }
};

