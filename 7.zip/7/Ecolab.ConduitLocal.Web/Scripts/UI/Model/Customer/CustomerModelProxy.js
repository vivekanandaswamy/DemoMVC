Ecolab.Model.CustomerModelProxy = function () {
};

Ecolab.Model.CustomerModelProxy.prototype =
{
    CustomerModelProxy: function (id, callBack, errorCallBack) {
        var url = "CustomerController/{id}";
        var requestData = { "id": id };
        this.ApiRead("Customer", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.CustomerModelProxy.prototype = $.extend({}, Ecolab.Model.CustomerModelProxy.prototype, base);
Ecolab.Model.CustomerModelProxy.prototype.base = base;