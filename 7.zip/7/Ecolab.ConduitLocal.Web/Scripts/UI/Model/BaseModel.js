﻿Ecolab.Model.BaseModel = function (options) {
    var defaultSettings = {
        eventHandlers: {
            onServerRequestError: null
        }
    };

    this.options = $.extend(defaultSettings, options);
    var _this = this;

    Ecolab.Model.Common.registerErrorCallBack(
        function (data, errors) {
            _this.options.eventHandlers.onServerRequestError(data, errors);
        });
};

Ecolab.Model.BaseModel.prototype = {};