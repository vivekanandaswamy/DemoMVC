Ecolab.Model.LaborCostModelProxy = function () {
};

Ecolab.Model.LaborCostModelProxy.prototype =
{
    loadLaborCostData: function (callBack, errorCallBack) {
        var url = "/Api/LaborCost/Fetch";
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    updateLaborCostData: function (laborCostViewModel, callBack, errorCallBack) {
        var url = "/Api/LaborCost/Put";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, laborCostViewModel);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.LaborCostModelProxy.prototype = $.extend({}, Ecolab.Model.LaborCostModelProxy.prototype, base);
Ecolab.Model.LaborCostModelProxy.prototype.base = base;