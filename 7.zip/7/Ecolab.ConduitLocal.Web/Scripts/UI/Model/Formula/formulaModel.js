Ecolab.Model.FormulaModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onTextileSaturationReceicved: function () { },
            onTextileSaturationFailed: function () { },
            onFormulaDataLoaded: function () { },
            onLoadDropDownDataLoaded: function () { },
            onGetChainFormulaNames: function () { },
            onGetChainFormulaData: function () { },
            onFormulaUpdateSuccess: function () { },
            onFormulaUpdateFailed: function () { },
            onFormulaSaveSuccess: function () { },
            onFormulaSaveFailed: function () { },
            onFormulaDataForUpdateLoaded: function () { },
            onFormulaDeleteSuccess: function () { },
            onFormulaDeleteFailed: function () { },
            onFormulaDataForUpdateLoadedEdit: function () { },

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.FormulaModelProxy = new Ecolab.Model.FormulaModelProxy();
};

Ecolab.Model.FormulaModel.prototype = {
    init: function () {
    },
    loadFormulaData: function (callBackData) {
        var _this = this;
        var programId = 0;
        this.FormulaModelProxy.loadFormulaData(programId,
            function (formulaData) {
                _this.settings.eventHandlers.onFormulaDataLoaded(formulaData);
            });
    },
    LoadDropDownData: function(plantChainId, callBackData){
        var _this = this;
        this.FormulaModelProxy.LoadDropDownData(plantChainId,
            function (formulaDropDownData) {
                _this.settings.eventHandlers.onLoadDropDownDataLoaded(formulaDropDownData);
            });
    },
    GetChainFormulaNames:function(plantChainId, callBackData){
        var _this = this;
        var data = {};
        data.PlantChainId = plantChainId;
        this.FormulaModelProxy.GetChainFormulaNames(plantChainId,
            function (chainFormulaNames) {
                data.ChainFormulaNames = chainFormulaNames;
                _this.settings.eventHandlers.onGetChainFormulaNames(data);
            });
    },
    getChainFormulaData:function(plantProgramId,callBackData){
        var _this = this;
        this.FormulaModelProxy.getChainFormulaData(plantProgramId,
            function (chainFormulaData) {
                _this.settings.eventHandlers.onGetChainFormulaData(chainFormulaData);
            });
    },
    onFormulaUpdate: function (data) {
        var _this = this;
        this.FormulaModelProxy.onFormulaUpdate(data,
            function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onFormulaUpdateSuccess(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onFormulaUpdateFailed(error, description);
            });
    },
    onFormulaSave: function (formulaData) {
        var _this = this;
        this.FormulaModelProxy.onFormulaSave(formulaData,
            function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onFormulaSaveSuccess(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onFormulaSaveFailed(error, description);
            });
    },
    loadFormulaDataForUpdate: function (programId,isCopy, callBackData) {
        var _this = this;
        this.FormulaModelProxy.loadFormulaData(programId,
            function (formulaData) {
                _this.settings.eventHandlers.onFormulaDataForUpdateLoaded(formulaData, isCopy);
            });
    },
    DeleteFormula: function (programId, lastmodifiedtime) {
        var _this = this;
        this.FormulaModelProxy.onDeleteFormula(programId,lastmodifiedtime,
            function (FormulaData) { //Callback method
                _this.settings.eventHandlers.onFormulaDeleteSuccess(FormulaData);
            },
            function (error, description) { //Error callback method 
                _this.settings.eventHandlers.onFormulaDeleteFailed(error, description);
            });
    },
    loadFormulaDataForUpdateEdit: function (programId, isCopy, data, callBackData) {
        var _this = this;
        this.FormulaModelProxy.loadFormulaData(programId,
            function (formulaData) {
                _this.settings.eventHandlers.onFormulaDataForUpdateLoadedEdit(formulaData, isCopy, data);
            });
    }
};

