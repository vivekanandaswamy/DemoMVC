Ecolab.Model.FormulaModelProxy = function () {
};

Ecolab.Model.FormulaModelProxy.prototype =
{
    FormulaModelProxy: function (id, callBack, errorCallBack) {
        var url = "FormulaController/{id}";
        var requestData = { "id": id };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadFormulaData: function (programId, callBack) {
        var requestData = { "programId": programId };
        var url = "Api/PlantFormula/GetFormula";
        this.ApiRead("Formula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    LoadDropDownData: function (plantChainId, callBack) {
        var requestData = { "plantChainId": plantChainId };
        var url = "Api/PlantFormula/GetFormulaForDropDown";
        this.ApiRead("Formula", url, function (response) { callBack(response); }, null, null, requestData);
    },
    GetChainFormulaNames:function(plantChainId, callBack){
        var url = "Api/PlantFormula/GetChainFormulaNames";
        var requestData = { "plantChainId": plantChainId };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getChainFormulaData:function(plantProgramId, callBack){
        var url = "Api/PlantFormula/GetChainFormulaData";
        var requestData = { "plantProgramId": plantProgramId };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    onFormulaUpdate: function (data, callBack, errorCallBack) {
        var url = "Api/PlantFormula/Put";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    },
    onFormulaSave: function (formulaData, callBack, errorCallBack) {
        var url = "Api/PlantFormula/CreateFormula";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, formulaData);
    },
    onDeleteFormula: function (programId,lastmodifiedtime, callBack, errorCallBack) {
        var url = "Api/PlantFormula/DeleteFormula";
        var requestData = { "programId": programId, "lastmodifiedtime": lastmodifiedtime };
        this.ApiRead("Formula", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.FormulaModelProxy.prototype = $.extend({}, Ecolab.Model.FormulaModelProxy.prototype, base);
Ecolab.Model.FormulaModelProxy.prototype.base = base;