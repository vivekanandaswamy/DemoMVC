// JavaScript source code
Ecolab.Model.DryerModelProxy = function () {
};

Ecolab.Model.DryerModelProxy.prototype =
{
    loadDryerGroupData: function (callBack, errorCallBack) {
        var url = "/Api/Dryer/Get";
        this.ApiRead("Dryer", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadDryerTypes: function (callBack, errorCallBack) {
        var url = "/Api/Dryer/FetchDryerTypes";
        this.ApiRead("Dryer", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    createDryerGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/CreateDryerGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateDryerGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/UpdateDryerGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteDryerGroup: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/DeleteDryerGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    createDryer: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/CreateDryer";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateDryer: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/UpdateDryer";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteDryer: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Dryer/DeleteDryer";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
}
var base = new Ecolab.Model.Common();
Ecolab.Model.DryerModelProxy.prototype = $.extend({}, Ecolab.Model.DryerModelProxy.prototype, base);
Ecolab.Model.DryerModelProxy.prototype.base = base;