Ecolab.Model.ChemicalModel = function (options) {
	var defaultOptions = {
		eventHandlers: {
			onGetWasherGroupList: null,
			onGetUnUsedPlantChemicalList: null,
			onCheckWasherGroupForProduct: null,
			onSaveSubstitueChemical: null,
		}
	};

	this.settings = $.extend(defaultOptions, options);
	this.ChemicalModelProxy = new Ecolab.Model.ChemicalModelProxy();
};

Ecolab.Model.ChemicalModel.prototype = {
	init: function () {
	},
	loadChemicalData: function (pageIndex, callBackData) {
		var _this = this;
		_this.onDataLoaded("data", true);
	},
	onDataLoaded: function (data, callBackData) {
		var _this = this;

		_this.settings.eventHandlers.onChemicalDataLoaded(data, callBackData);
	},
	loadChemicals: function (request, callBack) {
		this.ChemicalModelProxy.loadChemicals(request, callBack);
	},
	GetWasherGroupList: function () {
		var _this = this;

		this.ChemicalModelProxy.GetWasherGroupList(function (data) {
			_this.GetProductList(data);

		});
	},
	GetProductList: function (washerGroupList) {
		var _this = this;
		var data = [];
		data.WasherGroupList = washerGroupList;
		this.ChemicalModelProxy.GetUnUsedPlantChemicalList(-1, function (productList) {
			data.ProductList = productList;
			_this.settings.eventHandlers.onGetWasherGroupList(data);
		});
	},
	GetUnUsedPlantChemicalList: function (washerGroupId) {
		var _this = this;

		this.ChemicalModelProxy.GetUnUsedPlantChemicalList(washerGroupId, function (data) {
			_this.settings.eventHandlers.onGetUnUsedPlantChemicalList(data);
		});
	},
	CheckWasherGroupForProduct: function (requestData) {
		var _this = this;
		this.ChemicalModelProxy.CheckWasherGroupForProduct(requestData, function (data) {
			_this.settings.eventHandlers.onCheckWasherGroupForProduct(data);
		});
	},
	SaveSubstitueChemical: function (requestData) {
		var _this = this;
		this.ChemicalModelProxy.SaveSubstitueChemical(requestData, function (data) {
			_this.settings.eventHandlers.onSaveSubstitueChemical(data);
		});
	},
};

