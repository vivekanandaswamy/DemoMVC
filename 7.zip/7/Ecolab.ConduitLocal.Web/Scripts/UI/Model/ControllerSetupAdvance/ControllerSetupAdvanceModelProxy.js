Ecolab.Model.ControllerSetupAdvanceModelProxy = function () {
};

Ecolab.Model.ControllerSetupAdvanceModelProxy.prototype =
{
    getMetaData: function (tabId, controllerId, callBack) {
        var url = "Api/ControllerSetup/GetControllerSetupAdvanceMetaData";
        var requestData = { "tabId": tabId, "controllerId": controllerId };
        this.ApiRead("ControllerSetup", url,
            function (response) {
                callBack(response);
            },
            null, null, requestData);
    },
    getMetaDataWithValues: function (controllerId, tab, callBack) {        
        var url = "Api/ControllerSetup/GetControllerSetupMetaDataWithValues";
        var requestData = { "tabId": tab, "controllerId": controllerId };
        this.ApiRead("ControllerSetup", url,
            function (response) {
                callBack(response);
            },
            null, null, requestData);
    },
    saveMetaData: function (requestData, callBack, errorCallBack) {
        var url = "Api/ControllerSetup/SaveControllerSetupAdvanceData";
        this.ServerRequest("POST",url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); },null, requestData);
    },
    updateMetaData: function (requestData, callBack, errorCallBack) {
        var url = "Api/ControllerSetup/UpdateControllerSetupData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    GetMaxInjectionClassCount: function (controllerId, ecolabAccountNumber, callBack) {
        var url = "Api/ControllerSetup/GetMaxInjectionClassesCount";
        var requestData = { "controllerId": controllerId, "ecolabAccountNumber": ecolabAccountNumber };
        this.ApiRead("ControllerSetup", url,
            function (response) {
                callBack(response);
            },
            null, null, requestData);
    },

};

var base = new Ecolab.Model.Common();
Ecolab.Model.ControllerSetupAdvanceModelProxy.prototype = $.extend({}, Ecolab.Model.ControllerSetupAdvanceModelProxy.prototype, base);
Ecolab.Model.ControllerSetupAdvanceModelProxy.prototype.base = base;