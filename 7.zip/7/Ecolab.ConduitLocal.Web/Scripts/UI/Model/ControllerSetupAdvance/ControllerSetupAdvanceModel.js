Ecolab.Model.ControllerSetupAdvanceModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onGetMetaDataReceived: null,
            onMetaDataSaved: null,
            onMetaDataSavedFailed: null,
            onMaxInjectionClassCountRecieved: null,
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ControllerSetupAdvanceModelProxy = new Ecolab.Model.ControllerSetupAdvanceModelProxy();
};

Ecolab.Model.ControllerSetupAdvanceModel.prototype = {
    init: function () {
    },
    getMetaData: function (tabId, controllerId) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.getMetaData(tabId, controllerId, function (metaData) {
            _this.onGetMetaDataReceived(metaData);
        });
    },
    getMetaDataWithValues: function (data, tab) {
        var _this = this;
        var controllerId = typeof (data) == 'object' ? data.controllerId : data;
        this.ControllerSetupAdvanceModelProxy.getMetaDataWithValues(controllerId, tab, function (metaData) {
            _this.onGetMetaDataWithValuesReceived(metaData);
        });
    },
    saveMetaData: function (metaDatatoSave, isSaveAndClose) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.saveMetaData(metaDatatoSave,
            function (data) { _this.onMetaDataSaved(data, isSaveAndClose); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    updateMetaData: function (metaDatatoSave, isSaveAndClose) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.updateMetaData(metaDatatoSave,
            function () { _this.onMetaDataSaved(isSaveAndClose); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    getControllerUIData:function(controllerId, callBackData){
        var _this=this;
        this.ControllerSetupAdvanceModelProxy.getControllerUIData(controllerId, function (ControllerSetupData) {
            _this.onUIDataLoaded(ControllerSetupData, callBackData);
        });
    },
    onGetMetaDataReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataReceived(metadata);
    },
    onGetMetaDataWithValuesReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataWithValuesReceived(metadata);
    },
    onMetaDataSaved: function (data, isSaveAndClose) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSaved(data, isSaveAndClose);
    },
    onMetaDataSavedFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSavedFailed(data, exception);
    },
    GetMaxInjectionClassCount: function (controllerId, ecolabAccountNumber) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.GetMaxInjectionClassCount(controllerId, ecolabAccountNumber, function (count) {
            _this.settings.eventHandlers.onMaxInjectionClassCountRecieved(count);
        });
    }
};

