Ecolab.Model.ControllerSetupModelProxy = function () {
};

Ecolab.Model.ControllerSetupModelProxy.prototype =
{
    loadControllerModelData: function (regionId, callBack) {
        var url = "Api/ControllerSetup/GetControllerModelsDetails";
        var requestData = { "regionId": regionId };
        this.ApiRead("ControllerSetup", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadControllerTypeData: function (controllerModel, callBack) {
        var url = "Api/ControllerSetup/GetControllerTypesDetails";
        var requestData = { "controllerModelId": controllerModel };
        this.ApiRead("ControllerSetup", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    getMetaData: function (controllerModelId, controllerTypeId, tab, callBack) {
        var url = "Api/ControllerSetup/GetControllerSetupMetaData";
        var requestData = { "tabId": tab, "controllerModelId": controllerModelId, "controllerTypeId": controllerTypeId };
        this.ApiRead("ControllerSetup", url,
            function (response) {
                callBack(response);
            },
            null, null, requestData);
    },
    getMetaDataWithValues: function (controllerId, tab, callBack) {        
        var url = "Api/ControllerSetup/GetControllerSetupMetaDataWithValues";
        var requestData = { "tabId": tab, "controllerId": controllerId };
        this.ApiRead("ControllerSetup", url,
            function (response) {
                callBack(response);
            },
            null, null, requestData);
    },
    saveMetaData: function (requestData, callBack, errorCallBack) {
        var url = "Api/ControllerSetup/SaveControllerSetupData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateMetaData: function (requestData, callBack, errorCallBack) {
        var url = "Api/ControllerSetup/UpdateControllerSetupData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ControllerSetupModelProxy.prototype = $.extend({}, Ecolab.Model.ControllerSetupModelProxy.prototype, base);
Ecolab.Model.ControllerSetupModelProxy.prototype.base = base;