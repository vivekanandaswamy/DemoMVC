; (function ($) {
    $.fn.fixMeonScroll = function () {
        return this.each(function () {

            var $this = $(this),
                $t_fixed, $fixedColumn, $columnHeaderFix;

            function init() {

                $(".fixed-header, .fixed-column, .fixed-column-header").remove();
                //$("body").css("overflow-x", "hidden");

                $t_fixed = $this.clone();
                $t_fixed.find("tbody").remove().end().addClass("fixed-header").removeClass("original-table").removeAttr("id").insertBefore($this);
                $t_fixed.css("width", $this.width());

                $fixedColumn = $this.clone();
                $fixedColumn.find('th:not(:first-child), td:not(:first-child)').remove().end().addClass('fixed-column').removeClass("original-table").removeAttr("id").insertBefore($this);
                $this.parent().css("overflow-x", "auto");

                $columnHeaderFix = $this.clone();
                $columnHeaderFix.find("th:not(:first-child), tbody").remove().end().addClass("fixed-column-header").removeClass("original-table").removeAttr("id").insertBefore($this)
                    .css({
                        "width": $fixedColumn.outerWidth(),
                        "top": $this.parent().parent().prev().height(),
                        "left": $("#divDetails").offset().left
                    });
                resizeTable();

                $this.find("a.toggler").off().on('click', function () {
                    $('tr.OtherRows').toggle();
                    $(this).find("i").toggleClass("glyphicon-plus, glyphicon-minus");
                    resizeTable();
                });

                $fixedColumn.off().on("click", "a.toggler", function () {
                    $('tr.OtherRows').toggle();
                    $(this).find("i").toggleClass("glyphicon-plus, glyphicon-minus");
                    resizeTable();
                });
            }

            function scrollFixed() {
                var offset = $(this).scrollTop(),
                    tableOffsetTop = $this.offset().top - $this.parent().parent().prev().height(),
                    tableOffsetBottom = tableOffsetTop + $this.height() - $this.find("thead").height();

                if (offset < tableOffsetTop || offset > tableOffsetBottom) {
                    $t_fixed.hide();
                }
                else if (offset >= tableOffsetTop && offset <= tableOffsetBottom && $t_fixed.is(":hidden")) {
                    $t_fixed.show();
                    $t_fixed.css("width", $this.width());
                }
                if ($t_fixed.is(":visible")) {
                    $this.parent().parent().prev().addClass("fixed");
                }
                else {
                    $this.parent().parent().prev().removeClass("fixed");
                }
            }

            function scrollFixedHorizontal() {
                var tableWth = $this.width(),
                    containerWth = $this.parent().parent().width();
                if (tableWth <= containerWth) {
                    $fixedColumn.hide();
                }
                else {
                    $fixedColumn.show();
                }
            }

            function resizeTable() {
                $t_fixed.css("width", $this.width());
                $t_fixed.find("th").each(function (i, elem) {
                    $(this).css("width", $this.find('th:eq(' + i + ')').outerWidth());
                });

                $fixedColumn.find('tr').each(function (i, elem) {
                    $(this).height($this.find('tr:eq(' + i + ')').height());
                });

                $columnHeaderFix.find("th").each(function (i, elem) {
                    $(this).css("min-width", $this.find('th:eq(' + i + ')').outerWidth());
                });

                $columnHeaderFix.find('tr').each(function (i, elem) {
                    $(this).height($this.find('tr:eq(' + i + ')').height());
                });

            }

            $(window).scroll(function () {
                scrollFixed();
                var topPosition = $(window).scrollTop() - $this.offset().top + $t_fixed.height() + $this.parent().parent().prev().height();
                $t_fixed.css("top", topPosition);

                if ($this.parent().parent().prev().hasClass("fixed")) {
                    $(".filter-row").width($this.parent().parent().width());
                }
                else {
                    $(".filter-row").width("auto");
                }

                if ($t_fixed.is(":visible")) {
                    $columnHeaderFix.show();
                }
                else {
                    $columnHeaderFix.hide();
                }
            });

            $(".reporttable-outer").scroll(function () {
                scrollFixedHorizontal();

                if ($t_fixed.is(":visible")) {
                    $columnHeaderFix.show();
                }
                else {
                    $columnHeaderFix.hide();
                }
            });

            init();
        });
    };
})(jQuery);