﻿/*
Use BlockUI to show a confirmation dialog with callbacks for yes/no/ok/cancel

*/

; (function($) {
    Ecolab.Views.ConfirmDialog = function() {
        this.initialized = false;
        this.init = function(options) {
            var defaults = {
                TemplateUri: ['/Scripts/UI/CommonTemplates/ConfirmDialog.html'],
                containerSelector: '#ConfirmDialog'
            };
            this.options = $.extend(defaults, options);

            var _this = this;

            this.tm = new TemplateManager({
                templateName: 'confirmPopUp',
                templateUri: this.options.TemplateUri,
                parameters: [],
                containerElement: this.options.containerSelector,
                eventHandlers: {
                    onRendered: _this.onRendered
                }
            });
            this.initialized = true;
        }
        this.setData = function(dialogOptions) {
            var defaults = {
                HeaderText: 'Are you sure?',
                BodyMessage: '',
                Buttons: {
                    Yes: {
                        Callback: null,
                        CallbackParameters: null
                    },
                    Cancel: {
                        Callback: null,
                        CallbackParameters: null
                    },
                    No: {
                        Callback: null,
                        CallbackParameters: null
                    },
                    OK: {
                        Callback: null,
                        CallbackParameters: null
                    },
                    Delete: {
                        Callback: null,
                        CallbackParameters: null
                    },
                    Save: {
                        Callback: null,
                        CallbackParameters: null
                    }
                },
                blockSelector: '.Container_Table'
            };
            this.dialogOptions = $.extend(defaults, dialogOptions);

            this.tm.Render(this.dialogOptions, this);
        };

        //attach events to buttons

        this.onRendered = function (context) {

            $(".k-tooltip").parent(".k-animation-container").hide();
            $(".page-content, #topnav, #leftnav-holder").addClass("blur");
            var container = $(context.options.containerSelector);
            $(context.dialogOptions.blockSelector).block({ message: container });
            var $dialog = $(".ctmdialog-window");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
            $("body").css("overflow-y", "hidden");
            //attach events
            container.find('.imbYes').bind("click", { context: context }, context.yesClicked);
            container.find('.imbNo').bind("click", { context: context }, context.noClicked);
            container.find('.imbCancel').bind("click", { context: context }, context.cancelClicked);
            container.find('.imbOk').bind("click", { context: context }, context.okClicked);
            container.find('.imbDelete').bind("click", { context: context }, context.deleteClicked);
            container.find('.imbSave').bind("click", { context: context }, context.saveClicked);
        }
        this.yesClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.Yes.Callback) dialogOptions.Buttons.Yes.Callback(dialogOptions.Buttons.Yes.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        this.noClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.No.Callback) dialogOptions.Buttons.No.Callback(dialogOptions.Buttons.No.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        this.cancelClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.Cancel.Callback) dialogOptions.Buttons.Cancel.Callback(dialogOptions.Buttons.Cancel.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        this.okClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.Ok.Callback) dialogOptions.Buttons.Ok.Callback(dialogOptions.Buttons.Ok.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        this.deleteClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.Delete.Callback) dialogOptions.Buttons.Delete.Callback(dialogOptions.Buttons.Delete.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        this.saveClicked = function(event) {
            var _this = event.data.context;
            var dialogOptions = _this.dialogOptions;
            $(dialogOptions.blockSelector).unblock();
            if (dialogOptions.Buttons.Save.Callback) dialogOptions.Buttons.Save.Callback(dialogOptions.Buttons.Save.CallbackParameters);
            $(".page-content, #topnav, #leftnav-holder").removeClass("blur");
            $("body").css("overflow-y", "auto");
        }
        $(document).on('keyup', function (e) {
            if (e.which == 27) {
                $('.imbNo').trigger('click');
            }
        });

    }
})(jQuery);
