﻿// -----------------------------------------------------------------------
// <copyright file="WebMappingProfile.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Objects Mapping </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Infra
{
    using System;
    using System.Globalization;
	using AutoMapper;
    using Ecolab.ConduitLocal.Web.Models;
	using Ecolab.Models;
	using Ecolab.Models.Common;
	using Ecolab.Models.ControllerSetup;
	using Ecolab.Models.ControllerSetup.Pumps;
	using Ecolab.Models.Default;
	using Ecolab.Models.ManualInput;
	using Ecolab.Models.ManualInput.ManualLabor;
	using Ecolab.Models.ManualInput.Production;
	using Ecolab.Models.ManualInput.Rewash;
	using Ecolab.Models.NavigationMenu;
	using Ecolab.Models.PlantSetup;
	using Ecolab.Models.PlantSetup.Chemical;
	using Ecolab.Models.PlantSetup.Dryer;
	using Ecolab.Models.PlantSetup.Finnisher;
	using Ecolab.Models.PlantSetup.RedFlag;
	using Ecolab.Models.PlantSetup.ShiftLabor;
	using Ecolab.Models.PlantSetup.UserManagement;
	using Ecolab.Models.Reports;
	using Ecolab.Models.StorageTanks;
	using Ecolab.Models.Visualization;
	using Ecolab.Models.Visualization.ConventionalWasher;
	using Ecolab.Models.Visualization.Monitor;
	using Ecolab.Models.WasherGroup;
	using Ecolab.Models.Washers;
	using Ecolab.Models.Washers.Conventional;
	using Ecolab.Models.Washers.Tunnel;
	using Models.Common;
	using Models.ControllerSetup;
	using Models.Default;
	using Models.ManualInput;
	using Models.ManualInput.Batch;
	using Models.ManualInput.Production;
	using Models.NavigationMenu;
	using Models.PlantSetup;
	using Models.PlantSetup.Chemical;
	using Models.PlantSetup.Dryer;
	using Models.PlantSetup.Finnisher;
	using Models.PlantSetup.RedFlag;
	using Models.PlantSetup.ShiftLabor;
	using Models.PlantSetup.UserManagement;
	using Models.Reports;
	using Models.StorageTanks;
	using Models.Visualization;
	using Models.Visualization.ConventionalWasher;
	using Models.Visualization.Monitor;
	using Models.WasherGroup;
	using Models.Washers;
	using Models.Washers.Conventional;
	using Models.Washers.Tunnel;
	using Cell = Ecolab.Models.Reports.TableCells;
	using ChartData = Ecolab.Models.Reports.ChartData;
	using ChartModel = Ecolab.Models.Reports.ReportChart;
	using ChartSettings = Ecolab.Models.Reports.ChartSettings;
	using ChartType = Ecolab.Models.Reports.ChartType;
	using ControllerModel = Models.ControllerSetup.ControllerModel;
	using DashboardsForHome = Ecolab.Models.Visualization.DashboardsForHome;
	using Data = Ecolab.Models.Reports.Data;
	using GroupType = Ecolab.Models.Common.GroupType;
	using LaborTypeCost = Ecolab.Models.PlantSetup.ShiftLabor.LaborTypeCost;
	using MachinesForWasherGroupType = Ecolab.Models.Visualization.Monitor.MachinesForWasherGroupType;
	using ManualRewash = Models.ManualInput.Rewash.ManualRewash;
	using Model = Ecolab.Models;
	using MonitorDetails = Ecolab.Models.Visualization.Monitor.MonitorDetails;
	using PlantUtilityFactorTypes = Ecolab.Models.PlantSetup.PlantUtilityFactorTypes;
	using ProductModel = Ecolab.Models.ControllerSetup.Pumps.ProductModel;
	using Series = Ecolab.Models.Reports.Series;
	using SeriesData = Ecolab.Models.Reports.SeriesData;
	using TableColumn = Ecolab.Models.Reports.TableColumn;
	using TableModel = Ecolab.Models.Reports.ReportTable;
	using TableRow = Ecolab.Models.Reports.TableRow;
	using WasherGroup = Ecolab.Models.WasherGroup.WasherGroup;
	using WasherGroupType = Ecolab.Models.Visualization.Monitor.WasherGroupType;
	using WasherModelSize = Ecolab.Models.Washers.Tunnel.WasherModelSize;
	using WasherModelSizeModel = Models.Washers.Tunnel.WasherModelSizeModel;
	using WebModel = Models;
	using XAxis = Ecolab.Models.Reports.XAxis;

    /// <summary>
    ///     class for WebMappingProfile
    /// </summary>
    public class WebMappingProfile : Profile
    {
        /// <summary>
        ///     Override this method in a derived class and call the CreateMap method to associate that map with this profile.
        ///     <see cref="T:AutoMapper.Mapper" /> class from this method.
        /// </summary>
        protected override void Configure()
        {
            #region "ControllerSetup"

            //Model to WebModel
            Mapper.CreateMap<MetaData, MetaDataModel>();
            Mapper.CreateMap<ControllerSetupMetaData, ControllerSetupMetaDataModel>();
            Mapper.CreateMap<FieldSource, FieldSourceModel>();
            Mapper.CreateMap<Controller, ControllerModel>();
            Mapper.CreateMap<Ecolab.Models.ControllerSetup.ControllerModel, ControllerModelModel>();
            Mapper.CreateMap<ControllerType, ControllerTypeModel>();
            Mapper.CreateMap<TagManagement, TagManagementModel>();

            //WebModel to Model
            Mapper.CreateMap<ControllerModel, Controller>();
            Mapper.CreateMap<ControllerSetupDataModel, ControllerSetupData>();
            Mapper.CreateMap<TagManagementModel, TagManagement>();

            #endregion

            #region "Formula"

            //Model to WebModel
            Mapper.CreateMap<Model.Formula, WebModel.FormulaModel>();
            Mapper.CreateMap<Model.FormulaSegment, WebModel.FormulaSegmentModel>();
            Mapper.CreateMap<Model.EcolabTextileCategory, EcolabTextileCategoryModel>();
            Mapper.CreateMap<Model.EcolabSaturation, EcolabSaturationModel>();
            Mapper.CreateMap<Model.PlantChainProgram, WebModel.PlantChainProgramModel>();
            Mapper.CreateMap<Model.ChainTextileCategory, ChainTextileCategoryModel>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.FormulaModel, Model.Formula>();

            #endregion

            #region "Contact"

            //Model to WebModel
            Mapper.CreateMap<Model.PlantContact, WebModel.PlantContactModel>();
            Mapper.CreateMap<PlantContactPosition, PlantContactPositionModel>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.PlantContactModel, Model.PlantContact>();

            #endregion

            #region "Customer"

            //Model to WebModel
            Mapper.CreateMap<Model.PlantCustomer, WebModel.PlantCustomerModel>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.PlantCustomerModel, Model.PlantCustomer>();

            #endregion

            #region "Meter"

            //Model to WebModel
            Mapper.CreateMap<Meter, MeterWebModel>();
            Mapper.CreateMap<ResourceMaster, ResourceMasterModel>();
            Mapper.CreateMap<GroupType, GroupTypeModel>();
            Mapper.CreateMap<ParentMeter, ParentMeterModel>();
            Mapper.CreateMap<ConduitController, ConduitControllerModel>();
            Mapper.CreateMap<UOMMeter, UOMMeterModel>();
            Mapper.CreateMap<MachineSetup, MachineSetupModel>();
            Mapper.CreateMap<Meter, MeterModel>();
            //WebModel to Model
            Mapper.CreateMap<MeterWebModel, Meter>();
            Mapper.CreateMap<MeterModel, Meter>();

            #endregion

            #region "Chemicals"

            //Model to WebModel
            Mapper.CreateMap<ProductMaster, WebModel.ProductMasterModel>();
            Mapper.CreateMap<Chemicals, ChemicalsModel>();
			Mapper.CreateMap<SubstituteChemical, SubstituteChemicalModel>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.ProductMasterModel, ProductMaster>();
			Mapper.CreateMap<SubstituteChemicalModel, SubstituteChemical>();

            #endregion

            #region "Plant"

            //Model to WebModel
            Mapper.CreateMap<Model.Plant, WebModel.PlantModel>();
            Mapper.CreateMap<Model.PlantCustAddress, WebModel.PlantCustAddressModel>();
            Mapper.CreateMap<Model.ShippingAddress, WebModel.ShippingAddressModel>();
            Mapper.CreateMap<Model.CurrencyMaster, WebModel.CurrencyMasterModel>();
            Mapper.CreateMap<Model.LanguageMaster, WebModel.LanguageMasterModel>();
            Mapper.CreateMap<Model.DimensionalUnitSystems, WebModel.DimensionalUnitSystemsModel>();
            Mapper.CreateMap<Model.UOMSubUnit, WebModel.UOMSubUnit>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.PlantModel, Model.Plant>();

            #endregion

            #region "RedFlag"

            //Model to WebModel
            Mapper.CreateMap<RedFlag, RedFlagModel>();
            Mapper.CreateMap<RedFlagItem, ItemModel>();
            Mapper.CreateMap<RedFlagLocation, RedFlagLocationModel>();
            Mapper.CreateMap<RedFlagCategory, RedFlagCategoryModel>();

            //WebModel to Model
            Mapper.CreateMap<RedFlagModel, RedFlag>();
            Mapper.CreateMap<RedFlagCategoryModel, RedFlagCategory>();
            #endregion

            #region "Sensor"

            //Model to WebModel
            Mapper.CreateMap<Sensor, SensorWebModel>();
            Mapper.CreateMap<Sensor, SensorModel>();

            Mapper.CreateMap<SensorModel, SensorWebModel>()
                .ForMember(dest => dest.SensorName, opt => opt.MapFrom(src => src.Description))
                .ForMember(dest => dest.CalibrationValue20, opt => opt.MapFrom(src => src.Calibration20mA))
                .ForMember(dest => dest.CalibrationValue4, opt => opt.MapFrom(src => src.Calibration4mA))
                .ForMember(dest => dest.MachineId, opt => opt.MapFrom(src => src.MachineCompartment));

            Mapper.CreateMap<MeterModel, MeterWebModel>();

            Mapper.CreateMap<SensorType, SensorTypeModel>();

            Mapper.CreateMap<UOMSensor, UOMSensorModel>();
            Mapper.CreateMap<SensorChemicalChart, SensorChemicalChartModel>();

            //WebModel to Model
            Mapper.CreateMap<SensorWebModel, Sensor>();
            Mapper.CreateMap<SensorModel, Sensor>();

            #endregion

            #region "ShiftLabour"

            //Model to WebModel
            Mapper.CreateMap<Shift, ShiftModel>();
            Mapper.CreateMap<ShiftBreak, ShiftBreakModel>();
            Mapper.CreateMap<ShiftLabor, ShiftLaborModel>();
            Mapper.CreateMap<LaborType, LaborTypeModel>();
            Mapper.CreateMap<LaborTypeCost, Models.PlantSetup.ShiftLabor.LaborTypeCostModel>();
            Mapper.CreateMap<TargetProduction, Models.PlantSetup.TargetProduction.TargetProduction>();

            //WebModel to Model
            Mapper.CreateMap<ShiftModel, Shift>();
            Mapper.CreateMap<ShiftBreakModel, ShiftBreak>();
            Mapper.CreateMap<ShiftLaborModel, ShiftLabor>();
            Mapper.CreateMap<LaborTypeModel, LaborType>();
            Mapper.CreateMap<Models.PlantSetup.TargetProduction.TargetProduction, TargetProduction>();

            #endregion

            #region "User"

            //Model To Webmodel
            Mapper.CreateMap<Model.UserRoles, WebModel.UserRoles>();

            #endregion

            #region "Utility"

            //Model to WebModel
            Mapper.CreateMap<Utility, UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                DateTime dt = src.InstallDate;
                return dt.ToString("d");
            }));

            Mapper.CreateMap<DeviceType, DeviceTypeModel>();

            Mapper.CreateMap<Utility, UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                DateTime dt = src.InstallDate;
                return dt.ToString("d");
            }));

            Mapper.CreateMap<DeviceType, DeviceTypeModel>();
            Mapper.CreateMap<DeviceModel, DevicemodelModel>();
            Mapper.CreateMap<DeviceType, DeviceTypeModel>();
            Mapper.CreateMap<DeviceModel, DevicemodelModel>();

            //WebModel to Model
            Mapper.CreateMap<UtilityModel, Utility>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                string dt = src.InstallDate;
                return DateTime.Parse(dt,CultureInfo.InvariantCulture);
            }));

            #endregion

            #region "PlantUtility"

            //Model to WebModel
            Mapper.CreateMap<PlantUtilityFactorTypes, Models.PlantSetup.PlantUtilityFactorTypes>();
            Mapper.CreateMap<PlantUtilityWaterTypeMaster, PlantUtilityWaterTypeMasterModel>();
            Mapper.CreateMap<PlantUtilityGasoilTypes, PlantUtilityGasoilTypeModel>();
            Mapper.CreateMap<PlantUtilityDimensionTypes, PlantUtilityDimesionTypesModel>();
            Mapper.CreateMap<Model.PlantUtilityUnitTypes, WebModel.PlantUtilityUnitTypesModel>();
            //WebModel to Model
            Mapper.CreateMap<PlantUtilitySetupModel, PlantUtilitySetup>();

            #endregion

            #region "Dryer"

            //Model to WebModel
            Mapper.CreateMap<Dryer, DryerModel>();
            Mapper.CreateMap<DryerGroup, DryerGroupModel>();
            Mapper.CreateMap<DryerType, DryerTypeModel>();

            //WebModel to Model
            Mapper.CreateMap<DryerModel, Dryer>();
            Mapper.CreateMap<DryerGroupModel, DryerGroup>();
            Mapper.CreateMap<DryerTypeModel, DryerType>();

            #endregion

            #region "WasherGroup"

            //Model to WebModel Mapping.
            Mapper.CreateMap<WasherGroup, Models.WasherGroup.WasherGroup>();
            Mapper.CreateMap<WasherGroupFormula, WasherGroupFormulaModel>();
            Mapper.CreateMap<WashStep, WashStepModel>();
            Mapper.CreateMap<WasherFormulaWashStep, WasherFormulaWashStepModel>();
            Mapper.CreateMap<WasherDosingProduct, WasherDosingProductModel>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.DrainDestinationList, Models.WasherGroup.DrainDestinationList>();
			Mapper.CreateMap<Ecolab.Models.WasherGroup.CopyFormulaContainer, Models.WasherGroup.CopyFormulaContainerModel>();

            //WebModel to Model Mapping.
            Mapper.CreateMap<Models.WasherGroup.WasherGroup, WasherGroup>();
            Mapper.CreateMap<WasherGroupFormulaModel, WasherGroupFormula>();
            Mapper.CreateMap<WashStepModel, WashStep>();
            Mapper.CreateMap<WasherFormulaWashStepModel, WasherFormulaWashStep>();
            Mapper.CreateMap<WasherDosingProductModel, WasherDosingProduct>();
            Mapper.CreateMap<Models.WasherGroup.DrainDestinationList, Ecolab.Models.WasherGroup.DrainDestinationList>();
			Mapper.CreateMap<Models.WasherGroup.CopyFormula, Ecolab.Models.WasherGroup.CopyFormula>();
			Mapper.CreateMap<Models.WasherGroup.CopyFormulaContainerModel, Ecolab.Models.WasherGroup.CopyFormulaContainer>();

            #endregion

            #region "StorageTanks"

            //Model to WebModel
            Mapper.CreateMap<Tanks, TanksModel>();

            //WebModel to Model
            Mapper.CreateMap<TanksModel, Tanks>();

            #endregion

            #region "User Management"

            //Model to WebModel
            Mapper.CreateMap<UserManagement, UserManagementModel>();

            //WebModel to Model
            Mapper.CreateMap<UserManagementModel, UserManagement>();

            #endregion

            #region "Finnisher"

            //Model to WebModel
            Mapper.CreateMap<Finnisher, FinnisherModel>();
            Mapper.CreateMap<FinnisherGroup, FinnisherGroupModel>();
            Mapper.CreateMap<FinnisherType, FinnisherTypeModel>();

            //WebModel to Model
            Mapper.CreateMap<FinnisherModel, Finnisher>();
            Mapper.CreateMap<FinnisherGroupModel, FinnisherGroup>();
            Mapper.CreateMap<FinnisherTypeModel, FinnisherType>();

            #endregion

            #region "Manual Inputs"

            //Model to WebModel
            Mapper.CreateMap<ManualProduction, ManualProductionModel>();
            Mapper.CreateMap<WashProgramSetup, WashProgramSetupModel>();
            Mapper.CreateMap<Ecolab.Models.ManualInput.GroupType, GroupTypeModel>();
            Mapper.CreateMap<ManualLabor, Models.ManualInputs.ManualLabor.ManualLabor>();
            Mapper.CreateMap<ManualBatchData, ManualBatchDataModel>();
            //WebModel to Model
            Mapper.CreateMap<ManualProductionModel, ManualProduction>();
            Mapper.CreateMap<RewashReason, Models.ManualInput.Rewash.RewashReason>();
            Mapper.CreateMap<ManualRewash, Ecolab.Models.ManualInput.Rewash.ManualRewash>();
            Mapper.CreateMap<Ecolab.Models.ManualInput.Rewash.ManualRewash, ManualRewash>();
            Mapper.CreateMap<Models.ManualInputs.ManualLabor.ManualLabor, ManualLabor>();
            Mapper.CreateMap<ManualBatchDataModel, ManualBatchData>();

            #endregion

            #region "Pumps"

            //Model to WebModel
            Mapper.CreateMap<PumpsModel, Models.ControllerSetup.Pumps.PumpsModel>();
            Mapper.CreateMap<ProductModel, Models.ControllerSetup.Pumps.ProductModel>();
            Mapper.CreateMap<MixingVesselsModel, Models.ControllerSetup.Pumps.MixingVesselsModel>();
            Mapper.CreateMap<SetupDosingLine, Models.ControllerSetup.Pumps.SetupDosingLineModel>();
            //WebModel to Model
            Mapper.CreateMap<Models.ControllerSetup.Pumps.PumpsModel, PumpsModel>();
            Mapper.CreateMap<Models.ControllerSetup.Pumps.ProductModel, ProductModel>();
            Mapper.CreateMap<Models.ControllerSetup.Pumps.MixingVesselsModel, MixingVesselsModel>();
            Mapper.CreateMap<Models.ControllerSetup.Pumps.SetupDosingLineModel, SetupDosingLine>();
            #endregion

            #region "Visualization"

            //Model to WebModel
            Mapper.CreateMap<Tunnel, TunnelModel>();
            Mapper.CreateMap<Compartment, CompartmentModel>();
            #endregion

            #region TunnelStep

            //Model to WebModel
            Mapper.CreateMap<TunnelWashStep, TunnelWashStepModel>();
            Mapper.CreateMap<TunnelWashStepProducts, TunnelWashStepProductsModel>();
            //WebModel to Model
            Mapper.CreateMap<TunnelWashStepModel, TunnelWashStep>();
            Mapper.CreateMap<TunnelWashStepProductsModel, TunnelWashStepProducts>();

            #endregion

            #region Washers

            //Model to WebModel
            Mapper.CreateMap<Washers, WashersModel>();
            Mapper.CreateMap<Alarms, AlarmsModel>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.InjectionData, Models.WasherGroup.InjectionData>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.InjectionDetails, Models.WasherGroup.InjectionDetails>();
            //WebModel to Model
            Mapper.CreateMap<WashersModel, Washers>();
            Mapper.CreateMap<AlarmsModel, Alarms>();
            Mapper.CreateMap<Models.WasherGroup.InjectionData, Ecolab.Models.WasherGroup.InjectionData>();
            Mapper.CreateMap<Models.WasherGroup.InjectionDetails, Ecolab.Models.WasherGroup.InjectionDetails>();

            #endregion

            #region Tunnel

            //Model to WebModel
            Mapper.CreateMap<TunnelGeneral, TunnelGeneralModel>();
            Mapper.CreateMap<WashersList, WashersListModel>();
            Mapper.CreateMap<WasherModelSize, WasherModelSizeModel>();
            Mapper.CreateMap<PressExtractor, PressExtractorModel>();
            Mapper.CreateMap<PumpsProductList, PumpsProductListModel>();
            Mapper.CreateMap<TunnelCompartment, TunnelCompartmentModel>();
            Mapper.CreateMap<PumpAssociation, PumpAssociationModel>();
            Mapper.CreateMap<Ecolab.Models.Washers.Tunnel.TunnelConnections, Web.Models.Washers.Tunnel.TunnelConnections>().ReverseMap();

            //WebModel to Model
            Mapper.CreateMap<TunnelGeneralModel, TunnelGeneral>();
            Mapper.CreateMap<WashersListModel, WashersList>();
            Mapper.CreateMap<WasherModelSizeModel, WasherModelSize>();
            Mapper.CreateMap<PressExtractorModel, PressExtractor>();
            Mapper.CreateMap<PumpsProductListModel, PumpsProductList>();
            Mapper.CreateMap<TunnelCompartmentModel, TunnelCompartment>();
            Mapper.CreateMap<PumpAssociationModel, PumpAssociation>();

            #endregion

            //Model to WebModel
            Mapper.CreateMap<LaborCost, LaborCostModel>();
            //WebModel to Model
            Mapper.CreateMap<LaborCostModel, LaborCost>();

            //Model to WebModel for Alarm
            Mapper.CreateMap<Model.Alarm, WebModel.AlarmModel>();
            //WebModel to Model for Alarm
            Mapper.CreateMap<WebModel.AlarmModel, Model.Alarm>();

            //Model to WebModel for WasherGroupType
            Mapper.CreateMap<WasherGroupType, Models.Visualization.Monitor.WasherGroupType>();
            //WebModel to Model for WasherGroupType
            Mapper.CreateMap<Models.Visualization.Monitor.WasherGroupType, WasherGroupType>();

            //Model to WebModel for Machines in MonitorSetup
            Mapper.CreateMap<MachinesForWasherGroupType, Models.Visualization.Monitor.MachinesForWasherGroupType>();
            Mapper.CreateMap<MonitorDetails, Models.Visualization.Monitor.MonitorDetails>();
            Mapper.CreateMap<MonitorSetUp, MonitorSetupModel>();
            //WebModel to Model for Machines in MonitorSetup
            Mapper.CreateMap<Models.Visualization.Monitor.MachinesForWasherGroupType, MachinesForWasherGroupType>();

            //Model to WebModel for Conventional Washer dashboard Visualization
            Mapper.CreateMap<BatchDetails, BatchDetailsModel>();
            Mapper.CreateMap<ConventionalWasher, ConventionalWasherModel>();
            Mapper.CreateMap<BreakAndTimeline, BreakAndTimelineModel>();

            // Model for washer & TUnnel tags mapping.
            Mapper.CreateMap<ConventionalTagModel, ConventionalTags>();
            Mapper.CreateMap<TunnelTagsModel, TunnelTags>();

            Mapper.CreateMap<ConventionalTags, ConventionalTagModel>();
            Mapper.CreateMap<TunnelTags, TunnelTagsModel>();
            //Model to WebModel for DashboardsForHome
            Mapper.CreateMap<DashboardsForHome, Models.Visualization.DashboardsForHome>();

            #region Conventional

            //Model to WebModel
            Mapper.CreateMap<ConventionalGeneral, ConventionalGeneralModel>();
            Mapper.CreateMap<WasherModeList, WasherModeListModel>();
            Mapper.CreateMap<WasherModelList, WasherModelListModel>();
            Mapper.CreateMap<Ecolab.Models.Washers.Conventional.WasherModelSize, Models.Washers.Conventional.WasherModelSizeModel>();
            Mapper.CreateMap<LfsWasherNumber, LfsWasherNumberModel>();

            //WebModel to Model
            Mapper.CreateMap<ConventionalGeneralModel, ConventionalGeneral>();
            Mapper.CreateMap<WasherModeListModel, WasherModeList>();
            Mapper.CreateMap<WasherModelListModel, WasherModelList>();
            Mapper.CreateMap<Models.Washers.Conventional.WasherModelSizeModel, Ecolab.Models.Washers.Conventional.WasherModelSize>();
            Mapper.CreateMap<LfsWasherNumberModel, LfsWasherNumber>();

            #endregion

            //Model to WebModel for Reports
            Mapper.CreateMap<Report, ReportLayoutModel>();
            Mapper.CreateMap<ReportFilter, ReportFilterModel>();
            Mapper.CreateMap<ReportFilterList, ReportFilterListModel>();
            Mapper.CreateMap<ReportAllColumns, ReportAllColumnsModel>();
            Mapper.CreateMap<RibbonOption, RibbonOptionModel>();
            Mapper.CreateMap<ReportSwitchMode, ReportSwitchModeModel>();
            Mapper.CreateMap<ReportSettings, ReportSettingsModel>();
            Mapper.CreateMap<ReportSettings, ReportSettingsModel>();

            Mapper.CreateMap<Data, Models.Reports.Data>();
            Mapper.CreateMap<ReportSettingsModel, ReportSettings>();

            Mapper.CreateMap<ReportTableAndChart, ReportTableAndChartModel>();
            Mapper.CreateMap<Ecolab.Models.Reports.ReportTable, Models.Reports.ReportTable>();
            Mapper.CreateMap<Ecolab.Models.Reports.TableCells, Models.Reports.TableCells>();
            Mapper.CreateMap<Ecolab.Models.Reports.TableColumn, Models.Reports.TableColumn>();
            Mapper.CreateMap<Ecolab.Models.Reports.TableRow, Models.Reports.TableRow>();
            Mapper.CreateMap<Ecolab.Models.Reports.Filter, Models.Reports.FilterModel>();
            Mapper.CreateMap<Ecolab.Models.Reports.SelectList, Models.Reports.SelectListModel>();
            Mapper.CreateMap<Ecolab.Models.Reports.ReportSubView, Models.Reports.ReportSubView>();
            Mapper.CreateMap<Ecolab.Models.Reports.Settings, Models.Reports.SettingsModel>();

            //WebModel to Model for Conventional Washer dashboard Visualization
            Mapper.CreateMap<ReportLayoutModel, Report>();
            Mapper.CreateMap<ReportFilterModel, ReportFilter>();
            Mapper.CreateMap<ReportAllColumnsModel, ReportAllColumns>();
            Mapper.CreateMap<RibbonOptionModel, RibbonOption>();
            Mapper.CreateMap<ReportSwitchModeModel, ReportSwitchMode>();
            Mapper.CreateMap<ReportSettings, ReportSettingsModel>();

            Mapper.CreateMap<Models.Reports.Data, Data>();

            Mapper.CreateMap<ReportModel, Models.Reports.ReportModel>();
            Mapper.CreateMap<SettingsModel, Models.Reports.SettingsModel>();
            Mapper.CreateMap<ReportChart, Models.Reports.ReportChartModel>();
            Mapper.CreateMap<ChartData, Models.Reports.ChartData>();
            Mapper.CreateMap<XAxis, Models.Reports.XAxis>();
            Mapper.CreateMap<TableColumn, Models.Reports.TableColumn>();
            Mapper.CreateMap<TableRow, Models.Reports.TableRow>();
            Mapper.CreateMap<ChartSettings, Models.Reports.ChartSettings>();
            Mapper.CreateMap<ChartType, Models.Reports.ChartType>();

            Mapper.CreateMap<ReportRibbonOptions, ReportRibbonOptionsModel>();
            Mapper.CreateMap<SeriesData, Models.Reports.SeriesData>();
            Mapper.CreateMap<Series, Models.Reports.Series>();
            Mapper.CreateMap<ReportTableAndChartModel, ReportTableAndChart>();
            Mapper.CreateMap<Models.Reports.ReportTable, Ecolab.Models.Reports.ReportTable>();
            Mapper.CreateMap<Models.Reports.TableCells, Ecolab.Models.Reports.TableCells>();
            Mapper.CreateMap<Models.Reports.TableColumn, Ecolab.Models.Reports.TableColumn>();
            Mapper.CreateMap<Models.Reports.TableRow, Ecolab.Models.Reports.TableRow>();
            Mapper.CreateMap<Models.Reports.FilterModel, Ecolab.Models.Reports.Filter>();
            Mapper.CreateMap<Models.Reports.SelectListModel, Ecolab.Models.Reports.SelectList>();
            Mapper.CreateMap<Models.Reports.ReportSubView, Ecolab.Models.Reports.ReportSubView>();
            Mapper.CreateMap<Models.Reports.SettingsModel, Ecolab.Models.Reports.Settings>();

            //Model to WebModel for Left NavigationMenu
            Mapper.CreateMap<NavigationMenu, NavigationMenuModel>();

            //Model to WebModel
            Mapper.CreateMap<Model.UserAudit, WebModel.UserAuditModel>();

            //WebModel to Model
            Mapper.CreateMap<WebModel.UserAuditModel, Model.UserAudit>();

            //PlcTags WebModel to Model
            Mapper.CreateMap<WebModel.PlcTagModel, Model.PlcTag>();

            //PlcTags Model to WebModel
            Mapper.CreateMap<Model.PlcTag, WebModel.PlcTagModel>();

            //Portlet Model to WebModel
            Mapper.CreateMap<Model.Portlet, WebModel.PortletModel>();

            //Portlet WebModel to Model
            Mapper.CreateMap<WebModel.PortletModel, Model.Portlet>();

            //shift summary Entity to Model
            Mapper.CreateMap<ShiftSummary, ShiftSummaryModel>();

            //ControllerInfoforPLC Model to WebModel
            Mapper.CreateMap<ControllerInfoForPlc, ControllerInfoForPlcModel>();

            //WebModel to Model
            Mapper.CreateMap<ControllerInfoForPlcModel, ControllerInfoForPlc>();

            // Model to WebModel
            Mapper.CreateMap<Ecolab.Models.ExchangeRate, WebModel.ExchangeRate>();

            // Model to WebModel
            Mapper.CreateMap<Ecolab.Models.TagTypes, WebModel.TagTypeModel>();

            Mapper.CreateMap<WasherFlushTime, WasherFlushTimeModel>().ReverseMap();
            Mapper.CreateMap<WasherTimeOutMachine, WasherTimeOutMachineModel>().ReverseMap();

            Mapper.CreateMap<PumpModelsModel, Models.ControllerSetup.Pumps.PumpModelsModel>().ReverseMap();
            Mapper.CreateMap<ControllerDataModel, Models.ControllerSetup.Pumps.ControllerDataModel>().ReverseMap();
            Mapper.CreateMap<LineCompartmentMappingModel, Models.ControllerSetup.Pumps.LineCompartmentMappingModel>().ReverseMap();

            Mapper.CreateMap<ProductDeviation, ProductDeviationModel>().ReverseMap();
            Mapper.CreateMap<PumpsAndMECount, PumpsAndMECountModel>().ReverseMap();

			Mapper.CreateMap<Ecolab.Models.Washers.Tunnel.AnalogueDosing, Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.AnalogueDosing>().ReverseMap();

            // Model to WebModel
            Mapper.CreateMap<Ecolab.Models.MissingFields, Models.MissingFieldsModel>().ReverseMap();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.TunnelAnalogueControl, Models.WasherGroup.TunnelAnalogueControlModel>().ReverseMap();
            //
            Mapper.CreateMap<Ecolab.Models.WasherGroup.ConventionalAnalogueControl, Models.WasherGroup.ConventionalAnalogueControl>();
            Mapper.CreateMap<Models.WasherGroup.ConventionalAnalogueControl, Ecolab.Models.WasherGroup.ConventionalAnalogueControl>().ReverseMap();
            // Model to WebModel
            Mapper.CreateMap<Ecolab.Models.WasherGroup.WasherFormulaConventionalAnalogueControl, Models.WasherGroup.WasherFormulaConventionalAnalogueControl>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.WasherFormulaTunnelAnalogueControl, Models.WasherGroup.WasherFormulaTunnelAnalogueControl>();
            // Model to WebModel
            Mapper.CreateMap<Ecolab.Models.Common.PLCDiscrepancyModel, Models.Common.PLCDiscrepancyModel>().ReverseMap();
        }
    }
}