﻿// -----------------------------------------------------------------------
// <copyright file="WindsorControllerFactory.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WindsorControllerFactory object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Infra
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Web.Mvc;
    using System.Web.Routing;
    using Castle.MicroKernel.Registration;
    using Castle.Windsor;

    /// <summary>
    ///     Windsor Controller Factory
    /// </summary>
    public class WindsorControllerFactory : DefaultControllerFactory
    {
        /// <summary>
        ///     IWindsorContainer
        /// </summary>
        private readonly IWindsorContainer container;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WindsorControllerFactory" /> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public WindsorControllerFactory(IWindsorContainer container)
        {
            this.container = container;
            IEnumerable<Type> controllerTypes = from t in Assembly.GetExecutingAssembly().GetTypes() where typeof(IController).IsAssignableFrom(t) select t;
            foreach(Type t in controllerTypes)
            {
                container.Register(Component.For(t).LifeStyle.Transient);
            }
        }

        /// <summary>
        ///     Retrieves the controller instance for the specified request context and controller type.
        /// </summary>
        /// <param name="requestContext">The context of the HTTP request, which includes the HTTP context and route data.</param>
        /// <param name="controllerType">The type of the controller.</param>
        /// <returns>
        ///     The controller instance.
        /// </returns>
        /// <exception cref="T:System.Web.HttpException">
        ///     <paramref name="controllerType" /> is null.
        /// </exception>
        /// <exception cref="T:System.ArgumentException">
        ///     <paramref name="controllerType" /> cannot be assigned.
        /// </exception>
        /// <exception cref="T:System.InvalidOperationException">
        ///     An instance of <paramref name="controllerType" /> cannot be
        ///     created.
        /// </exception>
        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            if(controllerType == null)
            {
                return base.GetControllerInstance(requestContext, controllerType);
            }
            return (IController)this.container.Resolve(controllerType);
        }
    }
}