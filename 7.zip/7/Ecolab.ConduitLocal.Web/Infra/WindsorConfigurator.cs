﻿// -----------------------------------------------------------------------
// <copyright file="WindsorConfigurator.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WindsorConfigurator object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Infra
{
    using System.Web.Http.Controllers;
    using Castle.Facilities.Logging;
    using Castle.MicroKernel.Registration;
    using Ecolab.Infra;
    using Services;
    using Services.ControllerSetup;
    using Services.ControllerSetup.Pumps;
    using Services.Default;
    using Services.Home;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Default;
    using Services.Interfaces.Home;
    using Services.Interfaces.ManualInput;
    using Services.Interfaces.ManualInputs;
    using Services.Interfaces.NavigationMenu;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.PlantSetup.Dryer;
    using Services.Interfaces.PlantSetup.Finnisher;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.Interfaces.Plc;
    using Services.Interfaces.Reports;
    using Services.Interfaces.StorageTanks;
    using Services.Interfaces.Visualization;
    using Services.Interfaces.Visualization.ConventionalWasher;
    using Services.Interfaces.Visualization.Monitor;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Conventional;
    using Services.Interfaces.Washers.Tunnel;
    using Services.ManualInput;
    using Services.ManualInputs;
    using Services.NavigationMenu;
    using Services.PlantSetup;
    using Services.PlantSetup.Dryer;
    using Services.PlantSetup.Finnisher;
    using Services.PlantSetup.ShiftLabor;
    using Services.Plc;
    using Services.Reports;
    using Services.StorageTanks;
    using Services.Visualization;
    using Services.Visualization.ConventionalWasher;
    using Services.Visualization.Monitor;
    using Services.WasherGroup;
    using Services.Washers;
    using Services.Washers.conventional;
    using Services.Washers.Tunnel;
    using Shared.Authentication;

    /// <summary>
    ///     class WindsorConfigurator
    /// </summary>
    public class WindsorConfigurator
    {
        /// <summary>
        ///     Configure for service
        /// </summary>
        public static void Configure()
        {
            IoC.Container.AddFacility<LoggingFacility>(f => f.UseLog4Net());
            WindsorRegistrar.Register(typeof(IFormsAuthentication), typeof(FormAuthService));
            WindsorRegistrar.Register(typeof(IUserService), typeof(UserService));
            WindsorRegistrar.Register(typeof(IPlantCustomerService), typeof(PlantCustomerService));
            WindsorRegistrar.Register(typeof(IPlantService), typeof(PlantService));
            WindsorRegistrar.Register(typeof(IPlantContactService), typeof(PlantContactService));
            WindsorRegistrar.Register(typeof(IProductMasterService), typeof(ProductMasterService));
            WindsorRegistrar.Register(typeof(ITrendingChartService), typeof(TrendingChartService));
            WindsorRegistrar.Register(typeof(ICustomPrincipal), typeof(CustomPrincipal));
            WindsorRegistrar.Register(typeof(IMeterService), typeof(MeterService));
            WindsorRegistrar.Register(typeof(ISensorService), typeof(SensorService));
            WindsorRegistrar.Register(typeof(IUtilityService), typeof(UtilityService));
            WindsorRegistrar.Register(typeof(IProgramMasterService), typeof(ProgramMasterService));
            WindsorRegistrar.Register(typeof(IControllerSetupService), typeof(ControllerSetupService));
            WindsorRegistrar.Register(typeof(IPlantUtilityService), typeof(PlantUtilityService));
            WindsorRegistrar.Register(typeof(IShiftBreakService), typeof(ShiftBreakService));
            WindsorRegistrar.Register(typeof(ILaborService), typeof(LaborService));
            WindsorRegistrar.Register(typeof(IRedFlagService), typeof(RedFlagService));
            WindsorRegistrar.Register(typeof(IDryerService), typeof(DryerService));
            WindsorRegistrar.Register(typeof(IDryerGroupService), typeof(DryerGroupService));
            WindsorRegistrar.Register(typeof(IWasherGroupService), typeof(WasherGroupService));
            WindsorRegistrar.Register(typeof(IWasherGroupFormulaService), typeof(WasherGroupFormulaService));
            WindsorRegistrar.Register(typeof(IStorageTanksService), typeof(StorageTanksService));
            WindsorRegistrar.Register(typeof(IUserManagementService), typeof(UserManagementService));
            WindsorRegistrar.Register(typeof(IFinnisherGroupService), typeof(FinnisherGroupService));
            WindsorRegistrar.Register(typeof(IFinnisherService), typeof(FinnisherService));
            WindsorRegistrar.Register(typeof(IManualProductionDataEntryService), typeof(ManualProductionDataEntryService));
            WindsorRegistrar.Register(typeof(IPumpsService), typeof(PumpsServices));
            WindsorRegistrar.Register(typeof(IManualRewashService), typeof(ManualRewashService));
            WindsorRegistrar.Register(typeof(IManualUtilityService), typeof(ManualUtilityService));
            WindsorRegistrar.Register(typeof(IManualBatchDataService), typeof(ManualBatchDataService));
            WindsorRegistrar.Register(typeof(IManualLaborService), typeof(ManualLaborService));
            WindsorRegistrar.Register(typeof(IDashboardService), typeof(DashboardService));
            WindsorRegistrar.Register(typeof(IWasherServices), typeof(WasherServices));
            WindsorRegistrar.Register(typeof(ITunnelGeneralServices), typeof(TunnelGeneralServices));
            WindsorRegistrar.Register(typeof(ILaborCostService), typeof(LaborCostService));
            WindsorRegistrar.Register(typeof(IConventionalWasherDashboardService), typeof(ConventionalWasherDashboardService));
            IoC.Container.Register(Classes.FromThisAssembly().BasedOn<IHttpController>().LifestyleScoped());
            WindsorRegistrar.RegisterAllFromAssemblies("Ecolab.ConduitLocal.Web");
            WindsorRegistrar.Register(typeof(IMyProfileService), typeof(MyProfileService));
            WindsorRegistrar.Register(typeof(IAlarmService), typeof(AlarmService));
            WindsorRegistrar.Register(typeof(IMonitorSetupService), typeof(MonitorSetupService));
            WindsorRegistrar.Register(typeof(IConventionalGeneralServices), typeof(ConventionalGeneralServices));
            WindsorRegistrar.Register(typeof(ITunnelCompartmentServices), typeof(TunnelCompartmentServices));
            WindsorRegistrar.Register(typeof(IReportCategoryService), typeof(ReportCategoryService));
            WindsorRegistrar.Register(typeof(IRibbonOptionService), typeof(RibbonOptionService));
            WindsorRegistrar.Register(typeof(IAlarmReportService), typeof(AlarmReportService));
            WindsorRegistrar.Register(typeof(IProductionSummaryReportService), typeof(ProductionSummaryReportService));
            WindsorRegistrar.Register(typeof(INavigationMenuService), typeof(NavigationMenuService));
            WindsorRegistrar.Register(typeof(IProductionMixReportService), typeof(ProductionMixReportService));
            WindsorRegistrar.Register(typeof(IPlcService), typeof(PlcService));
            WindsorRegistrar.Register(typeof(IDefaultService), typeof(DefaultService));
            WindsorRegistrar.Register(typeof(IInjectionService), typeof(InjectionService));
            WindsorRegistrar.Register(typeof(IReportSubView), typeof(ReportSubViewService));
            WindsorRegistrar.Register(typeof(ITagManagementService), typeof(TagManagementService));
            WindsorRegistrar.Register(typeof(IFlushTimesAndSetupTomServices), typeof(FlushTimesAndSetupTomServices));
            WindsorRegistrar.Register(typeof(IProductDeviationService), typeof(ProductDeviationService));
			WindsorRegistrar.Register(typeof(ITunnelConnectionServices), typeof(TunnelConnectionServices));
			WindsorRegistrar.Register(typeof(ITunnelAnalogueDosingControlServices), typeof(TunnelAnalogueDosingControlServices));
            WindsorRegistrar.Register(typeof(ICompareFormulaService), typeof(CompareFormulaService));
        }
    }
}