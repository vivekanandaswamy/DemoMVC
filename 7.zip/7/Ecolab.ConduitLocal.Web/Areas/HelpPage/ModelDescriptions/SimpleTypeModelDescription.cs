// -----------------------------------------------------------------------
// <copyright file="SimpleTypeModelDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SimpleTypeModelDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}