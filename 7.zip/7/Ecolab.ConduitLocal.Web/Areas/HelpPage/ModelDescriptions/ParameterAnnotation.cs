// -----------------------------------------------------------------------
// <copyright file="ParameterAnnotation.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ParameterAnnotation </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    using System;

    public class ParameterAnnotation
    {
        public Attribute AnnotationAttribute { get; set; }
        public string Documentation { get; set; }
    }
}