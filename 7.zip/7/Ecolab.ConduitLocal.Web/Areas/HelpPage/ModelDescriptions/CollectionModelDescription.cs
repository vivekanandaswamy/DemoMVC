// -----------------------------------------------------------------------
// <copyright file="CollectionModelDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CollectionModelDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    public class CollectionModelDescription : ModelDescription
    {
        public ModelDescription ElementDescription { get; set; }
    }
}