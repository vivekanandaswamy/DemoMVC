// -----------------------------------------------------------------------
// <copyright file="EnumTypeModelDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The EnumTypeModelDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    using System.Collections.ObjectModel;

    public class EnumTypeModelDescription : ModelDescription
    {
        public EnumTypeModelDescription()
        {
            Values = new Collection<EnumValueDescription>();
        }

        public Collection<EnumValueDescription> Values { get; private set; }
    }
}