// -----------------------------------------------------------------------
// <copyright file="IModelDocumentationProvider.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The IModelDocumentationProvider </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    using System;
    using System.Reflection;

    public interface IModelDocumentationProvider
    {
        string GetDocumentation(MemberInfo member);
        string GetDocumentation(Type type);
    }
}