// -----------------------------------------------------------------------
// <copyright file="DictionaryModelDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DictionaryModelDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}