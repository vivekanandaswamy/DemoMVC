// -----------------------------------------------------------------------
// <copyright file="KeyValuePairModelDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The KeyValuePairModelDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    public class KeyValuePairModelDescription : ModelDescription
    {
        public ModelDescription KeyModelDescription { get; set; }
        public ModelDescription ValueModelDescription { get; set; }
    }
}