// -----------------------------------------------------------------------
// <copyright file="EnumValueDescription.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>The EnumValueDescription </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Areas.HelpPage.ModelDescriptions
{
    public class EnumValueDescription
    {
        public string Documentation { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
}