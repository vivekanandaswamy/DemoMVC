﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Models;
    using Models.PlantSetup.UserManagement;
    using Services.Interfaces;
    using Model = Ecolab.Models.PlantSetup.UserManagement;
   
    /// <summary>
    ///     Class UserManagementController
    /// </summary>
    public class UserManagementController : BaseApiController
    {
        /// <summary>
        ///     UserManagement Service
        /// </summary>
        private readonly IUserManagementService userManagementService;

        /// <summary>
        ///      Initializes a new instance of the <see cref="UserManagementController" /> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="UserManagementService">User Management Service</param>
        public UserManagementController(IUserService userService, IPlantService plantService, IUserManagementService UserManagementService) : base(userService, plantService)
        {
            this.userManagementService = UserManagementService;
        }

        /// <summary>
        ///     Gets User Management Details
        /// </summary>
        /// <returns>List of UserManagementModel</returns>
        [HttpGet]
        public UserManagementViewModel Fetch()
        {
            IEnumerable<Model.UserManagement> userManagement = this.userManagementService.FetchUserManagementDetails(null, this.EcolabAccountNumber);
            IEnumerable<UserManagementModel> userManagementList = Mapper.Map<IEnumerable<Model.UserManagement>, IEnumerable<UserManagementModel>>(userManagement);
            userManagementList = userManagementList.Where(c => c.IsActive).ToList();

            IEnumerable<UserRoles> userRolesList = this.FetchUserRoles();
            UserManagementViewModel userManagementViewModel = new UserManagementViewModel();
            userManagementViewModel.UserManagementList = userManagementList;
            userManagementViewModel.UserRole = userRolesList;
            return userManagementViewModel;
        }

        /// <summary>
        ///     Gets Dictionary of selected userManagement details and IEnumerable of userRoles
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>UserManagementViewModel</returns>
        [HttpGet]
        public UserManagementViewModel FetchOnEditClicked(int id)
        {
            Model.UserManagement userManagement = this.userManagementService.FetchUserManagementDetails(id, this.EcolabAccountNumber).FirstOrDefault();
            UserManagementModel userManagementList = Mapper.Map<Model.UserManagement, UserManagementModel>(userManagement);
            IEnumerable<UserRoles> userRolesList = this.FetchUserRoles();

            return new UserManagementViewModel { UserManagement = userManagementList, UserRole = userRolesList };
        }

        /// <summary>
        ///     Gets IEnumerable List of UserRoles
        /// </summary>
        /// <returns>IEnumerable UserRoles</returns>
        [HttpGet]
        public IEnumerable<UserRoles> FetchUserRoles()
        {
            List<Ecolab.Models.UserRoles> userRoles = this.UserService.GetAllRoles();
            IEnumerable<UserRoles> userRolesList = Mapper.Map<IEnumerable<Ecolab.Models.UserRoles>, IEnumerable<UserRoles>>(userRoles);
            return userRolesList;
        }

        /// <summary>
        ///     Creates new User in User Management
        /// </summary>
        /// <param name="data">Data to create New user</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPost]
        public HttpResponseMessage Create([FromBody] UserManagementModel data)
        {
            Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
            objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
            DateTime lastModifiedTimeStamp;
            int userMasterId;
            string status = this.userManagementService.InsertUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
            objUserManagement.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            objUserManagement.UserNumber = userMasterId;
            objUserManagement.IsActive = true;
            if (objUserManagement.UserNumber > 0)
            {
               Push.PushToQueue(objUserManagement, this.UserId, objUserManagement.UserNumber, (int)TcdAdminMessageTypes.TcdAddUserManagement,
               this.EcolabAccountNumber);
            }
            return this.Status(status);
        }

        /// <summary>
        ///     To update the User Management details
        /// </summary>
        /// <param name="id">User Number</param>
        /// <param name="data">Data to update User Management</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, UserManagementModel data)
        {
            Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
            objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
            DateTime lastModifiedTimeStamp;
            int userMasterId;
            string status = this.userManagementService.UpdateUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
            objUserManagement.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            objUserManagement.UserNumber = userMasterId;
            objUserManagement.IsActive = true;
            if (objUserManagement.UserNumber > 0)
            {
                Push.PushToQueue(objUserManagement, this.UserId, objUserManagement.UserNumber, (int)TcdAdminMessageTypes.TcdUpdateUserManagement,
                this.EcolabAccountNumber);
            }
            return this.Status(status);
        }

        ///// <summary>
        /////     To update the User Management details
        ///// </summary>
        ///// <param name="data">Data to update User Management</param>
        ///// <returns>Returns Success or failure response Messages</returns>
        //[HttpPut]
        //public HttpResponseMessage Put(UserManagementModel data)
        //{
        //    return this.Put(data.UserNumber, data);
        //}

        /// <summary>
        ///     To update the User Management details
        /// </summary>
        /// <param name="data">Data to update User Management</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpPut]
        public HttpResponseMessage Put(List<UserManagementModel> data)
        {
            string status = string.Empty;
            Dictionary<string, string> StatusList = new Dictionary<string, string>();
            foreach (UserManagementModel userManagementModel in data)
            {
                status = Save(userManagementModel);
                if (!string.IsNullOrEmpty(status))
                    StatusList.Add(userManagementModel.LoginName, status);
            }
            if (StatusList.Count > 0)
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, StatusList);
            else
                return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }

        /// <summary>
        ///     Delete the User Management data
        /// </summary>
        /// <param name="data">the User Management data</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [HttpDelete]
        public HttpResponseMessage Delete(UserManagementModel data)
        {
            Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
            objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
            if(objUserManagement.UserNumber != this.UserId)
            {
                DateTime lastModifiedTimeStamp;
                this.userManagementService.DeleteUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp);
                objUserManagement.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                Push.PushToQueue(objUserManagement, this.UserId, objUserManagement.UserNumber, (int)TcdAdminMessageTypes.TcdDeleteUserManagement, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, string.Empty);
        }

        /// <summary>
        ///     Returns success or failure Response basing on status code
        /// </summary>
        /// <param name="status">status code from Database</param>
        /// <returns>Success or failure HttpResponseMessage</returns>
        private HttpResponseMessage Status(string status)
        {
            if(string.IsNullOrEmpty(status))
            {
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
        }
        /// <summary>
        /// Saves the user data
        /// </summary>
        /// <param name="data">the user namangement data</param>
        /// <returns>Success or failure message</returns>
        private string Save(UserManagementModel data)
        {
            string status = string.Empty;
            int sttusID = 0;
            Model.UserManagement objUserManagement = Mapper.Map<UserManagementModel, Model.UserManagement>(data);
            objUserManagement.EcolabAccountNumber = this.EcolabAccountNumber;
            DateTime lastModifiedTimeStamp;
            int userMasterId;
            status = this.userManagementService.UpdateUserManagement(objUserManagement, this.UserId, out lastModifiedTimeStamp, out userMasterId);
            objUserManagement.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            objUserManagement.UserNumber = userMasterId;
            objUserManagement.IsActive = true;
            if (objUserManagement.UserNumber > 0)
            {
                sttusID = Push.PushToQueue(objUserManagement, this.UserId, objUserManagement.UserNumber, (int)TcdAdminMessageTypes.TcdUpdateUserManagement,
                this.EcolabAccountNumber);

                if (sttusID > 0)
                    status = sttusID.ToString();
            }
            return status;
        }

		/// <summary>
		///     Gets User Management Details
		/// </summary>
		/// <returns>List of UserManagementModel</returns>
		[HttpGet]
		public IEnumerable<UserManagementModel> FetchUserList()
		{
			IEnumerable<Model.UserManagement> userManagement = this.userManagementService.FetchUserManagementDetails(null, this.EcolabAccountNumber);
			IEnumerable<UserManagementModel> userManagementList = Mapper.Map<IEnumerable<Model.UserManagement>, IEnumerable<UserManagementModel>>(userManagement);
			userManagementList = userManagementList.Where(c => c.IsActive).ToList();
			
			return userManagementList;
		}
	}
}