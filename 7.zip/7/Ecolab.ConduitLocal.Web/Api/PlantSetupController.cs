﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Setup Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Elmah;
    using Models;
    using Services;
    using Services.Interfaces;
    using EntityConverter = Mapper.EntityConverter;

    /// <summary>
    ///     Class Plant Setup Controller
    /// </summary>
    public class PlantSetupController : BaseApiController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        public PlantSetupController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get all the values related to Plant setup
        /// </summary>
        /// <returns>Returns the plant model</returns>
        public PlantModel Get()
        {
            User user = this.GetCurrentUser();
            List<CurrencyMaster> currencyCode = this.PlantService.GetCurrencyDetails();
            List<LanguageMaster> languages = this.PlantService.GetLanguageDetails();
            List<DimensionalUnitSystems> uoms = this.PlantService.GetDimensionalUnitSystems();
           
            PlantModel plantModel = new PlantModel();

            plantModel = Mapper.Map<Plant, PlantModel>(this.PlantService.GetPlantDetails(user.UserId, user.EcolabAccountNumber));
            plantModel.StartTime = DateTime.ParseExact(plantModel.StartTime, "HH:mm:ss", null).ToString("HH:mm");
            plantModel.EndTime = DateTime.ParseExact(plantModel.EndTime, "HH:mm:ss", null).ToString("HH:mm");
            plantModel.CurrencyCodes = currencyCode.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Languages = languages.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Uoms = uoms.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();

            return plantModel;
        }

        /// <summary>
        ///     The plant Setup save
        /// </summary>
        /// <param name="plant">Save the plant details</param>
        /// <returns>http Response message</returns>
        [HttpPost]
        public HttpResponseMessage Save(PlantModel plant)
        {
            try
            {
                Plant objPlant = EntityConverter.ConvertToServiceModel(plant);
                objPlant.StartTime = new TimeSpan(Convert.ToInt32(plant.StartTime.Split(':')[0]), Convert.ToInt32(plant.StartTime.Split(':')[1]), 0);
                objPlant.EndTime = new TimeSpan(Convert.ToInt32(plant.EndTime.Split(':')[0]), Convert.ToInt32(plant.EndTime.Split(':')[1]), 0);
                IPrincipal user = HttpContext.Current.User;
                bool isFolderPathExists = Directory.Exists(objPlant.ExportPath);
                if(!isFolderPathExists)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Path");
                }
                DateTime lastModifiedTimeStamp;
                string retVal = this.PlantService.SavePlantDetails(objPlant, ((CustomPrincipal)user).UserId, out lastModifiedTimeStamp);
                objPlant = this.PlantService.GetPlantDetails(this.EcolabAccountNumber);
                objPlant.LastModifiedTimeStamp = DateTime.SpecifyKind(objPlant.LastModifiedTimeStamp, DateTimeKind.Utc);
                
                Push.PushToQueue(objPlant, this.UserId, 0, (int)TcdAdminMessageTypes.TcdUpdatePlant, this.EcolabAccountNumber);
            }
            catch(Exception ex)
            {
                this.Logger.Error("PlantSetup  - Save Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "An exception occurred saving the plant details.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, plant);
        }

        /// <summary>
        ///     Gets the values
        /// </summary>
        /// <param name="id">gets the values by ID</param>
        /// <returns>Returns the fetched values</returns>
        public string Get(int id)
        {
            return "value";
        }

        /// <summary>
        ///     Post the values
        /// </summary>
        /// <param name="value">Post the fetched values</param>
        public void Post([FromBody] string value)
        {
        }

        /// <summary>
        ///     Update the values
        /// </summary>
        /// <param name="id">Update the values by ID</param>
        /// <param name="value">Update the modified values</param>
        public void Put(int id, [FromBody] string value)
        {
        }

        /// <summary>
        ///     Delete the values
        /// </summary>
        /// <param name="id">Delete the values by ID</param>
        public void Delete(int id)
        {
        }

		/// <summary>
		/// FirstTime Request Sync
		/// </summary>
        /// <returns>Http Response Message</returns>
		[HttpPost]
		public HttpResponseMessage FirstTimeRequest()
	    {
			TcdErrCodes errCodes = new TcdErrCodes();
			errCodes = Push.PushAllPlantEntities(this.EcolabAccountNumber, this.UserId);
			if (errCodes == TcdErrCodes.NggNotConnected)
			{
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "51032");
			}
			else if (errCodes != TcdErrCodes.Success)
			{
				return this.Request.CreateResponse(HttpStatusCode.BadRequest);
			}
			return this.Request.CreateResponse(HttpStatusCode.OK);
	    }
    }
}