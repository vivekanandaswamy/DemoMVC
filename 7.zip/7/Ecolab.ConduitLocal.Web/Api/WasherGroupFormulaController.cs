﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaController.cs" company="Ecolab">
// Gets the detalis of the washergroupformula for WasherGroupFormulaController Controller class.
// </copyright>
// <summary>The methods for washer group formula setup.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Elmah;
    using Mapper;
    using Models.WasherGroup;
    using Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using InjectionDetails = Models.WasherGroup.InjectionDetails;
    using Model = Ecolab.Models;
    using ModelChemical = Ecolab.Models.PlantSetup.Chemical;
    using WasherGroup = Models.WasherGroup.WasherGroup;
    using WebModel = Models;
    using WebModelChemical = Models.PlantSetup.Chemical;
    using Models.Common;
    using Utilities;
    using Ecolab.Models.Enum;

    public class WasherGroupFormulaController : BaseApiController
    {
        /// <summary>
        ///     The injection service
        /// </summary>
        private readonly IInjectionService injectionService;

        /// <summary>
        ///     Interface object for plant utility service.
        /// </summary>
        private readonly IPlantUtilityService plantUtilityService;

        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Product Master Service(Plant chemical)
        /// </summary>
        private readonly IProductMasterService prodMastService;

        /// <summary>
        ///     prog Master Service
        /// </summary>
        private readonly IProgramMasterService progMasterService;

        /// <summary>
        ///     Interface object for Washer Group formula Service.
        /// </summary>
        private readonly IWasherGroupFormulaService washerGroupFormulaService;

        /// <summary>
        ///     Interface object for Washer Group Service.
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Plant Service
        /// </summary>
        private readonly IPlantService plantService = new Ecolab.Services.PlantService();

        /// <summary>
        /// The controler name
        /// </summary>
        private string controlerName;
        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormulaController" /> class.
        /// </summary>
		/// <param name="washerGroupService">Wash group formula Service object.</param>
		/// <param name="progMasterService">IProduct Master Service</param>
		/// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
		/// <param name="plantUtilityService">Plant Utility Service</param>
		/// <param name="prodMastService">Product Master Service</param>
		/// <param name="plantService">The Plant Service</param>
		/// <param name="userService">User Service</param>
		/// <param name="washerServices">Washer Service</param>
		/// <param name="injectionService">The Injection Service</param>
		/// <param name="plcService">THe PLC Service</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
		public WasherGroupFormulaController(IWasherGroupService washerGroupService, IProgramMasterService progMasterService, IWasherGroupFormulaService washerGroupFormulaService, IPlantUtilityService plantUtilityService, IProductMasterService prodMastService, IPlantService plantService, IUserService userService, IWasherServices washerServices, IInjectionService injectionService, IPlcService plcService, IControllerSetupService controllerSetupService)
            : base(userService, plantService)
        {
            this.washerGroupService = washerGroupService;
            this.progMasterService = progMasterService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.plantUtilityService = plantUtilityService;
            this.prodMastService = prodMastService;
            this.washerServices = washerServices;
            this.injectionService = injectionService;
            this.controllerSetupService = controllerSetupService;
            this.plcService = plcService;
        }

        /// <summary>
        /// Get all the values related to washergroup
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <param name="pageNumber">The Page Number.</param>
        /// <param name="numberOfRecordsPerpage">Number Of Records Perpage.</param>
        /// <param name="sortColumn">The sort column.</param>
        /// <param name="regionId">The Region Id</param>
        /// <returns>
        /// Returns the washergroup model
        /// </returns>
        [HttpGet]
        public IEnumerable<WasherGroup> GetWasherGroupDetails(int washergroupId, string ecolabAccountNumber, int pageNumber, int numberOfRecordsPerpage, string sortColumn, int regionId)
        {
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, pageNumber, numberOfRecordsPerpage, sortColumn);
            IEnumerable<WasherGroup> washerGroups = Mapper.Map<IEnumerable<Ecolab.Models.WasherGroup.WasherGroup>, IEnumerable<WasherGroup>>(washerGroupModel);
            return washerGroups;
        }

        /// <summary>
        /// Get all the values related to washergroup with washer list.
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <param name="pageNumber">The Page Number.</param>
        /// <param name="numberOfRecordsPerpage">Number Of Records Perpage.</param>
        /// <param name="sortColumn">the Sort Column</param>
        /// <param name="regionId">the region Id.</param>
        /// <returns>
        /// Returns the WasherGroupFormulaLists model
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWasherGroupWithWasherDetails(int washergroupId, string ecolabAccountNumber, int pageNumber, int numberOfRecordsPerpage, string sortColumn, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            objWasherGroupFormulaModel.NextAvailableWasherGroupNumber = this.washerGroupService.GetNextAvailableWasherGroupNumber(ecolabAccountNumber);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, pageNumber, numberOfRecordsPerpage, sortColumn);
            IEnumerable<WasherGroup> washerGroups = Mapper.Map<IEnumerable<Ecolab.Models.WasherGroup.WasherGroup>, IEnumerable<WasherGroup>>(washerGroupModel);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroups;
            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washergroupId);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);
            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Get all the values related to washergroup formula
        /// </summary>
        /// <param name="washergroupId">Washer group Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <returns>
        /// Returns the washergroup formula model
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWasherGroupFormula(int washergroupId, string ecolabAccountNumber)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();

            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washergroupId, 0);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, 1, 12, string.Empty);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).OrderBy(x => x.ProgramNumber).ToList();
            if (objWasherGroupFormulaModel.WasherGroupFormulaDetails.Count > 0)
            {
                foreach (WasherGroupFormulaModel wgfm in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                    if (washerGroupModel != null && washerGroupModel.First().ControllerModelId == 8)
                    {
                        wgfm.CompartmentStandardRunTime = wgfm.StandardRunTime != 0 ? this.ConvertionofSeconds(wgfm.StandardRunTime) : "01:30";
                    }
                    else
                    {
                        wgfm.CompartmentStandardRunTime = wgfm.StandardRunTime != 0 ? this.ConvertionofSeconds(wgfm.StandardRunTime) : "02:00";
                    }
                }
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.ForEach(_ => _.LoadsPerMonthAsString = _.LoadsPerMonth.ToString("#,0.##"));
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.ForEach(_ => _.NominalLoadAsString = _.NominalLoad.ToString("#,0.##"));
            }
            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = new List<WasherFormulaWashStepModel>();
            
            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Saves the formulas to PLC.
        /// </summary>
        /// <param name="washerGroupFormulaModel">The washer group formula model.</param>
        /// <returns>Success or Failure Message</returns>
        public HttpResponseMessage SaveFormulasToPLC(WasherGroupFormulaModel washerGroupFormulaModel)
        {
            List<int> controllerIds = washerGroupFormulaService.GetWasherGroupBasedControllerIds(washerGroupFormulaModel.WasherGroupId);
            PLCDiscrepancyModel objPLCDiscrepancyModel = new PLCDiscrepancyModel();
            string message = string.Empty;
            string erroIds = string.Empty;
            if (controllerIds.Count > 0)
            {
                //Formula injections
                foreach (int controllerId in controllerIds)
                {
                    Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washerGroupFormulaModel.EcolabAccountNumber);

                    List<Model.WasherGroup.InjectionDetails> objData;
                    if ((controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2) ||
                       (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14)) ||
                       (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7)))
                    {
                        try
                        {
                            WriteFormulaDetailsToPlc(controllerId, washerGroupFormulaModel);
                        }
                        catch (Exception ex)
                        {
                            message = ex.Message;
                            erroIds += controllerId + ", ";
                        }
                    }
                    else
                    {
                        objData = injectionService.GetWasherGroupInjectionDetails(washerGroupFormulaModel.EcolabAccountNumber, washerGroupFormulaModel.WasherGroupId, controllerId);

                        if (objData.Count > 0)
                        {
                            List<InjectionDetails> injectionDetails = Mapper.Map<List<Models.WasherGroup.InjectionDetails>>(objData);

                            try
                            {
                                Dictionary<int, int> sucessInjections = new Dictionary<int, int>();
                                sucessInjections = ValidateAndWriteInjectionsInPlc(injectionDetails);
                                foreach (var injection in sucessInjections)
                                {
                                    objPLCDiscrepancyModel = new PLCDiscrepancyModel
                                    {
                                        ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                                        ParentEntityId = washerGroupFormulaModel.WasherGroupId,
                                        Entity = Convert.ToInt32(PlcDiscrepancyEntity.ConventionalFormula),
                                        EntityId = Convert.ToInt32(injection.Key),
                                        IsCentral = false,
                                        ControllerId = controllerDetails.ControllerId,
                                        UserId = this.UserId,
                                        LastModifiedUserId = this.UserId
                                    };
                                    this.plcService.DeletePlcDiscrepancy(AutoMapper.Mapper.Map<PLCDiscrepancyModel, Ecolab.Models.Common.PLCDiscrepancyModel>(objPLCDiscrepancyModel));
                                }

                            }
                            catch (Exception ex)
                            {
                                message = ex.Message;
                                erroIds += controllerId + ", ";
                            }
                        }
                    }
                }

                erroIds = erroIds.Trim().Trim(',');

                if (message == "901")
                {
                    message = "Unable to connect to PLC.";
                }
                else if (message.Contains("Timeout has elapsed") ||
                        message.Contains("Port is disabled") ||
                        message.Contains("Target machine could not be found") ||
                        message.Contains("ADS could not be initialized") ||
                        message.Contains("Open Failed") || 
                        message.Contains("Retrieving the COM class factory"))
                {
                    message = "Unable to connect to PLC.";
                }
                else if (message.Contains("No Formula Exists"))
                {
                    message = "Unable to send to PLC as No Formula Exists";
                }
                else if (!string.IsNullOrEmpty(erroIds))
                {
                    string[] controllerIdArr = erroIds.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    foreach (string controllerId in controllerIdArr)
                    {
                        Ecolab.Models.Common.ControllerInfoForPlc controllerInfoForPlc = plcService.GetControllerInfoForPlc(Convert.ToInt32(controllerId), washerGroupFormulaModel.EcolabAccountNumber).FirstOrDefault();
                        if (controllerInfoForPlc != null)
                        {
                            controlerName += controllerInfoForPlc.TopicName + ";";
                        }
                    }
                    message = "Formulas for Controller(s) " + controlerName + " are not saved to PLC";
                }
                else
                {
                    message = "Sent Formula details Successfully";
                }
            }
            else
            {
                message = "Formulas are not saved to PLC";
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, message);
        }

        /// <summary>
        /// Writes the formula details to PLC.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="washerGroupFormulaModel">The washer group formula model.</param>
        /// <exception cref="System.Exception">No Formula Exists</exception>
        private void WriteFormulaDetailsToPlc(int controllerId, WasherGroupFormulaModel washerGroupFormulaModel)
        {
            Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washerGroupFormulaModel.EcolabAccountNumber);

            var plcTagController = new PlcTagController(this.plcService, this.UserService, this.PlantService);

            // Send PLC XL 10 Washers Formulas To PLC, which has Additional Feature Use Group 1 Formulas for Group 2 (Special Case)
            if (controllerDetails.ControllerModelId == 11 && controllerDetails.ControllerTypeId == 12)
            {
                List<WasherGroupFormulaDetails> washerGroupFormulaDetailsFor10Washers = GetPLCXL10WWasherGroupFormulaSettings(controllerId, washerGroupFormulaModel);
                plcTagController.WritePLCXLWasherGroupFormulaSettings(washerGroupFormulaDetailsFor10Washers, controllerId);
            }
            else
            {
                //Rest Send Formulas for MyControl, PLC XL (1T5W, 2T) & EControl Plus
                WasherGroupFormulaDetails washerFormulaDetails = PrepareStructureForWritingToPLC(controllerId, washerGroupFormulaModel);
                if (washerFormulaDetails.WasherGroupFormulas.Count == 0)
                {
                    throw new Exception("No Formula Exists");
                }
                else
                {
                    if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                    {
                        plcTagController.WriteMyControlWasherGroupFormulaSettings(washerFormulaDetails, controllerId);
                    }
                    else if (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14))
                    {
                        plcTagController.WritePLCXLWasherGroupFormulaSettings(new List<WasherGroupFormulaDetails>() { washerFormulaDetails }, controllerId);
                    }
                    else if (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7))
                    {
                        plcTagController.WriteEControlPlusWasherGroupFormulaSettings(washerFormulaDetails, controllerId);
                    }
                }
            }
        }

        /// <summary>
        /// Get PLC XL 10W Washer Group Formula Settings
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="washerGroupFormulaModel">Washer Group Formula Model</param>
        /// <returns>Washer Group Formula Details Collection</returns>
        private List<WasherGroupFormulaDetails> GetPLCXL10WWasherGroupFormulaSettings(int controllerId, WasherGroupFormulaModel washerGroupFormulaModel)
        {
            List<WasherGroupFormulaDetails> WasherGroupFormulaList = new List<WasherGroupFormulaDetails>();

            int washerGroupIdGroupOne = this.washerGroupFormulaService.GetWasherGroupIdForGroupOne(washerGroupFormulaModel.EcolabAccountNumber, controllerId, 1);
            int washerGroupIdGroupTwo = this.washerGroupFormulaService.GetWasherGroupIdForGroupOne(washerGroupFormulaModel.EcolabAccountNumber, controllerId, 2);
            bool isWasherGroupIdBelongsToGroupOne = washerGroupFormulaModel.WasherGroupId == washerGroupIdGroupOne ? true : false;
            bool isWasherGroupIdBelongsToGroupTwo = washerGroupFormulaModel.WasherGroupId == washerGroupIdGroupTwo ? true : false;
            bool useGroupOneFormulasForGroupTwo = washerGroupFormulaModel.UseGroup1Formulas.HasValue && washerGroupFormulaModel.UseGroup1Formulas.Value == true ? true : false;

            if (isWasherGroupIdBelongsToGroupOne)
            {
                useGroupOneFormulasForGroupTwo = this.washerGroupService.GetWasherGroupDetails(washerGroupIdGroupTwo, washerGroupFormulaModel.EcolabAccountNumber, 1, 1, string.Empty).First().UseGroup1Formulas;
            }

            WasherGroupFormulaDetails washerFormulaDetailsForGroupOne = new WasherGroupFormulaDetails();
            WasherGroupFormulaDetails washerFormulaDetailsForGroupTwo = new WasherGroupFormulaDetails();

            if (useGroupOneFormulasForGroupTwo)
            {
                //Group 1 Structure
                washerGroupFormulaModel.WasherGroupId = washerGroupIdGroupOne;
                washerFormulaDetailsForGroupOne = PrepareStructureForWritingToPLC(controllerId, washerGroupFormulaModel);
                washerFormulaDetailsForGroupOne.UseGroup1FormulaUsedForGroup2ForPLCXL = true;

                //Group 2 Structure Taken From Group 1 Structure
                washerFormulaDetailsForGroupTwo = new WasherGroupFormulaDetails();
                washerFormulaDetailsForGroupTwo.WasherGroupFormulas = washerFormulaDetailsForGroupOne.WasherGroupFormulas;
                washerFormulaDetailsForGroupTwo.WasherGroupDeletedFormulas = washerFormulaDetailsForGroupOne.WasherGroupDeletedFormulas;
                washerFormulaDetailsForGroupTwo.WasherGroupTypeId = washerFormulaDetailsForGroupOne.WasherGroupTypeId;
                washerFormulaDetailsForGroupTwo.AreSendAllFormulasToPLC = washerFormulaDetailsForGroupOne.AreSendAllFormulasToPLC;
                washerFormulaDetailsForGroupTwo.WasherDosingNumber = 2;
                washerFormulaDetailsForGroupTwo.UseGroup1FormulaUsedForGroup2ForPLCXL = true;

                if (isWasherGroupIdBelongsToGroupOne)
                {
                    WasherGroupFormulaList.Add(washerFormulaDetailsForGroupOne);
                    WasherGroupFormulaList.Add(washerFormulaDetailsForGroupTwo);
                }
                else if (isWasherGroupIdBelongsToGroupTwo)
                {
                    WasherGroupFormulaList.Add(washerFormulaDetailsForGroupTwo);
                }
            }
            else
            {
                //Group 1 Structure
                washerGroupFormulaModel.WasherGroupId = washerGroupIdGroupOne;
                washerFormulaDetailsForGroupOne = PrepareStructureForWritingToPLC(controllerId, washerGroupFormulaModel);
                washerFormulaDetailsForGroupOne.UseGroup1FormulaUsedForGroup2ForPLCXL = false;

                //Group 2 Structure
                washerGroupFormulaModel.WasherGroupId = washerGroupIdGroupTwo;
                washerFormulaDetailsForGroupTwo = PrepareStructureForWritingToPLC(controllerId, washerGroupFormulaModel);
                washerFormulaDetailsForGroupTwo.UseGroup1FormulaUsedForGroup2ForPLCXL = false;

                if (isWasherGroupIdBelongsToGroupOne)
                {
                    WasherGroupFormulaList.Add(washerFormulaDetailsForGroupOne);
                }
                else if (isWasherGroupIdBelongsToGroupTwo)
                {
                    WasherGroupFormulaList.Add(washerFormulaDetailsForGroupTwo);
                }
            }

            return WasherGroupFormulaList;
        }

        /// <summary>
        /// Write Deleted Formula Details To PLC
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="washerGroupId">Washer Group Id</param>
        /// <param name="washerGroupTypeId">Washer Group Type Id</param>
        /// <param name="controllerId">Controller Id</param>
        private void WriteDeletedFormulaDetailsToPLC(string ecolabAccountNumber, int washerGroupId, int washerGroupTypeId, int controllerId)
        {
            List<WasherGroupFormula> deletedFormulas = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, 0, true)
                                                                        .Where(x => x.IsDelete == true).ToList();
            if (deletedFormulas.Count > 0)
            {
                int washerDosingNumber = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 0, 0, string.Empty)
                                                       .Where(w => w.WasherGroupId == washerGroupId)
                                                       .First()
                                                       .WasherDosingNumber;

                Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, ecolabAccountNumber);
                var plcTagController = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                {
                    plcTagController.WriteMyControlWasherGroupDeletedFormulaSettings(controllerDetails.ControllerId, washerGroupTypeId, deletedFormulas, washerDosingNumber);
                }
                else if (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14))
                {
                    plcTagController.WritePLCXLWasherGroupDeletedFormulaSettings(controllerDetails.ControllerId, washerGroupTypeId, deletedFormulas, washerDosingNumber);

                    if (controllerDetails.ControllerTypeId == 12)
                    {
                        int washerGorupIdForGroup2 = this.washerGroupFormulaService.GetWasherGroupIdForGroupOne(controllerDetails.EcolabAccountNumber, controllerDetails.ControllerId, 2);
                        bool userFormulaFromGroupOne = this.washerGroupService.GetWasherGroupDetails(washerGorupIdForGroup2, controllerDetails.EcolabAccountNumber, 1, 1, string.Empty).First().UseGroup1Formulas;
                        if (userFormulaFromGroupOne)
                        {
                            plcTagController.WritePLCXLWasherGroupDeletedFormulaSettings(controllerDetails.ControllerId, washerGroupTypeId, deletedFormulas, 2);
                        }
                    }
                }
                else if (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7))
                {
                    plcTagController.WriteEControlPlusWasherGroupDeletedFormulaSettings(controllerDetails.ControllerId, washerGroupTypeId, deletedFormulas, washerDosingNumber);
                }
            }
        }

        /// <summary>
        /// Prepare Structure For Writing To PLC
        /// </summary>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="washerGroupFormulaModelToPLC">Washer Group Formula Model</param>
        /// <returns>Washer Group Formula Details</returns>
        private WasherGroupFormulaDetails PrepareStructureForWritingToPLC(int controllerId, WasherGroupFormulaModel washerGroupFormulaModelToPLC)
        {
            int programNumber = washerGroupFormulaModelToPLC.ProgramNumber;
            int washerGroupTypeId = this.washerGroupService.GetWasherGroupDetails(washerGroupFormulaModelToPLC.WasherGroupId, washerGroupFormulaModelToPLC.EcolabAccountNumber, 0, 0, string.Empty)
                               .Where(w => w.WasherGroupId == washerGroupFormulaModelToPLC.WasherGroupId).First().WasherGroupTypeId;

            WasherGroupFormulaDetails washerFormulaDetails = new WasherGroupFormulaDetails();

            Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washerGroupFormulaModelToPLC.EcolabAccountNumber);
            List<Model.WasherGroup.InjectionDetails> objData = injectionService.GetWasherGroupFormulaInjectionDetails(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, controllerId, washerGroupFormulaModelToPLC.Id);
            List<InjectionDetails> injectionDetails = Mapper.Map<List<Models.WasherGroup.InjectionDetails>>(objData);

            //Get Washer Group Formula Details
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, 0);
            List<WasherGroupFormulaModel> washerGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).OrderBy(x => x.ProgramNumber).ToList();

            //Get Washer Group Details
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupFormulaModelToPLC.WasherGroupId, washerGroupFormulaModelToPLC.EcolabAccountNumber, 1, 1, string.Empty);
            List<WasherGroup> washerGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();

            List<Models.WasherGroup.WasherFormula> washerFormulas = null;
            if (washerGroupTypeId == 1)
            {
                #region "Conventional Formulas"

                washerFormulas = injectionDetails
                                                .Where(x => x.WasherDosingNumber == washerGroupModel.FirstOrDefault().WasherDosingNumber)
                                                .GroupBy(x => x.ProgramNumber)
                                                                           .Select(x => x.First())
                                                                           .OrderBy(x => x.ProgramNumber)
                                                                           .Select(f => new Models.WasherGroup.WasherFormula()
                                                                           {
                                                                               ProgramId = f.ProgramId,
                                                                               ProgramNumber = f.ProgramNumber,
                                                                               StepNumber = f.StepNumber,
                                                                               NominalLoad = f.NominalLoad,
                                                                               TotalRunTime = washerGroupFormulaDetails.Where(x => x.ProgramNumber == f.ProgramNumber).First().TotalRunTime / 60,
                                                                               ExtraTime = f.ExtraTime,
                                                                               WashStepsCount = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, f.WasherProgramSetupId, false).SingleOrDefault().WashStepCount,
                                                                               CoolDownStep = f.CoolDownStep,
                                                                               EcolabTextileCategoryID = f.EcolabTextileCategoryID,
                                                                               WasherDosingNumber = f.WasherDosingNumber
                                                                           })
                                                                           .ToList();

                //Add Formulas With No injections
                List<int> programNumbers = washerFormulas.Select(x => x.ProgramNumber).ToList();
                if (programNumber == 0)
                {
                    foreach (WasherGroupFormulaModel washerGroupFormula in washerGroupFormulaDetails)
                    {
                        if (!programNumbers.Contains(washerGroupFormula.ProgramNumber))
                        {
                            IEnumerable<WasherGroupFormula> washerGroupFormulaList = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, washerGroupFormula.Id, false);
                            washerFormulas.Add(new Models.WasherGroup.WasherFormula()
                            {
                                ProgramId = washerGroupFormula.ProgramId,
                                ProgramNumber = washerGroupFormula.ProgramNumber,
                                NominalLoad = washerGroupFormula.NominalLoad,
                                TotalRunTime = washerGroupFormula.TotalRunTime / 60,
                                ExtraTime = washerGroupFormula.ExtraTime,
                                WashStepsCount = washerGroupFormulaList.Any() ? washerGroupFormulaList.First().WashStepCount : 0,
                                CoolDownStep = washerGroupFormulaList.Any() ? washerGroupFormulaList.First().CoolDownStep : 0,
                                WasherDosingNumber = washerGroupModel.FirstOrDefault().WasherDosingNumber
                            });
                        }
                    }
                }
                else
                {
                    WasherGroupFormulaModel washerGroupFormula = washerGroupFormulaDetails.Where(x => x.ProgramNumber == programNumber).FirstOrDefault();
                    if (washerGroupFormula != null)
                    {
                        if (!programNumbers.Contains(washerGroupFormula.ProgramNumber))
                        {
                            IEnumerable<WasherGroupFormula> washerGroupFormulaList = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, washerGroupFormula.Id, false);
                            washerFormulas.Add(new Models.WasherGroup.WasherFormula()
                            {
                                ProgramId = washerGroupFormula.ProgramId,
                                ProgramNumber = washerGroupFormula.ProgramNumber,
                                NominalLoad = washerGroupFormula.NominalLoad,
                                TotalRunTime = washerGroupFormula.TotalRunTime / 60,
                                ExtraTime = washerGroupFormula.ExtraTime,
                                WashStepsCount = washerGroupFormulaList.Any() ? washerGroupFormulaList.First().WashStepCount : 0,
                                CoolDownStep = washerGroupFormulaList.Any() ? washerGroupFormulaList.First().CoolDownStep : 0,
                                WasherDosingNumber = washerGroupModel.FirstOrDefault().WasherDosingNumber
                            });
                        }
                    }
                }
                washerFormulas = washerFormulas.OrderBy(x => x.ProgramNumber).ToList();

                //Get Washer Formula Conventional Analogue Control Details
                List<Model.WasherGroup.WasherFormulaConventionalAnalogueControl> conventionalAnalogueControlData = this.washerGroupFormulaService.GetConventionalAnalogueControlDetailsForWasherGroupFormulas(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, washerGroupModel.FirstOrDefault().ControllerId);
                List<Web.Models.WasherGroup.WasherFormulaConventionalAnalogueControl> conventionalAnalogueControlDetails = Mapper.Map<List<Models.WasherGroup.WasherFormulaConventionalAnalogueControl>>(conventionalAnalogueControlData);

                foreach (Models.WasherGroup.WasherFormula washerFormula in washerFormulas)
                {
                    //Temparature Analogue Control Steps
                    washerFormula.washerFormulaTemperatureAnalogueControlSteps = conventionalAnalogueControlDetails
                                                                                            .Where(x => x.SensorType == 1)
                                                                                            .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                                                                            .Where(x => (int)x.ProgramNumber == washerFormula.ProgramNumber)
                                                                                            .GroupBy(x => x.WasherDosingSetupId)
                                                                                            .Select(g => g.First())
                                                                                            .OrderBy(x => x.StepNumber)
                                                                                            .Select(t => new Models.WasherGroup.TemperatureAnalogueControlStep()
                                                                                            {
                                                                                                ProbeNumber = t.SensorNum,
                                                                                                StepNumber = t.StepNumber,
                                                                                                MinimumTime = t.MinimumTime,
                                                                                                StartDelay = t.StartDelay,
                                                                                                AcceptedDelay = t.AcceptedDelay,
                                                                                                ProductId = t.ProductId,
                                                                                                ProductCheck = (t.ProductId > 0) ? true : false,
                                                                                                SetPointTemperature = t.SetPointTemperature,
                                                                                                EquipmentNumber = t.EquipmentNumber
                                                                                            })
                                                                                            .ToList();

                    washerFormula.washerFormulaTemperatureAnalogueControlSteps.RemoveAll(tx => tx.MinimumTime == 0 &&
                                                                                                tx.AcceptedDelay == 0 &&
                                                                                                tx.StartDelay == 0 &&
                                                                                                tx.ProductCheck == false &&
                                                                                                tx.SetPointTemperature == 0);

                    //Ph Analogue Control Steps
                    washerFormula.washerFormulaPhAnalogueControlSteps = conventionalAnalogueControlDetails
                                                                                        .Where(x => x.SensorType == 2)
                                                                                        .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                                                                        .Where(x => (int)x.ProgramNumber == washerFormula.ProgramNumber)
                                                                                        .GroupBy(x => x.WasherDosingSetupId)
                                                                                        .Select(g => g.First())
                                                                                        .OrderBy(x => x.StepNumber)
                                                                                        .Select(p => new Models.WasherGroup.PhAnalogueControlStep()
                                                                                        {
                                                                                            ProbeNumber = p.SensorNum,
                                                                                            StepNumber = p.StepNumber,
                                                                                            PhControlDuringDrain = p.PhControlDuringDrain,
                                                                                            PhDelayTime = p.PhDelayTime,
                                                                                            PhMeasuringTime = p.PhMeasuringTime,
                                                                                            PhMaximum = p.PhMaximum,
                                                                                            PhMinimum = p.PhMininum
                                                                                        })
                                                                                        .ToList();

                    washerFormula.washerFormulaPhAnalogueControlSteps.RemoveAll(px => px.PhControlDuringDrain == false &&
                                                                                               px.PhDelayTime == 0 &&
                                                                                               px.PhMeasuringTime == 0 &&
                                                                                               px.PhMaximum == 0M &&
                                                                                               px.PhMinimum == 0M);

                    //Dosing Steps
                    washerFormula.WasherFormulaDosingSteps = injectionDetails
                                        .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                        .Where(x => x.ProgramNumber == washerFormula.ProgramNumber)
                                        .GroupBy(x => x.StepNumber)
                                        .Select(g => g.First())
                                        .OrderBy(x => x.StepNumber)
                                        .Select(d => new Models.WasherGroup.WasherFormulaDosingStep()
                                        {
                                            CompartmentNumberOrWashStepNumber = d.StepNumber,
                                            DosageStepNumber = d.WasherDosingSetupId,
                                            WashOperations = d.WashOperation,
                                            WaterType = d.WaterType,
                                            RunTime = d.RunTime,
                                            Temparature = d.Temperature,
                                            WaterLevel = d.WaterLevel,
                                            DrainDestination = d.DrainDestination,
                                            WaterInletDrain = d.WaterInletDrain
                                        })
                                        .ToList();

                    foreach (WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                    {
                        washerFormulaDosingStep.WasherFormulaDosingStepProducts = injectionDetails
                            .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                        .Where(z => z.WasherDosingSetupId == washerFormulaDosingStep.DosageStepNumber)
                                        .OrderBy(o => o.StepNumber).ThenBy(z => z.WasherDosingSetupId).ThenBy(t => t.WasherDosingProductMappingId)
                                        .Select(p => new Models.WasherGroup.WasherFormulaDosingStepProduct()
                                        {
                                            StepNumber = p.StepNumber,
                                            InjectionNumber = p.InjectionNumber,
                                            EquipmentNumber = p.ControllerEquipmentId,
                                            ProductId = p.ProductId,
                                            ProductName = p.ProductName,
                                            Quantity = p.Quantity,
                                            Delay = p.Delay
                                        })
                                        .ToList();
                    }
                }

                #endregion
            }
            else
            {
                #region "Tunnel Formulas"

                washerFormulas = injectionDetails.GroupBy(x => x.ProgramNumber)
                                                .Select(x => x.First())
                                                .OrderBy(x => x.ProgramNumber)
                                                .Select(f => new Models.WasherGroup.WasherFormula()
                                                {
                                                    WasherDosingNumber = f.WasherDosingNumber,
                                                    ProgramNumber = f.ProgramNumber,
                                                    NominalLoad = f.NominalLoad,
                                                    EcolabTextileCategoryID = f.EcolabTextileCategoryID
                                                })
                                                .ToList();

                //Add Formulas With No injections
                List<int> programNumbers = washerFormulas.Select(x => x.ProgramNumber).ToList();
                if (programNumber == 0)
                {
                    foreach (WasherGroupFormulaModel washerGroupFormula in washerGroupFormulaDetails)
                    {
                        if (!programNumbers.Contains(washerGroupFormula.ProgramNumber))
                        {
                            washerFormulas.Add(new Models.WasherGroup.WasherFormula()
                            {
                                WasherDosingNumber = washerGroupDetails.FirstOrDefault().WasherDosingNumber,
                                ProgramNumber = washerGroupFormula.ProgramNumber,
                                NominalLoad = washerGroupFormula.NominalLoad
                            });
                        }
                    }
                }
                else
                {
                    WasherGroupFormulaModel washerGroupFormula = washerGroupFormulaDetails.Where(x => x.ProgramNumber == programNumber).FirstOrDefault();
                    if (washerGroupFormula != null)
                    {
                        if (!programNumbers.Contains(washerGroupFormula.ProgramNumber))
                        {
                            washerFormulas.Add(new Models.WasherGroup.WasherFormula()
                            {
                                WasherDosingNumber = washerGroupDetails.FirstOrDefault().WasherDosingNumber,
                                ProgramNumber = washerGroupFormula.ProgramNumber,
                                NominalLoad = washerGroupFormula.NominalLoad
                            });
                        }
                    }
                }

                washerFormulas = washerFormulas.OrderBy(x => x.ProgramNumber).ToList();

                //Get Washer Formula Conventional Analogue Control Details
                List<Model.WasherGroup.WasherFormulaTunnelAnalogueControl> tunnelAnalogueControlData = this.washerGroupFormulaService.GetTunnelAnalogueControlDetailsForWasherGroupFormulas(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId);
                List<Web.Models.WasherGroup.WasherFormulaTunnelAnalogueControl> tunnelAnalogueControlDetails = Mapper.Map<List<Models.WasherGroup.WasherFormulaTunnelAnalogueControl>>(tunnelAnalogueControlData);

                //Analogue Temparature Details for Compartments
                foreach (Models.WasherGroup.WasherFormula washerFormula in washerFormulas)
                {
                    var formulaTunnelAnalogueControlDetails = tunnelAnalogueControlDetails
                                                                    .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                                                    .Where(x => x.ProgramNumber == washerFormula.ProgramNumber);

                    //Temparature Analogue Control Steps
                    if (formulaTunnelAnalogueControlDetails.Where(x => x.SensorType == 1).Where(m => m.MachineCompartment == 0).Any())
                    {
                        washerFormula.washerFormulaTemperatureAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                            .Where(x => x.SensorType == 1)
                                                                                            .Where(x => x.MachineCompartment == 0)
                                                                                            .OrderBy(x => x.CompartmentNumber)
                                                                                            .Select(t => new Models.WasherGroup.TemperatureAnalogueControlStep()
                                                                                            {
                                                                                                ProbeNumber = t.ProbeNumber,
                                                                                                CompartmentNumber = t.CompartmentNumber,
                                                                                                TunnelSetPointTemperature = t.SetPointTemparature,
                                                                                                TunnelMinimumTime = t.MinimumTime,
                                                                                                TunnelStartDelay = t.StartDelay,
                                                                                                TunnelAcceptedDelay = t.AcceptedDelay,
                                                                                                ProductCheck = t.ProductCheck
                                                                                            })
                                                                                            .ToList();
                    }
                    else
                    {
                        washerFormula.washerFormulaTemperatureAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                            .Where(x => x.SensorType == 1)
                                                                                            .GroupBy(x => x.ProbeNumber)
                                                                                            .Select(g => g.First())
                                                                                            .OrderBy(x => x.ProbeNumber)
                                                                                            .Select(t => new Models.WasherGroup.TemperatureAnalogueControlStep()
                                                                                            {
                                                                                                ProbeNumber = t.ProbeNumber,
                                                                                                CompartmentNumber = t.CompartmentNumber,
                                                                                                TunnelSetPointTemperature = t.SetPointTemparature,
                                                                                                TunnelMinimumTime = t.MinimumTime,
                                                                                                TunnelStartDelay = t.StartDelay,
                                                                                                TunnelAcceptedDelay = t.AcceptedDelay,
                                                                                                ProductCheck = t.ProductCheck
                                                                                            })
                                                                                            .ToList();
                    }

                    washerFormula.washerFormulaTemperatureAnalogueControlSteps.RemoveAll(tx => tx.TunnelMinimumTime == 0 &&
                                                                                                tx.TunnelAcceptedDelay == 0 &&
                                                                                                tx.TunnelStartDelay == 0 &&
                                                                                                tx.ProductCheck == false &&
                                                                                                tx.TunnelSetPointTemperature == 0D);

                    //Ph Analogue Control Steps
                    if (formulaTunnelAnalogueControlDetails.Where(x => x.SensorType == 2).Where(m => m.MachineCompartment == 0).Any())
                    {
                        washerFormula.washerFormulaPhAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                .Where(x => x.SensorType == 2)
                                                                                .Where(x => x.MachineCompartment == 0)
                                                                                .OrderBy(x => x.CompartmentNumber)
                                                                                .Select(p => new Models.WasherGroup.PhAnalogueControlStep()
                                                                                {
                                                                                    ProbeNumber = p.ProbeNumber,
                                                                                    CompartmentNumber = p.CompartmentNumber,
                                                                                    PhRegulationLevel = p.PHRegulationLevel,
                                                                                    PhMonitoringLevel = p.PHMonitoringLevel,
                                                                                    PhMinimum = p.PHMinimum,
                                                                                    PhMaximum = p.PHMaximum,
                                                                                    PhDelayTime = p.DelayTime,
                                                                                    PhMeasuringTime = p.MeasuringTime
                                                                                })
                                                                                 .ToList();
                    }
                    else
                    {
                        washerFormula.washerFormulaPhAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                .Where(x => x.SensorType == 2)
                                                                                .GroupBy(x => x.ProbeNumber)
                                                                                .Select(g => g.First())
                                                                                .OrderBy(x => x.ProbeNumber)
                                                                                .Select(p => new Models.WasherGroup.PhAnalogueControlStep()
                                                                                {
                                                                                    ProbeNumber = p.ProbeNumber,
                                                                                    CompartmentNumber = p.CompartmentNumber,
                                                                                    PhRegulationLevel = p.PHRegulationLevel,
                                                                                    PhMonitoringLevel = p.PHMonitoringLevel,
                                                                                    PhMinimum = p.PHMinimum,
                                                                                    PhMaximum = p.PHMaximum,
                                                                                    PhDelayTime = p.DelayTime,
                                                                                    PhMeasuringTime = p.MeasuringTime
                                                                                })
                                                                                .ToList();
                    }

                    washerFormula.washerFormulaPhAnalogueControlSteps.RemoveAll(x => x.PhRegulationLevel == 0 &&
                                                                                     x.PhMonitoringLevel == 0 &&
                                                                                     x.PhMinimum == 0M &&
                                                                                     x.PhMaximum == 0M &&
                                                                                     x.PhDelayTime == 0 &&
                                                                                     x.PhMeasuringTime == 0);

                    //Conductivity Analogue Control Steps
                    if (formulaTunnelAnalogueControlDetails.Where(x => x.SensorType == 4).Where(m => m.MachineCompartment == 0).Any())
                    {
                        washerFormula.washerFormulaConductivityAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                        .Where(x => x.SensorType == 4)
                                                                                        .Where(x => x.MachineCompartment == 0)
                                                                                        .OrderBy(x => x.CompartmentNumber)
                                                                                        .Select(c => new Models.WasherGroup.ConductivityAnalogueControlStep()
                                                                                        {
                                                                                            ProbeNumber = c.ProbeNumber,
                                                                                            CompartmentNumber = c.CompartmentNumber,
                                                                                            ConductivityRegulationLevel = c.ConductivityRegulationLevel,
                                                                                            ConductivityMinimum = c.ConductivityMininum,
                                                                                            ConductivityMaximum = c.ConductivityMaximum,
                                                                                            ConductivityDelayTime = c.ConductivityDelayTime,
                                                                                            ConductivityMeasuringTime = c.ConductivityMeasuringTime
                                                                                        })
                                                                                        .ToList();
                    }
                    else
                    {
                        washerFormula.washerFormulaConductivityAnalogueControlSteps = formulaTunnelAnalogueControlDetails
                                                                                        .Where(x => x.SensorType == 4)
                                                                                        .GroupBy(x => x.ProbeNumber)
                                                                                        .Select(g => g.First())
                                                                                        .OrderBy(x => x.ProbeNumber)
                                                                                        .Select(c => new Models.WasherGroup.ConductivityAnalogueControlStep()
                                                                                        {
                                                                                            ProbeNumber = c.ProbeNumber,
                                                                                            CompartmentNumber = c.CompartmentNumber,
                                                                                            ConductivityRegulationLevel = c.ConductivityRegulationLevel,
                                                                                            ConductivityMinimum = c.ConductivityMininum,
                                                                                            ConductivityMaximum = c.ConductivityMaximum,
                                                                                            ConductivityDelayTime = c.ConductivityDelayTime,
                                                                                            ConductivityMeasuringTime = c.ConductivityMeasuringTime
                                                                                        })
                                                                                        .ToList();
                    }

                    washerFormula.washerFormulaConductivityAnalogueControlSteps.RemoveAll(x => x.ConductivityRegulationLevel == 0 &&
                                                                                               x.ConductivityMinimum == 0M &&
                                                                                               x.ConductivityMaximum == 0M &&
                                                                                               x.ConductivityDelayTime == 0 &&
                                                                                               x.ConductivityMeasuringTime == 0);
                }

                foreach (Models.WasherGroup.WasherFormula washerFormula in washerFormulas)
                {
                    washerFormula.WasherFormulaDosingSteps = injectionDetails
                                        .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                        .Where(x => x.ProgramNumber == washerFormula.ProgramNumber)
                                        .GroupBy(x => x.ControllerEquipmentId)
                                        .Select(g => g.First())
                                        .OrderBy(x => x.ControllerEquipmentId)
                                        .Select(d => new Models.WasherGroup.WasherFormulaDosingStep()
                                        {
                                            ControllerEquipmentId = d.ControllerEquipmentId,
                                            CompartmentNumberOrWashStepNumber = d.StepNumber
                                        })
                                        .ToList();

                    foreach (WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                    {
                        List<int> compartmentsIds = injectionDetails
                                         .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                         .Where(x => x.ProgramNumber == washerFormula.ProgramNumber)
                                         .Where(x => x.ControllerEquipmentId == washerFormulaDosingStep.ControllerEquipmentId)
                                         .GroupBy(x => x.StepNumber)
                                         .Select(x => x.First())
                                         .Select(x => x.StepNumber)
                                         .ToList();

                        washerFormulaDosingStep.WasherFormulaDosingStepProducts = injectionDetails
                                        .Where(x => x.WasherDosingNumber == washerFormula.WasherDosingNumber)
                                        .Where(x => x.ProgramNumber == washerFormula.ProgramNumber)
                                        .Where(x => x.ControllerEquipmentId == washerFormulaDosingStep.ControllerEquipmentId)
                                        .Where(x => compartmentsIds.Contains(x.StepNumber))
                                        .Select(p => new Models.WasherGroup.WasherFormulaDosingStepProduct()
                                        {
                                            StepNumber = p.StepNumber,
                                            EquipmentNumber = p.ControllerEquipmentId,
                                            ProductId = p.ProductId,
                                            ProductName = p.ProductName,
                                            Quantity = p.Quantity,
                                            Delay = p.Delay,
                                            DosingPointNumber = p.DosingPointNumber,
                                            ValveNumber = p.ValveNumber,
                                            IsDirectDosing = p.IsDirectDosing
                                        })
                                        .ToList();
                    }
                }

                #endregion
            }

            List<WasherGroupFormula> deletedFormulas = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormulaModelToPLC.EcolabAccountNumber, washerGroupFormulaModelToPLC.WasherGroupId, 0, true)
                                                                       .Where(x => x.IsDelete == true).ToList();
            washerFormulaDetails.WasherGroupTypeId = washerGroupTypeId;
            washerFormulaDetails.WasherGroupFormulas = washerFormulas;
            washerFormulaDetails.AreSendAllFormulasToPLC = washerGroupFormulaModelToPLC.Id == 0 ? true : false;
            washerFormulaDetails.WasherGroupDeletedFormulas = deletedFormulas;
            washerFormulaDetails.WasherDosingNumber = this.washerGroupService.GetWasherGroupDetails(washerGroupFormulaModelToPLC.WasherGroupId, washerGroupFormulaModelToPLC.EcolabAccountNumber, 0, 0, string.Empty)
                                                   .Where(w => w.WasherGroupId == washerGroupFormulaModelToPLC.WasherGroupId)
                                                   .First()
                                                   .WasherDosingNumber;
            return washerFormulaDetails;
        }

        /// <summary>
        /// Save the Washer Group Data
		/// </summary>
		/// <param name="washerGroupWebData">Object of Washer group.</param>
        /// <returns>
        /// The result of the save opreation in string format.
        /// </returns>
		[HttpPost]
        public HttpResponseMessage CreateWasherGroup(WasherGroup washerGroupWebData)
        {
            int result;
            Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washerGroupWebData);
            try
            {
                DateTime lastModifiedTimeStamp;
                washerGroupData.MyServiceWasherGroupGuid = Guid.NewGuid();
                washerGroupData.WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupData, this.UserId, washerGroupWebData.EcolabAccountNumber, out lastModifiedTimeStamp);
                result = washerGroupData.WasherGroupId;
                if (washerGroupData.WasherGroupId > 0)
                {
                    washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(washerGroupData, this.UserId, washerGroupData.WasherGroupId, (int)TcdAdminMessageTypes.TcdAddWasherGroup, washerGroupData.EcolabAccountNumber);
                }
            }
            catch (Exception ex)
            {
                int message = int.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Update the Washer Group Data
        /// </summary>
        /// <param name="washerGroupWebData">Washer group web data.</param>
        /// <returns>
        /// The result of the save opreation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherGroup(WasherGroup washerGroupWebData)
        {
            int result;
            Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washerGroupWebData);
            try
            {
                DateTime lastModifiedTimeStamp;
                washerGroupData.WasherGroupId = this.washerGroupService.SaveWasherGroup(washerGroupData, this.UserId, washerGroupWebData.EcolabAccountNumber, out lastModifiedTimeStamp);
                result = washerGroupData.WasherGroupId;
                if (washerGroupData.WasherGroupId > 0)
                {
                    washerGroupData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(washerGroupData, this.UserId, washerGroupData.WasherGroupId, (int)TcdAdminMessageTypes.TcdUpdateWasherGroup, washerGroupData.EcolabAccountNumber);
                }
            }
            catch (Exception ex)
            {
                int message = int.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        /// Save the WasherFormulaWashStepModel Data
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">washer group formula wash step.</param>
        /// <returns>The result of the save operation.</returns>
        public HttpResponseMessage SaveWasherGroupFormulaWashSteps(WasherFormulaWashStepModel washerGroupFormulaWashStep)
        {
            bool isDeviceConnected = true;
            int result;
            int controllerId = 0;
            DateTime lastModifiedTimeStamp;
            WasherFormulaWashStep objWasherGroupFormulaWashStep = Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(washerGroupFormulaWashStep);

            if (objWasherGroupFormulaWashStep.Id > 0)
            {
                result = this.washerGroupFormulaService.UpdateWasherGroupWashStepFormula(objWasherGroupFormulaWashStep, this.UserId, out lastModifiedTimeStamp);

                WasherFormulaModel washerModel = new WasherFormulaModel
                {
                    washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault()
                };
                washerModel.washerFormula.LastModifiedTime = lastModifiedTimeStamp;
                washerModel.washerFormula.EcolabAccountNumber = objWasherGroupFormulaWashStep.EcolabAccountNumber;
                washerModel.washerFormulaWashStep = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId, objWasherGroupFormulaWashStep.Id).ToList();

                foreach (var item in washerModel.washerFormulaWashStep)
                {
                    List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(this.EcolabAccountNumber, item.Id, true).ToList();
                    item.WasherDosingProducts = prodDosing;
                    item.EcolabAccountNumber = this.EcolabAccountNumber;
                }

                foreach (var item in washerModel.washerFormulaWashStep)
                {
                    item.ProgramSetupId = washerModel.washerFormula.Id;
                }

                if (washerModel.washerFormula.ControllerId.HasValue)
                {
                    controllerId = washerModel.washerFormula.ControllerId.Value;
                }

                Push.PushToQueue(washerModel, this.UserId, washerModel.washerFormula.Id, (int)TcdAdminMessageTypes.TcdUpdateWasherFormulaWashStep, washerModel.washerFormula.EcolabAccountNumber);
            }
            else
            {
                result = this.washerGroupFormulaService.AddWasherGroupFormulaWashSteps(objWasherGroupFormulaWashStep, this.UserId, washerGroupFormulaWashStep.RegionId, out lastModifiedTimeStamp);

                WasherFormulaModel washerModel = new WasherFormulaModel
                {
                    washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault()
                };

                washerModel.washerFormula.LastModifiedTime = lastModifiedTimeStamp;
                washerModel.washerFormula.EcolabAccountNumber = objWasherGroupFormulaWashStep.EcolabAccountNumber;
                washerModel.washerFormulaWashStep = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId, objWasherGroupFormulaWashStep.Id).ToList();

                foreach (var item in washerModel.washerFormulaWashStep)
                {
                    List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(this.EcolabAccountNumber, item.Id, true).ToList();
                    item.WasherDosingProducts = prodDosing;
                    item.EcolabAccountNumber = this.EcolabAccountNumber;
                }

                foreach (var item in washerModel.washerFormulaWashStep)
                {
                    item.ProgramSetupId = washerModel.washerFormula.Id;
                }

                if (washerModel.washerFormula.ControllerId.HasValue)
                {
                    controllerId = washerModel.washerFormula.ControllerId.Value;
                }

                Push.PushToQueue(washerModel, this.UserId, washerModel.washerFormula.Id, (int)TcdAdminMessageTypes.TcdAddWasherFormulaWashStep, washerModel.washerFormula.EcolabAccountNumber);
            }

            var returnStatus = string.Empty;
            try
            {
                Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washerGroupFormulaWashStep.EcolabAccountNumber);

                if ((controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2) ||
                   (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14)) ||
                   (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7)))
                {
                    isDeviceConnected = SaveFormulaToPLC(washerGroupFormulaWashStep.EcolabAccountNumber, washerGroupFormulaWashStep.WasherGroupId, washerGroupFormulaWashStep.ProgramSetupId);
                }
                else
                {
                    foreach (var item in washerGroupFormulaWashStep.WasherDosingProducts)
                    {
                        List<Ecolab.Models.WasherGroup.InjectionDetails> objData =
                            this.injectionService.GetWasherStepInjectionDetails(this.EcolabAccountNumber, item.WasherDosingSetupId, washerGroupFormulaWashStep.ProgramSetupId, item.InjectionNumber);
                        List<InjectionDetails> injectionDetails = Mapper.Map<List<Ecolab.Models.WasherGroup.InjectionDetails>, List<InjectionDetails>>(objData);
                        returnStatus = this.InjectionReturnStatus(injectionDetails);
                    }
                }
                if (!string.IsNullOrEmpty(returnStatus))
                {
                    return Request.CreateResponse(HttpStatusCode.OK, returnStatus);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }

            if (!string.IsNullOrEmpty(returnStatus))
            {
                return this.Request.CreateResponse(HttpStatusCode.OK, false);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, true);
        }

        /// <summary>
        /// Injections the return status.
        /// </summary>
        /// <param name="injectionDetails">The injection details.</param>
        /// <returns>The Injection Status.</returns>
        private string InjectionReturnStatus(List<InjectionDetails> injectionDetails)
        {
            int defaultControllerId = 0;
            var groupedCustomerList = injectionDetails.GroupBy(u => u.ControllerId)
                                    .Select(grp => new { ControllerId = grp.Key, injectionDetails = grp.ToList() })
                                    .ToList();
            string returnStatus = string.Empty;
            int factorsMultiplier = 1;
            int controllerId = injectionDetails != null && injectionDetails.Count > 0 ? injectionDetails.FirstOrDefault().ControllerId : 0;
            List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, this.RoleId);
            var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Injection Quantity Multiplier").FirstOrDefault().FieldDefaultValue);

            if (factorsMulti.Any())
            {
                factorsMultiplier = (int)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
            }

            var controllerAdvData = controllerSetupService.GetControllerSetupAdvanceMetadataWithValues(3, controllerId, EcolabAccountNumber);
            var pumps = controllerAdvData.Select(x => x.FieldGroupInfo.AsEnumerable().Where(v => v.FieldLabel == "No. of Chemical Valves").FirstOrDefault().FieldDefaultValue);
            int valwesCount = 16;

            if (pumps.Any())
            {
                valwesCount = Convert.ToInt32(pumps.FirstOrDefault().ToString());
            }

            foreach (var grpItem in groupedCustomerList)
            {
                var taglst = new List<OpcTag>();

                var injections = grpItem.injectionDetails.GroupBy(x => x.InjectionNumber);

                foreach (var item in injections)
                {
                    var existingValwes = item.Select(x => x.ControllerEquipmentId).ToList();
                    int count = 1;
                    foreach (var injection in item.AsEnumerable())
                    {
                        int index = 0;
                        //Loop through total number of valwes
                        for (byte i = 1; i <= valwesCount; i++)
                        {
                            if (existingValwes.Contains(i))
                            {
                                var inj = item.AsEnumerable().ElementAt(index);
                                index++;
                                existingValwes.Remove(i);
                                GenerateTags(factorsMultiplier, taglst, inj, inj.ControllerEquipmentId, inj.Quantity);
                            }
                            else if (count == 1)
                            {
                                GenerateTags(factorsMultiplier, taglst, injection, i, 0);
                            }
                        }
                        count++;
                    }
                }

                defaultControllerId = injectionDetails.FirstOrDefault().ControllerId;

                try
                {
                    var plc = new PlcTagController(plcService, UserService, PlantService);
                    returnStatus += plc.ValidateOrWriteTags(taglst, grpItem.ControllerId, true);
                    if (string.IsNullOrEmpty(returnStatus))
                    {
                        plc.ValidateOrWriteTags(taglst, defaultControllerId);
                    }
                }
                catch (Exception ex)
                {
                    returnStatus = ex.Message;
                    Ecolab.Models.Common.ControllerInfoForPlc controllerInfoForPlc = plcService.GetControllerInfoForPlc(controllerId, EcolabAccountNumber).FirstOrDefault();
                    if (controllerInfoForPlc != null)
                    {
                        controlerName += controllerInfoForPlc.TopicName + ";";
                    }
                }
            }

            return returnStatus;
        }

        /// <summary>
        /// Generates the tags.
        /// </summary>
        /// <param name="factorsMultiplier">The factors multiplier.</param>
        /// <param name="taglst">The tag list data.</param>
        /// <param name="injection">The injection data.</param>
        /// <param name="controllerEquipId">The controller equip identifier.</param>
        /// <param name="quantity">The quantity value.</param>
		private static void GenerateTags(int factorsMultiplier, List<OpcTag> taglst, InjectionDetails injection, byte controllerEquipId, decimal quantity)
        {
            var tag = new OpcTag();
            int value;
            decimal nominalLoadPercent = injection.NominalLoad;
            decimal nominalLoad = nominalLoadPercent / 100;
            switch (injection.ControllerType)
            {
                case 1:
                    var x = injection.ProgramId + 10;
                    var y = ((Convert.ToInt32(injection.InjectionClass) - 1) * 60) + ((Convert.ToInt32(injection.InjectionNumber) - 1) * 10) + (controllerEquipId - 1);
                    var adderess = "N" + x + ":" + y;
                    value = Convert.ToInt32(((quantity * nominalLoad * injection.ReferenceLoad) / 100) * factorsMultiplier);
                    tag.Address = adderess;
                    tag.Value = Convert.ToString(value);
                    taglst.Add(tag);
                    break;

                case 2:
                    var beckhoffTagFormat = ConfigurationManager.AppSettings["BeckhoffTagFormat"];
                    beckhoffTagFormat = beckhoffTagFormat.Replace("x", Convert.ToString(injection.InjectionClass)).Replace("#F", Convert.ToString(injection.ProgramId)).Replace("#I", Convert.ToString(injection.InjectionNumber)).Replace("#V", Convert.ToString(controllerEquipId));
                    value = Convert.ToInt32(((quantity * nominalLoad * injection.ReferenceLoad) / 100) * 10);
                    tag.Address = beckhoffTagFormat;
                    tag.Value = Convert.ToString(value);
                    taglst.Add(tag);
                    break;
            }
        }

        /// <summary>
        /// Gets the tags status.
        /// </summary>
        /// <param name="tags">The my controller tags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Return the status whether success or failure.</returns>
        private string WriteTags(List<OpcTag> tags, int controllerId)
        {
            string returnStatus = string.Empty;

            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            TagCollection tagStatus = plc.WriteTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerId);

            foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
            {
                int last = tagStatus.Tags.LastIndexOf(status);
                if (last != 14 && !string.IsNullOrEmpty(status.Address))
                {
                    returnStatus += status.Address + ",";
                }
                else
                {
                    if (!string.IsNullOrEmpty(returnStatus))
                    {
                        returnStatus += status.Address;
                    }
                }
            }

            return returnStatus;
        }

        /// <summary>
        /// Get Formula Details for Add
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="washerGroupId">washer group id.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>
        /// Returns the Fromula Details
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetAddFormulaDetails(string ecolabAccountNumber, int washerGroupId, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();

            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, this.EcolabAccountNumber, washerGroupId);
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();
            objWasherGroupFormulaModel.GetDrainDestinationsList =
               Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.ConduitLocal.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            objWasherGroupFormulaModel.WasherGroupFormulaDetails = new List<WasherGroupFormulaModel>();

            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<WebModel.FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(formulaName);
            string comaprtmentStandardRunTime = string.Empty;
            if (washerGroupModel != null && washerGroupModel.First().ControllerModelId == 8)
            {
                comaprtmentStandardRunTime = "01:30";
            }
            else
            {
                comaprtmentStandardRunTime = "02:00";
            }
            WasherGroupFormulaModel washerGroupFormulaModel = new WasherGroupFormulaModel { Formulas = formulaNameDropDown, CompartmentStandardRunTime = comaprtmentStandardRunTime };
            washerGroupFormulaModel.CanAddInjections = true;
            washerGroupFormulaModel.ControllerId = washerGroupModel.ToList().Count() > 0 ? washerGroupModel.FirstOrDefault().ControllerId : 0;
            washerGroupFormulaModel.ControllerModelId = washerGroupModel.ToList().Count() > 0 ? washerGroupModel.FirstOrDefault().ControllerModelId : 0;

            washerGroupFormulaModel.MaxInjectionsCount = this.washerGroupFormulaService.GetMaxInjectionCount(ecolabAccountNumber, washerGroupId, washerGroupFormulaModel.ControllerModelId, washerGroupFormulaModel.ControllerId);

            int refrenceLoad = this.washerGroupFormulaService.GetReferenceLoad(ecolabAccountNumber, washerGroupId);

            objWasherGroupFormulaModel.DefaultDrainDestination = this.washerGroupFormulaService.GetDefaultDrainDestinationId();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails.Add(washerGroupFormulaModel);

            objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].ReferenceLoad = refrenceLoad;
            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washerGroupId);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Get Fromula Details for Add/Edit
        /// </summary>
        /// <param name="washerGroupId">Washer Group Id</param>
        /// <param name="programSetupId">Program Setup Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="regionId">Region of the plant.</param>
        /// <returns>
        /// Returns the Fromula Details
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetEditFormulaDetails(int washerGroupId, int programSetupId, string ecolabAccountNumber, int regionId)
        {
            var objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            int washerDosingCount = 0;
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            List<WasherFormulaWashStep> washerGroupFormulaWashSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, 0).OrderBy(x => x.StepNumber).ToList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);

            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, ecolabAccountNumber, washerGroupId);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();

            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = Mapper.Map<List<WasherFormulaWashStep>, List<WasherFormulaWashStepModel>>(washerGroupFormulaWashSteps);
            // if (objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel.Count == 0)
            //  {
            objWasherGroupFormulaModel.SensorAttached = this.washerGroupFormulaService.GetSensorAttachedValue(washerGroupId, ecolabAccountNumber);
            //  }
            foreach (WasherFormulaWashStepModel wfws in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {
                wfws.StepRunTime = this.ConvertionofSeconds(wfws.RunTime);
            }

            IEnumerable<WasherGroupFormula> washerGroupFormulaModelNumbers = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, 0);
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers = washerGroupFormulaModelNumbers.Select(EntityConverter.ConvertToWebModel).OrderBy(x => x.ProgramNumber).ToList();

            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            if (objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].TotalRunTime > 0)
            {
                objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].RunTime = this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].TotalRunTime);
                objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].CompartmentStandardRunTime = objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].StandardRunTime != 0 ? this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaDetails[0].StandardRunTime) : "02:00";
            }
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<WebModel.FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(formulaName);

            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {
                List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(ecolabAccountNumber, washStep.Id, false).ToList();

                if (washerGroupFormulaModel != null && washerGroupFormulaModel.Count() > 0
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId > 6
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId != 12
                    && washerGroupFormulaModel.FirstOrDefault().ControllerModelId != 13)
                {
                    foreach (WasherDosingProduct product in prodDosing)
                    {
                        foreach (ModelChemical.Chemicals chemical in chemicals)
                        {
                            if (product.ProductId == chemical.ProductId && product.ControllerEquipmentSetupId == chemical.ControllerEquipmentSetupId)
                            {
                                product.ControllerEquipmentTypeId = chemical.ControllerEquipmentTypeId;
                            }
                        }
                    }
                    prodDosing = (from pd in prodDosing where (pd.ControllerEquipmentTypeId != 0) select pd).ToList();
                }
                washStep.WasherDosingProducts = Mapper.Map<List<WasherDosingProduct>, List<WasherDosingProductModel>>(prodDosing);
            }

            foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
            {
                Ecolab.Models.WasherGroup.ConventionalAnalogueControl analogDosing = this.washerGroupFormulaService.GetWasherAnalogControl(ecolabAccountNumber, washStep.ProgramSetupId, washStep.StepNumber);
                washStep.ConventionalAnalogue = analogDosing;
                washerDosingCount++;
            }
            objWasherGroupFormulaModel.GetDrainDestinationsList =
                Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.ConduitLocal.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);
            foreach (WasherGroupFormulaModel item in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
            {
                item.Formulas = formulaNameDropDown;
            }
            objWasherGroupFormulaModel.DefaultDrainDestination = this.washerGroupFormulaService.GetDefaultDrainDestinationId();

            IEnumerable<Ecolab.Models.Washers.Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber, washerGroupId);
            washersModel.ToList().ForEach(a => a.WasherName = a.WasherNumber + " : " + a.WasherName);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Ecolab.Models.Washers.Washers>, IEnumerable<WashersModel>>(washersModel);
            objWasherGroupFormulaModel.WashersList = washers.OrderBy(x => x.WasherNumber);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="dosingSetupId">dosing setup id.</param>
        /// <param name="ecolabAccountNumber">Passing ecolab account number.</param>
        /// <param name="regionId">Passing RegionId.</param>
        /// <returns>
        /// the lists of wash step details.
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetEditFormulaWashStepDetails(int washerGroupId, int programSetupId, int dosingSetupId, string ecolabAccountNumber, int regionId)
        {
            var objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecolabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, ecolabAccountNumber, washerGroupId);
            List<WasherFormulaWashStep> washerGroupFormulaWashSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, dosingSetupId).ToList();

            objWasherGroupFormulaModel.WashStepsWithDosing = new List<KeyValuePair<int, int>>();
            List<WasherFormulaWashStep> washSteps = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(ecolabAccountNumber, washerGroupId, programSetupId, 0).ToList();
            foreach (WasherFormulaWashStep washStep in washSteps)
            {
                objWasherGroupFormulaModel.WashStepsWithDosing.Add(new KeyValuePair<int, int>(washStep.Id, washStep.StepNumber));
            }

            objWasherGroupFormulaModel.GetDrainDestinationsList =
               Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.ConduitLocal.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel = Mapper.Map<List<WasherFormulaWashStep>, List<WasherFormulaWashStepModel>>(washerGroupFormulaWashSteps);
            if (objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel != null)
            {
                if (objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel.Count > 0)
                {
                    objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel[0].StepRunTime = this.ConvertionofSeconds(objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel[0].RunTime);
                }
                objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
                foreach (WasherFormulaWashStepModel washStep in objWasherGroupFormulaModel.WasherGroupFormulaWashStepModel)
                {
                    List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(ecolabAccountNumber, washStep.Id, false).ToList();
                    washStep.WasherDosingProducts = Mapper.Map<List<WasherDosingProduct>, List<WasherDosingProductModel>>(prodDosing);
                }
            }

            objWasherGroupFormulaModel.GetDrainDestinationsList =
                Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.ConduitLocal.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Save the Formula Data
        /// </summary>
        /// <param name="formulaData">Washer Group Formula object</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage CreateFormula(WasherGroupFormulaModel formulaData)
        {
            int formulaId;
            bool isPLCConnected = false;
            try
            {
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                WasherGroupFormula washerGroupFormula = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(formulaData);
                washerGroupFormula.MyServiceCustFrmulaMchGrpGUID = Guid.NewGuid();
                formulaId = this.washerGroupFormulaService.AddWasherGroupFormula(washerGroupFormula, this.UserId, out lastModifiedTimeStamp);

                if (washerGroupFormula.WasherGroupTypeName == "Conventional")
                {
                    WasherFormulaModel washerModel = new WasherFormulaModel { washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormula.EcolabAccountNumber, washerGroupFormula.WasherGroupId, formulaId).FirstOrDefault() };
                    washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    washerModel.washerFormula.EcolabAccountNumber = washerGroupFormula.EcolabAccountNumber;
                    washerModel.washerFormula.WasherGroupId = washerGroupFormula.WasherGroupId;
                    Push.PushToQueue(washerModel, this.UserId, formulaId, (int)TcdAdminMessageTypes.TcdAddWasherFormula, washerModel.washerFormula.EcolabAccountNumber);
                }
                else if (washerGroupFormula.WasherGroupTypeName == "Tunnel")
                {
                    TunnelFormulaModel tunnelModel = this.washerGroupFormulaService.GetTunnelGroupFormulaResync(this.EcolabAccountNumber, formulaData.WasherGroupId, formulaId, true).FirstOrDefault();

                    Push.PushToQueue(tunnelModel, this.UserId, formulaId, (int)TcdAdminMessageTypes.TcdAddTunnelFormula, this.EcolabAccountNumber);
                }
            }
            catch (SqlException ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Number == 2627 ? "Storage tank already exists. Please try again." : ex.Message.Substring(9, 5));
            }

            isPLCConnected = SaveFormulaToPLC(formulaData.EcolabAccountNumber, formulaData.WasherGroupId, formulaId);

            if (isPLCConnected)
                return this.Request.CreateResponse(HttpStatusCode.OK, formulaId);
            else
                return this.Request.CreateResponse(HttpStatusCode.OK, formulaId + "," + isPLCConnected);
        }

        /// <summary>
        /// Deletes the washer group based on the washergroupId.
        /// </summary>
        /// <param name="formulaData">The Formula data</param>
        /// <returns>
        /// The string value the deletion is passed or failed.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage DeleteWasherGroup(WasherGroupFormulaModel formulaData)
        {
            var isPLCConnected = true;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            WasherGroupFormula washerGroupFormula = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(formulaData);

            Ecolab.Models.WasherGroup.WasherGroup washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupFormula.WasherGroupId, this.EcolabAccountNumber, 1, 12, string.Empty).FirstOrDefault();
            bool result = this.washerGroupFormulaService.DeleteWasherGroupFormula(washerGroupFormula, this.UserId, out lastModifiedTimeStamp);
            if (result == false)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            washerGroupFormula.IsDelete = true;
            if (washerGroupModel.WasherGroupTypeName == "Conventional")
            {
                WasherFormulaModel washerModel = new WasherFormulaModel { washerFormula = washerGroupFormula };
                washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                Push.PushToQueue(washerModel, this.UserId, washerGroupFormula.Id, (int)TcdAdminMessageTypes.TcdDeleteWasherFormula, washerModel.washerFormula.EcolabAccountNumber);
            }
            else if (washerGroupModel.WasherGroupTypeName == "Tunnel")
            {
                TunnelFormulaModel tunnelModel = this.washerGroupFormulaService.GetTunnelGroupFormulaResync(this.EcolabAccountNumber, formulaData.WasherGroupId, formulaData.Id, true).FirstOrDefault();
                Push.PushToQueue(tunnelModel, this.UserId, washerGroupFormula.Id, (int)TcdAdminMessageTypes.TcdDeleteTunnelFormula, tunnelModel.tunnelFormula.EcolabAccountNumber);
            }

            try
            {
                WriteDeletedFormulaDetailsToPLC(washerGroupModel.EcolabAccountNumber, washerGroupModel.WasherGroupId, washerGroupModel.WasherGroupTypeId, washerGroupModel.ControllerId);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                isPLCConnected = false;
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, isPLCConnected);
        }

        /// <summary>
        /// Deletes the Formula Wash Step based on the washergroupId.
        /// </summary>
        /// <param name="formulaWashStepData">Formula Wash Step Data</param>
        /// <returns>
        /// The string value the deletion is passed or failed.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage DeleteWasherGroupFormulaWashStep(WasherFormulaWashStepModel formulaWashStepData)
        {
            DateTime lastModifiedTimeStamp;
            WasherFormulaWashStep formulaWashData = Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(formulaWashStepData);
            bool result = this.washerGroupFormulaService.DeleteWasherGroupFormulaWashStep(formulaWashData, this.UserId, out lastModifiedTimeStamp);
            if (result == false)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            formulaWashData.IsDelete = true;
            WasherFormulaModel washerModel = new WasherFormulaModel { washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, formulaWashData.WasherGroupId, formulaWashData.ProgramSetupId).FirstOrDefault() };
            washerModel.washerFormula.LastModifiedTime = lastModifiedTimeStamp;
            washerModel.washerFormula.EcolabAccountNumber = this.EcolabAccountNumber;

            List<WasherFormulaWashStep> washerFormulaWashStep = new List<WasherFormulaWashStep> { formulaWashData };
            washerModel.washerFormulaWashStep = washerFormulaWashStep;

            Push.PushToQueue(washerModel, this.UserId, washerModel.washerFormula.Id, (int)TcdAdminMessageTypes.TcdDeleteWasherFormulaWashStep, washerModel.washerFormula.EcolabAccountNumber);

            SaveFormulaToPLC(formulaWashStepData.EcolabAccountNumber, formulaWashStepData.WasherGroupId, formulaWashStepData.ProgramSetupId);

            return this.Request.CreateResponse(HttpStatusCode.OK);
        }

        /// <summary>
        /// Update the Washer Group Formula
        /// </summary>
        /// <param name="formulaData">The Formula data.</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherGroupFormula(WasherGroupFormulaModel formulaData)
        {
            try
            {
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                WasherGroupFormula washerGroupFormula = Mapper.Map<WasherGroupFormulaModel, WasherGroupFormula>(formulaData);
                Ecolab.Models.WasherGroup.WasherGroup washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupFormula.WasherGroupId, this.EcolabAccountNumber, 1, 12, string.Empty).FirstOrDefault();
                this.washerGroupFormulaService.UpdateWasherGroupFormula(washerGroupFormula, this.UserId, out lastModifiedTimeStamp);

                if (washerGroupModel.WasherGroupTypeName == "Conventional")
                {
                    WasherFormulaModel washerModel = new WasherFormulaModel { washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(washerGroupFormula.EcolabAccountNumber, washerGroupFormula.WasherGroupId, washerGroupFormula.Id).FirstOrDefault() };
                    washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    washerModel.washerFormula.EcolabAccountNumber = washerGroupFormula.EcolabAccountNumber;
                    washerModel.washerFormula.WasherGroupId = washerGroupFormula.WasherGroupId;

                    Push.PushToQueue(washerModel, this.UserId, washerGroupFormula.Id, (int)TcdAdminMessageTypes.TcdUpdateWasherFormula, washerModel.washerFormula.EcolabAccountNumber);

                    //Write to PLC only if there were no wash steps, this is needed to write formula header details
                    washerModel.washerFormulaWashStep = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(this.EcolabAccountNumber, washerGroupFormula.WasherGroupId, washerGroupFormula.Id, 0).ToList();
                    formulaData.IsPLCConnected = true;
                    if (washerModel.washerFormulaWashStep.Count == 0)
                    {
                        formulaData.IsPLCConnected = SaveFormulaToPLC(washerGroupFormula.EcolabAccountNumber, washerGroupFormula.WasherGroupId, washerGroupFormula.Id);
                    }
                }
                else if (washerGroupModel.WasherGroupTypeName == "Tunnel")
                {
                    TunnelFormulaModel tunnelModel = this.washerGroupFormulaService.GetTunnelGroupFormulaResync(this.EcolabAccountNumber, washerGroupFormula.WasherGroupId, washerGroupFormula.Id, true).FirstOrDefault();

                    Push.PushToQueue(tunnelModel, this.UserId, washerGroupFormula.Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelFormula, tunnelModel.tunnelFormula.EcolabAccountNumber);

                    formulaData.IsPLCConnected = SaveFormulaToPLC(washerGroupFormula.EcolabAccountNumber, washerGroupFormula.WasherGroupId, washerGroupFormula.Id);
                }
            }
            catch (SqlException ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Number == 2627 ? "Storage tank already exists. Please try again." : "Unable to update the Storage tank. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, formulaData);
        }

        /// <summary>
        /// Injections the return status.
        /// </summary>
        /// <param name="injectionDetails">The injection details.</param>
        /// <returns></returns>
        private Dictionary<int, int> ValidateAndWriteInjectionsInPlc(List<Models.WasherGroup.InjectionDetails> injectionDetails)
        {
            string returnStatus = string.Empty;
            Dictionary<int, int> sucessInjections = new Dictionary<int, int>();
            var uniqueList = injectionDetails.Select(i => i.ControllerId).Distinct().ToList();
            foreach (var ctrlrId in uniqueList)
            {
                var injectionToSpecificCtrlr = injectionDetails.FindAll(i => i.ControllerId == ctrlrId);
                sucessInjections = BuildInjectionTagsAndWriteToPlc(injectionToSpecificCtrlr, ctrlrId);
            }

            return sucessInjections;
        }

        /// <summary>
        /// Builds the injection tags and write to PLC.
        /// </summary>
        /// <param name="injectionToSpecificCtrlr">The injection to specific CTRLR.</param>
        /// <param name="ctrlrId">The CTRLR identifier.</param>
        /// <returns>Return the status whether success or failure.</returns>
        private Dictionary<int, int> BuildInjectionTagsAndWriteToPlc(List<Models.WasherGroup.InjectionDetails> injectionToSpecificCtrlr, int ctrlrId)
        {
            var taglst = new List<OpcTag>();
            var plc = new PlcTagController(plcService, UserService, PlantService);
            string returnStatus = string.Empty;
            Dictionary<int, int> sucessInjections = new Dictionary<int, int>();
            foreach (var injection in injectionToSpecificCtrlr)
            {
                taglst = new List<OpcTag>();
                try
                {
                    var tag = new OpcTag();
                    int value;
                    decimal nominalLoadPercent = injection.NominalLoad;
                    decimal nominalLoad = nominalLoadPercent / 100;
                    int factorsMultiplier = 1;
                    List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, ctrlrId, this.EcolabAccountNumber, this.RoleId);
                    var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Injection Quantity Multiplier").FirstOrDefault().FieldDefaultValue);

                    if (factorsMulti.Any())
                    {
                        factorsMultiplier = (int)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
                    }

                    switch (injection.ControllerType)
                    {
                        case 1:
                            var x = injection.ProgramId + 10;
                            var y = ((Convert.ToInt32(injection.InjectionClass) - 1) * 60) + (Convert.ToInt32(injection.InjectionNumber - 1) * 10) + (injection.ControllerEquipmentId - 1);
                            var adderess = "N" + x + ":" + y;
                            value = Convert.ToInt32(((injection.Quantity * nominalLoad * injection.ReferenceLoad) / 100) * factorsMultiplier);
                            tag.Address = adderess;
                            tag.Value = Convert.ToString(value);
                            taglst.Add(tag);
                            break;

                        case 2:
                            var beckhoffTagFormat = ConfigurationManager.AppSettings["BeckhoffTagFormat"];
                            beckhoffTagFormat = beckhoffTagFormat.Replace("x", Convert.ToString(injection.InjectionClass)).Replace("#F", Convert.ToString(injection.ProgramId)).Replace("#I", Convert.ToString(injection.InjectionNumber)).Replace("#V", Convert.ToString(injection.ControllerEquipmentId));
                            value = Convert.ToInt32(((injection.Quantity * nominalLoad * injection.ReferenceLoad) / 100) * 10);
                            tag.Address = beckhoffTagFormat;
                            tag.Value = Convert.ToString(value);
                            taglst.Add(tag);
                            break;
                    }
                    returnStatus = plc.ValidateOrWriteTags(taglst, ctrlrId, true);
                    if (string.IsNullOrEmpty(returnStatus))
                    {
                        plc.ValidateOrWriteTags(taglst, ctrlrId);
                        if (!sucessInjections.ContainsKey(injection.WasherProgramSetupId))
                            sucessInjections.Add(injection.WasherProgramSetupId, Convert.ToInt32(injection.WasherGroupNumber));
                    }
                }
                catch
                {

                }
            }
            return sucessInjections;
        }

        /// <summary>
        /// Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="washergroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="ecolabAccountNumber">Passing ecolab account number.</param>
        /// <param name="formulaId">Passing the formula Id.</param>
        /// <param name="regionId">Passing region Id.</param>
        /// <returns>
        /// the lists of wash step details.
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetWashStepDetails(int washergroupId, string ecolabAccountNumber, int formulaId, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washergroupId, ecolabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, false);
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washergroupId, formulaId);
            IEnumerable<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, this.EcolabAccountNumber, washergroupId);

            objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objWasherGroupFormulaModel.GetChemicalList = Mapper.Map<IEnumerable<ModelChemical.Chemicals>, IEnumerable<WebModelChemical.ChemicalsModel>>(chemicals);
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(this.EcolabAccountNumber, 0, 0, 0);
            List<WebModel.FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(formulaName);
            foreach (WasherGroupFormulaModel item in objWasherGroupFormulaModel.WasherGroupFormulaDetails)
            {
                item.Formulas = formulaNameDropDown;
            }
            List<Model.WasherGroup.DrainDestinationList> washStepDrainDestinationSteps = this.washerGroupFormulaService.GetDrainDestinationsList();
            objWasherGroupFormulaModel.GetDrainDestinationsList =
               Mapper.Map<List<Ecolab.Models.WasherGroup.DrainDestinationList>, List<Ecolab.ConduitLocal.Web.Models.WasherGroup.DrainDestinationList>>(washStepDrainDestinationSteps);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Save Wash Step
        /// </summary>
        /// <param name="washdata">The Wash Step Data</param>
        /// <param name="productData">The Product Data</param>
        /// <returns>
        /// Http Response Message
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveWashStep(WasherFormulaWashStepModel washdata, WasherDosingProductModel productData)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK);
        }

        /// <summary>
        /// Gets the ChemicalsList
        /// </summary>
        /// <param name="term">Search term to get matching chemicals</param>
        /// <returns>
        /// List of ChemicalsModel
        /// </returns>
        [HttpGet]
        public IEnumerable<WebModelChemical.ChemicalsModel> GetChemicalList(string term)
        {
            List<ModelChemical.Chemicals> chemicals = this.prodMastService.FetchUsedChemicalList(term, this.EcolabAccountNumber, 0);
            List<WebModelChemical.ChemicalsModel> chemicalList = Mapper.Map<List<ModelChemical.Chemicals>, List<WebModelChemical.ChemicalsModel>>(chemicals);
            return chemicalList;
        }

        /// <summary>
        /// Gets the basic details for loading the wash step.
        /// </summary>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="dosingSetupId">Passing dosingSetupId.</param>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="regionId">Passing region Id.</param>
        /// <returns>
        /// wash step details.
        /// </returns>
        [HttpGet]
        public TunnelGroupFormulaLists GetTunnelDetails(int programSetupId, string ecoalabAccountNumber, int dosingSetupId, int washerGroupId, int regionId)
        {
            TunnelGroupFormulaLists objTunnelGroupFormulaListsModel = new TunnelGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecoalabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoalabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);
            objTunnelGroupFormulaListsModel.WashStepsWithDosing = new List<KeyValuePair<int, int>>();
            List<TunnelWashStep> washSteps = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, 0).ToList();
            foreach (TunnelWashStep washStep in washSteps)
            {
                objTunnelGroupFormulaListsModel.WashStepsWithDosing.Add(new KeyValuePair<int, int>(washStep.Id, washStep.CompartmentNumber));
            }

            dosingSetupId = dosingSetupId > 0 ? dosingSetupId : washSteps.FirstOrDefault() == null ? 0 : washSteps.FirstOrDefault().Id;
            TunnelWashStep washStepsData = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, dosingSetupId).FirstOrDefault();
            TunnelWashStepModel tunnelWashSteps = Mapper.Map<TunnelWashStep, TunnelWashStepModel>(washStepsData);
            if (tunnelWashSteps != null)
            {
                tunnelWashSteps.TunnelAnalogueControl = Mapper.Map<Ecolab.Models.WasherGroup.TunnelAnalogueControl, Web.Models.WasherGroup.TunnelAnalogueControlModel>(this.washerGroupFormulaService.FetchTunnelAnalogueControl(programSetupId, tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber));
                List<TunnelWashStepProducts> productData = this.washerGroupFormulaService.GetTunnelProductList(tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber, tunnelWashSteps.GroupId, dosingSetupId);
                List<TunnelWashStepProductsModel> productListData = Mapper.Map<List<TunnelWashStepProducts>, List<TunnelWashStepProductsModel>>(productData);
                tunnelWashSteps.ProductsList = productListData;
                tunnelWashSteps.RunTime = this.ConvertionofSeconds(tunnelWashSteps.StepRunTime);
                objTunnelGroupFormulaListsModel.TunnelWashStepsModel = new List<TunnelWashStepModel> { tunnelWashSteps };
            }

            objTunnelGroupFormulaListsModel.TunnelProductsWithInjectionCount = this.GetTunnelProdsWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            if (objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails != null)
            {
                foreach (WasherGroupFormulaModel wgfm in objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                }
            }
            return objTunnelGroupFormulaListsModel;
        }

        /// <summary>
        /// Update Tunnel Step.
        /// </summary>
        /// <param name="tunnelStepData">Passing the tunnelStepData.</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage UpdateTunnelStep([FromBody] List<TunnelWashStepModel> tunnelStepData)
        {
            bool isDeviceConnected = true;
            try
            {
                List<TunnelWashStep> tunnelStepDetails = Mapper.Map<List<TunnelWashStepModel>, List<TunnelWashStep>>(tunnelStepData);
                DateTime lastModifiedTimeStamp;
                this.washerGroupFormulaService.UpdateTunnelWashStep(tunnelStepDetails, this.UserId, out lastModifiedTimeStamp);

                TunnelFormulaModel tunnelModel = this.washerGroupFormulaService.GetTunnelGroupFormulaResync(this.EcolabAccountNumber, tunnelStepDetails.ElementAt(0).GroupId, tunnelStepData.FirstOrDefault().TunnelProgramSetupId, true).FirstOrDefault();

                Push.PushToQueue(tunnelModel, this.UserId, tunnelStepDetails.ElementAt(0).Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelFormulaWashStep, this.EcolabAccountNumber);

                isDeviceConnected = SaveFormulaToPLC(this.EcolabAccountNumber, tunnelStepDetails.ElementAt(0).GroupId, tunnelStepData.FirstOrDefault().TunnelProgramSetupId);
            }
            catch (SqlException ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Number == 2627 ? "Storage tank already exists. Please try again." : "Unable to update the Storage tank. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, isDeviceConnected ? 200 : 901);
        }

        /// <summary>
        /// Gets the basic details for loading the tunnel grid view data.
        /// </summary>
        /// <param name="programSetupId">Passing the programSetupId.</param>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="dosingSetupId">Passing dosing Setup Id.</param>
        /// <param name="washerGroupId">Passing the washer group Id for washer group details.</param>
        /// <param name="regionId">Passing region Id.</param>
        /// <returns>
        /// Gets all compartment details.
        /// </returns>
        [HttpGet]
        public TunnelGroupFormulaLists GetTunnelGridDetails(int programSetupId, string ecoalabAccountNumber, int dosingSetupId, int washerGroupId, int regionId)
        {
            TunnelGroupFormulaLists objTunnelGroupFormulaListsModel = new TunnelGroupFormulaLists();
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecoalabAccountNumber, washerGroupId, programSetupId);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoalabAccountNumber, 1, 12, string.Empty);
            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            List<TunnelWashStep> washSteps = this.washerGroupFormulaService.GetTunnelWashSteps(programSetupId, ecoalabAccountNumber, 0).ToList();
            List<PlantUtilityWaterTypeMaster> utilityData = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, regionId);

            objTunnelGroupFormulaListsModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            objTunnelGroupFormulaListsModel.TunnelProductsWithInjectionCount = this.GetTunnelProdsWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId).ToList();
            objTunnelGroupFormulaListsModel.TunnelWashStepsModel = new List<TunnelWashStepModel>();
            foreach (TunnelWashStep washStep in washSteps)
            {
                washStep.TunnelAnalogueControl = this.washerGroupFormulaService.FetchTunnelAnalogueControl(programSetupId, washStep.CompartmentNumber, ecoalabAccountNumber);
                TunnelWashStepModel tunnelWashSteps = Mapper.Map<TunnelWashStep, TunnelWashStepModel>(washStep);
                if (tunnelWashSteps == null)
                {
                    continue;
                }
                tunnelWashSteps.RunTime = this.ConvertionofSeconds(tunnelWashSteps.StepRunTime);
                List<TunnelWashStepProducts> productData = this.washerGroupFormulaService.GetTunnelProductList(tunnelWashSteps.CompartmentNumber, ecoalabAccountNumber, tunnelWashSteps.GroupId, tunnelWashSteps.TunnelDosingSetupId);
                List<TunnelWashStepProductsModel> productListData = Mapper.Map<List<TunnelWashStepProducts>, List<TunnelWashStepProductsModel>>(productData);
                tunnelWashSteps.ProductsList = productListData;
                objTunnelGroupFormulaListsModel.TunnelWashStepsModel.Add(tunnelWashSteps);
            }
            objTunnelGroupFormulaListsModel.WasheStepWaterTypes = utilityData.Select(EntityConverter.ConvertToWebModel).ToList();
            if (objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails != null)
            {
                foreach (WasherGroupFormulaModel wgfm in objTunnelGroupFormulaListsModel.WasherGroupFormulaDetails)
                {
                    wgfm.RunTime = wgfm.TotalRunTime != 0 ? this.ConvertionofSeconds(wgfm.TotalRunTime) : "00:00";
                }
            }
            return objTunnelGroupFormulaListsModel;
        }

        /// <summary>
        /// Gets the Tunnel products with count.
        /// </summary>
        /// <param name="ecoalabAccountNumber">Passing ecolab account number.</param>
        /// <param name="washerGroupId">Washer Group Id.</param>
        /// <param name="programSetupId">Program Setup Id.</param>
        /// <returns>
        /// Returns TunnelWashStepProductsModel list
        /// </returns>
        private IEnumerable<TunnelWashStepProductsModel> GetTunnelProdsWithInjectionCount(string ecoalabAccountNumber, int washerGroupId, int programSetupId)
        {
            IEnumerable<TunnelWashStepProducts> tunnelProdWithInj = this.washerGroupFormulaService.GetTunnelProductListForFormulaWithInjectionCount(ecoalabAccountNumber, washerGroupId, programSetupId);
            return Mapper.Map<IEnumerable<TunnelWashStepProducts>, IEnumerable<TunnelWashStepProductsModel>>(tunnelProdWithInj);
        }

        /// <summary>
        /// Updating the conventional wash setp injections for a formula
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">class object of washergroup formula washstep</param>
        /// <returns>
        /// Status of the operation.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage UpdateConventionalWashStepInjections(WasherFormulaWashStepModel washerGroupFormulaWashStep)
        {
            try
            {
                bool result = true;
                bool success = true;
                bool isDeviceConnected = true;
                WasherFormulaWashStep objWasherGroupFormulaWashStep = Mapper.Map<WasherFormulaWashStepModel, WasherFormulaWashStep>(washerGroupFormulaWashStep);
                DateTime lastModifiedTimeStamp;
                result = this.washerGroupFormulaService.UpdateConventionalWashStepInjections(objWasherGroupFormulaWashStep, this.UserId, out lastModifiedTimeStamp);
                success = this.washerGroupFormulaService.UpdateConventionalAnalogControl(objWasherGroupFormulaWashStep, this.UserId, out lastModifiedTimeStamp);
                WasherFormulaModel washerModel = new WasherFormulaModel
                {
                    washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId).FirstOrDefault()
                };
                washerModel.washerFormula.LastModifiedTime = lastModifiedTimeStamp;
                washerModel.washerFormula.EcolabAccountNumber = objWasherGroupFormulaWashStep.EcolabAccountNumber;
                washerModel.washerFormulaWashStep = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(this.EcolabAccountNumber, objWasherGroupFormulaWashStep.WasherGroupId, objWasherGroupFormulaWashStep.ProgramSetupId, objWasherGroupFormulaWashStep.Id).ToList();
                foreach (var item in washerModel.washerFormulaWashStep)
                {
                    List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(this.EcolabAccountNumber, item.Id, true).ToList();
                    item.WasherDosingProducts = prodDosing;
                    item.EcolabAccountNumber = this.EcolabAccountNumber;
                }
                Push.PushToQueue(washerModel, this.UserId, washerModel.washerFormula.Id, (int)TcdAdminMessageTypes.TcdUpdateWasherFormulaWashStep, washerModel.washerFormula.EcolabAccountNumber);
                try
                {
                    int controllerId = 0;
                    if (washerModel.washerFormula.ControllerId.HasValue)
                    {
                        controllerId = washerModel.washerFormula.ControllerId.Value;
                    }
                    Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washerGroupFormulaWashStep.EcolabAccountNumber);

                    if ((controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2) ||
                       (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14)) ||
                       (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7)))
                    {
                        isDeviceConnected = SaveFormulaToPLC(washerGroupFormulaWashStep.EcolabAccountNumber, washerGroupFormulaWashStep.WasherGroupId, washerGroupFormulaWashStep.ProgramSetupId);
                    }
                    else
                    {
                        List<Ecolab.Models.WasherGroup.InjectionDetails> objData = this.injectionService.GetWasherGroupFromulaInjectionDetails(this.EcolabAccountNumber, washerGroupFormulaWashStep.WasherGroupId, washerGroupFormulaWashStep.ProgramSetupId);
                        List<InjectionDetails> injectionDetails = Mapper.Map<List<Ecolab.Models.WasherGroup.InjectionDetails>, List<InjectionDetails>>(objData);

                        this.InjectionReturnStatus(injectionDetails);

                        if (!string.IsNullOrEmpty(controlerName))
                        {
                            string message = "909";
                            return Request.CreateResponse(HttpStatusCode.BadRequest, message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return Request.CreateResponse(HttpStatusCode.OK, isDeviceConnected ? 909 : 902);
                }

                if (!result)
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, 400);
                }
                return Request.CreateResponse(HttpStatusCode.OK, isDeviceConnected ? 200 : 901);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, int.Parse(Regex.Match(ex.Message, @"\d+").Value));
            }
        }

        /// <summary>
        /// save the Conventional washsteps Grid View details
        /// </summary>
        /// <param name="washerGroupFormulaWashStep">steps object of Wash Step</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage SaveConventionalWashStepGridView(List<WasherFormulaWashStepModel> washerGroupFormulaWashStep)//
        {
            try
            {
                List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
                bool? isDeviceConnected = null;
                List<WasherFormulaWashStep> objWasherGroupFormulaWashStep = Mapper.Map<List<WasherFormulaWashStepModel>, List<WasherFormulaWashStep>>(washerGroupFormulaWashStep);
                washerGroupFormulaService.SaveConventionalWashStepGridView(objWasherGroupFormulaWashStep, this.UserId);

                if (washerGroupFormulaWashStep != null && washerGroupFormulaWashStep.Count > 0)
                {
                    var washStepFormulaModel = washerGroupFormulaWashStep.FirstOrDefault();
                    WasherFormulaModel washerModel = new WasherFormulaModel();
                    washerModel.washerFormula = new WasherGroupFormula();
                    if (washStepFormulaModel != null)
                    {
                        washerModel = new WasherFormulaModel
                        {
                            washerFormula = this.washerGroupFormulaService.GetWasherGroupFormula(this.EcolabAccountNumber, washStepFormulaModel.WasherGroupId, washStepFormulaModel.ProgramSetupId).FirstOrDefault()
                        };

                        washerModel.washerFormula.LastModifiedTime = DateTime.SpecifyKind(washerModel.washerFormula.LastModifiedTime, DateTimeKind.Utc);
                        washerModel.washerFormula.EcolabAccountNumber = washStepFormulaModel.EcolabAccountNumber;
                        washerModel.washerFormulaWashStep = this.washerGroupFormulaService.GetWasherGroupFormulaWashSteps(this.EcolabAccountNumber, washStepFormulaModel.WasherGroupId, washStepFormulaModel.ProgramSetupId, 0).ToList();
                        foreach (var item in washerModel.washerFormulaWashStep)
                        {
                            List<WasherDosingProduct> prodDosing = this.washerGroupFormulaService.GetWasherDosingProduct(this.EcolabAccountNumber, item.Id, true).ToList();
                            item.WasherDosingProducts = prodDosing;
                            item.ConventionalAnalogue = this.washerGroupFormulaService.GetWasherAnalogControl(this.EcolabAccountNumber, item.ProgramSetupId, item.StepNumber);
                            item.EcolabAccountNumber = this.EcolabAccountNumber;
                        }

                        foreach (var item in washerModel.washerFormulaWashStep)
                        {
                            item.ProgramSetupId = washerModel.washerFormula.Id;
                        }

                        //Update Washer Group Formula For Cool Down Step
                        if (washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").Any())
                        {
                            washerModel.washerFormula.CoolDownStep = washerModel.washerFormulaWashStep.Where(x => x.WashOperation == "Cooldown").First().StepNumber;
                        }
                        else
                        {
                            washerModel.washerFormula.CoolDownStep = 0;
                        }
                        DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                        this.washerGroupFormulaService.UpdateWasherGroupFormula(washerModel.washerFormula, this.UserId, out lastModifiedTimeStamp);
                        Push.PushToQueue(washerModel, this.UserId, washerModel.washerFormula.Id, (int)TcdAdminMessageTypes.TcdAddWasherFormulaWashStep, washerModel.washerFormula.EcolabAccountNumber);
                    }

                    var returnStatus = string.Empty;

                    int controllerId = 0;
                    if (washerModel.washerFormula.ControllerId.HasValue)
                    {
                        controllerId = washerModel.washerFormula.ControllerId.Value;
                    }
                    if (controllerId != 0)
                    {
                        Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(controllerId, washStepFormulaModel.EcolabAccountNumber);
                        if ((controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2) ||
                            (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14))
                           || (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7)))
                        {
                            isDeviceConnected = SaveFormulaToPLC(washStepFormulaModel.EcolabAccountNumber, washStepFormulaModel.WasherGroupId, washStepFormulaModel.ProgramSetupId);
                        }
                    }
                    else
                    {
                        List<Ecolab.Models.WasherGroup.InjectionDetails> objData = this.injectionService.GetWasherGroupFromulaInjectionDetails(this.EcolabAccountNumber, washStepFormulaModel.WasherGroupId, washStepFormulaModel.ProgramSetupId);
                        List<InjectionDetails> injectionDetails = Mapper.Map<List<Ecolab.Models.WasherGroup.InjectionDetails>, List<InjectionDetails>>(objData);

                        returnStatus = this.InjectionReturnStatus(injectionDetails);
                        if (injectionDetails.Count > 0)
                        {
                            objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                            {
                                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                                ParentEntityId = Convert.ToInt32(washerModel.washerFormula.WasherGroupId),
                                Entity = Convert.ToInt32(PlcDiscrepancyEntity.ConventionalFormula),
                                EntityId = washStepFormulaModel.ProgramSetupId,
                                IsCentral = false,
                                ControllerId = injectionDetails.FirstOrDefault().ControllerId,
                                UserId = this.UserId,
                                LastModifiedUserId = this.UserId
                            });
                        }
                    }

                    if (!string.IsNullOrEmpty(returnStatus))
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, returnStatus);
                    }
                }
                
                if (isDeviceConnected.HasValue)
                {
                    if (isDeviceConnected == true)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, new { message = 200, source = SourcePage.FormulaPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, new { message = 901 });
                    }
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK, new { message = 200, source = SourcePage.FormulaPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return Request.CreateResponse(HttpStatusCode.BadRequest, int.Parse(Regex.Match(ex.Message, @"\d+").Value));
            }
        }
        /// <summary>
        /// Get Formula Details for Copy
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>
        /// Returns the Fromula Details
        /// </returns>
        [HttpGet]
        public WasherGroupFormulaLists GetImportFormulaDetails(string ecolabAccountNumber, int washerGroupId, int regionId)
        {
            WasherGroupFormulaLists objWasherGroupFormulaModel = new WasherGroupFormulaLists();

            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(-1, ecolabAccountNumber, 1, 0, string.Empty);

            string washerGroupType = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).WasherGroupTypeName;
            int controllerModelId = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).ControllerModelId;

            if (washerGroupType.Equals("Conventional"))
            {
                if (controllerModelId > 6 || controllerModelId != 12 || controllerModelId != 13)
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Conventional") && t.ControllerModelId == controllerModelId).ToList();
                }
                else
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Conventional")).ToList();
                }
            }
            else
            {
                if (controllerModelId > 6 || controllerModelId != 12 || controllerModelId != 13)
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Tunnel") && t.ControllerModelId == controllerModelId).ToList();
                }
                else
                {
                    objWasherGroupFormulaModel.WasherGroupDetails = washerGroupModel.Select(EntityConverter.ConvertToWebModel).ToList().Where(t => t.WasherGroupTypeName.Equals("Tunnel")).ToList();
                }
            }

            objWasherGroupFormulaModel.WasherGroupFormulaDetails = new List<WasherGroupFormulaModel>();
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers = new List<WasherGroupFormulaModel>();
            List<Model.Formula> formulaName = this.progMasterService.GetFormulaDetails(ecolabAccountNumber, 0, 0, 0);
            List<WebModel.FormulaModel> formulaNameDropDown = Mapper.Map<List<Model.Formula>, List<WebModel.FormulaModel>>(formulaName);

            WasherGroupFormulaModel washerGroupFormulaModel = new WasherGroupFormulaModel { Formulas = formulaNameDropDown };
            washerGroupFormulaModel.WasherGroupTypeName = washerGroupModel.FirstOrDefault(t => t.WasherGroupId == washerGroupId).WasherGroupTypeName;

            foreach (var item in objWasherGroupFormulaModel.WasherGroupDetails)
            {
                IEnumerable<WasherGroupFormula> washerGroupFormula = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, item.WasherGroupId, -1);
                objWasherGroupFormulaModel.WasherGroupFormulaDetails.AddRange(washerGroupFormula.Select(EntityConverter.ConvertToWebModel).ToList().OrderBy(o => o.ProgramNumber).ToList());
            }
            washerGroupFormulaModel.WasherGroupTypeName = washerGroupType;
            washerGroupFormulaModel.ProgramId = objWasherGroupFormulaModel.WasherGroupFormulaDetails.Where(t => t.WasherGroupId == washerGroupId).ToList().Count > 0 ?
                                                objWasherGroupFormulaModel.WasherGroupFormulaDetails.FirstOrDefault(t => t.WasherGroupId == washerGroupId).ProgramId : 0;
            objWasherGroupFormulaModel.WasherGroupFormulaNumbers.Add(washerGroupFormulaModel);

            return objWasherGroupFormulaModel;
        }

        /// <summary>
        /// Save the Formula Data
        /// </summary>
        /// <param name="formulaDataContainer">The formula data container.</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveCopyFormula(WebModel.WasherGroup.CopyFormulaContainerModel formulaDataContainer)
        {
            try
            {
                Model.WasherGroup.CopyFormulaContainer copyFormulaList = Mapper.Map<WebModel.WasherGroup.CopyFormulaContainerModel, Model.WasherGroup.CopyFormulaContainer>(formulaDataContainer);

                this.washerGroupFormulaService.SaveCopyFormula(copyFormulaList, this.UserId);

                Push.PushToQueue(copyFormulaList, this.UserId, 0, (int)TcdAdminMessageTypes.TcdCopyFormula, copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber);
            }
            catch (SqlException ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message.Substring(9, 5));
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, "Formula imported successfully.");
        }

        /// <summary>
        /// Find the missing Chemicals if any
        /// </summary>
        /// <param name="formulaDataContainer">Washer Group Formula object</param>
        /// <returns>
        /// http response message.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage FindMissingChemical(WebModel.WasherGroup.CopyFormulaContainerModel formulaDataContainer)
        {
            List<object> data = new List<object>();
            var tunnelCannotImport = false;
            try
            {
                Model.WasherGroup.CopyFormulaContainer copyFormulaList = Mapper.Map<WebModel.WasherGroup.CopyFormulaContainerModel, Model.WasherGroup.CopyFormulaContainer>(formulaDataContainer);
                IEnumerable<ModelChemical.Chemicals> fromWasherGroupChemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);
                IEnumerable<ModelChemical.Chemicals> toWasherGroupChemicals = this.prodMastService.FetchUsedChemicalList(string.Empty, copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().ToWasherGroupId);
                var missingFromChemicals = (from obj1 in fromWasherGroupChemicals where !toWasherGroupChemicals.Any(x => x.ProductId == obj1.ProductId) select obj1).ToList();
                var missingToChemicals = (from obj1 in toWasherGroupChemicals where !fromWasherGroupChemicals.Any(x => x.ProductId == obj1.ProductId) select obj1).ToList();
                IEnumerable<ModelChemical.Chemicals> fromWasherDosingProductList = this.prodMastService.FetchWasherDosingProductList(copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);

                var tunnelUnUsedChemicals = (from obj1 in toWasherGroupChemicals where !fromWasherDosingProductList.Any(x => x.ProductId == obj1.ProductId) select obj1).OrderBy(x => x.Name).ToList();

                data.Add(missingFromChemicals);
                data.Add(tunnelUnUsedChemicals);
                if (missingFromChemicals.ToList().Count > 0 || missingToChemicals.ToList().Count > 0)
                {
                    tunnelCannotImport = true;
                }
                else
                {
                    if (copyFormulaList.FormulaList.FirstOrDefault().WasherGroupTypeName.Equals("Tunnel"))
                    {
                        tunnelCannotImport = this.washerGroupFormulaService.ValidateTunnelSettings(copyFormulaList.FormulaList.FirstOrDefault().EcolabAccountNumber, copyFormulaList.FormulaList.FirstOrDefault().ToWasherGroupId, copyFormulaList.FormulaList.FirstOrDefault().FromWasherGroupId);
                    }
                }
                data.Add(tunnelCannotImport);
            }
            catch (SqlException ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message.Substring(9, 5));
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        /// Update Washer Group Formula From Group One
        /// </summary>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage UpdateWasherFormulaFromGroupOne(WasherGroup washerGroup)
        {
            Ecolab.Models.WasherGroup.WasherGroup washerGroupData = Mapper.Map<WasherGroup, Ecolab.Models.WasherGroup.WasherGroup>(washerGroup);
            IEnumerable<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupData.WasherGroupId, washerGroupData.EcolabAccountNumber, 0, 0, string.Empty);
            if (washerGroupModel.FirstOrDefault().UseGroup1Formulas == false)
            {
                washerGroupModel.FirstOrDefault().UseGroup1Formulas = true;
            }
            else
            {
                washerGroupModel.FirstOrDefault().UseGroup1Formulas = false;
            }
            WasherGroupFormulaModel washerGroupFormulaModel = new WasherGroupFormulaModel { WasherGroupId = washerGroup.WasherGroupId, EcolabAccountNumber = washerGroup.EcolabAccountNumber, UseGroup1Formulas = washerGroupModel.First().UseGroup1Formulas };
            HttpResponseMessage httpResponseMessage = null;
            try
            {
                httpResponseMessage = SaveFormulasToPLC(washerGroupFormulaModel);
                string responseText = ((System.Net.Http.ObjectContent)httpResponseMessage.Content).Value.ToString();

                if (responseText.Contains("Sent Formula details Successfully"))
                {
                    DateTime lastModifiedTimeStamp;
                    this.washerGroupService.SaveWasherGroup(washerGroupModel.FirstOrDefault(), this.UserId, washerGroup.EcolabAccountNumber, out lastModifiedTimeStamp);
                    washerGroupModel.FirstOrDefault().LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(washerGroupModel.FirstOrDefault(), this.UserId, washerGroupData.WasherGroupId, (int)TcdAdminMessageTypes.TcdUpdateWasherGroup, washerGroupData.EcolabAccountNumber);
                    return this.Request.CreateResponse(HttpStatusCode.OK, washerGroupModel.FirstOrDefault().UseGroup1Formulas);
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, ((System.Net.Http.ObjectContent)httpResponseMessage.Content).Value.ToString());
                }
            }
            catch
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ((System.Net.Http.ObjectContent)httpResponseMessage.Content).Value.ToString());
            }
        }

        /// <summary>
		///  Get plant chain id.
		/// </summary>
		/// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
		/// <returns>Integer value of plant chain id.</returns>
        [HttpGet]
        public int GetPlantChainId(string ecolabAccountNumber)
        {
            int plantChainId = this.progMasterService.GetPlantChainId(ecolabAccountNumber);
            return plantChainId;
        }
        /// <summary>
        /// Method to convert into seconds
        /// </summary>
        /// <param name="runTime">Run time parameter</param>
        /// <returns>Returns time in seconds.</returns>
        private string ConvertionofSeconds(int runTime)
        {
            string strRunTime;
            if (runTime != 0)
            {
                int mins = runTime / 60;
                int secs = runTime % 60;
                if (mins < 10)
                {
                    strRunTime = "0" + mins;
                }
                else
                {
                    strRunTime = Convert.ToString(mins);
                }
                if (secs < 10)
                {
                    strRunTime = strRunTime + ":" + "0" + secs;
                }
                else
                {
                    strRunTime = strRunTime + ":" + secs;
                }
            }
            else
            {
                strRunTime = "01:30";
            }

            return strRunTime;
        }

        /// <summary>
        /// Save Formula To PLC
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="washerGroupId">Washer Group Id</param>
        /// <param name="programSetupId">Program Setup Id</param>
        /// <returns>Returns boolean value.</returns>
        private bool SaveFormulaToPLC(string ecolabAccountNumber, int washerGroupId, int programSetupId)
        {
            bool isDeviceConnected = true;
            IEnumerable<WasherGroupFormula> washerGroupFormulaModel = this.washerGroupFormulaService.GetWasherGroupFormula(ecolabAccountNumber, washerGroupId, 0).Where(x => x.Id == programSetupId);
            List<WasherGroupFormulaModel> washerGroupFormulaDetails = washerGroupFormulaModel.Select(EntityConverter.ConvertToWebModel).ToList();
            //washerGroupFormulaDetails.ForEach(x => x.WasherGroupId = washerGroupId);
            if (washerGroupFormulaDetails.FirstOrDefault() != null)
            {
                if (washerGroupFormulaDetails.FirstOrDefault().ControllerId.Value > 0)
                {
                    Model.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(washerGroupFormulaDetails.FirstOrDefault().ControllerId.Value, ecolabAccountNumber);

                    if ((controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2) ||
                       (controllerDetails.ControllerModelId == 11 && (controllerDetails.ControllerTypeId == 12 || controllerDetails.ControllerTypeId == 13 || controllerDetails.ControllerTypeId == 14)) ||
                       (controllerDetails.ControllerModelId == 8 && (controllerDetails.ControllerTypeId == 6 || controllerDetails.ControllerTypeId == 7)))
                    {
                        try
                        {
                            WriteFormulaDetailsToPlc(controllerDetails.ControllerId, washerGroupFormulaDetails.FirstOrDefault());
                        }
                        catch (Exception ex)
                        {
                            isDeviceConnected = false;
                            ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        }
                    }
                }
            }
            return isDeviceConnected;
        }
    }
}