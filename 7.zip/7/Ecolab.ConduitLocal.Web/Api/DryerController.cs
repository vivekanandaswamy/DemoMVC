﻿// -----------------------------------------------------------------------
// <copyright file="DryerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Text.RegularExpressions;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.PlantSetup.Dryer;
    using Models.PlantSetup.Dryer;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Dryer;
	using Utilities;

    /// <summary>
    ///     Api controller for DryerController
    /// </summary>
    [Authorize]
    public class DryerController : BaseApiController
    {
        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private readonly IDryerGroupService dryerGroupService;

        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private readonly IDryerService dryerService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="DryerController"/>class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService"></param>
        /// <param name="dryerGroupService">dryerGroupService</param>
        /// <param name="dryerService">dryerService</param>
        public DryerController(IUserService userService, IPlantService plantService, IDryerGroupService dryerGroupService, IDryerService dryerService) : base(userService, plantService)
        {
            this.dryerGroupService = dryerGroupService;
            this.dryerService = dryerService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        #region DryerGroups

        /// <summary>
        ///     Method to get the Dryers along with Dryer Groups
        /// </summary>
        /// <returns>get dryer Group list</returns>
        public List<DryerGroupModel> Get()
        {
            List<DryerGroup> dryers = this.dryerGroupService.FetchDryerGroupDetails(this.EcolabAccountNumber);
            List<DryerGroupModel> dryerGroupModel = Mapper.Map<List<DryerGroup>, List<DryerGroupModel>>(dryers);
            dryerGroupModel.ForEach(x => x.Dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0));
            var groupList = dryerGroupModel.Select(x => new { x.Id, x.Name, x.DesiredUnits, x.IsDeleted, x.LastModifiedTimeStampDryerGroup }).Where(x => x.IsDeleted == false).Distinct().ToList();

            return (from @group in groupList let dryersList = dryerGroupModel.FindAll(x => x.Id == @group.Id) let drList = dryersList.Where(dr => dr.Dryer.Number > 0).Select(dr => new DryerModel { GroupId = @group.Id, Id = dr.Dryer.Id, Name = dr.Dryer.Name, Number = dr.Dryer.Number, Nominalload = dr.Dryer.Nominalload, ConvertedNominalload = dr.Dryer.ConvertedNominalload, ConvertedNominalloadAsString = dr.Dryer.ConvertedNominalload.ToString("#,0.##"), DesiredUnits = dr.Dryer.DesiredUnits, LastModifiedTimeStampDryer = dr.Dryer.LastModifiedTimeStampDryer , DryerType = new DryerTypeModel { Id = dr.Dryer.DryerType.Id, Name = dr.Dryer.DryerType.Name } }).ToList() select new DryerGroupModel { Id = @group.Id, Name = @group.Name, DesiredUnits = @group.DesiredUnits, LastModifiedTimeStampDryerGroup = @group.LastModifiedTimeStampDryerGroup,Dryers = drList.OrderBy(_ => _.Number).ToList() }).ToList();
                        }

        /// <summary>
        ///     Method to create a new Dryer group
        /// </summary>
        /// <param name="dryerGroup">Dryer Group</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage CreateDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            try
            {
                int result = 0;
                DryerGroup dryerGroupData = new DryerGroup { Name = dryerGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };
                DateTime lastModifiedTimeStamp;
                result = this.dryerGroupService.InsertDryerGroup(dryerGroupData, this.UserId, out lastModifiedTimeStamp);
                dryerGroupData.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc); 
                dryerGroupData.Id = result;

                switch (result)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);

                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                Push.PushToQueue(dryerGroupData, this.UserId, dryerGroupData.Id, (int)TcdAdminMessageTypes.TcdAddDryerGroup, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Dryer group
        /// </summary>
        /// <param name="dryerGroup">Dryer Group</param>
        /// <returns>update dryer group</returns>
        [HttpPost]
        public HttpResponseMessage UpdateDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            try
            {
                DryerGroup dryerGroupData = new DryerGroup { Id = dryerGroup.Id, Name = dryerGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };

                DateTime lastModifiedTimeStamp;
                int response = this.dryerGroupService.UpdateDryerGroup(dryerGroupData, this.UserId, out lastModifiedTimeStamp);
                dryerGroupData.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc); 

                switch (response)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }

                if (response > 0 && dryerGroupData.Id > 0)
                {
                    Push.PushToQueue(dryerGroupData, this.UserId, dryerGroupData.Id, (int)TcdAdminMessageTypes.TcdUpdateDryerGroup, this.EcolabAccountNumber);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a DryerGroup
        /// </summary>
        /// <param name="dryerGroup">dryerGroup</param>
        /// <returns>delete DryerGroup</returns>
        [HttpPost]
        public HttpResponseMessage DeleteDryerGroup([FromBody] DryerGroupModel dryerGroup)
        {
            try
            {
                DryerGroup dryerGroupData = new DryerGroup { Id = dryerGroup.Id, Name = dryerGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };
                IPrincipal user = HttpContext.Current.User;
                int userId = ((CustomPrincipal)user).UserId;
                string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;

                DateTime lastModifiedTimeStamp;
                int result = this.dryerGroupService.DeleteDryerGroup(dryerGroupData, dryerGroupData.Id, userId, ecolabAccountNumber, out lastModifiedTimeStamp);
                dryerGroupData.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc); 
                dryerGroupData.IsDelete = true;

                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }

                Push.PushToQueue(dryerGroupData, this.UserId, dryerGroupData.Id, (int)TcdAdminMessageTypes.TcdDeleteDryerGroup, this.EcolabAccountNumber);

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion

        #region Dryer
        /// <summary>
        /// Fetch Dryer Types
        /// </summary>
        /// <returns>All Dryer types</returns>
        [HttpGet]
        public List<DryerTypeModel> FetchDryerTypes()
        {
            List<DryerType> dryerType = this.dryerService.FetchDryerTypes(this.EcolabAccountNumber);
            return Mapper.Map<List<DryerType>, List<DryerTypeModel>>(dryerType).ToList();
        }

        /// <summary>
        ///     Method to create a new Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>Crreate dryer</returns>
        [HttpPost]
        public HttpResponseMessage CreateDryer([FromBody] DryerModel dryer)
        {
            int result = 0;
            try
            {
                dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);
                Dryer dryerData = new Dryer { Number = dryer.Number, Name = dryer.Name, Nominalload = dryer.Nominalload, ConvertedNominalload = dryer.ConvertedNominalload, DryerType = new DryerType { Id = dryer.DryerType.Id }, EcolabAccountNumber = this.EcolabAccountNumber, GroupId = dryer.GroupId, GroupName = dryer.GroupName };

                DateTime lastModifiedTimeStamp;
                result = this.dryerService.InsertDryer(dryerData, dryer.GroupId, this.UserId, out lastModifiedTimeStamp);
                dryerData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                dryerData.Id = result;
                
                switch (result)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
               
                Push.PushToQueue(dryerData, this.UserId, dryerData.Id, (int)TcdAdminMessageTypes.TcdAddDryers, this.EcolabAccountNumber);

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>update dryer</returns>
        [HttpPost]
        public HttpResponseMessage UpdateDryer([FromBody] DryerModel dryer)
        {
            int response = 0;
            dryer.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);
            Dryer dryerData = new Dryer { GroupId = dryer.GroupId, Id = dryer.Id, Number = dryer.Number, Name = dryer.Name, Nominalload = dryer.Nominalload, ConvertedNominalload = dryer.ConvertedNominalload, DryerType = new DryerType { Id = dryer.DryerType.Id }, EcolabAccountNumber = this.EcolabAccountNumber };
            try
            {
                DateTime lastModifiedTimeStamp;
                response = this.dryerService.UpdateDryer(dryerData, this.UserId, out lastModifiedTimeStamp);
                dryerData.LastModifiedTimeStampDryer = lastModifiedTimeStamp;
				dryerData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryerData.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                switch (response)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                Push.PushToQueue(dryerData, this.UserId, dryerData.Id, (int)TcdAdminMessageTypes.TcdUpdateDryers, this.EcolabAccountNumber);
                
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a Dryer
        /// </summary>
        /// <param name="dryer">dryer</param>
        /// <returns>delete dryer</returns>
        [HttpPost]
        public HttpResponseMessage DeleteDryer([FromBody] DryerModel dryer)
        {
            int result = 0;
            Dryer dryerData = new Dryer { Id = dryer.Id, DryerType = new DryerType { Id = dryer.DryerType.Id }, Name = dryer.Name, EcolabAccountNumber = this.EcolabAccountNumber, Number = dryer.Number, GroupId = dryer.GroupId };
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;
            string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;
            try
            {
                DateTime lastModifiedTimeStamp;
                result = this.dryerService.DeleteDryer(dryerData, dryerData.Id, userId, ecolabAccountNumber, out lastModifiedTimeStamp);
                dryerData.LastModifiedTimeStampDryer = lastModifiedTimeStamp;
                dryerData.IsDelete = true;
				dryerData.LastModifiedTimeStampDryer = DateTime.SpecifyKind(dryerData.LastModifiedTimeStampDryer, DateTimeKind.Utc);
                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }
                Push.PushToQueue(dryerData, this.UserId, dryerData.Id, (int)TcdAdminMessageTypes.TcdDeleteDryers, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK);
                ;
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion
    }
}