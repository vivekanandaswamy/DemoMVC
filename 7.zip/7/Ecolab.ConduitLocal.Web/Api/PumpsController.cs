﻿// -----------------------------------------------------------------------
// <copyright file="PumpsController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Pump Controller </summary>
// -----------------------------------------------------------------------

using Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps;
using Ecolab.Models.ControllerSetup;

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.ConduitLocal.Models;
    using Ecolab.Models.ControllerSetup.Pumps;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Elmah;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Plc;
    using Utilities;
    using PumpsModel = Models.ControllerSetup.Pumps.PumpsModel;
    using Models.Common;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     Api Controller for Pumps/Valves
    /// </summary>
    [Authorize]
    public class PumpsController : BaseApiController
    {
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Pumps Setup Service
        /// </summary>
        private readonly IPumpsService pumpServices;

        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpsController" /> class.
        /// </summary>
        /// <param name="pumpServices">The pump services.</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        public PumpsController(IPumpsService pumpServices, IPlcService plcService, IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService) : base(userService, plantService)
        {
            this.pumpServices = pumpServices;
            this.plcService = plcService;
            this.controllerSetupService = controllerSetupService;
            PumpsController.FactorsMultiplier = 10;
            PumpsController.OunceSecMultiplier = 10;
        }

        /// <summary>
        ///  Gets or sets Static variable to hold factors multiplier for k-factor
        /// </summary>
        public static int FactorsMultiplier { get; set; }

        /// <summary>
        /// Gets or sets Static variable to hold ouncepersecond multiplier for time volume calibration
        /// </summary>
        public static int OunceSecMultiplier { get; set; }

        /// <summary>
        ///     To Get the Product List
        /// </summary>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number.</param>
        /// <returns>Product List</returns>
        [HttpGet]
        public List<ProductModel> GetProductList(string ecolabAccountNumber)
        {
            try
            {
                return this.pumpServices.GetProductList(ecolabAccountNumber).ToList();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return new List<ProductModel>();
            }
        }

        /// <summary>
        /// Getting All Pumps based on Controller id and EcoLab AccountNumber
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="controlNumber">Control Number</param>
        /// <param name="showOption">Option value(Active/Inactive)</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <returns>
        /// Pumps List
        /// </returns>
        public List<PumpsModel> GetPumps(string ecoLabAccountNumber, int controlNumber, string showOption, int controllerModelId)
        {
            List<PumpsModel> pumpMetaData = new List<PumpsModel>();
            try
            {
                if (showOption == "All")
                {
                    showOption = string.Empty;
                }

                List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel> pumpDataModel = this.pumpServices.GetPumps(ecoLabAccountNumber, controlNumber, showOption);
                pumpMetaData = Mapper.Map<List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel>, List<PumpsModel>>(pumpDataModel);
                pumpMetaData.ForEach(_ => _.PumpCalibrationAsString = _.PumpCalibration == 0 ? "0" : _.PumpCalibration.ToString("#,0.0#"));
                pumpMetaData.ForEach(_ => _.KFactorAsString = _.KFactor == 0 ? "0" : _.KFactor.ToString("#,0.0#"));

                List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controlNumber, this.EcolabAccountNumber, this.RoleId);
                var factorsMulti = controllerSetupMetaDataModel.Select(x =>
                {
                    ControllerSetupMetaData controllerSetupMetaData = x.FieldGroupInfo.AsEnumerable().FirstOrDefault(_ => _.FieldLabel == "Factors Multiplier");
                    return controllerSetupMetaData != null ? controllerSetupMetaData.FieldDefaultValue : null;
                });
                var ounceSecMulti = controllerSetupMetaDataModel.Select(x =>
                {
                    ControllerSetupMetaData setupMetaData = x.FieldGroupInfo.AsEnumerable().FirstOrDefault(_ => _.FieldLabel == "OZ/Second Multiplier");
                    return setupMetaData != null ? setupMetaData.FieldDefaultValue : null;
                });
                string factorMultiplier = factorsMulti.FirstOrDefault();
                string oneSecMultiplier = ounceSecMulti.FirstOrDefault();
                if (factorMultiplier != null && oneSecMultiplier != null)
                {
                    FactorsMultiplier = (int)Convert.ToDecimal(factorMultiplier);
                    OunceSecMultiplier = (int)Convert.ToDecimal(oneSecMultiplier);
                }
                List<string> tagCollectionList = new List<string>();
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);

                TagCollection tagStatus = new TagCollection();
                var tagsList = new List<OpcTag>();
                pumpMetaData.Where(_ => !string.IsNullOrEmpty(_.ProductName)).Each(_ => _.ProductName = Regex.Replace(_.ProductName.ToString().Trim(), @"\s+", " "));

                //E-Control Plus
                if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8)
                {
                    return BuildPumpsModelForEControlPlus(pumpMetaData, plc);
                }
                else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11)
                {
                    //11 - PLC XL; 
                    return BuildPLCXLModelWithPLCOverrides(pumpMetaData);
                }
                else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 7)
                {
                    //7 - myControl
                    return BuildMyControlModelWithPLCOverrides(pumpMetaData);
                }
                else
                {
                    foreach (PumpsModel model in pumpMetaData)
                    {
                        if (controllerModelId == 3)
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = "stMachineConfig.xFlowSwitchType[" + model.ControllerEquipmentId + "]",
                                Value = (model.FlowDetectorType == 1) ? true.ToString() : false.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                            });

                            //Flow Switch Alarm
                            tagsList.Add(new OpcTag
                            {
                                Address = "stMachineConfig.xFlowAlarmOverride[" + model.ControllerEquipmentId + "]",
                                Value = model.FlowSwitchAlarm.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                            });

                            //Flow Meter Alarm
                            tagsList.Add(new OpcTag
                            {
                                Address = "stMachineConfig.xFlowMeterAlarmOverride[" + model.ControllerEquipmentId + "]",
                                Value = model.FlowMeterAlarm.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                            });

                            //Flow Meter Type
                            tagsList.Add(new OpcTag
                            {
                                Address = "stPumpConfig[" + model.ControllerEquipmentId + "].eFlowMeterMode",
                                Value = model.FlowMeterType.ToString(),
                            });

                            //Flow Alarm Delay Time
                            tagsList.Add(new OpcTag
                            {
                                Address = "stPumpConfig[" + model.ControllerEquipmentId + "].fLossOfFlowDuration",
                                Value = model.FlowAlarmDelay.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeFloat
                            });

                            //Flow Meter Pump Delay
                            tagsList.Add(new OpcTag
                            {
                                Address = "stPumpConfig[" + model.ControllerEquipmentId + "].fTdFlowMeter",
                                Value = model.FlowMeterPumpDelay.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeFloat
                            });

                            //Flow Meter Alarm Delay
                            tagsList.Add(new OpcTag
                            {
                                Address = "stPumpConfig[" + model.ControllerEquipmentId + "].fTAlarmDelayFlowMeter",
                                Value = model.FlowMeterAlarmDelay.ToString(),
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeFloat
                            });
                        }
                        if (!string.IsNullOrEmpty(model.LfsChemicalNameTag))
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = model.LfsChemicalNameTag,
                                Value = model.LfsChemicalName,
                                TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeString
                            });
                        }

                        if (!string.IsNullOrEmpty(model.KfactorTag))
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = model.KfactorTag,
                                Value = Convert.ToInt32(model.KFactor * FactorsMultiplier).ToString()
                            });
                        }

                        if (!string.IsNullOrEmpty(model.CalibrationTag))
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = model.CalibrationTag,
                                Value = Convert.ToInt32(model.PumpCalibration * OunceSecMultiplier).ToString()
                            });
                        }
                    }
                }
                if (tagsList.Count > 0)
                {
                    try
                    {
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, pumpMetaData[0].ControllerId);

                        foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (tag.Address == plcTag.Address)
                                {
                                    if (tag.TagItemType == UIInputType.TypeInt)
                                    {
                                        if (Convert.ToInt32(tag.Value.Trim()) != Convert.ToInt32(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else if (tag.TagItemType == UIInputType.TypeFloat)
                                    {
                                        if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else if (tag.TagItemType == UIInputType.TypeBool)
                                    {
                                        if (Convert.ToBoolean(tag.Value.Trim()) != Convert.ToBoolean(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else
                                    {
                                        if (tag.Value.Trim() != plcTag.Value.Trim())
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }

                                }

                            }
                        }
                        foreach (PumpsModel metaData in pumpMetaData)
                        {
                            if (!string.IsNullOrEmpty(metaData.LfsChemicalNameTag) && tagCollectionList.Contains(metaData.LfsChemicalNameTag))
                            {
                                metaData.LfsOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.KfactorTag) && tagCollectionList.Contains(metaData.KfactorTag))
                            {
                                metaData.KFactorOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.CalibrationTag) && tagCollectionList.Contains(metaData.CalibrationTag))
                            {
                                metaData.CalibrationOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowDetectorType.ToString()) &&
                                    tagCollectionList.Contains("stMachineConfig.xFlowSwitchType[" + metaData.ControllerEquipmentId + "]"))
                            {
                                metaData.FlowDetectorTypeOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowSwitchAlarm.ToString()) &&
                                    tagCollectionList.Contains("stMachineConfig.xFlowAlarmOverride[" + metaData.ControllerEquipmentId + "]"))
                            {
                                metaData.FlowSwitchAlarmOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowMeterAlarm.ToString()) &&
                                    tagCollectionList.Contains("stMachineConfig.xFlowMeterAlarmOverride[" + metaData.ControllerEquipmentId + "]"))
                            {
                                metaData.FlowMeterAlarmOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowMeterType.ToString()) &&
                                    tagCollectionList.Contains("stPumpConfig[" + metaData.ControllerEquipmentId + "].eFlowMeterMode"))
                            {
                                metaData.FlowMeterTypeOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowAlarmDelay.ToString()) &&
                                    tagCollectionList.Contains("stPumpConfig[" + metaData.ControllerEquipmentId + "].fLossOfFlowDuration"))
                            {
                                metaData.FlowAlarmDelayOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowMeterPumpDelay.ToString()) &&
                                    tagCollectionList.Contains("stPumpConfig[" + metaData.ControllerEquipmentId + "].fTdFlowMeter"))
                            {
                                metaData.FlowMeterPumpDelayOverridePlcValues = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.FlowMeterAlarmDelay.ToString()) &&
                                    tagCollectionList.Contains("stPumpConfig[" + metaData.ControllerEquipmentId + "].fTAlarmDelayFlowMeter"))
                            {
                                metaData.FlowMeterAlarmDelayOverridePlcValues = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                }

                return pumpMetaData;
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return pumpMetaData;
            }
        }

        /// <summary>
        /// Updating Pump Details
        /// </summary>
        /// <param name="pumpDataList">The pump data list.</param>
        /// <returns>
        /// Return Responcse of Success
        /// </returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage UpdatePump(List<PumpsModel> pumpDataList)
        {
            List<PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<PLCDiscrepancyModel>();
            try
            {
                Ecolab.Models.ControllerSetup.Pumps.PumpsModel prevPumpsModel = null;
                if (pumpDataList.Count() == 1)
                {
                    prevPumpsModel = this.pumpServices.GetPumps(pumpDataList.FirstOrDefault().EcolabAccountNumber, pumpDataList.FirstOrDefault().ControllerId, string.Empty).Where(x => x.ControllerEquipmentSetupId == pumpDataList.FirstOrDefault().ControllerEquipmentSetupId).FirstOrDefault();
                    prevPumpsModel.LineCompartmentMappings = GetLineData(prevPumpsModel.LineNumber, prevPumpsModel.ControllerId, prevPumpsModel.ControllerEquipmentSetupId);
                }

                Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = null;
                foreach (PumpsModel pumpData in pumpDataList)
                {
                    DateTime lastModifiedTime;
                    objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
                    int response = this.pumpServices.UpdatePump(objPumpData, this.UserId, out lastModifiedTime, null);
                    objPumpData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTime, DateTimeKind.Utc);
                    objPumpData.ControllerEquipmentSetupId = response;
                    pumpData.LastModifiedTimeStamp = objPumpData.LastModifiedTimeStamp;
                    pumpData.ControllerEquipmentSetupId = objPumpData.ControllerEquipmentSetupId;
                    if (response > 0 && objPumpData.ControllerId > 0)
                    {
                        List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel> objPumpList = pumpServices.GetPumpsForResync(objPumpData.EcolabAccountNumber, objPumpData.ControllerId, objPumpData.ControllerEquipmentSetupId);
                        Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPump = objPumpList.Where(p => p.ControllerEquipmentSetupId == pumpData.ControllerEquipmentSetupId).FirstOrDefault();
                        Push.PushToQueue(objPump, this.UserId, objPumpData.ControllerId, (int)TcdAdminMessageTypes.TcdUpdatePump, objPumpData.EcolabAccountNumber);
                        pumpData.ModuleTags = objPumpData.ModuleTags;
                    }
                    if (!string.IsNullOrEmpty(pumpData.ProductName))
                        pumpData.ProductName = Regex.Replace(pumpData.ProductName.ToString().Trim(), @"\s+", " ");
                    objPLCDiscrepancyModels.Add(new PLCDiscrepancyModel
                    {
                        ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                        ParentEntityId = objPumpData.ControllerId,
                        Entity = Convert.ToInt32(PlcDiscrepancyEntity.Devices),
                        EntityId = objPumpData.ControllerEquipmentSetupId,
                        IsCentral = false,
                        ControllerId = objPumpData.ControllerId,
                        UserId = this.UserId,
                        LastModifiedUserId = this.UserId
                    });
                }

                if (objPumpData.ControllerModelId == 7 || objPumpData.ControllerModelId == 11)
                {
                    return WriteEUTagsToPLC(pumpDataList, prevPumpsModel);
                }
                else if (objPumpData.ControllerModelId == 8)
                {
                    return WriteTagsToPLCForEcontrolPlus(pumpDataList, prevPumpsModel);
                }
                else
                {
                    pumpDataList = ValidateTags(pumpDataList);
                    if (pumpDataList != null && pumpDataList.Count > 0 && pumpDataList[0].IsInlineEdit == true)
                    {
                        return WriteTagsToPLC(pumpDataList);
                    }
                    else if (pumpDataList != null && pumpDataList.Count > 0)
                    {
                        return this.Request.CreateResponse((HttpStatusCode)Enum.Parse(typeof(HttpStatusCode), pumpDataList[0].HttpStatusCode.ToString(), true), pumpDataList[0].EorrorList != null ? (Object)pumpDataList[0].EorrorList : (Object)pumpDataList[0].Eorror);

                    }
                }
            }
            catch (SqlException sqlex)
            {
                ErrorLog.GetDefault(null).Log(new Error(sqlex) { Message = sqlex.Message });
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                if (ex.GetType() == typeof(COMException) ||
                    ex.Message.Contains("Timeout has elapsed") ||
                                   ex.Message.Contains("Port is disabled") ||
                    ex.Message.Contains("Target machine could not be found") ||
                    ex.Message.Contains("ADS could not be initialized") ||
                    ex.Message.Contains("Open Failed") ||
                    ex.Message.Contains("Retrieving the COM class factory") ||
                    ex.Message.Contains("901"))
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "901");
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "902");
                }
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, new { plcDiscrepancyModel = objPLCDiscrepancyModels });
        }
        /// <summary>
        /// Validate Tags method
        /// </summary>
        /// <param name="pumpDataList">Pumps data list</param>
        /// <returns>Returns tags list</returns>
        private List<PumpsModel> ValidateTags(List<PumpsModel> pumpDataList)
        {
            try
            {
                Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = null;
                foreach (PumpsModel pumpData in pumpDataList)
                {
                    objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
                    var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                    var tagsList = new List<OpcTag>();
                    TagCollection tagStatus = new TagCollection();
                    if (pumpData.ControllerModelId == 3)
                    {
                        tagsList = BuildTagForTunnel(pumpData);
                    }
                    if (!string.IsNullOrEmpty(pumpData.LfsChemicalNameTag))
                    {
                        tagsList.Add(new OpcTag
                        {
                            Address = pumpData.LfsChemicalNameTag,
                            Value = pumpData.LfsChemicalName,
                            TagType = "Tag_NML",
                            TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeString
                        });
                    }
                    List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, pumpDataList.FirstOrDefault().ControllerId, this.EcolabAccountNumber, 1);
                    var factors = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.Where(_ => _.FieldLabel == "Factors Multiplier").FirstOrDefault()).FirstOrDefault();
                    var factorsMulti = factors != null ? (int)Convert.ToDecimal(factors.FieldDefaultValue.ToString()) : 0;

                    var ounceSec = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.Where(_ => _.FieldLabel == "OZ/Second Multiplier").FirstOrDefault()).FirstOrDefault();
                    var ounceSecMulti = ounceSec != null ? (int)Convert.ToDecimal(ounceSec.FieldDefaultValue.ToString()) : 0;

                    if (!string.IsNullOrEmpty(pumpData.KfactorTag))
                    {
                        tagsList.Add(new OpcTag
                        {
                            Address = pumpData.KfactorTag,
                            Value = Convert.ToInt32(Convert.ToDecimal(pumpData.KFactor) * factorsMulti).ToString()
                        });
                    }

                    if (!string.IsNullOrEmpty(pumpData.CalibrationTag))
                    {
                        tagsList.Add(new OpcTag
                        {
                            Address = pumpData.CalibrationTag,
                            Value = Convert.ToInt32(Convert.ToDecimal(pumpData.PumpCalibration) * ounceSecMulti).ToString()
                        });
                    }
                    List<OpcTag> tags = null;
                    if (tagsList.Any())
                    {
                        tags = tagsList.Clone();
                        string error = string.Empty;
                        this.pumpServices.UpdatePumpTags(objPumpData, this.UserId, out error);
                        if (!string.IsNullOrEmpty(error))
                        {
                            pumpData.HttpStatusCode = (int)HttpStatusCode.BadRequest;
                            pumpData.Eorror = error;
                            continue;
                        }
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, pumpData.ControllerId);
                        string errorCode = string.Empty;
                        foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                        {
                            if (status.Address == pumpData.LfsChemicalNameTag)
                            {
                                errorCode += "804,";
                            }
                            if (status.Address == pumpData.KfactorTag)
                            {
                                errorCode += "805,";
                            }
                            if (status.Address == pumpData.CalibrationTag)
                            {
                                errorCode += "806,";
                            }
                            if (pumpData.ControllerModelId == 3)
                            {
                                //FlowDetectorType
                                if (status.Address == "stMachineConfig.xFlowSwitchType[" + pumpData.ControllerEquipmentId + "]")
                                {
                                    errorCode += "807,";
                                }
                                //Flow Switch Alarm
                                if (status.Address == "stMachineConfig.xFlowAlarmOverride[" + pumpData.ControllerEquipmentId + "]")
                                {
                                    errorCode += "808,";
                                }

                                //Flow Meter Alarm
                                if (status.Address == "stMachineConfig.xFlowMeterAlarmOverride[" + pumpData.ControllerEquipmentId + "]")
                                {
                                    errorCode += "809,";
                                }

                                //Flow Meter Type
                                if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].eFlowMeterMode")
                                {
                                    errorCode += "8010,";
                                }

                                //Flow Alarm Delay Time
                                if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fLossOfFlowDuration")
                                {
                                    errorCode += "8011,";
                                }

                                //Flow Meter Pump Delay
                                if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTdFlowMeter")
                                {
                                    errorCode += "8012,";
                                }

                                //Flow Meter Alarm Delay
                                if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTAlarmDelayFlowMeter")
                                {
                                    errorCode += "8013,";
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(errorCode))
                        {
                            pumpData.HttpStatusCode = (int)HttpStatusCode.BadRequest;
                            pumpData.Eorror = errorCode;
                            continue;
                        }
                    }

                    var message = new StringBuilder();
                    var ambiguousTags = new List<OpcTag>();
                    string tagValue = string.Empty;
                    string plcTagValue = string.Empty;
                    string tagAddress = string.Empty;
                    if (tags != null)
                    {
                        foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (plcTag.TagItemType == UIInputType.TypeBool)
                                {
                                    plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                                }
                                if (tag.Address == plcTag.Address)
                                {
                                    if (tag.Address.Contains(".fLossOfFlowDuration")
                                        || tag.Address.Contains(".fTdFlowMeter")
                                        || tag.Address.Contains(".fTAlarmDelayFlowMeter"))
                                    {
                                        if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                        {
                                            message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                            ambiguousTags.Add(tag);
                                        }
                                    }
                                    else
                                    {
                                        if (tag.Value.Trim().ToLower() != plcTag.Value.Trim().ToLower())
                                        {
                                            if (tag.Address.Contains(".xFlowSwitchType"))
                                            {
                                                tagValue = tag.Value.ToLower() == "false" ? "Switch" : "Paddle";
                                                plcTagValue = plcTag.Value.ToLower() == "false" ? "Switch" : "Paddle";
                                            }
                                            else if (tag.Address.Contains(".eFlowMeterMode"))
                                            {
                                                if (tag.Value == "0")
                                                { tagValue = "Disabled"; }
                                                else { tagValue = tag.Value == "1" ? "Digital" : "High Speed"; }
                                                if (plcTag.Value == "0")
                                                { plcTagValue = "Disabled"; }
                                                else { plcTagValue = plcTag.Value == "1" ? "Digital" : "High Speed"; }
                                            }
                                            else
                                            {
                                                tagValue = tag.Value;
                                                plcTagValue = plcTag.Value;
                                            }
                                            message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tagValue, plcTagValue));
                                            ambiguousTags.Add(tag);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(message.ToString()))
                    {
                        message.Append("Do you want to override the value in plc ?");

                        var error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
                        pumpData.PlcTags = ambiguousTags;
                        pumpData.OverridePlcValues = true;
                        pumpData.HttpStatusCode = (int)HttpStatusCode.Ambiguous;
                        pumpData.EorrorList = error;
                        continue;
                    }
                    pumpData.HttpStatusCode = (int)HttpStatusCode.OK;
                    pumpData.Eorror = message.ToString();
                    continue;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                throw ex;
            }
            return pumpDataList;
        }
        /// <summary>
        /// Build Tag for Tunnel method
        /// </summary>
        /// <param name="pumpData">The pump model data.</param>
        /// <returns>List of Tags for tunnel.</returns>
        private List<OpcTag> BuildTagForTunnel(PumpsModel pumpData)
        {
            var tagsList = new List<OpcTag>();
            //FlowDetectorType
            tagsList.Add(new OpcTag
            {
                Address = "stMachineConfig.xFlowSwitchType[" + pumpData.ControllerEquipmentId + "]",
                Value = (pumpData.FlowDetectorType == 1) ? "True" : "False",
                TagItemType = UIInputType.TypeBool,
            });
            pumpData.FlowDetectorTypeTag = "stMachineConfig.xFlowSwitchType[" + pumpData.ControllerEquipmentId + "]";

            //Flow Switch Alarm
            tagsList.Add(new OpcTag
            {
                Address = "stMachineConfig.xFlowAlarmOverride[" + pumpData.ControllerEquipmentId + "]",
                Value = pumpData.FlowSwitchAlarm.ToString(),
                TagItemType = UIInputType.TypeBool,
            });
            pumpData.FlowSwitchAlarmTag = "stMachineConfig.xFlowAlarmOverride[" + pumpData.ControllerEquipmentId + "]";

            //Flow Meter Alarm
            tagsList.Add(new OpcTag
            {
                Address = "stMachineConfig.xFlowMeterAlarmOverride[" + pumpData.ControllerEquipmentId + "]",
                Value = pumpData.FlowMeterAlarm.ToString(),
                TagItemType = UIInputType.TypeBool,
            });
            pumpData.FlowMeterAlarmTag = "stMachineConfig.xFlowMeterAlarmOverride[" + pumpData.ControllerEquipmentId + "]";

            //Flow Meter Type
            tagsList.Add(new OpcTag
            {
                Address = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].eFlowMeterMode",
                Value = pumpData.FlowMeterType.ToString(),
                TagItemType = UIInputType.TypeInt,
            });
            pumpData.FlowMeterTypeTag = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].eFlowMeterMode";

            //Flow Alarm Delay Time
            tagsList.Add(new OpcTag
            {
                Address = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fLossOfFlowDuration",
                Value = pumpData.FlowAlarmDelay.ToString(),
                TagItemType = UIInputType.TypeFloat,
            });
            pumpData.FlowAlarmDelayTag = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fLossOfFlowDuration";

            //Flow Meter Pump Delay
            tagsList.Add(new OpcTag
            {
                Address = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTdFlowMeter",
                Value = pumpData.FlowMeterPumpDelay.ToString(),
                TagItemType = UIInputType.TypeFloat
            });
            pumpData.FlowMeterPumpDelayTag = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTdFlowMeter";

            //Flow Meter Alarm Delay
            tagsList.Add(new OpcTag
            {
                Address = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTAlarmDelayFlowMeter",
                Value = pumpData.FlowMeterAlarmDelay.ToString(),
                TagItemType = UIInputType.TypeFloat
            });
            pumpData.FlowMeterAlarmDelayTag = "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTAlarmDelayFlowMeter";

            return tagsList;
        }

        /// <summary>
        /// Writing tags to plc
        /// </summary>
        /// <param name="pumpDataList">The pump data list.</param>
        /// <returns>
        /// Return Response Success Message.
        /// </returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage WriteTagsToPLC(List<PumpsModel> pumpDataList)
        {
            List<PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<PLCDiscrepancyModel>();
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                foreach (PumpsModel pumpData in pumpDataList)
                {
                    Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);

                    if (objPumpData.ControllerId > 0)
                    {
                        objPumpData.ModuleTags = this.pumpServices.GetModuleTagsDetails(objPumpData.ControllerEquipmentSetupId, 4, this.EcolabAccountNumber);
                        Push.PushToQueue(objPumpData, this.UserId, objPumpData.ControllerId, (int)TcdAdminMessageTypes.TcdUpdatePump, objPumpData.EcolabAccountNumber);
                    }

                    if (this.RoleId >= 6 && pumpData.ControllerModelId != 7 && pumpData.ControllerModelId != 11)
                    {
                        if (pumpData.OverridePlcValues)
                        {
                            List<Ecolab.Models.TagTypes> tagTypeData = this.pumpServices.GetTagTypes();
                            List<Ecolab.ConduitLocal.Web.Models.TagTypeModel> tagTypeList = Mapper.Map<List<Ecolab.Models.TagTypes>, List<Ecolab.ConduitLocal.Web.Models.TagTypeModel>>(tagTypeData);

                            var tag = pumpData.PlcTags.Where(_ => _.Address == pumpData.LfsChemicalNameTag).FirstOrDefault();
                            if (tag != null)
                            {
                                var dataType = tagTypeList.Where(_ => _.TagType == tag.TagType).Select(_ => _.DataType).FirstOrDefault();

                                if (dataType != null)
                                {
                                    pumpData.PlcTags.Where(_ => _.Address == pumpData.LfsChemicalNameTag).FirstOrDefault().TagItemType = UIInputType.TypeString;
                                }
                            }

                            pumpData.PlcTags.Where(_ => _.Address == pumpData.LfsChemicalNameTag).Each(x => x.SizetoRead = x.Value.Length);
                            plc.WriteTags(new TagCollection { Tags = new List<Tag>(pumpData.PlcTags) }, pumpData.ControllerId);
                            objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                            {
                                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                                ParentEntityId = pumpData.ControllerId,
                                Entity = Convert.ToInt32(PlcDiscrepancyEntity.Devices),
                                EntityId = pumpData.ControllerEquipmentSetupId,
                                IsCentral = false,
                                ControllerId = pumpData.ControllerId,
                                UserId = this.UserId,
                                LastModifiedUserId = this.UserId
                            });
                        }
                    }
                }
            }
            catch (SqlException sqlex)
            {
                ErrorLog.GetDefault(null).Log(new Error(sqlex) { Message = sqlex.Message });
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, new { plcDiscrepancyModel = objPLCDiscrepancyModels });

        }
        /// <summary>
        /// EU tags to PLC
        /// </summary>
        /// <param name="pumpDataList">The pump data list.</param>
        /// <param name="prevPumpsModel">The pumps previous model.</param>
        /// <returns>Http Response Message.</returns>
        private HttpResponseMessage WriteEUTagsToPLC(List<PumpsModel> pumpDataList, Ecolab.Models.ControllerSetup.Pumps.PumpsModel prevPumpsModel = null)
        {
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                foreach (PumpsModel pumpData in pumpDataList)
                {
                    Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);

                    if (objPumpData.ControllerId > 0)
                    {
                        objPumpData.ModuleTags = this.pumpServices.GetModuleTagsDetails(objPumpData.ControllerEquipmentSetupId, 4, this.EcolabAccountNumber);
                        Push.PushToQueue(objPumpData, this.UserId, objPumpData.ControllerId, (int)TcdAdminMessageTypes.TcdUpdatePump, objPumpData.EcolabAccountNumber);
                    }

                    if (pumpData.ControllerModelId == 7)
                    {
                        List<BeckhoffTag> beckhoffTags = BuildPumpsTags(pumpData, prevPumpsModel);
                        foreach (var tag in beckhoffTags)
                        {
                            if (tag.Address.Contains(".str_ProductName"))
                            {
                                int length = tag.Value.Length;

                                if (length > 30)
                                {
                                    tag.Value = tag.Value.Substring(0, 30);
                                }
                                tag.Value = Regex.Replace(tag.Value, "[^0-9A-Za-z ,._%-/(){}&]", string.Empty);
                            }
                        }
                        beckhoffTags.Each(x => x.IsValid = true);
                        beckhoffTags.Where(t => t.TagItemType != UIInputType.TypeObject).Each(x => x.SizetoRead = x.Value.Length);
                        plc.WriteMyControlTags(beckhoffTags, pumpData.ControllerId, SourcePage.PumpsPage);
                    }
                    else if (pumpData.ControllerModelId == 11)
                    {
                        bool isReset = false;
                        if (pumpData.ProductId == null || pumpData.ProductId == 0)
                        {
                            isReset = true;
                        }
                        List<MitsubishiTag> mitsubishiTag = BuildPumpsTagsPLCXL(pumpData, isReset, prevPumpsModel);
                        mitsubishiTag.Each(x => x.IsValid = true);
                        plc.WritePLCXLTags(mitsubishiTag, pumpData.ControllerId, SourcePage.PumpsPage);
                        ValidateAndWriteConventionalWasherGroupConnectionFields(pumpData, plc);
                    }
                }
            }
            catch (SqlException sqlex)
            {
                ErrorLog.GetDefault(null).Log(new Error(sqlex) { Message = sqlex.Message });
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);

        }

        /// <summary>
        /// Validate the PLC tag details
        /// </summary>
        /// <param name="pumpData">Storage Tanks Data</param>
        /// <returns>
        /// Success or failure message
        /// </returns>
        [HttpPost]
        public HttpResponseMessage ValidateTags(PumpsModel pumpData)
        {
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                if (pumpData.ControllerModelId == 3)
                {
                    tagsList = BuildTagForTunnel(pumpData);
                }
                TagCollection tagStatus = new TagCollection();
                if (!string.IsNullOrEmpty(pumpData.LfsChemicalNameTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = pumpData.LfsChemicalNameTag,
                        Value = pumpData.LfsChemicalName,
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeString,
                        SizetoRead = pumpData.LfsChemicalName.Length,
                    });
                }

                if (!string.IsNullOrEmpty(pumpData.KfactorTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = pumpData.KfactorTag,
                        Value = pumpData.KFactor.ToString()
                    });
                }

                if (!string.IsNullOrEmpty(pumpData.CalibrationTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = pumpData.CalibrationTag,
                        Value = pumpData.PumpCalibration.ToString()
                    });
                }
                List<OpcTag> tags = null;
                if (tagsList.Any())
                {
                    tags = tagsList.Clone();
                    tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, pumpData.ControllerId);
                    string errorCode = string.Empty;
                    foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                    {
                        if (status.Address == pumpData.LfsChemicalNameTag)
                        {
                            errorCode += "804,";
                        }
                        if (status.Address == pumpData.KfactorTag)
                        {
                            errorCode += "805,";
                        }
                        if (status.Address == pumpData.CalibrationTag)
                        {
                            errorCode += "806,";
                        }
                        if (pumpData.ControllerModelId == 3)
                        {
                            //FlowDetectorType
                            if (status.Address == "stMachineConfig[" + pumpData.ControllerEquipmentId + "].xFlowSwitchType[" + pumpData.ControllerEquipmentId + "]")
                            {
                                errorCode += "807,";
                            }
                            //Flow Switch Alarm
                            if (status.Address == "stMachineConfig[" + pumpData.ControllerEquipmentId + "].xFlowAlarmOverride[" + pumpData.ControllerEquipmentId + "]")
                            {
                                errorCode += "808,";
                            }

                            //Flow Meter Alarm
                            if (status.Address == "stMachineConfig[" + pumpData.ControllerEquipmentId + "].xFlowMeterAlarmOverride[" + pumpData.ControllerEquipmentId + "]")
                            {
                                errorCode += "809,";
                            }

                            //Flow Meter Type
                            if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].eFlowMeterMode")
                            {
                                errorCode += "8010,";
                            }

                            //Flow Alarm Delay Time
                            if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fLossOfFlowDuration")
                            {
                                errorCode += "8011,";
                            }

                            //Flow Meter Pump Delay
                            if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTdFlowMeter")
                            {
                                errorCode += "8012,";
                            }

                            //Flow Meter Alarm Delay
                            if (status.Address == "stPumpConfig[" + pumpData.ControllerEquipmentId + "].fTAlarmDelayFlowMeter")
                            {
                                errorCode += "8013,";
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(errorCode))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                    }
                }

                var message = new StringBuilder();
                var ambiguousTags = new List<OpcTag>();
                if (tags != null)
                {
                    foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                            {
                                message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                ambiguousTags.Add(tag);
                            }
                        }
                    }
                }
                if (!string.IsNullOrWhiteSpace(message.ToString()))
                {
                    message.Append("Do you want to override the value in plc ?");

                    var error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
                    return this.Request.CreateResponse(HttpStatusCode.Ambiguous, error);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, message.ToString());
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        /// <summary>
        /// To Get the Pump Models Model List
        /// </summary>
        /// <returns>
        /// PumpModelsModel List
        /// </returns>
        [HttpGet]
        public List<PumpModelsModel> GetPumpModels()
        {
            try
            {
                return this.pumpServices.GetPumpModels().ToList();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return new List<PumpModelsModel>();
            }
        }

        /// <summary>
        ///     To Get the Pump Models Model List
        /// </summary>
        /// <returns>PumpModelsModel List</returns>
        /// <param name="lineNo">The line Number</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="equipmentId">The Equipment Id</param>
        [HttpGet]
        public List<LineCompartmentMappingModel> GetLineData(int lineNo, int controllerId, int equipmentId = 0)
        {
            try
            {
                return this.pumpServices.GetLineData(lineNo, controllerId, equipmentId, this.EcolabAccountNumber).ToList();
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return new List<LineCompartmentMappingModel>();
            }
        }

        /// <summary>
        /// To Get the Pump Models Model List
        /// </summary>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>
        /// PumpModelsModel List
        /// </returns>
        [HttpGet]
        public List<ControllerDataModel> GetControllerData(int controllerId)
        {
            try
            {
                List<ControllerDataModel> lst = this.pumpServices.GetControllerData(controllerId, EcolabAccountNumber).ToList();
                return lst;
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return new List<ControllerDataModel>();
            }
        }

        /// <summary>
        /// Gets the compartment valve data.
        /// </summary>
        /// <param name="controllerEquipSetupId">The controller equip setup identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="controllerEquipmentTypeId">The controller equipment type identifier.</param>
        /// <returns>
        /// Return Line Compartment Mapping Model
        /// </returns>
        public List<Web.Models.ControllerSetup.Pumps.LineCompartmentMappingModel> GetCompartmentValveData(int controllerEquipSetupId, int washerGroupNumber, int controllerEquipmentTypeId)
        {
            List<LineCompartmentMappingModel> tunnelCmptValvelist = this.pumpServices.GetCompartmentValveData(controllerEquipSetupId, washerGroupNumber, controllerEquipmentTypeId, this.EcolabAccountNumber).ToList();
            return Mapper.Map<List<LineCompartmentMappingModel>, List<Web.Models.ControllerSetup.Pumps.LineCompartmentMappingModel>>(tunnelCmptValvelist);
        }

        /// <summary>
        /// Gets the pumps products.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>Return Product Model Data.</returns>
        public List<Web.Models.ControllerSetup.Pumps.ProductModel> GetPumpsProducts(int controllerId, string ecolabAccountNumber)
        {
            List<ProductModel> pumpsProductList = this.pumpServices.GetPumpsProductData(controllerId, ecolabAccountNumber);
            return Mapper.Map<List<ProductModel>, List<Web.Models.ControllerSetup.Pumps.ProductModel>>(pumpsProductList);
        }

        /// <summary>
        /// Saves the pumps products.
        /// </summary>
        /// <param name="pumpProductdata">The pump productdata.</param>
        /// <returns>Success or failure message</returns>
        [HttpPost]
        public HttpResponseMessage SavePumpsProducts(List<Web.Models.ControllerSetup.Pumps.ProductModel> pumpProductdata)
        {
            DateTime lastModifiedTime;
            try
            {
                List<Ecolab.Models.ControllerSetup.Pumps.ProductModel> objPumpProductData = Mapper.Map<List
                <Web.Models.ControllerSetup.Pumps.ProductModel>, List<Ecolab.Models.ControllerSetup.Pumps.ProductModel>>(pumpProductdata);

                this.pumpServices.SavePumpsProducts(objPumpProductData, pumpProductdata[0].ControllerId, EcolabAccountNumber, out lastModifiedTime);
                return this.Request.CreateResponse(HttpStatusCode.OK, pumpProductdata);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        /// <summary>
        /// Gets the mixing vessels data.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>Mixing Vessels Model Data</returns>
        public List<Web.Models.ControllerSetup.Pumps.MixingVesselsModel> GetMixingVesselsData(int controllerId, string ecolabAccountNumber)
        {
            List<MixingVesselsModel> mixingVesselsList = this.pumpServices.GetMixingVesselsData(controllerId, ecolabAccountNumber);
            return Mapper.Map<List<MixingVesselsModel>, List<Web.Models.ControllerSetup.Pumps.MixingVesselsModel>>(mixingVesselsList);
        }

        /// <summary>
        /// Saves the mixing vessels.
        /// </summary>
        /// <param name="mixingVesselsData">The mixing vessels data.</param>
        /// <returns>Success or failure message</returns>
        [HttpPost]
        public HttpResponseMessage SaveMixingVessels(List<Web.Models.ControllerSetup.Pumps.MixingVesselsModel> mixingVesselsData)
        {
            DateTime lastModifiedTime;
            try
            {
                List<Ecolab.Models.ControllerSetup.Pumps.MixingVesselsModel> objMixingVesselsData = Mapper.Map<List
                <Web.Models.ControllerSetup.Pumps.MixingVesselsModel>, List<Ecolab.Models.ControllerSetup.Pumps.MixingVesselsModel>>(mixingVesselsData);

                this.pumpServices.SaveMixingVessels(objMixingVesselsData, mixingVesselsData[0].ControllerId, EcolabAccountNumber, out lastModifiedTime);

                return this.Request.CreateResponse(HttpStatusCode.OK, mixingVesselsData);
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }

        /// <summary>
        /// Gets the auxiliary pump data.
        /// </summary>
        /// <param name="lineNumber">The line number.</param>
        /// <param name="controllerid">The controllerid.</param>
        /// <returns>Setup Dosing LineModel</returns>
        public List<SetupDosingLineModel> GetAuxiliaryPumpData(int lineNumber, int controllerid)
        {
            List<SetupDosingLine> dosingLinelsList = this.pumpServices.GetAuxiliaryPumpData(lineNumber, controllerid, EcolabAccountNumber);
            return Mapper.Map<List<SetupDosingLine>, List<SetupDosingLineModel>>(dosingLinelsList);
        }

        /// <summary>
        /// Writes the tags to PLC for econtrol plus.
        /// </summary>
        /// <param name="pumpMetaData">The pump meta data.</param>
        /// <param name="prevPumpsModel">The previous pumps model.</param>
        /// <returns>Success or failure message</returns>
        public HttpResponseMessage WriteTagsToPLCForEcontrolPlus(List<PumpsModel> pumpMetaData, Ecolab.Models.ControllerSetup.Pumps.PumpsModel prevPumpsModel = null)
        {
            int controllerId = pumpMetaData[0].ControllerId;
            int controllerTypeID = pumpMetaData[0].ControllerTypeId;
            List<PumpsModel> pumpList = pumpMetaData.OrderBy(t => t.ControllerEquipmentId).ToList();

            PlcTagController plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            List<MitsubishiTag> tagList = plc.ReadEControlPlusDeviceTags(controllerId, controllerTypeID);

            int[] cbwParameters = tagList[0].IntArrayData;
            int[] washerParameters = tagList[1].IntArrayData;

            //FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
            int[] pumpParameters = tagList[2].IntArrayData;

            //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            int[] flowValues = tagList[3].IntArrayData;

            //FlowMeterPulsesPerLiter,MaxTimeFlowMeter
            int[] flowIntValues = tagList[4].IntArrayData;
            int totalWasherCount = 6;
            // 7: 1 Tunnel 6 Washers; 6: 8 Washers
            if (controllerTypeID == 7)
            {
                totalWasherCount = 6;
            }
            else if (controllerTypeID == 6)
            {
                totalWasherCount = 8;
            }

            foreach (PumpsModel pump in pumpList)
            {
                //Check the conventional Washer Group connection 
                CheckConventionalWasherGroupConnectionForEControlPlus(pump, totalWasherCount, washerParameters);
                //Compare the Line numbers
                CheckLineNumberForEControlPlus(pump, pumpParameters);
                WriteLineCompartmentNumbersForEControlPlus(pump, cbwParameters);
                CheckCalibarationForEControlPlus(pump, pumpParameters);
                CheckFlowDectorTypeForEcontrolPlus(pump, flowValues);
                CheckFlowMeterCalibration(pump, flowIntValues);
                CheckMaximumDosingTimeForEcontrolPlus(pump, flowIntValues);
                CheckFlowSwitchTimeOutForEcontrolPlus(pump, pumpParameters);
                CheckFlowMeterActivatedForEControlPlus(pump, flowValues);
                CheckFlushWhileDosingForEcontrolPlus(pump, pumpParameters);
                CheckWeightControlledDosageForEControlPlus(pump, flowValues);
                CheckEquipmentDoseAloneForEControlPlus(pump, flowValues);
                CheckLowLevelAlarmEControlPlus(pump, flowValues);
                CheckMETypeForEcontrolPlus(pump, pumpParameters);
                CheckMEPumpingTimeForEcontrolPlus(pump, pumpParameters);
                CheckMEFlushTimeForEControlPlus(pump, pumpParameters);
                CheckMEPreFlushTimeForEControlPlus(pump, pumpParameters);
                CheckMENightFlushTimeEControlPlus(pump, pumpParameters);
                CheckMENightFlushPauseTimeEControlPlus(pump, pumpParameters);
                CheckValveOutputAsTOMEControlPlus(pump, pumpParameters);
            }

            plc.WriteEControlPlusDeviceTags(controllerId, controllerTypeID, tagList);

            return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }

        /// <summary>
        /// Builds the pumps model for e control plus.
        /// </summary>
        /// <param name="pumpMetaData">The pump meta data.</param>
        /// <param name="plc">The PLC data for EControl Plus.</param>
        /// <returns>Return the Pumps Model Data.</returns>
        private List<PumpsModel> BuildPumpsModelForEControlPlus(List<PumpsModel> pumpMetaData, PlcTagController plc)
        {
            List<PumpsModel> pumpList = pumpMetaData.OrderBy(t => t.ControllerEquipmentId).ToList();
            try
            {
                int controllerId = pumpMetaData[0].ControllerId;
                int controllerTypeID = pumpMetaData[0].ControllerTypeId;
                List<MitsubishiTag> tagList = plc.ReadEControlPlusDeviceTags(controllerId, controllerTypeID);

                int[] cbwParameters = tagList[0].IntArrayData;
                int[] washerParameters = tagList[1].IntArrayData;

                //FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
                int[] pumpParameters = tagList[2].IntArrayData;

                //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
                int[] flowValues = tagList[3].IntArrayData;

                //FlowMeterPulsesPerLiter,MaxTimeFlowMeter
                int[] flowIntValues = tagList[4].IntArrayData;

                int totalWasherCount = 6;
                // 7: 1 Tunnel 6 Washers; 6: 8 Washers
                if (controllerTypeID == 7)
                {
                    totalWasherCount = 6;
                }
                else if (controllerTypeID == 6)
                {
                    totalWasherCount = 8;
                }

                foreach (PumpsModel pump in pumpList)
                {
                    //Check the conventional Washer Group connection 
                    CheckConventionalWasherGroupConnectionForEControlPlus(pump, totalWasherCount, washerParameters);
                    //Compare the Line numbers
                    CheckLineNumberForEControlPlus(pump, pumpParameters);
                    CheckLineCompartmentNumbersForEControlPlus(pump, cbwParameters);
                    CheckCalibarationForEControlPlus(pump, pumpParameters);
                    CheckFlowDectorTypeForEcontrolPlus(pump, flowValues);
                    CheckFlowMeterCalibration(pump, flowIntValues);
                    CheckMaximumDosingTimeForEcontrolPlus(pump, flowIntValues);
                    CheckFlowSwitchTimeOutForEcontrolPlus(pump, pumpParameters);
                    CheckFlowMeterActivatedForEControlPlus(pump, flowValues);
                    CheckFlushWhileDosingForEcontrolPlus(pump, pumpParameters);
                    CheckWeightControlledDosageForEControlPlus(pump, flowValues);
                    CheckEquipmentDoseAloneForEControlPlus(pump, flowValues);
                    CheckLowLevelAlarmEControlPlus(pump, flowValues);
                    CheckMETypeForEcontrolPlus(pump, pumpParameters);
                    CheckMEPumpingTimeForEcontrolPlus(pump, pumpParameters);
                    CheckMEFlushTimeForEControlPlus(pump, pumpParameters);
                    CheckMEPreFlushTimeForEControlPlus(pump, pumpParameters);
                    CheckMENightFlushTimeEControlPlus(pump, pumpParameters);
                    CheckMENightFlushPauseTimeEControlPlus(pump, pumpParameters);
                    CheckValveOutputAsTOMEControlPlus(pump, pumpParameters);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return pumpMetaData;
            }

            return pumpMetaData;
        }

        /// <summary>
        /// Checks the valve output as tome control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckValveOutputAsTOMEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.ValveOutputAsTomOverridePLCValues = false;
            int vlaveOutput = pump.ValveOutputAsTom ? 1 : 0;
            if (pump.ControllerEquipmentId < 9) return;// return if it is a pump
            ///ME_Parameters[ME Nb,6]
            //FlushWhileDosingME(2),....8 address locations,Pump_Parameters,ME_Parameters
            int index;
            if (pump.ControllerEquipmentId == 9)//ME1
            {
                index = 42 + 4;
            }
            else
            {
                index = 42 + 9 + 4;
            }

            if (vlaveOutput != pumpParameters[index])
            {
                pump.ValveOutputAsTomOverridePLCValues = true;
                pumpParameters[index] = vlaveOutput;
            }
        }

        /// <summary>
        /// Checks me night flush pause time e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMENightFlushPauseTimeEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.NightFlushPauseTimeOverridePlcValues = false;
            if (pump.ControllerEquipmentId < 9) return;// return if it is a pump
            ///ME_Parameters[ME Nb,6]
            //FlushWhileDosingME(2),....8 address locations,Pump_Parameters,ME_Parameters
            /// 
            int index;
            if (pump.ControllerEquipmentId == 9)//ME1
            {
                index = 42 + 5;
            }
            else
            {
                index = 42 + 9 + 5;
            }

            if (pump.NightFlushPauseTime != pumpParameters[index])
            {
                pump.NightFlushPauseTimeOverridePlcValues = true;
                pumpParameters[index] = pump.NightFlushPauseTime;
            }
        }
        /// <summary>
        /// Checks me night flush time e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMENightFlushTimeEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.NightFlushTimeOverridePlcValues = false;
            if (pump.ControllerEquipmentId < 9) return;// return if it is a pump
            ///ME_Parameters[ME Nb,7]
            //FlushWhileDosingME(2),....8 address locations,Pump_Parameters,ME_Parameters
            int index;
            if (pump.ControllerEquipmentId == 9)//ME1
            {
                index = 42 + 6;
            }
            else
            {
                index = 42 + 9 + 6;
            }

            if (pump.NightFlushTime * 10 != pumpParameters[index])
            {
                pump.NightFlushTimeOverridePlcValues = true;
                pumpParameters[index] = pump.NightFlushTime * 10;
            }
        }

        /// <summary>
        /// Checks me pre flush time for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMEPreFlushTimeForEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.PreFlushTimeOverridePlcValues = false;
            // return if it is a pump
            if (pump.ControllerEquipmentId < 9) return;
            //return if not Compactomix / Desamix/Examix
            if (pump.ControllerEquipmentTypeModelId != 12 && pump.ControllerEquipmentTypeModelId != 13) return;

            int index;
            if (pump.ControllerEquipmentId == 9)
            {
                index = 42 + 1;
            }
            else
            {
                index = 42 + 9 + 1;
            }

            if (pump.PreFlushTime * 10 != pumpParameters[index])
            {
                pump.PreFlushTimeOverridePlcValues = true;
                pumpParameters[index] = pump.PreFlushTime * 10;
            }
        }

        /// <summary>
        /// Checks me pumping time for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMEPumpingTimeForEcontrolPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.PumpingTimeOverridePlcValues = false;
            if (pump.ControllerEquipmentId < 9) return;
            if (pump.ControllerEquipmentTypeModelId != 12) return;
            int index;
            if (pump.ControllerEquipmentId == 9)
            {
                index = 42 + 2;
            }
            else
            {
                index = 42 + 9 + 2;
            }

            if (pump.PumpingTime * 10 != pumpParameters[index])
            {
                pump.PumpingTimeOverridePlcValues = true;
                pumpParameters[index] = pump.PumpingTime * 10;
            }
        }

        /// <summary>
        /// Checks me flush time for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMEFlushTimeForEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.FlushTimeOverridePlcValues = false;
            // return if it is a pump
            if (pump.ControllerEquipmentId < 9) return;

            //return if not Compatomix
            if (pump.ControllerEquipmentTypeModelId != 13) return;
            int index;
            //ME1
            if (pump.ControllerEquipmentId == 9)
            {
                index = 42 + 2;
            }
            else
            {
                index = 42 + 9 + 2;
            }

            if (pump.FlushTime * 10 != pumpParameters[index])
            {
                pump.FlushTimeOverridePlcValues = true;
                pumpParameters[index] = pump.FlushTime * 10;
            }
        }

        /// <summary>
        /// Checks me type for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckMETypeForEcontrolPlus(PumpsModel pump, int[] pumpParameters)
        {
            pump.METypeOverridePlcValues = false;
            // return if it is a pump
            if (pump.ControllerEquipmentId < 9) return;
            int METype = pump.ControllerEquipmentTypeModelId - 11;
            ///ME_Parameters[ME Nb, 4]
            //FlushWhileDosingME(2),....8 address locations,Pump_Parameters,ME_Parameters
            /// 
            int index;
            //ME1
            if (pump.ControllerEquipmentId == 9)
            {
                index = 42 + 3;
            }
            else
            {
                index = 42 + 9 + 3;
            }
            if (METype != pumpParameters[index])
            {
                pump.METypeOverridePlcValues = true;
                pumpParameters[index] = METype;
            }
        }
        /// <summary>
        /// Checks the low level alarm e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowValues">The flow values.</param>
        private void CheckLowLevelAlarmEControlPlus(PumpsModel pump, int[] flowValues)
        {
            int startIndex;
            int lowLevelAram = pump.LowLevelAlarm ? 1 : 0;
            // ControllerEquipmentId == 9 : ME1; ControllerEquipmentId == 10): ME2
            if (pump.ControllerEquipmentId == 9)
            {
                startIndex = 0;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                startIndex = 9 * 2;
            }
            else
            {
                startIndex = pump.ControllerEquipmentId * 2;
            }
            pump.LowLevelAlarmOverridePlcValues = false;
            if (lowLevelAram != flowValues[startIndex])
            {
                pump.LowLevelAlarmOverridePlcValues = true;
                flowValues[startIndex] = lowLevelAram;
            }
        }

        /// <summary>
        /// Checks the equipment dose alone for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowValues">The flow values.</param>
        private void CheckEquipmentDoseAloneForEControlPlus(PumpsModel pump, int[] flowValues)
        {
            int startIndex;
            int isEquipmentDoseAlone = pump.EquipmentDoseAlone ? 1 : 0;
            if (pump.ControllerEquipmentId == 9)
            {
                startIndex = 66 + 0;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                startIndex = 66 + 9;
            }
            else
            {
                startIndex = 66 + pump.ControllerEquipmentId;
            }

            pump.EquipmentDoseAloneOverridePlcValues = false;
            if (flowValues[startIndex] != isEquipmentDoseAlone)
            {
                pump.EquipmentDoseAloneOverridePlcValues = true;
                flowValues[startIndex] = isEquipmentDoseAlone;
            }
        }
        /// <summary>
        /// Checks the weight controlled dosage for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowValues">The flow values.</param>
        private void CheckWeightControlledDosageForEControlPlus(PumpsModel pump, int[] flowValues)
        {
            //Following variables are stored in int[] flowValues
            //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            int isWeightControlled = pump.WeightControlledDosage ? 1 : 0;
            int startIndex;
            if (pump.ControllerEquipmentId == 9)
            {
                startIndex = 1;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                startIndex = 9 * 2 + 1;
            }
            else
            {
                startIndex = pump.ControllerEquipmentId * 2 + 1;
            }
            pump.WeightControlledDosageOverridePlcValues = false;
            if (isWeightControlled != flowValues[startIndex])
            {
                pump.WeightControlledDosageOverridePlcValues = true;
                flowValues[startIndex] = isWeightControlled;
            }
        }
        /// <summary>
        /// Checks the flush while dosing for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckFlushWhileDosingForEcontrolPlus(PumpsModel pump, int[] pumpParameters)
        {
            int flushWhileDosing = pump.FlushWhileDosing ? 1 : 0;

            //int[] pumpParameters  array has following varibles in it.
            //FlushWhileDosingME(2),....8 address locations,Pump_Parameters,ME_Parameters
            int StartIndex;
            if (pump.ControllerEquipmentId == 9)
            {
                StartIndex = 0;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                StartIndex = 1;
            }
            else
            {
                StartIndex = 10 + (pump.ControllerEquipmentId - 1) * 4 + 3;
            }
            pump.FlushWhileDosingOverridePlcValues = false;
            if (flushWhileDosing != pumpParameters[StartIndex])
            {
                pump.FlushWhileDosingOverridePlcValues = true;
                pumpParameters[StartIndex] = flushWhileDosing;
            }
        }
        /// <summary>
        /// Checks the flow meter activated for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowValues">The flow values.</param>
        private void CheckFlowMeterActivatedForEControlPlus(PumpsModel pump, int[] flowValues)
        {
            int switchActivated = 0;
            pump.FlowmeterSwitchActivatedOverridePlcValues = false;
            if (pump.FlowDetectorType == 0) return;

            //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            int startIndex = 56;//FMS_Activ starts at 956 in int[] flowValues

            if (pump.ControllerEquipmentId == 10)
            {
                startIndex = startIndex + 9;
            }
            else if (pump.ControllerEquipmentId < 9)
            {
                startIndex = startIndex + pump.ControllerEquipmentId;
            }
            if (pump.FlowmeterSwitchActivated) switchActivated = 1;

            if (flowValues[startIndex] != switchActivated)
            {
                pump.FlowmeterSwitchActivatedOverridePlcValues = true;
                flowValues[startIndex] = switchActivated;
            }
        }

        /// <summary>
        /// Checks the flow switch time out for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckFlowSwitchTimeOutForEcontrolPlus(PumpsModel pump, int[] pumpParameters)
        {
            int startIndex = 0;
            if (pump.ControllerEquipmentId == 9)
            {
                startIndex = 42 + 8;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                startIndex = 42 + 9 + 8;
            }
            else
            {
                startIndex = 10 + (pump.ControllerEquipmentId - 1) * 4 + 1;
            }
            pump.FlowSwitchTimeOutOverridePlcValues = false;
            if (pump.FlowSwitchTimeOut * 10 != pumpParameters[startIndex])
            {
                pump.FlowSwitchTimeOutOverridePlcValues = true;
                pumpParameters[startIndex] = Convert.ToInt32(pump.FlowSwitchTimeOut * 10);
            }
        }

        /// <summary>
        /// Checks the flow meter calibration.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowIntValues">The flow int values.</param>
        private void CheckFlowMeterCalibration(PumpsModel pump, int[] flowIntValues)
        {
            pump.KFactorOverridePlcValues = false;
            int index = 0; //for ME1 index =0
            if (pump.FlowDetectorType != 1) return;
            if (pump.ControllerEquipmentId == 10)
            {
                index = 9;
            }
            else if (pump.ControllerEquipmentId < 9)
            {
                index = pump.ControllerEquipmentId;
            }

            if (pump.KFactor != flowIntValues[index])
            {
                pump.KFactorOverridePlcValues = true;
                flowIntValues[index] = Convert.ToInt32(pump.KFactor);
            }
        }
        /// <summary>
        /// Checks the maximum dosing time for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowIntValues">The flow int values.</param>
        private void CheckMaximumDosingTimeForEcontrolPlus(PumpsModel pump, int[] flowIntValues)
        {
            try
            {
                ///flowIntValues array has following PLC variables FlowMeterPulsesPerLiter,MaxTimeFlowMeter
                int startIndex = 10; //MaxTimeFlowMeter starts at 10 in the array flowIntValues.
                if (pump.ControllerEquipmentId == 10)
                {
                    startIndex = startIndex + 9;
                }
                else if (pump.ControllerEquipmentId < 9)
                {
                    startIndex = startIndex + pump.ControllerEquipmentId;
                }
                pump.MaximumDosingTimeOverridePlcValues = false;
                if (flowIntValues[startIndex] != pump.MaximumDosingTime)
                {
                    pump.MaximumDosingTimeOverridePlcValues = true;
                    flowIntValues[startIndex] = Convert.ToInt16(pump.MaximumDosingTime);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                System.Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Checks the flow dector type for econtrol plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="flowValues">The flow values.</param>
        private void CheckFlowDectorTypeForEcontrolPlus(PumpsModel pump, int[] flowValues)
        {
            pump.FlowDetectorTypeOverridePlcValues = false;
            //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            int flowMeterStartIndex = 36;
            int flowSwitchStartIndex = 46;

            if (pump.ControllerEquipmentId == 10)
            {
                flowMeterStartIndex = flowMeterStartIndex + 9;
                flowSwitchStartIndex = flowSwitchStartIndex + 9;
            }
            else if (pump.ControllerEquipmentId < 9)
            {
                flowMeterStartIndex = flowMeterStartIndex + pump.ControllerEquipmentId;
                flowSwitchStartIndex = flowSwitchStartIndex + pump.ControllerEquipmentId;
            }

            if (pump.FlowDetectorType == 0)
            {
                if (flowValues[flowMeterStartIndex] != 0 || flowValues[flowSwitchStartIndex] != 0)
                {
                    pump.FlowDetectorTypeOverridePlcValues = true;
                    flowValues[flowMeterStartIndex] = 0;
                    flowValues[flowSwitchStartIndex] = 0;
                }
            }
            else if (pump.FlowDetectorType == 1)
            {
                if (flowValues[flowMeterStartIndex] != 1 || flowValues[flowSwitchStartIndex] != 0)
                {
                    pump.FlowDetectorTypeOverridePlcValues = true;
                    flowValues[flowMeterStartIndex] = 1;
                    flowValues[flowSwitchStartIndex] = 0;
                }
            }
            else if (pump.FlowDetectorType == 2)
            {
                if (flowValues[flowMeterStartIndex] != 0 || flowValues[flowSwitchStartIndex] != 1)
                {
                    pump.FlowDetectorTypeOverridePlcValues = true;
                    flowValues[flowMeterStartIndex] = 0;
                    flowValues[flowSwitchStartIndex] = 1;
                }
            }
        }

        /// <summary>
        /// Checks the calibaration for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckCalibarationForEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            int startIndex = 0;

            if (pump.ControllerEquipmentId == 9)
            {
                startIndex = 42;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                startIndex = 42 + 9;
            }
            else
            {
                startIndex = 10 + (pump.ControllerEquipmentId - 1) * 4;
            }
            if (pumpParameters[startIndex] != Convert.ToInt32(pump.PumpCalibration))
            {
                pump.CalibrationOverridePlcValues = true;
                pumpParameters[startIndex] = Convert.ToInt32(pump.PumpCalibration);
            }
        }
        /// <summary>
        /// Writes the line compartment numbers for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="cbwParameters">The CBW parameters.</param>
        private void WriteLineCompartmentNumbersForEControlPlus(PumpsModel pump, int[] cbwParameters)
        {
            List<LineCompartmentMappingModel> lineCompartmentMappings;
            lineCompartmentMappings = GetLineData(pump.LineNumber, pump.ControllerId);
            LineCompartmentMappingModel cmptMapping;
            int valveIndex;
            int compartmentIndex;
            if (pump.ControllerTypeId == 6)
                return;

            for (int i = 1; i <= 4; i++)
            {
                valveIndex = 14 + (pump.LineNumber - 1) * 4 + i - 1;
                cmptMapping = lineCompartmentMappings.FirstOrDefault(t => t.DosingPointNumber == i && t.LineNumber == pump.LineNumber);

                if (cmptMapping == null)
                {
                    cbwParameters[valveIndex] = 0;
                }
                else
                {
                    cbwParameters[valveIndex] = cmptMapping.ValveNumber;
                    compartmentIndex = 46 + cmptMapping.ValveNumber - 1;
                    cbwParameters[compartmentIndex] = cmptMapping.CompartmentNumber;
                }
            }
        }
        /// <summary>
        /// Checks the line compartment numbers for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="cbwParameters">The CBW parameters.</param>
        private void CheckLineCompartmentNumbersForEControlPlus(PumpsModel pump, int[] cbwParameters)
        {
            List<LineCompartmentMappingModel> lineCompartmentMappings;
            lineCompartmentMappings = GetLineData(pump.LineNumber, pump.ControllerId);
            LineCompartmentMappingModel cmptMapping;
            int valveIndex;
            int compartmentIndex;
            int valveNumberInPLC;
            int compartNumberInPLC;
            if (pump.ControllerTypeId == 6)
                return;
            if (pump.LineNumberOverridePlcValues)
            {
                pump.TunnelCompartmentOverridePlcValues = "1,2,3,4";
                return;
            }
            StringBuilder OverridePlcValues = new StringBuilder(10);
            for (int i = 1; i <= 4; i++)
            {
                valveIndex = 14 + (pump.LineNumber - 1) * 4 + i - 1;
                valveNumberInPLC = cbwParameters[valveIndex];
                compartNumberInPLC = 0;
                if (valveNumberInPLC > 0 && valveNumberInPLC < 21)
                {
                    compartmentIndex = 46 + valveNumberInPLC - 1;
                    compartNumberInPLC = cbwParameters[compartmentIndex];
                }

                cmptMapping = lineCompartmentMappings.FirstOrDefault(t => t.DosingPointNumber == i && t.LineNumber == pump.LineNumber);

                if (cmptMapping == null)
                {
                    if (compartNumberInPLC > 0)
                        OverridePlcValues.Append(i.ToString() + ",");
                }
                else
                {
                    if (valveNumberInPLC != cmptMapping.ValveNumber ||
                        compartNumberInPLC != cmptMapping.CompartmentNumber)
                    {
                        OverridePlcValues.Append(i.ToString() + ",");
                    }
                }
            }
            pump.TunnelCompartmentOverridePlcValues = OverridePlcValues.ToString();

        }

        /// <summary>
        /// Checks the line number for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="pumpParameters">The pump parameters.</param>
        private void CheckLineNumberForEControlPlus(PumpsModel pump, int[] pumpParameters)
        {
            int startIndex;

            /*
                 ME1: ME_Parameters[1,8] - Must be forced to 1
                ME2: ME_Parameters[2,8]
                Pumps: Pump_Parameters[PumpNb,3]
            */
            //FlushWhileDosingME(2),....8 address,Pump_Parameters,ME_Parameters

            if (pump.ControllerEquipmentId == 9)
            {
                // ME_Parameters starts @ 34  because pumpParameters has all 3 arrays FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
                //ME_Parameters is 2 dimensional Array ME_Parameters[ME_NB,9params].For ME1 it starts with 34 in int[] pumpParameters argument above
                //Line_Number is 8th parameter in the ME_Parameters. So 7 is added to 34 below
                startIndex = 42 + 7;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                // ME_Parameters starts @ 34  because pumpParameters has all 3 arrays FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
                //ME_Parameters i 2 dimensional Array ME_Parameters[ME_NB,9params].For ME2 it starts with 34 + 9 in int[] pumpParameters argument above
                //Line_Number is 8th parameter in the ME_Parameters. So 7 is added to 34 below
                startIndex = 42 + 9 + 7;
            }
            else
            {
                //Pump_Parameters 2 in pumpParameters because pumpParameters has all 3 arrays FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
                //Pump_Parameters is 2 dimensional Array Pump_Parameters[pump_nb,4params].
                //Line_Number is 3rd parameter in the Pump_Parameters. So 2 is added below
                startIndex = 10 + (pump.ControllerEquipmentId - 1) * 4 + 2;
            }

            pump.LineNumberOverridePlcValues = false;
            if (pump.LineNumber != pumpParameters[startIndex])
            {
                pump.LineNumberOverridePlcValues = true;
                pumpParameters[startIndex] = pump.LineNumber;
            }
        }

        /// <summary>
        /// Checks the conventional washer group connection for e control plus.
        /// </summary>
        /// <param name="pump">The pump data for Econtrol Plus.</param>
        /// <param name="totalWasherCount">The total washer count.</param>
        /// <param name="washerParameters">The washer parameters.</param>
        private void CheckConventionalWasherGroupConnectionForEControlPlus(PumpsModel pump, int totalWasherCount, int[] washerParameters)
        {
            int plcPumpIndex;
            int deviationIndex;
            //check Conventional Washer Group Connection.
            pump.ConventionalWgConnOverridePlcValues = false;
            if (pump.ControllerEquipmentId == 9)
            {
                plcPumpIndex = 3;
            }
            else if (pump.ControllerEquipmentId == 10)
            {
                plcPumpIndex = 12;
            }
            else
            {
                plcPumpIndex = 4 + pump.ControllerEquipmentId - 1;
            }
            //WE_Parameters[WENb,x]---If ConventionalWasherGroupConnection=No, 
            //the product deviation for this pump must be set to 0 for all the WE
            if (!pump.ConventionalWasherGroupConnection)
            {
                for (int index = 0; index < totalWasherCount; index++)
                {
                    deviationIndex = index * 30 + plcPumpIndex - 1;
                    if (washerParameters[deviationIndex] != 0)
                    {
                        pump.ConventionalWgConnOverridePlcValues = true;
                        washerParameters[deviationIndex] = 0;

                    }
                }
            }
        }

        /// <summary>
        /// Builds the model with PLC overrides.
        /// </summary>
        /// <param name="pumpMetaData">The pump meta data.</param>
        /// <returns>List of Pumps Model data.</returns>
        private List<PumpsModel> BuildPLCXLModelWithPLCOverrides(List<PumpsModel> pumpMetaData)
        {
            List<string> tagCollectionList = new List<string>();
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            foreach (PumpsModel model in pumpMetaData)
            {
                tagCollectionList = new List<string>();
                List<MitsubishiTag> appTags = BuildPumpsTagsPLCXL(model, false);
                List<MitsubishiTag> plcTags = BuildPumpsTagsPLCXL(model, false);
                if (appTags != null)
                {
                    plcTags = plc.ValidatePLCXLTags(plcTags, model.ControllerId, SourcePage.PumpsPage);
                }
                if (plcTags.Count > 0 && appTags.Count > 0)
                {
                    foreach (MitsubishiTag tag in appTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) || (_.TagItemType == (UIInputType.TypeObject) || _.TagItemType == UIInputType.TypeString)))
                    {
                        foreach (MitsubishiTag plcTag in plcTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                            {
                                tagCollectionList.Add(tag.TagType);
                            }
                        }
                    }
                }
                model.KFactorOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlowMeterCalibrationKFactor")).FirstOrDefault()) ? false : true;
                if (model.FlowDetectorType == 1)
                {
                    model.MaximumDosingTimeOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("MaximumDosingTime")).FirstOrDefault()) ? false : true;
                    model.FlowmeterSwitchActivatedOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlowSwitchActivatedFlowMeter")).FirstOrDefault()) ? false : true;

                }
                else if (model.FlowDetectorType == 2)
                {
                    model.FlowSwitchTimeOutOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlowSwitchTimeout")).FirstOrDefault()) ? false : true;
                    model.FlowmeterSwitchActivatedOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlowSwitchActivatedFlowSwitch")).FirstOrDefault()) ? false : true;
                }

                model.LineNumberOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("LineNumber")).FirstOrDefault()) ? false : true;
                model.CalibrationOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("PumpCalibration")).FirstOrDefault()) ? false : true;

                model.WeightControlledDosageOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("WeightControlledDosage")).FirstOrDefault()) ? false : true;
                model.LowLevelAlarmOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("LowLevelAlarm")).FirstOrDefault()) ? false : true;
                model.LeakageAlarmOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("LeakageAlarm")).FirstOrDefault()) ? false : true;
                model.ConcentrationOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("Concentration")).FirstOrDefault()) ? false : true;
                model.CalibrationConductSS_TankOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("CalibrationConductSS-Tank")).FirstOrDefault()) ? false : true;
                model.BackFlowControlOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("BackFlowControl")).FirstOrDefault()) ? false : true;
                model.FactorFM_B_FMOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FactorFM-B-FM")).FirstOrDefault()) ? false : true;
                model.AcceptedDeviationRingLineOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("AcceptedDeviationOnTheRingLine")).FirstOrDefault()) ? false : true;
                model.StockSolutionDeadEndOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("StockSolutionDeadEnd")).FirstOrDefault()) ? false : true;
                model.METypeOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("METype")).FirstOrDefault()) ? false : true;
                model.FlushTimeOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlushTime")).FirstOrDefault()) ? false : true;
                model.PumpingTimeOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("PumpingTime")).FirstOrDefault()) ? false : true;

                model.UsePumpOfGroup1ForTunnelOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("UsePumpOfGroup1ForTunnel")).FirstOrDefault()) ? false : true;
                model.pHSensorEnabledOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("PumpUsedForph-Control")).FirstOrDefault()) ? false : true;
                if (!model.DirectDosingFlag)
                {
                    var compartments = tagCollectionList.Where(x => x.Contains("CompartmentNbrFor")).ToList();
                    if (compartments.Count > 0)
                    {
                        foreach (string item in compartments)
                        {
                            model.TunnelCompartmentOverridePlcValues += item + " ";
                        }
                    }
                }
                else
                {
                    model.DirectDosingTunnelCompartmentIdOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("CompartmentNumberForDirectDosing")).FirstOrDefault()) ? false : true;
                }
                if (model.FlushValveNumber != null)
                {
                    model.FlushValveNumberOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlushValveNumber")).FirstOrDefault()) ? false : true;
                    model.FlushWhileDosingOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlushWhileDosing")).FirstOrDefault()) ? false : true;
                }
            }
            return pumpMetaData;
        }
        /// <summary>
        /// Mycontrol model with Plc override values.
        /// </summary>
        /// <param name="pumpMetaData">The pump metadata.</param>
        /// <returns>List of mycontrol plc override values.</returns>
        private List<PumpsModel> BuildMyControlModelWithPLCOverrides(List<PumpsModel> pumpMetaData)
        {
            List<string> tagCollectionList = new List<string>();
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            foreach (PumpsModel model in pumpMetaData)
            {
                tagCollectionList = new List<string>();
                if (model.ProductName != null)
                {
                    List<BeckhoffTag> appTags = BuildPumpsTags(model);
                    List<BeckhoffTag> plcTags = BuildPumpsTags(model);
                    Uints_Helms_ConfigCNAndHelms_2 objAppUints_Helms_ConfigCNAndHelms_2;
                    Uints_Helms_ConfigCNAndHelms_2 objPlcUints_Helms_ConfigCNAndHelms_2;
                    Uints_Helms_ConfigCN objUints_Helms_ConfigCN;
                    if (appTags != null)
                    {
                        plcTags = plc.ValidateMyControlTags(plcTags, model.ControllerId, SourcePage.PumpsPage);
                    }
                    if (plcTags.Count > 0 && appTags.Count > 0)
                    {
                        foreach (BeckhoffTag tag in appTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) || (_.TagItemType == UIInputType.TypeObject || _.TagItemType == UIInputType.TypeString)))
                        {
                            foreach (BeckhoffTag plcTag in plcTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) || (_.TagItemType == UIInputType.TypeObject || _.TagItemType == UIInputType.TypeString)))
                            {
                                if (tag.Address == plcTag.Address)
                                {
                                    if (tag.TagItemType == UIInputType.TypeInt)
                                    {
                                        if (Convert.ToInt32(tag.Value.Trim()) != Convert.ToInt32(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else if (tag.TagItemType == UIInputType.TypeFloat)
                                    {
                                        if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else if (tag.TagItemType == UIInputType.TypeBool)
                                    {
                                        if (Convert.ToBoolean(tag.Value.Trim()) != Convert.ToBoolean(plcTag.Value.Trim()))
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                    else if (tag.TagItemType == UIInputType.TypeObject)
                                    {
                                        int valExists = 0;
                                        int zeroExists = 0;
                                        if (tag.Address == "Helms_Info.uint_Helms_ConfigCN")
                                        {
                                            objUints_Helms_ConfigCN = (Uints_Helms_ConfigCN)plcTag.ComplexObject;
                                            for (int tagIndex = 0; tagIndex < 16; tagIndex++)
                                            {
                                                if (objUints_Helms_ConfigCN.uint_WE_Parameter[((model.ControllerEquipmentId + 2) + (72 * tagIndex)) - 1] != 0)
                                                { valExists++; }
                                                else { zeroExists++; }
                                            }
                                            if (valExists > 0 && zeroExists > 0)
                                            { model.ConventionalWgConnOverridePlcValues = true; }
                                            else if (model.ConventionalWasherGroupConnection && zeroExists > 0)
                                            { model.ConventionalWgConnOverridePlcValues = true; }
                                            else if (!model.ConventionalWasherGroupConnection && valExists > 0)
                                            { model.ConventionalWgConnOverridePlcValues = true; }
                                        }
                                        else if (tag.Address == "Helms_Info.uint_Helms_ConfigCNAndHelms_2")
                                        {
                                            objAppUints_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)tag.ComplexObject;
                                            objPlcUints_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)plcTag.ComplexObject;
                                            for (int j = 0; j < objAppUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter.Length; j++)
                                            {
                                                if (objAppUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[j] == 6550)
                                                {
                                                    objAppUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[j] = 0;
                                                }
                                            }

                                            List<LineCompartmentMappingModel> LineCompartmentMappings = GetLineData(model.LineNumber, model.ControllerId, model.ControllerEquipmentSetupId);

                                            int tunnelRootNumber = 0;
                                            foreach (var item in LineCompartmentMappings)
                                            {
                                                tunnelRootNumber = item.TunnelNumber > 1 ? 176 : 0;
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((tunnelRootNumber) + 100 + item.ValveNumber)]) !=
                                                    Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((tunnelRootNumber) + 100 + item.ValveNumber)]))
                                                {
                                                    model.TunnelCompartmentOverridePlcValues = string.Concat(model.TunnelCompartmentOverridePlcValues, (item.TunnelNumber > 1 ? " T2Dp" : " T1Dp") + item.DosingPointNumber.ToString());
                                                }
                                                tunnelRootNumber = 0;
                                            }

                                            if (model.ControllerEquipmentId < 25)
                                            {
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].DosLine) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].DosLine))
                                                {
                                                    model.LineNumberOverridePlcValues = true;//Line Number(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FMMaxTime) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FMMaxTime))
                                                {
                                                    model.MaximumDosingTimeOverridePlcValues = true;//Max dosing Time
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FSDelay) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FSDelay))
                                                {
                                                    model.FlowSwitchTimeOutOverridePlcValues = true;//Flow switch timeout(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].PumpCalib) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].PumpCalib))
                                                {
                                                    model.CalibrationOverridePlcValues = true;//Flow switch timeout(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].AuxiliaryPumpCalib) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].AuxiliaryPumpCalib))
                                                {
                                                    model.AxillaryPumpCalibrationOverridePlcValues = true;//Auxillary Pump Calibration(P)
                                                }
                                                if (model.DirectDosingFlag)
                                                {
                                                    model.TunnelCompartmentOverridePlcValues = string.Empty;
                                                    if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].TUNNb_DD) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].TUNNb_DD))
                                                    {
                                                        model.DirectDosingMachineInternalIdOverridePlcValues = true;
                                                    }
                                                    if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].CompNb_DD) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].CompNb_DD))
                                                    {
                                                        model.DirectDosingTunnelCompartmentIdOverridePlcValues = true;
                                                    }
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FMCalib) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[model.ControllerEquipmentId - 1].FMCalib))
                                                {
                                                    model.KFactorOverridePlcValues = true;//KFactor(P)
                                                }
                                            }
                                            else if (model.ControllerEquipmentId > 24 && model.ControllerEquipmentId < 27)
                                            {
                                                //For MEs (25,26)
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].DosLine) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].DosLine))
                                                {
                                                    model.LineNumberOverridePlcValues = true;//Line Number(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].PumpCalib) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].PumpCalib))
                                                {
                                                    model.CalibrationOverridePlcValues = true;//Line Number(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FMMaxTime) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FMMaxTime))
                                                {
                                                    model.MaximumDosingTimeOverridePlcValues = true;//Max dosing Time
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FSDelay) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FSDelay))
                                                {
                                                    model.FlowSwitchTimeOutOverridePlcValues = true;//Flow switch timeout(P)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].PreFlushTime) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].PreFlushTime))
                                                {
                                                    model.PreFlushTimeOverridePlcValues = true;//Pre flush time(ME) only for ME Type Compactomix or Desamix / Examix
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].StNightFlush) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].StNightFlush))
                                                {
                                                    model.NightFlushPauseTimeOverridePlcValues = true;//Night flush pause time (ME)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].NightFlushTime) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].NightFlushTime))
                                                {
                                                    model.NightFlushTimeOverridePlcValues = true;//Night flush time 
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FlushPumpingtime) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FlushPumpingtime))
                                                {
                                                    model.PumpingTimeOverridePlcValues = true;//Line Number(ME)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FMCalib) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].FMCalib))
                                                {
                                                    model.KFactorOverridePlcValues = true;//KFactor(ME)
                                                }
                                                if (Convert.ToInt16(objAppUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].METype) != Convert.ToInt16(objPlcUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(model.ControllerEquipmentId == 25 ? 0 : 1)].METype))
                                                {
                                                    model.METypeOverridePlcValues = true;//METype(ME)
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (tag.Value.Trim() != plcTag.Value.Trim())
                                        {
                                            tagCollectionList.Add(tag.Address);
                                        }
                                    }
                                }
                            }
                            bool aFS = appTags.Where(x => x.Address.Contains("FSEnable")).FirstOrDefault().Value.ToLower() == "false" ? false : true;
                            bool aFM = appTags.Where(x => x.Address.Contains("FMEnable")).FirstOrDefault().Value.ToLower() == "false" ? false : true;
                            bool pFS, pFM = false;
                            if (plcTags.Count() != 0)
                            {
                                pFS = plcTags.Where(x => x.Address.Contains("FSEnable")).FirstOrDefault().Value.ToLower() == "false" ? false : true;
                                pFM = plcTags.Where(x => x.Address.Contains("FMEnable")).FirstOrDefault().Value.ToLower() == "false" ? false : true;
                                model.FlowDetectorTypeOverridePlcValues = (aFS != pFS || aFM != pFM) == true ? true : false;
                            }
                        }
                    }
                    model.ProductNameOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("str_ProductName")).FirstOrDefault()) ? false : true;
                    model.FlushWhileDosingOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FlushWDos")).FirstOrDefault()) ? false : true;
                    model.WeightControlledDosageOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("WeightControl")).FirstOrDefault()) ? false : true;
                    model.EquipmentDoseAloneOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("PDosAlone")).FirstOrDefault()) ? false : true;
                    model.LowLevelAlarmOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("LLAlarm")).FirstOrDefault()) ? false : true;
                    model.LeakageAlarmOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("LeakAlarm")).FirstOrDefault()) ? false : true;
                    model.FlowmeterSwitchActivatedOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("FMFSActive")).FirstOrDefault()) ? false : true;
                    model.DirectDosingFlagOverridePlcValues = string.IsNullOrEmpty(tagCollectionList.Where(x => x.Contains("DirectDosing")).FirstOrDefault()) ? false : true;
                }
            }
            return pumpMetaData;
        }

        /// <summary>
        /// Builds the pumps tags.
        /// </summary>
        /// <param name="pumpData">The pump data.</param>
        /// <param name="prevPumpData">The previous pump data.</param>
        /// <returns>List of Beckhoff tags.</returns>
        private List<BeckhoffTag> BuildPumpsTags(PumpsModel pumpData, Ecolab.Models.ControllerSetup.Pumps.PumpsModel prevPumpData = null)
        {
            var tagsList = new List<BeckhoffTag>();

            Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
            objPumpData.LineCompartmentMappings = GetLineData(objPumpData.LineNumber, objPumpData.ControllerId, objPumpData.ControllerEquipmentSetupId);
            if (pumpData.ProductName != null)
            {
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".str_ProductName[" + pumpData.ControllerEquipmentId + "]",
                    Value = pumpData.ProductName.ToString().Trim(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeString
                });
                foreach (var tag in tagsList)
                {
                    if (tag.Address.Contains(".str_ProductName"))
                    {
                        int length = tag.Value.Length;
                        if (length > 30)
                        {
                            tag.Value = tag.Value.Substring(0, 30);
                        }
                        tag.Value = Regex.Replace(tag.Value, "[^0-9A-Za-z ,._%-/(){}&]", string.Empty);
                    }
                }
                //Product Deviation
                Uints_Helms_ConfigCN objUints_Helms_ConfigCN = new Uints_Helms_ConfigCN();
                for (int i = 0; i < objUints_Helms_ConfigCN.uint_WE_Parameter.Length; i++)
                {
                    objUints_Helms_ConfigCN.uint_WE_Parameter[i] = 6550;
                }
                for (int i = 0; i < 16; i++)
                {
                    objUints_Helms_ConfigCN.uint_WE_Parameter[(((pumpData.ControllerEquipmentId + 2) + (72 * i)) - 1)] = Convert.ToUInt16(pumpData.ConventionalWasherGroupConnection ? 100 : 0);
                }
                tagsList.Add(new BeckhoffTag()
                {
                    Address = "Helms_Info.uint_Helms_ConfigCN",
                    TagItemType = UIInputType.TypeObject,
                    ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName,
                    ComplexObject = objUints_Helms_ConfigCN
                });
                //Pump in Direct Dosing Mode(P)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].DirectDosing",
                    Value = pumpData.DirectDosingFlag.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });

                Uints_Helms_ConfigCNAndHelms_2 objUints_Helms_ConfigCNAndHelms_2 = new Uints_Helms_ConfigCNAndHelms_2();
                for (int i = 0; i < objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter.Length; i++)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[i] = 6550;
                }
                for (int i = 0; i < objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter.Length; i++)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].DosLine = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].FMMaxTime = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].FSDelay = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].PumpCalib = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].AuxiliaryPumpCalib = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].FMCalib = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].TUNNb_DD = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[i].CompNb_DD = 6550;
                }
                for (int i = 0; i < objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter.Length; i++)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].DosLine = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].PumpCalib = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].FMMaxTime = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].FSDelay = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].PreFlushTime = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].StNightFlush = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].NightFlushTime = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].FMCalib = 6550;
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[i].METype = 6550;
                }
                if (prevPumpData != null)
                {
                    if (prevPumpData.LineCompartmentMappings.Count() > 0)
                    {
                        if (!prevPumpData.DirectDosingFlag)
                        {
                            foreach (LineCompartmentMappingModel item in prevPumpData.LineCompartmentMappings)
                            {
                                int tunnelNumber = item.TunnelNumber == 1 ? 0 : 176;
                                objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[(tunnelNumber + (Convert.ToInt32((item.LineNumber - 1) * 4)) + (Convert.ToInt32(item.DosingPointNumber) - 1) + 37)] = 0;
                                objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[(tunnelNumber + 100) + item.ValveNumber] = 0;
                            }
                        }
                        if (pumpData.ControllerEquipmentId < 25)
                        {
                            objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].TUNNb_DD = 0;
                            objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].CompNb_DD = 0;
                        }
                    }
                }
                if (objPumpData.LineCompartmentMappings.Count() > 0)
                {
                    if (!objPumpData.DirectDosingFlag)
                    {
                        foreach (LineCompartmentMappingModel item in objPumpData.LineCompartmentMappings)
                        {
                            //uint_TUN_Parameter[1 – 176]
                            int tunnelNumber = item.TunnelNumber == 1 ? 0 : 176;
                            objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((tunnelNumber) + (Convert.ToInt32((item.LineNumber - 1) * 4)) + (Convert.ToInt32(item.DosingPointNumber) - 1) + 37)] = item.ValveNumber;//Helms_Info.uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[n][38 … 121])
                            objUints_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((tunnelNumber) + 100) + item.ValveNumber] = item.CompartmentNumber;
                        }
                    }
                }
                if (pumpData.ControllerEquipmentId < 25)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].TUNNb_DD = Convert.ToUInt16(pumpData.DirectDosingFlag ? pumpData.DirectDosingMachineInternalId : 0);
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].CompNb_DD = Convert.ToUInt16(pumpData.DirectDosingFlag ? pumpData.DirectDosingTunnelCompartmentId : 0);
                }
                if (pumpData.ControllerEquipmentId < 25)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].DosLine = pumpData.LineNumber;//Line Number(P)
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].FMMaxTime = Convert.ToUInt16(pumpData.MaximumDosingTime);//Max dosing Time
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].FSDelay = Convert.ToUInt16(pumpData.FlowSwitchTimeOut);//Flow switch timeout(P)
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].PumpCalib = Convert.ToUInt16(pumpData.PumpCalibration);//Pump Calibration(P)
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].AuxiliaryPumpCalib = Convert.ToUInt16(pumpData.AxillaryPumpCalibration);//Auxillary Pump Calibration(P)
                    objUints_Helms_ConfigCNAndHelms_2.uint_Pump_Parameter[pumpData.ControllerEquipmentId - 1].FMCalib = Convert.ToUInt16(pumpData.KFactor);//Flow Meter Calibration{K-Factor}(P)

                }
                else if (pumpData.ControllerEquipmentId > 24 && pumpData.ControllerEquipmentId < 27)
                {
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].DosLine = pumpData.LineNumber;//Line Number(ME)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].PumpCalib = Convert.ToUInt16(pumpData.PumpCalibration);//Pump Calibration(P)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].FMMaxTime = Convert.ToUInt16(pumpData.MaximumDosingTime);//Max dosing Time
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].FSDelay = Convert.ToUInt16(pumpData.FlowSwitchTimeOut);//Flow switch timeout(ME)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].PreFlushTime = Convert.ToUInt16(pumpData.PreFlushTime);//Pre flush time(ME) only for ME Type Compactomix or Desamix / Examix
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].StNightFlush = Convert.ToUInt16(pumpData.NightFlushPauseTime);//Night flush pause time (ME)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].NightFlushTime = Convert.ToUInt16(pumpData.NightFlushTime); //Night flush time (ME)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].FlushPumpingtime = Convert.ToUInt16(pumpData.ControllerEquipmentTypeModelId == 12 ? pumpData.PumpingTime : pumpData.FlushTime); //Night flush time (ME)
                    objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].FMCalib = Convert.ToUInt16(pumpData.KFactor);//Flow Meter Calibration{K-Factor}(P)
                    if (pumpData.ControllerEquipmentTypeModelId == 12)
                    {
                        //1 = Desamix / Examix
                        objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].METype = 1;
                    }
                    else if (pumpData.ControllerEquipmentTypeModelId == 13)
                    {
                        //2 = Compactomix 
                        objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].METype = 2;
                    }
                    else if (pumpData.ControllerEquipmentTypeModelId == 14)
                    {
                        //3 = Stock Solution
                        objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].METype = 3;
                    }
                    else
                    {
                        //0 = Not used
                        objUints_Helms_ConfigCNAndHelms_2.uint_ME_Parameter[(pumpData.ControllerEquipmentId == 25 ? 0 : 1)].METype = 0;
                    }
                }
                tagsList.Add(new BeckhoffTag()
                {
                    Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2",
                    TagItemType = UIInputType.TypeObject,
                    ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName,
                    ComplexObject = objUints_Helms_ConfigCNAndHelms_2
                });

                //Flow meter / Flow switch activated (P+ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FMFSActive",
                    Value = pumpData.FlowmeterSwitchActivated.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });
                //Flush While Dosing(P + ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FlushWDos",
                    Value = pumpData.FlushWhileDosing.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });
                //Weight Controlled dosage (P+ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].WeightControl",
                    Value = pumpData.WeightControlledDosage.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });
                //Equipment dose alone (P+ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].PDosAlone",
                    Value = pumpData.EquipmentDoseAlone.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });
                //Low Level Alarm(P+ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].LLAlarm",
                    Value = pumpData.LowLevelAlarm.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });
                //Leakage alarm(P+ME)
                tagsList.Add(new BeckhoffTag
                {
                    Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].LeakAlarm",
                    Value = pumpData.LeakageAlarm.ToString(),
                    TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                });

                //Flow-meter or Flow-switch
                if (pumpData.FlowDetectorType == 0)
                {
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FMEnable",
                        Value = "false",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FSEnable",
                        Value = "false",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });

                }
                else if (pumpData.FlowDetectorType == 1)
                {
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FMEnable",
                        Value = "true",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FSEnable",
                        Value = "false",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });
                }
                else
                {
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FMEnable",
                        Value = "false",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });
                    tagsList.Add(new BeckhoffTag
                    {
                        Address = ".x_Equip_Parameter[" + pumpData.ControllerEquipmentId + "].FSEnable",
                        Value = "true",
                        TagItemType = Ecolab.Dcs.Entities.UIInputType.TypeBool
                    });
                }
            }
            return tagsList;
        }

        /// <summary>
        /// Builds the pumps tags PLCXL.
        /// </summary>
        /// <param name="pumpData">The pump data.</param>
        /// <param name="isReset">The Reset flag.</param>
        /// <param name="prevPumpData">The previous pump data.</param>
        /// <returns>List of Mitsubishi Tags</returns>
        private List<MitsubishiTag> BuildPumpsTagsPLCXL(PumpsModel pumpData, bool isReset, Ecolab.Models.ControllerSetup.Pumps.PumpsModel prevPumpData = null)
        {
            var tagsList = new List<MitsubishiTag>();
            int pumpMeType = 0;
            Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
            objPumpData.LineCompartmentMappings = GetLineData(objPumpData.LineNumber, objPumpData.ControllerId, objPumpData.ControllerEquipmentSetupId);

            //Pump Calibration (Time Volume Calibration)
            tagsList.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (100) + (objPumpData.WasherGroupNumber == 2 ? 45 : 0) + (objPumpData.ControllerEquipmentTypeId == 2 ? ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 13) :
                (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId))),
                TagItemType = UIInputType.TypeInt,
                Value = isReset ? "0" : Convert.ToInt32(objPumpData.PumpCalibration).ToString(),
                TagType = "PumpCalibration"
            });

            //Weight Controlled dosage 
            tagsList.Add(new MitsubishiTag()
            {
                Address = string.Format("L{0}", (360) + (objPumpData.WasherGroupNumber == 2 ? 14 : 0) + (objPumpData.ControllerEquipmentTypeId == 2 ? ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 13) :
                    (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId))),
                TagItemType = UIInputType.TypeBool,
                Value = isReset ? "0" : (objPumpData.WeightControlledDosage ? "1" : "0"),
                TagType = "WeightControlledDosage"
            });

            //Leakage alarm
            tagsList.Add(new MitsubishiTag()
            {
                Address = string.Format("L{0}", (569) + (objPumpData.WasherGroupNumber == 2 ? 14 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)),
                TagItemType = UIInputType.TypeBool,
                Value = isReset ? "0" : (objPumpData.LeakageAlarm ? "1" : "0")
                ,
                TagType = "LeakageAlarm"
            });
            if (prevPumpData != null)
            {
                if (prevPumpData.LineCompartmentMappings.Count() > 0)
                {
                    if (!prevPumpData.DirectDosingFlag)
                    {
                        foreach (LineCompartmentMappingModel item in prevPumpData.LineCompartmentMappings)
                        {
                            if (item.CompartmentNumber != 0 && item.ValveNumber != 0 && item.ControllerEquipmentId == objPumpData.ControllerEquipmentId)
                            {
                                tagsList.Add(new MitsubishiTag()
                                {
                                    Address = string.Format("R{0}", (200 + ((objPumpData.WasherGroupNumber == 2 && objPumpData.ControllerTypeId != 13) ? 50 : 0) + (objPumpData.ControllerEquipmentTypeId == 2 ? ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 1 : 19) : (25)) + item.ValveNumber)),
                                    TagItemType = UIInputType.TypeInt,
                                    Value = "0",
                                    TagType = "Reset CpmntNbrFor" + item.ValveNumber
                                });

                                tagsList.Add(new MitsubishiTag()
                                {
                                    Address = string.Format("R{0}", (200 + ((objPumpData.WasherGroupNumber == 2 && objPumpData.ControllerTypeId != 13) ? 50 : 0) + (35) + item.ValveNumber) - 2),
                                    TagItemType = UIInputType.TypeInt,
                                    Value = "0",
                                    TagType = "Reset PmpAllocateNbr" + item.ValveNumber
                                });
                            }
                        }
                    }
                }
            }
            //Compartment Nbr for V1-V8
            foreach (LineCompartmentMappingModel item in objPumpData.LineCompartmentMappings)
            {
                if (item.CompartmentNumber != 0 && item.ValveNumber != 0 && item.ControllerEquipmentId == objPumpData.ControllerEquipmentId)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((200) + ((objPumpData.WasherGroupNumber == 2 && objPumpData.ControllerTypeId != 13) ? 50 : 0) + (objPumpData.ControllerEquipmentTypeId == 2 ? ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 1 : 19) : (25)) + item.ValveNumber)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : item.CompartmentNumber.ToString(),
                        TagType = "CompartmentNbrFor" + item.ValveNumber
                    });

                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((200) + ((objPumpData.WasherGroupNumber == 2 && objPumpData.ControllerTypeId != 13) ? 50 : 0) + (35) + item.ValveNumber) - 2),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : (objPumpData.ControllerEquipmentTypeId == 1 ? (item.ControllerEquipmentId > 14 ? item.ControllerEquipmentId - 14 : item.ControllerEquipmentId).ToString() : "0"),
                        TagType = "PumpAllocateNbr" + item.ValveNumber
                    });

                }
            }

            if (objPumpData.ControllerEquipmentTypeId == 1)
            {
                //Flow Meter Calibration 15-Startindex
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (100) + (objPumpData.WasherGroupNumber == 2 ? 45 : 0) + (15) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) - 1),
                    TagItemType = UIInputType.TypeInt,
                    Value = isReset ? "0" : Convert.ToInt32(Convert.ToDecimal(objPumpData.KFactor)).ToString(),
                    TagType = "FlowMeterCalibrationKFactor"
                });

                //Maximum dosing time 
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (100) + (objPumpData.WasherGroupNumber == 2 ? 45 : 0) + (29) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) - 1),
                    TagItemType = UIInputType.TypeInt,
                    Value = isReset ? "0" : Convert.ToInt32(objPumpData.MaximumDosingTime).ToString(),
                    TagType = "MaximumDosingTime"
                });

                //Flow switch timeout
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (objPumpData.ControllerTypeId == 12 ? 31229 : (objPumpData.ControllerTypeId == 13 ? 25827 : 17709)) + (objPumpData.WasherGroupNumber == 2 ? 12 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)),
                    TagItemType = UIInputType.TypeInt,
                    Value = isReset ? "0" : (Convert.ToInt32(objPumpData.FlowSwitchTimeOut * 10).ToString()),
                    TagType = "FlowSwitchTimeout"
                });

                //FlowSwitchActivated // Flow Meter - 1 Flow Switch -2
                if (objPumpData.FlowDetectorType == 1)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 24 : 0) + (((objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) * 2) - 1)),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : (objPumpData.FlowmeterSwitchActivated ? "1" : "0"),
                        TagType = "FlowSwitchActivatedFlowMeter"
                    });
                    tagsList.Add(new MitsubishiTag()//reset
                    {
                        Address = string.Format("L{0}", (objPumpData.ControllerTypeId == 14 ? 736 : 532) + (objPumpData.WasherGroupNumber == 2 ? 12 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)),
                        TagItemType = UIInputType.TypeBool,
                        Value = "0",
                        TagType = "Reset FlowSwitchActivatedFlowSwitch"
                    });
                }
                else if (objPumpData.FlowDetectorType == 2)
                {
                    tagsList.Add(new MitsubishiTag()//reset
                    {
                        Address = string.Format("L{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 24 : 0) + (((objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) * 2) - 1)),
                        TagItemType = UIInputType.TypeBool,
                        Value = "0",
                        TagType = "Reset FlowSwitchActivatedFlowMeter"
                    });
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (objPumpData.ControllerTypeId == 14 ? 736 : 532) + (objPumpData.WasherGroupNumber == 2 ? 12 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : (objPumpData.FlowmeterSwitchActivated ? "1" : "0"),
                        TagType = "FlowSwitchActivatedFlowSwitch"
                    });
                }
                else
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 23 : 0) + (((objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) * 2) - 1)),
                        TagItemType = UIInputType.TypeBool,
                        Value = "0",
                        TagType = "Reset FlowSwitchActivatedFlowMeter"
                    });
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (objPumpData.ControllerTypeId == 14 ? 736 : 532) + (objPumpData.WasherGroupNumber == 2 ? 12 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)),
                        TagItemType = UIInputType.TypeBool,
                        Value = "0",
                        TagType = "Reset FlowSwitchActivatedFlowSwitch"
                    });
                }

                //Flush While Dosing
                if (objPumpData.FlushValveNumber != null)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (55) + (objPumpData.WasherGroupNumber == 2 ? 5 : 0) + (objPumpData.FlushValveNumber) - 1),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : (objPumpData.WeightControlledDosage ? "1" : "0"),
                        TagType = "FlushWhileDosing"
                    });
                }

                //Low Level Alarm / Alarm Messages
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("L{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 24 : 0) + (((objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) * 2))),
                    TagItemType = UIInputType.TypeBool,
                    Value = isReset ? "0" : (objPumpData.LowLevelAlarm ? "1" : "0"),
                    TagType = "LowLevelAlarm"
                });

                //Pump Used for ph-Control
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (242) + (objPumpData.WasherGroupNumber == 2 ? 50 : 0)),
                    TagItemType = UIInputType.TypeBool,
                    Value = isReset ? "0" : (objPumpData.pHSensorEnabled ? "1" : "0"),
                    TagType = "PumpUsedForph-Control"
                });
            }
            else
            {
                if (pumpData.ControllerEquipmentTypeModelId == 12)// ME Type
                {
                    pumpMeType = 1;//1 = Desamix / Examix
                                   //Pumping Time
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 23 : 24) - 1),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.PumpingTime.ToString(),
                        TagType = "PumpingTime"
                    });
                }
                else if (pumpData.ControllerEquipmentTypeModelId == 13)
                {
                    pumpMeType = 2;//2 = Compactomix
                                   //Flush Time
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 23 : 24) - 1),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.FlushTime.ToString(),
                        TagType = "FlushTime"
                    });
                }
                else if (pumpData.ControllerEquipmentTypeModelId == 14)
                {
                    pumpMeType = 3;//3 = Stock Solution
                                   //Concentration
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 15 : 16) - 1),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.Concentration.ToString(),
                        TagType = "Concentration"
                    });

                    //Maximum dosing time 
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (100) + (objPumpData.WasherGroupNumber == 2 ? 45 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 28 : 41)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : (objPumpData.FlowDetectorType == 1 ? objPumpData.MaximumDosingTime.ToString() : "0"),
                        TagType = "MaximumDosingTime"
                    });

                    //Flow meter activated
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (49) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 2)),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : ((objPumpData.FlowDetectorType == 1 && objPumpData.FlowmeterSwitchActivated) ? "1" : "0"),
                        TagType = "FlowSwitchActivatedFlowMeter"
                    });

                    //Flow-meter Calibration KFactor
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (100) + (objPumpData.WasherGroupNumber == 2 ? 45 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 14 : 27)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : Convert.ToInt32(Convert.ToDecimal(objPumpData.KFactor)).ToString(),
                        TagType = "FlowMeterCalibrationKFactor"
                    });

                    //Calibration Conduct SS-Tank
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (objPumpData.ControllerTypeId == 12 ? 658 : (objPumpData.ControllerTypeId == 13 ? 4095 : 1696)) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 1)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : Convert.ToInt32(objPumpData.CalibrationConductSS_Tank).ToString(),
                        TagType = "CalibrationConductSS-Tank"
                    });

                    //Backflow control(Not applicable for Dead End)
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (86) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 2)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : Convert.ToInt32(objPumpData.BackFlowControl).ToString(),
                        TagType = "BackFlowControl"
                    });

                    //Factor FM - B - FM(Not applicable for Dead End)
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (objPumpData.ControllerTypeId == 12 ? 660 : (objPumpData.ControllerTypeId == 13 ? 4500 : 492)) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 4)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : Convert.ToInt32(objPumpData.FactorFM_B_FM).ToString(),
                        TagType = "FactorFM-B-FM"
                    });

                    //Accepted Deviation on the ring line(Not applicable for Dead End)
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (objPumpData.ControllerTypeId == 12 ? 660 : (objPumpData.ControllerTypeId == 13 ? 4500 : 492)) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 2 : 6)),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : Convert.ToInt32(objPumpData.AcceptedDeviationRingLine).ToString(),
                        TagType = "AcceptedDeviationOnTheRingLine"
                    });

                    //DeadEnd
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", (765) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 2)),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : (objPumpData.StockSolutionDeadEnd ? "1" : "0"),
                        TagType = "StockSolutionDeadEnd"
                    });
                }
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 1 : 22) - 1),
                    TagItemType = UIInputType.TypeInt,
                    Value = isReset ? "0" : pumpMeType.ToString(),
                    TagType = "METype"
                });

                //Low Level Alarm / Alarm Messages
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("L{0}", (82) + (objPumpData.WasherGroupNumber == 2 ? 1 : 0) + ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 0 : 2)),
                    TagItemType = UIInputType.TypeBool,
                    Value = isReset ? "0" : (objPumpData.LowLevelAlarm ? "1" : "0"),
                    TagType = "LowLevelAlarm"
                });
            }
            //10 Washers
            if (objPumpData.ControllerTypeId == 12)
            {
                //Line Number
                // Not for Group1ME1 Group2ME1
                if (objPumpData.ControllerEquipmentId != 13 && objPumpData.ControllerEquipmentId != 27)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", (0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + (objPumpData.ControllerEquipmentTypeId == 2 ? 13 :

                        ((objPumpData.ControllerEquipmentId > 12 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.LineNumber.ToString(),
                        TagType = "LineNumber"
                    });
                }

                //Flush Valve Number
                if (objPumpData.ControllerEquipmentTypeId == 1 && objPumpData.FlushValveNumber != null)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((15) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.FlushValveNumber.ToString(),
                        TagType = "FlushValveNumber"
                    });
                }
            }
            else if (objPumpData.ControllerTypeId == 13)//1 Tunnel 5 Washers
            {
                //Compartment Number for Direct Dosing
                if (objPumpData.ControllerEquipmentTypeId == 1 && objPumpData.WasherGroupNumber == 2)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((200) + (objPumpData.ControllerEquipmentId - 14) + (8) - (1))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.DirectDosingTunnelCompartmentId.ToString(),
                        TagType = "CompartmentNumberForDirectDosing"
                    });
                }
                // Not for Group1ME1 Group2ME1
                //Line Number
                if (objPumpData.ControllerEquipmentId != 13 && objPumpData.ControllerEquipmentId != 27)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + (objPumpData.ControllerEquipmentId > 12 ? (objPumpData.ControllerEquipmentId - 14) : objPumpData.ControllerEquipmentId) + (objPumpData.ControllerEquipmentTypeId == 2 ? 13 : 0))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.LineNumber.ToString(),
                        TagType = "LineNumber"
                    });
                }
                //Use Pump of Group1 for Tunnel
                if (objPumpData.ControllerEquipmentTypeId == 1 && objPumpData.WasherGroupNumber == 2)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("L{0}", ((387) + (objPumpData.ControllerEquipmentId - 14))),
                        TagItemType = UIInputType.TypeBool,
                        Value = isReset ? "0" : (objPumpData.UsePumpOfGroup1ForTunnel ? "1" : "0"),
                        TagType = "UsePumpOfGroup1ForTunnel"
                    });
                }
                //Flush Valve Number
                if (objPumpData.ControllerEquipmentTypeId == 1 && objPumpData.FlushValveNumber != null)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((objPumpData.WasherGroupNumber == 2 ?
                        ((25) + (objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId)) :
                        ((15) + (objPumpData.FlushValveNumber))))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : (objPumpData.WasherGroupNumber == 2 ? objPumpData.FlushValveNumber.ToString() : objPumpData.LineNumber.ToString()),
                        TagType = "FlushValveNumber"
                    });
                }
            }
            else if (objPumpData.ControllerTypeId == 14)//2 Tunnels
            {
                //Compartment Number for Direct Dosing
                if (objPumpData.ControllerEquipmentTypeId == 1)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((200) + (objPumpData.WasherGroupNumber == 2 ? 50 : 0) + (objPumpData.ControllerEquipmentId > 12 ? (objPumpData.ControllerEquipmentId - 14) : objPumpData.ControllerEquipmentId) + (8) - (1))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.DirectDosingTunnelCompartmentId.ToString(),
                        TagType = "CompartmentNumberForDirectDosing"
                    });
                }
                //Flush Valve Number
                if (objPumpData.ControllerEquipmentTypeId == 1 && objPumpData.FlushValveNumber != null)
                {
                    tagsList.Add(new MitsubishiTag()
                    {
                        Address = string.Format("R{0}", ((0) + (objPumpData.WasherGroupNumber == 2 ? 25 : 0) + (objPumpData.ControllerEquipmentId > 14 ? (objPumpData.ControllerEquipmentId - 14) : objPumpData.ControllerEquipmentId))),
                        TagItemType = UIInputType.TypeInt,
                        Value = isReset ? "0" : objPumpData.FlushValveNumber.ToString(),
                        TagType = "FlushValveNumber"
                    });
                }
            }
            return tagsList;
        }

        /// <summary>
        /// Validates the and write conventional washer group connection fields.
        /// </summary>
        /// <param name="pumpData">The pump data.</param>
        /// <param name="plc">The PLC data of washer group connection fields.</param>
        private void ValidateAndWriteConventionalWasherGroupConnectionFields(PumpsModel pumpData, PlcTagController plc)
        {
            var tagsList = new List<MitsubishiTag>();
            Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPumpData = Mapper.Map<PumpsModel, Ecolab.Models.ControllerSetup.Pumps.PumpsModel>(pumpData);
            for (int i = 0; i < 5; i++)
            {
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (objPumpData.WasherGroupNumber == 1 ? 300 : 450) + (i * 30) +
                    (objPumpData.ControllerEquipmentTypeId == 2 ?
                    ((objPumpData.ControllerEquipmentId == 13 || objPumpData.ControllerEquipmentId == 27) ? 2 : 28) :

                    ((objPumpData.ControllerEquipmentId > 14 ? objPumpData.ControllerEquipmentId - 14 : objPumpData.ControllerEquipmentId) > 9 ?
                    ((objPumpData.ControllerEquipmentId > 14 ? ((objPumpData.ControllerEquipmentId - 14) + 15) : ((objPumpData.ControllerEquipmentId) + 15))) : ((objPumpData.ControllerEquipmentId > 14 ? ((objPumpData.ControllerEquipmentId - 14) + 2) : ((objPumpData.ControllerEquipmentId) + 2)))
                    ))),
                    TagItemType = UIInputType.TypeInt,
                    Value = "0"
                    ,
                    TagType = "ConventionalWasherGroupConnection" + i
                });
            }
            var plcTags = plc.ValidatePLCXLTags(tagsList, objPumpData.ControllerId, SourcePage.PumpsPage);
            foreach (var item in plcTags)
            {
                if (objPumpData.ConventionalWasherGroupConnection)
                {
                    item.Value = Convert.ToInt32(item.Value) > 0 ? item.Value : "100";
                }
                else
                {
                    item.Value = "0";
                }
            }
            plc.WritePLCXLTags(plcTags, objPumpData.ControllerId, SourcePage.PumpsPage);
        }
    }
}
