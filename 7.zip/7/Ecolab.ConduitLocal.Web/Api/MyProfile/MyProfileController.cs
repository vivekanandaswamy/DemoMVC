﻿// -----------------------------------------------------------------------
// <copyright file="MyProfileController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyProfile Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.MyProfile
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.ConduitLocal.Web.Mapper;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.UserManagement;
    using Models;
    using Models.PlantSetup.UserManagement;
    using Services.Interfaces;
    using Services.Interfaces.Home;

    /// <summary>
    ///     class MyProfileController
    /// </summary>
    public class MyProfileController : BaseApiController
    {
        /// <summary>
        ///     MyProfile Service
        /// </summary>
        private readonly IMyProfileService myProfileService;

        /// <summary>
        ///     Initializes a new instance of the MyProfileController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="myProfileService">myProfile Service</param>
        public MyProfileController(IUserService userService, IPlantService plantService, IMyProfileService myProfileService)
            : base(userService, plantService)
        {
            this.myProfileService = myProfileService;
        }

        /// <summary>
        ///     Gets User profile details
        /// </summary>
        /// <returns>Details of the user based on id</returns>
        [HttpGet]
        public UserProfileViewModel FetchMyProfileDetails()
        {
            this.myProfileService.FetchMyProfileDetails(this.UserId, this.EcolabAccountNumber);
            UserProfileViewModel objViewModel = new UserProfileViewModel { UserManagement = Mapper.Map<UserManagement, UserManagementModel>(this.myProfileService.FetchMyProfileDetails(this.UserId, this.EcolabAccountNumber)), Languages = Mapper.Map<List<LanguageMaster>, List<LanguageMasterModel>>(this.PlantService.GetLanguageDetails()) };
            List<CurrencyMaster> currencyCode = this.PlantService.GetCurrencyDetails();
            List<DimensionalUnitSystems> uoms = this.PlantService.GetDimensionalUnitSystems();
            objViewModel.CurrencyCodes = currencyCode.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            objViewModel.Uoms = uoms.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            return objViewModel;
        }

        /// <summary>
        ///     Method to update user profile
        /// </summary>
        /// <param name="objUserProfile">UserManagement Object</param>
        /// <returns>success or failure response string</returns>
        [HttpPost]
        public string SaveUserProfile(UserManagement objUserProfile)
        {
            objUserProfile.Title = objUserProfile.Title == string.Empty ? null : objUserProfile.Title;
            objUserProfile.UserNumber = this.UserId;
            string status = this.myProfileService.UpdateMyProfile(objUserProfile, this.EcolabAccountNumber);
            if (status == "201")
            {
                User user = null;
                System.Security.Principal.IPrincipal context = System.Web.HttpContext.Current.User;
                if (context != null && context.GetType() == typeof(Ecolab.Services.CustomPrincipal))
                {
                    Ecolab.Services.CustomPrincipal currentUser = (Ecolab.Services.CustomPrincipal)context;
                    {
                        user = new User
                        {
                            Id = currentUser.UserId,
                            UserId = currentUser.UserId,
                            Name = currentUser.UserName,
                            EcolabAccountNumber = currentUser.EcolabAccountNumber,
                            RegionId = currentUser.RegionId,
                            LanguageId = objUserProfile.LanguageId,
                            Locale = objUserProfile.Locale
                        };
                        System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(user.Locale);
                        System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(user.Locale);
                        string[] roleIds = currentUser.UserRoleIds.Split(',');
                        string[] rolesList = currentUser.UserRoles.Split(',');
                        List<Ecolab.Models.UserRoles> userRolesList = rolesList.Select((t, i) => new Ecolab.Models.UserRoles
                        {
                            Code = t,
                            RoleId = Convert.ToInt32(roleIds[i])
                        }).ToList();
                        user.Roles = userRolesList;
                    }
                    UserManagement objUserManagement = new UserManagement();
                    IUserManagementService userManagementService = new Ecolab.Services.UserManagementService();
                    objUserManagement = userManagementService.FetchUserManagementDetails(objUserProfile.UserNumber, this.GetPlantDetails().EcoalabAccountNumber).FirstOrDefault();
                    int statusid = Push.PushToQueue(objUserManagement, this.UserId, objUserManagement.UserNumber, (int)TcdAdminMessageTypes.TcdUpdateUserManagement, this.EcolabAccountNumber);
                }
            }
            return status;
        }

        /// <summary>
        ///     Method to update user password
        /// </summary>
        /// <param name="objUserProfile">UserManagement Object</param>
        /// <returns>User profile object</returns>
        [HttpPost]
        public UserProfileViewModel SavePassword(UserManagement objUserProfile)
        {
            objUserProfile.UserNumber = this.UserId;
            string result = this.myProfileService.UpdateUserPassword(objUserProfile, this.EcolabAccountNumber);
            UserProfileViewModel objViewModel = this.FetchMyProfileDetails();
            objViewModel.Result = result;
            return objViewModel;
        }
    }
}