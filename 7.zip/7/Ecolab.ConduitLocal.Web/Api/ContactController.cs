﻿// -----------------------------------------------------------------------
// <copyright file="ContactController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Contact Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.Common;
    using Elmah;
    using Mapper;
    using Models;
    using Models.PlantSetup;
    using Services.Interfaces;
    using ServiceModel = Ecolab.Models;

    /// <summary>
    ///     Class Contact Controller
    /// </summary>
    public class ContactController : BaseApiController
    {
        /// <summary>
        ///     Plant Contact Service
        /// </summary>
        private readonly IPlantContactService plantContService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ContactController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plantContService">User Management Service</param>
        public ContactController(IUserService userService, IPlantService plantService, IPlantContactService plantContService) : base(userService, plantService)
        {
            this.plantContService = plantContService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get the Contact list
        /// </summary>
        /// <returns>Returns the Contact list</returns>
        [HttpGet]
        public IEnumerable<PlantContactModel> GetContact()
        {
            List<ServiceModel.PlantContact> contact = this.plantContService.GetPlantContactDetails();
            List<PlantContactModel> contactList = contact.Select(EntityConverter.ConvertToWebModel).ToList();
            contactList = contactList.Where(item => item.IsDelete == false).ToList();
            return contactList.AsEnumerable();
        }

        /// <summary>
        ///     Gets UOM basing on Utility Type
        /// </summary>
        /// <returns>List of UOM</returns>
        [HttpGet]
        public IEnumerable<PlantContactPositionModel> FetchPlantContactPosition()
        {
            List<PlantContactPosition> plantContPositions = this.plantContService.FetchPlantContactPosition();
            List<PlantContactPositionModel> plantList = Mapper.Map<List<PlantContactPosition>, List<PlantContactPositionModel>>(plantContPositions);
            return plantList.AsEnumerable();
        }

        /// <summary>
        ///     creates new the Contact data
        /// </summary>
        /// <param name="data">Contact data to create</param>
        /// <returns>Returns created Contact data</returns>
        [HttpPost]
        public HttpResponseMessage CreateContact([FromBody]List< PlantContactModel> data)
        {
            int result = 0;
            try
            {
                if(data[0].Id == 0)
                {
                    data[0].Id = -1;
                }
                DateTime lastModifiedTimeStamp;
                data[0].ContactTitle = data[0].ContactTitle == string.Empty ? null : data[0].ContactTitle;
                ServiceModel.PlantContact objplantContact = EntityConverter.ConvertToServiceModel(data[0]);
                objplantContact.EcoalabAccountNumber = this.EcolabAccountNumber;
                objplantContact.MyServiceCntctGuid = Guid.NewGuid();
                result = this.plantContService.SavePlantContactDetails(objplantContact, this.UserId, out lastModifiedTimeStamp);
                objplantContact.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objplantContact.Id = result;

                switch(result)
                {
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }

                Push.PushToQueue(objplantContact, this.UserId, objplantContact.Id.Value, (int)TcdAdminMessageTypes.TcdAddPlantContact, this.EcolabAccountNumber);
            }
            catch(Exception ex)
            {
                this.Logger.Error("Api - Contact - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     To update the Contact details
        /// </summary>
        /// <param name="id">Contact id</param>
        /// <param name="data">Contact data to update</param>
        /// <returns>Returns updated Contact data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, PlantContactModel data)
        {
            if(id > 0)
            {
                try
                {
                    DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                    data.ContactTitle = data.ContactTitle == string.Empty ? null : data.ContactTitle;
                    ServiceModel.PlantContact objplantContact = EntityConverter.ConvertToServiceModel(data);
                    objplantContact.Id = this.plantContService.SavePlantContactDetails(objplantContact, this.UserId, out lastModifiedTimeStamp);
                    objplantContact.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(objplantContact, this.UserId, id.Value, (int)TcdAdminMessageTypes.TcdUpdatePlantContact, this.EcolabAccountNumber);
                }
                catch(Exception ex)
                {
                    this.Logger.Error("Api - Contact - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Contact details.");
        }

        /// <summary>
        ///     Updates the data
        /// </summary>
        /// <param name="data">The Contact related data</param>
        /// <returns>the saved data</returns>
        public HttpResponseMessage Put(List< PlantContactModel> data)
        {
            HttpResponseMessage status = new HttpResponseMessage();
            foreach (PlantContactModel plantContactModel in data)
            {
                status= this.Put(plantContactModel.Id, plantContactModel);
            }
            return status;
        }

        /// <summary>
        ///     Delete the Contact data
        /// </summary>
        /// <param name="id">Contact ID</param>
        /// <param name="data">delete contact data</param>
        /// <returns>the deleted data</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteContact(int? id, PlantContactModel data)
        {
            if(id > 0)
            {
                try
                {
                    DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                    ServiceModel.PlantContact objplantContact = EntityConverter.ConvertToServiceModel(data);
                    this.plantContService.DeletePlantContactDetails(objplantContact, this.UserId, out lastModifiedTimeStamp);
                    objplantContact.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    objplantContact.IsDelete = true;
                    Push.PushToQueue(objplantContact, this.UserId, id.Value, (int)TcdAdminMessageTypes.TcdDeletePlantContact, this.EcolabAccountNumber);
                }
                catch(Exception ex)
                {
                    this.Logger.Error("Api - Contact - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the Contact. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }

            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Contact details.");
        }

        /// <summary>
        ///     Delete Contact related data
        /// </summary>
        /// <param name="data">The data in contact</param>
        /// <returns>contact deleted data</returns>
        public HttpResponseMessage DeleteContact(List< PlantContactModel> data)
        {
            HttpResponseMessage status = new HttpResponseMessage();
            foreach (PlantContactModel plantContactModel in data)
            {
                status = this.DeleteContact(plantContactModel.Id, plantContactModel);
            }
            return status;
        }

        /// <summary>
        ///     Get the Contact list
        /// </summary>
        /// <param name="term">Part of First Name or Last Name</param>
        /// <returns>List of filtered Contact details</returns>
        [HttpGet]
        public IEnumerable<PlantContactModel> GetContactList(string term)
        {
            return Mapper.Map<IEnumerable<ServiceModel.PlantContact>, IEnumerable<PlantContactModel>>(this.plantContService.GetContactList(term, this.EcolabAccountNumber));
        }
    }
}