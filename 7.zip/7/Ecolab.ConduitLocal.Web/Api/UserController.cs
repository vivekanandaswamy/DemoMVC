﻿// -----------------------------------------------------------------------
// <copyright file="UserController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The UserController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Models;
    using Services.Interfaces;

    public class UserController : ApiController
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private readonly IUserService userService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="UserController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        public UserController(IUserService userService)
        {
            this.userService = userService;
        }
        /// <summary>
        /// Get user roles method
        /// </summary>
        /// <returns>Returns user roles</returns>
        public IEnumerable<UserRoles> Get()
        {
            List<Ecolab.Models.UserRoles> allRoles = this.userService.GetAllRoles();

            List<UserRoles> objAllRoles = Mapper.Map<List<Ecolab.Models.UserRoles>, List<UserRoles>>(allRoles);
            return objAllRoles.AsEnumerable();
        }
    }
}