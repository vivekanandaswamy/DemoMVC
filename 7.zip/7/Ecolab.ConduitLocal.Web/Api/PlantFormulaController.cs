﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Formula Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Data.SqlClient;
	using System.Net;
	using System.Net.Http;
	using System.Security.Principal;
    using System.Text.RegularExpressions;
    using System.Linq;
    using System.Web;
	using System.Web.Http;
	using System.Web.Mvc;
	using AutoMapper;
	using Castle.Core.Logging;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Elmah;
	using Models;
	using Services;
	using Services.Interfaces;
	using Utilities;
	using Model = Ecolab.Models;
	using WebModel = Models.PlantSetup;

	/// <summary>
	///     class Plant Chemical Controller
	/// </summary>
	public class PlantFormulaController : BaseApiController
	{
		/// <summary>
		///     Plant Customer Service
		/// </summary>
		private readonly IPlantCustomerService customerService;

		/// <summary>
		///     Plant Formula Service
		/// </summary>
		private readonly IProgramMasterService progMasterService;

		/// <summary>
		///     Initializes a new instance of the <see cref="PlantFormulaController" /> class.
		/// </summary>
		/// <param name="userService">The user service.</param>
		/// <param name="plantService">The Plant Service</param>
		/// <param name="progMasterService">The program Master Service.</param>
		/// <param name="customerService">The Customer Service</param>
		public PlantFormulaController(IUserService userService, IPlantService plantService, IProgramMasterService progMasterService, IPlantCustomerService customerService)
			: base(userService, plantService)
		{
			this.progMasterService = progMasterService;
			this.customerService = customerService;
		}

		/// <summary>
		///     Gets or sets the logger.
		/// </summary>
		/// <value>The logger.</value>
		public ILogger Logger { get; set; }

		/// <summary>
		/// Get the Formula list
		/// </summary>
		/// <param name="programId">The program identifier.</param>
		/// <returns>Returns the Formula list</returns>
		[System.Web.Http.HttpGet]
		public HttpResponseMessage GetFormula(int programId)
		{
			int regionId = this.GetCurrentUser().RegionId;
			List<Model.Formula> formulas = this.progMasterService.GetFormulaDetails(this.EcolabAccountNumber, 1, 12, programId);
			formulas = this.CalPieceWeight(formulas);
			List<FormulaModel> meterList = Mapper.Map<List<Model.Formula>, List<FormulaModel>>(formulas);
			//meterList = ConvertUnits(meterList, false);
			long total = meterList.Count > 0 ? meterList[0].TotalCount : 0;
			List<Model.PlantUtilityUnitTypes> units = this.progMasterService.GetFormulaUnits(this.EcolabAccountNumber, regionId);

			var result = new { Items = meterList, TotalCount = total, Units = units };

			return this.Request.CreateResponse(HttpStatusCode.OK, result);
		}

		/// <summary>
		///     Convert Units
		/// </summary>
		/// <param name="meterList">The meter list.</param>
		/// <param name="isEdit">isedit parameter.</param>
		/// <returns></returns>
		private List<FormulaModel> ConvertUnits(List<FormulaModel> meterList, bool isEdit)
		{
            var plantModel = GetPlantDetails();
            var userDetails = GetCurrentUser();
            meterList.ConvertUnit(plantModel.UOMId, plantModel.EcoalabAccountNumber, userDetails.UserId, isEdit, 0);
			return meterList;
		}

		/// <summary>
		/// Get the Formula list
		/// </summary>
		/// <param name="page">page parameter</param>
		/// <param name="pageSize">pageSize parameter</param>
		/// <param name="programId">The program identifier.</param>
		/// <returns>Returns the Formula list</returns>     
		[System.Web.Http.HttpGet]
		public List<FormulaModel> GetFormulaForPrint(int page, int pageSize, int programId)
		{
			List<Model.Formula> formulas = this.progMasterService.GetFormulaDetails(this.EcolabAccountNumber, page, pageSize, programId);
			PlantModel plantModel = this.GetPlantDetails();
			formulas.ForEach(cc => cc.PlantChainId = plantModel.PlantChainId);
			return Mapper.Map<List<Model.Formula>, List<FormulaModel>>(this.CalPieceWeight(formulas));
		}

        /// <summary>
        /// Gets the formula for drop down.
        /// </summary>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <returns>
        /// WebModel.FormulaViewModel.
        /// </returns>
        [System.Web.Http.HttpGet]
		public WebModel.FormulaViewModel GetFormulaForDropDown(int plantChainId)
		{
			int regionId = this.GetCurrentUser().RegionId;
			List<Model.EcolabTextileCategory> ecolabTextileCategory = this.progMasterService.GetEcolabTextileCategory(this.EcolabAccountNumber);
			List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(0);
			List<Model.PlantChainProgram> plantChainProgram = this.progMasterService.GetPlantChainProgramByChainId(plantChainId);
			List<Model.ChainTextileCategory> chainTextileCategory = this.progMasterService.GetChainTextileCategory(this.EcolabAccountNumber);
			List<Model.PlantCustomer> customer = this.customerService.GetPlantCustomer(this.EcolabAccountNumber);
			List<Model.PlantUtilityUnitTypes> units = this.progMasterService.GetFormulaUnits(this.EcolabAccountNumber, regionId);
			List<Model.FormulaSegment> formulaSegments = this.progMasterService.GetFormulaSegments();

			List<WebModel.EcolabTextileCategoryModel> utilityTypeList = Mapper.Map<List<Model.EcolabTextileCategory>, List<WebModel.EcolabTextileCategoryModel>>(ecolabTextileCategory);
			List<WebModel.EcolabSaturationModel> utilityLocationsList = Mapper.Map<List<Model.EcolabSaturation>, List<WebModel.EcolabSaturationModel>>(ecolabSaturation);
			List<PlantChainProgramModel> controllerList = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(plantChainProgram);
			List<WebModel.ChainTextileCategoryModel> parentList = Mapper.Map<List<Model.ChainTextileCategory>, List<WebModel.ChainTextileCategoryModel>>(chainTextileCategory);
			List<FormulaSegmentModel> formulaSegmentsmodel = Mapper.Map<List<Model.FormulaSegment>, List<FormulaSegmentModel>>(formulaSegments);
			List<Model.PlantUtilityUnitTypes> unitlist = Mapper.Map<List<Model.PlantUtilityUnitTypes>, List<Model.PlantUtilityUnitTypes>>(units);

			WebModel.FormulaViewModel formulaView = new WebModel.FormulaViewModel { EcolabTextileCategory = utilityTypeList, FormulaSegments = formulaSegmentsmodel, ecolabSaturation = utilityLocationsList, plantChainProgram = controllerList, chainTextileCategory = parentList, units = unitlist, CustomerList = customer };

			return formulaView;
		}

        /// <summary>
        /// To save the data
        /// </summary>
        /// <param name="programid">program identifier.</param>
        /// <param name="data">the data parameter</param>
        /// <returns>Returns updated customer data</returns>
        [System.Web.Http.HttpPut]
        public HttpResponseMessage Put(int programid, List<FormulaModel> data)
        {
            if (programid > 0)
            {
                try
                {
                    int response = 0;
                    IPrincipal user = HttpContext.Current.User;
                    int userId = ((CustomPrincipal)user).UserId;
                    string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;

                    foreach (var formula in data)
                    {
                        formula.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);

                        formula.EcolabAccountNumber = ecolabAccountNumber;
                        DateTime lastModifiedTimeStamp;

                        Model.Formula objformula = Mapper.Map<FormulaModel, Model.Formula>(formula);
                        response = this.progMasterService.SaveFormulaDetails(objformula, this.UserId, out lastModifiedTimeStamp);
                        objformula.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        switch (response)
                        {
                            case 303:
                                string errorMessage = "Formula Name already exists.";
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                            case 51030:
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                        }
                        if (objformula.ProgramId > 0)
                        {
                            List<Model.Formula> formulaList = new List<Model.Formula>();
                            formulaList = this.progMasterService.GetPlantFormulasForSync(objformula.ProgramId, ecolabAccountNumber);
                            formulaList.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                            if (formulaList != null && formulaList.Count > 0)
                            {
                                Push.PushToQueue(formulaList.FirstOrDefault(), userId, objformula.ProgramId, (int)TcdAdminMessageTypes.TcdUpdatePlantFormula, ecolabAccountNumber);
                            }
                        }
                    }
                }
                catch (SqlException ex)
                {
                    this.Logger.Error("Api - Formula - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    if (Regex.IsMatch(ex.Message, @"\d+"))
                    {
                        int errorCode = Int32.Parse(Regex.Replace(ex.Message, @"\D", string.Empty));
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
                    }
                }

                var result = new { Items = data, data[0].TotalCount };
                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid Formula details.");
        }

        /// <summary>
        /// Creates the formula.
        /// </summary>
        /// <param name="data">The data parameter.</param>
        /// <returns>HttpResponseMessage.</returns>
        [System.Web.Http.HttpPost]
        public HttpResponseMessage CreateFormula(FormulaModel data)
        {
            int result = 0;
            try
            {
                //data.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);
                IPrincipal user = HttpContext.Current.User;
                int userId = ((CustomPrincipal)user).UserId;
                string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;

                DateTime lastModifiedTimeStamp;
                Model.Formula objFormula = Mapper.Map<FormulaModel, Model.Formula>(data);
                objFormula.EcolabAccountNumber = this.EcolabAccountNumber;
                result = this.progMasterService.SaveFormulaDetails(objFormula, this.UserId, out lastModifiedTimeStamp);
                objFormula.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objFormula.ProgramId = result;
                data.ProgramId = result;

                switch (result)
                {
                    case 303:
                        string errorMessage = "Formula Name already exists.";
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                if (objFormula.ProgramId > 0)
                {
                    List<Model.Formula> formulaList = new List<Model.Formula>();
                    formulaList = this.progMasterService.GetPlantFormulasForSync(objFormula.ProgramId, ecolabAccountNumber);
                    formulaList.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                    if (formulaList != null && formulaList.Count > 0)
                    {
                        Push.PushToQueue(formulaList.FirstOrDefault(), userId, objFormula.ProgramId, (int)TcdAdminMessageTypes.TcdAddPlantFormula, ecolabAccountNumber);
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Meter - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                int errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

		/// <summary>
		/// To update the formula details
		/// </summary>
		/// <param name="data">formula data to update</param>
		/// <returns>Returns the updated data</returns>
		[System.Web.Http.HttpPost]
		public HttpResponseMessage Put(List<FormulaModel> data)
		{
			return this.Put(data[0].ProgramId, data);
		}

		/// <summary>
		/// Delete the Formula
		/// </summary>
		/// <param name="programId">The program id</param>
		/// <param name="lastmodifiedtime">The lastmodifiedtime.</param>
		/// <returns>Returns the status code</returns>
		[System.Web.Http.HttpGet]
		public HttpResponseMessage DeleteFormula(int programId, DateTime lastmodifiedtime)
		{
			Model.Formula objFormula = new Ecolab.Models.Formula();

			if (programId > 0)
			{
				try
				{
					IPrincipal user = HttpContext.Current.User;
					if (user != null)
					{
						int userId = ((CustomPrincipal)user).UserId;
						string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;
						objFormula.EcolabAccountNumber = ecolabAccountNumber;
						DateTime lastModifiedTimeStamp;
						this.progMasterService.DeleteFormulaDetails(programId, lastmodifiedtime, this.EcolabAccountNumber, userId, out lastModifiedTimeStamp);
						objFormula.ProgramId = programId;
						objFormula.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
						objFormula.IsDelete = true;
						if (objFormula.ProgramId > 0)
						{
							List<Model.Formula> formulaList = new List<Model.Formula>();
							formulaList = this.progMasterService.GetPlantFormulasForSync(objFormula.ProgramId, ecolabAccountNumber);
							formulaList.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
							if (formulaList != null && formulaList.Count > 0)
							{
								Push.PushToQueue(formulaList.FirstOrDefault(), this.UserId, objFormula.ProgramId, (int)TcdAdminMessageTypes.TcdDeletePlantFormula, this.EcolabAccountNumber);
							}
						}
					}
				}
				catch (Exception ex)
				{
					this.Logger.Error("Api - Formula - Delete Error :", ex);
					ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
					return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the Formula. Some error has occured. Please try again.");
				}

				return this.Request.CreateResponse(HttpStatusCode.OK, programId);
			}
			return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid Formula details.");
		}
        /// <summary>
        /// Get Categories method
        /// </summary>
        /// <returns>List of categories</returns>
		[System.Web.Http.HttpGet]
		public JsonResult GetCategories()
		{
			List<Model.EcolabTextileCategory> ecolabTextileCategory = this.progMasterService.GetEcolabTextileCategory(this.EcolabAccountNumber);
			List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(0);
			List<Model.PlantChainProgram> plantChainProgram = this.progMasterService.GetPlantChainProgram();
			List<Model.ChainTextileCategory> chainTextileCategory = this.progMasterService.GetChainTextileCategory(this.EcolabAccountNumber);
			List<Model.PlantCustomer> customerLists = this.customerService.GetPlantCustomer(this.EcolabAccountNumber);
			var result = new { TextileCategory = ecolabTextileCategory, Saturation = ecolabSaturation, ChainProgram = plantChainProgram, ChainTextileCategory = chainTextileCategory, CustomerList = customerLists };

			return new JsonResult { Data = result, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
		}
        /// <summary>
        /// Get Saturation Details
        /// </summary>
        /// <param name="textileId">the textile identifier</param>
        /// <returns>Ecolab Saturation details</returns>
		public List<Model.EcolabSaturation> GetSaturationDetails(int textileId)
		{
			List<Model.EcolabSaturation> ecolabSaturation = this.progMasterService.GetEcolabSaturation(textileId);
			return ecolabSaturation;
		}

		/// <summary>
		/// Gets the chain formula names.
		/// </summary>
		/// <param name="plantChainId">The plant chain identifier.</param>
		/// <returns>Chain Formual names</returns>
		public List<PlantChainProgramModel> GetChainFormulaNames(int plantChainId)
		{
			List<Model.PlantChainProgram> chainFormulas = this.progMasterService.GetChainFormulaNames(plantChainId);
			List<PlantChainProgramModel> chainFormulaNames = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(chainFormulas);
			return chainFormulaNames;
		}

		/// <summary>
		/// Gets the chain formula data.
		/// </summary>
		/// <param name="plantProgramId">The plant program identifier.</param>
		/// <returns>Chain formula data</returns>
		public List<PlantChainProgramModel> GetChainFormulaData(int plantProgramId)
		{
			List<Model.PlantChainProgram> chainFormulasData = this.progMasterService.GetChainFormulaData(plantProgramId);
			List<PlantChainProgramModel> chainFormulaData = Mapper.Map<List<Model.PlantChainProgram>, List<PlantChainProgramModel>>(chainFormulasData);
			return chainFormulaData;
		}

		#region privatemethods

		/// <summary>
		///     Caluculate Piece Weight
		/// </summary>
		/// <param name="formulas">The formulas</param>
		/// <returns>Returns the calculate value</returns>
		private List<Model.Formula> CalPieceWeight(List<Model.Formula> formulas)
		{
			foreach (Model.Formula item in formulas)
			{
				if (item.Weight.HasValue && item.Weight.Value != 0 && item.Pieces.HasValue && item.Pieces.Value != 0)
				{
					item.PieceWeight = Math.Round(item.Weight.Value / item.Pieces.Value, 2);
				}
				else
				{
					item.PieceWeight = 0;
				}
				item.PieceWeightAsString = item.PieceWeight.ToString("#,0.##");
			}

			return formulas;
		}
		#endregion
	}
}