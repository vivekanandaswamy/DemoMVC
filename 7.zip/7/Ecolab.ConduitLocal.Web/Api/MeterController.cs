﻿// -----------------------------------------------------------------------
// <copyright file="MeterController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Meter Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Models.PlantSetup;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using WebModel = Models.PlantSetup;
    using Utilities;
    using Ecolab.Models.Enum;

    /// <summary>
    /// Class Meter Controller
    /// </summary>
    /// <seealso cref="Ecolab.ConduitLocal.Web.Api.BaseApiController" />
    public class MeterController : BaseApiController
    {
        /// <summary>
        /// Meter Service
        /// </summary>
        private readonly IMeterService meterService;

        /// <summary>
        /// PLC Service
        /// </summary>
        private readonly IPlcService plcService;
        /// <summary>
        /// PLC Service
        /// </summary>
        private readonly IPlantUtilityService plantUtilityService;
        /// <summary>
        /// PLC Service
        /// </summary>
        private readonly IPlantService plantService;

        /// <summary>
        /// The _controller setup service
        /// </summary>
		private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        /// The washer group service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        /// The washer service
        /// </summary>
        private readonly IWasherServices washerService;

        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="meterService">The meter service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="plantUtilityService">The plant utility service</param>
        /// <param name="controllerSetupService">The controller setup service</param>
        /// <param name="washerGroupService">The washer group service.</param>
        /// <param name="washerService">The washer service.</param>
        public MeterController(IUserService userService, IMeterService meterService, IPlantService plantService, IPlcService plcService, IPlantUtilityService plantUtilityService, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IWasherServices washerService)
            : base(userService, plantService)
        {
            this.meterService = meterService;
            this.plcService = plcService;
            this.plantUtilityService = plantUtilityService;
            this.plantService = plantService;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.washerService = washerService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// Get the Meter details
        /// </summary>
        /// <returns>
        /// List of MeterModel
        /// </returns>
        [HttpGet]
        public IEnumerable<WebModel.MeterWebModel> GetMeter()
        {
            List<Meter> meters = this.meterService.GetPlantMeterDetails(null, EcolabAccountNumber);
            List<WebModel.MeterWebModel> meterList = Mapper.Map<List<Meter>, List<WebModel.MeterWebModel>>(meters);
            meterList.ForEach(_ => _.CalibrationAsString = _.Calibration.ToString("#,0.##"));
            meterList.ForEach(_ => _.MaxValueLimitAsString = _.MaxValueLimit.ToString("#,0.##"));
            return meterList.AsEnumerable();

        }

        /// <summary>
        /// Gets Meter Details on Add Clicked
        /// </summary>
        /// <returns>
        /// Dictionary of ResourceMasterModel, GroupTypeModel, ParentMeterModel, ConduitControllerModel
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GetMeterOnAdd()
        {
            List<ResourceMaster> utilityType = this.meterService.GetUtilitySetupDetails();
            List<WebModel.ResourceMasterModel> utilityTypeList = Mapper.Map<List<ResourceMaster>, List<WebModel.ResourceMasterModel>>(utilityType);

            List<GroupType> utilityLocations = this.meterService.GetMeterUtilityLocation(this.EcolabAccountNumber);
            List<WebModel.GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<WebModel.GroupTypeModel>>(utilityLocations);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(null, null, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            Ecolab.Models.Plant plantDetails = this.plantService.GetPlantDetails(this.EcolabAccountNumber);
            List<PlantUtilityWaterTypeMaster> waterTypes = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, plantDetails.RegionId);
            List<WebModel.PlantUtilityWaterTypeMasterModel> waterTypesList = Mapper.Map<List<PlantUtilityWaterTypeMaster>, List<WebModel.PlantUtilityWaterTypeMasterModel>>(waterTypes);
            var meterData = new Dictionary<string, object>
            {
                { "UtilityType", utilityTypeList },
                { "UtilityLocation", utilityLocationsList },
                { "Controller", controllerList },
                { "WaterType", waterTypesList }
            };
            return meterData;
        }

        /// <summary>
        /// Gets Meter Details on Edit Clicked
        /// </summary>
        /// <param name="id">Meter Id</param>
        /// <returns>
        /// Dictionary of selected MeterModel, ResourceMasterModel, GroupTypeModel, MachineSetupModel, ParentMeterModel,
        /// UOMMeterModel, ConduitControllerModel
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GetMeterOnEdit(int id)
        {
            Meter meterDetails = this.meterService.GetPlantMeterDetails(id, EcolabAccountNumber).FirstOrDefault();
            WebModel.MeterWebModel meter = Mapper.Map<Meter, WebModel.MeterWebModel>(meterDetails);

            List<Ecolab.Models.Washers.Washers> washerlist = this.washerService.GetWashersDetails(this.EcolabAccountNumber, meter.UtilityId.Value, false).ToList();
            meter.IsTunnel = washerlist.Where(x => x.WasherType.Contains("WasherExtractor")).Count() > 0 ? false : true;

            List<ResourceMaster> utilityType = this.meterService.GetUtilitySetupDetails();
            List<WebModel.ResourceMasterModel> utilityTypeList = Mapper.Map<List<ResourceMaster>, List<WebModel.ResourceMasterModel>>(utilityType);

            List<GroupType> utilityLocations = this.meterService.GetMeterUtilityLocation(this.EcolabAccountNumber);
            List<WebModel.GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<WebModel.GroupTypeModel>>(utilityLocations);

            List<MachineSetup> machineOrCompartment = this.meterService.GetPlantMachineDetails(meter.UtilityId, this.EcolabAccountNumber);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            int meterType = Convert.ToInt32(meter.MeterType);
            List<ParentMeter> parent = this.meterService.GetParentMeterDetails(meterType, id, this.EcolabAccountNumber);
            List<WebModel.ParentMeterModel> parentList = Mapper.Map<List<ParentMeter>, List<WebModel.ParentMeterModel>>(parent);

            List<UOMMeter> uom = this.meterService.GetUomMeterDetails(meterType);
            List<WebModel.UOMMeterModel> uomList = Mapper.Map<List<UOMMeter>, List<WebModel.UOMMeterModel>>(uom);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(meter.UtilityId, meter.MachineId, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            Ecolab.Models.Plant plantDetails = this.plantService.GetPlantDetails(this.EcolabAccountNumber);
            List<PlantUtilityWaterTypeMaster> waterTypes = this.plantUtilityService.GetPlantUtilityWaterFactorTypes(this.EcolabAccountNumber, plantDetails.RegionId);
            List<WebModel.PlantUtilityWaterTypeMasterModel> waterTypesList = Mapper.Map<List<PlantUtilityWaterTypeMaster>, List<WebModel.PlantUtilityWaterTypeMasterModel>>(waterTypes);
            var meterData = new Dictionary<string, object>
            {
                { "Meter", meter },
                { "UtilityType", utilityTypeList },
                { "UtilityLocation", utilityLocationsList },
                { "MachineCompartment", machineOrCompartmentList },
                { "Parent", parentList },
                { "UOM", uomList },
                { "Controller", controllerList },
                { "WaterType", waterTypesList },
                { "Counters", this.meterService.FetchCounters(meter.UtilityId, meter.MachineId, meter.MeterType,meter.MeterId, meter.IsTunnel, true, this.EcolabAccountNumber, meter.ControllerId) }
            };
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);

                if (meter.ControllerModelId == 11)
                {
                    if (meter.IsTunnel)
                    {
                        meter.LfsWasherNumber = washerlist.FirstOrDefault().lfsWasher;
                    }
                    else
                    {
                        if (meter.MachineId.HasValue)
                        {
                            IEnumerable<Ecolab.Models.Washers.Washers> washers = washerlist.Where(x => x.Id == meter.MachineId.Value);
                            meter.LfsWasherNumber = washers.Any() ? washers.FirstOrDefault().lfsWasher : 0;
                        }
                        else
                        {
                            meter.LfsWasherNumber = 0;
                        }
                    }

                    var ambigousTags = new List<Tag>();
                    var appTags = BuildPlcXlTagsForMeters(meter, meter.ControllerTypeId);//app Tags

                    if (appTags.Count > 0)
                    {
                        var plctagList = BuildPlcXlTagsForMeters(meter, meter.ControllerTypeId);//plc Tags
                        var plctags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(plctagList) }, meter.ControllerId, SourcePage.MetersPage);

                        foreach (var appTag in appTags)
                        {
                            foreach (var plcTag in plctags.Tags)
                            {
                                if (appTag.Address == plcTag.Address && appTag.Value != plcTag.Value)
                                {
                                    ambigousTags.Add(appTag);
                                }
                            }
                        }

                        foreach (var tag in ambigousTags)
                        {
                            meter.CalibrationOverride = ambigousTags.Where(x => x.TagType.ToUpper() == "KFACTOR").Count() > 0 ? true : false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Meter - Get Meter on Edit Error :", ex);
                return meterData;
            }

            return meterData;
        }

        /// <summary>
        /// Ges the on utility location change.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Returns the metadata of utility location
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GeOnUtilityLocationChange(int id)
        {
            int? locationId = id > 0 ? (int?)id : null;
            List<MachineSetup> machineOrCompartment = this.meterService.GetPlantMachineDetails(id, EcolabAccountNumber);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(locationId, null, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            var meterData = new Dictionary<string, object>
            {
                { "MachineCompartment", machineOrCompartmentList },
                { "Controller", controllerList }
            };
            return meterData;
        }

        /// <summary>
        /// Gets UOM basing on Utility Type
        /// </summary>
        /// <param name="utilityId">Utility Type Id</param>
        /// <param name="id">The meter Id</param>
        /// <returns>
        /// List of UOM
        /// </returns>
        [HttpGet]
        public Dictionary<string, object> GetUom(int utilityId, int? id)
        {
            List<ParentMeter> parent = this.meterService.GetParentMeterDetails(utilityId, id, this.EcolabAccountNumber);
            List<WebModel.ParentMeterModel> parentList = Mapper.Map<List<ParentMeter>, List<WebModel.ParentMeterModel>>(parent);
            List<UOMMeter> uom = meterService.GetUomMeterDetails(utilityId);
            List<WebModel.UOMMeterModel> uomList = Mapper.Map<List<UOMMeter>, List<WebModel.UOMMeterModel>>(uom);
            return new Dictionary<string, object> { { "Parent", parentList }, { "UOM", uomList } };
        }

        /// <summary>
        /// Gets data on machine Dropdown change
        /// </summary>
        /// <param name="locationId">The Location Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <returns>
        /// List of ConduitControllerModel
        /// </returns>
        [HttpGet]
        public List<WebModel.ConduitControllerModel> GetOnMachineCompartmentChange(int? locationId, int? machineId)
        {
            return
                Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(
                    meterService.GetPlantMeterControllerDetailsOnMachineChange(locationId, machineId, EcolabAccountNumber));
        }

        /// <summary>
        /// creates new the Meter data
        /// </summary>
        /// <param name="data">Meter data to create</param>
        /// <returns>
        /// Returns Success or failure response Messages
        /// </returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage CreateMeter([FromBody]List<WebModel.MeterWebModel> data)
        {
            Meter objMeter = new Meter();
            List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
            Models.Common.PLCDiscrepancyModel objPLCDiscrepancyModel = new Models.Common.PLCDiscrepancyModel();
            try
            {
                int controllerId;
                if (data[0].UtilityId == null && data[0].MachineId == null)
                {
                    data[0].ControllerId = -1;
                    data[0].ControllerModelId = 5;

                    List<ConduitController> controller = this.meterService.GetPlantMeterControllerDetailsOnMachineChange(null, null, this.EcolabAccountNumber);
                    IEnumerable<ConduitController> utilityLogger = controller.Where(_ => _.ControllerModelId == 5);
                    if (utilityLogger.Any())
                    {
                        controllerId = utilityLogger.FirstOrDefault().ControllerId;
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "701" });
                    }
                }
                else if (data[0].UtilityId != null && data[0].MachineId == null)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                }
                else if (data[0].UtilityId != null && data[0].ControllerId == 0 && data[0].AllowManualEntry == false)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                }
                else
                {
                    controllerId = data[0].ControllerId;
                }

                objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data[0]);
                objMeter.EcolabAccountNumber = this.EcolabAccountNumber;
                DateTime lastModifiedTimeStamp;
                string errorCode;
                MeterModel objMeterModel = new MeterModel();
                if (!string.IsNullOrEmpty(data[0].DigitalInputNumber) && controllerId > 0)
                {
                    try
                    {
                        string status = this.ValidateTag(data[0].DigitalInputNumber, controllerId);
                        if (status.Equals("801") || status.Equals("802"))
                        {
                            objMeter.DigitalInputNumber = String.Empty;
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Logger.Error("Api - Meter - create meter Error :", ex);
                    }

                }
                objMeter.MeterId = this.meterService.SavePlantMeterDetails(objMeter, this.UserId, out errorCode, out lastModifiedTimeStamp);

                List<Ecolab.Models.Washers.Washers> washerlist = this.washerService.GetWashersDetails(this.EcolabAccountNumber, data.First().UtilityId.GetValueOrDefault(), false).ToList();
                foreach (var item in washerlist)
                {
                    if (item.Id == data.First().MachineId)
                    {
                        data.First().LfsWasherNumber = item.lfsWasher;
                    }
                }

                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objMeter.ControllerId, this.EcolabAccountNumber);

                if (string.IsNullOrWhiteSpace(errorCode))
                {
                    if (objMeter.MeterId.Value > 0)
                    {
                        objMeterModel = this.meterService.GetPlantMeterDetailsByMeterId(objMeter.MeterId.Value, this.EcolabAccountNumber);
                        objMeterModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        Push.PushToQueue(objMeterModel, this.UserId, objMeterModel.MeterId.Value, (int)TcdAdminMessageTypes.TcdAddMeters, this.EcolabAccountNumber);

                        string error = string.Empty;
                        this.meterService.SavePlantMeterTags(objMeter, this.UserId, out error);
                        if (!string.IsNullOrEmpty(error))
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objMeter.MeterId });
                        }

                        ModuleTagsModel objModuleTags = this.meterService.GetModuleTagsDetails(objMeter.MeterId.Value, 2, this.EcolabAccountNumber);
                        if (objModuleTags != null)
                        {
                            objMeterModel.ModuleTagId = objModuleTags.ModuleTagId;
                            objMeterModel.TagType = objModuleTags.TagType;
                            if (objModuleTags.Active)
                            {
                                objMeterModel.TagAddress = objModuleTags.TagAddress;
                            }
                            else
                            {
                                objMeterModel.TagAddress = string.Empty;
                            }
                            objMeterModel.ModuleTypeId = objModuleTags.ModuleTypeId;
                            objMeterModel.ModuleId = objModuleTags.ModuleId;
                            objMeterModel.DeadBand = objModuleTags.DeadBand;
                            objMeterModel.Active = objModuleTags.Active;
                        }

                        Push.PushToQueue(objMeterModel, this.UserId, objMeterModel.MeterId.Value, (int)TcdAdminMessageTypes.TcdUpdateMeters, this.EcolabAccountNumber);

                        try
                        {
                            WebModel.MeterWebModel meterWebModel = Mapper.Map<MeterModel, WebModel.MeterWebModel>(objMeterModel);
                            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                            objPLCDiscrepancyModel = new Models.Common.PLCDiscrepancyModel()
                            {
                                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Meters),
                                ParentEntityId = Convert.ToInt32(meterWebModel.MeterId),
                                Entity = Convert.ToInt32(PlcDiscrepancyEntity.Meters),
                                EntityId = Convert.ToInt32(meterWebModel.MeterId),
                                IsCentral = false,
                                ControllerId = controllerDetails.ControllerId,
                                UserId = this.UserId,
                                LastModifiedUserId = this.UserId
                            };
                            if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                            {
                                plc.WriteMyControlSettingsForMeters(meterWebModel, objMeter.ControllerId, false);
                                objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                            }
                            else if (controllerDetails.ControllerModelId == 11)
                            {
                                var tags = BuildPlcXlTagsForMeters(meterWebModel, controllerDetails.ControllerTypeId);

                                if (tags.Count > 0)
                                {
                                    plc.WriteTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerDetails.ControllerId, SourcePage.MetersPage);
                                }
                                objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                            }
                        }
                        catch (Exception ex)
                        {
                            this.Logger.Error("Api - Meter - Plc Discrepancy error :", ex);
                            if (ex.Message.Contains("Timeout has elapsed") ||
                                ex.Message.Contains("Port is disabled") ||
                                ex.Message.Contains("Target machine could not be found") ||
                                ex.Message.Contains("ADS could not be initialized") ||
                                ex.Message.Contains("Open Failed") ||
                                ex.Message.Contains("Retrieving the COM class factory"))
                            {
                                objPLCDiscrepancyModel.IsPLCError = true;
                                objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "901", source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                            }
                            else
                            {
                                objPLCDiscrepancyModel.IsPLCError = true;
                                objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "902", source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                            }
                        }
                    }
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode + "#" + objMeter.MeterId });
                }

                if (RoleId >= 8)
                {
                    if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                    {
                        if (!string.IsNullOrEmpty(data[0].DigitalInputNumber) && controllerId > 0)
                        {
                            string status = this.ValidateTag(data[0].DigitalInputNumber, controllerId);
                            if (!string.IsNullOrWhiteSpace(status))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = status + "#" + objMeter.MeterId });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Meter - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string result = ex.Message + "#" + objMeter.MeterId;
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = result });
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, new { message = data, source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
        }

        /// <summary>
        /// To update the Meter details
        /// </summary>
        /// <param name="id">The Meter id</param>
        /// <param name="data">Meter data to update</param>
        /// <returns>
        /// Returns Success or failure response Messages
        /// </returns>
        [HttpPut]

        public HttpResponseMessage Put(int? id, WebModel.MeterWebModel data)
        {
            List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
            Models.Common.PLCDiscrepancyModel objPLCDiscrepancyModel = new Models.Common.PLCDiscrepancyModel();
            if (id > 0)
            {
                try
                {
                    if (data.UtilityId == null && data.MachineId == null && data.ControllerModelId != 5)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "601" });
                    }

                    if (data.UtilityId != null && data.MachineId == null)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "501" });
                    }
                    if (data.UtilityId != null && data.ControllerId == 0 && data.AllowManualEntry == false)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "401" });
                    }

                    MeterModel objMeterModelDetails = this.meterService.GetPlantMeterDetailsByMeterId(id.Value, this.EcolabAccountNumber);

                    Meter objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data);
                    objMeter.EcolabAccountNumber = this.EcolabAccountNumber;
                    DateTime lastModifiedTimeStamp;
                    string errorCode;
                    MeterModel objMeterModel = new MeterModel();
                    if (!string.IsNullOrEmpty(data.DigitalInputNumber) && objMeterModelDetails.DigitalInputNumber.Value.ToString() != data.DigitalInputNumber && data.ControllerId > 0)
                    {
                        try
                        {
                            string status = this.ValidateTag(data.DigitalInputNumber, data.ControllerId);
                            if (status.Equals("801") || status.Equals("802"))
                            {
                                objMeter.DigitalInputNumber = String.Empty;
                            }
                        }
                        catch (Exception ex)
                        {
                            this.Logger.Error("Api - Meter - Meter Put Error :", ex);
                        }
                    }

                    objMeter.MeterId = this.meterService.SavePlantMeterDetails(objMeter, this.UserId, out errorCode, out lastModifiedTimeStamp);

                    Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objMeter.ControllerId, this.EcolabAccountNumber);

                    if (string.IsNullOrWhiteSpace(errorCode))
                    {
                        if (objMeter.MeterId.Value > 0)
                        {
                            objMeterModel = this.meterService.GetPlantMeterDetailsByMeterId(objMeter.MeterId.Value, this.EcolabAccountNumber);
                            objMeterModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objMeterModel, this.UserId, objMeterModel.MeterId.Value, (int)TcdAdminMessageTypes.TcdUpdateMeters, this.EcolabAccountNumber);

                            string error = string.Empty;
                            this.meterService.UpdatePlantMeterTags(objMeter, this.UserId, out error);
                            if (!string.IsNullOrEmpty(error))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error });
                            }
                            ModuleTagsModel objModuleTags = this.meterService.GetModuleTagsDetails(objMeter.MeterId.Value, 2, this.EcolabAccountNumber);
                            objMeterModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

                            if (objModuleTags != null)
                            {
                                objMeterModel.ModuleTagId = objModuleTags.ModuleTagId;
                                objMeterModel.TagType = objModuleTags.TagType;
                                if (objModuleTags.Active)
                                {
                                    objMeterModel.TagAddress = objModuleTags.TagAddress;
                                }
                                else
                                {
                                    objMeterModel.TagAddress = string.Empty;
                                }
                                objMeterModel.ModuleTypeId = objModuleTags.ModuleTypeId;
                                objMeterModel.ModuleId = objModuleTags.ModuleId;
                                objMeterModel.DeadBand = objModuleTags.DeadBand;
                                objMeterModel.Active = objModuleTags.Active;
                            }

                            Push.PushToQueue(objMeterModel, this.UserId, objMeterModel.MeterId.Value, (int)TcdAdminMessageTypes.TcdUpdateMeters, this.EcolabAccountNumber);

                            try
                            {
                                WebModel.MeterWebModel meterWebModelDetails = Mapper.Map<MeterModel, WebModel.MeterWebModel>(objMeterModelDetails);
                                WebModel.MeterWebModel meterWebModel = Mapper.Map<MeterModel, WebModel.MeterWebModel>(objMeterModel);

                                objPLCDiscrepancyModel = new Models.Common.PLCDiscrepancyModel
                                {
                                    ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Meters),
                                    ParentEntityId = Convert.ToInt32(meterWebModel.MeterId),
                                    Entity = Convert.ToInt32(PlcDiscrepancyEntity.Meters),
                                    EntityId = Convert.ToInt32(meterWebModel.MeterId),
                                    IsCentral = false,
                                    ControllerId = controllerDetails.ControllerId,
                                    UserId = this.UserId,
                                    LastModifiedUserId = this.UserId
                                };
                                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                                if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                                {
                                    plc.WriteMyControlSettingsForMeters(meterWebModelDetails, objMeter.ControllerId, true);
                                    plc.WriteMyControlSettingsForMeters(meterWebModel, objMeter.ControllerId, false);
                                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                }
                                else if (controllerDetails.ControllerModelId == 11)
                                {
                                    var tags = BuildPlcXlTagsForMeters(meterWebModel, controllerDetails.ControllerTypeId);

                                    if (tags.Count > 0)
                                    {
                                        plc.WriteTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerDetails.ControllerId, SourcePage.MetersPage);
                                    }
                                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                }
                            }
                            catch (Exception ex)
                            {
                                this.Logger.Error("Api - Meter - Plc Discrepancy Error :", ex);
                                if (ex.Message.Contains("Timeout has elapsed") ||
                                    ex.Message.Contains("Port is disabled") ||
                                    ex.Message.Contains("Target machine could not be found") ||
                                    ex.Message.Contains("ADS could not be initialized") ||
                                    ex.Message.Contains("Open Failed") ||
                                    ex.Message.Contains("Retrieving the COM class factory"))
                                {
                                    objPLCDiscrepancyModel.IsPLCError = true;
                                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "901", source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                                }
                                else
                                {
                                    objPLCDiscrepancyModel.IsPLCError = true;
                                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "902", source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                                }
                            }
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode, source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                    }

                    if (this.RoleId >= 8)
                    {
                        if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                        {
                            if (!string.IsNullOrEmpty(data.DigitalInputNumber) && objMeterModelDetails.DigitalInputNumber.Value.ToString() != data.DigitalInputNumber && data.ControllerId > 0)
                            {
                                string status = this.ValidateTag(data.DigitalInputNumber, data.ControllerId);
                                if (!string.IsNullOrWhiteSpace(status))
                                {
                                    objPLCDiscrepancyModel.IsPLCError = true;
                                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = status });
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Meter - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message });
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, new { message = data, source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "Save failed. Invalid meter details." });
        }

        /// <summary>
        /// To update the meter details
        /// </summary>
        /// <param name="data">Meter data to update</param>
        /// <returns>Returns Success or failure response Messages</returns>
        [PLCDiscrepancyCheck]
        public HttpResponseMessage Put(List<WebModel.MeterWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.MeterWebModel MeterWebModel in data)
            {
                HttpResponseMessage = this.Put(MeterWebModel.MeterId, MeterWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        /// To delete the Meter
        /// </summary>
        /// <param name="id">Delete Meter based on ID</param>
        /// <param name="data">The Meter Model Data</param>
        /// <returns>
        /// Returns Success or failure response Messages
        /// </returns>
        [HttpDelete]
        public HttpResponseMessage DeleteMeter(int? id, WebModel.MeterWebModel data)
        {
            if (id > 0)
            {
                Meter objMeter = Mapper.Map<WebModel.MeterWebModel, Meter>(data);
                try
                {
                    IPrincipal user = HttpContext.Current.User;
                    if (user != null)
                    {
                        int userId = ((CustomPrincipal)user).UserId;
                        DateTime lastModifiedTimeStamp;
                        int error;
                        int response = this.meterService.DeletePlantMeterDetails(objMeter, userId, out error, out lastModifiedTimeStamp);

                        if (error <= 0)
                        {
                            if (response > 0 && objMeter.MeterId.Value > 0)
                            {
                                MeterModel objMeterModel = this.meterService.GetPlantMeterDetailsByMeterId(objMeter.MeterId.Value, this.EcolabAccountNumber);
                                ModuleTagsModel objModuleTags = this.meterService.GetModuleTagsDetails(objMeter.MeterId.Value, 2, this.EcolabAccountNumber);
                                objMeterModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

                                if (objModuleTags != null)
                                {
                                    objMeterModel.ModuleTagId = objModuleTags.ModuleTagId;
                                    objMeterModel.TagType = objModuleTags.TagType;
                                    if (objModuleTags.Active)
                                    {
                                        objMeterModel.TagAddress = objModuleTags.TagAddress;
                                    }
                                    else
                                    {
                                        objMeterModel.TagAddress = string.Empty;
                                    }
                                    objMeterModel.ModuleTypeId = objModuleTags.ModuleTypeId;
                                    objMeterModel.ModuleId = objModuleTags.ModuleId;
                                    objMeterModel.DeadBand = objModuleTags.DeadBand;
                                    objMeterModel.Active = objModuleTags.Active;
                                }

                                Push.PushToQueue(objMeterModel, this.UserId, objMeterModel.MeterId.Value, (int)TcdAdminMessageTypes.TcdDeleteMeters, this.EcolabAccountNumber);

                                try
                                {
                                    Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objMeter.ControllerId, this.EcolabAccountNumber);

                                    WebModel.MeterWebModel meterWebModel = Mapper.Map<MeterModel, WebModel.MeterWebModel>(objMeterModel);
                                    var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                                    if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                                    {
                                        plc.WriteMyControlSettingsForMeters(meterWebModel, objMeter.ControllerId, true);
                                    }
                                    else if (controllerDetails.ControllerModelId == 11)
                                    {

                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                                    return this.Request.CreateResponse(HttpStatusCode.OK);
                                }
                            }
                        }
                        else
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, id);
        }

        /// <summary>
        /// Delete Meter
        /// </summary>
        /// <param name="data">data parameter</param>
        /// <returns>
        /// HttpResponseMessage
        /// </returns>
        public HttpResponseMessage DeleteMeter(List<WebModel.MeterWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.MeterWebModel MeterWebModel in data)
            {
                HttpResponseMessage = this.DeleteMeter(MeterWebModel.MeterId, MeterWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        /// Validate PLC Tags
        /// </summary>
        /// <param name="tag">Tag address</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>Status Exception Code</returns>
        private string ValidateTag(string tag, int controllerId)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag> { new OpcTag { Address = tag } } }, controllerId);
            return tagStatus.Tags.FirstOrDefault().IsValid && tagStatus.Tags[0].Quality == "Good" ? string.Empty : "801";
        }

        /// <summary>
        /// Fetches the external or internal counter
        /// </summary>
        /// <param name="locationId">The locationId</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="utilityTypeId">Utility Type Id</param>
        /// <param name="meterId">meter Id</param>
        /// <param name="isTunnel">Is Tunnel</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>Returns Dictionary.</returns>
        [HttpGet]
        public Dictionary<string, string> FetchCounters(int? locationId, int? washerId, string utilityTypeId, int? meterId, bool isTunnel, int? controllerId)
        {
            return this.meterService.FetchCounters(locationId, washerId, utilityTypeId,meterId, isTunnel, true, this.EcolabAccountNumber, controllerId);
        }

        /// <summary>
        /// Builds the PLC xl tags for meters.
        /// </summary>
        /// <param name="meter">The meter Tags.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>Returns List of Tags</returns>
        private List<Tag> BuildPlcXlTagsForMeters(Ecolab.ConduitLocal.Web.Models.PlantSetup.MeterWebModel meter, int controllerTypeId)
        {
            List<Tag> tags = new List<Tag>();

            if (meter.LfsWasherNumber != 0)
            {
                int kFactorWEIndex = (controllerTypeId == 12 || controllerTypeId == 13 ? 324 : 0) + ((meter.LfsWasherNumber - 1) * 30);
                int kFactorTUNIndex = ((controllerTypeId == 14 || controllerTypeId == 13) ? 249 : 0) + ((meter.LfsWasherNumber - 1) * 50);

                tags.Add(new MitsubishiTag
                {
                    Address = string.Format("R{0}", (meter.IsTunnel == true ? kFactorTUNIndex : kFactorWEIndex)),
                    Value = Convert.ToUInt32(meter.Calibration).ToString(),
                    TagType = "KFACTOR"
                });
            }

            return tags;
        }
    }
}