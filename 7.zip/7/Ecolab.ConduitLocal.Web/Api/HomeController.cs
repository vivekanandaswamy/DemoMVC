﻿// -----------------------------------------------------------------------
// <copyright file="HomeController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Home Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System.Collections.Generic;
    using System.Web.Http;
    using AutoMapper;
    using Services.Interfaces;
    using Services.Interfaces.Visualization;
    using Model = Ecolab.Models.Visualization;
    using WebModel = Models.Visualization;

    /// <summary>
    ///     class HomeController
    /// </summary>
    public class HomeController : BaseApiController
    {
        /// <summary>
        ///     Dashboard Service
        /// </summary>
        private readonly IDashboardService dashboardService;

        /// <summary>
        ///     Initializes a new instance of the<see cref="HomeController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="dashboardService">dashboard Service</param>
        public HomeController(IUserService userService, IPlantService plantService, IDashboardService dashboardService) : base(userService, plantService)
        {
            this.dashboardService = dashboardService;
        }

        /// <summary>
        ///     Gets Dashboards mapped to home screen
        /// </summary>
        /// <returns>Returns list of dashboards</returns>
        [HttpGet]
        public List<WebModel.DashboardsForHome> FetchDashboardsForHome()
        {
            return Mapper.Map<List<Model.DashboardsForHome>, List<WebModel.DashboardsForHome>>(this.dashboardService.FetchDashboardsForHome());
        }
    }
}