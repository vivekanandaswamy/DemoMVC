﻿// -----------------------------------------------------------------------
// <copyright file="VisualizationController.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Visualization Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Ecolab.Models.Visualization;
    using Ecolab.Models.Visualization.ConventionalWasher;
    using Models.Visualization;
    using Models.Visualization.ConventionalWasher;
    using Services.Interfaces;
    using Services.Interfaces.Visualization;
    using Services.Interfaces.Visualization.ConventionalWasher;
    using Services.SyncConfigSettingService;
    using Utilities;
    using WebModel = Models;

    /// <summary>
    ///     VisualizationController Class
    /// </summary>
    public class VisualizationController : BaseApiController
    {
        /// <summary>
        ///     IConventionalWasher Dashboard Service
        /// </summary>
        private readonly IConventionalWasherDashboardService conventionalWasherDashboardService;

        /// <summary>
        ///     Visualization Dasboard Service
        /// </summary>
        private readonly IDashboardService dashboardService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="VisualizationController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="dashboardService">The dashboard service.</param>
        /// <param name="conventionalWasherDashboardService">The conventional washer dashboard service.</param>
        public VisualizationController(IUserService userService, IPlantService plantService, IDashboardService dashboardService, IConventionalWasherDashboardService conventionalWasherDashboardService)
            : base(userService, plantService)
        {
            this.dashboardService = dashboardService;
            this.conventionalWasherDashboardService = conventionalWasherDashboardService;
        }

        /// <summary>
        ///     Get the visualization Data based on the dahboardId
        /// </summary>
        /// <param name="id">dashboard Id</param>
        /// <returns>VisualizationViewModel</returns>
        public VisualizationViewModel GetVisualizationData(int id)
        {
            List<Compartment> compartmentDetails = this.dashboardService.FetchCompartmentData(id, this.EcolabAccountNumber);
            List<CompartmentModel> compartmentModelList = Mapper.Map<List<Compartment>, List<CompartmentModel>>(compartmentDetails);

            foreach (CompartmentModel compartmentModel in compartmentModelList)
            {
                compartmentModel.WeightColor = this.FetchFontColor((compartmentModel.WeightLoaded / compartmentModel.WeightExpected) * 100);
                compartmentModel.CustomerId = compartmentModel.CustomerId.Length > 4 ? compartmentModel.CustomerId.Substring(0, 4) : compartmentModel.CustomerId;
            }
            
            List<Tunnel> tunnelDetails = this.dashboardService.FetchTunnelData(id, this.EcolabAccountNumber);
            List<TunnelModel> tunnelModelList = Mapper.Map<List<Tunnel>, List<TunnelModel>>(tunnelDetails);

            VisualizationViewModel visualizationViewModel = new VisualizationViewModel();
            var tunnels = new List<TunnelViewModel>();            

            //List<int> standerdTransferRate = this.dashboardService.GetStanderdTransferRate(this.EcolabAccountNumber);

            foreach (TunnelModel tunnelModel in tunnelModelList)
            {
                List<CompartmentModel> compartments = compartmentModelList.Where(_ => _.GroupId == tunnelModel.TunnelId).ToList();
                TunnelViewModel tunnelViewModel = new TunnelViewModel();
                TunnelModel tunnel = Mapper.Map<TunnelModel, TunnelModel>(tunnelModel);
                tunnel.Compartments = compartments;

                int standerdTransferRate = this.dashboardService.GetStanderdTransferRate(this.EcolabAccountNumber, tunnelModel.WasherNumber, tunnelModel.TunnelId);

                tunnelViewModel.Tunnel = tunnel;
                tunnelViewModel.Tunnel.ActualWeight = tunnel.ActualLoad.ToString("#,0.##");
                tunnelViewModel.Tunnel.NominalLoad = tunnel.NominalLoad;
                tunnelViewModel.Tunnel.ActualLoad = tunnel.ActualLoad;
                tunnelViewModel.LostWeightInBatches = tunnel.LostWeightInBatches;
                if (GetPlantDetails().UOMId == 2)
                {
                    tunnelViewModel.Tunnel.ActualLoadDecimal = (decimal)tunnel.ActualLoad;
                    tunnelViewModel.Tunnel.ActualLoadConverted = (decimal)tunnel.ActualLoad;
                    tunnelViewModel.Tunnel.IsPLCConnected = tunnel.IsPLCConnected;
                    if (GetPlantDetails() != null && GetCurrentUser() != null)
                    {
                        tunnelViewModel.Tunnel.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    }
                   // tunnelViewModel.Tunnel.ActualWeight = tunnel.ActualLoadConverted.ToString("#,0.##");
                }

                double weightEfficiency = (tunnel.ActualLoad / tunnel.NominalLoad) * 100;
                tunnelViewModel.WeightLevel = this.FetchPercent(weightEfficiency);
                tunnelViewModel.WeightColor = this.FetchColor(weightEfficiency);
                //tunnelViewModel.TransferLevel = this.FetchPercent(tunnel.TransferPercent);
                tunnelViewModel.TransferLevel = Convert.ToString(standerdTransferRate);
                tunnelViewModel.TransferColor = this.FetchColor(tunnel.TransferPercent);
                tunnelViewModel.TransferRateColor = this.GetTransferRateColor(tunnel.TransferRate, standerdTransferRate);

                tunnels.Add(tunnelViewModel);
            }
            visualizationViewModel.TotalWeightDecimal = Convert.ToDecimal(tunnelDetails.Sum(_ => _.ActualLoad));
            visualizationViewModel.LostWeightDecimal = Convert.ToDecimal(tunnelDetails.Sum(_ => _.LostWeight));
            visualizationViewModel.TotalWeightConverted = visualizationViewModel.TotalWeightDecimal;
            visualizationViewModel.LostWeightConverted = visualizationViewModel.LostWeightDecimal;
            if (GetPlantDetails() != null && GetCurrentUser() != null)
            {
                 WebModel.PlantModel PlantModel =GetPlantDetails();
                //visualizationViewModel.ConvertUnit(PlantModel.UOMId, PlantModel.EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);

                Ecolab.ConduitLocal.Web.Controllers.LocaleController LocaleController = new Ecolab.ConduitLocal.Web.Controllers.LocaleController(this.UserService, this.PlantService);
                visualizationViewModel.UOM = LocaleController.LocalizeUom("Weight_CommonUse", "LBS");
                if (this.GetPlantDetails().RegionId == 2)
                {
                    visualizationViewModel.UOM = "KGS";
            }
                if (this.GetPlantDetails().RegionId == 1)
                {
                    visualizationViewModel.UOMId = 1;
                }
                else
                {
                    visualizationViewModel.UOMId = 2;
                }
            }
			visualizationViewModel.TotalWeight = Math.Round(visualizationViewModel.TotalWeightConverted).ToString("#,0.##");
			visualizationViewModel.LostWeight = Math.Round(visualizationViewModel.LostWeightConverted).ToString("#,0.##");
			visualizationViewModel.PlantLogo = this.Logo;
			
            if (tunnelDetails.Any())
            {
                visualizationViewModel.Efficiency = tunnelDetails.FirstOrDefault().AverageEfficiency;
            }

            visualizationViewModel.EfficiencyLevel = this.FetchPercent(visualizationViewModel.Efficiency);
            visualizationViewModel.EfficiencyColor = this.FetchColor(visualizationViewModel.Efficiency);
            double loadEfficiency = (tunnelDetails.Sum(_ => _.ActualLoad) / tunnelDetails.Sum(_ => _.NominalLoad)) * 100;
            visualizationViewModel.WeightColor = this.FetchColor(loadEfficiency);
            visualizationViewModel.WeightLevel = this.FetchPercent(loadEfficiency);            

            visualizationViewModel.Tunnels = tunnels;
            visualizationViewModel.LostWeightInBatches = Math.Round(tunnelDetails.Sum(_ => _.LostWeightInBatches));
            visualizationViewModel.RegionId = this.GetPlantDetails().RegionId;
            return visualizationViewModel;
        }

        /// <summary>
        ///     Get the ConventionalWasher visualization Data based on the dashboardId
        /// </summary>
        /// <param name="id">the id parameter.</param>
        /// <returns>ConventionalWasherViewModel</returns>
        public ConventionalWasherViewModel GetConventionalWasherVisualizationData(int id)
        {
            List<BreakAndTimeline> breakAndTimelineDetails = this.conventionalWasherDashboardService.FetchTimeLineAndBreakData(id, this.EcolabAccountNumber);
            List<BreakAndTimelineModel> breakAndTimelineModelList = Mapper.Map<List<BreakAndTimeline>, List<BreakAndTimelineModel>>(breakAndTimelineDetails);
            BreakAndTimelineModel timelineList = breakAndTimelineModelList.Where(_ => _.Type == "TimeLine").FirstOrDefault();
            DateTime fromTime = new DateTime(int.Parse(DateTime.Now.Year.ToString()), int.Parse(DateTime.Now.Month.ToString()), int.Parse(DateTime.Now.Day.ToString()), timelineList.FromTimeInSeconds, 0, 0);
            DateTime toTime = new DateTime(int.Parse(DateTime.Now.Year.ToString()), int.Parse(DateTime.Now.Month.ToString()), int.Parse(DateTime.Now.Day.ToString()), timelineList.ToTimeInSeconds == 24 ? 00 : timelineList.ToTimeInSeconds, 0, 0);
            var timeList = new List<int>();

            if (timelineList.FromTimeInSeconds > timelineList.ToTimeInSeconds || timelineList.ToTimeInSeconds == 24)
            {
                toTime = toTime.AddDays(1);
            }

            if (timelineList != null)
            {
                for (DateTime time = fromTime; time <= toTime; time = time.AddHours(1))
                {
                    timeList.Add(int.Parse(time.Hour.ToString()));
                }
            }

            ConventionalWasherViewModel conventionalWasherViewModel = new ConventionalWasherViewModel { Time = timeList, BreakAndTimelineDetails = breakAndTimelineModelList.Where(_ => _.Type == "BreakTime" || _.Type == "ShiftTime").ToList() };

            List<ConventionalWasher> washerDetails = this.conventionalWasherDashboardService.FetchWasherData(id, this.EcolabAccountNumber);
            List<ConventionalWasherModel> washerModelList = Mapper.Map<List<ConventionalWasher>, List<ConventionalWasherModel>>(washerDetails);

            DateTime startDateTime = DateTime.Now;
            if (timeList.LastOrDefault() < timeList.FirstOrDefault())
            {
                if (startDateTime.TimeOfDay.Hours < timeList.FirstOrDefault())
                {
                    startDateTime = startDateTime.Date.AddDays(-1);
                }
            }
            TimeSpan startTime = new TimeSpan(timeList.FirstOrDefault(), 0, 0);
            startDateTime = startDateTime.Date + startTime;
            startDateTime = TimeZoneInfo.ConvertTimeToUtc(startDateTime);

            DateTime endDateTime = DateTime.Now;
            endDateTime = startDateTime.AddHours(timeList.Count() - 1);

            int currentTimeInSeconds = this.GetCurrentTime(startDateTime);
            int endTimeInSeconds = this.GetEndTime(startDateTime, endDateTime);

            List<BatchDetails> batchDetails = this.conventionalWasherDashboardService.FetchBatchData(id, this.EcolabAccountNumber, startDateTime, endDateTime, currentTimeInSeconds);
            List<BatchDetailsModel> batchModelList = Mapper.Map<List<BatchDetails>, List<BatchDetailsModel>>(batchDetails);
            var washers = new List<ConventionalWasherModel>();
            var batchs = new List<BatchDetailsModel>();
            var alarms = new List<string>();
            foreach (ConventionalWasherModel washerModel in washerModelList)
            {
                ConventionalWasherModel washer = new ConventionalWasherModel();
                washer.GroupId = washerModel.GroupId;
                washer.WasherId = washerModel.WasherId;
                washer.WasherName = washerModel.WasherName;
                washer.WasherNumber = washerModel.WasherNumber;
                washer.NominalLoad = washerModel.NominalLoad;
                washer.ActualLoad = washerModel.ActualLoad;
                washer.LostLoad = washerModel.LostLoad;
                washer.LoadEfficiency = Math.Round(washerModel.LoadEfficiency, 0);
                washer.TimeEfficiency = Math.Round(washerModel.TimeEfficiency, 0);
                washer.Status = washerModel.Status;
                washer.BatchDetails = batchModelList.Where(_ => _.GroupId == washerModel.GroupId && _.MachineId == washerModel.WasherId && (!(_.ActualTurnTimeInSeconds < 0))).ToList();
                washer.startTime = batchModelList.Where(_ => _.GroupId == washerModel.GroupId && _.MachineId == washerModel.WasherId).Select(_ => _.BatchStartTimeInSeconds).FirstOrDefault();
                washer.Alarm = washerModel.Alarm;
                washer.AlarmDescription = washerModel.AlarmDescription;
                washer.DefaultIdleTime = washerModel.DefaultIdleTime;
                washer.TargetTurnTime = washerModel.TargetTurnTime;
                washer.IsPLCConnected = washerModel.IsPLCConnected;
                washer.DispenserName = washerModel.DispenserName;
                washer.LostWeightInBatches = washerModel.LostWeightInBatches;
                washer.CurrentBatchLoadEfficiency = washerModel.CurrentBatchLoadEfficiency;
                washer.AverageEfficiency = washerModel.AverageEfficiency;
                int WasherStandardTurnTime = 0;

                if (washer.DefaultIdleTime != 0)
                    WasherStandardTurnTime = (washer.DefaultIdleTime - washer.TargetTurnTime) ;
                else
                    WasherStandardTurnTime = washer.TargetTurnTime;

                foreach (BatchDetailsModel batchModel in washer.BatchDetails)
                {
                    int batchStartTimeInSeconds = batchModel.BatchStartTimeInSeconds > 0 ? batchModel.BatchStartTimeInSeconds : 0;
                    int batchActualEndTimeInSeconds = batchModel.BatchActualEndTimeInSeconds > 0 ? batchModel.BatchActualEndTimeInSeconds : 0;
                    batchModel.ProgressWidth = this.GetProgressBarWidth(batchModel.RunningStatus, batchModel.BatchStartTimeInSeconds, batchModel.BatchStandardEndTimeInSeconds, batchModel.BatchActualEndTimeInSeconds);
                    int batchStandardEndTimeInSeconds = batchModel.BatchStandardEndTimeInSeconds > 0 ? batchModel.BatchStandardEndTimeInSeconds : 0;
                    int additionalWidth = batchModel.BatchActualEndTimeInSeconds == 0 ? (currentTimeInSeconds - batchModel.BatchStandardEndTimeInSeconds) : (batchActualEndTimeInSeconds - batchStandardEndTimeInSeconds);
                    batchModel.AdditionalWidth = additionalWidth > 0 ? additionalWidth : 0;
                    //StandardTurnTimeInSeconds = batchModel.StandardTurnTimeInSeconds;
                    batchModel.TurnTimeProgressWidth = this.GetTurnTimeProgressBarWidth(batchModel.RunningStatus, batchModel.StandardTurnTimeInSeconds, batchModel.ActualTurnTimeInSeconds);
                    int turnTimeAdditionalWidth = 0;
                    // if (batchModel.ActualTurnTimeInSeconds > (batchModel.StandardTurnTimeInSeconds + (PlantStandardTurnTime * 60)))
                    if (batchModel.ActualTurnTimeInSeconds > (batchModel.StandardTurnTimeInSeconds + (WasherStandardTurnTime * 60)))
                    {
                        //   turnTimeAdditionalWidth = PlantStandardTurnTime * 60;
                       // batchModel.OtherTurnTimeWidth = batchModel.ActualTurnTimeInSeconds - (batchModel.StandardTurnTimeInSeconds + (PlantStandardTurnTime * 60));
                        turnTimeAdditionalWidth = WasherStandardTurnTime * 60;
                        batchModel.OtherTurnTimeWidth = batchModel.ActualTurnTimeInSeconds - (batchModel.StandardTurnTimeInSeconds + (WasherStandardTurnTime * 60));
                    }
                    else
                    {
                        turnTimeAdditionalWidth = batchModel.ActualTurnTimeInSeconds - batchModel.StandardTurnTimeInSeconds;
                    }

                    batchModel.TurnTimeAdditionalWidth = turnTimeAdditionalWidth > 0 ? turnTimeAdditionalWidth : 0;
                    if ((batchModel.BatchStandardEndTimeInSeconds - batchStartTimeInSeconds) > 0)
                    {
                    if (batchModel.BatchActualEndTimeInSeconds > 0 || batchModel.BatchActualEndTimeInSeconds < 0)
                    {
                        batchModel.TimeEfficiency = ((batchModel.BatchActualEndTimeInSeconds - batchStartTimeInSeconds) * 100) / (batchModel.BatchStandardEndTimeInSeconds - batchStartTimeInSeconds);
                    }
                    else
                    {

                            batchModel.TimeEfficiency = ((currentTimeInSeconds - batchStartTimeInSeconds) * 100) / (batchModel.BatchStandardEndTimeInSeconds - batchStartTimeInSeconds);
                    }
                    }

                    if (batchModel.DisplayFormula)
                    {
                        conventionalWasherViewModel.DisplayFormula = batchModel.DisplayFormula;
                        conventionalWasherViewModel.FormulaDisplayType = batchModel.FormulaDisplayType;
                    }
                }

                washers.Add(washer);
                if (washer.Alarm)
                {
                    alarms.Add(washer.AlarmDescription);
                }
            }
            if (alarms.Count > 0)
            {
                conventionalWasherViewModel.AlarmWasherName = alarms;
            }
            conventionalWasherViewModel.ActualLoadDecimal = Convert.ToDecimal(washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Sum(_ => _.ActualLoad));
            conventionalWasherViewModel.LostLoadDecimal = Convert.ToDecimal(washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Sum(_ => _.LostLoad));
            conventionalWasherViewModel.ActualLoadConverted = conventionalWasherViewModel.ActualLoadDecimal;
            conventionalWasherViewModel.LostLoadConverted = conventionalWasherViewModel.LostLoadDecimal;
            conventionalWasherViewModel.LostWeightInBatches = Math.Round(washers.Sum(_ => _.LostWeightInBatches));
            if (GetPlantDetails() != null && GetCurrentUser() != null)
            {
                WebModel.PlantModel PlantModel = GetPlantDetails();
                //conventionalWasherViewModel.ConvertUnit(PlantModel.UOMId, PlantModel.EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                Ecolab.ConduitLocal.Web.Controllers.LocaleController LocaleController = new Ecolab.ConduitLocal.Web.Controllers.LocaleController(this.UserService, this.PlantService);
                conventionalWasherViewModel.UOM = LocaleController.LocalizeUom("Weight_CommonUse", "LBS");
                if (this.GetPlantDetails().RegionId == 2)
                {
                    conventionalWasherViewModel.UOM = "KGS";
                }
                if (this.GetPlantDetails().RegionId == 1)
                {
                    conventionalWasherViewModel.UOMId = 1;
                }
                else
                {
                    conventionalWasherViewModel.UOMId = 2;
                }                 
            }
            conventionalWasherViewModel.ActualLoad = Math.Round(conventionalWasherViewModel.ActualLoadConverted).ToString("#,0.##");
            conventionalWasherViewModel.LostLoad = Math.Round(conventionalWasherViewModel.LostLoadConverted).ToString("#,0.##");
            double efficiency = Math.Round(((washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Sum(_ => _.LoadEfficiency) / washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Count()) * (washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Sum(_ => _.TimeEfficiency) / washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Count())) / 100, 0);
            //conventionalWasherViewModel.Efficiency = double.IsNaN(efficiency) ? 0 : Math.Round(efficiency, 0);
            if (washers.Any())
            {
                conventionalWasherViewModel.Efficiency = washers.FirstOrDefault().AverageEfficiency;
            }
            conventionalWasherViewModel.EfficiencyLevel = this.FetchPercent(conventionalWasherViewModel.Efficiency);
            conventionalWasherViewModel.EfficiencyColor = this.FetchColor(conventionalWasherViewModel.Efficiency);
            double weightEfficiency = washers.Any() ? washers.Sum(_ => _.LoadEfficiency) / washers.Where(_ => Math.Abs(_.NominalLoad) != 0).Count() : 0;
            conventionalWasherViewModel.WeightColor = this.FetchColor(weightEfficiency);
            conventionalWasherViewModel.WeightLevel = this.FetchPercent(weightEfficiency);
            conventionalWasherViewModel.ConventionalWashers = washers;
            conventionalWasherViewModel.Pixel = 2;
            conventionalWasherViewModel.CurrentTimeInSeconds = currentTimeInSeconds;
            conventionalWasherViewModel.EndTimeInSeconds = endTimeInSeconds;
            conventionalWasherViewModel.HoursToDisplay = timeList.Count - 1;
            conventionalWasherViewModel.PlantLogo = this.Logo;            
            conventionalWasherViewModel.RegionId = this.GetPlantDetails().RegionId;
            return conventionalWasherViewModel;
        }

        /// <summary>
        ///     method to fetch percent for handling the classes dynamically
        /// </summary>
        /// <param name="percent">The percent</param>
        /// <returns>The string.</returns>
        public string FetchPercent(double percent)
        {
            if (percent <= 10)
            {
                return "zero";
            }
            if (percent <= 20.0)
            {
                return "one";
            }
            if (percent <= 30.0)
            {
                return "two";
            }
            if (percent <= 40.0)
            {
                return "three";
            }
            if (percent <= 50.0)
            {
                return "four";
            }
            if (percent <= 60.0)
            {
                return "five";
            }
            if (percent <= 70.0)
            {
                return "six";
            }
            if (percent <= 80.0)
            {
                return "seven";
            }
            if (percent <= 90.0)
            {
                return "eight";
            }
            if (percent < 100.0)
            {
                return "nine";
            }
            if (percent >= 100.0)
            {
                return "ten";
            }
            return "zero";
        }

        /// <summary>
        ///     method to fetch colour for handling the classes dynamically
        /// </summary>
        /// <param name="percent">the percent parameter.</param>
        /// <returns>returns the Colour </returns>
        public string FetchColor(double percent)
        {
            int red = Convert.ToInt16((new AppSettingsReader()).GetValue("red", typeof(string)));
            int green = Convert.ToInt16((new AppSettingsReader()).GetValue("green", typeof(string)).ToString());

            if (percent <= red)
            {
                return "red";
            }
            if (percent > red && percent < green)
            {
                return "yel";
            }
            if (percent >= green)
            {
                return "green";
            }
            return "green";
        }

        /// <summary>
        ///     method to fetch font colour for handling the casses dynamically
        /// </summary>
        /// <param name="percent">the percent parameter.</param>
        /// <returns>returns the Colour </returns>
        public string FetchFontColor(double percent)
        {
            int red = Convert.ToInt16((new AppSettingsReader()).GetValue("fontRed", typeof(string)));
            int yellow = Convert.ToInt16((new AppSettingsReader()).GetValue("fontYellow", typeof(string)).ToString());

            if (percent > red)
            {
                return "red";
            }
            if (percent <= yellow && percent > 0)
            {
                return "yel";
            }
            if (Math.Abs(percent) == 0)
            {
                return "skyblue";
            }
            return "white";
        }

        /// <summary>
        ///     method to get the CurrentTime in seconds from start time
        /// </summary>
        /// <param name="startHour">The Start hour.</param>
        /// <returns>returns the integer.</returns>
        protected int GetCurrentTime(DateTime startHour)
        {
            DateTime currentHour = DateTime.UtcNow;
            return Convert.ToInt32((currentHour - startHour).TotalSeconds);
        }

        /// <summary>
        ///     method to get the End in seconds from start time
        /// </summary>
        /// <param name="startHour">The start Hour.</param>
        /// <param name="endHour">The end Hour.</param>
        /// <returns>returns the integer.</returns>
        protected int GetEndTime(DateTime startHour, DateTime endHour)
        {
            return int.Parse((endHour - startHour).TotalSeconds.ToString());
        }

        /// <summary>
        ///     Method to get the progressbar width in mins from starts time
        /// </summary>
        /// <param name="runningStatus">the running status</param>
        /// <param name="startTime">the start time.</param>
        /// <param name="standardEndTime">the standard end time</param>
        /// <param name="actualEndTime">the actual end time</param>
        /// <returns>returns the integer.</returns>
        protected int GetProgressBarWidth(bool runningStatus, int startTime, int standardEndTime, int actualEndTime)
        {
            startTime = startTime < 0 ? 0 : startTime;
            if (runningStatus == false && startTime > 0 && actualEndTime <= standardEndTime)
            {
                return actualEndTime - startTime;
            }
            if (runningStatus == false && startTime > 0 && actualEndTime > standardEndTime)
            {
                return standardEndTime - startTime;
            }
            if (runningStatus == false && startTime == 0 && actualEndTime <= 0)
            {
                return 1;
            }
            if (runningStatus == false && startTime == 0 && standardEndTime >= actualEndTime)
            {
                return actualEndTime;
            }
            if (runningStatus == false && startTime == 0 && standardEndTime <= 0 && actualEndTime > standardEndTime)
            {
                return actualEndTime;
            }
            if (runningStatus == false && startTime == 0 && actualEndTime > standardEndTime)
            {
                return standardEndTime;
            }
            if (runningStatus)
            {
                return standardEndTime - startTime;
            }
            return standardEndTime;
        }

        /// <summary>
        ///     Method to get the Turntime progressbar width in mins from starts time
        /// </summary>
        /// <param name="runningStatus">the running status</param>
        /// <param name="standardTurnTime">the standard turn time</param>
        /// <param name="actualTurnTime">the actual turn time</param>
        /// <returns>returns the Turn time</returns>
        protected int GetTurnTimeProgressBarWidth(bool runningStatus, int standardTurnTime, int actualTurnTime)
        {
            if (runningStatus == false)
            {
                if (actualTurnTime < standardTurnTime)
                {
                    return actualTurnTime;
                }
                if (actualTurnTime >= standardTurnTime)
                {
                    return standardTurnTime;
                }
                return actualTurnTime;
            }
            return standardTurnTime;
        }

        /// <summary>
        /// method to fetch colour for handling the classes dynamically
        /// </summary>
        /// <param name="actualTrasferRate">The actual trasfer rate.</param>
        /// <param name="standerdTrasferRate">The standerd trasfer rate.</param>
        /// <returns>
        /// returns the Colour
        /// </returns>
        public string GetTransferRateColor(int actualTrasferRate, int standerdTrasferRate)
        {
            Dictionary<string, string> configSettings = new Dictionary<string, string>();
            configSettings = GetConfigSettings("DashBoardTransferPerHour");
            
            double red = Convert.ToDouble(configSettings["TransferPerHourRedLevel"]);
            double green = Convert.ToDouble(configSettings["TransferPerHourGreenLevel"]);

            double redValue = (standerdTrasferRate * red) / 100;
            double greenValue = (standerdTrasferRate * green) / 100;

            if (actualTrasferRate < redValue)
            {
                return "red";
            }
            if (actualTrasferRate >= redValue && actualTrasferRate <= greenValue)
            {
                return "yel";
            }
            if (actualTrasferRate > greenValue)
            {
                return "green";
            }

            return "green";
        }

        /// <summary>
        /// method to fetch the Color code values from the Config Settings.
        /// </summary>
        /// <param name="typeOfService">The type Of Service.</param>
        /// <returns>
        /// returns the Dictionary of string , string value.
        /// </returns>
        public static Dictionary<string, string> GetConfigSettings(string typeOfService)
        {
            SyncConfigSettingService objSyncConfigSettingService = new SyncConfigSettingService();
            return objSyncConfigSettingService.GetAppConfigKeyValueDetails(typeOfService);
        }
    }
}