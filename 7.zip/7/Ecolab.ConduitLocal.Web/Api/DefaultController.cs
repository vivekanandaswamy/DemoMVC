﻿// -----------------------------------------------------------------------
// <copyright file="DefaultController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Default Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Models;
    using Ecolab.Models.Default;
    using Models;
    using Models.Default;
    using Models.Reports;
    using Services.Interfaces;
    using Services.Interfaces.Default;

    /// <summary>
    ///     DefaultController Class
    /// </summary>
    public class DefaultController : BaseApiController
    {
        /// <summary>
        ///     Default Service
        /// </summary>
        private readonly IDefaultService mDefaultService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="DefaultController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="defaultService">default Service</param>
        public DefaultController(IUserService userService, IPlantService plantService, IDefaultService defaultService) : base(userService, plantService)
        {
            this.mDefaultService = defaultService;
        }

        /// <summary>
        ///     Gets UserPortletData
        /// </summary>
        /// <returns>List of User PortletData</returns>
        [HttpGet]
        public PortletsViewModel FetchUserPortletData()
        {
            PortletsViewModel objPortletsViewModel = new PortletsViewModel();
            objPortletsViewModel.Portlets = Mapper.Map<List<Portlet>, List<PortletModel>>(this.mDefaultService.FetchPortletsByUser(this.UserId, this.EcolabAccountNumber));

            if (objPortletsViewModel.Portlets.Count > 0 && objPortletsViewModel.Portlets.Where(_ => _.IsEnabled).Count() == 0)
            {
                objPortletsViewModel.Portlets.Where(_ => _.ReportId == (int)ReportEnum.ProductionSummary).FirstOrDefault().IsEnabled = true;
            }

            PlantModel plant = this.GetPlantDetails();
            objPortletsViewModel.PlantName = plant.Name;
            objPortletsViewModel.PlantId = plant.EcoalabAccountNumber;
            ShiftSummaryModel objshiftsummarymodel = Mapper.Map<ShiftSummary, ShiftSummaryModel>(this.mDefaultService.GetShiftSummaryDetails(this.EcolabAccountNumber));

            if (objshiftsummarymodel == null)
            {
                objshiftsummarymodel = new ShiftSummaryModel();
                objshiftsummarymodel.Efficiency = 0;
                objshiftsummarymodel.LostLoad = 0;
                objshiftsummarymodel.TotalLoad = 0;
                objshiftsummarymodel.ShiftName = "No Shift Available";
            }
            objPortletsViewModel.LostLoad =Math.Round( objshiftsummarymodel.LostLoad,0).ToString("#,0.##");
            objPortletsViewModel.TotalLoad =Math.Round( objshiftsummarymodel.TotalLoad,0).ToString("#,0.##");
            objPortletsViewModel.Efficiency =Math.Round( objshiftsummarymodel.Efficiency,0);
            objPortletsViewModel.FontColor = this.FetchFontColor(objshiftsummarymodel.Efficiency);
            objPortletsViewModel.ShiftName = objshiftsummarymodel.ShiftName;

            return objPortletsViewModel;
        }

        /// <summary>
        ///     Save UserPortletData
        /// </summary>
        /// <param name="portletDataList"> Portlet Data List</param>
        /// <returns>Save User PortletData</returns>
        [HttpPost]
        public string CreateUserPortletData([FromBody] List<PortletModel> portletDataList)
        {
            List<Portlet> userPortletDataList = Mapper.Map<List<PortletModel>, List<Portlet>>(portletDataList);
            return this.mDefaultService.CreateUserPortletData(userPortletDataList, this.UserId, this.EcolabAccountNumber);
        }

        /// <summary>
        ///     method to fetch font colour for handling the classes dynamically
        /// </summary>
        /// <param name="percent">the percent parameter.</param>
        /// <returns>returns the Colour </returns>
        public string FetchFontColor(double percent)
        {
            int red = Convert.ToInt16((new AppSettingsReader()).GetValue("red", typeof(string)));
            int green = Convert.ToInt16((new AppSettingsReader()).GetValue("green", typeof(string)).ToString());

            if (percent <= red)
            {
                return "red";
            }
            if (percent > red && percent < green)
            {
                return "yellow";
            }
            if (percent >= green)
            {
                return "green";
            }
            return "green";
        }
    }
}