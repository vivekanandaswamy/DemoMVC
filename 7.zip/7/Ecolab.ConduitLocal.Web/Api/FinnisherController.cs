﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Text.RegularExpressions;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.PlantSetup.Finnisher;
    using Models.PlantSetup.Finnisher;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Finnisher;

    /// <summary>
    ///     Api controller for FinnisherController
    /// </summary>
    [Authorize]
    public class FinnisherController : BaseApiController
    {
        /// <summary>
        ///     FinnisherGroup Service
        /// </summary>
        private readonly IFinnisherGroupService finnisherGroupService;

        /// <summary>
        ///     z,o
        ///     FinnisherGroup Service
        /// </summary>
        private readonly IFinnisherService finnisherService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="FinnisherController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="finnisherGroupService">The Finnisher Group Service</param>
        /// <param name="finnisherService">The Finnisher Service</param>
        /// <param name="plantService">The Plant Service</param>
        public FinnisherController(IUserService userService, IFinnisherGroupService finnisherGroupService, IFinnisherService finnisherService, IPlantService plantService) : base(userService, plantService)
        {
            this.finnisherGroupService = finnisherGroupService;
            this.finnisherService = finnisherService;
        }

        #region FinnisherGroups

        /// <summary>
        ///     Method to get the Finnishers along with Finnisher Groups
        /// </summary>
        /// <returns>List of Finnisher Groups</returns>
        public List<FinnisherGroupModel> Get()
        {
            List<FinnisherGroup> finnishers = this.finnisherGroupService.FetchFinnisherGroupDetails(this.EcolabAccountNumber);
            List<FinnisherGroupModel> finnisherGroupModel = Mapper.Map<List<FinnisherGroup>, List<FinnisherGroupModel>>(finnishers);

            var groupList = finnisherGroupModel.Select(x => new { x.Id, x.Name, x.IsDeleted }).Where(x => x.IsDeleted == false).Distinct().ToList();

            var finnisherGroupModels = new List<FinnisherGroupModel>();

            foreach (var group in groupList)
            {
                List<FinnisherGroupModel> finnishersList = finnisherGroupModel.FindAll(x => x.Id == group.Id);
                var finsherModelList = new List<FinnisherModel>();
                foreach (FinnisherGroupModel dr in finnishersList)
                {
                    if (dr.Finnisher.Number > 0)
                    {
                        FinnisherModel drm = new FinnisherModel { GroupId = group.Id, Name = dr.Finnisher.Name, Number = dr.Finnisher.Number, FinisherId = dr.Finnisher.FinisherId, FinnisherType = new FinnisherTypeModel { Id = dr.Finnisher.FinnisherType.Id, Name = dr.Finnisher.FinnisherType.Name } };
                        finsherModelList.Add(drm);
                    }
                }

                finnisherGroupModels.Add(new FinnisherGroupModel { Id = group.Id, Name = group.Name, Finnishers = finsherModelList.OrderBy(_ => _.Number).ToList() });
            }

            return finnisherGroupModels;
        }

        /// <summary>
        ///     Method to create a new Finnisher group
        /// </summary>
        /// <param name="finnisherGroup">Finnisher Group</param>
        /// <returns>Create Finnisher Response Message</returns>
        [HttpPost]
        public HttpResponseMessage CreateFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            IPrincipal user = HttpContext.Current.User;
            try
            {
                int result = 0;
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Name = finnisherGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };
                if (user != null)
                {
                    DateTime lastModifiedTimeStamp;

                    finnisherGroupData.EcolabAccountNumber = this.EcolabAccountNumber;
                    result = this.finnisherGroupService.InsertFinnisherGroup(finnisherGroupData, this.UserId, out lastModifiedTimeStamp);

                    finnisherGroupData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    finnisherGroupData.Id = result;

                    switch (result)
                    {
                        case 301:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);

                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    }

                    Push.PushToQueue(finnisherGroupData, this.UserId, finnisherGroupData.Id, (int)TcdAdminMessageTypes.TcdAddFinnisherGroup, this.EcolabAccountNumber);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Finnisher group
        /// </summary>
        /// <param name="finnisherGroup">Finnisher Group</param>
        /// <returns>Update Finnisher Response Message</returns>
        [HttpPost]
        public HttpResponseMessage UpdateFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            IPrincipal user = HttpContext.Current.User;
            try
            {
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Id = finnisherGroup.Id, Name = finnisherGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };

                if (user != null)
                {
                    DateTime lastModifiedTimeStamp;
                    int response = this.finnisherGroupService.UpdateFinnisherGroup(finnisherGroupData, this.UserId, out lastModifiedTimeStamp);
                    finnisherGroupData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

                    switch (response)
                    {
                        case 301:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                        case 302:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                        case 51030:
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                    }
                    Push.PushToQueue(finnisherGroupData, this.UserId, finnisherGroupData.Id, (int)TcdAdminMessageTypes.TcdUpdateFinnisherGroup, this.EcolabAccountNumber);
                }

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a FinnisherGroup
        /// </summary>
        /// <param name="finnisherGroup">Finnisher group</param>
        /// <returns>Delete finnisher Response message</returns>
        [HttpPost]
        public HttpResponseMessage DeleteFinnisherGroup([FromBody] FinnisherGroupModel finnisherGroup)
        {
            try
            {
                FinnisherGroup finnisherGroupData = new FinnisherGroup { Id = finnisherGroup.Id, Name = finnisherGroup.Name, EcolabAccountNumber = this.EcolabAccountNumber };

                DateTime lastModifiedTimeStamp;
                int result = this.finnisherGroupService.DeleteFinnisherGroup(finnisherGroupData, finnisherGroupData.Id, this.UserId, this.EcolabAccountNumber, out lastModifiedTimeStamp);
                finnisherGroupData.LastModifiedTimeStampFinnisherGroup = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                finnisherGroupData.IsDelete = true;
                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 501:
                        finnisherGroupData.IsDelete = false;
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }

                Push.PushToQueue(finnisherGroupData, this.UserId, finnisherGroupData.Id, (int)TcdAdminMessageTypes.TcdDeleteFinnisherGroup, this.EcolabAccountNumber);

                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion

        #region Finnisher
        /// <summary>
        /// Method to fetch finnisher types
        /// </summary>
        /// <returns>Collection of finnisher types</returns>
        [HttpGet]
        public IEnumerable<FinnisherTypeModel> FetchFinnisherTypes()
        {
            List<FinnisherType> finnisherType = this.finnisherService.FetchFinnisherTypes(this.EcolabAccountNumber);
            List<FinnisherTypeModel> finnisherTypeModel = Mapper.Map<List<FinnisherType>, List<FinnisherTypeModel>>(finnisherType);
            return finnisherTypeModel.ToList();
        }

        /// <summary>
        ///     Method to create a new Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage CreateFinnisher([FromBody] FinnisherModel finnisher)
        {
            try
            {
                int finnisherGroupId = finnisher.GroupId;

                Finnisher finnisherData = new Finnisher { Name = finnisher.Name, FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id }, EcolabAccountNumber = this.EcolabAccountNumber, Number = finnisher.Number, GroupId = finnisher.GroupId };

                DateTime lastModifiedTimeStamp;
                int result = this.finnisherService.InsertFinnisher(finnisherData, finnisherGroupId, this.UserId, out lastModifiedTimeStamp);
                finnisherData.FinisherId = result;
                finnisherData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                switch (result)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                Push.PushToQueue(finnisherData, this.UserId, finnisherData.FinisherId, (int)TcdAdminMessageTypes.TcdAddFinnisher, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to Update a Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http Response messgae</returns>
        [HttpPost]
        public HttpResponseMessage UpdateFinnisher([FromBody] FinnisherModel finnisher)
        {
            try
            {
                int result = 0;
                Finnisher finnisherData = new Finnisher { GroupId = finnisher.GroupId, FinisherId = finnisher.FinisherId, Name = finnisher.Name, EcolabAccountNumber = this.EcolabAccountNumber, Number = finnisher.Number, FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id } };
                DateTime lastModifiedTimeStamp;
                result = this.finnisherService.UpdateFinnisher(finnisherData, this.UserId, out lastModifiedTimeStamp);
                finnisherData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                switch (result)
                {
                    case 301:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
                    case 302:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 302);
                    case 303:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 303);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
                }
                Push.PushToQueue(finnisherData, this.UserId, finnisherData.FinisherId, (int)TcdAdminMessageTypes.TcdUpdateFinnisher, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        /// <summary>
        ///     Method to delete a Finnisher
        /// </summary>
        /// <param name="finnisher">Finnisher object</param>
        /// <returns>Http response message</returns>
        [HttpPost]
        public HttpResponseMessage DeleteFinnisher([FromBody] FinnisherModel finnisher)
        {
            try
            {
                Finnisher finnisherData = new Finnisher { FinisherId = finnisher.FinisherId, GroupId = finnisher.GroupId, Name = finnisher.Name, FinnisherType = new FinnisherType { Id = finnisher.FinnisherType.Id }, Number = finnisher.Number };
                DateTime lastModifiedTimeStamp;
                int result = this.finnisherService.DeleteFinnisher(finnisherData, finnisherData.Number, this.UserId, this.EcolabAccountNumber, out lastModifiedTimeStamp);
                finnisherData.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                finnisherData.IsDelete = true;
                finnisherData.EcolabAccountNumber = this.EcolabAccountNumber;
                switch (result)
                {
                    case -1:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 51030:
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                    case 501:
                        finnisherData.IsDelete = false;
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
                }
                Push.PushToQueue(finnisherData, this.UserId, finnisherData.FinisherId, (int)TcdAdminMessageTypes.TcdDeleteFinnisher, this.EcolabAccountNumber);
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
            }
        }

        #endregion
    }
}