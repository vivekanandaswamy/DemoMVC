﻿// -----------------------------------------------------------------------
// <copyright file="SensorController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorController </summary>
// -----------------------------------------------------------------------
namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using Utilities;
    using WebModel = Models.PlantSetup;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     class SensorController
    /// </summary>
    public class SensorController : BaseApiController
    {
        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Sensor Service
        /// </summary>
        private readonly ISensorService sensorService;

        /// <summary>
		///     The _controller setup service
		/// </summary>
		private readonly IControllerSetupService controllerSetupService;
        /// <summary>
        /// Washer group service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;
        /// <summary>
        /// washer service.
        /// </summary>
        private readonly IWasherServices washerService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="SensorController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="sensorService">Sensor Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plcService">The Plc Service</param>
        /// <param name="controllerSetupService">The controller setup service</param>
        /// <param name="washerGroupService">The washer group service</param>
        /// <param name="washerService">The washer service.</param>
        public SensorController(IUserService userService, ISensorService sensorService, IPlantService plantService, IPlcService plcService, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IWasherServices washerService)
            : base(userService, plantService)
        {
            this.sensorService = sensorService;
            this.plcService = plcService;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.washerService = washerService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }
        /// <summary>
        /// Gets sensor method
        /// </summary>
        /// <returns>List of sensors</returns>
        [HttpGet]
        public IEnumerable<WebModel.SensorWebModel> GetSensor()
        {
            List<Sensor> sensors = this.sensorService.GetPlantSensorDetails(null, this.EcolabAccountNumber);
            List<WebModel.SensorWebModel> sensorList = Mapper.Map<List<Sensor>, List<WebModel.SensorWebModel>>(sensors);

            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                TagCollection tagStatus = new TagCollection();
                foreach (WebModel.SensorWebModel model in sensorList)
                {
                    if (!string.IsNullOrEmpty(model.CalibrationTag4))
                    {
                        tagsList.Add(new OpcTag
                        {
                            Address = model.CalibrationTag4,
                            Value = model.CalibrationValue4.ToString(CultureInfo.CurrentCulture)
                        });
                    }

                    if (!string.IsNullOrEmpty(model.CalibrationTag20))
                    {
                        tagsList.Add(new OpcTag
                        {
                            Address = model.CalibrationTag20,
                            Value = model.CalibrationValue20.ToString(CultureInfo.CurrentCulture)
                        });
                    }

                    if (tagsList.Count > 0)
                    {
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, sensorList.FirstOrDefault().ControllerId.Value);
                        List<string> tagCollectionList = new List<string>();
                        foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            tagCollectionList.AddRange(
                                tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value))
                                    .Where(plcTag => tag.Address == plcTag.Address && (IsNumeric(tag.Value) && Convert.ToInt32(tag.Value) != Convert.ToInt32(plcTag.Value) || tag.Value != plcTag.Value))
                                    .Select(plcTag => tag.Address));
                        }
                        foreach (WebModel.SensorWebModel metaData in sensorList)
                        {
                            if (!string.IsNullOrEmpty(metaData.CalibrationTag4) && tagCollectionList.Contains(metaData.CalibrationTag4))
                            {
                                metaData.Calibration4Override = true;
                            }
                            if (!string.IsNullOrEmpty(metaData.CalibrationTag20) && tagCollectionList.Contains(metaData.CalibrationTag20))
                            {
                                metaData.Calibration20Override = true;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Error occured while reading PLC Data for Sensors :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }

            return sensorList.AsEnumerable();
        }
        /// <summary>
        /// Method to check whether it is number or not.
        /// </summary>
        /// <param name="Expression">The expression parameter.</param>
        /// <returns>Return static boolean value.</returns>
        public static bool IsNumeric(object Expression)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        /// <summary>
        ///     creates new the sensor
        /// </summary>
        /// <param name="data">Sensor data to create</param>
        /// <returns>Returns created sensor data</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage CreateSensor([FromBody] List<WebModel.SensorWebModel> data)
        {
            Sensor objSensor = new Sensor();
            List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
            try
            {
                int? controllerId = null;
                if ((data[0].SensorLocationId == null && data[0].MachineId == null) || data[0].ControllerId == null)
                {
                    if (data[0].ControllerId != null)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "603" });
                    }
                    data[0].ControllerId = -1;
                    data[0].ControllerModelId = 5;

                    List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(null, null, this.EcolabAccountNumber);
                    IEnumerable<ConduitController> utilityLogger = controller.Where(_ => _.ControllerModelId == 5);
                    ConduitController[] conduitControllers = utilityLogger as ConduitController[] ?? utilityLogger.ToArray();
                    if (conduitControllers.Any())
                    {
                        ConduitController first = conduitControllers.FirstOrDefault();
                        if (first != null)
                        {
                            controllerId = first.ControllerId;
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "701" });
                    }
                }
                else if (data[0].SensorLocationId != null && data[0].MachineId == null)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "602" });
                }
                else if (data[0].SensorLocationId != null && data[0].ControllerId == 0)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "601" });
                }
                else
                {
                    controllerId = data[0].ControllerId;
                }

                objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data[0]);
                objSensor.EcolabAccountNumber = this.EcolabAccountNumber;
                objSensor.MinimumAlarmValue = WELoggerAnalogAlarmCalCluations(objSensor.MinimumAlarmValue, objSensor.CalibrationValue20,false);
                objSensor.MaximumAlarmValue = WELoggerAnalogAlarmCalCluations(objSensor.MaximumAlarmValue, objSensor.CalibrationValue20,false);

                DateTime lastModifiedTimeStamp;
                string error;
                objSensor.SensorNumber = this.sensorService.SavePlantSensorDetails(objSensor, this.UserId, out error, out lastModifiedTimeStamp);
                List<Ecolab.Models.Washers.Washers> washerlist = this.washerService.GetWashersDetails(this.EcolabAccountNumber, data.First().SensorLocationId.GetValueOrDefault(), false).ToList();

                foreach (var item in washerlist)
                {
                    if (item.WasherType.ToLower().Contains("tunnel"))
                    {
                        data.First().LfsWasherNumber = item.lfsWasher;
                    }
                    else
                    {
                        if (item.Id == data.First().MachineId)
                        {
                            data.First().LfsWasherNumber = item.lfsWasher;
                        }
                    }
                }
                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objSensor.ControllerId.Value, this.EcolabAccountNumber);
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel
                {
                    ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Sensors),
                    ParentEntityId = Convert.ToInt32(objSensor.SensorNumber),
                    Entity = Convert.ToInt32(PlcDiscrepancyEntity.Sensors),
                    EntityId = Convert.ToInt32(objSensor.SensorNumber),
                    IsCentral = false,
                    ControllerId = controllerDetails.ControllerId,
                    UserId = this.UserId,
                    LastModifiedUserId = this.UserId
                });
                if (string.IsNullOrWhiteSpace(error))
                {
                    if (objSensor.SensorNumber.Value > 0)
                    {
                        SensorModel objSensorModel = this.sensorService.GetPlantSensorDetailsBySensorId(objSensor.SensorNumber.Value, this.EcolabAccountNumber);
                        objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdAddSensor, this.EcolabAccountNumber);

                        try
                        {
                            WebModel.SensorWebModel sensorWebModel = Mapper.Map<SensorModel, WebModel.SensorWebModel>(objSensorModel);
                            if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                            {
                                plc.WriteMyControlSettingsForSensors(sensorWebModel, objSensor.ControllerId.Value, false);
                            }
                            else if (controllerDetails.ControllerModelId == 11)
                            {
                                var tags = GeneratePlcXlTagsForSensors(sensorWebModel, controllerDetails.ControllerTypeId, false);
                                if (tags.Count > 0)
                                {
                                    plc.WriteTags(new TagCollection { Tags = tags }, controllerDetails.ControllerId, SourcePage.SensorsPage);
                                }
                            }
                            else if (controllerDetails.ControllerModelId == 8)
                            {
                                List<Tag> tags = FormEcontrolPlusTagsWithValues(sensorWebModel, false);
                                if (tags.Count > 0)
                                {
                                    plc.WriteEControlPlusTagsWithRandomArray(tags, controllerDetails.ControllerId);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Contains("Timeout has elapsed") ||
                                ex.Message.Contains("Port is disabled") ||
                                ex.Message.Contains("Target machine could not be found") ||
                                ex.Message.Contains("ADS could not be initialized") ||
                                ex.Message.Contains("Open Failed") ||
                                ex.Message.Contains("Retrieving the COM class factory"))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "901" });
                            }
                            else
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "902" });
                            }
                        }

                        this.sensorService.SavePlantSensorTags(objSensor, this.UserId, out error);
                        if (!string.IsNullOrEmpty(error))
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                        }

                        objSensorModel.ModuleTags = this.sensorService.GetModuleTagsDetails(objSensor.SensorNumber.Value, 3, this.EcolabAccountNumber);
                        objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdUpdateSensor, this.EcolabAccountNumber);
                    }
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                }

                var ambiguousTags = new List<Tag>();
                if (this.RoleId >= 8)
                {
                    if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                    {
                        var tagsList = new List<OpcTag>();
                        if (!string.IsNullOrEmpty(data[0].AnalogueImputNumber))
                        {
                            tagsList.Add(new OpcTag { Address = data[0].AnalogueImputNumber });
                        }

                        if (!string.IsNullOrEmpty(data[0].CalibrationTag4))
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = data[0].CalibrationTag4,
                                Value = data[0].CalibrationValue4.ToString()
                            });
                        }

                        if (!string.IsNullOrEmpty(data[0].CalibrationTag20))
                        {
                            tagsList.Add(new OpcTag
                            {
                                Address = data[0].CalibrationTag20,
                                Value = data[0].CalibrationValue20.ToString()
                            });
                        }
                        string errorCode = null;
                        var tags = new TagCollection();
                        if (tagsList.Any())
                        {
                            tags.Tags = new List<Tag>(tagsList.Clone());
                            TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, controllerId.Value);

                            foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                            {
                                if (status.Address == data[0].AnalogueImputNumber)
                                {
                                    errorCode += "801,";
                                }
                                if (status.Address == data[0].CalibrationTag4)
                                {
                                    errorCode += "802,";
                                }
                                if (status.Address == data[0].CalibrationTag20)
                                {
                                    errorCode += "803,";
                                }
                            }
                        }

                        var message = new StringBuilder();
                        if (tags.Tags != null)
                        {
                            foreach (Tag tag in tags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (OpcTag plcTag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                                    {
                                        message.Append(
                                            string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.{3}",
                                                tag.Address, tag.Value, plcTag.Value, Environment.NewLine));
                                        ambiguousTags.Add(tag);
                                    }
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(errorCode))
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode + "#" + objSensor.SensorNumber });
                        }

                        if (!data[0].OverridePlcValues && !string.IsNullOrWhiteSpace(message.ToString()))
                        {
                            message.Append("Do you want to override the value in plc ?");
                            return Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = message.ToString() });
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(error))
                {
                    if (objSensor.SensorNumber.Value > 0)
                    {
                        this.sensorService.SavePlantSensorTags(objSensor, this.UserId, out error);
                        if (!string.IsNullOrEmpty(error))
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                        }
                        SensorModel objSensorModel = this.sensorService.GetPlantSensorDetailsBySensorId(objSensor.SensorNumber.Value, this.EcolabAccountNumber);
                        objSensorModel.ModuleTags = this.sensorService.GetModuleTagsDetails(objSensor.SensorNumber.Value, 3, this.EcolabAccountNumber);
                        objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdUpdateSensor, this.EcolabAccountNumber);
                    }
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                }

                if (this.RoleId >= 8)
                {
                    if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                    {
                        if (data[0].OverridePlcValues)
                        {
                            if (ambiguousTags.Any())
                            {
                                plc.WriteTags(new TagCollection { Tags = ambiguousTags }, controllerId.Value);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Sensor - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string result = ex.Message + "#" + objSensor.SensorNumber;
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = result });
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, new { message = data, source = SourcePage.MetersPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
        }

        /// <summary>
        /// Read Sensor Tags For PLC XL
        /// </summary>
        /// <param name="model">Sensor Model</param>
        /// <returns>Sensor Model</returns>
        private WebModel.SensorWebModel ReadSensorTagsForPLCXL(WebModel.SensorWebModel model)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            List<Ecolab.Models.Washers.Washers> washerlist = this.washerService.GetWashersDetails(this.EcolabAccountNumber, model.SensorLocationId.GetValueOrDefault(), false).ToList();

            model.IsTunnel = washerlist.Where(x => x.WasherType.Contains("WasherExtractor")).Count() > 0 ? false : true;
            if (model.IsTunnel)
            {
                model.LfsWasherNumber = washerlist.FirstOrDefault().lfsWasher;
            }
            else
            {
                model.LfsWasherNumber = model.MachineId.HasValue ? washerlist.Where(x => x.Id == model.MachineId.Value).FirstOrDefault().lfsWasher : 0;
            }

            var ambiguosTags = new List<Tag>();
            var appTags = GeneratePlcXlTagsForSensors(model, model.ControllerTypeId, false);//appTags

            if (appTags.Count > 0)
            {
                var plcTagsList = GeneratePlcXlTagsForSensors(model, model.ControllerTypeId, false);//plcTags
                var plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, model.ControllerId.Value, SourcePage.SensorsPage);

                foreach (var appTag in appTags)
                {
                    foreach (var plcTag in plcTags.Tags)
                    {
                        if (appTag.Address == plcTag.Address && appTag.Value != plcTag.Value)
                        {
                            ambiguosTags.Add(appTag);
                        }
                    }
                }
            }

            model.Calibration20Override = ambiguosTags.Where(x => x.TagType.ToUpper() == "CALIBRATION20MA").Count() > 0 ? true : false;
            model.Calibration4Override = ambiguosTags.Where(x => x.TagType.ToUpper() == "CALIBRATION4MA").Count() > 0 ? true : false;
            model.OutputTypeOverride = ambiguosTags.Where(x => x.TagType.ToUpper() == "OUTPUTTYPE").Count() > 0 ? true : false;
            model.SensorTypeOverride = ambiguosTags.Where(x => x.TagType.ToUpper() == "SENSORTYPE").Count() > 0 ? true : false;
            model.MachineCompartmentOverride = ambiguosTags.Where(x => x.TagType.ToUpper() == "MACHINECOMPARTMENT").Count() > 0 ? true : false;

            return model;
        }

        /// <summary>
        /// Read Sensor Tags For EControlPlus
        /// </summary>
        /// <param name="model">Sensor Model</param>
        /// <returns>Sensor Model</returns>
        public WebModel.SensorWebModel ReadSensorTagsForEControlPlus(WebModel.SensorWebModel model)
        {
            List<int> lstvalues = new List<int>();
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);

            var ambiguosTags = new List<Tag>();
            var appTags = FormEcontrolPlusTagsWithValues(model, false);//appTags

            if (appTags.Count > 0)
            {
                var plcTagsList = FormEcontrolPlusTagsWithValues(model, false);//plcTags
                var plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, Convert.ToInt32(model.ControllerId), SourcePage.SensorsPage);

                foreach (var plcTag in plcTags.Tags)
                {
                    if (model.SensorType == 1)
                    {
                        if (plcTag.TagType == "CALIBRATION20MA")
                        {
                            int fisrtplcvalue = Convert.ToInt32(plcTag.Value);

                            model.Calibration20Override = fisrtplcvalue == Convert.ToInt32(model.CalibrationValue20) ? false : true;
                        }
                        else
                        {
                            model.OutputTypeOverride = plcTag.Value == (model.OutputType == "0-20mA" ? "0" : "1") ? false : true;
                        }
                    }
                    else if (model.SensorType == 2)
                    {
                        int fisrtplcvalue = 0;
                        int lastplcvalue = 0;

                        if (plcTag.Value.Length == 5)
                        {
                            fisrtplcvalue = Convert.ToInt32(plcTag.Value.Substring(0, 3)) / 10;
                            lastplcvalue = Convert.ToInt32(plcTag.Value.Substring(3, 2)) / 10;
                        }
                        else if (plcTag.Value.Length == 4)
                        {
                            fisrtplcvalue = Convert.ToInt32(plcTag.Value.Substring(0, 2)) / 10;
                            lastplcvalue = Convert.ToInt32(plcTag.Value.Substring(2, 2)) / 10;
                        }
                        else if (plcTag.Value.Length == 3)
                        {
                            fisrtplcvalue = Convert.ToInt32(plcTag.Value.Substring(0, 3)) / 10;
                        }
                        else if (plcTag.Value.Length == 2)
                        {
                            fisrtplcvalue = Convert.ToInt32(plcTag.Value.Substring(0, 2)) / 10;
                        }
                        else
                        {
                            fisrtplcvalue = Convert.ToInt32(plcTag.Value.Substring(0, 1)) / 10;
                        }
                        model.Calibration20Override = fisrtplcvalue == Convert.ToInt32(model.CalibrationValue20) ? false : true;
                        model.Calibration4Override = lastplcvalue == Convert.ToInt32(model.CalibrationValue4) ? false : true;
                    }
                    else if (model.SensorType == 4)
                    {
                        if (plcTag.TagType == "CALIBRATION20MA")
                        {
                            model.Calibration20Override = plcTag.Value == model.CalibrationValue20.ToString() ? false : true;
                        }
                        else
                        {
                            model.Calibration4Override = plcTag.Value == model.CalibrationValue4.ToString() ? false : true;
                        }
                    }
                }
            }

            return model;
        }
        /// <summary>
        ///     min and max alarm converstion factor
        /// </summary>
        /// <param name="id">min or max alarm values</param>
        /// <param name="data">calibration Value to check conversion factors</param>
        /// <returns>Returns min or max alarm value</returns>
        public decimal WELoggerAnalogAlarmCalCluations(decimal value, decimal calibrationValue, bool isRead)
        {
            if (isRead)
            {
                if (calibrationValue <= 1)
                {
                    value = value / 1000;
                }
                else if (calibrationValue > 1 && calibrationValue <= 10)
                {
                    value = value / 100;
                }
                else if (calibrationValue > 10 && calibrationValue <= 1000)
                {
                    value = value / 10;
                }
                return value;
            }
            else
            {
                if (calibrationValue <= 1)
                {
                    value = value * 1000;
                }
                else if (calibrationValue > 1 && calibrationValue <= 10)
                {
                    value = value * 100;
                }
                else if (calibrationValue > 10 && calibrationValue <= 1000)
                {
                    value = value * 10;
                }
                return value;
            }
        }
        /// <summary>
        ///     min and max alarm converstion factor
        /// </summary>
        /// <param name="id">min or max alarm values</param>
        /// <param name="data">calibration Value to check conversion factors</param>
        /// <returns>Returns min or max alarm value</returns>
        public decimal SetAlarmCalCluations(decimal value, decimal calibrationValue)
        {
            if (calibrationValue <= 1)
            {
                value = value * 1000;
            }
            else if (calibrationValue > 1 && calibrationValue <= 10)
            {
                value = value * 100;
            }
            else if (calibrationValue > 10 && calibrationValue <= 1000)
            {
                value = value * 10;
            }
            return value;
        }
        /// <summary>
        ///     To update the Sensor details
        /// </summary>
        /// <param name="id">Sensor identifier.</param>
        /// <param name="data">Sensor data to update</param>
        /// <returns>Returns updated Sensor data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, WebModel.SensorWebModel data)
        {
            if (id > 0)
            {
                List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
                try
                {
                    SensorModel objSensorModelDetails = this.sensorService.GetPlantSensorDetailsBySensorId(id.Value, this.EcolabAccountNumber);
                    Sensor objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data);
                    objSensor.EcolabAccountNumber = this.EcolabAccountNumber;
                    objSensor.MinimumAlarmValue = WELoggerAnalogAlarmCalCluations(objSensor.MinimumAlarmValue, objSensor.CalibrationValue20,false);
                    objSensor.MaximumAlarmValue = WELoggerAnalogAlarmCalCluations(objSensor.MaximumAlarmValue, objSensor.CalibrationValue20,false);
                    DateTime lastModifiedTimeStamp;
                    string error;
                    objSensor.SensorNumber = this.sensorService.SavePlantSensorDetails(objSensor, this.UserId, out error, out lastModifiedTimeStamp);
                    var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                    Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objSensor.ControllerId.Value, this.EcolabAccountNumber);

                    if (string.IsNullOrWhiteSpace(error))
                    {
                        if (objSensor.SensorNumber.Value > 0)
                        {
                            SensorModel objSensorModel = this.sensorService.GetPlantSensorDetailsBySensorId(objSensor.SensorNumber.Value, this.EcolabAccountNumber);
                            objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdUpdateSensor, this.EcolabAccountNumber);
                            objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel
                            {
                                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Sensors),
                                ParentEntityId = Convert.ToInt32(objSensorModel.SensorId),
                                Entity = Convert.ToInt32(PlcDiscrepancyEntity.Sensors),
                                EntityId = Convert.ToInt32(objSensorModel.SensorId),
                                IsCentral = false,
                                ControllerId = controllerDetails.ControllerId,
                                UserId = this.UserId,
                                LastModifiedUserId = this.UserId
                            });
                            try
                            {
                                WebModel.SensorWebModel sensorWebModelDetails = Mapper.Map<SensorModel, WebModel.SensorWebModel>(objSensorModelDetails);
                                WebModel.SensorWebModel sensorWebModel = Mapper.Map<SensorModel, WebModel.SensorWebModel>(objSensorModel);
                                if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                                {
                                    plc.WriteMyControlSettingsForSensors(sensorWebModelDetails, objSensor.ControllerId.Value, true);
                                    plc.WriteMyControlSettingsForSensors(sensorWebModel, objSensor.ControllerId.Value, false);
                                }
                                else if (controllerDetails.ControllerModelId == 11)
                                {
                                    var resetTags = GeneratePlcXlTagsForSensors(sensorWebModelDetails, controllerDetails.ControllerTypeId, true);
                                    var tags = GeneratePlcXlTagsForSensors(sensorWebModel, controllerDetails.ControllerTypeId, false);
                                    resetTags.AddRange(tags);

                                    if (resetTags.Count > 0)
                                    {
                                        plc.WriteTags(new TagCollection { Tags = resetTags }, controllerDetails.ControllerId, SourcePage.SensorsPage);
                                    }
                                }
                                else if (controllerDetails.ControllerModelId == 8)
                                {
                                    List<Tag> resetTags = FormEcontrolPlusTagsWithValues(sensorWebModelDetails, true);
                                    if (resetTags.Count > 0)
                                    {
                                        plc.WriteEControlPlusTagsWithRandomArray(resetTags, controllerDetails.ControllerId);
                                    }

                                    List<Tag> tags = FormEcontrolPlusTagsWithValues(sensorWebModel, false);
                                    if (tags.Count > 0)
                                    {
                                        plc.WriteEControlPlusTagsWithRandomArray(tags, controllerDetails.ControllerId);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.Contains("Timeout has elapsed") ||
                                    ex.Message.Contains("Port is disabled") ||
                                    ex.Message.Contains("Target machine could not be found") ||
                                    ex.Message.Contains("ADS could not be initialized") ||
                                    ex.Message.Contains("Open Failed") ||
                                    ex.Message.Contains("Retrieving the COM class factory"))
                                {
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "901" });
                                }
                                else
                                {
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = "902" });
                                }
                            }
                            objSensorModel.ModuleTags = this.sensorService.GetModuleTagsDetails(objSensor.SensorNumber.Value, 3, this.EcolabAccountNumber);
                            this.sensorService.UpdatePlantSensorTags(objSensor, this.UserId, out error);
                            if (!string.IsNullOrEmpty(error))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                            }
                            objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdUpdateSensor, this.EcolabAccountNumber);
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error });
                    }
                    var ambiguousTags = new List<Tag>();
                    TagCollection tagStatus = new TagCollection();
                    if (this.RoleId >= 8)
                    {
                        if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                        {
                            var tagsList = new List<OpcTag>();
                            if (!string.IsNullOrEmpty(data.AnalogueImputNumber))
                            {
                                tagsList.Add(new OpcTag { Address = data.AnalogueImputNumber });
                            }

                            if (!string.IsNullOrEmpty(data.CalibrationTag4))
                            {
                                tagsList.Add(new OpcTag
                                {
                                    Address = data.CalibrationTag4,
                                    Value = data.CalibrationValue4.ToString()
                                });
                            }

                            if (!string.IsNullOrEmpty(data.CalibrationTag20))
                            {
                                tagsList.Add(new OpcTag
                                {
                                    Address = data.CalibrationTag20,
                                    Value = data.CalibrationValue20.ToString()
                                });
                            }
                            string errorCode = null;
                            var tags = new TagCollection();
                            if (tagsList.Any())
                            {
                                tags.Tags = new List<Tag>(tagsList.Clone());
                                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, data.ControllerId.Value);

                                foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                                {
                                    if (status.Address == data.AnalogueImputNumber)
                                    {
                                        errorCode += "801,";
                                    }
                                    if (status.Address == data.CalibrationTag4)
                                    {
                                        errorCode += "802,";
                                    }
                                    if (status.Address == data.CalibrationTag20)
                                    {
                                        errorCode += "803,";
                                    }
                                }
                            }
                            var message = new StringBuilder();
                            if (tags.Tags != null)
                            {
                                foreach (Tag tag in tags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                    {
                                        if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                                        {
                                            message.Append(
                                                string.Format(
                                                    "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.{3}",
                                                    tag.Address, tag.Value, plcTag.Value, Environment.NewLine));
                                            ambiguousTags.Add(tag);
                                        }
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(errorCode))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode });
                            }

                            if (!data.OverridePlcValues && !string.IsNullOrWhiteSpace(message.ToString()))
                            {
                                message.Append("Do you want to override the value in plc ?");
                                return this.Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = message.ToString() });
                            }
                        }
                    }
                    if (string.IsNullOrWhiteSpace(error))
                    {
                        if (objSensor.SensorNumber.Value > 0)
                        {
                            SensorModel objSensorModel = this.sensorService.GetPlantSensorDetailsBySensorId(objSensor.SensorNumber.Value, this.EcolabAccountNumber);
                            objSensorModel.ModuleTags = this.sensorService.GetModuleTagsDetails(objSensor.SensorNumber.Value, 3, this.EcolabAccountNumber);
                            this.sensorService.UpdatePlantSensorTags(objSensor, this.UserId, out error);
                            if (!string.IsNullOrEmpty(error))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error + "#" + objSensor.SensorNumber });
                            }
                            objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdUpdateSensor, this.EcolabAccountNumber);
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = error });
                    }
                    if (this.RoleId >= 8)
                    {
                        if (!(controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2))
                        {
                            if (data.OverridePlcValues)
                            {
                                if (ambiguousTags.Any())
                                {
                                    plc.WriteTags(new TagCollection { Tags = ambiguousTags }, data.ControllerId.Value);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Sensor - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message });
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, new { message = data, source = SourcePage.SensorsPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid Sensor details.");
        }

        /// <summary>
        ///     To update the Sensor details
        /// </summary>
        /// <param name="data">Sensor data to update</param>
        /// <returns>Status Message</returns>
        [HttpPut]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage Put(List<WebModel.SensorWebModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.SensorWebModel SensorWebModel in data)
            {
                HttpResponseMessage = this.Put(SensorWebModel.SensorNumber, SensorWebModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Method to set all the default dropdown values
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Returns Dictionary object</returns>
        [HttpGet]
        public Dictionary<string, object> GetDefaults(int? id)
        {
            int? machineId = null;
            int? locationId = null;
            int? controllerId = null;
            //SensorModel objsensor = null;
            WebModel.SensorWebModel sensor = null;
            var sensorData = new Dictionary<string, object>();
            if (id != null)
            {
                List<Sensor> sensors = this.sensorService.GetPlantSensorDetails(null, this.EcolabAccountNumber);
                List<WebModel.SensorWebModel> sensorList = Mapper.Map<List<Sensor>, List<WebModel.SensorWebModel>>(sensors);
                sensor = sensorList.FirstOrDefault(a => a.SensorNumber == id);
                List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(sensor.SensorLocationId, sensor.MachineId, this.EcolabAccountNumber);
                List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);
                IEnumerable<WebModel.MachineSetupModel> machineList = this.GetMachineOrCompartment(sensor.SensorLocationId, Convert.ToInt32(sensor.SensorType));
                // set is tunnel
                IEnumerable<WebModel.UOMSensorModel> uomList = this.GetUomSensorDetails(sensor.SensorType);
                sensorData.Add("Sensor", sensor);
                sensorData.Add("SensorController", controllerList);
                sensorData.Add("MachineList", machineList);
                sensorData.Add("UoMList", uomList);
                sensorData.Add("Counters", this.sensorService.FetchCounters(sensor.SensorLocationId, sensor.MachineId, sensor.SensorType.HasValue ? sensor.SensorType.Value.ToString() : string.Empty, sensor.IsTunnel, false, this.EcolabAccountNumber, id, sensor.ControllerId));

                locationId = sensor.SensorLocationId;
                machineId = sensor.MachineId;
                controllerId = sensor.ControllerId;
            }
            else
            {
                List<ConduitController> controller = this.sensorService.GetConduitControllerDetails(null, null, this.EcolabAccountNumber);
                List<WebModel.ConduitControllerModel> controllerList = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);
                sensorData.Add("SensorController", controllerList);
            }

            IEnumerable<WebModel.SensorChemicalChartModel> chemicalsList = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, this.EcolabAccountNumber)).AsEnumerable();
            sensorData.Add("ChemicalList", chemicalsList);
            List<SensorType> sensorType = this.sensorService.GetSensorTypeDetails();
            List<WebModel.SensorTypeModel> sensorTypeList = Mapper.Map<List<SensorType>, List<WebModel.SensorTypeModel>>(sensorType);
            List<GroupType> utilityLocations = this.sensorService.GetGroupTypeDetails(this.EcolabAccountNumber);
            List<WebModel.GroupTypeModel> utilityLocationsList = Mapper.Map<List<GroupType>, List<WebModel.GroupTypeModel>>(utilityLocations);
            sensorData.Add("SensorType", sensorTypeList);
            sensorData.Add("SensorLocation", utilityLocationsList);
            if (sensor != null)
            {
                sensor.MinimumAlarmValue = WELoggerAnalogAlarmCalCluations(sensor.MinimumAlarmValue, sensor.CalibrationValue20, true);
                sensor.MaximumAlarmValue = WELoggerAnalogAlarmCalCluations(sensor.MaximumAlarmValue, sensor.CalibrationValue20, true);
            }
            try
            {
                if (sensor.ControllerModelId == 11)
                {
                    sensor = ReadSensorTagsForPLCXL(sensor);
                }
                else if (sensor.ControllerModelId == 8)
                {
                    sensor = ReadSensorTagsForEControlPlus(sensor);
                }
            }
            catch
            {
                return sensorData;
            }

            return sensorData;
        }

        /// <summary>
        ///     Method to Get sensor Machine or Compartment based on location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>Machines or compartments</returns>
        [HttpGet]
        public IEnumerable<WebModel.MachineSetupModel> GetMachineOrCompartment(int? id, int sensorTypeId = 0)
        {
            List<MachineSetup> machineOrCompartment = this.sensorService.GetPlantMachineDetails(id, this.EcolabAccountNumber, sensorTypeId);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);
            return machineOrCompartmentList.AsEnumerable();
        }

        /// <summary>
        ///     Method to Get UoM based on location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <returns>list of UOM's</returns>
        [HttpGet]
        public IEnumerable<WebModel.UOMSensorModel> GetUomSensorDetails(int? id)
        {
            List<UOMSensor> uom = this.sensorService.GetUomSensorDetails(id);
            List<WebModel.UOMSensorModel> uomList = Mapper.Map<List<UOMSensor>, List<WebModel.UOMSensorModel>>(uom);
            return uomList.AsEnumerable();
        }

        /// <summary>
        ///     Method to get Controller and Machine values based on Sensor Location
        /// </summary>
        /// <param name="id">id of the location</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>Machines/Compartments</returns>
        [HttpGet]
        public Dictionary<string, object> GeOnLocationChange(int id, int sensorTypeId = 0)
        {
            List<MachineSetup> machineOrCompartment = this.sensorService.GetPlantMachineDetails(id, this.EcolabAccountNumber, sensorTypeId);
            List<WebModel.MachineSetupModel> machineOrCompartmentList = Mapper.Map<List<MachineSetup>, List<WebModel.MachineSetupModel>>(machineOrCompartment);

            List<ConduitController> controller = (id > 0)
                ? this.sensorService.GetConduitControllerDetails(id, null, this.EcolabAccountNumber)
                : this.sensorService.GetConduitControllerDetails(null, null, this.EcolabAccountNumber);
            List<WebModel.ConduitControllerModel> controllerList =
                Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(controller);

            List<WebModel.SensorChemicalChartModel> chemicalForChart = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(id, null, null, this.EcolabAccountNumber));
            var controllerData = new Dictionary<string, object>
            {
                { "Controller", controllerList },
                { "Machine", machineOrCompartmentList },
                { "ChemicalForChart", chemicalForChart }
            };
            return controllerData;
        }

        /// <summary>
        ///     Method to get UoM values on Sensor Type change
        /// </summary>
        /// <param name="id">id of the sensor type</param>
        /// <returns>UOM's assosiated to the sensor</returns>
        [HttpGet]
        public Dictionary<string, object> GeOnSensorTypeChange(int id)
        {
            List<UOMSensor> uom = sensorService.GetUomSensorDetails(id);
            List<WebModel.UOMSensorModel> uomList = Mapper.Map<List<UOMSensor>, List<WebModel.UOMSensorModel>>(uom);
            var uomData = new Dictionary<string, object> { { "UoM", uomList } };
            return uomData;
        }

        /// <summary>
        ///     Method to get on Controller Change
        /// </summary>
        /// <param name="locationId">The Locaion Id</param>
        /// <param name="machineId">id of the machine/compartment</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>Chemicals for chart</returns>
        [HttpGet]
        public IEnumerable<WebModel.SensorChemicalChartModel> GetOnControllerChange(int? locationId, int? machineId, int controllerId)
        {
            return Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, this.EcolabAccountNumber)).AsEnumerable();
        }

        /// <summary>
        ///     Gets data on machine Dropdown change
        /// </summary>
        /// <param name="locationId">The Location Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns>List of SensorChemicalChartModel and ConduitControllerModel</returns>
        [HttpGet]
        public Dictionary<string, object> GetOnMachineCompartmentChange(int? locationId, int? machineId, int sensorTypeId = 0)
        {
            int controllerId = 0;
            MachineSetup machine = this.sensorService.GetPlantMachineDetails(locationId, this.EcolabAccountNumber, sensorTypeId).FirstOrDefault(_ => _.MachineId == machineId);
            if (machine != null)
            {
                controllerId = machine.ControllerId;
            }

            List<WebModel.ConduitControllerModel> controller = Mapper.Map<List<ConduitController>, List<WebModel.ConduitControllerModel>>(this.sensorService.GetConduitControllerDetails(locationId, machineId, this.EcolabAccountNumber));

            List<WebModel.SensorChemicalChartModel> chemicalForChart = Mapper.Map<List<SensorChemicalChart>, List<WebModel.SensorChemicalChartModel>>(this.sensorService.GetSensorChemicalChartDetails(locationId, machineId, controllerId, this.EcolabAccountNumber));
            return new Dictionary<string, object> { { "ChemicalForChart", chemicalForChart }, { "Controller", controller } };
        }

        /// <summary>
        ///     Delete the Sensor
        /// </summary>
        /// <param name="id">Delete the Sensor based on ID</param>
        /// <param name="data">The Sensor Model Data</param>
        /// <returns>Returns the Sensor data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteSensor(int? id, WebModel.SensorWebModel data)
        {
            if (id > 0)
            {
                Sensor objSensor = Mapper.Map<WebModel.SensorWebModel, Sensor>(data);
                try
                {
                    DateTime lastModifiedTimeStamp;
                    int error;
                    int response = this.sensorService.DeletePlantSensorDetails(objSensor, this.UserId, out error, out lastModifiedTimeStamp);
                    if (error <= 0)
                    {
                        if (response > 0 && objSensor.SensorNumber.Value > 0)
                        {
                            SensorModel objSensorModel = this.sensorService.GetPlantSensorDetailsBySensorId(objSensor.SensorNumber.Value, this.EcolabAccountNumber);
                            objSensorModel.ModuleTags = this.sensorService.GetModuleTagsDetails(objSensor.SensorNumber.Value, 3, this.EcolabAccountNumber);
                            objSensorModel.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objSensorModel, this.UserId, objSensorModel.SensorId.Value, (int)TcdAdminMessageTypes.TcdDeleteSensor, this.EcolabAccountNumber);

                            try
                            {
                                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(objSensor.ControllerId.Value, this.EcolabAccountNumber);

                                WebModel.SensorWebModel sensorWebModel = Mapper.Map<SensorModel, WebModel.SensorWebModel>(objSensorModel);

                                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                                if (controllerDetails.ControllerModelId == 7 && controllerDetails.ControllerTypeId == 2)
                                {
                                    plc.WriteMyControlSettingsForSensors(sensorWebModel, objSensor.ControllerId.Value, true);
                                }
                                else if (controllerDetails.ControllerModelId == 11)
                                {
                                    var resetTags = GeneratePlcXlTagsForSensors(sensorWebModel, controllerDetails.ControllerTypeId, true);
                                    if (resetTags.Count > 0)
                                    {
                                        plc.WriteTags(new TagCollection { Tags = resetTags }, controllerDetails.ControllerId, SourcePage.SensorsPage);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                                return this.Request.CreateResponse(HttpStatusCode.OK);
                            }
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, error);
                    }
                }
                catch (Exception)
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest);
                }
                return this.Request.CreateResponse(HttpStatusCode.OK);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Deletion failed. Invalid sensor details.");
        }

        /// <summary>
        ///     Method to delete sensor
        /// </summary>
        /// <param name="data">Sensor Model</param>
        /// <returns>Whether sensor deleted or not</returns>
        public HttpResponseMessage DeleteSensor(List<WebModel.SensorWebModel> data)
        {
            return this.DeleteSensor(data[0].SensorNumber, data[0]);
        }

        /// <summary>
        /// Fetches the external or internal counter
        /// </summary>
        /// <param name="locationId">The locationId</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="utilityTypeId">Utility Type Id</param>
        /// <param name="isTunnel">Is Tunnel</param>
        /// <param name="sensorId">Sensor Id</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns></returns>        
        [HttpGet]
        public Dictionary<string, string> FetchCounters(int? locationId, int? washerId, string utilityTypeId, bool isTunnel, int? sensorId, int? controllerId)
        {
            return this.sensorService.FetchCounters(locationId, washerId, utilityTypeId, isTunnel, false, this.EcolabAccountNumber, sensorId, controllerId);
        }

        /// <summary>
        /// Generate PlcXl Tags For Sensors
        /// </summary>
        /// <param name="sensor"Sensor Web Model></param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <param name="isReset">is Reset Tags</param>
        /// <returns>List of Tags</returns>
        public List<Tag> GeneratePlcXlTagsForSensors(Ecolab.ConduitLocal.Web.Models.PlantSetup.SensorWebModel sensor, int controllerTypeId, bool isReset)
        {
            List<Tag> tags = new List<Tag>();

            if (sensor.LfsWasherNumber != 0)
            {
                int tempWEIndex = ((controllerTypeId == 12) ? 1011 : controllerTypeId == 13 ? 3691 : 0) + ((sensor.LfsWasherNumber - 1));

                int tempTUNIndex = ((controllerTypeId == 14 && sensor.LfsWasherNumber == 1) ? 2380 : (controllerTypeId == 14 && sensor.LfsWasherNumber == 2) ? 2383 : (controllerTypeId == 13) ? 3696 : 0) + (sensor.SensorNum - 1);

                int tempOutputWEIndex = (controllerTypeId == 12 || controllerTypeId == 13) ? 731 : 0;

                int tempOutputTUNIndex = ((controllerTypeId == 14 && sensor.LfsWasherNumber == 1) ? 731 : (controllerTypeId == 14 && sensor.LfsWasherNumber == 2) ? 734 : (controllerTypeId == 13) ? 736 : 0) + (sensor.SensorNum - 1);

                int sensorpHWEIndex0mA = (controllerTypeId == 12 ? 1021 : controllerTypeId == 13 ? 2000 : 0) + (sensor.LfsWasherNumber - 1);

                int sensorpHWEIndex20mA = (controllerTypeId == 12 ? 1031 : controllerTypeId == 13 ? 2005 : 0) + (sensor.LfsWasherNumber - 1);

                int weightWEIndex = ((controllerTypeId == 12 || (controllerTypeId == 13)) ? 320 : 0) + ((sensor.LfsWasherNumber - 1) * 30);

                int weightTUNIndex = ((controllerTypeId == 14 && sensor.LfsWasherNumber == 1) ? 1722 : (controllerTypeId == 14 && sensor.LfsWasherNumber == 2) ? 1724 : (controllerTypeId == 13) ? 2011 : 0);

                int compartmentTUNIndex = ((controllerTypeId == 14 && sensor.LfsWasherNumber == 1) ? 1723 : (controllerTypeId == 14 && sensor.LfsWasherNumber == 2) ? 1725 : (controllerTypeId == 13) ? 2012 : 0);

                int scaleConnectedWEIndex = ((controllerTypeId == 12 || (controllerTypeId == 13)) ? 741 : 0) + ((sensor.LfsWasherNumber - 1));

                if (sensor.SensorType == 1)//Temperature
                {
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("R{0}", (sensor.IsTunnel == true ? tempTUNIndex : tempWEIndex)),
                        Value = isReset ? "0" : Convert.ToUInt32(sensor.CalibrationValue20).ToString(),
                        TagType = "CALIBRATION20MA"
                    });
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("L{0}", (sensor.IsTunnel == true ? tempOutputTUNIndex : tempOutputWEIndex)),
                        Value = isReset ? "0" : sensor.OutputType.Equals("0-20mA") ? "0" : "1",
                        TagType = "OUTPUTTYPE"
                    });
                }
                else if (sensor.SensorType == 2 && sensor.IsTunnel == false)//pH
                {
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("R{0}", (sensorpHWEIndex0mA)),
                        Value = isReset ? "0" : (Convert.ToUInt32(sensor.CalibrationValue4)).ToString(),
                        TagType = "CALIBRATION4MA"
                    });
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("R{0}", (sensorpHWEIndex20mA)),
                        Value = isReset ? "0" : (Convert.ToUInt32(sensor.CalibrationValue20)).ToString(),
                        TagType = "CALIBRATION20MA"
                    });
                }
                else if (sensor.SensorType == 5)//Weight
                {
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("R{0}", (sensor.IsTunnel == true ? weightTUNIndex : weightWEIndex)),
                        Value = isReset ? "0" : Convert.ToUInt32(sensor.CalibrationValue20).ToString(),
                        TagType = "CALIBRATION20MA"
                    });
                }
                if (sensor.IsTunnel == true)
                {
                    //Compartment Number
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("R{0}", compartmentTUNIndex),
                        Value = (isReset ? "0" : (sensor.MachineId.HasValue ? Convert.ToUInt32(sensor.MachineId).ToString() : "0")),
                        TagType = "MACHINECOMPARTMENT"
                    });
                }
                if (sensor.IsTunnel == false)
                {
                    //Scale Connected, applicable only for conventional Type. If Weight then 1 else 0
                    tags.Add(new MitsubishiTag
                    {
                        Address = string.Format("L{0}", scaleConnectedWEIndex),
                        Value = isReset ? "0" : sensor.SensorType == 5 ? "1" : "0",
                        TagType = "SCALECONNECTED"
                    });
                }
            }

            return tags;
        }

        /// <summary>
        /// Form EcontrolPlus Tags With Values
        /// </summary>
        /// <param name="objSensorModelDetails"Sensor Model Details></param>
        /// <param name="isReset">is Reset Tags</param>
        /// <returns>List of Tags</returns>
        public List<Tag> FormEcontrolPlusTagsWithValues(WebModel.SensorWebModel objSensorModelDetails, bool isReset)
        {
            try
            {
                List<Tag> tags = new List<Tag>();
                if (objSensorModelDetails != null)
                {
                    if (objSensorModelDetails.LfsWasherNumber != 0)
                    {
                        if (objSensorModelDetails.IsTunnel == false)
                        {
                            if (objSensorModelDetails.SensorType == 1)
                            {
                                if (objSensorModelDetails.CalibrationValue20 != 0)
                                {
                                    tags.AddRange(new List<MitsubishiTag>() { new MitsubishiTag { Address = "D" + (449 + objSensorModelDetails.LfsWasherNumber), Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20).ToString(), TagType = "CALIBRATION20MA" }, new MitsubishiTag { Address = "M" + (978 + objSensorModelDetails.LfsWasherNumber), Value = isReset ? "0" : objSensorModelDetails.OutputType == "0-20mA" ? "0" : "1", TagType = "OUTPUTTYPE" } });
                                }
                            }
                            if (objSensorModelDetails.SensorType == 2)
                            {
                                if (objSensorModelDetails.CalibrationValue20 != 0 && objSensorModelDetails.CalibrationValue4 != 0)
                                {
                                    tags.Add(new MitsubishiTag { Address = "D" + (391 + objSensorModelDetails.LfsWasherNumber), Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20 * 10) + string.Empty + Convert.ToInt32(objSensorModelDetails.CalibrationValue4 * 10), TagType = "CALIBRATION20MA" });
                                }
                            }
                        }
                        else
                        {
                            if (objSensorModelDetails.SensorType == 1)
                            {
                                if (objSensorModelDetails.CalibrationValue20 != 0)
                                {
                                    if (objSensorModelDetails.SensorNum == 1)
                                    {
                                        tags.AddRange(new List<MitsubishiTag>() { new MitsubishiTag { Address = "D456", Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20).ToString(), TagType = "CALIBRATION20MA" }, new MitsubishiTag { Address = "M985", Value = objSensorModelDetails.OutputType == "0-20mA" ? "0" : "1", TagType = "OUTPUTTYPE" } });
                                    }
                                    else
                                    {
                                        tags.AddRange(new List<MitsubishiTag>() { new MitsubishiTag { Address = "D457", Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20).ToString(), TagType = "CALIBRATION20MA" }, new MitsubishiTag { Address = "M986", Value = isReset ? "0" : objSensorModelDetails.OutputType == "0-20mA" ? "0" : "1", TagType = "OUTPUTTYPE" } });
                                    }
                                }
                            }
                            else if (objSensorModelDetails.SensorType == 2)
                            {
                                if (objSensorModelDetails.CalibrationValue20 != 0)
                                {
                                    tags.Add(new MitsubishiTag { Address = "D398", Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20 * 10) + string.Empty + Convert.ToInt32(objSensorModelDetails.CalibrationValue4 * 10), TagType = "CALIBRATION20MA" });
                                }
                            }
                            else if (objSensorModelDetails.SensorType == 4)
                            {
                                if (objSensorModelDetails.CalibrationValue20 != 0)
                                {
                                    tags.Add(new MitsubishiTag { Address = "D459", Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue20 * 100).ToString(), TagType = "CALIBRATION20MA" });
                                }
                                if (objSensorModelDetails.CalibrationValue4 != 0)
                                {
                                    tags.Add(new MitsubishiTag { Address = "D458", Value = isReset ? "0" : Convert.ToInt32(objSensorModelDetails.CalibrationValue4 * 100).ToString(), TagType = "CALIBRATION4MA" });
                                }
                            }
                        }
                    }
                }
                return tags;
            }
            catch (Exception ex)
            {
                this.Logger.Error("Error occured while creating econtrol+ tags :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return null;
            }
        }
    }
}