﻿namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    public class PlcDiscrepancyController : BaseApiController
    {
        /// <summary>
        /// The Plc Service
        /// </summary>        
        private readonly IPlcService plcService;
        /// <summary>
        /// Initializes the PlcDiscrepancyController
        /// </summary>
        /// <param name="userService">The User service object</param>
        /// <param name="plantService">The plant service object</param>
        /// <param name="plcService">The plc service object</param>
        public PlcDiscrepancyController(IUserService userService, IPlantService plantService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.plcService = plcService;
        }
        /// <summary>
        /// Fetches the Plc Discrepancy count
        /// </summary>
        /// <returns>The Plc Discrepancy count</returns>
        [HttpPost]
        public int FetchPlcDiscrepancyCount()
        {
            return plcService.FetchPlcDiscrepancyData().Count();
        }
    }
}