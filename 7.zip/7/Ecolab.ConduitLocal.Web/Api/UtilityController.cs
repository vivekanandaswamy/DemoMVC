﻿// -----------------------------------------------------------------------
// <copyright file="UtilityController.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Utility Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.Common;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using WebModel = Models.PlantSetup;

    /// <summary>
    ///     Api controller for Utility
    /// </summary>
    public class UtilityController : BaseApiController
    {
        /// <summary>
        ///     Meter Service
        /// </summary>
        private readonly IUtilityService utilityService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="UtilityController" /> class.
        /// </summary>
        /// <param name="userService"> the user service </param>
        /// <param name="utilityService">the utility service </param>
        /// <param name="plantService">Plant Service</param>
        public UtilityController(IUserService userService, IUtilityService utilityService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.utilityService = utilityService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// Gets or sets List of utilities
        /// </summary>
        /// <value>The utility list.</value>
        public static List<Utility> Utilities { get; set; }

        /// <summary>
        ///     GET api/utility
        /// </summary>
        /// <returns>List of Utility Model</returns>
        [HttpGet]
        public IEnumerable<WebModel.UtilityModel> GetUtility()
        {
            Utilities = utilityService.GetUtilityDetails(EcolabAccountNumber, null);
            List<WebModel.UtilityModel> utilityList = Mapper.Map<List<Utility>, List<WebModel.UtilityModel>>(Utilities);
            return utilityList.AsEnumerable();
        }

        /// <summary>
        ///     Get utility details for edit
        /// </summary>
        /// <returns>The dictonary.</returns>
        [HttpGet]
        public Dictionary<string, object> GetUtilityOnAddNew()
        {
            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();
            List<WebModel.DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<WebModel.DeviceTypeModel>>(deviceTypes);

            var utilityData = new Dictionary<string, object> { { "DeviceType", deviceTypeList }, { "DeviceNumber", Utilities.Max(x => x.DeviceNumber) != null ? Utilities.Max(x => x.DeviceNumber) + 1 : 1 } };

            return utilityData;
        }

        /// <summary>
        ///     Get utility details for edit
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [HttpGet]
        public Dictionary<string, object> GetUtilityOnEdit(int id)
        {
            List<Utility> utilities = utilityService.GetUtilityDetails(EcolabAccountNumber, null);

            Mapper.CreateMap<Utility, WebModel.UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
                        {
                            DateTime dt = src.InstallDate;
                            return string.Format("{0:MM'/'dd'/'yyyy}", dt);
                        }));
            List<WebModel.UtilityModel> utilityList = Mapper.Map<List<Utility>, List<WebModel.UtilityModel>>(utilities);
            WebModel.UtilityModel utility = utilityList.FirstOrDefault(a => a.Id == id);

            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();
            List<WebModel.DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<WebModel.DeviceTypeModel>>(deviceTypes);

            List<DeviceModel> deviceModels = this.utilityService.GetDeviceModelDetails(utility.DeviceTypeId, this.EcolabAccountNumber);
            List<WebModel.DevicemodelModel> deviceModelList = Mapper.Map<List<DeviceModel>, List<WebModel.DevicemodelModel>>(deviceModels);

            var utilityData = new Dictionary<string, object> { { "Utility", utility }, { "DeviceType", deviceTypeList }, { "DeviceModel", deviceModelList } };
            return utilityData;
        }

        /// <summary>
        ///     GET Device type details
        /// </summary>
        /// <returns>IEnumerable DeviceTypeModel</returns>
        [HttpGet]
        public IEnumerable<WebModel.DeviceTypeModel> GetDeviceTypeDetails()
        {
            List<DeviceType> deviceTypes = this.utilityService.GetDeviceTypeDetails();

            List<WebModel.DeviceTypeModel> deviceTypeList = Mapper.Map<List<DeviceType>, List<WebModel.DeviceTypeModel>>(deviceTypes);
            return deviceTypeList.AsEnumerable();
        }

        /// <summary>
        ///     GET Device model details
        /// </summary>
        /// <param name="id">Parameter Id</param>
        /// <returns>List of DeviceModel</returns>
        [HttpGet]
        public IEnumerable<WebModel.DevicemodelModel> GetDeviceModelDetails(int id)
        {
            List<DeviceModel> deviceModels = this.utilityService.GetDeviceModelDetails(id, this.EcolabAccountNumber);

            List<WebModel.DevicemodelModel> deviceModelList = Mapper.Map<List<DeviceModel>, List<WebModel.DevicemodelModel>>(deviceModels);
            return deviceModelList.AsEnumerable();
        }

        /// <summary>
        ///     creates the new utility data
        /// </summary>
        /// <param name="data">Utility data to create</param>
        /// <returns>Returns the created utility data</returns>
        [HttpPost]
        public HttpResponseMessage CreateUtility([FromBody] List<WebModel.UtilityModel> data)
        {
            try
            {
                DateTime dateTime;
                bool deviceNumberExists = Utilities.Any(x => x.DeviceNumber == data[0].DeviceNumber);
                if (!deviceNumberExists)
                {
                    if (DateTime.TryParse(data[0].InstallDate, out dateTime))
                    {
                        Utility objUtility = Mapper.Map<WebModel.UtilityModel, Utility>(data[0]);
                        IPrincipal user = HttpContext.Current.User;

                        if (user != null)
                        {
                            DateTime lastModifiedTimeStamp;
                            objUtility.EcolabAccountNumber = this.EcolabAccountNumber;
                            objUtility.MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid();
                            objUtility.InstallDate = DateTime.SpecifyKind(objUtility.InstallDate, DateTimeKind.Utc);
                            objUtility.Id = this.utilityService.SaveUtilityDetails(objUtility, this.UserId, out lastModifiedTimeStamp);
                            objUtility.LastModifiedTimeStamp = lastModifiedTimeStamp;
                            if (objUtility.DeviceNumber > 0)
                            {
                                Push.PushToQueue(objUtility, this.UserId, (int)objUtility.DeviceNumber, (int)TcdAdminMessageTypes.TcdAddUtility, this.EcolabAccountNumber);
                            }
                        }
                    }
                    else
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid install date. Please try again");
                    }
                }
                else
                {
                    //501 - Device number already exists
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "501");
                }
            }
            catch (SqlException sqlEx)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlEx.Message);
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Utility - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Utility already exist. Please enter new utility.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     update the utility details
        /// </summary>
        /// <param name="id">device number</param>
        /// <param name="data">Utility data</param>
        /// <returns>Http response message</returns>
        [HttpPut]
        public HttpResponseMessage Put(int? id, WebModel.UtilityModel data)
        {
            if (id > 0)
            {
                try
                {
                    DateTime dateTime;
                    int deviceNumberExists = Utilities.Count(x => (x.DeviceNumber == data.DeviceNumber) && (x.Id != data.Id));
                    if (deviceNumberExists == 0)
                    {
                        if (DateTime.TryParse(data.InstallDate, out dateTime))
                        {
                            Utility objUtility = Mapper.Map<WebModel.UtilityModel, Utility>(data);
                            IPrincipal user = HttpContext.Current.User;

                            if (user != null)
                            {
                                objUtility.EcolabAccountNumber = this.EcolabAccountNumber;
                                DateTime lastModifiedTimeStamp;
                                objUtility.DeviceNumber = utilityService.SaveUtilityDetails(objUtility, UserId, out lastModifiedTimeStamp);
                                objUtility.InstallDate = DateTime.SpecifyKind(objUtility.InstallDate, DateTimeKind.Utc);
                                objUtility.LastModifiedTimeStamp = lastModifiedTimeStamp;
                                if (objUtility.DeviceNumber > 0)
                                {
                                    Push.PushToQueue(objUtility, this.UserId, (int)objUtility.DeviceNumber, (int)TcdAdminMessageTypes.TcdUpdateUtility, this.EcolabAccountNumber);
                                }
                            }
                        }
                        else
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid install date. Please try again");
                        }
                    }
                    else
                    {
                        //501 - Device number already exists
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "501");
                    }
                }
                catch (SqlException ex)
                {
                    this.Logger.Error("Api - Utility - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    if (ex.Number == 2627)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Utility already exists. Please try again.");
                    }

                    if (ex.Message == "401")
                    {
                        return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                    }
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the utility. Some error has occured. Please try again.");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, data);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid utility details.");
        }

        /// <summary>
        ///     To update the utility details
        /// </summary>
        /// <param name="data">Utility data to update</param>
        /// <returns>Returns the updated utility data</returns>
        public HttpResponseMessage Put(List<WebModel.UtilityModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (WebModel.UtilityModel UtilityModel in data)
            {
                HttpResponseMessage = this.Put(UtilityModel.DeviceNumber, UtilityModel);
            }
            return HttpResponseMessage;
        }

        /// <summary>
        ///     Delete the Utility data
        /// </summary>
        /// <param name="id">Device Number</param>
        /// <param name="data">The Utility Model Data</param>
        /// <returns>the deleted data</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteUtility(int? id, WebModel.UtilityModel data)
        {
            if (id > 0)
            {
                try
                {
                    Utility objUtility = Mapper.Map<WebModel.UtilityModel, Utility>(data);
                    IPrincipal user = HttpContext.Current.User;
                    if (user != null)
                    {
                        objUtility.EcolabAccountNumber = this.EcolabAccountNumber;

                        DateTime lastModifiedTimeStamp;
                        objUtility.DeviceNumber = utilityService.DeleteUtilityDetails(id.Value, UserId, EcolabAccountNumber, out lastModifiedTimeStamp);
                        objUtility.LastModifiedTimeStamp = lastModifiedTimeStamp;
                        objUtility.IsDeleted = true;
                        if (objUtility.DeviceNumber > 0)
                        {
                            Push.PushToQueue<Utility>(objUtility, UserId, (int)objUtility.DeviceNumber, (int)TcdAdminMessageTypes.TcdDeleteUtility, EcolabAccountNumber);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Utility - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the utility. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid utility details.");
        }

        /// <summary>
        ///     Delete the Meter data
        /// </summary>
        /// <param name="data">Delete the Meter datas</param>
        /// <returns>Returns the deleted data by Id</returns>
        public HttpResponseMessage DeleteUtility(List<WebModel.UtilityModel> data)
        {
            return this.DeleteUtility(data[0].DeviceNumber, data[0]);
        }
    }
}