﻿// -----------------------------------------------------------------------
// <copyright file="BaseApiController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Base API Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Controllers;
    using AutoMapper;
    using Ecolab.Dcs.Entities;
    using Services;
    using Services.Interfaces;
    using ServiceModel = Ecolab.Models;
    using WebModel = Models;

    /// <summary>
    ///     Base for Api Controllers
    /// </summary>
    public class BaseApiController : ApiController
    {
        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantService PlantService;

        /// <summary>
        ///     User Service
        /// </summary>
        protected readonly IUserService UserService;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        private string ecolabAccountNumber;

        /// <summary>
        ///     exchangeRate
        /// </summary>
        private double exchangeRate;

        /// <summary>
        ///  List of UOM's
        /// </summary>
        private List<Ecolab.ConduitLocal.Web.Models.UOMSubUnit> units;

        /// <summary>
        ///     Logo
        /// </summary>
        private string logo;

        /// <summary>
        ///     Role Id
        /// </summary>
        private int roleId;

        /// <summary>
        ///     User Id
        /// </summary>
        private int userId;

        /// <summary>
        ///     Plant Standard TurnTime
        /// </summary>
        private int plantStandardTurnTime;
        /// <summary>
        /// Gets or sets Tunnel Number
        /// </summary>
        /// <value>Tunnel Number</value>
        public static int TunnelNumber { get; set; }

        /// <summary>
        ///      Initializes a new instance of the <see cref="BaseApiController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        protected BaseApiController(IUserService userService, IPlantService plantService)
        {
            this.UserService = userService;
            this.PlantService = plantService;
        }

        /// <summary>
        ///     Gets Ecolab Account Number
        /// </summary>
        protected string EcolabAccountNumber
        {
            get { return this.ecolabAccountNumber ?? (this.ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber); }
        }

        /// <summary>
        ///     Gets Exchange Rate
        /// </summary>
        protected double ExchangeRate
        {
            get { return this.exchangeRate = this.GetExchangeRates(this.GetPlantDetails().CurrencyCode, "USD").Rate; }
        }

        /// <summary>
        /// Gets UOM's
        /// </summary>
        protected List<Ecolab.ConduitLocal.Web.Models.UOMSubUnit> Units
        {
            get { return this.units = GetPlantUOMSubUnits(this.GetPlantDetails().UOMId, this.GetPlantDetails().EcoalabAccountNumber); }
        }
        /// <summary>
        /// Gets Logo of the plant
        /// </summary>
        protected string Logo
        {
            get { return this.logo ?? (this.logo = this.GetPlantDetails().Logo); }
        }
        /// <summary>
        /// Gets Plant Standard Turn Time
        /// </summary>
        protected int PlantStandardTurnTime
        {
            get { return this.plantStandardTurnTime = this.GetPlantDetails().PlantStandardTurnTime; }
        }

        /// <summary>
        ///     Gets User Id
        /// </summary>
        protected int UserId
        {
            get
            {
                this.userId = this.GetUser() != null ? this.GetUser().UserId : 0;
                if (this.userId > 0)
                {
                    return this.userId;
                }

                return this.userId;
            }
        }
        /// <summary>
        /// Gets Role Id
        /// </summary>
        protected int RoleId
        {
            get { return this.roleId = this.GetCurrentUser().Roles.Select(i => i.RoleId).Max(); }
        }
        /// <summary>
        ///     Gets Plant Details
        /// </summary>
        /// <returns>PlantModel</returns>        
        protected WebModel.PlantModel GetPlantDetails()
        {
            return Mapper.Map<ServiceModel.Plant, WebModel.PlantModel>(this.PlantService.GetPlantDetails(this.UserId));
        }

        /// <summary>
        ///     Gets current user Details
        /// </summary>
        /// <returns>CustomPrincipal</returns>
        private CustomPrincipal GetUser()
        {
            return HttpContext.Current.User as CustomPrincipal;
        }

        /// <summary>
        ///     Get Current User logged in
        /// </summary>
        /// <returns>The user details</returns>        
        protected ServiceModel.User GetCurrentUser()
        {
            ServiceModel.User user = null;
            IPrincipal context = HttpContext.Current.User;
            if (context != null && context.GetType() == typeof(Ecolab.Services.CustomPrincipal))
            {
                CustomPrincipal currentUser = (CustomPrincipal)context;
                {
                    user = new ServiceModel.User
                    {
                        Id = currentUser.UserId,
                        UserId = currentUser.UserId,
                        Name = currentUser.UserName,
                        EcolabAccountNumber = currentUser.EcolabAccountNumber,
                        RegionId = currentUser.RegionId,
                        LanguageId = currentUser.LanguageId,
                        Locale = currentUser.Locale
                    };
                    string[] roleIds = currentUser.UserRoleIds.Split(',');
                    string[] rolesList = currentUser.UserRoles.Split(',');
                    List<ServiceModel.UserRoles> userRolesList = rolesList.Select((t, i) => new ServiceModel.UserRoles
                    {
                        Code = t,
                        RoleId = Convert.ToInt32(roleIds[i])
                    }).ToList();
                    user.Roles = userRolesList;
                }
            }
            return user;
        }

        /// <summary>
        /// Executes asynchronously a single HTTP operation.
        /// </summary>
        /// <returns>
        /// The newly started task.
        /// </returns>
        /// <param name="controllerContext">The controller context for a single HTTP operation.</param>
        /// <param name="cancellationToken">The cancellation token assigned for the HTTP operation.</param>
        public override Task<HttpResponseMessage> ExecuteAsync(HttpControllerContext controllerContext, CancellationToken cancellationToken)
        {
            if (this.GetCurrentUser() == null)
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            }
            else
            {
                ServiceModel.User user = this.GetCurrentUser();
                Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(user.Locale);
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(user.Locale);
            }
            return base.ExecuteAsync(controllerContext, cancellationToken);
        }

        /// <summary>
        /// Get Currency exchange rates
        /// </summary>
        /// <param name="sourceCurrency">source Currency</param>
        /// <param name="targetCurrency">target Currency</param>
        /// <returns>ExchangeRate Model Object</returns>
        protected Ecolab.ConduitLocal.Web.Models.ExchangeRate GetExchangeRates(string sourceCurrency, string targetCurrency)
        {
            Ecolab.Models.ExchangeRate rate = this.PlantService.GetExchangeRates(sourceCurrency, targetCurrency);
            if (rate != null)
            {
                return Mapper.Map<ServiceModel.ExchangeRate, WebModel.ExchangeRate>(rate);
            }
            else
            {
                return new WebModel.ExchangeRate();
            }
        }

        /// <summary>
        ///     Get Plant UOM SubUnits
        /// </summary>
        /// <param name="uomId">Uom Identifier.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Plant Model Object</returns>
        protected List<Ecolab.ConduitLocal.Web.Models.UOMSubUnit> GetPlantUOMSubUnits(int uomId, string ecolabAccountNumber)
        {
            List<Ecolab.Models.UOMSubUnit> UomList = this.PlantService.GetPlantUOMSubUnits(this.GetCurrentUser().UserId, uomId, ecolabAccountNumber);
            return Mapper.Map<List<ServiceModel.UOMSubUnit>, List<WebModel.UOMSubUnit>>(UomList);
        }

        /// <summary>
        /// Tags Comparison
        /// </summary>
        /// <param name="tagStatus">Tag Status</param>
        /// <param name="tags">Tags Parameter</param>
        /// <param name="error">error Parameter</param>
        /// <returns>Returns tags</returns>
        protected string CompareTags(TagCollection tagStatus, List<OpcTag> tags, out Dictionary<string, object> error)
        {
            StringBuilder message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            if (tags != null)
            {
                foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                {
                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                        {
                            message.Append(
                                string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>",
                                    tag.Address, tag.Value, plcTag.Value));
                            ambiguousTags.Add(tag);
                        }
                    }
                }
            }

            error = new Dictionary<string, object>();
            if (!string.IsNullOrWhiteSpace(message.ToString()))
            {
                message.Append("Do you want to override the value in plc ?");

                error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
            }

            return message.ToString();
        }

    }
}