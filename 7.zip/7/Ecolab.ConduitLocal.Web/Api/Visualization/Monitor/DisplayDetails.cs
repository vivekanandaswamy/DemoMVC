﻿// -----------------------------------------------------------------------
// <copyright file="DisplayDetails.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>External Display Details Connected to CPU</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.Visualization.Monitor
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Win32;

    /// <summary>
    ///     Display Details
    /// </summary>
    public class DisplayDetails
    {
        /// <summary>
        ///     Display Details
        /// </summary>
        /// <param name="pnPid">s Pn PID</param>
        /// <param name="serialNumber">s Serial Number</param>
        /// <param name="model">s Model</param>
        /// <param name="monitorId">s Monitor ID</param>
        public DisplayDetails(string pnPid, string serialNumber, string model, string monitorId)
        {
            this.PnPid = pnPid;
            this.SerialNumber = serialNumber;
            this.Model = model;
            this.MonitorId = monitorId;
        }

        /// <summary>
        ///     Gets or sets PnPID
        /// </summary>
        public string PnPid { get; set; }

        /// <summary>
        ///     Gets or sets Serial Number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        ///     Gets or sets Model
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        ///     Gets or sets Monitor ID
        /// </summary>
        public string MonitorId { get; set; }

        /// <summary>
        ///     This Function returns all Monitor Details
        /// </summary>
        /// <returns>List of DisplayDetails</returns>
        public static IEnumerable<DisplayDetails> GetMonitorDetails()
        {
            //Open the Display Reg-Key
            RegistryKey display = Registry.LocalMachine;
            bool bFailed = false;
            try
            {
                display = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum\DISPLAY");
            }
            catch
            {
                bFailed = true;
            }

            if (!bFailed & (display != null))
            {
                //Get all MonitorIDss
                foreach (string sMonitorId in display.GetSubKeyNames())
                {
                    RegistryKey monitorId = display.OpenSubKey(sMonitorId);

                    if (monitorId != null)
                    {
                        //Get all Plug&Play ID's
                        foreach (string sPnpid in monitorId.GetSubKeyNames())
                        {
                            RegistryKey pnPid = monitorId.OpenSubKey(sPnpid);
                            if (pnPid != null)
                            {
                                string[] sSubkeys = pnPid.GetSubKeyNames();

                                //Check if Monitor is active
                                if (sSubkeys.Contains("Control") && sSubkeys.Contains("Device Parameters"))
                                {
                                    RegistryKey devParam = pnPid.OpenSubKey("Device Parameters");
                                    string serial = string.Empty;
                                    string model = string.Empty;

                                    //Define Search Keys
                                    string serFind = new string(new[] { (char)00, (char)00, (char)00, (char)0xff });
                                    string modFind = new string(new[] { (char)00, (char)00, (char)00, (char)0xfc });

                                    //Get the EDID code
                                    var encodedId = devParam.GetValue("EDID", null) as byte[];
                                    if (encodedId != null)
                                    {
                                        //Get the 4 Vesa descriptor blocks
                                        var descriptorArray = new string[4];
                                        descriptorArray[0] = Encoding.Default.GetString(encodedId, 0x36, 18);
                                        descriptorArray[1] = Encoding.Default.GetString(encodedId, 0x48, 18);
                                        descriptorArray[2] = Encoding.Default.GetString(encodedId, 0x5A, 18);
                                        descriptorArray[3] = Encoding.Default.GetString(encodedId, 0x6C, 18);

                                        //Search the Keys
                                        foreach (string descriptior in descriptorArray)
                                        {
                                            if (descriptior.Contains(serFind))
                                            {
                                                serial = descriptior.Substring(4).Replace("\0", string.Empty).Trim();
                                            }
                                            if (descriptior.Contains(modFind))
                                            {
                                                model = descriptior.Substring(4).Replace("\0", string.Empty).Trim();
                                            }
                                        }
                                    }
                                    if (!string.IsNullOrEmpty(sPnpid + serFind + model + sMonitorId))
                                    {
                                        yield return new DisplayDetails(sPnpid, serial, model, sMonitorId);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}