﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetupController.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The API Controller for Monitor Setup</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.Visualization.Monitor
{
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Services.Interfaces;
    using Services.Interfaces.Visualization.Monitor;
    using Model = Models.Visualization.Monitor;
    using ServiceModel = Ecolab.Models.Visualization.Monitor;

    /// <summary>
    ///     class MonitorSetupController
    /// </summary>
    public class MonitorSetupController : BaseApiController
    {
        /// <summary>
        ///     List of WasherGroupTypes
        /// </summary>
        private static List<Model.WasherGroupType> lstWasherGroupTypes;

        /// <summary>
        ///     List of Displays
        /// </summary>
        private static List<Model.MonitorDetails> lstDisplays;

        /// <summary>
        ///     Alarm Service
        /// </summary>
        private readonly IMonitorSetupService monitorSetupService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="MonitorSetupController"/> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="monitorSetupService">MonitorSetup Service</param>
        public MonitorSetupController(IUserService userService, IPlantService plantService, IMonitorSetupService monitorSetupService)
            : base(userService, plantService)
        {
            this.monitorSetupService = monitorSetupService;
        }

        /// <summary>
        ///     Gets Washer Group Details
        /// </summary>
        /// <returns>List of Washer Group Types</returns>
        [HttpGet]
        public List<Model.WasherGroupType> FetchWasherGroupTypes()
        {
            return Mapper.Map<List<ServiceModel.WasherGroupType>, List<Model.WasherGroupType>>(this.monitorSetupService.GetWasherGroupTypes());
        }

        /// <summary>
        ///     Gets MonitorSetUp details
        /// </summary>
        /// <returns>List of Monitors setted</returns>
        [HttpGet]
        public List<Model.MonitorSetupModel> FetchMonitorSetUpDetails()
        {
            List<ServiceModel.MonitorSetUp> lstMonitorSetUp = this.monitorSetupService.FetchMonitorSetUpDetails(this.EcolabAccountNumber);
            return this.ConstructMonitorSetUp(lstMonitorSetUp);
        }

        /// <summary>
        ///     Method to construct MonitorSetup model to view
        /// </summary>
        /// <param name="lstMonitorSetUp">lstMonitorSetUp</param>
        /// <returns>List of MonitorSetup details</returns>
        private List<Model.MonitorSetupModel> ConstructMonitorSetUp(IEnumerable<ServiceModel.MonitorSetUp> lstMonitorSetUp)
        {
            var lstViewModel = new List<Model.MonitorSetupModel>();
            if (lstMonitorSetUp == null)
            {
                return lstViewModel;
            }
            Dictionary<int, IGrouping<int, ServiceModel.MonitorSetUp>> dashBoard = lstMonitorSetUp.GroupBy(x => x.DashboardId).ToDictionary(x => x.Key);

            lstWasherGroupTypes = new List<Model.WasherGroupType>(this.FetchWasherGroupTypes());
            lstDisplays = new List<Model.MonitorDetails>(this.FetchMonitors());
            var lstSelectedMachines = new List<Model.MachinesForWasherGroupType>();

            foreach (IGrouping<int, ServiceModel.MonitorSetUp> item in dashBoard.Values)
            {
                ServiceModel.MonitorSetUp firstOrDefault = item.FirstOrDefault();
                if (firstOrDefault != null)
                {
                    Model.MonitorSetupModel objMonitorSetupModel = new Model.MonitorSetupModel
                    {
                        WasherGroupTypes = lstWasherGroupTypes,
                        Displays = lstDisplays,
                        DashboardId = firstOrDefault.DashboardId,
                        DashboardName = firstOrDefault.DashboardName,
                        IsEnableParameter = firstOrDefault.IsEnableParameter,
                        WasherGroupTypeId = firstOrDefault.WasherGroupTypeId,
                        WasherGroupTypeName = firstOrDefault.WasherGroupTypeName,
                        Customer = firstOrDefault.Customer,
                        Formula = firstOrDefault.Formula,
                        Load = firstOrDefault.Load,
                        DisplayOnLogin = firstOrDefault.DisplayOnLogin,
                        MonitorId = firstOrDefault.MonitorId,
                        FormulaDisplayTypeName = firstOrDefault.FormulaDisplayTypeName,
                        TimelineHours = firstOrDefault.TimelineHours,
                        FormulaDisplayType = firstOrDefault.FormulaDisplayType,
                        SlideDuration = firstOrDefault.SlideDuration,
                        EfficiencyCalcType = firstOrDefault.EfficiencyCalcType,
                        EfficiencyCalcTypeName = firstOrDefault.EfficiencyCalcTypeName,
                        MachineNameDispalyType=firstOrDefault.MachineNameDispalyType
                    };
                    List<Model.MachinesForWasherGroupType> machinesForWasherGroupTypes = (from m in item select new Model.MachinesForWasherGroupType { MachineId = m.WasherId, MachineName = m.MachineName }).ToList<Model.MachinesForWasherGroupType>();
                    objMonitorSetupModel.SelectedMachines = machinesForWasherGroupTypes.GroupBy(x => x.MachineId).Select(grp => grp.FirstOrDefault()).ToList();
                    objMonitorSetupModel.SelectedDisplays = new List<Model.MonitorDetails>();
                    foreach (Model.MonitorDetails display in lstDisplays)
                    {
                        foreach (ServiceModel.MonitorSetUp details in item)
                        {
                            if ((display.MonitorId == details.MonitorId) && !objMonitorSetupModel.SelectedDisplays.Contains(display))
                            {
                                objMonitorSetupModel.SelectedDisplays.Add(display);
                            }
                        }
                    }

                    lstViewModel.Add(objMonitorSetupModel);
                }
            }
            return lstViewModel;
        }

        /// <summary>
        ///     Gets MonitorSetUp details
        /// </summary>
        /// <returns>List of Monitors setted</returns>
        [HttpGet]
        public Model.MonitorSetupModel FetchMonitorSetUpForAdd()
        {
            Model.MonitorSetupModel objMonitorSetupModel = new Model.MonitorSetupModel { WasherGroupTypes = lstWasherGroupTypes, Displays = lstDisplays,TimelineHours =8 };
            return objMonitorSetupModel;
        }

        /// <summary>
        ///     Run Windows exe
        /// </summary>
        public void RunExe()
        {
            Process prc = new Process();
            ProcessStartInfo info = new ProcessStartInfo(ConfigurationManager.AppSettings["MonitorSetupEXE"]);
            info.UseShellExecute = true;
            prc.StartInfo = info;
            prc.Start();
        }

        /// <summary>
        ///     Gets Washer Group Details
        /// </summary>
        /// <param name="id">id of the selected washer group</param>
        /// <returns>List of Machines</returns>
        [HttpGet]
        public List<Model.MachinesForWasherGroupType> FetchMachinesForWasherGroupType(int id)
        {
            return Mapper.Map<List<ServiceModel.MachinesForWasherGroupType>, List<Model.MachinesForWasherGroupType>>(this.monitorSetupService.GetMachinesForWasherGroupType(this.EcolabAccountNumber, id));
        }

        /// <summary>
        ///     Gets External Display Details
        /// </summary>
        /// <returns>List of Monitors Connected to System CPU </returns>
        [HttpGet]
        public List<Model.MonitorDetails> FetchMonitors()
        {
            List<Model.MonitorDetails> listMonitorDetails = Mapper.Map<List<ServiceModel.MonitorDetails>, List<Model.MonitorDetails>>(this.monitorSetupService.FetchMonitorDetails(this.EcolabAccountNumber));
            return listMonitorDetails.ToList();
        }

        /// <summary>
        ///     Gets Monitor Details for editing
        /// </summary>
        /// <param name="id">id of the dashboard</param>
        /// <returns>MonitorModel</returns>
        [HttpGet]
        public Model.MonitorSetupModel FetchMonitorDetailsToEdit(int id)
        {
            List<ServiceModel.MonitorSetUp> lstMonitorSetUp = this.monitorSetupService.FetchMonitorSetUpDetailsById(id, this.EcolabAccountNumber);
            var lstMachines = new List<Model.MachinesForWasherGroupType>();
            ServiceModel.MonitorSetUp firstOrDefault = lstMonitorSetUp.FirstOrDefault();
            if (firstOrDefault != null)
            {
                lstMachines = this.FetchMachinesForWasherGroupType(firstOrDefault.WasherGroupTypeId);
            }
            Model.MonitorSetupModel objMonitorSetUpModel = this.ConstructMonitorSetUp(lstMonitorSetUp).FirstOrDefault();
            objMonitorSetUpModel.Machines = lstMachines;
            return objMonitorSetUpModel;
        }

        /// <summary>
        ///     Update Monitor Setup Configuration
        /// </summary>
        /// <param name="model">MonitorSetup Model</param>
        /// <returns>result of the Save operation</returns>
        [HttpPost]
        public int SaveMonitorSetup(IEnumerable<Model.MonitorSetupModel> model)
        {
            int result = 0;
            int count = 0;
            foreach (Model.MonitorSetupModel item in model)
            {
                ServiceModel.MonitorSetUp objMonitorSetup = new ServiceModel.MonitorSetUp
                {
                    DashboardId = item.DashboardId > 0 ? item.DashboardId : result,
                    DashboardName = item.DashboardName,
                    EcolabAccountNumber = this.EcolabAccountNumber,
                    IsEnableParameter = item.IsEnableParameter,
                    MachineName = item.MachineName,
                    MonitorId = item.MonitorId,
                    WasherGroupTypeId = item.WasherGroupTypeId,
                    WasherGroupTypeName = item.WasherGroupTypeName,
                    WasherId = item.WasherId,
                    IsEdit = item.IsEdit,
                    IsDeleteMapping = item.IsDeleteMapping,
                    Customer = item.Customer,
                    Load = item.Load,
                    Formula = item.Formula,
                    DisplayOnLogin = item.DisplayOnLogin,
                    TimelineHours = item.TimelineHours,
                    FormulaDisplayType = item.FormulaDisplayType,
                    EfficiencyCalcType = item.EfficiencyCalcType,
                    MachineNameDispalyType=item.MachineNameDispalyType
                };

                if (this.monitorSetupService.CheckDashboardName(objMonitorSetup) == 0)
                {
                    //While editing, delete the existing Mappings and create new mapping
                    if (objMonitorSetup.IsDeleteMapping)
                    {
                        if (count == 0)
                        {
                            this.monitorSetupService.DeleteDashboardMonitorSetUpMapping(objMonitorSetup, this.UserId);
                            count++;
                        }
                    }
                    result = this.monitorSetupService.InsertMonitorSetUp(objMonitorSetup, this.UserId);
                }
                else
                {
                    result = 701;
                }
            }
            return result;
        }

        /// <summary>
        /// Creates the duration of the slide.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// result of the Save operation
        /// </returns>
        [HttpGet]
        public int CreateSlideDuration(int id)
        {
            int result = -1;
            result = this.monitorSetupService.UpdateSlideDuration(id, EcolabAccountNumber);
            return result;
        }

        /// <summary>
        ///     Delete Monitor Setup Configuration
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>result of the delete operation</returns>
        [HttpGet]
        public string DeleteMonitorSetup(int id)
        {
            ServiceModel.MonitorSetUp objMonitorSetup = new ServiceModel.MonitorSetUp { DashboardId = id, EcolabAccountNumber = this.EcolabAccountNumber };
            return this.monitorSetupService.DeleteMonitorSetUp(objMonitorSetup, this.UserId);
        }
    }
}