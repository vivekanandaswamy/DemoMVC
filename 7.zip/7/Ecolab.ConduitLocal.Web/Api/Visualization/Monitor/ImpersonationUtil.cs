﻿// -----------------------------------------------------------------------
// <copyright file="ImpersonationUtil.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Impersonation Util </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.Visualization.Monitor
{
    using System;
    using System.Runtime.InteropServices;
    using System.Security.Principal;

    /// <summary>
    ///     class used for impersonation services
    /// </summary>
    public class ImpersonationUtil
    {
        #region EndImpersonation

        /// <summary>
        ///     ends the impersonation
        /// </summary>
        public void EndImpersonation()
        {
            if(this.impersonationContext != null)
            {
                this.impersonationContext.Undo();
            }
        }

        #endregion

        #region External dll functions

        public const int Logon32LogonInteractive = 2;
        public const int Logon32ProviderDefault = 0;

        private WindowsImpersonationContext impersonationContext;

        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
        private static extern int LogonUserA(string lpszUserName, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int DuplicateToken(IntPtr hToken, int impersonationLevel, ref IntPtr hNewToken);

        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool RevertToSelf();

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern bool CloseHandle(IntPtr handle);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DisplayDevice lpDisplayDevice, uint dwFlags);

        #endregion

        #region ImpersonateUser

        [Flags]
        public enum DisplayDeviceStateFlags
        {
            /// <summary>The device is part of the desktop.</summary>
            AttachedToDesktop = 0x1,
            MultiDriver = 0x2,

            /// <summary>The device is part of the desktop.</summary>
            PrimaryDevice = 0x4,

            /// <summary>Represents a pseudo device used to mirror application drawing for remoting or other purposes.</summary>
            MirroringDriver = 0x8,

            /// <summary>The device is VGA compatible.</summary>
            VgaCompatible = 0x10,

            /// <summary>The device is removable; it cannot be the primary display.</summary>
            Removable = 0x20,

            /// <summary>The device has more display modes than its output devices support.</summary>
            ModesPruned = 0x8000000,
            Remote = 0x4000000,
            Disconnect = 0x2000000
        }

        /// <summary>
        ///     impersonates the user
        /// </summary>
        public void Display()
        {
            DisplayDevice d = new DisplayDevice();
            d.cb = Marshal.SizeOf(d);
            try
            {
                for(uint id = 0; EnumDisplayDevices(null, id, ref d, 0); id++)
                {
                    if(d.StateFlags.HasFlag(DisplayDeviceStateFlags.AttachedToDesktop))
                    {
                        Console.WriteLine("{0}, {1}, {2}, {3}, {4}, {5}", id, d.DeviceName, d.DeviceString, d.StateFlags, d.DeviceID, d.DeviceKey);
                        d.cb = Marshal.SizeOf(d);
                        EnumDisplayDevices(d.DeviceName, 0, ref d, 0);
                        Console.WriteLine("{0}, {1}", d.DeviceName, d.DeviceString);
                    }
                    d.cb = Marshal.SizeOf(d);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("{0}", ex);
            }
        }

        /// <summary>
        ///     Impersonate User
        /// </summary>
        /// <param name="userName">Parameter User Name</param>
        /// <param name="domain">Parameter Domain</param>
        /// <param name="password">Parameter PassWord</param>
        /// <returns>Returns Boolean Value</returns>
        public bool ImpersonateUser(string userName, string domain, string password)
        {
            WindowsIdentity tempWindowsIdentity;
            IntPtr token = IntPtr.Zero;
            IntPtr tokenDuplicate = IntPtr.Zero;

            if(RevertToSelf())
            {
                if(LogonUserA(userName, domain, password, Logon32LogonInteractive, Logon32ProviderDefault, ref token) != 0)
                {
                    if(DuplicateToken(token, 2, ref tokenDuplicate) != 0)
                    {
                        tempWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                        this.impersonationContext = tempWindowsIdentity.Impersonate();
                        if(this.impersonationContext != null)
                        {
                            CloseHandle(token);
                            CloseHandle(tokenDuplicate);
                            return true;
                        }
                    }
                }
            }
            if(token != IntPtr.Zero)
            {
                CloseHandle(token);
            }
            if(tokenDuplicate != IntPtr.Zero)
            {
                CloseHandle(tokenDuplicate);
            }
            return false;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct DisplayDevice
        {
            [MarshalAs(UnmanagedType.U4)] public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
            [MarshalAs(UnmanagedType.U4)] public DisplayDeviceStateFlags StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }

        #endregion
    }
}