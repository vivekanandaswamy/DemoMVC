﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The RedFlag Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Text.RegularExpressions;
	using System.Web.Http;
	using AutoMapper;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Ecolab.Models.PlantSetup;
	using Ecolab.Models.PlantSetup.RedFlag;
	using Models.PlantSetup;
	using Models.PlantSetup.RedFlag;
	using Services.Interfaces;
	using Services.Interfaces.PlantSetup;

	/// <summary>
	///     RedFlag Controller class
	/// </summary>
	public class RedFlagController : BaseApiController
	{
		/// <summary>
		///     RedFlag Service
		/// </summary>
		private readonly IRedFlagService redFlagService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="RedFlagController"/>class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="redFlagService">The red flag service</param>
        public RedFlagController(IUserService userService, IPlantService plantService, IRedFlagService redFlagService)
			: base(userService, plantService)
		{
			this.redFlagService = redFlagService;
		}

		/// <summary>
		///     Gets Red Flag details
		/// </summary>
		/// <returns>List of RedFlagModel</returns>
		[HttpGet]
		public List<RedFlagModel> Get()
		{
			List<RedFlag> redFlag = this.redFlagService.FetchRedFlagDetails(null, this.EcolabAccountNumber);
			List<RedFlagModel> redflagList = Mapper.Map<List<RedFlag>, List<RedFlagModel>>(redFlag);

			redflagList = redflagList.Where(item => item.IsDelete == false).ToList();
			redflagList.ForEach(_ => _.MinimumRangeAsString = _.MinimumRange.ToString("#,0.###"));
			redflagList.ForEach(_ => _.MaximumRangeAsString = _.MaximumRange.ToString("#,0.###"));
			return redflagList;
		}

		/// <summary>
		///     Gets Items for Dropdown
		/// </summary>
		/// <returns>List of ItemModel</returns>
		[HttpGet]
		public List<ItemModel> GetItemData()
		{
			List<RedFlagItem> item = this.redFlagService.FetchRedFlagItemDetails(null, this.EcolabAccountNumber);
			return Mapper.Map<List<RedFlagItem>, List<ItemModel>>(item);
		}

		/// <summary>
        ///     Gets Items for Dropdown
        /// </summary>
        /// <returns>List of ItemModel</returns>
        [HttpGet]
        public List<RedFlagCategoryModel> GetCategoryData()
        {
            List<Ecolab.Models.PlantSetup.RedFlag.RedFlagCategory> category = this.redFlagService.FetchRedFlagCategoryData();
            return Mapper.Map<List<RedFlagCategory>, List<RedFlagCategoryModel>>(category);
        }

        /// <summary>
        /// Gets RedFlagItems for dropdown based on category
        /// </summary>
        /// <param name="categoryId">The category identifier.</param>
        /// <returns>
        /// List of ItemModel
        /// </returns>
        [HttpGet]
        public List<ItemModel> GetRedFlagItemListByCategory(int categoryId)
        {
            List<Ecolab.Models.PlantSetup.RedFlag.RedFlagItem> RedFlagItemList = this.redFlagService.GetRedFlagItemListByCategory(categoryId, this.EcolabAccountNumber);
            return Mapper.Map<List<RedFlagItem>, List<ItemModel>>(RedFlagItemList);
        }

        /// <summary>
		///     Gets Cascading locations data on Item change
		/// </summary>
		/// <param name="id">Red Flag Id</param>
		/// <param name="itemId">Item Identifier</param>
		/// <returns>List of RedFlagLocationModel</returns>
		[HttpGet]
		public List<RedFlagLocationModel> GetOnItemChange(int? id, int itemId)
		{
			List<RedFlagLocation> location = this.redFlagService.FetchRedFlagLocationDetails(itemId, this.EcolabAccountNumber);
			List<RedFlagLocationModel> locationList = Mapper.Map<List<RedFlagLocation>, List<RedFlagLocationModel>>(location);
			return locationList;
		}

		/// <summary>
		///     Gets Cascading locations data on Location change
		/// </summary>
		/// <param name="id">Red flag Id</param>
		/// <param name="itemId">Item Identifier.</param>
		/// <param name="locationId">Location Id</param>
		/// <returns>List of RedFlagLocationModel</returns>
		[HttpGet]
		public List<MachineSetupModel> GetOnLocationChange(int? id, int itemId, int locationId)
		{
			List<MachineSetupModel> objMachines = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.redFlagService.GetRedFlagMachineDetails(locationId, this.EcolabAccountNumber));
			return objMachines;
		}

		/// <summary>
        ///     Gets Cascading FormulaCategory data on Location change
        /// </summary>
        /// <param name="id">Red flag Id</param>
        /// <param name="itemId">Item Identifier.</param>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of EcolabTextileCategoryModel</returns>
        [HttpGet]
        public List<Models.FormulaModel> GetFormulaCategoryOnLocationChange(int id, int itemId, int locationId)
        {
            List<Models.FormulaModel> textileCategory = Mapper.Map<List<Ecolab.Models.Formula>, List<Models.FormulaModel>>(this.redFlagService.FetchFormulaCategorybyLocationId(locationId, this.EcolabAccountNumber));
            return textileCategory;
        }

        /// <summary>
        /// Gets Cascading formula data on FormulaCategory change
        /// </summary>
        /// <param name="locationId">groupTypeId Id</param>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// List of FormulaModel
        /// </returns>
        public List<Models.FormulaModel> GetFormulaOnFormulaCategoryChange(int locationId, int id)
        {
            List<Models.FormulaModel> formula = Mapper.Map<List<Ecolab.Models.Formula>, List<Models.FormulaModel>>(this.redFlagService.FetchFormulabyFormulaCategory(locationId, id, this.EcolabAccountNumber));
            return formula;
        }

        /// <summary>
        /// Gets Cascading formula data on FormulaCategory change
        /// </summary>
        /// <param name="locationId">groupTypeId Id</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>
        /// List of FormulaModel
        /// </returns>
        public List<Models.ProductMasterModel> GetProductsOnFormulaChange(int locationId, int? formulaId)
        {
            List<Models.ProductMasterModel> products = Mapper.Map<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>, List<Models.ProductMasterModel>>(this.redFlagService.FetchProductsByFormulaId(locationId,formulaId, this.EcolabAccountNumber));
            return products;
        }

        /// <summary>
        ///     Gets list of Meters for the location
        /// </summary>
        /// <param name="locationId">Location Id</param>
        /// <param name="itemId">Item identifier.</param>
        /// <returns>List of Meters</returns>
        [HttpGet]
        public List<MeterModel> GetMeterOnLocationChange(int locationId,int itemId)
        {
            List<MeterModel> meters = Mapper.Map<List<Meter>, List<MeterModel>>(this.redFlagService.GetRedFlagMetersByLocation(locationId, this.EcolabAccountNumber, itemId));
            return meters;
        }

        /// <summary>
        ///     Gets list of Sensors for the location
        /// </summary>
        /// <param name="locationId">Location Id</param>
        /// <returns>List of Sensors</returns>
        [HttpGet]
        public List<Sensor> GetSensorOnLocationChange(int locationId)
        {
            List<Sensor> sensors = this.redFlagService.GetRedFlagSensorsByLocation(locationId, this.EcolabAccountNumber);
            return sensors;
        }

        /// <summary>
		///     Gets RedFlag Data on Edit Clicked
		/// </summary>
		/// <param name="id">Red Flag Id</param>
		/// <returns>Dictionary of selected RedFlagModel, ItemModel, RedFlagLocationModel</returns>
		[HttpGet]
		public Dictionary<string, object> GetOnEditClicked(int id)
		{
			RedFlagModel redFlag = Mapper.Map<RedFlag, RedFlagModel>(this.redFlagService.FetchRedFlagDetails(id, this.EcolabAccountNumber).FirstOrDefault());
            List<Ecolab.Models.PlantSetup.RedFlag.RedFlagItem> itemList = this.redFlagService.GetRedFlagItemListByCategory(redFlag.CategoryId, this.EcolabAccountNumber);            
            List<RedFlagCategory> category = this.redFlagService.FetchRedFlagCategoryData();
			List<RedFlagLocation> location = this.redFlagService.FetchRedFlagLocationDetails(redFlag.ItemId, this.EcolabAccountNumber);
			List<RedFlagLocationModel> locationList = Mapper.Map<List<RedFlagLocation>, List<RedFlagLocationModel>>(location);
			List<MachineSetupModel> objMachines = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.redFlagService.GetRedFlagMachineDetails(redFlag.LocationId, this.EcolabAccountNumber));
            List<MeterModel> meters = Mapper.Map<List<Meter>, List<MeterModel>>(this.redFlagService.GetRedFlagMetersByLocation(redFlag.LocationId, this.EcolabAccountNumber, redFlag.ItemId));
            List<Models.FormulaModel> textileCategory = Mapper.Map<List<Ecolab.Models.Formula>, List<Models.FormulaModel>>(this.redFlagService.FetchFormulaCategorybyLocationId(redFlag.LocationId, this.EcolabAccountNumber));
            var selectedFormula = textileCategory.Where(a => a.ProgramId == redFlag.FormulaId).DefaultIfEmpty(new Models.FormulaModel() { EcolabTextileId = 0, ChainTextileId = 0 }).FirstOrDefault();
            redFlag.FormulaCategoryId = selectedFormula.EcolabTextileId != 0 ? selectedFormula.EcolabTextileId : selectedFormula.ChainTextileId;
            List <Models.FormulaModel> formula = Mapper.Map<List<Ecolab.Models.Formula>, List<Models.FormulaModel>>(this.redFlagService.FetchFormulabyFormulaCategory(redFlag.LocationId,id, this.EcolabAccountNumber));
            List<Models.ProductMasterModel> products = Mapper.Map<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>, List<Models.ProductMasterModel>>(this.redFlagService.FetchProductsByFormulaId(redFlag.LocationId,redFlag.FormulaId, this.EcolabAccountNumber));
            List<Sensor> sensors = this.redFlagService.GetRedFlagSensorsByLocation(redFlag.LocationId, this.EcolabAccountNumber);

            return new Dictionary<string, object> { { "Category",category}, { "RedFlag", redFlag }, { "Item", itemList }, { "Location", locationList }, { "Machines", objMachines }, {"FormulaCategory", textileCategory }, {"Formula", formula }, { "Product", products } , { "Meter", meters} , { "Sensor", sensors } };
		}

		/// <summary>
		///     Creates new Red Flag
		/// </summary>
		/// <param name="data">Data to create Red Flag</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpPost]
		public HttpResponseMessage Create([FromBody]List< RedFlagModel> data)
		{
			try
			{
				//for Plant Level and Group Level machineIds will be null
				data[0].MachineIds = data[0].MachineIds ?? "-1";

				List<RedFlagModel> redFlagFiltered = this.RedFlagFilteredData(data[0]);
				redFlagFiltered.ForEach(r => r.EcolabAccountNumber = this.EcolabAccountNumber);

				List<RedFlag> objRedFlag = Mapper.Map<List<RedFlagModel>, List<RedFlag>>(redFlagFiltered);

				DateTime lastModifiedTimeStamp;
				int result = this.redFlagService.InsertRedFlag(objRedFlag, this.UserId, out lastModifiedTimeStamp);
				objRedFlag.ForEach(r => r.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc));

				if (result > 0)
				{
					switch (result)
					{
						case 51030:
						case 401:
						case 301:
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
						default:
							List<RedFlag> objFlag = this.redFlagService.FetchRedFlagDetailsForReSync(result,
								this.EcolabAccountNumber);
							Push.PushToQueue(objFlag.FirstOrDefault(), this.UserId, result, (int)TcdAdminMessageTypes.TcdAddRedFlag, this.EcolabAccountNumber);
							return this.Request.CreateResponse(HttpStatusCode.OK, data);
					}
				}
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, result); // Need to Change
			}
			catch (Exception ex)
			{
				int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
			}
		}

		/// <summary>
		///     To update the Red Flag details
		/// </summary>
		/// <param name="id">RedFlag Id</param>
		/// <param name="data">Data to update Red Flag</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpPut]
		public HttpResponseMessage Put(int? id, RedFlagModel data)
		{
			try
			{
				//for Plant Level machineIds will be null
				data.MachineIds = String.IsNullOrEmpty(data.MachineIds) ? "-1" : data.MachineIds;

				RedFlagModel redFlag = Mapper.Map<RedFlag, RedFlagModel>(this.redFlagService.FetchRedFlagDetails(id, this.EcolabAccountNumber).FirstOrDefault());
				var redFlagFiltered = new List<RedFlagModel>();
				redFlagFiltered.ForEach(r => r.EcolabAccountNumber = this.EcolabAccountNumber);
				var oldMachines = new List<int>();
                List<int> newMachines = new List<int>();

				if (redFlag.MachineIds != null)
				{
					oldMachines = redFlag.MachineIds.Split(',').Select(int.Parse).ToList();
				}

                if (data.MachineIds != null)
                {
                    newMachines = data.MachineIds.Split(',').Select(int.Parse).ToList();
                }                

                data.MachineId = newMachines.FirstOrDefault();
				if (redFlag.ItemId == data.ItemId && redFlag.LocationId == data.LocationId)
				{
                    var diff = oldMachines.Except(newMachines).Union(newMachines.Except(oldMachines)).Select(item => new { MachineId = item, IsSelected = newMachines.Contains(item) }).ToList();
					if (diff.Any())
					{
                        if (diff.FirstOrDefault().MachineId == -1)
						{
							diff.Remove(diff.FirstOrDefault());
						}

                        redFlagFiltered = (from d in diff select new RedFlagModel
                        {
                            Id = data.Id, ItemId = data.ItemId, UOM = data.UOM, MinimumRange = data.MinimumRange, MaximumRange = data.MaximumRange,
                            LocationId = data.LocationId, EcolabAccountNumber = this.EcolabAccountNumber, IsSelected = d.IsSelected,
                            MachineId = (d.MachineId == -1) ? (int?)null : d.MachineId,
                            FormulaId = (data.FormulaId == -1) ? (int?)null : data.FormulaId,
                            ProductId = data.ProductId == -1 ? (int?)null : data.ProductId,
                            MeterId = data.MeterId == -1 ? (int?)null : data.MeterId,
                            SensorId = data.SensorId == -1 ? (int?)null : data.SensorId,
                            CategoryId = data.CategoryId
                        }).ToList();
					}
					else
					{
                        data.FormulaId = (data.FormulaId == -1) ? (int?)null : data.FormulaId;
                        data.ProductId = data.ProductId == -1 ? (int?)null : data.ProductId;
                        data.MeterId = data.MeterId == -1 ? (int?)null : data.MeterId;
                        data.SensorId = data.SensorId == -1 ? (int?)null : data.SensorId;
                        redFlagFiltered.Add(data);
						data.IsDirty = true;
					}
				}
				else
				{
					redFlagFiltered = this.RedFlagFilteredData(data);
				}

				List<RedFlag> objRedFlag = Mapper.Map<List<RedFlagModel>, List<RedFlag>>(redFlagFiltered);

				DateTime lastModifiedTimeStamp;
				int result = this.redFlagService.UpdateRedFlag(objRedFlag, this.UserId, out lastModifiedTimeStamp);
				objRedFlag.ForEach(r => r.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc));

				if (result > 0)
				{
					switch (result)
					{
						case 51030:
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
						case 401:
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
						case 301:
							return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
						default:
							List<RedFlag> objFlag = this.redFlagService.FetchRedFlagDetailsForReSync(id,
								this.EcolabAccountNumber);
							Push.PushToQueue(objFlag.FirstOrDefault(), this.UserId, id.Value, (int)TcdAdminMessageTypes.TcdUpdateRedFlag, this.EcolabAccountNumber);

							return this.Request.CreateResponse(HttpStatusCode.OK, data);
					}
				}

				return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
			}
			catch (Exception ex)
			{
				int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
			}
		}

		/// <summary>
		///     To update the Red Flag details
		/// </summary>
		/// <param name="data">Data to update Red Flag</param>
		/// <returns>Returns Success or failure response Messages</returns>
		public HttpResponseMessage Put(List< RedFlagModel> data)
		{
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();
            foreach (RedFlagModel RedFlagModel in data)
		{
                HttpResponseMessage = this.Put(RedFlagModel.Id, RedFlagModel);
		}
            return HttpResponseMessage;
        }

		/// <summary>
		///     Delete the RedFlag data
		/// </summary>
		/// <param name="data">Delete the Meter data</param>
		/// <returns>Returns Success or failure response Messages</returns>
		[HttpDelete]
		public HttpResponseMessage Delete(List< RedFlagModel> data)
		{
			try
			{
				data[0].IsDelete = true;
				RedFlag objRedFlag = Mapper.Map<RedFlagModel, RedFlag>(data[0]);
				DateTime lastModifiedTimeStamp;
				int result = this.redFlagService.DeleteRedFlag(objRedFlag, this.UserId, out lastModifiedTimeStamp);
				objRedFlag.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

				if (result == 0)
				{
					List<RedFlag> objFlag = this.redFlagService.FetchRedFlagDetailsForReSync(objRedFlag.Id,
								this.EcolabAccountNumber);
					Push.PushToQueue(objFlag.FirstOrDefault(), this.UserId, objRedFlag.Id, (int)TcdAdminMessageTypes.TcdDeleteRedFlag, this.EcolabAccountNumber);
				}

				return this.Request.CreateResponse(HttpStatusCode.OK, data);
			}
			catch (Exception ex)
			{
				int message = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, message);
			}
		}

		/// <summary>
		///     Gets list of redFlag with machines when new location is selected
		/// </summary>
		/// <param name="redFlag">redFlag Modal data</param>
		/// <returns>List of RedFlagModel</returns>
		public List<RedFlagModel> RedFlagFilteredData(RedFlagModel redFlag)
		{
			List<int> newMachines = redFlag.MachineIds.Split(',').Select(int.Parse).ToList();
            return (from machineId in newMachines select new RedFlagModel
            {
                Id = redFlag.Id,
                ItemId = redFlag.ItemId,
                UOM = redFlag.UOM,
                MinimumRange = redFlag.MinimumRange,
                MaximumRange = redFlag.MaximumRange,
                LocationId = redFlag.LocationId,
                EcolabAccountNumber = this.EcolabAccountNumber,
                IsSelected = true,
                MachineId = machineId == -1 ? (int?)null : machineId,
                LastModifiedTimeStamp = redFlag.LastModifiedTimeStamp,
                CategoryId = redFlag.CategoryId,
                FormulaCategoryId = redFlag.FormulaCategoryId,
                FormulaId = redFlag.FormulaId == -1 ? null : redFlag.FormulaId,
                ProductId = redFlag.ProductId == -1 ? null : redFlag.ProductId,
                MeterId = redFlag.MeterId == -1 ? null : redFlag.MeterId,
                SensorId = redFlag.SensorId == -1 ? null : redFlag.SensorId
            }).ToList();
		}
	}
}