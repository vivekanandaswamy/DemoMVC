﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Labor Cost Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Web.Http;
	using AutoMapper;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Models.PlantSetup.TargetProduction;
	using Services.Interfaces;
	using Services.Interfaces.PlantSetup.ShiftLabor;
	using Utilities;
	using Model = Ecolab.Models.PlantSetup.ShiftLabor;

    public class TargetProductionController : BaseApiController
    {
        /// <summary>
        ///     Shift Break Service
        /// </summary>
        private readonly IShiftBreakService shiftBreakService;

        /// <summary>
        /// Initializes a new instance of the <see cref="TargetProductionController"/>class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="shiftBreakService">The shift break service.</param>
        public TargetProductionController(IUserService userService, IPlantService plantService, IShiftBreakService shiftBreakService)
            : base(userService, plantService)
        {
            this.shiftBreakService = shiftBreakService;
        }

        /// <summary>
        ///     Method to fetch target production details
        /// </summary>
        /// <returns>List of target production</returns>
        [HttpGet]
        public TargetProdDetails FetchTargetProductionDetails()
        {
            List<Model.TargetProduction> targetProd = this.shiftBreakService.FetchTargetProductionDetails(this.EcolabAccountNumber);
            List<TargetProduction> prodList = Mapper.Map<List<Model.TargetProduction>, List<TargetProduction>>(targetProd);
            IEnumerable<string> shifts = prodList.AsEnumerable().Where(y => y.ShiftName != null).Select(x => x.ShiftName).Distinct();
            var details = targetProd.AsEnumerable().Select(x => x).GroupBy(s => new { s.ShiftName }).ToDictionary(a => a.Key, a => a.ToList());
            TargetProdDetails objTpDetails = new TargetProdDetails();
            objTpDetails.Sunday = new TargetProductionData();
            objTpDetails.Monday = new TargetProductionData();
            objTpDetails.Tuesday = new TargetProductionData();
            objTpDetails.Wednesday = new TargetProductionData();
            objTpDetails.Thursday = new TargetProductionData();
            objTpDetails.Friday = new TargetProductionData();
            objTpDetails.Saturday = new TargetProductionData();
            objTpDetails.Shift = new List<string>();
            objTpDetails.Shift.AddRange(shifts);
            int[] days = { 1, 2, 3, 4, 5, 6, 7 };
            foreach (var item1 in details)
            {
                int[] shiftDays = item1.Value.AsEnumerable().Select(x => x.DayId).ToArray();
                int[] remainingDays = null;
                foreach (Model.TargetProduction item in details[item1.Key])
                {
                    remainingDays = days.Except(shiftDays).ToArray();
                    BindTargetProduction(objTpDetails, item);
                }
                foreach (int item in remainingDays)
                {
                    switch (item)
                    {
                        case 1:
                            if (objTpDetails.Sunday.DayData != null)
                            {
                                objTpDetails.Sunday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Sunday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 2:
                            if (objTpDetails.Monday.DayData != null)
                            {
                                objTpDetails.Monday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Monday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 3:
                            if (objTpDetails.Tuesday.DayData != null)
                            {
                                objTpDetails.Tuesday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Tuesday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 4:
                            if (objTpDetails.Wednesday.DayData != null)
                            {
                                objTpDetails.Wednesday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Wednesday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 5:
                            if (objTpDetails.Thursday.DayData != null)
                            {
                                objTpDetails.Thursday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Thursday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 6:
                            if (objTpDetails.Friday.DayData != null)
                            {
                                objTpDetails.Friday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Friday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                        case 7:
                            if (objTpDetails.Saturday.DayData != null)
                            {
                                objTpDetails.Saturday.DayData.Add(new TargetProduction { DayId = item, TargetProd = null });
                            }
                            else
                            {
                                objTpDetails.Saturday = new TargetProductionData { DayData = new List<TargetProduction> { new TargetProduction { DayId = item, TargetProd = null } }, DisplayOrder = 0 };
                            }
                            break;
                    }
                }
            }

            return SortDays(objTpDetails);
        }
        /// <summary>
        /// Method to sort the days
        /// </summary>
        /// <param name="objTpDetails">Target production details</param>
        /// <returns>Target production details</returns>
        private TargetProdDetails SortDays(TargetProdDetails objTpDetails)
        {
            string[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
            var currentDay = DateTime.Now.DayOfWeek.ToString();
            List<string> sortedDays = days.Skip(Array.IndexOf(days, currentDay)).ToList();
            List<string> finalList = new List<string>();
            finalList.AddRange(sortedDays);
            finalList.AddRange(days.Except(finalList));
            return SetDisplayOrder(objTpDetails, finalList);
        }
        /// <summary>
        /// Method to display the order of days
        /// </summary>
        /// <param name="objTpDetails">Target production details</param>
        /// <param name="days">Days parameter.</param>
        /// <returns>Target production details</returns>
        private TargetProdDetails SetDisplayOrder(TargetProdDetails objTpDetails, List<string> days)
        {
            objTpDetails.Sunday.DisplayOrder = days.IndexOf("Sunday");
            objTpDetails.Sunday.Date = BindDate(days.IndexOf("Sunday"));
            objTpDetails.Monday.DisplayOrder = days.IndexOf("Monday");
            objTpDetails.Monday.Date = BindDate(days.IndexOf("Monday"));
            objTpDetails.Tuesday.DisplayOrder = days.IndexOf("Tuesday");
            objTpDetails.Tuesday.Date = BindDate(days.IndexOf("Tuesday"));
            objTpDetails.Wednesday.DisplayOrder = days.IndexOf("Wednesday");
            objTpDetails.Wednesday.Date = BindDate(days.IndexOf("Wednesday"));
            objTpDetails.Thursday.DisplayOrder = days.IndexOf("Thursday");
            objTpDetails.Thursday.Date = BindDate(days.IndexOf("Thursday"));
            objTpDetails.Friday.DisplayOrder = days.IndexOf("Friday");
            objTpDetails.Friday.Date = BindDate(days.IndexOf("Friday"));
            objTpDetails.Saturday.DisplayOrder = days.IndexOf("Saturday");
            objTpDetails.Saturday.Date = BindDate(days.IndexOf("Saturday"));
            return objTpDetails;
        }
        /// <summary>
        /// Method to bind the date
        /// </summary>
        /// <param name="daysToAdd">Add days to bind</param>
        /// <returns>Returns datetime</returns>
        private string BindDate(int daysToAdd)
        {
            return DateTime.Now.AddDays(daysToAdd).ToString("MM/dd/yyyy");
        }

        /// <summary>
        ///     Method to build target production class for view
        /// </summary>
        /// <param name="objTpDetails">target production details</param>
        /// <param name="item">target production model</param>
        private void BindTargetProduction(TargetProdDetails objTpDetails, Model.TargetProduction item)
        {
            List<Model.Shift> runningShifts = this.shiftBreakService.FetchRunningShiftDetails();
            switch (item.DayId)
            {
                case 1:
                    if (objTpDetails.Sunday.DayData != null)
                    {
                        objTpDetails.Sunday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdDisplay = item.TargetProd,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Sunday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Sunday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, 
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                              IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Sunday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        } };
                    }
                    //objTpDetails.Sunday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Sunday.DayData.Count > 0)
                    {
                        objTpDetails.Sunday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 2:
                    if (objTpDetails.Monday.DayData != null)
                    {
                        objTpDetails.Monday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Monday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Monday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                              IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Monday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    //objTpDetails.Monday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Monday.DayData.Count > 0)
                    {
                        objTpDetails.Monday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 3:
                    if (objTpDetails.Tuesday.DayData != null)
                    {
                        objTpDetails.Tuesday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Tuesday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd, 
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    //objTpDetails.Tuesday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Tuesday.DayData.Count > 0)
                    {
                        objTpDetails.Tuesday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 4:
                    if (objTpDetails.Wednesday.DayData != null)
                    {
                        objTpDetails.Wednesday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Wednesday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd, 
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true } };
                    }
                    //objTpDetails.Wednesday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Wednesday.DayData.Count > 0)
                    {
                        objTpDetails.Wednesday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 5:
                    if (objTpDetails.Thursday.DayData != null)
                    {
                        objTpDetails.Thursday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Thursday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Thursday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Thursday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    //objTpDetails.Thursday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Thursday.DayData.Count > 0)
                    {
                        objTpDetails.Thursday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 6:
                    if (objTpDetails.Friday.DayData != null)
                    {
                        objTpDetails.Friday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Friday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Friday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                           IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Friday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    //objTpDetails.Friday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Friday.DayData.Count > 0)
                    {
                        objTpDetails.Friday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
                case 7:
                    if (objTpDetails.Saturday.DayData != null)
                    {
                        objTpDetails.Saturday.DayData.Add(new TargetProduction
                        {
                            DayId = item.DayId,
                            DayName = item.DayName,
                            ShiftId = item.ShiftId,
                            ShiftName = item.ShiftName,
                            TargetProd = item.TargetProd,
                            StartTime = item.StartTime,
                            EndTime = item.EndTime,
                            TargetProdAsstring = item.TargetProd.ToString("#,0.##"),
                            TargetProdDisplay = item.TargetProd,
                            IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Saturday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true
                        });
                    }
                    else
                    {
                        objTpDetails.Saturday.DayData = new List<TargetProduction> { new TargetProduction { DayId = item.DayId, DayName = item.DayName, ShiftId = item.ShiftId, ShiftName = item.ShiftName, TargetProd = item.TargetProd, StartTime = item.StartTime, EndTime = item.EndTime, TargetProdAsstring = item.TargetProd.ToString("#,0.##"), TargetProdDisplay = item.TargetProd,
                           IsEditable = DateTime.Now.DayOfWeek == DayOfWeek.Saturday ? (runningShifts.Exists(x => x.ShiftName == item.ShiftName) ? false : true) : true} };
                    }
                    //objTpDetails.Saturday.DayData.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                    if (objTpDetails.Saturday.DayData.Count > 0)
                    {
                        objTpDetails.Saturday.DayData.Where(p => p.ShiftId == 0).Each(p => p.TargetProdDisplay = null);
                    }
                    break;
            }
        }

        /// <summary>
        ///     Update Target production Details
        /// </summary>
        /// <param name="data">List of Target production</param>
        /// <returns>Update status code</returns>
        [HttpPost]
        public HttpResponseMessage Put(IEnumerable<TargetProduction> data)
        {
            //data = data.ToList().ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);
            List<Model.TargetProduction> targetProductionLists = Mapper.Map<IEnumerable<TargetProduction>, IEnumerable<Model.TargetProduction>>(data).ToList();
            DateTime lastModifiedTime = DateTime.UtcNow;
            string status = this.shiftBreakService.SaveTargetProduction(targetProductionLists.AsEnumerable(), this.EcolabAccountNumber, this.UserId, out lastModifiedTime);
            targetProductionLists.ForEach(t => DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            if (status == "201")
            {
                TargetProductionSyncData();
            }
            return (status == "201") ? this.Request.CreateResponse(HttpStatusCode.OK, status) : this.Request.CreateResponse(HttpStatusCode.BadRequest, status);
        }

        /// <summary>
        /// TargetProductionSyncData
        /// </summary>
        public void TargetProductionSyncData()
        {
            Model.TargetProductionContainer targetProductionContainer = new Model.TargetProductionContainer();
            targetProductionContainer.TargetProduction = new List<Model.TargetProduction>();
            targetProductionContainer.TargetProduction = this.shiftBreakService.FetchTargetProductionDetailsForSync(this.EcolabAccountNumber);
            Model.TargetProduction targetProduction = targetProductionContainer.TargetProduction.FirstOrDefault();
            if (targetProduction != null)
            {
                Push.PushToQueue(targetProductionContainer, this.UserId, targetProduction.Id,
                    (int)TcdAdminMessageTypes.TcdUpdateTargetProduction,
                    this.EcolabAccountNumber);
            }
        }
    }
}