﻿// -----------------------------------------------------------------------
// <copyright file="ManualLaborController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Input Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models.Common;
    using Ecolab.Models.ManualInput.ManualLabor;
    using Ecolab.Models.PlantSetup.ShiftLabor;
    using Models.ManualInputs.Labor;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ManualInputs;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using WebModel = Models.PlantSetup;

    /// <summary>
    ///     Class ManualLaborController.
    /// </summary>
    [Authorize]
    public class ManualLaborController : BaseApiController
    {
        /// <summary>
        ///     ShiftBreak Service
        /// </summary>
        private readonly ILaborService laborService;

        /// <summary>
        ///     The manual labor service
        /// </summary>
        private readonly IManualLaborService manualLaborService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ManualLaborController" /> class.
        /// </summary>
        /// <param name="userService">The user Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="manualLaborService">The manual labor service.</param>
        /// <param name="laborService">The labor Service</param>
        public ManualLaborController(IUserService userService, IPlantService plantService, IManualLaborService manualLaborService, ILaborService laborService) : base(userService, plantService)
        {
            this.manualLaborService = manualLaborService;
            this.laborService = laborService;
        }

        /// <summary>
        ///     Gets the manual labor details with cost.
        /// </summary>
        /// <param name="ecolabAccountNumber">passing ecolab account number.</param>
        /// <param name="regionId">passing the region id.</param>
        /// <returns>List of manual labor details.</returns>
        public ManualLaborListDetails GetManualLaborDetails(string ecolabAccountNumber, int regionId)
        {
            ManualLaborListDetails objManualLaborListDetails = new ManualLaborListDetails();
            List<LaborType> laborType = this.laborService.FetchLabourType();
            List<GroupType> laborLocation = this.laborService.GetGroupTypeDetails();

            IEnumerable<WebModel.LaborTypeModel> laborTypeList = Mapper.Map<IEnumerable<LaborType>, IEnumerable<WebModel.LaborTypeModel>>(laborType);
            IEnumerable<WebModel.GroupTypeModel> locationTypeList = Mapper.Map<IEnumerable<GroupType>, IEnumerable<WebModel.GroupTypeModel>>(laborLocation);

            objManualLaborListDetails.Locations = locationTypeList;
            objManualLaborListDetails.LaborTypes = laborTypeList;

            return objManualLaborListDetails;
        }

        /// <summary>
        ///     Labors the cost.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="locationId">Location Identifier</param>
        /// <param name="manHourTypeId">Man Hour Type Id</param>
        /// <returns>System.Int32.</returns>
        [HttpGet]
        public ManualLaborListDetails LaborCost(string ecolabAccountNumber, int locationId, int manHourTypeId)
        {
            ManualLaborListDetails objManualLaborListDetails = new ManualLaborListDetails();
            IEnumerable<ManualLabor> objManualInputLabor = this.manualLaborService.GetManualLaborDetails(ecolabAccountNumber, manHourTypeId, locationId);
            LaborTypeCost cost = this.laborService.FetchCostByLabourType(manHourTypeId, this.EcolabAccountNumber);
            IEnumerable<Models.ManualInputs.ManualLabor.ManualLabor> manualLaborDetailsList = Mapper.Map<IEnumerable<ManualLabor>, IEnumerable<Models.ManualInputs.ManualLabor.ManualLabor>>(objManualInputLabor);
            objManualLaborListDetails.Cost = cost !=null ? cost.Cost : 0;
            objManualLaborListDetails.ManualLaborList = manualLaborDetailsList;
            return objManualLaborListDetails;
        }

        /// <summary>
        /// Saves the labor data.
        /// </summary>
        /// <param name="manualLaborList">The manual labor list.</param>
        /// <returns>
        /// HttpResponseMessage.
        /// </returns>
        [HttpPost]
        public ManualLaborListDetails SaveLaborData(ManualLaborListDetails manualLaborList)
        {
            int manualLaborId = 0;
            ManualLaborListDetails objManualLaborListDetails = new ManualLaborListDetails();
            IPrincipal user = HttpContext.Current.User;
            IEnumerable<Models.ManualInputs.ManualLabor.ManualLabor> manualLabors = manualLaborList.ManualLaborList;
            if(user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;
                foreach(Models.ManualInputs.ManualLabor.ManualLabor manualLabor in manualLabors)
                {
                    ManualLabor objManualLabor = Mapper.Map<Models.ManualInputs.ManualLabor.ManualLabor, ManualLabor>(manualLabor);
                    if(manualLabor.Id == -1 && manualLabor.AllocatedManHours > 0)
                    {
                        manualLaborId = this.manualLaborService.SaveManualLaborDetails(objManualLabor, userId);
                        objManualLabor.Id = manualLaborId;
                        objManualLabor.EcolabAccountNumber = EcolabAccountNumber;
                        objManualLabor.StartDate = DateTime.SpecifyKind(objManualLabor.StartDate, DateTimeKind.Utc);
                        objManualLabor.EndDate = DateTime.SpecifyKind(objManualLabor.EndDate, DateTimeKind.Utc);
                        Push.PushToQueue(objManualLabor, this.UserId, objManualLabor.Id, (int)TcdAdminMessageTypes.TcdAddManualInputLabor, this.EcolabAccountNumber);
                    }
                    else if(manualLabor.Id > 0)
                    {
                        this.manualLaborService.UpdateManualLaborDetails(objManualLabor, userId);
                        objManualLabor.EcolabAccountNumber = EcolabAccountNumber;
                        objManualLabor.StartDate = DateTime.SpecifyKind(objManualLabor.StartDate, DateTimeKind.Utc);
                        objManualLabor.EndDate = DateTime.SpecifyKind(objManualLabor.EndDate, DateTimeKind.Utc);
                        Push.PushToQueue(objManualLabor, this.UserId, objManualLabor.Id, (int)TcdAdminMessageTypes.TcdUpdateManualInputLabor, this.EcolabAccountNumber);
                    }
                    objManualLaborListDetails = this.LaborCost(manualLabor.ecolabAccNum, manualLabor.LocationId, manualLabor.ManHourTypeId);
                }
            }
            return objManualLaborListDetails;
        }

        /// <summary>
        /// Method to delete ManualInputLabor
        /// </summary>
        /// <param name="manualLaborList">The manual labor list.</param>
        /// <returns>
        /// ManualLaborListDetails
        /// </returns>
        [HttpPost]
        public ManualLaborListDetails DeleteManualLabor(ManualLaborListDetails manualLaborList)
        {
            ManualLaborListDetails objManualLaborListDetails = new ManualLaborListDetails();
            IPrincipal user = HttpContext.Current.User;
            IEnumerable<Models.ManualInputs.ManualLabor.ManualLabor> manualLabors = manualLaborList.ManualLaborList;
            if(user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;
                foreach(Models.ManualInputs.ManualLabor.ManualLabor manualLabor in manualLabors)
                {
                    ManualLabor objManualLabor = Mapper.Map<Models.ManualInputs.ManualLabor.ManualLabor, ManualLabor>(manualLabor);
                    if(manualLabor.Id > 0)
                    {
                        this.manualLaborService.DeleteManualLabor(manualLabor.Id, userId);
                        Push.PushToQueue(objManualLabor, this.UserId, objManualLabor.Id, (int)TcdAdminMessageTypes.TcdDeleteManualLabor , this.EcolabAccountNumber);
                        objManualLaborListDetails = this.LaborCost(manualLabor.ecolabAccNum, manualLabor.LocationId, manualLabor.ManHourTypeId);
                    }
                }
            }
            return objManualLaborListDetails;
        }
    }
}