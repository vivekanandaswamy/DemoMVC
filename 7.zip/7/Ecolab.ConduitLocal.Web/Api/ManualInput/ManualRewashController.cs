﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewashController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Input Rewash Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models.ManualInput;
    using Models.ManualInput.Rewash;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;
    using MIWebModel = Models.ManualInput;
    using Model = Ecolab.Models.ManualInput.Rewash;

    /// <summary>
    ///     class ManualRewashController
    /// </summary>
    public class ManualRewashController : BaseApiController
    {
        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualProductionDataEntryService manualProductionService;

        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualRewashService manualRewashService;

        /// <summary>
        ///     Initializes a new instance of the ManualRewashController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="manualRewashService">Manual Input Rewash Service</param>
        /// <param name="manualProductionService">Manual Production Data Service</param>
        public ManualRewashController(IUserService userService, IPlantService plantService, IManualRewashService manualRewashService, IManualProductionDataEntryService manualProductionService)
            : base(userService, plantService)
        {
            this.manualRewashService = manualRewashService;
            this.manualProductionService = manualProductionService;
        }

        /// <summary>
        ///     Fetch Rewash details
        /// </summary>
        /// <returns>ManualRewashViewModel</returns>
        [HttpGet]
        public ManualRewashViewModel Fetch()
        {            
            ManualRewashViewModel model = new ManualRewashViewModel();
            model.WasherGroups = this.FetchWasherGroups();            
            return model;
        }

        /// <summary>
        ///     Method to return list of washer groups
        /// </summary>
        /// <returns>List of WasherGroups</returns>
        public List<GroupTypeModel> FetchWasherGroups()
        {
            return Mapper.Map<List<GroupType>, List<GroupTypeModel>>(this.manualProductionService.FetchWasherGroups(this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="id">WasherGroupId</param>
        /// <param name="recordedDate">Recorded Date</param>
        /// <returns>List of Washers</returns>
        [HttpGet]
        public List<MIWebModel.WashProgramSetupModel> FetchMiFormulaDetails(int id,string recordedDate)
        {
            return Mapper.Map<List<WashProgramSetup>, List<MIWebModel.WashProgramSetupModel>>(this.manualRewashService.FetchFormulasByGroupId(id, this.EcolabAccountNumber, recordedDate));
        }

        /// <summary>
        ///     Method to fetch Rewash reason
        /// </summary>
        /// <returns>List of RewashReason</returns>
        private IEnumerable<RewashReason> FetchRewashReason()
        {
            return Mapper.Map<IEnumerable<Model.RewashReason>, IEnumerable<RewashReason>>(this.manualRewashService.FetchRewashReason());
        }

        /// <summary>
        ///     Method to save ManualRewash data
        /// </summary>
        /// <param name="manualRewashViewModel">Manual Rewash View Model</param>
        /// <returns>ManualRewashViewModel</returns>
        [HttpPost]
        public ManualRewashViewModel SaveManualProduction(ManualRewashViewModel manualRewashViewModel)
        {
            string result = string.Empty;
            //foreach (ManualRewash item in manualRewashViewModel.Rewash)
            //{
            //    ManualRewash manualRewash = item;
            //    manualRewash.RecordedDate = DateTime.ParseExact(item.RecordedDate, "M/d/yyyy", new CultureInfo("en-US"), DateTimeStyles.None).ToShortDateString();
            //    Model.ManualRewash manualProductionModelService = Mapper.Map<ManualRewash, Model.ManualRewash>(manualRewash);
            //    if (item.Id == -1)
            //    {
            //        if (Math.Abs(item.Value) > 0)
            //        {
            //            int rewashId = 0;
            //            result = this.manualRewashService.SaveManualRewash(manualProductionModelService, this.EcolabAccountNumber, this.UserId, out rewashId);
            //            manualProductionModelService.Id = rewashId;
            //            manualProductionModelService.EcolabAccountNumber = this.EcolabAccountNumber;

            //            Model.ManualRewashContainer manualRewashData = new Model.ManualRewashContainer();
            //            manualRewashData.ManualRewashData = manualProductionModelService;

            //            Push.PushToQueue(manualRewashData, this.UserId, manualRewashData.ManualRewashData.Id, (int)TcdAdminMessageTypes.TcdAddManualInputRewash, this.EcolabAccountNumber);
            //        }
            //    }
            //    else
            //    {
            //        if (string.IsNullOrEmpty(result))
            //        {
            //            result = this.manualRewashService.UpdateManualRewash(manualProductionModelService, this.EcolabAccountNumber, this.UserId);
            //        }
            //        else
            //        {
            //            this.manualRewashService.UpdateManualRewash(manualProductionModelService, this.EcolabAccountNumber, this.UserId);
            //        }
            //        Model.ManualRewashContainer manualRewashData = new Model.ManualRewashContainer();
            //        manualProductionModelService.EcolabAccountNumber = this.EcolabAccountNumber;
            //        manualRewashData.ManualRewashData = manualProductionModelService;

            //        Push.PushToQueue(manualRewashData, this.UserId, manualRewashData.ManualRewashData.Id, (int)TcdAdminMessageTypes.TcdUpdateManualInputRewash, this.EcolabAccountNumber);
            //    }
            //}
            ManualRewash manualRewash = manualRewashViewModel.Rewash[0];
            manualRewash.RecordedDate = DateTime.ParseExact(manualRewash.RecordedDate, "M/d/yyyy", new CultureInfo("en-US"), DateTimeStyles.None).ToShortDateString();
            Model.ManualRewash manualProductionModelService = Mapper.Map<ManualRewash, Model.ManualRewash>(manualRewash);
            if (Math.Abs(manualRewash.Value) > 0)
            {
                int rewashId = 0;
                result = this.manualRewashService.SaveManualRewash(manualProductionModelService, this.EcolabAccountNumber, this.UserId, out rewashId);
                manualProductionModelService.Id = rewashId;
                manualProductionModelService.EcolabAccountNumber = this.EcolabAccountNumber;
                Model.ManualRewashContainer manualRewashData = new Model.ManualRewashContainer();
                manualRewashData.ManualRewashData = manualProductionModelService;
                Push.PushToQueue(manualRewashData, this.UserId, manualRewashData.ManualRewashData.Id, (int)TcdAdminMessageTypes.TcdAddManualInputRewash, this.EcolabAccountNumber);
            }
            else
            {
                result ="501";
            }

            manualRewashViewModel.Rewash[0].Result = result;
            return this.FetchManualRewash(manualRewashViewModel.Rewash[0]);
        }

        /// <summary>
        ///     Method to get Rewash data details based on washer group id and formula id
        /// </summary>
        /// <param name="manualRewash">ManualProductionViewModel</param>
        /// <returns>Production Data</returns>
        [HttpPost]
        public ManualRewashViewModel FetchManualRewash(ManualRewash manualRewash)
        {
            ManualRewashViewModel model = new ManualRewashViewModel();
            List<ManualRewash> manualRewashList = Mapper.Map<List<Model.ManualRewash>, List<ManualRewash>>(this.manualRewashService.FetchManualRewash(manualRewash.WasherGroupId, this.EcolabAccountNumber));
            manualRewashList.ForEach(x => x.RecordedDate = Convert.ToDateTime(x.RecordedDate).ToString("d"));            
            model.Rewash =manualRewashList;
            model.RewashReason = this.FetchRewashReason().ToList();
            if (!string.IsNullOrEmpty(manualRewash.Result))
            {
                model.Rewash[0].Result = manualRewash.Result;
            }
            model.Formulas = FetchMiFormulaDetails(manualRewash.WasherGroupId, DateTime.Now.ToString("d"));
            return model;
        }

        /// <summary>
        ///     Method to delete ManualInputRewash
        /// </summary>
        /// <param name="manualRewashViewModel">Manual Rewash View Model</param>
        /// <returns>ManualRewashViewModel</returns>
        [HttpPost]
        public ManualRewashViewModel DeleteManualRewash(ManualRewashViewModel manualRewashViewModel)
        {
            ManualRewash manualRewash = manualRewashViewModel.Rewash[1];
            manualRewash.RecordedDate = DateTime.ParseExact(manualRewash.RecordedDate, "M/d/yyyy", new CultureInfo("en-US"), DateTimeStyles.None).ToShortDateString();
            Model.ManualRewash manualRewashModel = Mapper.Map<ManualRewash, Model.ManualRewash>(manualRewash);
            manualRewashViewModel.Rewash[0].Result = this.manualRewashService.DeleteManualRewash(manualRewashModel.Id, this.EcolabAccountNumber, this.UserId);

            Model.ManualRewashContainer manualRewashData = new Model.ManualRewashContainer();
            manualRewashData.ManualRewashData = manualRewashModel;
            manualRewashData.ManualRewashData.IsDeleted = true;
            manualRewashData.ManualRewashData.EcolabAccountNumber = this.EcolabAccountNumber;

            Push.PushToQueue(manualRewashData, this.UserId, manualRewashData.ManualRewashData.Id, (int)TcdAdminMessageTypes.TcdDeleteManualInputRewash, this.EcolabAccountNumber);
            return this.FetchManualRewash(manualRewashViewModel.Rewash[0]);
        }
    }
}