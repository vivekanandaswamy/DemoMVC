﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Input BatchData Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.ManualInput
{
	using System;
	using System.Collections.Generic;
	using System.Globalization;
	using System.Web.Http;
	using AutoMapper;
	using Ecolab.Conduit.Library.Enums;
	using Ecolab.Conduit.PushHandler;
	using Ecolab.Models.PlantSetup;
	using Models.ManualInput.Batch;
	using Models.PlantSetup;
	using Services.Interfaces;
	using Services.Interfaces.ManualInput;
	using MIWebModel = Models.ManualInput;
	using ServiceModel = Ecolab.Models.ManualInput;
	using Ecolab.Models;

    /// <summary>
    ///     class ManualBatchController
    /// </summary>
    public class ManualBatchController : BaseApiController
    {
        /// <summary>
        ///     BatchData Service
        /// </summary>
        private readonly IManualBatchDataService manualBatchDataService;

        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualProductionDataEntryService manualProductionService;

        /// <summary>
        ///     Initializes a new instance of the ManualBatchController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="manualBatchDataService">manualBatchData Service</param>
        /// <param name="manualProductionService">Manual Production Data Service</param>
        public ManualBatchController(IUserService userService, IPlantService plantService, IManualBatchDataService manualBatchDataService, IManualProductionDataEntryService manualProductionService)
            : base(userService, plantService)
        {
            this.manualBatchDataService = manualBatchDataService;
            this.manualProductionService = manualProductionService;
        }

        /// <summary>
        ///     Gets the manual batch date
        /// </summary>
        /// <returns>The latest batch date.</returns>
        [HttpGet]
        public ServiceModel.ManualBatchData GetBatchDate(string id)
        {
            ServiceModel.ManualBatchData objManualBatchData = this.manualBatchDataService.GetManualBatchDate(id);
            if (objManualBatchData != null)
            {
                objManualBatchData.StartDate.ToShortDateString();
            }
            else
            {
                objManualBatchData = new ServiceModel.ManualBatchData();
                objManualBatchData.StartDate = DateTime.Now;

                objManualBatchData.StartDate.ToShortDateString();
            }
            return objManualBatchData;
        }

        /// <summary>
        ///     Fetch Batch data
        /// </summary>
        /// <param name="id">id of the batch to fetch details</param>
        /// <returns>ManualBatchViewModel </returns>
        [HttpGet]
        public ManualBatchViewModel Fetch(int id)
        {
            ManualBatchViewModel objManualBatchViewModel = new ManualBatchViewModel 
			{ 
				Formulas = this.FetchMiFormulaDetails(id),
				Batch = new ManualBatch
                {
                    DesiredUnits = this.manualProductionService.FetchUnits(this.EcolabAccountNumber)
                },
                Washers = this.FetchMiWasherDetails(id), WasherGroups = new List<GroupTypeModel>()
            };
            return objManualBatchViewModel;
        }

        /// <summary>
        ///     Method to return list of washer groups
        /// </summary>
        /// <param name="data">date to select washer groups</param>
        /// <returns>List of WasherGroups</returns>
        [HttpGet]
        public List<GroupTypeModel> FetchWasherGroups(string data)
        {
            return Mapper.Map<List<ServiceModel.GroupType>, List<GroupTypeModel>>(this.manualBatchDataService.FetchBatchWasherGroupBySelectedDate(DateTime.ParseExact(data, "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None), this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get all the washers/machines assosiated to the washer group
        /// </summary>
        /// <param name="groupId">WasherGroupId</param>
        /// <returns>List of Formulas</returns>
        public List<MachineSetupModel> FetchMiWasherDetails(int groupId)
        {
            return Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.manualBatchDataService.FetchBatchWashersByGroupId(groupId, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="id">WasherGroupId</param>
        /// <returns>List of Washers</returns>
        [HttpGet]
        public List<MIWebModel.WashProgramSetupModel> FetchMiFormulaDetails(int id)
        {
            return Mapper.Map<List<ServiceModel.WashProgramSetup>, List<MIWebModel.WashProgramSetupModel>>(this.manualBatchDataService.FetchBatchFormulasByGroupId(id, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to return list of Batches
        /// </summary>
        /// <param name="manualBatch">manual batch object</param>
        /// <returns>List of Batches</returns>
        [HttpPost]
        public List<ServiceModel.ManualBatchData> FetchBatchByGroupId(ManualBatch manualBatch)
        {
            return Mapper.Map<List<ServiceModel.ManualBatchData>, List<ServiceModel.ManualBatchData>>(this.manualBatchDataService.FetchBatchByGroupId(manualBatch.WasherGroupId, manualBatch.WasherId, manualBatch.FormulaId, manualBatch.StartDate, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to return Batch details
        /// </summary>
        /// <param name="manualBatch">manual batch object</param>
        /// <returns>Batch details for the selected batch</returns>
        [HttpPost]
        public ManualBatchDataModel FetchBatchDetailsByBatchId(ManualBatch manualBatch)
        {
            ServiceModel.ManualBatchData objManualBatchData = this.manualBatchDataService.FetchBatchDetailsByBatchId(manualBatch.Id, this.EcolabAccountNumber);
            ManualBatchDataModel objWebModel = new ManualBatchDataModel { Id = objManualBatchData.Id, RecordingValue = objManualBatchData.RecordingValue, StartDate = objManualBatchData.StartDate };
            DateTime time = DateTime.Today.Add(objManualBatchData.StartTime);
            objWebModel.StartTime = time.ToString("hh:mm tt");

            return objWebModel;
        }

        /// <summary>
        ///     Update manual batch data details
        /// </summary>
        /// <param name="manualBatchData">manual batch object</param>
        /// <returns>updated batch data</returns>
        [HttpPost]
        public string UpdateManualBatch(ManualBatch manualBatchData)
        {
			string status = string.Empty;
            ServiceModel.ManualBatchData objManualBatchData = new ServiceModel.ManualBatchData { RecordingValue = manualBatchData.RecordingValue, Id = manualBatchData.Id, StartDate = manualBatchData.StartDate, StartTime = manualBatchData.StartTime };
            //string status = this.manualBatchDataService.UpdateManualBatch(objManualBatchData, this.EcolabAccountNumber, this.UserId);
            objManualBatchData.EcolabAccountNumber = this.EcolabAccountNumber;
            Push.PushToQueue(objManualBatchData, this.UserId, objManualBatchData.Id, (int)TcdAdminMessageTypes.TcdUpdateManualBatch, this.EcolabAccountNumber);

            return status;
        }
    }
}