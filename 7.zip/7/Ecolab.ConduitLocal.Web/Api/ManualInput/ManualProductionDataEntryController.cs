﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionDataEntryController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualProductionDataEntryController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Models.ManualInput;
    using Ecolab.Models.ManualInput.Production;
    using Ecolab.Models.PlantSetup;
    using Models.ManualInput;
    using Models.ManualInput.Production;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Conduit.Library.Enums;

    /// <summary>
    ///     class ManualProductionDataEntryController
    /// </summary>
    public class ManualProductionDataEntryController : BaseApiController
    {
        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualProductionDataEntryService manualProductionService;

        /// <summary>
        ///     Initializes a new instance of the ManualProductionDataEntryController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="manualProductionService">ManualProduction Service</param>
        public ManualProductionDataEntryController(IUserService userService, IPlantService plantService, IManualProductionDataEntryService manualProductionService)
            : base(userService, plantService)
        {
            this.manualProductionService = manualProductionService;
        }

        /// <summary>
        ///     Method to get all the washer groups
        /// </summary>
        /// <returns> List of washer groups</returns>
        [HttpGet]
        public ManualProductionViewModel FetchMiWasherGroups()
        {
            ManualProductionViewModel objProductionViewModel = new ManualProductionViewModel { Formulas = new List<WashProgramSetupModel>(), Washers = new List<MachineSetupModel>(), WasherGroups = this.FetchWasherGroups() };
            return objProductionViewModel;
        }

        /// <summary>
        ///     Method to return list of washer groups
        /// </summary>
        /// <returns>List of WasherGroups</returns>
        public List<GroupTypeModel> FetchWasherGroups()
        {
            return Mapper.Map<List<GroupType>, List<GroupTypeModel>>(this.manualProductionService.FetchWasherGroups(this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="groupId">WasherGroupId</param>
        /// <returns>List of Formulas</returns>
        public List<MachineSetupModel> FetchMiWasherDetails(string groupId)
        {
            return Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.manualProductionService.FetchWashersByGroupId(groupId, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="groupId">WasherGroupId</param>
        /// <returns>List of Washers</returns>
        public List<WashProgramSetupModel> FetchMiFormulaDetails(string groupId)
        {
            return Mapper.Map<List<WashProgramSetup>, List<WashProgramSetupModel>>(this.manualProductionService.FetchFormulasByGroupId(groupId, this.EcolabAccountNumber));
        }

        /// <summary>
        ///     Method to get formula and washer details by washer group id
        /// </summary>
        /// <param name="id">WasherGroupId</param>
        /// <returns>Manual Production Data</returns>
        [HttpGet]
        public ManualProductionViewModel FetchWasherFormulaByWasherGroup(string id)
        {
            ManualProductionViewModel objProductionViewModel = new ManualProductionViewModel { Formulas = this.FetchMiFormulaDetails(id) };
            return objProductionViewModel;
        }

	}
}