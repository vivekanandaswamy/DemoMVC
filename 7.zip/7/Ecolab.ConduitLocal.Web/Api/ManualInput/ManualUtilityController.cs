﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtilityController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualUtilityController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;
    using MIWebModel = Models.ManualInput.Utility;
    using Model = Ecolab.Models.ManualInput;

    /// <summary>
    ///     class MonitorSetupController
    /// </summary>
    public class ManualUtilityController : BaseApiController
    {
        /// <summary>
        ///     Manual Utility Service
        /// </summary>
        private readonly IManualUtilityService manualUtilityService;

        /// <summary>
        ///     Initializes a new instance of the ManualUtilityController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="manualUtiltiyService">MonitorSetup Service</param>
        public ManualUtilityController(IUserService userService, IPlantService plantService, IManualUtilityService manualUtiltiyService)
            : base(userService, plantService)
        {
            this.manualUtilityService = manualUtiltiyService;
        }

        /// <summary>
        ///     Get the manual utility data
        /// </summary>
        /// <returns>returns the list of Manual Input utilities</returns>
        [HttpGet]
        public List<MIWebModel.ManualUtilityViewModel> FetchManualUtilities()
        {
            return FetchUtilityGroupedData(this.manualUtilityService.FetchManualUtility(this.EcolabAccountNumber).ToList());
        }

        /// <summary>
        ///     Method to return list of Utilities
        /// </summary>
        /// <param name="lstManualUtility">List of Manual Utilities</param>
        /// <returns>list of Utility view model</returns>
        private static List<MIWebModel.ManualUtilityViewModel> FetchUtilityGroupedData(IEnumerable<Model.ManualUtility> lstManualUtility)
        {
            List<IGrouping<int, Model.ManualUtility>> viewModel = lstManualUtility.GroupBy(x => x.MeterId).ToList();
            var lstViewModel = new List<MIWebModel.ManualUtilityViewModel>();
            foreach (IGrouping<int, Model.ManualUtility> item in viewModel)
            {
                MIWebModel.ManualUtilityViewModel objViewModel = new MIWebModel.ManualUtilityViewModel();
                Model.ManualUtility utilityItem = item.FirstOrDefault();
                FetchUtilityModel(item, objViewModel, utilityItem);
                lstViewModel.Add(objViewModel);
            }

            return lstViewModel;
        }

        /// <summary>
        ///     Method to fetch Utility view object
        /// </summary>
        /// <param name="item">Grouped Manual Utility object</param>
        /// <param name="objViewModel">ManualUtilityViewModel object</param>
        /// <param name="utilityItem">ManualUtility object</param>
        private static void FetchUtilityModel(IGrouping<int, Model.ManualUtility> item, MIWebModel.ManualUtilityViewModel objViewModel, Model.ManualUtility utilityItem)
        {
            objViewModel.Description = utilityItem.Description;
            objViewModel.GroupId = utilityItem.GroupId;
            objViewModel.LocationName = utilityItem.LocationName;
            objViewModel.MeterId = utilityItem.MeterId;
            objViewModel.MeterTickUnit = utilityItem.MeterTickUnit;
            objViewModel.UtilityTypeId = utilityItem.UtilityTypeId;
            objViewModel.UtilityTypeName = utilityItem.UtilityTypeName;
            objViewModel.Id = utilityItem.Id;
            objViewModel.MaxValueLimit = utilityItem.MaxValueLimit;
            objViewModel.MyServiceMeterGuid = utilityItem.MyServiceMeterGuid;
            List<MIWebModel.ManualUtilityModel> lstManualUtilityModel = item.Select(util => new MIWebModel.ManualUtilityModel { RecordedDate = util.RecordedDate.Year == 1 ? string.Empty : util.RecordedDate.ToString("d"), Id = util.Id, Usage = util.Usage, Value = util.Value }).ToList();
            if (lstManualUtilityModel != null)
            {
                objViewModel.Utility = lstManualUtilityModel.OrderByDescending(x => x.Id).ToList();
                objViewModel.Utility.LastOrDefault().FirstRecord = true;
            }
        }

        /// <summary>
        ///     Get the manual utility data
        /// </summary>
        /// <param name="meterId">MeterId to get utility details</param>
        /// <returns>returns Manual Input utility</returns>
        public MIWebModel.ManualUtilityViewModel FetchManualUtility(int meterId)
        {
            List<Model.ManualUtility> lstManualUtility = this.manualUtilityService.FetchManualUtility(this.EcolabAccountNumber).ToList();
            IEnumerable<IGrouping<int, Model.ManualUtility>> viewModel = lstManualUtility.GroupBy(x => x.MeterId).ToList().Where(k => k.Key == meterId);
            MIWebModel.ManualUtilityViewModel objViewModel = new MIWebModel.ManualUtilityViewModel();
            foreach (IGrouping<int, Model.ManualUtility> item in viewModel)
            {
                Model.ManualUtility utilityItem = item.FirstOrDefault();
                FetchUtilityModel(item, objViewModel, utilityItem);
            }
            return objViewModel;
        }

        /// <summary>
        ///     Insert manual utility data details
        /// </summary>
        /// <param name="manualUtilityViewModel">manual utility object</param>
        /// <returns>result of the save operation</returns>
        [HttpPost]
        public List<MIWebModel.ManualUtilityViewModel> SaveManualUtility(MIWebModel.ManualUtilityViewModel manualUtilityViewModel)
        {
            string result = string.Empty;
            int utilityId = 0;

            foreach (MIWebModel.ManualUtilityModel item in manualUtilityViewModel.Utility)
            {
                Model.ManualUtility objServiceModel =
                    new Model.ManualUtility
                    {
                        MeterId = manualUtilityViewModel.MeterId,
                        EcolabAccountNumber = this.EcolabAccountNumber,
                        Id = item.Id,
                        RecordedDate = DateTime.Parse(item.RecordedDate, new CultureInfo("en-US"), DateTimeStyles.None),
                        Value = item.Value,
                        Usage = item.Usage
                    };
                if (item.Id == -1)
                {
                    if (Math.Abs(item.Value) > 0)
                    {
                        result = this.manualUtilityService.SaveManualUtility(objServiceModel, this.EcolabAccountNumber, this.UserId, out utilityId);
                        objServiceModel.Id = utilityId;
                        Push.PushToQueue(objServiceModel, this.UserId, objServiceModel.Id, (int)TcdAdminMessageTypes.TcdAddManualInputUtility, this.EcolabAccountNumber);
                    }
                }
                else
                {
                    this.manualUtilityService.UpdateManualUtility(objServiceModel, this.EcolabAccountNumber, this.UserId);
                    Push.PushToQueue(objServiceModel, this.UserId, objServiceModel.Id, (int)TcdAdminMessageTypes.TcdAddManualInputUtility, this.EcolabAccountNumber);
                }
            }
            List<MIWebModel.ManualUtilityViewModel> lstUtility = this.FetchManualUtilities();
            lstUtility.ForEach(se => se.Result = result);
            return lstUtility;
        }

        /// <summary>
        ///     Delete manual utility data details
        /// </summary>
        /// <param name="manualUtilityViewModel">utility id</param>
        /// <returns>ManualUtilityViewModel</returns>
        [HttpPost]
        public MIWebModel.ManualUtilityViewModel DeleteManualUtility(MIWebModel.ManualUtilityViewModel manualUtilityViewModel)
        {
            string result = string.Empty;
            IPrincipal user = HttpContext.Current.User;
            if (user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;

                foreach (MIWebModel.ManualUtilityModel Utitlityitem in manualUtilityViewModel.Utility)
                {
                    Model.ManualUtility ManualUtilityServiceModel = new Model.ManualUtility()
                    {
                        MeterId = manualUtilityViewModel.MeterId,
                        Usage = Utitlityitem.Usage,
                        Value = Utitlityitem.Value,
                        Id = Utitlityitem.Id,
                        EcolabAccountNumber = this.EcolabAccountNumber
                    };

                    if (Utitlityitem.RecordedDate == "-1" && Utitlityitem.Value == -1 && Utitlityitem.Usage == -1)
                    {
                        ManualUtilityServiceModel.IsDeleted = true;
                        result = this.manualUtilityService.DeleteManualUtility(ManualUtilityServiceModel.Id, this.EcolabAccountNumber, userId);
                        Push.PushToQueue(ManualUtilityServiceModel, this.UserId, Utitlityitem.Id, (int)TcdAdminMessageTypes.TcdDeleteManualInputUtility, this.EcolabAccountNumber);
                    }
                    else
                    {
                        if (Utitlityitem.Id != -1)
                        {
                            if (Math.Abs(Utitlityitem.Value) > 0)
                            {
                                ManualUtilityServiceModel.RecordedDate = DateTime.SpecifyKind(Convert.ToDateTime(Utitlityitem.RecordedDate), DateTimeKind.Utc);
                                result = this.manualUtilityService.UpdateManualUtility(ManualUtilityServiceModel, this.EcolabAccountNumber, this.UserId);
                                Push.PushToQueue(ManualUtilityServiceModel, this.UserId, ManualUtilityServiceModel.Id, (int)TcdAdminMessageTypes.TcdUpdateManualInputUtility, this.EcolabAccountNumber);
                            }
                        }
                    }
                }
            }
            MIWebModel.ManualUtilityViewModel objMiWebModel = this.FetchManualUtility(manualUtilityViewModel.MeterId);
            objMiWebModel.Result = result;
            return objMiWebModel;
        }
    }
}