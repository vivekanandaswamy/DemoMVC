﻿// -----------------------------------------------------------------------
// <copyright file="WasherController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Washer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.Washers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers;
    using Models.Washers;
    using Services;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Dcs.Entities;
    using WebModel = Models;
    using Services.Interfaces;
    using Services.Interfaces.Plc;
    using Services.Plc;
    using Models.Common;
    using Castle.Core.Logging;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     Class WasherController.
    /// </summary>
    public class WasherController : ApiController
    {
        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        /// The injection service
        /// </summary>
        private readonly IInjectionService injectionService;

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormulaController" /> class.
        /// </summary>
        /// <param name="_washerServices">The _washer services.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        /// <param name="injectionService">The injection service.</param>
        public WasherController(IWasherServices _washerServices, IWasherGroupService washerGroupService, IInjectionService injectionService)
        {
            this.washerServices = _washerServices;
            this.washerGroupService = washerGroupService;
            this.injectionService = injectionService;
        }

        /// <summary>
        /// Get all the values related to washers
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number.</param>
        /// <returns>
        /// Returns the washers model
        /// </returns>
        [HttpGet]
        public IEnumerable<WashersModel> GetWashersDetails(string ecolabAccountNumber)
        {
            IEnumerable<Washers> washersModel = this.washerServices.GetWashersDetails(ecolabAccountNumber);
            IEnumerable<WashersModel> washers = Mapper.Map<IEnumerable<Washers>, IEnumerable<WashersModel>>(washersModel);
            return washers.ToList().OrderBy(x => x.WasherNumber);
        }

        /// <summary>
        /// Deletes the washers.
        /// </summary>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="isTunnel">if set to <c>true</c> [is tunnel].</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>
        /// The string value the deletion is passed or failed.
        /// </returns>
        [HttpGet]
        public bool WasherDelete(int washerId, bool isTunnel, string ecolabAccountNumber, int washerGroupId)
        {
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;
            Washers washer = new Washers { Id = washerId, WasherTypeFlag = isTunnel, EcolabAccountNumber = ecolabAccountNumber, WasherGroupId = washerGroupId };

            try
            {
                if (user != null)
                {
                    if (isTunnel)
                    {
                        DateTime lastModifiedTimeStamp;
                        this.washerServices.DeleteWasher(isTunnel, washerId, ecolabAccountNumber, userId, out lastModifiedTimeStamp);
                        washer.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        Push.PushToQueue(washer, userId, washer.Id, (int)TcdAdminMessageTypes.TcdDeleteTunnelGeneral, washer.EcolabAccountNumber);
                        return true;
                    }
                    else
                    {
                        DateTime lastModifiedTimeStamp;
                        this.washerServices.DeleteConventional(washerId, ecolabAccountNumber, userId, out lastModifiedTimeStamp);
                        washer.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        washer.InjectionData = injectionService.GetInjectionDetailsForSynch(washer.WasherGroupId);
                        Push.PushToQueue(washer, userId, washer.Id, (int)TcdAdminMessageTypes.TcdDeleteConventionaGeneral, washer.EcolabAccountNumber);
                        return true;
                    }
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Get AlarmSetup Details.
        /// </summary>
        /// <param name="controllerModelId">The controllerModelId</param>
        /// <param name="controllerTypeId">The controllerTypeId</param>
        /// <param name="machineNumber">The machineNumber</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        /// <param name="tunnelId">The tunnel identifier.</param>
        /// <param name="isBatchEjectCondition">if set to <c>true</c> [is batch eject condition].</param>
        /// <returns>
        /// Returns alarm list
        /// </returns>
        [HttpGet]
        public AlarmsData GetAlarmSetupDetails(int controllerModelId, int controllerTypeId, int machineNumber, int washerGroupId, string ecoLabAccountNumber, int washerGroupTypeId, int tunnelId, bool isBatchEjectCondition)
        {
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;
            AlarmsData alarmsData = new AlarmsData();
            IEnumerable<Alarms> alarmsModel = new List<Alarms>();
            if (isBatchEjectCondition)
            {
                alarmsModel = this.washerServices.FetchBatchEjectConditions(controllerModelId, tunnelId, ecoLabAccountNumber, userId);
            }
            else
            {
                alarmsModel = this.washerServices.GetAlarmSetupDetails(controllerModelId, controllerTypeId, machineNumber, ecoLabAccountNumber, washerGroupTypeId, tunnelId);
            }
            if (alarmsModel.ToList().Count > 0)
            {
                alarmsData.LastModifiedTimeStamp = alarmsModel.ToList().Where(obj => obj.Active).DefaultIfEmpty(new Alarms() { LastModifiedTimeStamp = null }).FirstOrDefault().LastModifiedTimeStamp;
            }
            IEnumerable<AlarmsModel> alarms = Mapper.Map<IEnumerable<Alarms>, IEnumerable<AlarmsModel>>(alarmsModel);
            alarmsData.AlarmsModel = alarms;
            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);
            alarmsData.WasherGroupList = washerGroups;
            return alarmsData;
        }

        /// <summary>
        /// Save the Alarm Data
        /// </summary>
        /// <param name="alarmData">Object of alarmData.</param>
        /// <returns>
        /// The result of the save operation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveAlarmStatus(AlarmsModel alarmData)
        {
            int response = 0;
            string alarmMachineMappingIds = string.Empty;
            IPrincipal user = HttpContext.Current.User;
            if (user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;
                string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;
                Alarms alarm = Mapper.Map<AlarmsModel, Alarms>(alarmData);
                alarmMachineMappingIds = String.Join(",", alarm.AlarmMachineMappingIds.Count > 0 ? alarm.AlarmMachineMappingIds : new List<int>() { 0 });
                if (alarmData.IsBatchEjectCondition)
                {
                    alarm.LastModifiedTimeStamp = DateTime.UtcNow;
                    response = this.washerServices.SaveBatchEjectConditionStatus(alarm, userId, ecolabAccountNumber);
                    if (response == 0)
                    {
                        Push.PushToQueue(alarm, userId, 0, (int)TcdAdminMessageTypes.TcdAddBatchEjectConditionStatus, alarm.EcolabAccountNumber);
                    }
                }
                else
                {
                    response = this.washerServices.SaveAlarmStatus(alarm, userId, ecolabAccountNumber);
                    if (response == 0)
                    {
                        List<Ecolab.Models.Washers.Alarms> lstAlarms = this.washerServices.GetAlarmStatusDataForWasher(ecolabAccountNumber, alarm.MachineNumber, alarm.TunnelId);
                        Alarms alarms = lstAlarms.Count > 0 ? lstAlarms.First() : new Alarms();
                        alarms.AlarmMachineMappingIds = alarm.AlarmMachineMappingIds;
                        alarms.Ids = lstAlarms.Select(a => a.Id).ToList<int>();
                        alarms.LastModifiedTimeStamp = DateTime.SpecifyKind(alarm.LastModifiedTimeStamp ?? DateTime.Now, DateTimeKind.Utc);
                        Push.PushToQueue(alarms, userId, alarms.Id, (int)TcdAdminMessageTypes.TcdAddAlarmStatus, alarm.EcolabAccountNumber); 
                    }
                }
            }
            try
            {
                if (response == 0)
                {
                    UpdatePLCAlarmStatus(alarmData, alarmMachineMappingIds);
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorFormat("SaveAlarmStatus : PLC Connection failed", ex.Message);
                String msg = string.Empty;
                if (ex.Message.Contains("Timeout has elapsed") ||
                    ex.Message.Contains("Port is disabled") ||
                    ex.Message.Contains("Target machine could not be found") ||
                    ex.Message.Contains("ADS could not be initialized") ||
                    ex.Message.Contains("Open Failed") ||
                    ex.Message.Contains("Retrieving the COM class factory"))
                {
                    msg = "901@" + response;
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, msg);
                }
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        /// <summary>
        /// Updates the PLC alarm status.
        /// </summary>
        /// <param name="alarmData">The alarm data.</param>
        /// <param name="alarmMachineMappingIds">The alarm machine mapping ids.</param>
        public void UpdatePLCAlarmStatus(AlarmsModel alarmData, string alarmMachineMappingIds)
        {
            bool isTunnel = false;
            int controllerId;
            IPlcService plcservice = new PlcService();
            IPlantService plantService = new PlantService();
            IUserService userService = new UserService();
            var plc = new PlcTagController(plcservice, userService, plantService);
            int startIndex = -1;
            List<Tag> tags = new List<Tag>();
            List<int> alarmCodes = this.washerServices.GetAlarmCodesandNumbers(alarmMachineMappingIds, alarmData.IsBatchEjectCondition, alarmData.TunnelId, out isTunnel, out controllerId);
            ControllerInfoForPlcModel controllerInfo = plc.GetControllerInfo(controllerId).FirstOrDefault();

            if (controllerInfo.ControllerTypeId == 2 && controllerInfo.ControllerModelId == 7)
            {
                const int tunnelIndex = 162;
                const int conventionalIndex = 155;
                int actualIndex;
                if (isTunnel)
                    actualIndex = tunnelIndex;
                else
                    actualIndex = conventionalIndex;

                if (isTunnel)
                {
                    if (alarmData.IsBatchEjectCondition)
                        startIndex = ((alarmData.MachineNumber - 1) * actualIndex) + (alarmData.MachineNumber * actualIndex);
                    else
                        startIndex = ((alarmData.MachineNumber - 1) * actualIndex) + ((alarmData.MachineNumber - 1) * actualIndex);
                }
                else
                    startIndex = (alarmData.MachineNumber - 1) * actualIndex;

                for (int alarmindex = 1; alarmindex <= actualIndex; alarmindex++)
                {
                    bool alarmFound = false;
                    foreach (int alarmCode in alarmCodes)
                    {
                        if (alarmindex == alarmCode)
                        {
                            tags.Add(new OpcTag { TagId = startIndex, Value = "1" });
                            alarmFound = true;
                            break;
                        }
                    }
                    if (!alarmFound)
                        tags.Add(new OpcTag { TagId = startIndex, Value = "0" });
                    startIndex++;
                }
                if (isTunnel)
                    plc.WriteTunnelTags(new TagCollection { Tags = tags }, controllerId, 1);
                else
                    plc.WriteTunnelTags(new TagCollection { Tags = tags }, controllerId, 5);
            }
            else if (controllerInfo.ControllerModelId == 11) //PLC-XL
            {
                if (isTunnel)
                {
                    IEnumerable<Alarms> alarmsModel = new List<Alarms>();
                    IPrincipal user = HttpContext.Current.User;
                    int userId = ((CustomPrincipal)user).UserId;
                    string ecolabAccountNumber = ((CustomPrincipal)user).EcolabAccountNumber;
                    if (alarmData.IsBatchEjectCondition)
                    {
                        alarmsModel = this.washerServices.FetchBatchEjectConditions(controllerInfo.ControllerModelId, alarmData.TunnelId, ecolabAccountNumber, userId);
                    }
                    else
                    {
                        alarmsModel = this.washerServices.GetAlarmSetupDetails(controllerInfo.ControllerModelId, controllerInfo.ControllerTypeId, alarmData.MachineNumber, ecolabAccountNumber, alarmData.WasherGroupTypeId, alarmData.TunnelId);
                    }
                    IEnumerable<AlarmsModel> alarms = Mapper.Map<IEnumerable<Alarms>, IEnumerable<AlarmsModel>>(alarmsModel);

                    if (controllerInfo.ControllerTypeId == 13) //5W1CBW
                    {
                        if (alarmData.IsBatchEjectCondition)
                            startIndex = 451;
                        else
                            startIndex = 401;
                    }
                    else if (controllerInfo.ControllerTypeId == 14) //2CBW
                    {
                        if (alarmData.IsBatchEjectCondition)
                            startIndex = 601 + ((alarmData.MachineNumber - 1) * 40);
                        else
                            startIndex = 401 + ((alarmData.MachineNumber - 1) * 40);
                    }

                    foreach (AlarmsModel alarm in alarms)
                    {
                        bool alarmFound = false;
                        if (alarmData.AlarmMachineMappingIds.Contains(alarm.AlarmMachineMappingId))
                        {
                            tags.Add(new MitsubishiTag { Address = "L" + (startIndex), Value = "1" });
                            alarmFound = true;
                            //break;
                        }
                        if (!alarmFound)
                            tags.Add(new MitsubishiTag { Address = "L" + (startIndex), Value = "0" });
                        startIndex++;
                    }
                    if (alarmData.IsBatchEjectCondition)
                    {
                        tags.Add(new MitsubishiTag { Address = "L" + (startIndex), Value = "0" }); //Cbw_BatchEjection[1 .. 40] (38 to 40 Free) so assigning 38  to 0
                        tags.Add(new MitsubishiTag { Address = "L" + (startIndex + 1), Value = "0" }); //39 to 0
                        tags.Add(new MitsubishiTag { Address = "L" + (startIndex + 1), Value = "0" }); //40 to 0
                    }
                    else
                        tags.Add(new MitsubishiTag { Address = "L" + (startIndex), Value = "0" }); //Cbw_StopCondition[1 .. 40] (40 free) so assigning it to 0

                    plc.WritePLCXLTags(tags, controllerInfo.Value, controllerInfo.ControllerId, controllerInfo.ControllerTypeId);
                }
                else
                {
                    var offset = (alarmData.MachineNumber - 1) * 30;

                    if (alarmData.AlarmMachineMappingIds.Count > 0)
                    {
                        tags.Add(new MitsubishiTag { Address = "R" + (329 + offset), Value = "1" });
                    }
                    else
                    {
                        tags.Add(new MitsubishiTag { Address = "R" + (329 + offset), Value = "0" });
                    }

                    //ControllerTypes: 12 - 10 Washers, 13 - 1 Tunnel 5 Washers
                    if (tags != null && tags.Count > 0)
                    {
                        MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tags);
                        plc.WriteTags(mitsubishiTag, controllerInfo.ControllerId, 1, SourcePage.WasherPage);
                    }
                }
            }
        }
    }
}