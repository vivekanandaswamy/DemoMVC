﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The ProductDeviationController Controller </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Http;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.PushHandler;
using Ecolab.ConduitLocal.Web.Models.WasherGroup;
using Ecolab.ConduitLocal.Web.Models.Washers;
using Ecolab.ConduitLocal.Web.Models.Washers.Conventional;
using Ecolab.ConduitLocal.Web.Models.Washers.Tunnel;
using Ecolab.Models.Washers;
using Ecolab.Models.Washers.Conventional;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services;
using Ecolab.Services.Interfaces;
using Ecolab.Services.Interfaces.WasherGroup;
using Ecolab.Services.Interfaces.Washers;
using Ecolab.Services.Interfaces.Washers.Conventional;
using Ecolab.Services.Interfaces.Washers.Tunnel;
using WebModel = Ecolab.ConduitLocal.Web.Models;

namespace Ecolab.ConduitLocal.Web.Api.Washers
{
    using Services.Plc;
    using Services.Interfaces.Plc;
    using Dcs.Entities;
    using Elmah;
    using AutoMapper;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     The ProductDeviationController Controller Class.
    /// </summary>
    [Authorize]
    public class ProductDeviationController : BaseApiController
    {
        /// <summary>
        ///     The Conventional General services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     The Product Deviation Service
        /// </summary>
        private readonly IProductDeviationService productDeviationService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        /// The tunnel number
        /// </summary>
        private static int TunnelNumber;

        /// <summary>
        /// The controller model identifier
        /// </summary>
        private static int ControllerModelId;

        /// <summary>
        /// The washer group type identifier
        /// </summary>
        private static int washerGroupTypeId;

        /// <summary>
        /// Initializes a new instance of the ProductDeviationController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="productDeviationService">The ProductDeviation services.</param>
        /// <param name="conventionalGeneralServices">The conventional general services.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        public ProductDeviationController(IUserService userService, IPlantService plantService, IProductDeviationService productDeviationService, IConventionalGeneralServices conventionalGeneralServices, IWasherGroupService washerGroupService)
            : base(userService, plantService)
        {
            this.productDeviationService = productDeviationService;
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.washerGroupService = washerGroupService;
        }

        /// <summary>
        /// Initializes a new instance of the ProductDeviationController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="productDeviationService">The ProductDeviation services.</param>
        /// <param name="conventionalGeneralServices">The conventional general services.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        /// <param name="plcService">The plc service.</param>
        public ProductDeviationController(IUserService userService, IPlantService plantService, IProductDeviationService productDeviationService, IConventionalGeneralServices conventionalGeneralServices, IWasherGroupService washerGroupService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.productDeviationService = productDeviationService;
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
        }

        /// <summary>
        /// Get all the values related to ProductDeviation Data
        /// </summary>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>
        /// Returns the Product Deviation model
        /// </returns>
        [HttpGet]
        public WasherProductDeviationModel GetProductDeviationData(int machineId, int groupId, int controllerId)
        {
            ConventionalGeneralModel conventionaldata = AutoMapper.Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(this.conventionalGeneralServices.GetConventionalData(machineId, groupId, EcolabAccountNumber));
            Models.WasherGroup.WasherGroup washerGroup = AutoMapper.Mapper.Map<Ecolab.Models.WasherGroup.WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(groupId, EcolabAccountNumber, 0, 12, string.Empty).FirstOrDefault());
            WasherProductDeviationModel washerProductDeviationModel = new WasherProductDeviationModel
            {
                MachineId = conventionaldata.Id,
                WasherGroupId = conventionaldata.WasherGroupId,
                WasherGroupNumber = washerGroup.WasherGroupNumber,
                WasherGroupName = washerGroup.WasherGroupName,
                WasherGroupTypeId = washerGroup.WasherGroupTypeId,
                WasherGroupType = washerGroup.WasherGroupTypeName,
                ControllerId = conventionaldata.ControllerId,
                ControllerModelId = conventionaldata.ControllerModelId,
                ControllerTypeId = conventionaldata.ControllerTypeId,
                MachineNumber = conventionaldata.LfsWasher,
                MachineName = conventionaldata.Name,
                ProductDeviationdata = AutoMapper.Mapper.Map<IEnumerable<ProductDeviation>, IEnumerable<ProductDeviationModel>>(this.productDeviationService.GetProductDeviationData(machineId, controllerId, EcolabAccountNumber)).ToList(),
                PumpsAndMECount = AutoMapper.Mapper.Map<PumpsAndMECount, PumpsAndMECountModel>(this.productDeviationService.GetPumpsAndMECount(controllerId, EcolabAccountNumber)),
                WasherDosingNumber = washerGroup.WasherDosingNumber
            };
            TunnelNumber = conventionaldata.LfsWasher;
            ControllerModelId = conventionaldata.ControllerModelId;
            washerGroupTypeId = washerGroup.WasherGroupTypeId;

            IEnumerable<ProductDeviation> productDeviationList = AutoMapper.Mapper.Map<List<ProductDeviationModel>, List<ProductDeviation>>(washerProductDeviationModel.ProductDeviationdata);
            try
            {
                IPlcService plcService = new PlcService();
                var plc = new PlcTagController(plcService, UserService, PlantService);

                if (conventionaldata != null)
                {
                    if (conventionaldata.ControllerModelId == 11 && washerGroup.WasherGroupTypeId == 1)
                    {
                        List<Tag> plcTagsList = new List<Tag>();
                        TagCollection plctagStatus = new TagCollection();
                        var offset = (conventionaldata.LfsWasher - 1) * 30;

                        if (washerProductDeviationModel.ControllerTypeId == 12 && washerProductDeviationModel.WasherDosingNumber == 2)
                        {
                            plcTagsList = GenerateWasherProductDeviationDosingNumber2Tags(washerProductDeviationModel, conventionaldata.LfsWasher);
                        }
                        else
                        {
                            plcTagsList = GenerateConventionalWasherProductDeviationTags(washerProductDeviationModel, conventionaldata.LfsWasher);
                        }

                        if (plcTagsList.Count > 0 && conventionaldata.ControllerId > 0)
                        {
                            plctagStatus = plc.ValidateWasherConventionalPLCXLTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, conventionaldata.ControllerId, SourcePage.WasherPage);
                            List<string> tagCollectionList = new List<string>();

                            if (washerProductDeviationModel.ControllerTypeId == 12 && washerProductDeviationModel.WasherDosingNumber == 2)
                            {
                                plcTagsList = GenerateWasherProductDeviationDosingNumber2Tags(washerProductDeviationModel, conventionaldata.LfsWasher);
                            }
                            else
                            {
                                plcTagsList = GenerateConventionalWasherProductDeviationTags(washerProductDeviationModel, conventionaldata.LfsWasher);
                            }

                            foreach (MitsubishiTag tag in plcTagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plctagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (tag.Value != null && plcTag.Value != null && tag.TagType != null)
                                    {
                                        if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                        {
                                            //tagCollectionList.Add(tag.Address);
                                            tagCollectionList.Add(tag.TagType);
                                        }
                                    }
                                }
                            }

                            if (tagCollectionList.Count > 0)
                            {
                                int i = 0;
                                int j = 15;
                                foreach (var item in washerProductDeviationModel.ProductDeviationdata)
                                {
                                    i++;
                                    if (washerProductDeviationModel.ControllerTypeId == 12 && washerProductDeviationModel.WasherDosingNumber == 2)
                                    {
                                        washerProductDeviationModel.ProductDeviationdata[i - 1].IsValueDiffForProductDeviationValue = (tagCollectionList.Where(x => x == j.ToString()).ToList().Count > 0) ? true : false;
                                        j++;
                                    }
                                    else
                                    {
                                        washerProductDeviationModel.ProductDeviationdata[i - 1].IsValueDiffForProductDeviationValue = (tagCollectionList.Where(x => x == i.ToString()).ToList().Count > 0) ? true : false;
                                    }
                                }
                            }
                        }
                    }
                    //Read plc values for EcontrolPlus conventional washer product deviation and compare
                    else if (ControllerModelId == 8 && washerGroupTypeId == 1)
                    {
                        List<Tag> uiTags = GetEcontolPlusConventionalProductDeviationTags(productDeviationList.ToList(), productDeviationList.ToList());
                        List<Tag> uiTagsClone = GetEcontolPlusConventionalProductDeviationTags(productDeviationList.ToList(), productDeviationList.ToList());
                        List<string> tagCollectionList = new List<string>();
                        TagCollection plcTags = new TagCollection { Tags = new List<Tag>() };
                        try
                        {
                            plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(uiTagsClone) }, conventionaldata.ControllerId);
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                            //message = "Unable to Connect to PLC";
                        }
                        if (plcTags != null)
                        {
                            foreach (Tag uiTag in uiTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plcTags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (uiTag.Address == plcTag.Address && uiTag.Value.ToUpper() != plcTag.Value.ToUpper())
                                    {
                                        tagCollectionList.Add(uiTag.Address);
                                        break;
                                    }
                                }
                            }
                            int offset = (TunnelNumber - 1) * 30;
                            if (tagCollectionList.Count > 0)
                            {
                                int incrementAddress = 0;
                                foreach (var uiTag in uiTags)
                                {
                                    if (incrementAddress == 8)
                                    {
                                        //Tag for ME1
                                        if (tagCollectionList.Contains(string.Format("D{0}", (518 + offset))))
                                        {
                                            washerProductDeviationModel.ProductDeviationdata[incrementAddress].IsValueDiffForProductDeviationValue = true;
                                        }
                                    }
                                    else if (incrementAddress == 9)
                                    {
                                        //Tag for ME2
                                        if (tagCollectionList.Contains(string.Format("D{0}", (527 + offset))))
                                        {
                                            washerProductDeviationModel.ProductDeviationdata[incrementAddress].IsValueDiffForProductDeviationValue = true;
                                        }
                                    }
                                    else
                                    {
                                        //Tags for pumps
                                        if (tagCollectionList.Contains(string.Format("D{0}", (519 + incrementAddress + offset))))
                                        {
                                            washerProductDeviationModel.ProductDeviationdata[incrementAddress].IsValueDiffForProductDeviationValue = true;
                                        }
                                    }
                                    incrementAddress++;
                                }
                            }
                        }
                    }
                    else
                    {
                        var productDeviationTagData = GenerateConventionalProductDeviationTags(productDeviationList.ToList(), TunnelNumber);
                        var productDeviationPLC = ValidateConventionalProductDeviationPLC(conventionaldata, plc, productDeviationList.ToList(), TunnelNumber);
                        foreach (var item in washerProductDeviationModel.ProductDeviationdata)
                        {
                            //item.
                            washerProductDeviationModel.ProductDeviationdata[(item.ControllerEquipmentID) - 1].IsValueDiffForProductDeviationValue = (productDeviationPLC.Where(x => x.Address.ToUpper() == "PRODUCTDEVIATION" && x.TagType == item.ControllerEquipmentID.ToString()).ToList().Count > 0) ? true : false;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            return washerProductDeviationModel;
        }

        /// <summary>
        /// Save the Product Deviation Data
        /// </summary>
        /// <param name="washerProductDeviationModel">The washer product deviation model.</param>
        /// <returns>
        /// The result of the save operation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveProductDeviationData(WasherProductDeviationModel washerProductDeviationModel)
        {
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;

            IEnumerable<ProductDeviation> productDeviationList = AutoMapper.Mapper.Map<List<ProductDeviationModel>, List<ProductDeviation>>(washerProductDeviationModel.ProductDeviationdata);
            int washerId = productDeviationList.ToList()[0].WasherId;
            List<ProductDeviation> previousProductDeviationList = productDeviationService.GetProductDeviationList(washerId, EcolabAccountNumber);
            int status = productDeviationService.SaveProductDeviationData(productDeviationList,EcolabAccountNumber);

            ProductDeviationContainer productDeviationContainer = new ProductDeviationContainer();
            productDeviationContainer.EcolabAccountNumber = EcolabAccountNumber;
            productDeviationContainer.LstProductDeviation = productDeviationList.ToList();
			productDeviationContainer.LstProductDeviation.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            Push.PushToQueue(productDeviationContainer, userId, productDeviationContainer.LstProductDeviation[0].Id, (int)TcdAdminMessageTypes.TcdAddProductDeviation, EcolabAccountNumber);

            IPlcService plcService = new PlcService();
                        
            //Sending to PLC
            try
            {
                if (washerProductDeviationModel.ControllerModelId == 11 && washerProductDeviationModel.WasherGroupTypeId == 1)
                {
                    WriteConventionalProductDeviationDataToPlc(washerProductDeviationModel, TunnelNumber, washerProductDeviationModel.WasherGroupTypeId);
                }
                else if(washerProductDeviationModel.ControllerModelId == 8 && washerProductDeviationModel.WasherGroupTypeId == 1)
                {
                    WriteToPlc(productDeviationContainer.LstProductDeviation, washerProductDeviationModel.ControllerId, previousProductDeviationList);
                }
                else
                {
                var plc = new PlcTagController(plcService, UserService, PlantService);
                    List<Tag>  tags = GenerateConventionalProductDeviationTags(productDeviationContainer.LstProductDeviation, TunnelNumber);
                    plc.WriteTunnelTags(new TagCollection { Tags = tags }, washerProductDeviationModel.ControllerId, 7);
                }
            }
            catch (Exception ex)
            {
                String msg = string.Empty;
                if (ex.Message.Contains("Timeout has elapsed") ||
                    ex.Message.Contains("Port is disabled") ||
                    ex.Message.Contains("Target machine could not be found") ||
                    ex.Message.Contains("ADS could not be initialized") ||
                    ex.Message.Contains("Open Failed") ||
                    ex.Message.Contains("Retrieving the COM class factory"))
                {
                    msg = "901@" + status;
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, msg);
                }
            }            
            if (status == 0)
            {
                return this.Request.CreateResponse(HttpStatusCode.OK, 0);
            }
            return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, -1);
        }

        private void WriteConventionalProductDeviationDataToPlc(WasherProductDeviationModel washerProductDeviationModel, int lfsWasherNumber, int washerGroupTypeId)
        {
            IPlcService plcService = new PlcService();
            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            List<Tag> tagsList = new List<Tag>();
            int conventionalWasherNumber = lfsWasherNumber > 0 ? lfsWasherNumber : washerProductDeviationModel.MachineNumber;
            var offset = (conventionalWasherNumber - 1) * 30;

            if (washerProductDeviationModel != null)
            {
                if (washerProductDeviationModel.ControllerTypeId == 12 && washerProductDeviationModel.WasherDosingNumber == 2)
                {
                    tagsList = GenerateWasherProductDeviationDosingNumber2Tags(washerProductDeviationModel, lfsWasherNumber);
                }
                else
                {
                    tagsList = GenerateConventionalWasherProductDeviationTags(washerProductDeviationModel, lfsWasherNumber);
                }

                MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                plc.WriteTags(mitsubishiTag, washerProductDeviationModel.ControllerId, washerGroupTypeId, SourcePage.WasherPageProductDeviation);
            }
        }

        private List<Tag> GenerateConventionalWasherProductDeviationTags(WasherProductDeviationModel washerProductDeviationModel, int lfsWasherNumber)
        {
            List<Tag> tagsList = new List<Tag>();
            int conventionalWasherNumber = lfsWasherNumber > 0 ? lfsWasherNumber : washerProductDeviationModel.MachineNumber;
            var offset = (conventionalWasherNumber - 1) * 30;

            if (washerProductDeviationModel.ProductDeviationdata != null && washerProductDeviationModel.ProductDeviationdata.Count > 0)
            {
                foreach (ProductDeviationModel productDeviationModel in washerProductDeviationModel.ProductDeviationdata)
                {
                    switch (productDeviationModel.ControllerEquipmentID)
                    {
                        case 1:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (303 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 2:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (304 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 3:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (305 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 4:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (306 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 5:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (307 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 6:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (308 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 7:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (309 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 8:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (310 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 9:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (311 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 10:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (325 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 11:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (326 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 12:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (327 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 13:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (302 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 14:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (328 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;
                    }
                }
            }

            return tagsList;
        }

        private List<Tag> GenerateWasherProductDeviationDosingNumber2Tags(WasherProductDeviationModel washerProductDeviationModel, int lfsWasherNumber)
        {
            List<Tag> tagsList = new List<Tag>();
            int conventionalWasherNumber = lfsWasherNumber > 0 ? lfsWasherNumber : washerProductDeviationModel.MachineNumber;
            var offset = (conventionalWasherNumber - 1) * 30;

            if (washerProductDeviationModel.ProductDeviationdata != null && washerProductDeviationModel.ProductDeviationdata.Count > 0)
            {
                foreach (ProductDeviationModel productDeviationModel in washerProductDeviationModel.ProductDeviationdata)
                {
                    switch (productDeviationModel.ControllerEquipmentID)
                    {
                        case 15:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (303 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 16:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (304 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 17:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (305 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 18:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (306 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 19:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (307 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 20:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (308 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 21:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (309 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 22:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (310 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 23:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (311 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 24:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (325 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 25:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (326 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 26:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (327 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 27:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (302 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;

                        case 28:
                            tagsList.Add(new MitsubishiTag { Address = "R" + (328 + offset), Value = Convert.ToString(productDeviationModel.ProductDeviationValue), TagType = productDeviationModel.ControllerEquipmentID.ToString() });
                            break;
                    }
                }
            }

            return tagsList;
        }

        private static List<Tag> GenerateConventionalProductDeviationTags(List<ProductDeviation> listProductDeviation, int tunnelNumber)
        {
            List<Tag> tag = new List<Tag>();            
            const int conventionalPLCIndex = 72;
            int startIndex = ((tunnelNumber - 1) * conventionalPLCIndex);
            int initialIndex = 2;
            if (listProductDeviation != null)
            {
                //For Type ProductDeviation 3…28
                foreach (var item in listProductDeviation)
                {
                    tag.Add(new OpcTag { Address = "ProductDeviation", Value = Convert.ToString(item.ProductDeviationValue), TagId = initialIndex + startIndex,TagType=item.ControllerEquipmentID.ToString() });
                    initialIndex++;
                }
            }            
            return tag;
        }

        private List<OpcTag> ValidateConventionalProductDeviationPLC(ConventionalGeneralModel conventionalData, PlcTagController plc, List<ProductDeviation> listProductDeviation, int tunnelNumber)
        {
            var tg = GenerateConventionalProductDeviationTags(listProductDeviation, TunnelNumber);
            var generatedTags = GenerateConventionalProductDeviationTags(listProductDeviation, TunnelNumber);
            TagCollection tagStatusTunnel = plc.ValidateConventionalTags(new TagCollection { Tags = generatedTags }, conventionalData.ControllerId, 3, conventionalData.LfsWasher);
            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tg.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address && tag.TagId == plcTag.TagId && tag.Value!=plcTag.Value)
                    {
                        if (tag.Address.ToUpper() == "PRODUCTDEVIATION")
                        {
                            message.Append(string.Format(
                            "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                            tag.Value,
                            plcTag.Value));
                            ambiguousTags.Add(tag);
                        }
                    }
                }
            }
            return ambiguousTags;
        }

        private void WriteToPlc(List<ProductDeviation> listProductDeviation, int ControllerId, List<ProductDeviation> prevProductDeviationList)
        {
            //If Controller is of type EcontrolPlus
            if (ControllerModelId == 8 && washerGroupTypeId == 1)
            {
                //Get Address offset based on LFS washer number or MachineNumber
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);

                List<Tag> tagsList = GetEcontolPlusConventionalProductDeviationTags(listProductDeviation, prevProductDeviationList);
                if (listProductDeviation != null)
                {
                    if (tagsList != null && tagsList.Count > 0)
                    {
                        MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                        plc.WriteTags(mitsubishiTag, ControllerId, washerGroupTypeId, SourcePage.WasherPageProductDeviation);
                    }
                }
            }
        }

        private List<Tag> GetEcontolPlusConventionalProductDeviationTags(List<ProductDeviation> listProductDeviation, List<ProductDeviation> prevProductDeviationList)
        {
            int offset = (TunnelNumber - 1) * 30;
            List<Tag> tagsList = new List<Tag>();
            if (listProductDeviation != null && prevProductDeviationList != null)
            {
                int incrementAddress = 0;
                foreach (var ProductDeviation in listProductDeviation)
                {
                    if (incrementAddress == 8)
                    {
                        //Tag for ME1
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", (518 + offset)),
                            Value = Convert.ToString(ProductDeviation.ProductDeviationValue == 0 ? 100 : ProductDeviation.ProductDeviationValue),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    else if (incrementAddress == 9)
                    {
                        //Tag for ME2
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", (527 + offset)),
                            Value = Convert.ToString(ProductDeviation.ProductDeviationValue == 0 ? 100 : ProductDeviation.ProductDeviationValue),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    else
                    {
                        //Tags for pumps
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", (519 + incrementAddress + offset)),
                            Value = Convert.ToString(ProductDeviation.ProductDeviationValue == 0 ? 100 : ProductDeviation.ProductDeviationValue),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    incrementAddress++;
                }
            }
            return tagsList;
        }
    }
}