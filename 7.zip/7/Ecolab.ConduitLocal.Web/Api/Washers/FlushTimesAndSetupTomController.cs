﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTomController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The FlushTimesAndSetupTom Controller </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Http;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.PushHandler;
using Ecolab.ConduitLocal.Web.Models.Washers;
using Ecolab.ConduitLocal.Web.Models.Washers.Tunnel;
using Ecolab.Models.WasherGroup;
using Ecolab.Models.Washers;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services;
using Ecolab.Services.Interfaces;
using Ecolab.Services.Interfaces.WasherGroup;
using Ecolab.Services.Interfaces.Washers;
using Ecolab.Services.Interfaces.Washers.Tunnel;

namespace Ecolab.ConduitLocal.Web.Api.Washers
{
    using AutoMapper;
    using Dcs.Entities;
    using Ecolab.Models.Enum;
    using Elmah;
    using Services.Interfaces.Plc;
    using Services.Plc;
    using WasherFlushType = Models.Washers.WasherFlushType;

    /// <summary>
    ///     Class FlushTimesAndSetupTomController.
    /// </summary>
    [Authorize]
    public class FlushTimesAndSetupTomController : BaseApiController
    {
        /// <summary>
        ///     The Flush Times And Setup Tom Services service
        /// </summary>
        private readonly IFlushTimesAndSetupTomServices flushTimesAndSetupTomServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        /// Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="flushTimesAndSetupTomServices">The flushTimesAndSetupTom services.</param>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        public FlushTimesAndSetupTomController(IUserService userService, IPlantService plantService, IFlushTimesAndSetupTomServices flushTimesAndSetupTomServices, ITunnelGeneralServices tunnelGeneralServices, IWasherGroupService washerGroupService)
            : base(userService, plantService)
        {
            this.flushTimesAndSetupTomServices = flushTimesAndSetupTomServices;
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.washerGroupService = washerGroupService;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="flushTimesAndSetupTomServices">The flushTimesAndSetupTom services.</param>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="washerGroupService">The washer group services.</param>
        /// <param name="plcService">The plc service.</param>
        public FlushTimesAndSetupTomController(IUserService userService, IPlantService plantService, IFlushTimesAndSetupTomServices flushTimesAndSetupTomServices, ITunnelGeneralServices tunnelGeneralServices, IWasherGroupService washerGroupService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.flushTimesAndSetupTomServices = flushTimesAndSetupTomServices;
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
        }
        /// <summary>
        /// Get all the values related to FlushTimes And Setup TOM
        /// </summary>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="groupTypeId">The group type Id</param>
        /// <returns>
        /// Returns the washers model
        /// </returns>
        [HttpGet]
        public Web.Models.Washers.FlushTimesAndSetupTom GetData(int machineId, int groupId, int groupTypeId)
        {
            Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom = new Web.Models.Washers.FlushTimesAndSetupTom();

            try
            {
                TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(machineId, groupId, EcolabAccountNumber));
                Models.WasherGroup.WasherGroup washerGroup = AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(groupId, EcolabAccountNumber, 0, 12, string.Empty).FirstOrDefault());

                GetWasherFlushTimesList(machineId, EcolabAccountNumber, tunneldata.ControllerModelId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);

                flushTimesAndSetupTom.MachineId = tunneldata.Id;
                flushTimesAndSetupTom.WasherGroupId = tunneldata.WasherGroupId;
                flushTimesAndSetupTom.WasherGroupNumber = washerGroup.WasherGroupNumber;
                flushTimesAndSetupTom.WasherGroupName = washerGroup.WasherGroupName;
                flushTimesAndSetupTom.WasherGroupTypeId = washerGroup.WasherGroupTypeId;
                flushTimesAndSetupTom.WasherGroupType = washerGroup.WasherGroupTypeName;
                flushTimesAndSetupTom.ControllerId = tunneldata.ControllerId;
                flushTimesAndSetupTom.ControllerTypeId = tunneldata.ControllerTypeId;
                flushTimesAndSetupTom.ControllerModelId = tunneldata.ControllerModelId;
                flushTimesAndSetupTom.MachineNumber = tunneldata.LfsWasher;
                flushTimesAndSetupTom.NoOfCompartments = tunneldata.NoofCompartments;
                flushTimesAndSetupTom.MachineName = tunneldata.Name;

                if (tunneldata.ControllerModelId == 14 && tunneldata.WasherTypeName == "Tunnel")
                {
                    if (tunneldata.TunInTomMode)
                    {
                        GetWasherTimeOutMachinesList(machineId, EcolabAccountNumber, tunneldata.ControllerModelId, washerGroup.WasherGroupTypeId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);
                    }
                }
                else
                {
                    GetWasherTimeOutMachinesList(machineId, EcolabAccountNumber, tunneldata.ControllerModelId, washerGroup.WasherGroupTypeId, tunneldata.ControllerTypeId, flushTimesAndSetupTom);
                }

                //Validating data from UI with respect to data from PLC
                IPlcService plcService = new PlcService();
                var plc = new PlcTagController(plcService, UserService, PlantService);
                List<OpcTag> flushTimeTOMPLC;
                if (flushTimesAndSetupTom.ControllerModelId == 7)
                {
                    if (flushTimesAndSetupTom.WasherGroupTypeId == 1)
                    {
                        var conventionalTagData = GenerateConventionalFlushTOMTags(flushTimesAndSetupTom, tunneldata.LfsWasher);
                        flushTimeTOMPLC = ValidateConventionalFlushTOMTPLC(flushTimesAndSetupTom, tunneldata, plc, conventionalTagData);
                        int actualTagIndexinPLC = 0;
                        for (int index = 0; index < flushTimesAndSetupTom.Air.Count(); index++)
                        {
                            actualTagIndexinPLC++;
                            flushTimesAndSetupTom.Air[actualTagIndexinPLC - 1].IsValueDiffForFlushTime = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "air" && x.TagType == actualTagIndexinPLC.ToString()).ToList().Count > 0) ? true : false;

                        }
                        actualTagIndexinPLC = 0;
                        for (int index = 0; index < flushTimesAndSetupTom.Water.Count(); index++)
                        {
                            actualTagIndexinPLC++;
                            flushTimesAndSetupTom.Water[actualTagIndexinPLC - 1].IsValueDiffForFlushTime = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "water" && x.TagType == actualTagIndexinPLC.ToString()).ToList().Count > 0) ? true : false;
                        }
                        actualTagIndexinPLC = 0;
                        for (int index = 0; index < flushTimesAndSetupTom.WasherTimeOutMachine.Count(); index++)
                        {
                            actualTagIndexinPLC++;
                            flushTimesAndSetupTom.EquipmentTom[actualTagIndexinPLC - 1].IsValueDiffForEquipmentNumber = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "equipment" && x.TagType == actualTagIndexinPLC.ToString()).ToList().Count > 0) ? true : false;
                        }
                    }
                    else
                    {
                        var tagData = GenerateTunnelTags(flushTimesAndSetupTom, tunneldata.LfsWasher);
                        flushTimeTOMPLC = ValidateFlushTimePLC(flushTimesAndSetupTom, tunneldata, plc, tagData);
                        int j = 0;
                        for (int i = 0; i < flushTimesAndSetupTom.Air.Count(); i++)
                        {
                            j++;
                            flushTimesAndSetupTom.Air[j - 1].IsValueDiffForFlushTime = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "air" && x.TagType == j.ToString()).ToList().Count > 0) ? true : false;

                        }
                        j = 0;
                        for (int i = 0; i < flushTimesAndSetupTom.Water.Count(); i++)
                        {
                            j++;
                            flushTimesAndSetupTom.Water[j - 1].IsValueDiffForFlushTime = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "water" && x.TagType == j.ToString()).ToList().Count > 0) ? true : false;

                        }
                        j = 0;
                        for (int i = 0; i < flushTimesAndSetupTom.DosingPointTom.Count(); i++)
                        {
                            j++;
                            flushTimesAndSetupTom.DosingPointTom[j - 1].IsValueDiffForEquipmentNumber = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "equipment" && x.TagType == j.ToString()).ToList().Count > 0) ? true : false;
                            flushTimesAndSetupTom.DosingPointTom[j - 1].IsValueDiffForDosingPointNumber = (flushTimeTOMPLC.Where(x => x.Address.ToLower() == "dosing" && x.TagType == j.ToString()).ToList().Count > 0) ? true : false;
                        }
                    }
                }
                else if (flushTimesAndSetupTom.ControllerModelId == 11)
                {
                    if (flushTimesAndSetupTom.WasherGroupTypeId == 1)
                    {
                        List<Tag> plcTagsList = new List<Tag>();
                        TagCollection plctagStatus = new TagCollection();
                        var offset = (flushTimesAndSetupTom.MachineNumber - 1) * 30;
                        plcTagsList = GenerateWasherGroupFlushTimeTags(flushTimesAndSetupTom);

                        if (plcTagsList.Count > 0 && flushTimesAndSetupTom.ControllerId > 0)
                        {
                            plctagStatus = plc.ValidateWasherConventionalPLCXLTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, flushTimesAndSetupTom.ControllerId, SourcePage.WasherPage);
                            List<string> flushTimeTagCollections = new List<string>();

                            plcTagsList = GenerateWasherGroupFlushTimeTags(flushTimesAndSetupTom);

                            foreach (MitsubishiTag tag in plcTagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plctagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                    {
                                        flushTimeTagCollections.Add(tag.Address);
                                    }
                                }
                            }

                            if (flushTimeTagCollections.Count > 0)
                            {
                                if (flushTimeTagCollections.Contains("R" + (315 + offset)))
                                {
                                    flushTimesAndSetupTom.Pumps[0].IsValueDiffForPumpsFlushTime = true;
                                }

                                if (flushTimeTagCollections.Contains("R" + (316 + offset)))
                                {
                                    flushTimesAndSetupTom.MainEquipment[0].IsValueDiffForFlushTimeME1 = true;
                                }

                                if (flushTimeTagCollections.Contains("R" + (319 + offset)))
                                {
                                    flushTimesAndSetupTom.MainEquipment[1].IsValueDiffForFlushTimeME2 = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        return BuildPLCXLTunnelFlushTimeOverrides(flushTimesAndSetupTom);
                    }
                }
                else if (flushTimesAndSetupTom.ControllerModelId == 8)
                {
                    //Read EcontrolPlus PLC data and copare with DB data for conventional
                    if (flushTimesAndSetupTom.WasherGroupTypeId == 1)
                    {
                        List<Tag> uiTags = GetEcontolPlusConventionalFlushTimeTags(flushTimesAndSetupTom);
                        List<Tag> uiTagsClone = GetEcontolPlusConventionalFlushTimeTags(flushTimesAndSetupTom);
                        List<string> tagCollectionList = new List<string>();
                        TagCollection plcTags = new TagCollection { Tags = new List<Tag>() };
                        try
                        {
                            plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(uiTagsClone) }, flushTimesAndSetupTom.ControllerId);
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        }

                        if (plcTags != null)
                        {
                            foreach (Tag uiTag in uiTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plcTags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (uiTag.Address == plcTag.Address && uiTag.Value.ToUpper() != plcTag.Value.ToUpper())
                                    {
                                        tagCollectionList.Add(uiTag.Address);
                                        break;
                                    }
                                }
                            }
                            var offset = (flushTimesAndSetupTom.MachineNumber - 1) * 30;
                            if (tagCollectionList.Count > 0)
                            {
                                int i = 0;
                                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.Pumps)
                                {
                                    if (tagCollectionList.Contains(string.Format("D{0}", 534 + (i) + offset)))
                                    {
                                        flushTimesAndSetupTom.Pumps[i].IsValueDiffForPumpsFlushTime = true;
                                    }

                                    i++;
                                }

                                if (tagCollectionList.Contains(string.Format("D{0}", 529 + offset)))
                                {
                                    flushTimesAndSetupTom.MainEquipment[0].IsValueDiffForFlushTimeME1 = true;
                                }

                                if (tagCollectionList.Contains(string.Format("D{0}", 542 + offset)))
                                {
                                    flushTimesAndSetupTom.MainEquipment[1].IsValueDiffForFlushTimeME2 = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        //Read EcontrolPlus PLC data and copare with DB data for tunnel
                        List<Tag> uiTags = GetEcontolPlusTunnelFlushTimeTags(flushTimesAndSetupTom);
                        List<Tag> uiTagsClone = GetEcontolPlusTunnelFlushTimeTags(flushTimesAndSetupTom);
                        List<string> tagCollectionList = new List<string>();
                        TagCollection plcTags = new TagCollection { Tags = new List<Tag>() };
                        try
                        {
                            plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(uiTagsClone) }, flushTimesAndSetupTom.ControllerId);
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        }

                        if (plcTags != null)
                        {
                            foreach (Tag uiTag in uiTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plcTags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (uiTag.Address == plcTag.Address && uiTag.Value.ToUpper() != plcTag.Value.ToUpper())
                                    {
                                        tagCollectionList.Add(uiTag.Address);
                                        break;
                                    }
                                }
                            }
                            if (tagCollectionList.Count > 0)
                            {
                                int i = 0;
                                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.Pumps)
                                {
                                    if (tagCollectionList.Contains(string.Format("D{0}", 323 + i)))
                                    {
                                        flushTimesAndSetupTom.Pumps[i].IsValueDiffForPumpsFlushTime = true;
                                    }
                                    i++;
                                }

                                if (tagCollectionList.Contains("D321"))
                                {
                                    flushTimesAndSetupTom.MainEquipment[0].IsValueDiffForFlushTimeME1 = true;
                                }

                                if (tagCollectionList.Contains("D322"))
                                {
                                    flushTimesAndSetupTom.MainEquipment[1].IsValueDiffForFlushTimeME2 = true;
                                }

                                int j = 0, k = 0;
                                //For Type Equipment & Dosing Point
                                foreach (var item in flushTimesAndSetupTom.WasherTimeOutMachine)
                                {
                                    //Equipment
                                    if (tagCollectionList.Contains(string.Format("D{0}", 6051 + j)))
                                    {
                                        flushTimesAndSetupTom.DosingPointTom[k].IsValueDiffForEquipmentNumber = true;
                                    }

                                    //Dosing Point
                                    if (tagCollectionList.Contains(string.Format("D{0}", 6052 + j)))
                                    {
                                        flushTimesAndSetupTom.DosingPointTom[k].IsValueDiffForDosingPointNumber = true;
                                    }
                                    j += 2;
                                    k++;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Exception need to handle.
            }

            return flushTimesAndSetupTom;
        }

        /// <summary>
        /// Get Washer Time Out Machines List
        /// </summary>
        /// <param name="machineId">the washer id</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <param name="controllerModelId">controller Model Id</param>
        /// <param name="washerGroupTypeId">washer Group Type Id</param>
        /// <param name="controllerTypeId">controller Type Id</param>
        /// <param name="flushTimesAndSetupTom">flush Times And Setup Tom</param>
        private void GetWasherTimeOutMachinesList(int machineId, string ecolabAccountNumber, int controllerModelId, int washerGroupTypeId, int controllerTypeId, Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            flushTimesAndSetupTom.WasherTimeOutMachine =
                AutoMapper.Mapper.Map<IEnumerable<WasherTimeOutMachine>, IEnumerable<WasherTimeOutMachineModel>>(this.flushTimesAndSetupTomServices.GetWasherTimeOutMachine(machineId, ecolabAccountNumber, controllerModelId, controllerTypeId)).ToList();
            if ((flushTimesAndSetupTom.WasherTimeOutMachine.Count == 1 && (
                flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount != 0 ||
                flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount != 0)) ||
                (flushTimesAndSetupTom.WasherTimeOutMachine.Count == 1 &&
                 (flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount == 0 ||
                  flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount == 0)))
            {
                if (flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount > 0)
                {
                    flushTimesAndSetupTom.DosingPointTom = new List<WasherTimeOutMachineModel>();
                    for (int i = 0; i < flushTimesAndSetupTom.WasherTimeOutMachine[0].DosingPointCount; i++)
                    {
                        flushTimesAndSetupTom.DosingPointTom.Add(new WasherTimeOutMachineModel() { });
                    }
                }
                if (flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount > 0)
                {
                    flushTimesAndSetupTom.EquipmentTom = new List<WasherTimeOutMachineModel>();
                    for (int i = 0; i < flushTimesAndSetupTom.WasherTimeOutMachine[0].EquipmentCount; i++)
                    {
                        flushTimesAndSetupTom.EquipmentTom.Add(new WasherTimeOutMachineModel() { });
                    }
                }
            }
            else
            {
                flushTimesAndSetupTom.DosingPointTom = new List<WasherTimeOutMachineModel>();
                flushTimesAndSetupTom.EquipmentTom = new List<WasherTimeOutMachineModel>();
                if ((controllerModelId == 7 && washerGroupTypeId == 1) || (controllerModelId == 14 && washerGroupTypeId == 2))
                {
                    foreach (var washerTimeOutMachineModel in flushTimesAndSetupTom.WasherTimeOutMachine)
                    {
                        flushTimesAndSetupTom.EquipmentTom.Add(new WasherTimeOutMachineModel()
                        {
                            EquipmentNumber = washerTimeOutMachineModel.EquipmentNumber,
                            WasherId = washerTimeOutMachineModel.WasherId,
                            SignalNumber = washerTimeOutMachineModel.SignalNumber,
                            LastModifiedTime = washerTimeOutMachineModel.LastModifiedTime,
                            ControllerTypelId = washerTimeOutMachineModel.ControllerTypelId
                        });
                    }
                }
                else
                {
                    foreach (var washerTimeOutMachineModel in flushTimesAndSetupTom.WasherTimeOutMachine)
                    {
                        flushTimesAndSetupTom.DosingPointTom.Add(new WasherTimeOutMachineModel()
                        {
                            EquipmentNumber = washerTimeOutMachineModel.EquipmentNumber,
                            DosingPointNumber = washerTimeOutMachineModel.DosingPointNumber,
                            WasherId = washerTimeOutMachineModel.WasherId,
                            SignalNumber = washerTimeOutMachineModel.SignalNumber,
                            LastModifiedTime = washerTimeOutMachineModel.LastModifiedTime,
                            ControllerTypelId = washerTimeOutMachineModel.ControllerTypelId
                        });
                    }
                }
            }
        }

        /// <summary>
        /// GetWasherFlushTimesList
        /// </summary>
        /// <param name="machineId">the washer id</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <param name="controllerModelId">controller Model Id</param>
        /// <param name="controllerTypeId">controller Type Id</param>
        /// <param name="flushTimesAndSetupTom">flushTimes And Setup Tom</param>
        private void GetWasherFlushTimesList(int machineId, string ecolabAccountNumber, int controllerModelId, int controllerTypeId, Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<WasherFlushTimeModel> flushTimes = AutoMapper.Mapper.Map<IEnumerable<WasherFlushTime>, IEnumerable<WasherFlushTimeModel>>(
                    this.flushTimesAndSetupTomServices.GetWasherFlushTime(machineId, ecolabAccountNumber, controllerModelId, controllerTypeId)).ToList();
            if (flushTimes.Count() == 1 && (flushTimes[0].AirCount != 0 || flushTimes[0].MeCount != 0 ||
                flushTimes[0].PumpCount != 0 || flushTimes[0].WaterCount != 0))
            {
                flushTimesAndSetupTom.WasherFlushTime = new List<WasherFlushTimeModel>();
                if (flushTimes[0].PumpCount > 0)
                {
                    flushTimesAndSetupTom.Pumps = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].PumpCount; i++)
                    {
                        flushTimesAndSetupTom.Pumps.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = WasherFlushType.Pump
                        });
                    }
                }
                if (flushTimes[0].MeCount > 0)
                {
                    flushTimesAndSetupTom.MainEquipment = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].MeCount; i++)
                    {
                        flushTimesAndSetupTom.MainEquipment.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = WasherFlushType.MainEquipment
                        });
                    }
                }
                if (flushTimes[0].WaterCount > 0)
                {
                    flushTimesAndSetupTom.Water = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].WaterCount; i++)
                    {
                        flushTimesAndSetupTom.Water.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = WasherFlushType.Water
                        });
                    }
                }
                if (flushTimes[0].AirCount > 0)
                {
                    flushTimesAndSetupTom.Air = new List<WasherFlushTimeModel>();
                    for (int i = 0; i < flushTimes[0].AirCount; i++)
                    {
                        flushTimesAndSetupTom.Air.Add(new WasherFlushTimeModel()
                        {
                            WasherFlushTypeId = WasherFlushType.Air
                        });
                    }
                }
            }
            else
            {
                foreach (var washerFlushTimeModel in flushTimes)
                {
                    switch (washerFlushTimeModel.WasherFlushTypeId)
                    {
                        case WasherFlushType.Air:
                            {
                                if (flushTimesAndSetupTom.Air == null)
                                {
                                    flushTimesAndSetupTom.Air = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Air.Add(washerFlushTimeModel);
                                break;
                            }
                        case WasherFlushType.Water:
                            {
                                if (flushTimesAndSetupTom.Water == null)
                                {
                                    flushTimesAndSetupTom.Water = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Water.Add(washerFlushTimeModel);
                                break;
                            }
                        case WasherFlushType.Pump:
                            {
                                if (flushTimesAndSetupTom.Pumps == null)
                                {
                                    flushTimesAndSetupTom.Pumps = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.Pumps.Add(washerFlushTimeModel);
                                break;
                            }
                        case WasherFlushType.MainEquipment:
                            {
                                if (flushTimesAndSetupTom.MainEquipment == null)
                                {
                                    flushTimesAndSetupTom.MainEquipment = new List<WasherFlushTimeModel>();
                                }
                                flushTimesAndSetupTom.MainEquipment.Add(washerFlushTimeModel);
                                break;
                            }
                    }
                }
            }
        }

        /// <summary>
        /// Save the Alarm Data
        /// </summary>
        /// <param name="flushTimesAndSetupTom">Object of FlushTimesAndSetupTom.</param>
        /// <returns>
        /// The result of the save operation in string format.
        /// </returns>
        [HttpPost]
        public HttpResponseMessage SaveFlushTimesAndSetupTom(Web.Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;
            int flushTimeStatus = 0, washerTomStatus = 0;
            List<WasherFlushTimeModel> flushTimes = new List<WasherFlushTimeModel>();
            if (flushTimesAndSetupTom.Pumps != null && flushTimesAndSetupTom.Pumps.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Pumps);
            }
            if (flushTimesAndSetupTom.MainEquipment != null && flushTimesAndSetupTom.MainEquipment.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.MainEquipment);
            }
            if (flushTimesAndSetupTom.Air != null && flushTimesAndSetupTom.Air.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Air);
            }
            if (flushTimesAndSetupTom.Water != null && flushTimesAndSetupTom.Water.Count > 0)
            {
                flushTimes.AddRange(flushTimesAndSetupTom.Water);
            }
            List<WasherFlushTime> washerFlushTime = AutoMapper.Mapper.Map<List<WasherFlushTimeModel>, List<WasherFlushTime>>(flushTimes);
            List<WasherTimeOutMachine> washerTimeOutMachine = AutoMapper.Mapper.Map<List<WasherTimeOutMachineModel>, List<WasherTimeOutMachine>>(flushTimesAndSetupTom.WasherTimeOutMachine);
            if (washerFlushTime != null && washerFlushTime.Count > 0)
            {
                flushTimeStatus = this.flushTimesAndSetupTomServices.SaveWasherFlushTime(washerFlushTime, UserId, EcolabAccountNumber, flushTimesAndSetupTom.ControllerModelId);
            }
            if (washerTimeOutMachine != null && washerTimeOutMachine.Count > 0)
            {
                washerTomStatus = this.flushTimesAndSetupTomServices.SaveWasherTimeOutMachine(washerTimeOutMachine, UserId, EcolabAccountNumber, flushTimesAndSetupTom.WasherGroupTypeId);
            }

            if (flushTimeStatus == 0 && washerTomStatus == 0)
            {
                Ecolab.Models.Washers.FlushTimesAndSetupTom flushTimeAndSetup = this.flushTimesAndSetupTomServices.GetWasherFlushTimeAndSetupForResynch(flushTimesAndSetupTom.MachineId, EcolabAccountNumber, flushTimesAndSetupTom.ControllerModelId);
                flushTimeAndSetup.WasherFlushTime.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
                flushTimeAndSetup.WasherTimeOutMachine.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));

                flushTimeAndSetup.EcolabAccountNumber = EcolabAccountNumber;
                Push.PushToQueue(flushTimeAndSetup, userId, flushTimeAndSetup.WasherFlushTime.FirstOrDefault().WasherId, (int)TcdAdminMessageTypes.TcdAddFlushTimesAndSetupTom, EcolabAccountNumber);

                byte washergrouptype = flushTimesAndSetupTom.WasherGroupTypeId;
                IPlcService plcService = new PlcService();
                //Sending to PLC
                var plc = new PlcTagController(plcService, UserService, PlantService);
                try
                {
                    if (flushTimesAndSetupTom.ControllerModelId == 7)
                    {
                        if (flushTimesAndSetupTom.WasherGroupTypeId == 1)
                        {
                            List<Tag> tag = GenerateConventionalFlushTOMTags(flushTimesAndSetupTom, flushTimesAndSetupTom.MachineNumber);
                            plc.WriteTunnelTags(new TagCollection { Tags = tag }, flushTimesAndSetupTom.ControllerId, 7);
                        }
                        else
                        {
                            List<Tag> tag = GenerateTunnelTags(flushTimesAndSetupTom, flushTimesAndSetupTom.MachineNumber);
                            plc.WriteTunnelTags(new TagCollection { Tags = tag }, flushTimesAndSetupTom.ControllerId, 3);
                        }
                    }
                    else if (flushTimesAndSetupTom.ControllerModelId == 11)
                    {
                        //PLC write for PLCXL Conventional and Tunnel Flush time tags
                        WriteFlushTimeDataToPlc(flushTimesAndSetupTom, flushTimesAndSetupTom.WasherGroupTypeId);
                    }
                    else if (flushTimesAndSetupTom.ControllerModelId == 8)
                    {
                        //PLC write for Econtrol Plus
                        //PLC write for both tunnel and conventional washer
                        WriteToPlc(flushTimesAndSetupTom);
                    }
                }
                catch (Exception ex)
                {
                    string msg = string.Empty;
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        msg = "901@" + 0;
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, msg);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, 0);
            }
            return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, -1);
        }

        /// <summary>
        /// Writes the conventional flush time data to PLC.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        private void WriteFlushTimeDataToPlc(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom, int washerGroupTypeId)
        {
            IPlcService plcService = new PlcService();
            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            List<Tag> tagsList = new List<Tag>();

            if (flushTimesAndSetupTom != null)
            {
                if (flushTimesAndSetupTom.ControllerModelId == 11)
                {
                    if(washerGroupTypeId == 1)
                    {
                        tagsList = GenerateWasherGroupFlushTimeTags(flushTimesAndSetupTom);
                    }
                    else if(washerGroupTypeId == 2)
                    {
                        tagsList = BuildPLCXLTunnelFlushTimeTags(flushTimesAndSetupTom);
                    }

                    if (tagsList != null && tagsList.Count > 0)
                    {
                        MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                        plc.WriteTags(mitsubishiTag, flushTimesAndSetupTom.ControllerId, washerGroupTypeId, SourcePage.WasherPageFlushTime);
                    }
                }
            }
        }

        /// <summary>
        /// Generates the washer group flush time tags.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <returns>List of FlushTime Tags</returns>
        private List<Tag> GenerateWasherGroupFlushTimeTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<Tag> tags = new List<Tag>();
            var offset = (flushTimesAndSetupTom.MachineNumber - 1) * 30;

            if (flushTimesAndSetupTom.Pumps != null && flushTimesAndSetupTom.Pumps.Count > 0)
            {
                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.Pumps)
                {
                    if (washerFlushTimeModel.LineNumber == 1)
                    {
                        tags.Add(new MitsubishiTag { Address = "R" + (315 + offset), Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10) });
                    }
                }
            }

            if (flushTimesAndSetupTom.MainEquipment != null && flushTimesAndSetupTom.MainEquipment.Count > 0)
            {
                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.MainEquipment)
                {
                    if (washerFlushTimeModel.LineNumber == 2)
                    {
                        tags.Add(new MitsubishiTag { Address = "R" + (316 + offset), Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10) });
                    }
                    else if (washerFlushTimeModel.LineNumber == 3)
                    {
                        tags.Add(new MitsubishiTag { Address = "R" + (319 + offset), Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10) });
                    }
                }
            }

            return tags;
        }

        /// <summary>
        /// Validates the flush time PLC.
        /// </summary>
        /// <param name="flushTimeTom">The flush time tom.</param>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <param name="plc">The FlushTime PLC tags.</param>
        /// <param name="tg">The FlushTime tags.</param>
        /// <returns>List of FlushTime Tags</returns>
        private List<OpcTag> ValidateFlushTimePLC(Models.Washers.FlushTimesAndSetupTom flushTimeTom, TunnelGeneralModel tunnelData, PlcTagController plc, List<Tag> tg)
        {
            var generatedTags = GenerateTunnelTags(flushTimeTom, tunnelData.LfsWasher);
            TagCollection tagStatusTunnel = plc.ValidateTags(new TagCollection { Tags = generatedTags }, flushTimeTom.ControllerId, SourcePage.TunnelFlushTimesTomPage);
            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tg.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address)
                    {
                        GetFlushTimePLCAmbiguousTags(message, ambiguousTags, tag, plcTag);
                    }
                }
            }
            return ambiguousTags;
        }

        /// <summary>
        /// Gets the flush time PLC ambiguous tags.
        /// </summary>
        /// <param name="message">The message from PLC.</param>
        /// <param name="ambiguousTags">The ambiguous tags.</param>
        /// <param name="tag">The opc tag details.</param>
        /// <param name="plcTag">The PLC tags details .</param>
        private static void GetFlushTimePLCAmbiguousTags(StringBuilder message, List<OpcTag> ambiguousTags, OpcTag tag, Tag plcTag)
        {
            switch (tag.Address.ToUpper())
            {
                case "WATER":
                    if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()) && (tag.TagType == plcTag.TagType))
                    {
                        message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                        ambiguousTags.Add(tag);
                    }
                    break;
                case "AIR":
                    if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()) && (tag.TagType == plcTag.TagType))
                    {
                        message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                        ambiguousTags.Add(tag);
                    }
                    break;
                case "EQUIPMENT":
                    if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()) && (tag.TagType == plcTag.TagType))
                    {
                        message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                        ambiguousTags.Add(tag);
                    }
                    break;
                case "DOSING":
                    if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()) && (tag.TagType == plcTag.TagType))
                    {
                        message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                        ambiguousTags.Add(tag);
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Generates the tunnel tags.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <returns>List of FlushTime Tunnel Tags</returns>
        private static List<Tag> GenerateTunnelTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom, int tunnelNumber)
        {
            List<Tag> tag = new List<Tag>();
            //Tag Id is used to store tunnel number which is passed to WriteTunnel to distinugush the tunnels.
            if (flushTimesAndSetupTom.Air != null)
            {
                //For Type Air
                foreach (var item in flushTimesAndSetupTom.Air)
                {
                    tag.Add(new OpcTag { Address = "Air", Value = Convert.ToString(item.FlushTime), TagId = tunnelNumber, TagType = item.LineNumber.ToString() });
                }
            }

            if (flushTimesAndSetupTom.Water != null)
            {
                //For Type Water
                foreach (var item in flushTimesAndSetupTom.Water)
                {
                    tag.Add(new OpcTag { Address = "Water", Value = Convert.ToString(item.FlushTime), TagId = tunnelNumber, TagType = item.LineNumber.ToString() });
                }
            }

            if (flushTimesAndSetupTom.WasherTimeOutMachine != null)
            {
                //For Type Equipment
                foreach (var item in flushTimesAndSetupTom.WasherTimeOutMachine)
                {
                    tag.Add(new OpcTag { Address = "Dosing", Value = Convert.ToString(item.DosingPointNumber), TagId = tunnelNumber, TagType = item.SignalNumber.ToString() });
                    tag.Add(new OpcTag { Address = "Equipment", Value = Convert.ToString(item.EquipmentNumber), TagId = tunnelNumber, TagType = item.SignalNumber.ToString() });
                }
            }

            return tag;
        }

        /// <summary>
        /// Generates the conventional flush tom tags.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <returns>List of Conventional FlushTime Tags</returns>
        private static List<Tag> GenerateConventionalFlushTOMTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom, int tunnelNumber)
        {
            List<Tag> tag = new List<Tag>();
            //Tag Id is used to store tunnel number which is passed to WriteTunnel to distinugush the tunnels.
            const int ConventionalPLCIndex = 72;
            int startIndex = (tunnelNumber - 1) * ConventionalPLCIndex;
            int initialIndex = 29;
            int tagIndex = 0;
            if (flushTimesAndSetupTom.Water != null)
            {
                //For Type Water 30…41
                foreach (var item in flushTimesAndSetupTom.Water)
                {
                    tagIndex++;
                    tag.Add(new OpcTag { Address = "Water", Value = Convert.ToString(item.FlushTime), TagId = initialIndex + startIndex, TagType = tagIndex.ToString() });
                    initialIndex++;
                }
            }
            if (flushTimesAndSetupTom.Air != null)
            {
                tagIndex = 0;
                initialIndex = 41;
                //For Type Air 42…53
                foreach (var item in flushTimesAndSetupTom.Air)
                {
                    tagIndex++;
                    tag.Add(new OpcTag { Address = "Air", Value = Convert.ToString(item.FlushTime), TagId = initialIndex + startIndex, TagType = tagIndex.ToString() });
                    initialIndex++;
                }
            }

            if (flushTimesAndSetupTom.WasherTimeOutMachine != null)
            {
                initialIndex = 53;
                tagIndex = 0;
                //For Type TimeOutMachine 54..65
                foreach (var item in flushTimesAndSetupTom.WasherTimeOutMachine)
                {
                    tagIndex++;
                    tag.Add(new OpcTag { Address = "Equipment", Value = Convert.ToString(item.EquipmentNumber), TagId = initialIndex + startIndex, TagType = tagIndex.ToString() });
                    initialIndex++;
                }
            }
            return tag;
        }

        /// <summary>
        /// Validates the conventional flush tomtplc.
        /// </summary>
        /// <param name="flushTimeTom">The flush time tom.</param>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <param name="plc">The Conventional Flush TOMT PLC.</param>
        /// <param name="tg">The Conventional FlushTOMT PLC tags.</param>
        /// <returns></returns>
        private List<OpcTag> ValidateConventionalFlushTOMTPLC(Models.Washers.FlushTimesAndSetupTom flushTimeTom, TunnelGeneralModel tunnelData, PlcTagController plc, List<Tag> tg)
        {
            var generatedTags = GenerateConventionalFlushTOMTags(flushTimeTom, tunnelData.LfsWasher);
            TagCollection tagStatusTunnel = plc.ValidateConventionalTags(new TagCollection { Tags = generatedTags }, tunnelData.ControllerId, 2, tunnelData.LfsWasher);
            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tg.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address && tag.TagId == plcTag.TagId)
                    {
                        GetFlushTimePLCAmbiguousTags(message, ambiguousTags, tag, plcTag);
                    }
                }
            }
            return ambiguousTags;
        }

        /// <summary>
        /// Writes to PLC.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        private void WriteToPlc(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            //If Controller is of type EcontrolPlus and conentional washer
            if (flushTimesAndSetupTom.ControllerModelId == 8 && flushTimesAndSetupTom.WasherGroupTypeId == 1)
            {
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);

                if (flushTimesAndSetupTom != null)
                {
                    List<Tag> tagsList = GetEcontolPlusConventionalFlushTimeTags(flushTimesAndSetupTom);
                    if (tagsList != null && tagsList.Count > 0)
                    {
                        MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                        plc.WriteTags(mitsubishiTag, flushTimesAndSetupTom.ControllerId, flushTimesAndSetupTom.WasherGroupTypeId, SourcePage.WasherPageFlushTime);
                    }
                }
            }
            else if (flushTimesAndSetupTom.ControllerModelId == 8 && flushTimesAndSetupTom.WasherGroupTypeId == 2)
            {
                //If Controller is of type EcontrolPlus and tunnel washer
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);

                if (flushTimesAndSetupTom != null)
                {
                    List<Tag> tagsList = GetEcontolPlusTunnelFlushTimeTags(flushTimesAndSetupTom);
                    if (tagsList != null && tagsList.Count > 0)
                    {
                        MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                        plc.WriteTags(mitsubishiTag, flushTimesAndSetupTom.ControllerId, flushTimesAndSetupTom.WasherGroupTypeId, SourcePage.WasherPageFlushTime);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the econtol plus conventional flush time tags.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <returns>Econtol Plus Conventional FlushTime Tags</returns>
        private List<Tag> GetEcontolPlusConventionalFlushTimeTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<Tag> tagsList = new List<Tag>();
            //Get Address offset based on LFS washer number or MachineNumber
            int offset = (flushTimesAndSetupTom.MachineNumber - 1) * 30;
            if (flushTimesAndSetupTom.Pumps != null && flushTimesAndSetupTom.Pumps.Count > 0)
            {
                int i = 1;
                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.Pumps)
                {
                    //Create pump tags for Flush Time
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 534 + (i - 1) + offset),
                        Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10),
                        TagItemType = UIInputType.TypeInt
                    });
                    i++;
                }
            }

            if (flushTimesAndSetupTom.MainEquipment != null && flushTimesAndSetupTom.MainEquipment.Count > 0)
            {
                int i = 0;
                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.MainEquipment)
                {
                    //Create main equipment tags for Flush Time (ME1)
                    if (i == 0)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", 529 + offset),
                            Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    //Create main equipment tags for Flush Time (ME2)
                    if (i == 1)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", 542 + offset),
                            Value = Convert.ToString(washerFlushTimeModel.FlushTime * 10),
                            TagItemType = UIInputType.TypeInt
                        });
                    }

                    i++;
                }
            }
            return tagsList;
        }

        /// <summary>
        /// Builds the PLCXL tunnel flush time tags.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <returns>PLCXL Tunnel Flush Time Tags</returns>
        private List<Tag> BuildPLCXLTunnelFlushTimeTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<Tag> tagsList = new List<Tag>();
            int pumpStartIndex = flushTimesAndSetupTom.ControllerTypeId == 13 ? 275 : flushTimesAndSetupTom.MachineNumber == 1 ? 305 : 320;
            foreach (var item in flushTimesAndSetupTom.Pumps)
            {
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (pumpStartIndex + item.LineNumber) - 1),
                    Value = (item.FlushTime * 10).ToString(),
                    TagType = "PUMP",
                    TagId = flushTimesAndSetupTom.MachineNumber,
                    TagTypeId = item.LineNumber
                });
            }
            foreach (var item in flushTimesAndSetupTom.MainEquipment)
            {
                tagsList.Add(new MitsubishiTag()
                {
                    Address = string.Format("R{0}", (item.LineNumber == 6 ? pumpStartIndex : pumpStartIndex + 6) - (1)),
                    Value = (item.FlushTime * 10).ToString(),
                    TagType = "ME",
                    TagId = flushTimesAndSetupTom.MachineNumber,
                    TagTypeId = item.LineNumber
                });
            }
            return tagsList;
        }

        /// <summary>
        /// Builds the PLCXL tunnel flush time overrides.
        /// </summary>
        /// <param name="flushTimesAndSetupTom">The flush times and setup tom.</param>
        /// <returns>Flush Times And Setup Tom</returns>
        private Models.Washers.FlushTimesAndSetupTom BuildPLCXLTunnelFlushTimeOverrides(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            IPlcService plcService = new PlcService();
            var plc = new PlcTagController(plcService, UserService, PlantService);
            var appTags = BuildPLCXLTunnelFlushTimeTags(flushTimesAndSetupTom);
            var tags = BuildPLCXLTunnelFlushTimeTags(flushTimesAndSetupTom);
            var ambiguousTags = new List<Tag>();
            var plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tags) }, flushTimesAndSetupTom.ControllerId, SourcePage.TunnelFlushTimesTomPage);
            foreach (var appTag in appTags)
            {
                foreach (Tag plcTag in plcTags.Tags)
                {
                    if (appTag.Address == plcTag.Address && appTag.Value != plcTag.Value)
                    {
                        ambiguousTags.Add(appTag);
                    }
                }
            }
            int tagIndexinPLC = 0;
            for (int index = 0; index < flushTimesAndSetupTom.Pumps.Count(); index++)
            {
                tagIndexinPLC++;
                flushTimesAndSetupTom.Pumps[tagIndexinPLC - 1].IsValueDiffForPumpsFlushTime = ambiguousTags.Where(x => x.TagType.ToUpper() == "PUMP" && x.TagTypeId == flushTimesAndSetupTom.Pumps[tagIndexinPLC - 1].LineNumber).ToList().Count > 0 ? true : false;
            }
            tagIndexinPLC = 0;
            for (int index = 0; index < flushTimesAndSetupTom.MainEquipment.Count(); index++)
            {
                tagIndexinPLC++;
                flushTimesAndSetupTom.MainEquipment[tagIndexinPLC - 1].IsValueDiffForFlushTimeME = ambiguousTags.Where(x => x.TagType.ToUpper() == "ME" && x.TagTypeId == flushTimesAndSetupTom.MainEquipment[tagIndexinPLC - 1].LineNumber).ToList().Count > 0 ? true : false;
            }
            return flushTimesAndSetupTom;
        }

        /// <summary>
        /// Save the Alarm Data
        /// </summary>
        /// <param name="flushTimesAndSetupTom">Object of FlushTimesAndSetupTom.</param>
        /// <returns>
        /// List of TunnelFlushTimeTags.
        /// </returns>
        private List<Tag> GetEcontolPlusTunnelFlushTimeTags(Models.Washers.FlushTimesAndSetupTom flushTimesAndSetupTom)
        {
            List<Tag> tagsList = new List<Tag>();

            if (flushTimesAndSetupTom.Pumps != null && flushTimesAndSetupTom.Pumps.Count > 0)
            {
                int i = 0;

                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.Pumps)
                {
                    if (i <= 7)
                    {
                        //Create 8 pump tags for Flush Time
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", 323 + i),
                            Value = Convert.ToString(washerFlushTimeModel.FlushTime),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    i++;
                }
            }

            if (flushTimesAndSetupTom.MainEquipment != null && flushTimesAndSetupTom.MainEquipment.Count > 0)
            {
                int i = 0;
                foreach (WasherFlushTimeModel washerFlushTimeModel in flushTimesAndSetupTom.MainEquipment)
                {
                    //Create main equipment tags for Flush Time (ME1)
                    if (i == 0)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = "D321",
                            Value = Convert.ToString(washerFlushTimeModel.FlushTime),
                            TagItemType = UIInputType.TypeInt
                        });
                    }
                    //Create main equipment tags for Flush Time (ME2)
                    if (i == 1)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = "D322",
                            Value = Convert.ToString(washerFlushTimeModel.FlushTime),
                            TagItemType = UIInputType.TypeInt
                        });
                    }

                    i++;
                }
            }
            if (flushTimesAndSetupTom.WasherTimeOutMachine != null && flushTimesAndSetupTom.WasherTimeOutMachine.Count > 0)
            {
                int i = 0;

                //For Type Equipment & Dosing Point
                foreach (var item in flushTimesAndSetupTom.WasherTimeOutMachine)
                {
                    //Equipment
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 6051 + i),
                        Value = Convert.ToString(item.EquipmentNumber),
                        TagItemType = UIInputType.TypeInt
                    });
                    //Dosing Point
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 6052 + i),
                        Value = Convert.ToString(item.DosingPointNumber),
                        TagItemType = UIInputType.TypeInt
                    });
                    i += 2;
                }
            }

            return tagsList;
        }
    }
}