﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Conventional Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web.Http;
    using AutoMapper;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers.Conventional;
    using Elmah;
    using Models.Washers.Conventional;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Conventional;
    using Tunnel;
    using Utilities;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     Api Controller for Conventional.
    /// </summary>
    [Authorize]
    public class ConventionalController : BaseApiController
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The _conventional general services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ConventionalController" /> class.
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        /// The injection service
        /// </summary>
        private readonly IInjectionService injectionService;

        /// <summary>
        /// The washer services
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        /// The Washer Group Type Id
        /// </summary>
        private static int washerGroupTypeId = 2;

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="conventionalGeneralServices">conventional general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupService">The washer Group Service.</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="injectionService">The injection service.</param>
        /// <param name="washerServices">The washer services.</param>
        public ConventionalController(IConventionalGeneralServices conventionalGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService, IInjectionService injectionService, IWasherServices washerServices)
            : base(userService, plantService)
        {
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.injectionService = injectionService;
            this.washerServices = washerServices;
        }

        /// <summary>
        /// Initializes a new instance of the
        /// <see cref="TunnelController" />
        /// class.
        /// </summary>
        /// <param name="conventionalGeneralServices">conventional general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupService">The washer Group Service.</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="injectionService">The injection service.</param>
        /// <param name="washerServices">The washer services.</param>
        public ConventionalController(IConventionalGeneralServices conventionalGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupService washerGroupService, IPlcService plcService, IUserService userService, IPlantService plantService, IInjectionService injectionService, IWasherServices washerServices)
            : base(userService, plantService)
        {
            this.conventionalGeneralServices = conventionalGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
            this.injectionService = injectionService;
            this.washerServices = washerServices;
        }

        /// <summary>
        /// Gets the drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="washerGroupId">The washerGroup identifier.</param>
        /// <param name="washerType">Type of the washer.</param>
        /// <returns>
        /// ConventionalGeneralDropDownModel.
        /// </returns>
        [HttpGet]
        public ConventionalGeneralDropDownModel GetDropDownData(string ecoLabAccountNumber, int regionId, int washerGroupId, string washerType)
        {
            var conventionalGeneralDropdownsModel = new ConventionalGeneralDropDownModel();
            var objList = conventionalGeneralServices.GetWashersModelList(washerType, regionId);
            IEnumerable<WasherModelListModel> washerModelList = Mapper.Map<IEnumerable<WasherModelList>, List<WasherModelListModel>>(objList);
            conventionalGeneralDropdownsModel.WashersModelList = washerModelList;

            IEnumerable<Ecolab.Models.ControllerSetup.Controller> controllerList = controllerSetupService.GetControllerDetails(
                ecoLabAccountNumber, false)
                .Where(c => !string.IsNullOrEmpty(c.ControllerName));

            controllerList = controllerList.Where(c => c.WasherExtractorCount > 0);
            IEnumerable<WasherGroup> washerGroupModel = washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);

            IEnumerable<Ecolab.Models.Washers.Washers> washerList = washerServices.GetWashersDetails(ecoLabAccountNumber, washerGroupId, false);

            IEnumerable<WasherGroup> washerGroupListObj = washerGroupService.GetWasherGroupDetails(-1, ecoLabAccountNumber, 0, 12, string.Empty);

            var washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

            if (washerGroups.FirstOrDefault() != null && washerGroups.FirstOrDefault().ControllerId > 0)
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId > 6 || c.ControllerModelId != 12 || c.ControllerModelId != 13);
            }
            else if (washerGroups.FirstOrDefault() != null && washerGroups.FirstOrDefault().WasherCount > 0 && washerList.FirstOrDefault().WasherControllerId != 0)
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId == 12 || c.ControllerModelId == 13 || c.ControllerModelId < 7);
            }
            else
            {
                conventionalGeneralDropdownsModel.ControllerList = controllerList.Where(c => c.ControllerModelId == 12 || c.ControllerModelId == 13 || c.ControllerModelId < 8);
            }

            conventionalGeneralDropdownsModel.WasherGroupList = washerGroups;
            conventionalGeneralDropdownsModel.WasherGroupListForDropDown = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupListObj);

            conventionalGeneralDropdownsModel.WasherGroupListForDropDown = conventionalGeneralDropdownsModel.WasherGroupListForDropDown.Where(item => item.WasherGroupTypeId == 1);

            if (conventionalGeneralDropdownsModel.WasherGroupListForDropDown.Count() > 0)
            {
                washerGroupTypeId = 1;
            }

            return conventionalGeneralDropdownsModel;
        }

        /// <summary>
        /// Gets the size list.
        /// </summary>
        /// <param name="washerModelName">The washer model Name.</param>
        /// <param name="regionId">The Region Id Value</param>
        /// <param name="washerType">The Washer Type</param>
        /// <returns>
        /// List Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.WasherModelSizeModel.
        /// </returns>
        public IEnumerable<WasherModelSizeModel> GetSizeList(string washerModelName, int regionId, string washerType)
        {
            var objList = conventionalGeneralServices.GetWashersModelSizeList(washerModelName, regionId, washerType);
            var washerModelSizeList = Mapper.Map<IEnumerable<WasherModelSize>, IEnumerable<WasherModelSizeModel>>(objList);
            return washerModelSizeList;
        }

        /// <summary>
        /// Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>
        /// List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.LfsWasherNumberModel.
        /// </returns>
        public LfsWasherNumberModel GetLfsWasherList(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                var objList = conventionalGeneralServices.GetLfsWasherList(controllerId.Value, ecoLabAccountNumber);
                var lfsWasherList = Mapper.Map<LfsWasherNumber, LfsWasherNumberModel>(objList);
                return lfsWasherList;
            }
            else
            {
                return new LfsWasherNumberModel();
            }
        }

        /// <summary>
        /// Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>
        /// List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel.
        /// </returns>
        public List<WasherModeListModel> GetWasherModeList(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                var objWasherMode = conventionalGeneralServices.GetWasherModeList(ecoLabAccountNumber, controllerId.Value);
                var washerModeList = Mapper.Map<IEnumerable<WasherModeList>, IEnumerable<WasherModeListModel>>(objWasherMode).ToList();
                return washerModeList;
            }
            else
            {
                return new List<WasherModeListModel>();
            }
        }

        /// <summary>
        /// Saves the Conventional data.
        /// </summary>
        /// <param name="conventionalData">The Conventional data.</param>
        /// <returns>
        /// Http Response Message.
        /// </returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage SaveConventionalData(ConventionalGeneralModel conventionalData)
        {
            string washerIdcopy = string.Empty;
            List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
            try
            {
                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(conventionalData.ControllerId, this.EcolabAccountNumber);
                conventionalData.ControllerModelId = controllerDetails.ControllerModelId;
                conventionalData.ControllerTypeId = controllerDetails.ControllerTypeId;

                if (conventionalData.ControllerModelId > 6)
                {
                    conventionalData.EndOfFormula = 0;
                    conventionalData.HoldSignal = false;
                    conventionalData.HoldDelay = 0;
                    conventionalData.WaterFlushTime = 0;
                    conventionalData.RatioDosingActive = false;
                }
                var objConventionalData = Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                var objConventioalDataSync = Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                objConventioalDataSync.ConventionalWasherTagList = new List<ConventionalTags>();
                DateTime lastModifiedTimeStamp;
                objConventionalData.MyServiceCustMchGuid = Guid.NewGuid();
                if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupId != conventionalData.WasherGroupIdNew)
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, true);
                }
                else
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, false);
                }
                string washerId = this.conventionalGeneralServices.SaveConventionalData(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStamp);
                washerIdcopy = washerId;
                int isNumeric;
                if (!int.TryParse(washerId, out isNumeric))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, washerId);
                }
                objConventionalData.Id = Convert.ToInt32(washerId);
                objConventioalDataSync.Id = Convert.ToInt32(washerId);
                objConventionalData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objConventioalDataSync.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objConventioalDataSync.InjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupId);
                objConventioalDataSync.MyServiceCustMchGuid = objConventionalData.MyServiceCustMchGuid;
                Push.PushToQueue(objConventioalDataSync, UserId, objConventionalData.Id, (int)TcdAdminMessageTypes.TcdAddConventionaGeneral, objConventionalData.EcolabAccountNumber);

                DateTime lastModifiedTimeStampTags;
                //Step 4: Validate and save tags against DB
                string validateTagStatus = conventionalGeneralServices.ValidateDuplicateTags(objConventionalData, UserId, conventionalData.Role);

                if (!string.IsNullOrEmpty(validateTagStatus))
                {
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = validateTagStatus });
                }

                try
                {
                    if ((conventionalData.ControllerModelId == 11 || conventionalData.ControllerModelId == 8) && washerGroupTypeId == 1)
                    {
                        WriteToPlc(conventionalData, null);
                    }
                    else if (conventionalData.ControllerModelId == 7)
                    {
                        WriteGeneralTabDataToPLC(conventionalData);
                    }
                    else
                    {
                        try
                        {
                            var plc = new PlcTagController(plcService, UserService, PlantService);
                            var returnStatus = string.Empty;
                            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags.Count > 0 && conventionalData.ControllerId > 0)
                            {
                                returnStatus = plc.ValidateOrWriteTags(conventionalData.PlcWasherTagModelTags, conventionalData.ControllerId, true);
                            }
                            if (!string.IsNullOrEmpty(returnStatus))
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, returnStatus + "@" + washerId);
                            }
                            string tagStatus = conventionalGeneralServices.UpdateTagsInDB(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStampTags);
                            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags.Count > 0 && conventionalData.ControllerId > 0 && tagStatus == "0")
                            {
                                plc.ValidateOrWriteTags(conventionalData.PlcWasherTagModelTags, conventionalData.ControllerId, false);
                            }
                            objConventionalData.ConventionalWasherTagList = conventionalGeneralServices.GetConventionalWasherTagsByWasherId(objConventionalData.Id, objConventionalData.EcolabAccountNumber);
                            objConventionalData.InjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupId);
                            Push.PushToQueue(objConventionalData, UserId, objConventionalData.Id, (int)TcdAdminMessageTypes.TcdUpdateConventionaGeneral, objConventionalData.EcolabAccountNumber);
                            //Injections
                            string injStatus = ProcessInjectionOnSave(conventionalData, washerId);
                            if (!string.IsNullOrEmpty(injStatus))
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, injStatus);
                            }
                        }
                        catch (Exception ex)
                        {
                            //// TODO: We need to save Irrespective whether tags are valid or not. When exception occurs UpdateTags method is skipped previously. Needs to be refactored in future.
                            conventionalGeneralServices.UpdateTagsInDB(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStampTags);
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", washerIdcopy));
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", washerIdcopy));
                    }
                }
                objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                {
                    ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                    ParentEntityId = objConventionalData.WasherGroupId,
                    Entity = Convert.ToInt32(PlcDiscrepancyEntity.Washer),
                    EntityId = Convert.ToInt32(washerId),
                    IsCentral = false,
                    ControllerId = objConventionalData.ControllerId,
                    UserId = this.UserId,
                    LastModifiedUserId = this.UserId
                });

                return Request.CreateResponse(HttpStatusCode.OK, new { WasherId = washerId, plcDiscrepancyModel = objPLCDiscrepancyModels });

            }
            catch (SqlException sqlex)
            {
                if (conventionalData.ControllerId > 0)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, int.Parse(Regex.Match(sqlex.Message, @"\d+").Value));
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, "PhonyWasher");
                }
            }
            catch (Exception ex)
            {
                if (!string.IsNullOrEmpty(washerIdcopy))
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Length > 3 ? ex.Message.Substring(0, 5) : ex.Message + "@" + washerIdcopy);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Length > 3 ? ex.Message.Substring(0, 5) : ex.Message);
                }
            }
        }

        /// <summary>
        /// Updates the Conventional data.
        /// </summary>
        /// <param name="conventionalData">The Conventional data.</param>
        /// <returns>
        /// Http Response Message.
        /// </returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage UpdateConventionalData(ConventionalGeneralModel conventionalData)
        {
            string washerIdcopy = string.Empty;
            DateTime lastModifiedTimeStampTags;
            try
            {
                List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
                ConventionalGeneralModel prevconventionalData = null;
                ConventionalGeneral prevconventional = null;
                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(conventionalData.ControllerId, this.EcolabAccountNumber);
                conventionalData.ControllerModelId = controllerDetails.ControllerModelId;
                conventionalData.ControllerTypeId = controllerDetails.ControllerTypeId;
                if (conventionalData != null && ((conventionalData.ControllerModelId == 11) && (conventionalData.WasherGroupTypeName == "Conventional" || washerGroupTypeId == 1)) || (conventionalData.ControllerModelId == 8 && washerGroupTypeId == 1))
                {
                    prevconventional = conventionalGeneralServices.GetConventionalData(conventionalData.Id, conventionalData.WasherGroupId, conventionalData.EcolabAccountNumber);
                    prevconventionalData = Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(prevconventional);
                }
                #region Step 1: Save washer data to db
                if (conventionalData.ControllerModelId == 7)
                {
                    conventionalData.EndOfFormula = 0;
                    conventionalData.HoldSignal = false;
                    conventionalData.HoldDelay = 0;
                    conventionalData.WaterFlushTime = 0;
                    conventionalData.RatioDosingActive = false;
                }
                string tagStatus = string.Empty;
                var objConventionalData = Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                var objConventionalDataSync = Mapper.Map<ConventionalGeneralModel, ConventionalGeneral>(conventionalData);
                objConventionalDataSync.ConventionalWasherTagList = new List<ConventionalTags>();
                DateTime lastModifiedTimeStamp;
                if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupId != conventionalData.WasherGroupIdNew)
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, true);
                }
                else
                {
                    int maxInjectionStatus = this.conventionalGeneralServices.ValidateMaxInjectionClassesByController(objConventionalData, UserId, conventionalData.Role, false);
                }
                objConventionalData.LastModifiedTimeStamp = DateTime.MinValue;
                string washerId = conventionalGeneralServices.UpdateConventionalData(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStamp);
                washerIdcopy = washerId;
                int isNumeric;
                if (!int.TryParse(washerId, out isNumeric))
                {
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = washerId });
                }
                #endregion
                #region Step 2: Save washer data to central
                objConventionalData.Id = Convert.ToInt32(washerId);
                objConventionalDataSync.Id = Convert.ToInt32(washerId);
                objConventionalData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objConventionalDataSync.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objConventionalDataSync.InjectionData = new List<InjectionData>();
                if (conventionalData.WasherGroupIdNew > 0 && conventionalData.WasherGroupId != conventionalData.WasherGroupIdNew)
                {
                    var oldWasherGroupInjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupId);
                    objConventionalDataSync.InjectionData.AddRange(oldWasherGroupInjectionData);
                    var newWasherGroupInjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupIdNew);
                    objConventionalDataSync.InjectionData.AddRange(newWasherGroupInjectionData);
                }
                else
                {
                    objConventionalDataSync.InjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupId);
                }
                Push.PushToQueue(objConventionalDataSync, UserId, objConventionalData.Id, (int)TcdAdminMessageTypes.TcdUpdateConventionaGeneral, objConventionalData.EcolabAccountNumber);

                //Step 4: Validate and save tags against DB
                tagStatus = conventionalGeneralServices.ValidateDuplicateTags(objConventionalData, UserId, conventionalData.Role);

                if (!string.IsNullOrEmpty(tagStatus))
                {
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = tagStatus });
                }

                //Step 3: Validate tags against PLC

                #endregion
                #region Step 3: Validate tags against PLC
                try
                {
                    objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                    {
                        ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                        ParentEntityId = objConventionalData.WasherGroupId,
                        Entity = Convert.ToInt32(PlcDiscrepancyEntity.Washer),
                        EntityId = Convert.ToInt32(washerId),
                        IsCentral = false,
                        ControllerId = objConventionalData.ControllerId,
                        UserId = this.UserId,
                        LastModifiedUserId = this.UserId
                    });
                    if ((conventionalData.ControllerModelId == 8 || conventionalData.ControllerModelId == 11) && washerGroupTypeId == 1)
                    {
                        WriteToPlc(conventionalData, prevconventionalData);
                    }
                    else if (conventionalData.ControllerModelId == 7)
                    {
                        WriteGeneralTabDataToPLC(conventionalData);
                    }
                    else
                    {
                        try
                        {
                            var returnStatus = string.Empty;
                            var plc = new PlcTagController(plcService, UserService, PlantService);
                            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags.Count > 0 && conventionalData.ControllerId > 0)
                            {
                                returnStatus = plc.ValidateOrWriteTags(conventionalData.PlcWasherTagModelTags, conventionalData.ControllerId, true);
                            }

                            if (!string.IsNullOrEmpty(returnStatus))
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, returnStatus);
                            }
                            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags.Count > 0 && conventionalData.ControllerId > 0)
                            {
                                List<OpcTag> tagValues = new List<OpcTag>();
                                OpcTag tagAWEA = new OpcTag() { };
                                OpcTag tagRATD = new OpcTag();

                                var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, conventionalData.ControllerId);
                                bool awea = fieldTags.AWEActive == true ? true : false;
                                bool ratioDosing = fieldTags.RatioDosingActive == true ? true : false;
                                //Allenbradley and Beckhoff
                                if (fieldTags.ControllerTypeId == 1 || fieldTags.ControllerTypeId == 2)
                                {
                                    tagAWEA.Address = fieldTags.ControllerTypeId == 1 ? "B3:9/0" : "L_AWEE";
                                    tagAWEA.TagItemType = UIInputType.TypeBool;
                                    tagAWEA.TagType = "Tag_AWEA";
                                    tagAWEA.Value = awea.ToString();

                                    tagRATD.Address = fieldTags.ControllerTypeId == 1 ? "B3:10/0" : "L_RATD";
                                    tagRATD.TagItemType = UIInputType.TypeBool;
                                    tagRATD.TagType = "Tag_RDE";
                                    tagRATD.Value = ratioDosing.ToString();

                                    conventionalData.PlcWasherTagModelTags.Add(tagAWEA);
                                    conventionalData.PlcWasherTagModelTags.Add(tagRATD);
                                }

                                List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, conventionalData.ControllerId, conventionalData.EcolabAccountNumber, conventionalData.Role);
                                var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Injection Quantity Multiplier").FirstOrDefault().FieldDefaultValue);

                                if (factorsMulti.Any())
                                {
                                    var factorsMultiplier = (int)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
                                }
                                conventionalData.PlcWasherTagModelTags.Where(_ => _.TagType.Equals("InjectionRatioTag")).Each(x => x.Value = Convert.ToString(Math.Round(Convert.ToDecimal(x.Value) * 10)));
                            }

                            //Step 4: Validate and save tags against DB
                            tagStatus = conventionalGeneralServices.UpdateTagsInDB(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStampTags);
                            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags.Count > 0 && conventionalData.ControllerId > 0 && (tagStatus == "0"))
                            {
                                plc.ValidateOrWriteTags(conventionalData.PlcWasherTagModelTags, conventionalData.ControllerId, false);
                            }

                            //Step 5: update washer tags data to central
                            objConventionalData.Id = Convert.ToInt32(washerId);
                            objConventionalData.ConventionalWasherTagList = conventionalGeneralServices.GetConventionalWasherTagsByWasherId(objConventionalData.Id, objConventionalData.EcolabAccountNumber);

                            objConventionalData.InjectionData = injectionService.GetInjectionDetailsForSynch(objConventionalData.WasherGroupId);

                            Push.PushToQueue(objConventionalData, UserId, objConventionalData.Id, (int)TcdAdminMessageTypes.TcdUpdateConventionaGeneral, objConventionalData.EcolabAccountNumber);

                            //step 6: Write injections to PLC
                            string injStatus = ProcessInjectionOnSave(conventionalData, washerId);
                            if (!string.IsNullOrEmpty(injStatus))
                            {
                                return Request.CreateResponse(HttpStatusCode.BadRequest, injStatus);
                            }
                        }
                        catch(Exception ex)
                        {
                            //// TODO: We need to save Irrespective whether tags are valid or not. When exception occurs UpdateTags method is skipped previously. Needs to be refactored in future.
                            conventionalGeneralServices.UpdateTagsInDB(objConventionalData, UserId, conventionalData.Role, out lastModifiedTimeStampTags);
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") || 
                        ex.Message.Contains("901") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", washerIdcopy));
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", washerIdcopy));
                    }
                }
                #endregion
                return Request.CreateResponse(HttpStatusCode.OK, new { WasherId = washerId, plcDiscrepancyModel = objPLCDiscrepancyModels });
            }
            catch (SqlException sqlex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, int.Parse(Regex.Match(sqlex.Message, @"\d+").Value));
            }
            catch (Exception ex)
            {
                if (ex.Message.Length > 5)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
            }
        }

        /// <summary>
        /// Reverses the specified text.
        /// </summary>
        /// <param name="text">The Reverse text Value.</param>
        /// <returns>The Reverse text Value</returns>
        private string Reverse(string text)
        {
            if (text == null)
            { return null; }

            // this was posted by petebob as well 
            char[] array = text.ToCharArray();
            Array.Reverse(array);
            return new string(array);
        }

        /// <summary>
        /// Writes the general tab data to PLC.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        private void WriteGeneralTabDataToPLC(ConventionalGeneralModel conventionalData)
        {
            const int ConventionalPLCIndex = 72;
            int startIndex = (conventionalData.LfsWasher - 1) * ConventionalPLCIndex;
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            string returnStatus = string.Empty;
            List<Tag> tg = GenerateTags(conventionalData, startIndex);
            plc.WriteTunnelTags(new TagCollection { Tags = tg }, conventionalData.ControllerId, 6);
            if (conventionalData.Role >= 7 && conventionalData.PlcWasherTagModelTags != null && conventionalData.PlcWasherTagModelTags.Any())
            {
                TagCollection tagStatuslist = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(conventionalData.PlcWasherTagModelTags) }, conventionalData.ControllerId);
                foreach (Tag tstatus in tagStatuslist.Tags.Where(tstatus => !tstatus.IsValid || tstatus.Quality == "Bad"))
                {
                    if (!string.IsNullOrEmpty(tstatus.Address))
                    {
                        int last = tagStatuslist.Tags.LastIndexOf(tstatus);
                        if (last != 14 && !string.IsNullOrEmpty(tstatus.Address))
                        {
                            returnStatus += tstatus.Address + ",";
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(returnStatus))
                            {
                                returnStatus += tstatus.Address;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets the lines connected to manifold.
        /// </summary>
        /// <param name="conventionalGeneralData">The conventional general data.</param>
        /// <returns>Get Lines Connected To Manifold Value</returns>
        private long GetLinesConnectedToManifold(ConventionalGeneralModel conventionalGeneralData)
        {
            string binaryValues = string.Empty;
            binaryValues = conventionalGeneralData.L12 == true ? "1" : "0";
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L11 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L10 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L9 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L8 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L7 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L6 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L5 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L4 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L3 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L2 == true ? "1" : "0");
            binaryValues = binaryValues + string.Empty + (conventionalGeneralData.L1 == true ? "1" : "0");

            long num, rem, binaryDecimalValue = 0;
            int baseBinaryValues = 1;
            num = Convert.ToInt64(binaryValues);

            while (num > 0)
            {
                rem = num % 10;
                binaryDecimalValue = binaryDecimalValue + rem * baseBinaryValues;
                num = num / 10;
                baseBinaryValues = baseBinaryValues * 2;
            }

            return binaryDecimalValue;
        }

        /// <summary>
        /// Generates the washer group conventional tags.
        /// </summary>
        /// <param name="conventionalGeneralData">The conventional general data.</param>
        /// <param name="prevconventionalData">The prevconventional data.</param>
        /// <returns>List of conventional tags</returns>
        private List<Tag> GenerateWasherGroupConventionalTags(ConventionalGeneralModel conventionalGeneralData, ConventionalGeneralModel prevconventionalData)
        {
            List<Tag> tagsList = new List<Tag>();
            if (conventionalGeneralData != null)
            {
                var offset = (conventionalGeneralData.LfsWasher - 1) * 30;
                long linesConnectedToManifold = 0;

                linesConnectedToManifold = GetLinesConnectedToManifold(conventionalGeneralData);

                string washerModelNumber = conventionalGeneralServices.GetWasherModelNumber(conventionalGeneralData.EcolabAccountNumber, conventionalGeneralData.ControllerId, conventionalGeneralData.WasherModeId);
                washerModelNumber = washerModelNumber == string.Empty ? "0" : washerModelNumber;
                var washerModeValuetoPlC = Convert.ToInt32(washerModelNumber) * 10;

                if (conventionalGeneralData.WasherStopExternalSignal == true)
                {
                    int washerStopExternalSignal = conventionalGeneralData.WasherStopExternalSignal == true ? 2 : 0;
                    washerModeValuetoPlC = washerModeValuetoPlC + washerStopExternalSignal;
                }
                else if (conventionalGeneralData.WasherStopUseFinalExtracting == true)
                {
                    int washerStopUseFinalExtracting = conventionalGeneralData.WasherStopUseFinalExtracting == true ? 1 : 0;
                    washerModeValuetoPlC = washerModeValuetoPlC + washerStopUseFinalExtracting;
                }

                tagsList.Add(new MitsubishiTag { Address = "R" + (300 + offset), Value = Convert.ToString(conventionalGeneralData.MaxMachineLoad) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (301 + offset), Value = Convert.ToString(conventionalGeneralData.MinMachineLoad) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (312 + offset), Value = Convert.ToString(conventionalGeneralData.UseMe1OfGroup) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (313 + offset), Value = Convert.ToString(conventionalGeneralData.UsePumpOfGroup) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (314 + offset), Value = Convert.ToString(conventionalGeneralData.ManifoldFlushTime * 10) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (317 + offset), Value = Convert.ToString(conventionalGeneralData.WasherOnHoldSignalDelay) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (318 + offset), Value = Convert.ToString(linesConnectedToManifold) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (322 + offset), Value = Convert.ToString(washerModeValuetoPlC) });
                tagsList.Add(new MitsubishiTag { Address = "R" + (323 + offset), Value = Convert.ToString(conventionalGeneralData.UseMe2OfGroup) });

                // 12: 10 Washers; 13: 5 Washers/1Tunnel
                if (conventionalGeneralData.ControllerTypeId == 12)
                {
                    tagsList.Add(new MitsubishiTag { Address = "L" + (150 + (conventionalGeneralData.LfsWasher - 1)), Value = Convert.ToString(conventionalGeneralData.TemperatureAlarmYesNo).ToLower() == "true" ? "1" : "0" });
                }
                else if (conventionalGeneralData.ControllerTypeId == 13)
                {
                    tagsList.Add(new MitsubishiTag { Address = "L" + (153 + (conventionalGeneralData.LfsWasher - 1)), Value = Convert.ToString(conventionalGeneralData.TemperatureAlarmYesNo).ToLower() == "true" ? "1" : "0" });
                }
            }

            if (prevconventionalData != null && conventionalGeneralData != null)
            {
                if (conventionalGeneralData.LfsWasher != prevconventionalData.LfsWasher)
                {
                    var offset = (prevconventionalData.LfsWasher - 1) * 30;

                    // General page data defaulting to zero for previous lfs washer, when update to another lfs washer number.
                    tagsList.Add(new MitsubishiTag { Address = "R" + (300 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (301 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (312 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (313 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (314 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (317 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (318 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (322 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (323 + offset), Value = "0" });

                    // 12: 10 Washers; 13: 5 Washers/1Tunnel
                    if (conventionalGeneralData.ControllerTypeId == 12)
                    {
                        tagsList.Add(new MitsubishiTag { Address = "L" + (150 + (prevconventionalData.LfsWasher - 1)), Value = "0" });
                    }
                    else if (conventionalGeneralData.ControllerTypeId == 13)
                    {
                        tagsList.Add(new MitsubishiTag { Address = "L" + (153 + (prevconventionalData.LfsWasher - 1)), Value = "0" });
                    }

                    // FlushTime page data defaulting to zero for previous lfs washer, when update to another lfs washer number.
                    tagsList.Add(new MitsubishiTag { Address = "R" + (315 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (316 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (319 + offset), Value = "0" });

                    // ProductDeviation page data defaulting to zero for previous lfs washer, when update to another lfs washer number.
                    tagsList.Add(new MitsubishiTag { Address = "R" + (303 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (304 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (305 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (306 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (307 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (308 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (309 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (310 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (311 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (325 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (326 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (327 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (302 + offset), Value = "0" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (328 + offset), Value = "0" });
                }
            }

            return tagsList;
        }

        /// <summary>
        /// Generates the tags.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="startIndex">The start index.</param>
        /// <returns>List of conventional tags</returns>
        private List<Tag> GenerateTags(ConventionalGeneralModel conventionalData, int startIndex)
        {
            List<Tag> tg = new List<Tag>();

            //Modifying washer mode id's for writing in to PLC
            int alteredWasherMode = conventionalData.WasherModeId == 6 ? 1 : conventionalData.WasherModeId == 7 ? 2 : conventionalData.WasherModeId == 8 ? 3 : conventionalData.WasherModeId == 9 ? 4 :
                                                                conventionalData.WasherModeId == 10 ? 5 : conventionalData.WasherModeId == 11 ? 6 : 0;

            string formatConventionalOptions = string.Empty;
            formatConventionalOptions += conventionalData.ProgramSelectionByTime == true ? 1 : 0; //4
            formatConventionalOptions += conventionalData.WeInTomMode == true ? 1 : 0;   //5
            formatConventionalOptions += conventionalData.OnHoldWESignalActive == true ? 1 : 0;   // 6
            formatConventionalOptions += conventionalData.WasherStopExternalSignal == true ? 1 : 0;   //7
            formatConventionalOptions += conventionalData.ValveOutputsUsedAsTomSignal == true ? 1 : 0;   //8                        
            formatConventionalOptions += "0000000";

            var reversedString = Reverse(formatConventionalOptions);

            var washerMode = Convert.ToString(alteredWasherMode, 2); //0,1,2,3
            reversedString += alteredWasherMode == 1 ? washerMode = "000" + washerMode.ToString() :
                              alteredWasherMode == 2 ? washerMode = "00" + washerMode.ToString() :
                              alteredWasherMode == 3 ? washerMode = "00" + washerMode.ToString() :
                              alteredWasherMode == 4 ? washerMode = "0" + washerMode.ToString() :
                              alteredWasherMode == 5 ? washerMode = "0" + washerMode.ToString() :
                              alteredWasherMode == 6 ? washerMode = "0" + washerMode.ToString() : "0000";

            decimal formatTunnelOptionsDecimal = Convert.ToInt64(reversedString, 2);

            //Used TagId to identify the address of plc to be updated.
            tg.Add(new OpcTag { Address = nameof(conventionalData.MaxMachineLoad), Value = Convert.ToString(conventionalData.MaxMachineLoad), TagId = 0 + startIndex });
            tg.Add(new OpcTag { Address = nameof(conventionalData.MinMachineLoad), Value = Convert.ToString(conventionalData.MinMachineLoad), TagId = 1 + startIndex });
            tg.Add(new OpcTag { Address = "WasherOptions", Value = Convert.ToString(formatTunnelOptionsDecimal), TagId = 70 + startIndex });
            tg.Add(new OpcTag { Address = nameof(conventionalData.WasherOnHoldSignalDelay), Value = Convert.ToString(conventionalData.WasherOnHoldSignalDelay), TagId = 28 + startIndex });

            string linesConnectedToManifold = string.Empty;
            linesConnectedToManifold += conventionalData.L1 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L2 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L3 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L4 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L5 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L6 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L7 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L8 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L9 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L10 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L11 == true ? 1 : 0;
            linesConnectedToManifold += conventionalData.L12 == true ? 1 : 0;

            decimal formatLinesConnectedToManifold = Convert.ToInt64(Reverse(linesConnectedToManifold), 2);

            tg.Add(new OpcTag { Address = "ConventionalLinesConnected", Value = Convert.ToString(formatLinesConnectedToManifold), TagId = 69 + startIndex });
            tg.Add(new OpcTag { Address = nameof(conventionalData.ManifoldFlushTime), Value = Convert.ToString(conventionalData.ManifoldFlushTime), TagId = 71 + startIndex });
            tg.Add(new OpcTag { Address = "FlowSwitchNumber", Value = Convert.ToString(conventionalData.FlowSwitchNumber), TagId = conventionalData.LfsWasher - 1 });
            tg.Add(new OpcTag { Address = "SignalAcceptTimeWE", Value = conventionalData.SignalAcceptanceTime.ToString(), TagId = conventionalData.LfsWasher });
            return tg;
        }

        /// <summary>
        /// Processes the injection on save.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <returns>Process Injection Status</returns>
        private string ProcessInjectionOnSave(ConventionalGeneralModel conventionalData, string washerId)
        {
            var objList = injectionService.GetInjectionDetails(conventionalData.WasherGroupId);
            var injectionData = Mapper.Map<List<InjectionData>, List<Models.WasherGroup.InjectionData>>(objList);

            //Injection class and ration
            string injStatus = SaveInjectionClassAndRatioInPlc(conventionalData, injectionData);

            if (!string.IsNullOrEmpty(injStatus))
            {
                return injStatus;
            }

            return injStatus;
        }

        /// <summary>
        /// Injectionses the class and ratio.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="injectionData">The injection data.</param>
        /// <returns>Injection Class And Ratio In Plc</returns>
        private string SaveInjectionClassAndRatioInPlc(ConventionalGeneralModel conventionalData, IEnumerable<Models.WasherGroup.InjectionData> injectionData)
        {
            string returnStatus = string.Empty;
            var plc = new PlcTagController(plcService, UserService, PlantService);
            foreach (var injection in injectionData)
            {
                var tags = new List<OpcTag>();
                decimal injectionTagValue = injection.ReferenceLoad != 0 ? (Convert.ToDecimal(injection.Capacity) * 100) / Convert.ToDecimal(injection.ReferenceLoad) : 0;
                var injectiontagValue = Convert.ToInt32(injectionTagValue * 100);

                if (!string.IsNullOrEmpty(injection.InjectionClassTag) && !string.IsNullOrEmpty(injection.InjectionRatioTag) && injectionTagValue != 0)
                {
                    var tag = new OpcTag();
                    tag.Address = injection.InjectionClassTag;
                    tag.Value = injection.InjectionClass;
                    tags.Add(tag);

                    var tagRatio = new OpcTag();
                    tagRatio.Address = injection.InjectionRatioTag;
                    tagRatio.Value = injectiontagValue.ToString();
                    tags.Add(tagRatio);
                }
                if (conventionalData.ControllerId > 0)
                {
                    returnStatus = plc.ValidateOrWriteTags(tags, conventionalData.ControllerId, true);
                }
                if (string.IsNullOrEmpty(returnStatus))
                {
                    if (conventionalData.ControllerId > 0)
                    {
                        plc.ValidateOrWriteTags(tags, conventionalData.ControllerId);
                    }
                }
            }

            return returnStatus;
        }

        /// <summary>
        /// Gets the tunnel data.
        /// </summary>
        /// <param name="id">The identifier value.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>
        /// Ecolab.ConduitLocal.Web.Models.Washers.Conventional.ConventionalGeneralModel.
        /// </returns>
        [HttpGet]
        public ConventionalGeneralModel GetConventionalData(int id, int washerGroupId, string ecoLabAccountNumber, int regionId)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            var objList = conventionalGeneralServices.GetConventionalData(id, washerGroupId, ecoLabAccountNumber);
            if (objList != null && objList.Id > 0)
            {
                objList.ConventionalWasherTagList = conventionalGeneralServices.GetConventionalWasherTags(objList.Id, ecoLabAccountNumber);
            }
            var conventionaldata = Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(objList);

            var objInjectionList = injectionService.GetInjectionDetails(conventionaldata.WasherGroupId);
            int refrenceLoad = 0;

            foreach (var item in objInjectionList)
            {
                if (item.ReferenceLoad > refrenceLoad)
                {
                    refrenceLoad = item.ReferenceLoad;
                }
            }
            objInjectionList = objInjectionList.Where(item => item.WasherId == id).ToList();

            if (objInjectionList != null && objInjectionList.Count > 0 && refrenceLoad != 0)
            {
                conventionaldata.InjectionRatio = Convert.ToDecimal(objInjectionList[0].Capacity * 100) / refrenceLoad;
                conventionaldata.InjectionRatio = Math.Round(conventionaldata.InjectionRatio, 2);
            }
            if (!conventionaldata.ConventionalWasherTagList.Any())
            {
                conventionaldata.ConventionalWasherTagList = null;
            }
            if (conventionaldata.ConventionalWasherTagList != null)
            {
                var tagsList = new List<OpcTag>();
                TagCollection tagStatus = new TagCollection();

                var tagModel = conventionaldata.ConventionalWasherTagList.FirstOrDefault();

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.EndOfFormulaTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.EndOfFormulaTag,
                        Value = conventionaldata.EndOfFormula.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WasherModeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WasherModeTag,
                        Value = conventionaldata.WasherModeId.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.HoldDelayTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.HoldDelayTag,
                        Value = conventionaldata.HoldDelay.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WaterFlushTimeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WaterFlushTimeTag,
                        Value = conventionaldata.WaterFlushTime.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.RatioDosingActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.RatioDosingActiveTag,
                        Value = conventionaldata.RatioDosingActive.ToString(CultureInfo.CurrentCulture),
                        TagItemType = UIInputType.TypeBool
                    });
                }
                if (tagModel != null && !string.IsNullOrEmpty(tagModel.AutoWeightEntryActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.AutoWeightEntryActiveTag,
                        Value = conventionaldata.AweActive.ToString(CultureInfo.CurrentCulture),
                        TagItemType = UIInputType.TypeBool
                    });
                }
                if (tagModel != null && !string.IsNullOrEmpty(tagModel.HoldSignalTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.HoldSignalTag,
                        Value = conventionaldata.HoldSignal.ToString(CultureInfo.CurrentCulture),
                        TagItemType = UIInputType.TypeBool
                    });
                }

                if (tagsList.Count > 0 && conventionaldata.ControllerId > 0)
                {
                    try
                    {
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, conventionaldata.ControllerId);
                        List<string> tagCollectionList = new List<string>();

                        foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                {
                                    tagCollectionList.Add(tag.Address);
                                }
                            }
                        }
                        if (tagModel != null && tagCollectionList.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(tagModel.EndOfFormulaTag) &&
                                 tagCollectionList.Contains(tagModel.EndOfFormulaTag))
                            {
                                conventionaldata.IsValueDiffforEOF = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.WasherModeTag) &&
                                 tagCollectionList.Contains(tagModel.WasherModeTag))
                            {
                                conventionaldata.IsValueDiffforMode = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.HoldDelayTag) &&
                                 tagCollectionList.Contains(tagModel.HoldDelayTag))
                            {
                                conventionaldata.IsValueDiffforHoldDelay = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.WaterFlushTimeTag) &&
                                 tagCollectionList.Contains(tagModel.WaterFlushTimeTag))
                            {
                                conventionaldata.IsValueDiffforWaterFlush = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.RatioDosingActiveTag) &&
                                 tagCollectionList.Contains(tagModel.RatioDosingActiveTag))
                            {
                                conventionaldata.IsValueDiffforRatiodosingActive = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.AutoWeightEntryActiveTag) &&
                                tagCollectionList.Contains(tagModel.AutoWeightEntryActiveTag))
                            {
                                conventionaldata.IsValueDiffforAWEActive = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.HoldSignalTag) &&
                                tagCollectionList.Contains(tagModel.HoldSignalTag))
                            {
                                conventionaldata.IsValueDiffforHoldSignal = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                }
            }
            try
            {
                //Reading Data and Comparing data from PLC
                if (conventionaldata != null)
                {
                    if (conventionaldata.ControllerModelId == 11 && washerGroupTypeId == 1)
                    {
                        List<Tag> plcTagsList = new List<Tag>();
                        TagCollection plctagStatus = new TagCollection();
                        var offset = (conventionaldata.LfsWasher - 1) * 30;

                        plcTagsList = GenerateWasherGroupConventionalTags(conventionaldata, null);

                        if (plcTagsList.Count > 0 && conventionaldata.ControllerId > 0)
                        {
                            plctagStatus = plc.ValidateWasherConventionalPLCXLTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, conventionaldata.ControllerId, SourcePage.WasherPage);
                            List<string> tagCollectionList = new List<string>();

                            plcTagsList = GenerateWasherGroupConventionalTags(conventionaldata, null);

                            foreach (MitsubishiTag tag in plcTagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plctagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                    {
                                        tagCollectionList.Add(tag.Address);
                                    }
                                }
                            }

                            if (tagCollectionList.Count > 0)
                            {
                                if (tagCollectionList.Contains("R" + (300 + offset)))
                                {
                                    conventionaldata.IsValueDiffForMaxMachineLoad = true;
                                }

                                if (tagCollectionList.Contains("R" + (301 + offset)))
                                {
                                    conventionaldata.IsValueDiffForMinMachineLoad = true;
                                }

                                if (tagCollectionList.Contains("R" + (312 + offset)))
                                {
                                    conventionaldata.IsValueDiffForUseMe1OfGroup = true;
                                }

                                if (tagCollectionList.Contains("R" + (313 + offset)))
                                {
                                    conventionaldata.IsValueDiffForUsePumpOfGroup = true;
                                }

                                if (tagCollectionList.Contains("R" + (314 + offset)))
                                {
                                    conventionaldata.IsValueDiffForManifoldFlushTime = true;
                                }

                                if (tagCollectionList.Contains("R" + (317 + offset)))
                                {
                                    conventionaldata.IsValueDiffForWasherOnHoldSignalDelay = true;
                                }

                                if (tagCollectionList.Contains("R" + (323 + offset)))
                                {
                                    conventionaldata.IsValueDiffForUseMe2OfGroup = true;
                                }

                                if (tagCollectionList.Contains("L" + (150 + (conventionaldata.LfsWasher - 1))))
                                {
                                    conventionaldata.IsValueDiffForTemperatureAlarmYesNo = true;
                                }

                                if (tagCollectionList.Contains("R" + (318 + offset)))
                                {
                                    var ambiguousTags = new List<MitsubishiTag>();
                                    string conventionalLinesConnectedFieldPlCTagAddress = Convert.ToString("R" + (318 + offset));
                                    var conventionalLinesConnectedFieldPlCTagValues = plctagStatus.Tags.Where(_ => _.Address == conventionalLinesConnectedFieldPlCTagAddress && !string.IsNullOrWhiteSpace(_.Value)).FirstOrDefault();
                                    var conventionalLinesConnectedFieldTagValues = plcTagsList.Where(_ => _.Address == conventionalLinesConnectedFieldPlCTagAddress && !string.IsNullOrWhiteSpace(_.Value)).FirstOrDefault();

                                    var tagLinesValue = BinaryString(Convert.ToInt32(conventionalLinesConnectedFieldTagValues.Value));
                                    var plcTagLinesValue = BinaryString(Convert.ToInt32(conventionalLinesConnectedFieldPlCTagValues.Value));

                                    if (conventionaldata.ControllerTypeId == 12)
                                    {
                                        tagLinesValue = AddPreceedingZeros(tagLinesValue, 12);
                                        plcTagLinesValue = AddPreceedingZeros(plcTagLinesValue, 12);
                                    }
                                    else if (conventionaldata.ControllerTypeId == 13)
                                    {
                                        tagLinesValue = AddPreceedingZeros(tagLinesValue, 13);
                                        plcTagLinesValue = AddPreceedingZeros(plcTagLinesValue, 13);
                                    }

                                    RestructureWasherConventionalLinesConnectedFields(tagLinesValue, plcTagLinesValue, ambiguousTags);

                                    if (ambiguousTags != null)
                                    {
                                        if (ambiguousTags.Count > 0)
                                        {
                                            foreach (var item in ambiguousTags)
                                            {
                                                if (item.Address.Contains("L1")) { conventionaldata.IsValueDiffForL1 = true; }
                                                if (item.Address.Contains("L2")) { conventionaldata.IsValueDiffForL2 = true; }
                                                if (item.Address.Contains("L3")) { conventionaldata.IsValueDiffForL3 = true; }
                                                if (item.Address.Contains("L4")) { conventionaldata.IsValueDiffForL4 = true; }
                                                if (item.Address.Contains("L5")) { conventionaldata.IsValueDiffForL5 = true; }
                                                if (item.Address.Contains("L6")) { conventionaldata.IsValueDiffForL6 = true; }
                                                if (item.Address.Contains("L7")) { conventionaldata.IsValueDiffForL7 = true; }
                                                if (item.Address.Contains("L8")) { conventionaldata.IsValueDiffForL8 = true; }
                                                if (item.Address.Contains("L9")) { conventionaldata.IsValueDiffForL9 = true; }
                                                if (item.Address.Contains("L10")) { conventionaldata.IsValueDiffForL10 = true; }
                                                if (item.Address.Contains("L11")) { conventionaldata.IsValueDiffForL11 = true; }
                                                if (item.Address.Contains("L12")) { conventionaldata.IsValueDiffForL12 = true; }
                                            }
                                        }
                                    }
                                }

                                if (tagCollectionList.Contains("R" + (322 + offset)))
                                {
                                    string washerModeSignalTag = "R" + (322 + offset);
                                    decimal washerModePlCValuefromPLC = 0;
                                    int washerModeFromPLC = 0;
                                    int washerStopFromPLC = 0;
                                    var washerModePlCValue = plctagStatus.Tags.Where(_ => _.Address == washerModeSignalTag && !string.IsNullOrWhiteSpace(_.Value)).FirstOrDefault().Value;

                                    if (!string.IsNullOrWhiteSpace(washerModePlCValue))
                                    {
                                        washerModePlCValuefromPLC = Convert.ToDecimal(washerModePlCValue) / 10;
                                        string[] washerModePlCSplitValues = Convert.ToString(washerModePlCValuefromPLC).Split('.');
                                        if (washerModePlCSplitValues.Count() >= 1)
                                        {
                                            washerModeFromPLC = int.Parse(washerModePlCSplitValues[0]);
                                        }

                                        if (washerModePlCSplitValues.Count() >= 2)
                                        {
                                            washerStopFromPLC = int.Parse(washerModePlCSplitValues[1]);
                                        }

                                        conventionaldata.IsValueDiffForWasherModeId = washerModeFromPLC != conventionaldata.WasherModeId ? true : false;

                                        int washerStopExternalSignal = conventionaldata.WasherStopExternalSignal == true ? 2 : 0;
                                        int washerStopUseFinalExtracting = conventionaldata.WasherStopUseFinalExtracting == true ? 1 : 0;

                                        if (conventionaldata.WasherStopExternalSignal == true && washerStopFromPLC != washerStopExternalSignal)
                                        {
                                            conventionaldata.IsValueDiffForWasherStopExternalSignal = true;
                                        }
                                        else if (conventionaldata.WasherStopUseFinalExtracting == true && washerStopFromPLC != washerStopUseFinalExtracting)
                                        {
                                            conventionaldata.IsValueDiffForWasherStopUseFinalExtracting = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (conventionaldata.ControllerModelId == 8 && washerGroupTypeId == 1)
                    {
                        //Read plc values for EcontrolPlus conventional washer general and compare
                        List<Tag> uiTags = GetEcontolPlusConventionalGeneralTags(conventionaldata, null);
                        List<Tag> uiTagsClone = GetEcontolPlusConventionalGeneralTags(conventionaldata, null);
                        List<string> tagCollectionList = new List<string>();
                        TagCollection plcTags = new TagCollection { Tags = new List<Tag>() };
                        try
                        {
                            plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(uiTagsClone) }, conventionaldata.ControllerId);
                        }
                        catch (Exception ex)
                        {
                            ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        }

                        if (plcTags != null)
                        {
                            foreach (Tag uiTag in uiTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                foreach (Tag plcTag in plcTags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    if (uiTag.Address == plcTag.Address && uiTag.Value.ToUpper() != plcTag.Value.ToUpper())
                                    {
                                        tagCollectionList.Add(uiTag.Address);
                                        break;
                                    }
                                }
                            }
                            int offset = (conventionaldata.LfsWasher - 1) * 30;
                            if (tagCollectionList.Count > 0)
                            {
                                if (tagCollectionList.Contains(string.Format("D{0}", 516 + offset)))
                                {
                                    conventionaldata.IsValueDiffForMaxMachineLoad = true;
                                }
                                if (tagCollectionList.Contains(string.Format("D{0}", 517 + offset)))
                                {
                                    conventionaldata.IsValueDiffForMinMachineLoad = true;
                                }
                                if (tagCollectionList.Contains(string.Format("D{0}", 531 + offset)))
                                {
                                    conventionaldata.IsValueDiffforMode = true;
                                }
                                if (tagCollectionList.Contains(string.Format("D{0}", 532 + offset)))
                                {
                                    conventionaldata.IsValueDiffForWasherStopExternalSignal = true;
                                }
                                if (tagCollectionList.Contains(string.Format("D{0}", 533 + offset)))
                                {
                                    conventionaldata.IsValueDiffForWasherOnHoldSignalDelay = true;
                                }
                            }
                        }
                    }
                    else if (conventionaldata.ControllerModelId == 7)
                    {
                        const int ConventionalPLCIndex = 72;
                        int startIndex = (conventionaldata.LfsWasher - 1) * ConventionalPLCIndex;
                        var dataTags = GenerateTags(conventionaldata, startIndex);
                        var plcData = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                        var ambiguosTags = ValidateConventionalTags(conventionaldata, plc, dataTags);

                        if (conventionaldata.ControllerModelId == 7)
                        {
                            if (ambiguosTags != null)
                            {
                                if (ambiguosTags.Count > 0)
                                {
                                    foreach (var item in ambiguosTags)
                                    {
                                        if (item.Address.Contains("WasherMode")) { conventionaldata.IsValueDiffforMode = true; }
                                        if (item.Address.Contains("ProgramSelectionByTime")) { conventionaldata.IsValueDiffForProgramSelectionByTime = true; }
                                        if (item.Address.Contains("StopExternalSignal")) { conventionaldata.IsValueDiffForWasherStopExternalSignal = true; }
                                        if (item.Address.Contains("WeInTomMode")) { conventionaldata.IsValueDiffForWeInTomMode = true; }
                                        if (item.Address.Contains("OnHoldWESignalActive")) { conventionaldata.IsValueDiffForOnHoldWESignalActive = true; }
                                        if (item.Address.Contains("ValveOutputsUsedAsTomSignal")) { conventionaldata.IsValueDiffForValveOutputsUsedAsTomSignal = true; }
                                        if (item.Address.Contains("MaxMachineLoad")) { conventionaldata.IsValueDiffForMaxMachineLoad = true; }
                                        if (item.Address.Contains("MinMachineLoad")) { conventionaldata.IsValueDiffForMinMachineLoad = true; }
                                        if (item.Address.Contains("WasherOnHoldSignalDelay")) { conventionaldata.IsValueDiffForWasherOnHoldSignalDelay = true; }
                                        if (item.Address.Contains("FlowSwitchNumber")) { conventionaldata.IsValueDiffForFlowSwitchNumber = true; }
                                        if (item.Address.Contains("ManifoldFlushTime")) { conventionaldata.IsValueDiffForManifoldFlushTime = true; }
                                        if (item.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE")) { conventionaldata.IsValueDiffForSignalAcceptanceTime = true; }

                                        if (item.Address == "L1") { conventionaldata.IsValueDiffForL1 = true; }
                                        if (item.Address == "L2") { conventionaldata.IsValueDiffForL2 = true; }
                                        if (item.Address == "L3") { conventionaldata.IsValueDiffForL3 = true; }
                                        if (item.Address == "L4") { conventionaldata.IsValueDiffForL4 = true; }
                                        if (item.Address == "L5") { conventionaldata.IsValueDiffForL5 = true; }
                                        if (item.Address == "L6") { conventionaldata.IsValueDiffForL6 = true; }
                                        if (item.Address == "L7") { conventionaldata.IsValueDiffForL7 = true; }
                                        if (item.Address == "L8") { conventionaldata.IsValueDiffForL8 = true; }
                                        if (item.Address == "L9") { conventionaldata.IsValueDiffForL9 = true; }
                                        if (item.Address == "L10") { conventionaldata.IsValueDiffForL10 = true; }
                                        if (item.Address == "L11") { conventionaldata.IsValueDiffForL11 = true; }
                                        if (item.Address == "L12") { conventionaldata.IsValueDiffForL12 = true; }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Need to handle Exception 
            }
            return conventionaldata;
        }

        /// <summary>
        /// Gets the maximum washer number
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <returns>
        /// returns the integer.
        /// </returns>
        [HttpGet]
        public int GetMaxPlantWasherNumber(string ecoLabAccountNumber)
        {
            int MaxWasherNumber = conventionalGeneralServices.GetMaxPlantWasherNumber(ecoLabAccountNumber);
            return MaxWasherNumber;
        }

        /// <summary>
        /// Validates the conventional tags.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="plc">The Conventional PLC tags.</param>
        /// <param name="tags">The Conventional tags.</param>
        /// <returns>Return list of my control tags</returns>
        private List<OpcTag> ValidateConventionalTags(ConventionalGeneralModel conventionalData, PlcTagController plc, List<Tag> tags)
        {
            const int ConventionalPLCIndex = 72;
            int startIndex = (conventionalData.LfsWasher - 1) * ConventionalPLCIndex;
            var generatedTags = GenerateTags(conventionalData, startIndex);
            TagCollection tagStatusTunnel = plc.ValidateConventionalTags(new TagCollection { Tags = generatedTags }, conventionalData.ControllerId, 1, conventionalData.LfsWasher);

            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address)
                    {
                        switch (tag.Address)
                        {
                            case "MaxMachineLoad":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "MinMachineLoad":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "WasherOnHoldSignalDelay":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "ManifoldFlushTime":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "WasherOptions":
                                var tagValue = BinaryString(Convert.ToInt32(tag.Value));
                                var plcTagValue = BinaryString(Convert.ToInt32(plcTag.Value));
                                tagValue = AddPreceedingZeros(tagValue, 1);
                                plcTagValue = AddPreceedingZeros(plcTagValue, 1);
                                RestructureBooleanFieldsandValidate(tagValue, plcTagValue, message, ambiguousTags);
                                break;
                            case "ConventionalLinesConnected":
                                var tagLinesValue = BinaryString(Convert.ToInt32(tag.Value));
                                var plcTagLinesValue = BinaryString(Convert.ToInt32(plcTag.Value));
                                tagLinesValue = AddPreceedingZeros(tagLinesValue, 2);
                                plcTagLinesValue = AddPreceedingZeros(plcTagLinesValue, 2);
                                RestructureConventionalLinesConnectedFields(tagLinesValue, plcTagLinesValue, message, ambiguousTags);
                                break;
                            case "FlowSwitchNumber":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "SignalAcceptTimeWE":
                                if (tag.Value.Trim() != plcTag.Value.Trim())
                                {
                                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            return ambiguousTags;
        }

        /// <summary>
        /// Adds the preceeding zeros.
        /// </summary>
        /// <param name="tag">Tag to add preceeding zeros.</param>
        /// <param name="mode">The mode values of Tag preceeding zeros.</param>
        /// <returns></returns>
        private string AddPreceedingZeros(string tag, int mode)
        {
            string computedString = string.Empty;
            string tempString = string.Empty;
            if (tag == "0")
            {
                for (int i = 0; i < (mode == 1 ? 16 : 12) - tag.Length; i++)
                {
                    tempString += "0";
                }
                computedString = tempString + tag;
            }
            else if (mode == 1 || mode == 0)
            {
                for (int i = 0; i < 16 - tag.Length; i++)
                {
                    tempString += "0";
                }
                computedString = tempString + tag;
            }
            else
            {
                for (int i = 0; i < 12 - tag.Length; i++)
                {
                    tempString += "0";
                }
                computedString = tempString + tag;
            }
            return computedString;
        }

        /// <summary>
        /// Binaries the string.
        /// </summary>
        /// <param name="decimalNumber">The decimal number.</param>
        /// <returns>Return Binary String</returns>
        private string BinaryString(int decimalNumber)
        {
            int remainder;
            int x = decimalNumber;
            string result = string.Empty;
            while (decimalNumber > 0)
            {
                remainder = decimalNumber % 2;
                decimalNumber /= 2;
                result = remainder.ToString() + result;
            }
            return x == 0 ? "0" : result;
        }

        /// <summary>
        /// Restructures the conventional lines connected fields.
        /// </summary>
        /// <param name="conventionalOptionsUI">The conventional options UI.</param>
        /// <param name="conventionalOptionsPLC">The conventional options PLC.</param>
        /// <param name="message">The string builder message.</param>
        /// <param name="ambiguousTag">The ambiguous tag.</param>
        private void RestructureConventionalLinesConnectedFields(string conventionalOptionsUI, string conventionalOptionsPLC, StringBuilder message, List<OpcTag> ambiguousTag)
        {
            if (conventionalOptionsUI.Length == 12 && conventionalOptionsPLC.Length == 12)
            {
                // L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12
                // 0   1   2  3   4  5  6   7   8   9   10   11
                var dataFromUI = Reverse(conventionalOptionsUI).ToCharArray();
                var dataFromPLC = Reverse(conventionalOptionsPLC).ToCharArray();

                for (int i = 0; i < dataFromUI.Length; i++)
                {
                    if (dataFromUI[i] != dataFromPLC[i])
                    {
                        message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", " L" + (i + 1).ToString(), dataFromUI[i].ToString(), dataFromPLC[i].ToString()));
                        ambiguousTag.Add(new OpcTag { Address = string.Format("L{0}", i + 1), Value = dataFromUI[i].ToString() });
                    }
                }
            }
        }

        /// <summary>
        /// Restructures the washer conventional lines connected fields.
        /// </summary>
        /// <param name="conventionalOptionsUI">The conventional options UI.</param>
        /// <param name="conventionalOptionsPLC">The conventional options PLC.</param>
        /// <param name="ambiguousTag">The ambiguous tag.</param>
        private void RestructureWasherConventionalLinesConnectedFields(string conventionalOptionsUI, string conventionalOptionsPLC, List<MitsubishiTag> ambiguousTag)
        {
            if (conventionalOptionsUI.Length == 12 && conventionalOptionsPLC.Length == 12)
            {
                // L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12
                // 0   1   2  3   4  5  6   7   8   9   10   11
                var dataFromUI = Reverse(conventionalOptionsUI).ToCharArray();
                var dataFromPLC = Reverse(conventionalOptionsPLC).ToCharArray();

                for (int i = 0; i < dataFromUI.Length; i++)
                {
                    if (dataFromUI[i] != dataFromPLC[i])
                    {
                        ambiguousTag.Add(new MitsubishiTag { Address = "L" + (i + 1).ToString(), Value = dataFromUI[i].ToString() });
                    }
                }
            }
        }

        /// <summary>
        /// Restructures the boolean fieldsand validate.
        /// </summary>
        /// <param name="conventionalOptionsUI">The conventional options UI.</param>
        /// <param name="conventionalOptionsPLC">The conventional options PLC.</param>
        /// <param name="message">The string builder message.</param>
        /// <param name="ambiguousTag">The ambiguous tag.</param>
        private void RestructureBooleanFieldsandValidate(string conventionalOptionsUI, string conventionalOptionsPLC, StringBuilder message, List<OpcTag> ambiguousTag)
        {
            if (conventionalOptionsUI.Length == 16 && conventionalOptionsPLC.Length == 16)
            {
                ////////// FROM UI ////////
                var washerModel = Convert.ToInt32(conventionalOptionsUI.Substring(conventionalOptionsUI.Length - 4), 2);
                washerModel = washerModel == 1 ? 6 :
                                         washerModel == 2 ? 7 :
                                         washerModel == 3 ? 8 :
                                         washerModel == 4 ? 9 :
                                         washerModel == 5 ? 10 :
                                         washerModel == 6 ? 11 : 0;

                var programSelectionByTime = conventionalOptionsUI[11].ToString() == "1" ? true : false;
                var washerInTomMode = conventionalOptionsUI[10].ToString() == "1" ? true : false;
                var onHoldWESignalActive = conventionalOptionsUI[9].ToString() == "1" ? true : false;
                var washerStopExternalSignal = conventionalOptionsUI[8].ToString() == "1" ? true : false;
                var valveOutputsUsedAsTomSignal = conventionalOptionsUI[7].ToString() == "1" ? true : false;

                ///////////  FROM PLC ///////////
                var washerModel_PLC = Convert.ToInt32(conventionalOptionsPLC.Substring(conventionalOptionsPLC.Length - 4), 2);
                washerModel_PLC = washerModel_PLC == 1 ? 6 :
                                         washerModel_PLC == 2 ? 7 :
                                         washerModel_PLC == 3 ? 8 :
                                         washerModel_PLC == 4 ? 9 :
                                         washerModel_PLC == 5 ? 10 :
                                         washerModel_PLC == 6 ? 11 : 0;

                var programSelectionByTime_PLC = conventionalOptionsPLC[11].ToString() == "1" ? true : false;
                var washerInTomMode_PLC = conventionalOptionsPLC[10].ToString() == "1" ? true : false;
                var onHoldWESignalActive_PLC = conventionalOptionsPLC[9].ToString() == "1" ? true : false;
                var washerStopExternalSignal_PLC = conventionalOptionsPLC[8].ToString() == "1" ? true : false;
                var valveOutputsUsedAsTomSignal_PLC = conventionalOptionsPLC[7].ToString() == "1" ? true : false;

                /////// COMPARISIONS //////////
                if (washerModel != washerModel_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, washerModel, washerModel_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WasherMode", Value = Convert.ToString(washerModel) });
                }

                if (programSelectionByTime != programSelectionByTime_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, programSelectionByTime, programSelectionByTime_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "ProgramSelectionByTime", Value = Convert.ToString(programSelectionByTime) });
                }

                if (washerInTomMode != washerInTomMode_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, washerInTomMode, washerInTomMode_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WeInTomMode", Value = Convert.ToString(washerInTomMode_PLC) });
                }
                if (onHoldWESignalActive != onHoldWESignalActive_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, onHoldWESignalActive, onHoldWESignalActive_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "OnHoldWESignalActive", Value = Convert.ToString(onHoldWESignalActive) });
                }
                if (washerStopExternalSignal != washerStopExternalSignal_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, washerStopExternalSignal, washerStopExternalSignal_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "StopExternalSignal", Value = Convert.ToString(washerStopExternalSignal) });
                }
                if (valveOutputsUsedAsTomSignal != valveOutputsUsedAsTomSignal_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, valveOutputsUsedAsTomSignal, valveOutputsUsedAsTomSignal_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "ValveOutputsUsedAsTomSignal", Value = Convert.ToString(valveOutputsUsedAsTomSignal) });
                }
            }
        }

        /// <summary>
        /// Writes to PLC.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="prevconventionalData">The prevconventional data.</param>
        private void WriteToPlc(ConventionalGeneralModel conventionalData, ConventionalGeneralModel prevconventionalData)
        {
            //Controller is of type EcontrolPlus & PLCXL
            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            if ((conventionalData.ControllerModelId == 11 || conventionalData.ControllerModelId == 8) && washerGroupTypeId == 1)
            {
                List<Tag> tagsList = new List<Tag>();
                if (conventionalData.ControllerModelId == 11)
                {
                    tagsList = GenerateWasherGroupConventionalTags(conventionalData, prevconventionalData);
                }
                else
                {
                    tagsList = GetEcontolPlusConventionalGeneralTags(conventionalData, prevconventionalData);
                }
                
                if (tagsList != null && tagsList.Count > 0)
                {
                    MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                    plc.WriteTags(mitsubishiTag, conventionalData.ControllerId, washerGroupTypeId, SourcePage.WasherPage);
                }
            }
            else if (conventionalData.ControllerModelId == 7)
            {
                WriteGeneralTabDataToPLC(conventionalData);
            }
        }

        /// <summary>
        /// Gets the econtol plus conventional general tags.
        /// </summary>
        /// <param name="conventionalData">The conventional data.</param>
        /// <param name="prevconventionalData">The prevconventional data.</param>
        /// <returns>Econtol Plus Conventional Tags</returns>
        private List<Tag> GetEcontolPlusConventionalGeneralTags(ConventionalGeneralModel conventionalData, ConventionalGeneralModel prevconventionalData)
        {
            //Get Address offset based on LFS washer number
            List<Tag> tagsList = new List<Tag>();

            if (conventionalData != null)
            {
                int offset = (conventionalData.LfsWasher - 1) * 30;
                tagsList.Add(new MitsubishiTag
                {
                    Address = string.Format("D{0}", 516 + offset),
                    Value = conventionalData.MaxMachineLoad.ToString(),
                    TagItemType = UIInputType.TypeInt
                });
                tagsList.Add(new MitsubishiTag
                {
                    Address = string.Format("D{0}", 517 + offset),
                    Value = conventionalData.MinMachineLoad.ToString(),
                    TagItemType = UIInputType.TypeInt
                });
                //Washer operational (Start) Mode 
                string washerMode = conventionalGeneralServices.GetWasherModelNumber(conventionalData.EcolabAccountNumber, conventionalData.ControllerId, conventionalData.WasherModeId);
                washerMode = washerMode == string.Empty ? "0" : washerMode;
                tagsList.Add(new MitsubishiTag
                {
                    Address = string.Format("D{0}", 531 + offset),
                    Value = washerMode,
                    TagItemType = UIInputType.TypeInt
                });
                tagsList.Add(new MitsubishiTag
                {
                    Address = string.Format("D{0}", 532 + offset),
                    Value = conventionalData.WasherStopExternalSignal.ToString() == "True" ? "1" : "0",
                    TagItemType = UIInputType.TypeBool
                });
                //Multiply WasherOnHoldSignalDelay value with plc factor 10 before writing to plc
                tagsList.Add(new MitsubishiTag
                {
                    Address = string.Format("D{0}", 533 + offset),
                    Value = Convert.ToString(conventionalData.WasherOnHoldSignalDelay),
                    TagItemType = UIInputType.TypeBool
                });
            }

            if (prevconventionalData != null && conventionalData != null)
            {
                if (conventionalData.LfsWasher != prevconventionalData.LfsWasher)
                {
                    var offset = (prevconventionalData.LfsWasher - 1) * 30;

                    //ConventionalGeneral previous data reset
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 516 + offset),
                        Value = "0"
                    });
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 517 + offset),
                        Value = "0"
                    });
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 531 + offset),
                        Value = "0"
                    });
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 532 + offset),
                        Value = "0"
                    });
                    //Multiply WasherOnHoldSignalDelay value with plc factor 10 before writing to plc
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 533 + offset),
                        Value = "0"
                    });

                    //Conventional washer flush time previous data reset
                    for (int i = 1; i <= 8; i++)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", 534 + (i - 1) + offset),
                            Value = "0"
                        });
                    }
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 529 + offset),
                        Value = "0"
                    });
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 542 + offset),
                        Value = "0"
                    });

                    //Conventional washer product deviation previous data reset
                    //Tag for ME1
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 518 + offset),
                        Value = "0"
                    });
                    //Tag for ME2
                    tagsList.Add(new MitsubishiTag
                    {
                        Address = string.Format("D{0}", 527 + offset),
                        Value = "0"
                    });
                    //Tags for pumps
                    for (int incrementAddress = 0; incrementAddress < 8; incrementAddress++)
                    {
                        tagsList.Add(new MitsubishiTag
                        {
                            Address = string.Format("D{0}", 519 + incrementAddress + offset),
                            Value = "0"
                        });
                    }
                }
            }
            return tagsList;
        }
    }
}