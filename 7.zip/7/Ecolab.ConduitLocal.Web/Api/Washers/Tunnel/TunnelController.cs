﻿// -----------------------------------------------------------------------
// <copyright file="TunnelController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Tunnel Controller </summary>
// -----------------------------------------------------------------------

using System.Globalization;
using Elmah;

namespace Ecolab.ConduitLocal.Web.Api.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Reflection;
    using System.Security.Principal;
    using System.Text;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers.Tunnel;
    using Models.Washers.Conventional;
    using Models.Washers.Tunnel;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers.Tunnel;
    using Services.Plc;
    using EntityConverter = Mapper.EntityConverter;
    using WasherModelSizeModel = Models.Washers.Tunnel.WasherModelSizeModel;
    using Utilities;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     Tunnel Controller
    /// </summary>
    [Authorize]
    public class TunnelController : BaseApiController
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        private readonly ITunnelCompartmentServices tunnelCompartmentServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
		///     The _tunnel Connection services
		/// </summary>
		private readonly ITunnelConnectionServices tunnelConnectionServices;

        /// <summary>
        ///     The _washer group formula service
        /// </summary>
        private readonly IWasherGroupFormulaService washerGroupFormulaService;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
		///     The _washer Group Service
		/// </summary>
		private readonly ITunnelAnalogueDosingControlServices analogueDosingControlServices;

        /// <summary>
        /// PLC XL 1T 5W Max Machine Load Index
        /// </summary>
        private const int PLCXL1T5WMAXMACHINELOAD = 270;

        /// <summary>
        /// PLC XL 1T 5W Min Machine Load Index
        /// </summary>
        private const int PLCXL1T5WMINMACHINELOAD = 271;

        /// <summary>
        /// PLC XL 1T 5W USE ME 1 OF GROUP Index
        /// </summary>
        private const int PLCXL1T5WUSEME1OFGROUP = 272;

        /// <summary>
        /// PLC XL 1T 5W USE ME 2 OF GROUP Index
        /// </summary>
        private const int PLCXL1T5WUSEME2OFGROUP = 273;

        /// <summary>
        /// PLC XL 1T 5W AUTO RINSE DESAMIX AFTER Index
        /// </summary>
        private const int PLCXL1T5WAUTORINSEDESAMIXAFTER = 281;

        /// <summary>
        /// PLC XL 1T 5W AUTO RINSE DESAMIX 1 FOR Index
        /// </summary>
        private const int PLCXL1T5WAUTORINSEDESAMIX1FOR = 282;

        /// <summary>
        /// PLC XL 1T 5W AUTO RINSE DESAMIX 2 FOR
        /// </summary>
        private const int PLCXL1T5WAUTORINSEDESAMIX2FOR = 283;

        /// <summary>
        /// PLC XL 1T 5W Program Number Index
        /// </summary>
        private const int PLCXL1T5WPROGRAMNUMBER = 2010;

        /// <summary>
        /// PLC XL 1T 5W Weight Correction Fcc Index
        /// </summary>
        private const int PLCXL1T5WWEIGHTCORRECTIONFCC = 816;

        /// <summary>
        /// PLC XL 1T 5W Temperature Alarm Probe 1 Index
        /// </summary>
        private const int PLCXL1T5WTEMPERATUREALARMPROBE1 = 150;

        /// <summary>
        /// PLC XL 1T 5W Temperature Alarm Probe 2 Index
        /// </summary>
        private const int PLCXL1T5WTEMPERATUREALARMPROBE2 = 151;

        /// <summary>
        /// PLC XL 1T 5W Temperature Alarm Probe 3 Index
        /// </summary>
        private const int PLCXL1T5WTEMPERATUREALARMPROBE3 = 152;

        /// <summary>
        /// PLC XL 1T 5W Date And Time When Batch Ejects Index
        /// </summary>
        private const int PLCXL1T5WDATEANDTIMEWHENBATCHEJECTS = 762;

        /// <summary>
        /// PLC XL 1T 5W No of Compartments Index
        /// </summary>
        private const int PLCXL1T5WNOOFCOMPARTMENTS = 200;

        /// <summary>
        /// PLC XL 1T 5W Number Of Compartments Conveyor Belt Index
        /// </summary>
        private const int PLCXL1T5WNUMBEROFCOMPARTMENTSCONVEYORBELT = 201;

        /// <summary>
        /// PLC XL 1T 5W Washer Mode Index
        /// </summary>
        private const int PLCXL1T5WWASHERMODE = 244;

        /// <summary>
        /// PLC XL 1T 5W Tun In Tom Mode Index
        /// </summary>
        private const int PLCXL1T5WTUNINTOMMODE = 245;

        /// <summary>
        /// PLC XL 2T MAX MACHINE LOAD Index
        /// </summary>
        private const int PLCXL2TMAXMACHINELOAD = 300;

        /// <summary>
        /// PLC XL 2T MIN MACHINE LOAD Index
        /// </summary>
        private const int PLCXL2TMINMACHINELOAD = 301;

        /// <summary>
        /// PLC XL 2T USE ME 1 OF GROUP Index
        /// </summary>
        private const int PLCXL2TUSEME1OFGROUP = 302;

        /// <summary>
        /// PLC XL 2T USE ME 2 OF GROUP Index
        /// </summary>
        private const int PLCXL2TUSEME2OFGROUP = 303;

        /// <summary>
        /// PLC XL 2T AUTO RINSE DESAMIX AFTER Index
        /// </summary>
        private const int PLCXL2TAUTORINSEDESAMIXAFTER = 311;

        /// <summary>
        /// PLC XL 2T AUTO RINSE DESAMIX 1 FOR Index
        /// </summary>
        private const int PLCXL2TAUTORINSEDESAMIX1FOR = 312;

        /// <summary>
        /// PLC XL 2T AUTO RINSE DESAMIX 2 FOR
        /// </summary>
        private const int PLCXL2TAUTORINSEDESAMIX2FOR = 313;

        /// <summary>
        /// PLC XL 2T Program Number Index
        /// </summary>
        private const int PLCXL2TPROGRAMNUMBER = 1718;

        /// <summary>
        /// PLC XL 2T Weight Correction Fcc Index
        /// </summary>
        private const int PLCXL2TWEIGHTCORRECTIONFCC = 816;

        /// <summary>
        /// PLC XL 2T Temperature Alarm Probe 1 Index
        /// </summary>
        private const int PLCXL2TTEMPERATUREALARMPROBE1 = 150;

        /// <summary>
        /// PLC XL 2T Temperature Alarm Probe 2 Index
        /// </summary>
        private const int PLCXL2TTEMPERATUREALARMPROBE2 = 151;

        /// <summary>
        /// PLC XL 2T Temperature Alarm Probe 3 Index
        /// </summary>
        private const int PLCXL2TTEMPERATUREALARMPROBE3 = 152;

        /// <summary>
        /// PLC XL 2T Date And Time When Batch Ejects Index
        /// </summary>
        private const int PLCXL2TDATEANDTIMEWHENBATCHEJECTS = 763;

        /// <summary>
        /// PLC XL 2T No of Compartments Index
        /// </summary>
        private const int PLCXL2TNOOFCOMPARTMENTS = 200;

        /// <summary>
        /// PLC XL 2T Number Of Compartments Conveyor Belt Index
        /// </summary>
        private const int PLCXL2TNUMBEROFCOMPARTMENTSCONVEYORBELT = 201;

        /// <summary>
        /// PLC XL 2T Washer Mode Index
        /// </summary>
        private const int PLCXL2TWASHERMODE = 244;

        /// <summary>
        /// PLC XL 2T Tun In Tom Mode Index
        /// </summary>
        private const int PLCXL2TTUNINTOMMODE = 245;

        /// <summary>
        /// PLC XL 1T5W and 2T Multiplier for Pre Pause Time
        /// </summary>
        private const int PREPAUSETIMEMULTIPLIER = 10;

        /// <summary>
        /// PLC XL 1T5W and 2T Multiplier for Pause Time
        /// </summary>
        private const int PAUSETIMEMULTIPLIER = 10;

        /// <summary>
        /// PLC XL 1T5W and 2T Multiplier for Maximum Time
        /// </summary>
        private const int MAXTIMEMULTIPLIER = 10;

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        public static int AnalogueControllerId { get; set; }

        private static string tunnelNumber = string.Empty;

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
        /// <param name="tunnelCompartmentServices">Tunnel Compartment Services</param>
        /// <param name="washerGroupService">Washer Group Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public TunnelController(ITunnelGeneralServices tunnelGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupFormulaService washerGroupFormulaService, ITunnelCompartmentServices tunnelCompartmentServices, IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService, ITunnelConnectionServices tunnelConnectionServices)
            : base(userService, plantService)
        {
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.tunnelCompartmentServices = tunnelCompartmentServices;
            this.washerGroupService = washerGroupService;
            this.tunnelConnectionServices = tunnelConnectionServices;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelController" /> class.
        /// </summary>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="washerGroupFormulaService">Washer Group Formula Service</param>
        /// <param name="tunnelCompartmentServices">Tunnel Compartment Services</param>
        /// <param name="washerGroupService">Washer Group Service</param>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="tunnelConnectionServices">The tunnel Connection Services</param>
        /// <param name="analogueDosingControlService">The analogue Dosing Control Service</param>
        public TunnelController(ITunnelGeneralServices tunnelGeneralServices, IControllerSetupService controllerSetupService, IWasherGroupFormulaService washerGroupFormulaService, ITunnelCompartmentServices tunnelCompartmentServices, IWasherGroupService washerGroupService, IPlcService plcService, IUserService userService, IPlantService plantService, ITunnelConnectionServices tunnelConnectionServices, ITunnelAnalogueDosingControlServices analogueDosingControlService)
            : base(userService, plantService)
        {
            this.tunnelGeneralServices = tunnelGeneralServices;
            this.controllerSetupService = controllerSetupService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.tunnelCompartmentServices = tunnelCompartmentServices;
            this.washerGroupService = washerGroupService;
            this.plcService = plcService;
            this.tunnelConnectionServices = tunnelConnectionServices;
            this.analogueDosingControlServices = analogueDosingControlService;
        }

        /// <summary>
        ///     Gets the drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="washerType">Type of the washer.</param>
        /// <param name="washerGroupId">The washer Group Id</param>
        /// <returns>
        ///     TunnelGeneralDropdownsModel.
        /// </returns>
        [HttpGet]
        public TunnelGeneralDropdownsModel GetDropDownData(string ecoLabAccountNumber, int regionId, string washerType, int washerGroupId)
        {
            var tunnelGeneralDropdownsModel = new TunnelGeneralDropdownsModel();
            IEnumerable<WashersList> objList = this.tunnelGeneralServices.GetWashersList(washerType, regionId);
            IEnumerable<WashersListModel> washerModelList = Mapper.Map<IEnumerable<WashersList>, List<WashersListModel>>(objList);
            tunnelGeneralDropdownsModel.WashersModelList = washerModelList;

            IEnumerable<PressExtractor> objPressExtractorList = this.tunnelGeneralServices.GetPressExtractorList(this.EcolabAccountNumber);
            IEnumerable<PressExtractorModel> pressExtractorList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objPressExtractorList);
            tunnelGeneralDropdownsModel.PressExtractorList = pressExtractorList;

            IEnumerable<PressExtractor> objTransferTypeList = this.tunnelGeneralServices.GetTransferTypeList(this.EcolabAccountNumber);
            IEnumerable<PressExtractorModel> transferTypeList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objTransferTypeList);
            tunnelGeneralDropdownsModel.TransferTypeList = transferTypeList;
            tunnelGeneralDropdownsModel.ControllerList = this.tunnelGeneralServices.GetControllerDetailsforTunnel(ecoLabAccountNumber, washerGroupId).OrderBy(_ => _.ControllerNumber);

            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

            tunnelGeneralDropdownsModel.WasherGroupList = washerGroups;

            return tunnelGeneralDropdownsModel;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="washerModelId">The washer model identifier.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.WasherModelSizeModel.</returns>
        public IEnumerable<WasherModelSizeModel> GetSizeList(int washerModelId)
        {
            IEnumerable<WasherModelSize> objList = this.tunnelGeneralServices.GetWashersModelSizeList(washerModelId);
            IEnumerable<WasherModelSizeModel> washerModelSizeList = Mapper.Map<IEnumerable<WasherModelSize>, IEnumerable<WasherModelSizeModel>>(objList);
            return washerModelSizeList;
        }

        /// <summary>
        ///     Saves the tunnel data.
        /// </summary>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage SaveTunnelData(TunnelGeneralModel tunnelData)
        {
            try
            {
                List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
                int isNumeric = 0;
                string response = string.Empty;
                TunnelNumber = tunnelData.LfsWasher;
                TunnelGeneral objTunnelData = Mapper.Map<TunnelGeneralModel, TunnelGeneral>(tunnelData);
                objTunnelData.MyServiceWashersGuid = Guid.NewGuid();
                DateTime lastModifiedTimeStamp;
                string result = this.tunnelGeneralServices.SaveTunnelData(objTunnelData, this.UserId, out lastModifiedTimeStamp);
                tunnelNumber = result;
                if (int.TryParse(result, out isNumeric))
                {
                    objTunnelData.Id = isNumeric;
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    TunnelContainer container = new TunnelContainer { TunnelGeneral = this.tunnelGeneralServices.GetTunnelData(objTunnelData.Id, objTunnelData.WasherGroupId, objTunnelData.EcolabAccountNumber) };
                    container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(container, UserId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdAddTunnelGeneral, objTunnelData.EcolabAccountNumber);

                    response = tunnelGeneralServices.UpdateTagsInDB(objTunnelData, UserId, tunnelData.Role, EcolabAccountNumber, out lastModifiedTimeStamp);
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                    container.TunnelGeneral.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(objTunnelData.Id, objTunnelData.EcolabAccountNumber);
                    Push.PushToQueue(container, UserId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelGeneral, objTunnelData.EcolabAccountNumber);

                }
                var plc = new PlcTagController(plcService, UserService, PlantService);
                string returnStatus = string.Empty;
                try
                {
                    //------------------------------------------------------------
                    if (tunnelData.ControllerModelId == 8 || tunnelData.ControllerModelId == 11)
                    {
                        WriteToPlc(tunnelData, null);
                    }
                    else
                    {
                        if (tunnelData.ControllerModelId == 7)
                        {
                            List<Tag> tg = GenerateTags(tunnelData);
                            plc.WriteTunnelTags(new TagCollection { Tags = tg }, tunnelData.ControllerId, 2, tunnelData.LfsWasher);
                        }
                        if (tunnelData.Role >= 7 && tunnelData.PlcTunnelTagModelTags != null && tunnelData.PlcTunnelTagModelTags.Any())
                        {
                            TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tunnelData.PlcTunnelTagModelTags) }, tunnelData.ControllerId);
                            foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                            {
                                if (!string.IsNullOrEmpty(status.Address))
                                {
                                    int last = tagStatus.Tags.LastIndexOf(status);
                                    if (last != 14 && !string.IsNullOrEmpty(status.Address))
                                    {
                                        returnStatus += status.Address + ",";
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        Logger.ErrorFormat("SaveTunnelData : PLC Connection failed", ex.Message);
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", tunnelNumber));
                    }
                    else
                    {
                        Logger.ErrorFormat("SaveTunnelData : PLC Write failed", ex.Message);
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", tunnelNumber));
                    }
                }
                objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                {
                    ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                    ParentEntityId = objTunnelData.WasherGroupId,
                    Entity = Convert.ToInt32(PlcDiscrepancyEntity.Washer),
                    EntityId = objTunnelData.Id,
                    IsCentral = false,
                    ControllerId = objTunnelData.ControllerId,
                    UserId = this.UserId,
                    LastModifiedUserId = this.UserId
                });
                if (!string.IsNullOrEmpty(returnStatus))
                {
                    return Request.CreateResponse(HttpStatusCode.BadRequest, returnStatus + "@" + tunnelNumber);
                }
                else
                {
                    if (int.TryParse(response, out isNumeric))
                    {
                        if (tunnelData.Role >= 7 && tunnelData.PlcTunnelTagModelTags != null && tunnelData.PlcTunnelTagModelTags.Any())
                        {
                            try
                            {
                                plc.WriteTags(new TagCollection { Tags = new List<Tag>(tunnelData.PlcTunnelTagModelTags) }, tunnelData.ControllerId);
                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.Contains("Timeout has elapsed") ||
                                    ex.Message.Contains("Port is disabled") ||
                                    ex.Message.Contains("Target machine could not be found") ||
                                    ex.Message.Contains("ADS could not be initialized") ||
                                    ex.Message.Contains("Open Failed") ||
                                    ex.Message.Contains("Retrieving the COM class factory"))
                                {
                                    Logger.ErrorFormat("SaveTunnelData : PLC Connection failed", ex.Message);
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", tunnelNumber));
                                }
                                else
                                {
                                    Logger.ErrorFormat("SaveTunnelData : PLC Write failed", ex.Message);
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", tunnelNumber));
                                }
                            }
                        }
                        return Request.CreateResponse(HttpStatusCode.OK, new { Result = result, plcDiscrepancyModel = objPLCDiscrepancyModels });
                    }

                    if (isNumeric == 0)
                    {
                        return Request.CreateResponse(HttpStatusCode.Ambiguous, new { message = response });
                    }
                }

                return Request.CreateResponse(HttpStatusCode.OK, new { Result = result, plcDiscrepancyModel = objPLCDiscrepancyModels });
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5) + "@" + String.Empty);
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message + "@" + tunnelNumber);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5) + "@" + tunnelNumber);
            }
        }

        /// <summary>
        ///     Saves the tunnel compartment data.
        /// </summary>
        /// <param name="tunnelCompartmentData">The tunnel compartment data.</param>
        /// <returns>Http Response Message</returns>
        [HttpPost]
        public HttpResponseMessage SaveTunnelCompartmentData(TunnelCompartmentModel tunnelCompartmentData)
        {
            try
            {
                IPrincipal user = HttpContext.Current.User;
                int userId = ((CustomPrincipal)user).UserId;
                TunnelCompartment objTunnelData = Mapper.Map<TunnelCompartmentModel, TunnelCompartment>(tunnelCompartmentData);

                if (user != null)
                {
                    DateTime lastModifiedTimeStamp;
                    int result = this.tunnelCompartmentServices.SavetunnelCompartmentData(objTunnelData, userId, out lastModifiedTimeStamp);
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    objTunnelData.TunnelCompartmentId = result;
                }
                TunnelContainer container = new TunnelContainer { TunnelCompartments = new List<TunnelCompartment>(), TunnelGeneral = this.tunnelGeneralServices.GetTunnelData(objTunnelData.Id, objTunnelData.WasherGroupId, objTunnelData.EcolabAccountNumber) };
                container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                container.TunnelGeneral.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(objTunnelData.Id, objTunnelData.EcolabAccountNumber);
                TunnelCompartment compartment = tunnelCompartmentServices.GetCompartmentData(objTunnelData.Id, objTunnelData.WasherGroupId, objTunnelData.EcolabAccountNumber, Convert.ToByte(objTunnelData.CompartmentNumber), true);
                compartment.LastModifiedTimeStamp = DateTime.SpecifyKind(compartment.LastModifiedTimeStamp, DateTimeKind.Utc);
                container.TunnelCompartments.Add(compartment);

                Push.PushToQueue(container, userId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdSaveTunnnelCompartment, objTunnelData.EcolabAccountNumber);

                return Request.CreateResponse(HttpStatusCode.OK, tunnelCompartmentData);
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5));
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        ///     Updates the tunnel data.
        /// </summary>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <returns>HttpResponseMessage.</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage UpdateTunnelData(TunnelGeneralModel tunnelData)
        {
            try
            {
                List<Models.Common.PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<Models.Common.PLCDiscrepancyModel>();
                string result = string.Empty;
                int isNumeric;
                int isUpdateFine = 0;
                IPrincipal user = HttpContext.Current.User;
                int userId = ((CustomPrincipal)user).UserId;

                // To reset the existing washer while update. Need to implement refer PumpsController.cs/UpdatePump.
                TunnelGeneralModel prevTunnelGeneralModelData = null;
                TunnelGeneral prevTunnelGeneralData = null;

                if (tunnelData != null && tunnelData.ControllerModelId == 11)
                {
                    prevTunnelGeneralData = this.tunnelGeneralServices.GetTunnelData(tunnelData.Id, tunnelData.WasherGroupId, tunnelData.EcolabAccountNumber);
                    prevTunnelGeneralModelData = Mapper.Map<TunnelGeneral, TunnelGeneralModel>(prevTunnelGeneralData);
                }

                TunnelGeneral objTunnelData = Mapper.Map<TunnelGeneralModel, TunnelGeneral>(tunnelData);

                if (user != null)
                {
                    DateTime lastModifiedTimeStamp;
                    result = tunnelGeneralServices.UpdateTunnelData(objTunnelData, userId, out lastModifiedTimeStamp);
                    objTunnelData.Id = Convert.ToInt32(result);
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }

                if (int.TryParse(result, out isNumeric))
                {
                    TunnelContainer container = new TunnelContainer { TunnelGeneral = this.tunnelGeneralServices.GetTunnelData(objTunnelData.Id, objTunnelData.WasherGroupId, objTunnelData.EcolabAccountNumber) };
                    container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                    Push.PushToQueue(container, userId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelGeneral, objTunnelData.EcolabAccountNumber);

                    DateTime lastModifiedTimeStamp;
                    result = tunnelGeneralServices.UpdateTagsInDB(objTunnelData, userId, tunnelData.Role, EcolabAccountNumber, out lastModifiedTimeStamp);
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                    container.TunnelGeneral.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(objTunnelData.Id, objTunnelData.EcolabAccountNumber);
                    Push.PushToQueue(container, userId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelGeneral, objTunnelData.EcolabAccountNumber);

                }
                objPLCDiscrepancyModels.Add(new Models.Common.PLCDiscrepancyModel()
                {
                    ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                    ParentEntityId = objTunnelData.WasherGroupId,
                    Entity = Convert.ToInt32(PlcDiscrepancyEntity.Washer),
                    EntityId = objTunnelData.Id,
                    IsCentral = false,
                    ControllerId = objTunnelData.ControllerId,
                    UserId = this.UserId,
                    LastModifiedUserId = this.UserId
                });
                var plc = new PlcTagController(plcService, UserService, PlantService);
                string returnStatus = string.Empty;
                try
                {
                    if (tunnelData.ControllerModelId == 8 || tunnelData.ControllerModelId == 11)
                    {
                        WriteToPlc(tunnelData, prevTunnelGeneralModelData);
                    }
                    else if (tunnelData.ControllerModelId == 7)
                    {
                        TunnelNumber = tunnelData.LfsWasher;
                        List<Tag> tg = GenerateTags(tunnelData);
                        plc.WriteTunnelTags(new TagCollection { Tags = tg }, tunnelData.ControllerId, 2, tunnelData.LfsWasher);
                    }
                    else
                    {
                        if (tunnelData.Role >= 7 && tunnelData.PlcTunnelTagModelTags != null && tunnelData.PlcTunnelTagModelTags.Any())
                        {
                            TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tunnelData.PlcTunnelTagModelTags) }, tunnelData.ControllerId);
                            foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                            {
                                if (!string.IsNullOrEmpty(status.Address))
                                {
                                    int last = tagStatus.Tags.LastIndexOf(status);
                                    if (last != 14 && !string.IsNullOrEmpty(status.Address))
                                    {
                                        returnStatus += status.Address + ",";
                                    }
                                    else
                                    {
                                        if (!string.IsNullOrEmpty(returnStatus))
                                        {
                                            returnStatus += status.Address;
                                        }
                                    }
                                }
                            }

                            List<OpcTag> tagValues = new List<OpcTag>();
                            OpcTag tagAWEA = new OpcTag() { };
                            OpcTag tagRATD = new OpcTag();

                            var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, objTunnelData.ControllerId);
                            bool awea = fieldTags.AWEActive == true ? true : false;
                            bool ratioDosing = fieldTags.RatioDosingActive == true ? true : false;
                            //Allenbradley and Beckhoff
                            if (fieldTags.ControllerTypeId == 1 || fieldTags.ControllerTypeId == 2)
                            {
                                tagAWEA.Address = fieldTags.ControllerTypeId == 1 ? "B3:9/0" : "L_AWEE";
                                tagAWEA.TagItemType = UIInputType.TypeBool;
                                tagAWEA.TagType = "Tag_AWEA";
                                tagAWEA.Value = awea.ToString();

                                tagRATD.Address = fieldTags.ControllerTypeId == 1 ? "B3:10/0" : "L_RATD";
                                tagRATD.TagItemType = UIInputType.TypeBool;
                                tagRATD.TagType = "Tag_RDE";
                                tagRATD.Value = ratioDosing.ToString();

                                tunnelData.PlcTunnelTagModelTags.Add(tagAWEA);
                                tunnelData.PlcTunnelTagModelTags.Add(tagRATD);
                            }

                            try
                            {
                                plc.WriteTags(new TagCollection { Tags = new List<Tag>(tunnelData.PlcTunnelTagModelTags) }, tunnelData.ControllerId);
                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.Contains("Timeout has elapsed") ||
                                    ex.Message.Contains("Port is disabled") ||
                                    ex.Message.Contains("Target machine could not be found") ||
                                    ex.Message.Contains("ADS could not be initialized") ||
                                    ex.Message.Contains("Open Failed") ||
                                    ex.Message.Contains("Retrieving the COM class factory"))
                                {
                                    Logger.ErrorFormat("UpdateTunnelData : PLC Connection failed", ex.Message);
                                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", tunnelNumber));
                                }
                                else
                                {
                                    Logger.ErrorFormat("UpdateTunnelData : PLC Write failed", ex.Message);
                                    return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", tunnelNumber));
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        Logger.ErrorFormat("UpdateTunnelData : PLC Connection failed", ex.Message);
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "901", tunnelNumber));
                    }
                    else
                    {
                        Logger.ErrorFormat("UpdateTunnelData : PLC Write failed", ex.Message);
                        return Request.CreateResponse(HttpStatusCode.BadRequest, string.Format("{0}@{1}", "902", tunnelNumber));
                    }
                }
                if (!string.IsNullOrEmpty(returnStatus))
                {
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, returnStatus);
                }
                else
                {
                    isUpdateFine = 0;
                    DateTime lastModifiedTimeStamp;
                    result = tunnelGeneralServices.UpdateTagsInDB(objTunnelData, userId, tunnelData.Role, EcolabAccountNumber, out lastModifiedTimeStamp);
                    if (int.TryParse(result, out isUpdateFine))
                    {

                        objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                        TunnelContainer container = new TunnelContainer
                        {
                            TunnelGeneral = this.tunnelGeneralServices.GetTunnelData(objTunnelData.Id, objTunnelData.WasherGroupId, objTunnelData.EcolabAccountNumber)
                        };

                        container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
                        container.TunnelGeneral.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(objTunnelData.Id, objTunnelData.EcolabAccountNumber);
                        Push.PushToQueue(container, userId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdUpdateTunnelGeneral, objTunnelData.EcolabAccountNumber);
                        return Request.CreateResponse(HttpStatusCode.OK, new {Result= result, plcDiscrepancyModel = objPLCDiscrepancyModels } );
                    }

                    if (isUpdateFine == 0)
                    {
                        return Request.CreateResponse(HttpStatusCode.Ambiguous, result);
                    }
                }

                return Request.CreateResponse(HttpStatusCode.OK, new { Result = result, plcDiscrepancyModel = objPLCDiscrepancyModels });
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message.Substring(0, 5));
            }
            catch (Exception ex)
            {
                if (ex is NoNullAllowedException || ex is ApplicationException)
                {
                    return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
                }
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message.Substring(0, 5));
            }
        }

        /// <summary>
        /// Generate tags from Tunnel data
        /// </summary>
        /// <param name="tunnelData"></param>
        /// <returns></returns>
        private List<Tag> GenerateTags(TunnelGeneralModel tunnelData)
        {
            List<Tag> tg = new List<Tag>();

            //Modifying washer mode id's for writing in to PLC
            int alteredWasherMode = tunnelData.WasherMode == 20 ? 1 : tunnelData.WasherMode == 21 ? 2 : tunnelData.WasherMode == 22 ? 3 : tunnelData.WasherMode == 23 ? 4 :
                                                                tunnelData.WasherMode == 24 ? 5 : tunnelData.WasherMode == 25 ? 6 : tunnelData.WasherMode == 26 ? 7 : 0;

            string formatTunnelOptions = string.Empty;
            formatTunnelOptions += tunnelData.ProgramSelectionByTime == true ? 1 : 0; //4
            formatTunnelOptions += tunnelData.WeightSelectionByTime == true ? 1 : 0;   //5
            formatTunnelOptions += tunnelData.WeightSelectionByAnalogInput == true ? 1 : 0;   // 6
            formatTunnelOptions += tunnelData.TunInTomMode == true ? 1 : 0;   //7
            formatTunnelOptions += tunnelData.SignalStopTunActive == true ? 1 : 0;   //8
            formatTunnelOptions += tunnelData.SignalEjectionTunActive == true ? 1 : 0;   //9
            formatTunnelOptions += tunnelData.DelayTimeForTunWashingPrograms == true ? 1 : 0;   //10
            formatTunnelOptions += tunnelData.WeightCorrectionFcc == true ? 1 : 0;   // 11
            formatTunnelOptions += tunnelData.KannegiesserPressSpecialMode == true ? 1 : 0;   //12
            formatTunnelOptions += tunnelData.ExtendedClockOrDataProtocol == true ? 1 : 0;   // 13
            formatTunnelOptions += tunnelData.ValveOutputsUsedAsTomSignal == true ? 1 : 0;   // 14
            formatTunnelOptions += "0";

            var reversedString = Reverse(formatTunnelOptions);

            var washerMode = Convert.ToString(alteredWasherMode, 2); //0,1,2,3
            reversedString += alteredWasherMode == 1 ? washerMode = "000" + washerMode.ToString() :
                              alteredWasherMode == 2 ? washerMode = "00" + washerMode.ToString() :
                              alteredWasherMode == 3 ? washerMode = "00" + washerMode.ToString() :
                              alteredWasherMode == 4 ? washerMode = "0" + washerMode.ToString() :
                              alteredWasherMode == 5 ? washerMode = "0" + washerMode.ToString() :
                              alteredWasherMode == 6 ? washerMode = "0" + washerMode.ToString() :
                              alteredWasherMode == 7 ? washerMode = "0" + washerMode.ToString() : "0000";

            decimal formatTunnelOptionsDecimal = Convert.ToInt64(reversedString, 2);

            if (tunnelData.LfsWasher == 1)
            {
                //Used TagId to identify the address of plc to be updated.
                tg.Add(new OpcTag { Address = nameof(tunnelData.MaxMachineLoad), Value = Convert.ToString(tunnelData.MaxMachineLoad), TagId = 0 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.MinMachineLoad), Value = Convert.ToString(tunnelData.MinMachineLoad), TagId = 1 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.NoofCompartments), Value = Convert.ToString(tunnelData.NoofCompartments), TagId = 3 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.ProgramNumber), Value = Convert.ToString(tunnelData.ProgramNumber), TagId = 2 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.NumberOfCompartmentsConveyorBelt), Value = Convert.ToString(tunnelData.NumberOfCompartmentsConveyorBelt), TagId = 4 });
                tg.Add(new OpcTag { Address = "TunnelOptions", Value = Convert.ToString(formatTunnelOptionsDecimal), TagId = 174 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.KannegiesserDosageInPreparationTankMode), Value = Convert.ToString(tunnelData.KannegiesserDosageInPreparationTankMode == true ? "1" : "0"), TagId = 0 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.BatchOk), Value = Convert.ToString(tunnelData.BatchOk == true ? "1" : "0"), TagId = 0 });
            }
            else
            {
                //Used TagId to identify the address of plc to be updated.
                tg.Add(new OpcTag { Address = nameof(tunnelData.MaxMachineLoad), Value = Convert.ToString(tunnelData.MaxMachineLoad), TagId = 176 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.MinMachineLoad), Value = Convert.ToString(tunnelData.MinMachineLoad), TagId = 177 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.NoofCompartments), Value = Convert.ToString(tunnelData.NoofCompartments), TagId = 179 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.ProgramNumber), Value = Convert.ToString(tunnelData.ProgramNumber), TagId = 178 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.NumberOfCompartmentsConveyorBelt), Value = Convert.ToString(tunnelData.NumberOfCompartmentsConveyorBelt), TagId = 180 });
                tg.Add(new OpcTag { Address = "TunnelOptions", Value = Convert.ToString(formatTunnelOptionsDecimal), TagId = 350 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.KannegiesserDosageInPreparationTankMode), Value = Convert.ToString(tunnelData.KannegiesserDosageInPreparationTankMode == true ? "1" : "0"), TagId = 1 });
                tg.Add(new OpcTag { Address = nameof(tunnelData.BatchOk), Value = Convert.ToString(tunnelData.BatchOk == true ? "1" : "0"), TagId = 1 });
            }

            return tg;
        }

        private void RestructureBooleanFieldsandValidate(string tunnelOptionsUI, string tunnelOptionsPLC, StringBuilder message, List<OpcTag> ambiguousTag)
        {
            tunnelOptionsUI = tunnelOptionsUI.PadLeft(16, '0');
            tunnelOptionsPLC = tunnelOptionsPLC.PadLeft(16, '0');
            if (tunnelOptionsUI.Length == 16 && tunnelOptionsPLC.Length == 16)
            {
                ////////// FROM UI ////////
                var washerModel = Convert.ToInt32(tunnelOptionsUI.Substring(tunnelOptionsUI.Length - 4), 2);
                washerModel = washerModel == 1 ? 20 : washerModel == 2 ? 21 : washerModel == 3 ? 22 : washerModel == 4 ? 23 :
                                                                washerModel == 5 ? 24 : washerModel == 6 ? 25 : washerModel == 7 ? 26 : 0;

                var programSelectionByTime = tunnelOptionsUI[12 - 1].ToString() == "1" ? true : false;
                var weightSelectionByTime = tunnelOptionsUI[11 - 1].ToString() == "1" ? true : false;
                var weightSelectionByAnalogInput = tunnelOptionsUI[10 - 1].ToString() == "1" ? true : false;
                var tunnelInTomMode = tunnelOptionsUI[9 - 1].ToString() == "1" ? true : false;
                var signalStopTunActive = tunnelOptionsUI[8 - 1].ToString() == "1" ? true : false;
                var signalEjectionTunActive = tunnelOptionsUI[7 - 1].ToString() == "1" ? true : false;
                var delayTimeForTunWashingPrograms = tunnelOptionsUI[6 - 1].ToString() == "1" ? true : false;
                var weightCorrectionFcc = tunnelOptionsUI[5 - 1].ToString() == "1" ? true : false;
                var kannegiesserPressSpecialMode = tunnelOptionsUI[4 - 1].ToString() == "1" ? true : false;
                var extendedClockOrDataProtocol = tunnelOptionsUI[3 - 1].ToString() == "1" ? true : false;
                var valveOutputsUsedAsTomSignal = tunnelOptionsUI[2 - 1].ToString() == "1" ? true : false;

                ///////////  FROM PLC ///////////
                var washerModel_PLC = Convert.ToInt32(tunnelOptionsPLC.Substring(tunnelOptionsPLC.Length - 4), 2);
                washerModel_PLC = washerModel_PLC == 1 ? 20 : washerModel_PLC == 2 ? 21 : washerModel_PLC == 3 ? 22 : washerModel_PLC == 4 ? 23 : washerModel_PLC == 5 ? 24 : washerModel_PLC == 6 ? 25 : washerModel_PLC == 7 ? 26 : 0;

                var programSelectionByTime_PLC = tunnelOptionsPLC[12 - 1].ToString() == "1" ? true : false;
                var weightSelectionByTime_PLC = tunnelOptionsPLC[11 - 1].ToString() == "1" ? true : false;
                var weightSelectionByAnalogInput_PLC = tunnelOptionsPLC[10 - 1].ToString() == "1" ? true : false;
                var tunnelInTomMode_PLC = tunnelOptionsPLC[9 - 1].ToString() == "1" ? true : false;
                var signalStopTunActive_PLC = tunnelOptionsPLC[8 - 1].ToString() == "1" ? true : false;
                var signalEjectionTunActive_PLC = tunnelOptionsPLC[7 - 1].ToString() == "1" ? true : false;
                var delayTimeForTunWashingPrograms_PLC = tunnelOptionsPLC[6 - 1].ToString() == "1" ? true : false;
                var weightCorrectionFcc_PLC = tunnelOptionsPLC[5 - 1].ToString() == "1" ? true : false;
                var kannegiesserPressSpecialMode_PLC = tunnelOptionsPLC[4 - 1].ToString() == "1" ? true : false;
                var extendedClockOrDataProtocol_PLC = tunnelOptionsPLC[3 - 1].ToString() == "1" ? true : false;
                var valveOutputsUsedAsTomSignal_PLC = tunnelOptionsPLC[2 - 1].ToString() == "1" ? true : false;

                /////// COMPARISIONS //////////
                if (washerModel != washerModel_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, washerModel, washerModel_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WasherMode", Value = Convert.ToString(washerModel) });
                }

                if (programSelectionByTime != programSelectionByTime_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, programSelectionByTime, programSelectionByTime_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "ProgramSelectionByTime", Value = Convert.ToString(programSelectionByTime) });
                }
                if (weightSelectionByTime != weightSelectionByTime_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, weightSelectionByTime, weightSelectionByTime_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WeightSelectionByTime", Value = Convert.ToString(weightSelectionByTime) });
                }
                if (weightSelectionByAnalogInput != weightSelectionByAnalogInput_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, weightSelectionByAnalogInput, weightSelectionByAnalogInput_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WeightSelectionByAnalogInput", Value = Convert.ToString(weightSelectionByAnalogInput) });
                }
                if (tunnelInTomMode != tunnelInTomMode_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, tunnelInTomMode, tunnelInTomMode_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "TunInTomMode", Value = Convert.ToString(tunnelInTomMode) });
                }
                if (signalStopTunActive != signalStopTunActive_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, signalStopTunActive, signalStopTunActive_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "SignalStopTunActive", Value = Convert.ToString(signalStopTunActive) });
                }
                if (signalEjectionTunActive != signalEjectionTunActive_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, signalEjectionTunActive, signalEjectionTunActive_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "SignalEjectionTunActive", Value = Convert.ToString(signalEjectionTunActive) });
                }
                if (delayTimeForTunWashingPrograms != delayTimeForTunWashingPrograms_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, delayTimeForTunWashingPrograms, delayTimeForTunWashingPrograms_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "DelayTimeForTunWashingPrograms", Value = Convert.ToString(delayTimeForTunWashingPrograms) });
                }
                if (weightCorrectionFcc != weightCorrectionFcc_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, weightCorrectionFcc, weightCorrectionFcc_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "WeightCorrectionFcc", Value = Convert.ToString(weightCorrectionFcc) });
                }
                if (kannegiesserPressSpecialMode != kannegiesserPressSpecialMode_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, kannegiesserPressSpecialMode, kannegiesserPressSpecialMode_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "KannegiesserPressSpecialMode", Value = Convert.ToString(kannegiesserPressSpecialMode) });
                }
                if (extendedClockOrDataProtocol != extendedClockOrDataProtocol_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, extendedClockOrDataProtocol, extendedClockOrDataProtocol_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "ExtendedClockOrDataProtocol", Value = Convert.ToString(extendedClockOrDataProtocol) });
                }
                if (valveOutputsUsedAsTomSignal != valveOutputsUsedAsTomSignal_PLC)
                {
                    message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", string.Empty, valveOutputsUsedAsTomSignal, valveOutputsUsedAsTomSignal_PLC));
                    ambiguousTag.Add(new OpcTag { Address = "ValveOutputsUsedAsTomSignal", Value = Convert.ToString(valveOutputsUsedAsTomSignal) });
                }
            }
        }
        /// <summary>
        /// Validating Tunnel Tags to fetch ambiguos data between PLC and Envision
        /// </summary>
        /// <param name="tunnelData"></param>
        /// <param name="plc"></param>
        /// <param name="tg"></param>
        /// <returns></returns>
        private List<OpcTag> ValidateTunnelTags(TunnelGeneralModel tunnelData, PlcTagController plc, List<Tag> tg)
        {
            var generatedTags = GenerateTags(tunnelData);
            TagCollection tagStatusTunnel = plc.ValidateTags(new TagCollection { Tags = generatedTags }, tunnelData.ControllerId, SourcePage.TunnelGeneralPage);
            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tg.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address)
                    {
                        switch (tag.Address)
                        {
                            case "MaxMachineLoad":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "MinMachineLoad":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "NoofCompartments":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "ProgramNumber":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "NumberOfCompartmentsConveyorBelt":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "TunnelOptions":
                                var tunnelOptionsUI = tg.Where(s => s.Address == "TunnelOptions").FirstOrDefault().Value;
                                var tunnelOptionsPLC = tagStatusTunnel.Tags.Where(s => s.Address == "TunnelOptions").FirstOrDefault().Value;
                                RestructureBooleanFieldsandValidate(Convert.ToString(Convert.ToInt32(tunnelOptionsUI), 2), Convert.ToString(Convert.ToInt32(tunnelOptionsPLC), 2), message, ambiguousTags);
                                break;
                            case "KannegiesserDosageInPreparationTankMode":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "BatchOk":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            return ambiguousTags;
        }

        /// <summary>
        /// Validating Tunnel Analogue Dosing Tags to fetch ambiguos data
        /// </summary>
        /// <param name="tunnelData"></param>
        /// <param name="plc"></param>
        /// <param name="tg"></param>
        /// <param name="lstAnalogueDosing"></param>
        /// <returns></returns>
        private List<OpcTag> ValidateTunnelAnalogueTags(TunnelGeneralModel tunnelData, PlcTagController plc, List<Tag> tg, List<Models.Washers.Tunnel.AnalogueDosing> lstAnalogueDosing)
        {
            var tagData = GenerateTags(lstAnalogueDosing);
            TagCollection tagStatusTunnel = plc.ValidateTags(new TagCollection { Tags = tagData }, tunnelData.ControllerId, SourcePage.TunnelAnaloguePage);
            var message = new StringBuilder();
            var ambiguousTags = new List<OpcTag>();
            foreach (OpcTag tag in tg.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
            {
                foreach (Tag plcTag in tagStatusTunnel.Tags.Where(t => !string.IsNullOrWhiteSpace(t.Value)))
                {
                    if (plcTag.TagItemType == UIInputType.TypeBool)
                    {
                        plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                    }
                    if (tag.Address == plcTag.Address && tag.TagType == plcTag.TagType)
                    {
                        switch (tag.Address.ToUpper())
                        {
                            case "SETPOINT":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "DELAYAFTERTRANSFER":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "CONTROLDELAY":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "MAXVALUE":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "MINVALUE":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "PAUSETIME":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "QUANTITY":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "MAXTIME":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "PREQUANTITY":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            case "PREPAUSETIME":
                                if (Convert.ToDouble(tag.Value.Trim()) != Convert.ToDouble(plcTag.Value.Trim()))
                                {
                                    message.Append(string.Format(
                                "For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address,
                                tag.Value,
                                plcTag.Value));
                                    ambiguousTags.Add(tag);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            return ambiguousTags;
        }

        private string Reverse(string text)
        {
            if (text == null) return null;

            // this was posted by petebob as well 
            char[] array = text.ToCharArray();
            Array.Reverse(array);
            return new String(array);
        }

        /// <summary>
        ///     Gets the tunnel data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <returns>
        ///     Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.TunnelGeneralModel.
        /// </returns>
        [HttpGet]
        public TunnelGeneralModel GetTunnelData(int id, int washerGroupId, string ecoLabAccountNumber)
        {
            TunnelGeneral objList = this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber);
            if (objList != null && objList.Id > 0)
            {
                objList.TunnelTagsList = this.tunnelGeneralServices.GetTunnelWasherTags(objList.Id, ecoLabAccountNumber);
                if (objList.TunnelTagsList != null)
                    objList.TunnelTags = objList.TunnelTagsList.FirstOrDefault();
            }
            TunnelGeneralModel tunneldata = Mapper.Map<TunnelGeneral, TunnelGeneralModel>(objList);
            TunnelNumber = tunneldata.LfsWasher;
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            int washerModeNumber = this.tunnelGeneralServices.GetWasherModeNumberByWasherId(objList.ControllerTypeId, objList.ControllerModelId, objList.WasherMode);
            if (tunneldata.TunnelTagsList != null)
            {
                var tagsList = new List<OpcTag>();
                TagCollection tagStatus = new TagCollection();
                var tagModel = tunneldata.TunnelTagsList.FirstOrDefault();

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.WasherModeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.WasherModeTag,
                        Value = washerModeNumber.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.AutoWeightEntryActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.AutoWeightEntryActiveTag,
                        Value = tunneldata.AweActive.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.RatioDosingActiveTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.RatioDosingActiveTag,
                        Value = tunneldata.RatioDosingActive.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagModel != null && !string.IsNullOrEmpty(tagModel.EndOfFormulaTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = tagModel.EndOfFormulaTag,
                        Value = tunneldata.EndOfFormula.ToString(CultureInfo.CurrentCulture)
                    });
                }

                if (tagsList.Count > 0)
                {
                    try
                    {
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) },
                            tunneldata.ControllerId);
                        List<string> tagCollectionList = new List<string>();
                        foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                                {
                                    tagCollectionList.Add(tag.Address);
                                }
                            }
                        }
                        if (tagModel != null && tagCollectionList.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(tagModel.WasherModeTag) &&
                                 tagCollectionList.Contains(tagModel.WasherModeTag))
                            {
                                tunneldata.IsValueDiffforMode = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.RatioDosingActiveTag) &&
                                 tagCollectionList.Contains(tagModel.RatioDosingActiveTag))
                            {
                                tunneldata.IsValueDiffforRatiodosingActive = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.EndOfFormulaTag) &&
                                 tagCollectionList.Contains(tagModel.EndOfFormulaTag))
                            {
                                tunneldata.IsValueDiffforEOF = true;
                            }
                            if (!string.IsNullOrEmpty(tagModel.AutoWeightEntryActiveTag) &&
                                tagCollectionList.Contains(tagModel.AutoWeightEntryActiveTag))
                            {
                                tunneldata.IsValueDiffforAWEActive = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                }
            }
            try
            {
                if (tunneldata.ControllerModelId == 7)
                {
                    //Validating Tags against data from PLC
                    List<Tag> tg = GenerateTags(tunneldata);
                    var ambiguosTags = ValidateTunnelTags(tunneldata, plc, tg);
                    if (ambiguosTags != null)
                    {
                        if (ambiguosTags.Count > 0)
                        {
                            foreach (var item in ambiguosTags)
                            {
                                if (item.Address.Contains("WeightSelectionByTime")) { tunneldata.IsValueDiffforWeightSelectionByTime = true; }
                                if (item.Address.Contains("ProgramSelectionByTime")) { tunneldata.IsValueDiffforProgramSelectionByTime = true; }
                                if (item.Address.Contains("WeightSelectionByAnalogInput")) { tunneldata.IsValueDiffforWeightSelectionByAnalogInput = true; }
                                if (item.Address.Contains("TunInTomMode")) { tunneldata.IsValueDiffforTunInTomMode = true; }
                                if (item.Address.Contains("SignalStopTunActive")) { tunneldata.IsValueDiffforSignalStopTunActive = true; }
                                if (item.Address.Contains("SignalEjectionTunActive")) { tunneldata.IsValueDiffforSignalEjectionTunActive = true; }
                                if (item.Address.Contains("DelayTimeForTunWashingPrograms")) { tunneldata.IsValueDiffforDelayTimeForTunWashingPrograms = true; }
                                if (item.Address.Contains("WeightCorrectionFcc")) { tunneldata.IsValueDiffforWeightCorrectionFcc = true; }
                                if (item.Address.Contains("KannegiesserPressSpecialMode")) { tunneldata.IsValueDiffforKannegiesserPressSpecialMode = true; }
                                if (item.Address.Contains("ExtendedClockOrDataProtocol")) { tunneldata.IsValueDiffforExtendedClockOrDataProtocol = true; }
                                if (item.Address.Contains("ValveOutputsUsedAsTomSignal")) { tunneldata.IsValueDiffforValveOutputsUsedAsTomSignal = true; }
                                if (item.Address.Contains("MaxMachineLoad")) { tunneldata.IsValueDiffforMaxMachineLoad = true; }
                                if (item.Address.Contains("MinMachineLoad")) { tunneldata.IsValueDiffforMinMachineLoad = true; }
                                if (item.Address.Contains("WasherMode")) { tunneldata.IsValueDiffforMode = true; }
                                if (item.Address.Contains("NoofCompartments")) { tunneldata.IsValueDiffforNoofCompartments = true; }
                                if (item.Address.Contains("ProgramNumber")) { tunneldata.IsValueDiffforProgramNumber = true; }
                                if (item.Address.Contains("NumberOfCompartmentsConveyorBelt")) { tunneldata.IsValueDiffforNumberOfCompartmentsConveyorBelt = true; }
                                if (item.Address.Contains("KannegiesserDosageInPreparationTankMode")) { tunneldata.IsValueDiffforKannegiesserDosageInPreparationTankMode = true; }
                                if (item.Address.Contains("BatchOk")) { tunneldata.IsValueDiffforBatchOk = true; }

                            }
                        }
                    }
                }
                else if (tunneldata.ControllerModelId == 8)
                {
                    //Read plc values for EcontrolPlus tunnel washer general and compare
                    List<Tag> uiTags = GetEcontolPlusTunnelGeneralTags(tunneldata);
                    List<Tag> uiTagsClone = GetEcontolPlusTunnelGeneralTags(tunneldata);
                    List<string> tagCollectionList = new List<string>();
                    TagCollection plcTags = new TagCollection { Tags = new List<Tag>() };
                    try
                    {
                        plcTags = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(uiTagsClone) }, tunneldata.ControllerId);
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }

                    if (plcTags != null)
                    {
                        foreach (Tag uiTag in uiTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in plcTags.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (uiTag.Address == plcTag.Address && uiTag.Value.ToUpper() != plcTag.Value.ToUpper())
                                {
                                    tagCollectionList.Add(uiTag.Address);
                                    break;
                                }
                            }
                        }
                        if (tagCollectionList.Count > 0)
                        {
                            if (tagCollectionList.Contains("D317"))
                            {
                                tunneldata.IsValueDiffforMaxMachineLoad = true;
                            }
                            if (tagCollectionList.Contains("D318"))
                            {
                                tunneldata.IsValueDiffforMinMachineLoad = true;
                            }
                            if (tagCollectionList.Contains("D319"))
                            {
                                tunneldata.IsValueDiffforMode = true;
                            }
                            if (tagCollectionList.Contains("D320"))
                            {
                                tunneldata.IsValueDiffforNoofCompartments = true;
                            }
                            if (tagCollectionList.Contains("D384"))
                            {
                                tunneldata.IsValueDiffforTunInTomMode = true;
                            }
                            if (tagCollectionList.Contains("M933"))
                            {
                                tunneldata.IsValueDiffforDelayTimeForTunWashingPrograms = true;
                            }
                            if (tagCollectionList.Contains("M992"))
                            {
                                tunneldata.IsValueDiffforWeightCorrectionFcc = true;
                            }
                        }
                    }
                }
                else if (tunneldata != null && tunneldata.ControllerModelId == 11)
                {
                    List<Tag> plcTagsList = new List<Tag>();
                    TagCollection plctagStatus = new TagCollection();
                    var offset = (tunneldata.LfsWasher - 1) * 15;
                    var offset3 = (tunneldata.LfsWasher - 1) * 3;
                    var offset2 = (tunneldata.LfsWasher - 1) * 50;
                    List<string> tagCollectionList = new List<string>();

                    plcTagsList = GetPLCXLTunnelGeneralTags(tunneldata, null);

                    if (plcTagsList.Count > 0 && tunneldata.ControllerId > 0)
                    {
                        plctagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(plcTagsList) }, tunneldata.ControllerId, SourcePage.WasherPage);

                        plcTagsList = GetPLCXLTunnelGeneralTags(tunneldata, null);

                        foreach (MitsubishiTag tag in plcTagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in plctagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                {
                                    tagCollectionList.Add(tag.TagType);
                                }
                            }
                        }
                    }
                    //13 : 1-Tunnel, 5-Washers, 14 : //2-Tunnels
                    if (tunneldata.ControllerTypeId == 13)
                    {
                        ValidateTunnelGeneralTags(tunneldata, tagCollectionList);
                    }
                    else if (tunneldata.ControllerTypeId == 14)
                    {
                        ValidateTunnelGeneralTags(tunneldata, tagCollectionList);
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Ads-Error 0x745")) { ErrorLog.GetDefault(null).Log(new Error(ex) { Message = "Unable to connect to PLC." }); }
                else { ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message }); }
                return tunneldata;
            }
            return tunneldata;
        }

        /// <summary>
        ///     Gets the compartment data.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="compartmentNumber">The compartment number.</param>
        /// <param name="regionId">The Plant Region Id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>Tunnel Compartment Data</returns>
        [HttpGet]
        public TunnelCompartmentModel GetCompartmentData(int id, int washerGroupId, string ecoLabAccountNumber, byte compartmentNumber, int regionId, int controllerId)
        {
            TunnelCompartment objList = this.tunnelCompartmentServices.GetCompartmentData(id, washerGroupId, ecoLabAccountNumber, compartmentNumber, false);
            TunnelCompartmentModel tunneldata = Mapper.Map<TunnelCompartment, TunnelCompartmentModel>(objList);
            if (tunneldata != null)
            {
                tunneldata.CompartmentNumber = compartmentNumber;
                tunneldata.TunnelDropDowns = this.GetCompartmentDropDownData(ecoLabAccountNumber, regionId, controllerId, id, washerGroupId);
                TunnelGeneralModel tunnelGendata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
                tunneldata.MachineNumber = tunnelGendata.LfsWasher;
            }
            return tunneldata;
        }

        /// <summary>
        ///     Gets the compartment drop down data.
        /// </summary>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="tunnelId">The tunnel identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>
        ///     Returns Tunnel Conventional Drop Down Model
        /// </returns>
        [HttpGet]
        public TunnelConventionalDropDownModel GetCompartmentDropDownData(string ecoLabAccountNumber, int regionId, int controllerId, int tunnelId, int washerGroupId)
        {
            var objTunnelConventionalDropDownModel = new TunnelConventionalDropDownModel();

            IEnumerable<PressExtractor> objWaterInletDrainList = this.tunnelCompartmentServices.GetWaterInletDrainList(ecoLabAccountNumber);
            IEnumerable<PressExtractorModel> waterInletDrainList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objWaterInletDrainList);
            objTunnelConventionalDropDownModel.WaterInletDrainList = waterInletDrainList;

            IEnumerable<PressExtractor> objWaterFlowList = this.tunnelCompartmentServices.GetWaterFlowList(regionId);
            IEnumerable<PressExtractorModel> waterFlowList = Mapper.Map<IEnumerable<PressExtractor>, IEnumerable<PressExtractorModel>>(objWaterFlowList);
            objTunnelConventionalDropDownModel.WaterFlowList = waterFlowList;

            IEnumerable<WashStep> washStepWashOperations = this.washerGroupFormulaService.GetWashOperations(regionId, true);
            objTunnelConventionalDropDownModel.WashOperationDetails = washStepWashOperations.Select(EntityConverter.ConvertToWebModel).ToList();

            IEnumerable<PumpAssociation> objPumpsProductsList = this.tunnelCompartmentServices.PumpsProductsList(ecoLabAccountNumber, controllerId, tunnelId);
            IEnumerable<PumpAssociationModel> pumpsProductsList = Mapper.Map<IEnumerable<PumpAssociation>, IEnumerable<PumpAssociationModel>>(objPumpsProductsList);
            objTunnelConventionalDropDownModel.PumpsProductList = pumpsProductsList;

            IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty);
            IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

            objTunnelConventionalDropDownModel.WasherGroupList = washerGroups;

            return objTunnelConventionalDropDownModel;
        }

        /// <summary>
		/// Fetches the Tunnel Compartment Data
        /// </summary>
		/// <param name="id">The WasherId</param>
		/// <param name="washerGroupId">The WasherGroupId</param>
		/// <param name="ecoLabAccountNumber">The EcolabAccount Number</param>
		/// <param name="compartmentNumber">The CompartmentNumber</param>
		/// <param name="regionId">The region Id</param>
		/// <param name="controllerId">The controllerId</param>
		/// <returns>List of the Connections Data and WasherGroup Info  for a particular Tunnel</returns>
		[HttpGet]
        public IDictionary<string, object> FetchTunnelConnectionsData(int id, int washerGroupId, string ecoLabAccountNumber, int compartmentNumber, int regionId, int controllerId)
        {
            IDictionary<string, object> data = new Dictionary<string, object>();
            IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections> lstconn = this.tunnelConnectionServices.FetchTunnelConnections(id, controllerId, ecoLabAccountNumber);
            data.Add("List", lstconn);
            data.Add("WasherGroupInfo", AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty).FirstOrDefault()));
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
            data.Add("WasherName", tunneldata.Name);
            data.Add("MachineNumber", tunneldata.LfsWasher);
            return data;
        }
        /// <summary>
        /// Fetches the Analogue Dosing Data
        /// </summary>
        /// <param name="id">The WasherId</param>
        /// <param name="washerGroupId">The WasherGroupId</param>
        /// <param name="ecoLabAccountNumber">The EcolabAccount Number</param>
        /// <param name="compartmentNumber">The CompartmentNumber</param>
        /// <param name="regionId">The region Id</param>
        /// <param name="controllerId">The controllerId</param>
        /// <returns>List of Analogue Dosing Data for a particular Tunnel</returns>
        [HttpGet]
        public IDictionary<string, object> FetchAnalogueDosingData(int id, int washerGroupId, string ecoLabAccountNumber, int compartmentNumber, int regionId, int controllerId)
        {
            IDictionary<string, object> data = new Dictionary<string, object>();
            List<Models.Washers.Tunnel.AnalogueDosing> analogueDosingConn = new List<Models.Washers.Tunnel.AnalogueDosing>();
            try
            {
                AnalogueControllerId = controllerId;
                List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstAnalogDosing = analogueDosingControlServices.FetchAnalogueDosingDataForMachineId(id, this.EcolabAccountNumber);
                analogueDosingConn = Mapper.Map<List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>, List<Models.Washers.Tunnel.AnalogueDosing>>(lstAnalogDosing);

                data.Add("WasherGroupInfo", AutoMapper.Mapper.Map<WasherGroup, Models.WasherGroup.WasherGroup>(this.washerGroupService.GetWasherGroupDetails(washerGroupId, ecoLabAccountNumber, 0, 12, string.Empty).FirstOrDefault()));
                TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(id, washerGroupId, ecoLabAccountNumber));
                data.Add("WasherName", tunneldata.Name);
                data.Add("MachineNumber", tunneldata.LfsWasher);
                TunnelNumber = tunneldata.LfsWasher;

                //Reading and Verification of Tags from UI with PLC data
                var plc = new PlcTagController(plcService, UserService, PlantService);

                int indexAnalogControlLevelId = 0;
                if (analogueDosingConn.Count() > 0)
                    indexAnalogControlLevelId = analogueDosingConn[0].AnalogControlLevelId - 1;
                var ambiguousTags = new List<OpcTag>();
                if (tunneldata.ControllerModelId == 7)
                {
                    var tagData = GenerateTags(analogueDosingConn);
                    ambiguousTags = ValidateTunnelAnalogueTags(tunneldata, plc, tagData, analogueDosingConn);
                    foreach (var item in analogueDosingConn)
                    {
                        item.IsValueDiffForSetPoint = ambiguousTags.Where(x => x.Address == "SetPoint" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForDelayAfterTransfer = ambiguousTags.Where(x => x.Address == "DelayAfterTransfer" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForControlDelay = ambiguousTags.Where(x => x.Address == "ControlDelay" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForMaxValue = ambiguousTags.Where(x => x.Address == "MaxValue" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForMinValue = ambiguousTags.Where(x => x.Address == "MinValue" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForPauseTime = ambiguousTags.Where(x => x.Address == "PauseTime" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForQuantity = ambiguousTags.Where(x => x.Address == "Quantity" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForPreQuantity = ambiguousTags.Where(x => x.Address == "PreQuantity" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForMaxTime = ambiguousTags.Where(x => x.Address == "MaxTime" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                        item.IsValueDiffForPrePauseTime = ambiguousTags.Where(x => x.Address == "PrePauseTime" && x.TagType == (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString()).Count() > 0 ? true : false;
                    }
                }
                else if (tunneldata.ControllerModelId == 11)
                {
                    analogueDosingConn = BuildPLCXLTunnelAnalogueOverrides(analogueDosingConn, tunneldata.LfsWasher, tunneldata.ControllerId, tunneldata.ControllerTypeId);
                }
                data.Add("List", analogueDosingConn);
            }
            catch (Exception ex)
            {
                data.Add("List", analogueDosingConn);
            }
            return data;
        }

        /// <summary>
        ///     Gets the size list.
        /// </summary>
        /// <param name="controllerId">the controller id.</param>
        /// <param name="ecoLabAccountNumber">ecolab account number.</param>
        /// <returns>List Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel.</returns>
        public List<Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel> GetWasherModes(int? controllerId, string ecoLabAccountNumber)
        {
            if (controllerId != null)
            {
                var objWasherMode = tunnelGeneralServices.GetWasherModes(ecoLabAccountNumber, controllerId.Value);
                var washerModeList =
                    Mapper.Map<IEnumerable<Ecolab.Models.Washers.Conventional.WasherModeList>, IEnumerable<Ecolab.ConduitLocal.Web.Models.Washers.Conventional.WasherModeListModel>>(objWasherMode).ToList();
                return washerModeList;
            }
            else
            {
                return new List<WasherModeListModel>();
            }
        }

        /// <summary>
        /// Saves the Analogue Dosing data
        /// </summary>
        /// <param name="lstData">Analogue Dosing data List</param>
        /// <returns>True for saved and False for not saved</returns>
        [HttpPost]
        public HttpResponseMessage SaveAnalogueDosingData(List<Models.Washers.Tunnel.AnalogueDosing> lstData)
        {
            IPrincipal user = HttpContext.Current.User;
            int userId = ((CustomPrincipal)user).UserId;
            bool result = true;
            List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstSaveData = Mapper.Map<List<Models.Washers.Tunnel.AnalogueDosing>, List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>>(lstData);
            result = this.analogueDosingControlServices.SaveAnalogueDosingData(lstSaveData, this.EcolabAccountNumber, userId);
            if (result)
            {
                List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> analogDosingControlList = this.analogueDosingControlServices.GetTunnelAnalogueDosingControlForResynch(lstSaveData.FirstOrDefault().WasherId, this.EcolabAccountNumber);
                analogDosingControlList.ForEach(t => t.EcolabAccountNumber = this.EcolabAccountNumber);
                analogDosingControlList.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
                TunnelAnalogueDosingControlContainer analogueDosingControlContainer = new TunnelAnalogueDosingControlContainer();
                analogueDosingControlContainer.AnalogueDosingControlList = analogDosingControlList;

                Push.PushToQueue(analogueDosingControlContainer, userId, analogueDosingControlContainer.AnalogueDosingControlList.FirstOrDefault().WasherId, (int)TcdAdminMessageTypes.TcdAddTunnelAnalogueDosingControl, this.EcolabAccountNumber);

                //Sending to PLC
                try
                {
                    var analogueDosingDatafirstintheList = lstData.FirstOrDefault();
                    TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(analogueDosingDatafirstintheList.WasherId, analogueDosingDatafirstintheList.WasherGroupId, this.EcolabAccountNumber));
                    TunnelNumber = tunneldata.LfsWasher;
                    var plc = new PlcTagController(plcService, UserService, PlantService);
                    List<Tag> tagAnalogue;
                    if (tunneldata.ControllerModelId == 7)
                    {
                        tagAnalogue = GenerateTags(lstData);
                        plc.WriteTunnelTags(new TagCollection { Tags = tagAnalogue }, AnalogueControllerId, 4);
                    }
                    else if (tunneldata.ControllerModelId == 11)
                    {
                        tagAnalogue = BuildPLCXLTunnelAnalogueTags(lstData, tunneldata.LfsWasher, tunneldata.ControllerTypeId);
                        plc.WriteTags(new TagCollection { Tags = tagAnalogue }, tunneldata.ControllerId, SourcePage.TunnelAnaloguePage);
                    }

                }
                catch (Exception ex)
                {
                    string msg = string.Empty;
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        msg = "901@" + 0;
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, msg);
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, 0);
            }
            else
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 1);
            }
        }

        /// <summary>
        /// Generates the tags.
        /// </summary>
        /// <param name="analogueDosingData">The analogue dosing data.</param>
        /// <returns>List of OPC Tags.</returns>
        private static List<Tag> GenerateTags(List<Models.Washers.Tunnel.AnalogueDosing> analogueDosingData)
        {
            List<Tag> tagAnalogue = new List<Tag>();
            int indexAnalogControlLevelId = 0;
            if (analogueDosingData.Count() > 0)
                indexAnalogControlLevelId = analogueDosingData[0].AnalogControlLevelId - 1;
            foreach (var item in analogueDosingData)
            {
                //Here TagId is used to differentiate LF and pH
                //Here TagTypeId is used to differentiate Tunnel Number
                tagAnalogue.Add(new OpcTag { Address = nameof(item.SetPoint), Value = Convert.ToString(Convert.ToInt32(item.SetPoint * 100)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.DelayAfterTransfer), Value = Convert.ToString(Convert.ToInt32(item.DelayAfterTransfer)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.PreQuantity), Value = Convert.ToString(Convert.ToInt32(item.PreQuantity)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.PrePauseTime), Value = Convert.ToString(Convert.ToInt32(item.PrePauseTime)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.Quantity), Value = Convert.ToString(Convert.ToInt32(item.Quantity)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.ControlDelay), Value = Convert.ToString(Convert.ToInt32(item.ControlDelay)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.MaxValue), Value = Convert.ToString(Convert.ToInt32(item.MaxValue * 100)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.MinValue), Value = Convert.ToString(Convert.ToInt32(item.MinValue * 100)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.PauseTime), Value = Convert.ToString(Convert.ToInt32(item.PauseTime)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
                tagAnalogue.Add(new OpcTag { Address = nameof(item.MaxTime), Value = Convert.ToString(Convert.ToInt32(item.MaxTime)), TagId = item.AnalogControlLevelTypeId, TagTypeId = TunnelNumber, TagType = (item.AnalogControlLevelId - indexAnalogControlLevelId).ToString() });
            }

            return tagAnalogue;
        }

        /// <summary>
        /// Moves the pump .
        /// </summary>
        /// <param name="moveCompartmentData">The move compartment data.</param>
        /// <returns>Returns Http Response Message</returns>
        public HttpResponseMessage MovePump(TunnelCompartmentModel moveCompartmentData)
        {
            try
            {
                IPrincipal user = HttpContext.Current.User;
                int userId = ((CustomPrincipal)user).UserId;
                int result = 0;
                TunnelCompartment objTunnelData = Mapper.Map<TunnelCompartmentModel, TunnelCompartment>(moveCompartmentData);
                if (user != null)
                {
                    DateTime lastModifiedTimeStamp;
                    result = this.tunnelCompartmentServices.MovePump(objTunnelData, userId, out lastModifiedTimeStamp);
                    objTunnelData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }
                if (result == 0)
                {
                    Push.PushToQueue(objTunnelData, this.UserId, objTunnelData.Id, (int)TcdAdminMessageTypes.TcdMovePump, this.EcolabAccountNumber);
                }
                return Request.CreateResponse(HttpStatusCode.OK, moveCompartmentData);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        /// <summary>
        /// Gets the compartment count.
        /// </summary>
        /// <param name="tunnelId">The tunnel identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="ecoLabAccountNumber">The eco lab account number.</param>
        /// <returns>Returns List of Tunnel Compartment Model</returns>
        [HttpGet]
        public List<TunnelCompartmentModel> GetCompartmentCount(int tunnelId, int washerGroupId, string ecoLabAccountNumber)
        {
            List<TunnelCompartment> objList = this.tunnelCompartmentServices.getCompartmentCount(tunnelId, washerGroupId, ecoLabAccountNumber);
            return Mapper.Map<List<TunnelCompartment>, List<TunnelCompartmentModel>>(objList);
        }

        /// <summary>
        /// Write to PLC data.
        /// </summary>
        /// <param name="tunnelData">tunnel Data</param>
        /// <param name="prevTunnelGeneralModelData">previous Tunnel General Model Data</param>
        private void WriteToPlc(TunnelGeneralModel tunnelData, TunnelGeneralModel prevTunnelGeneralModelData)
        {
            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            //If Controller is of type EcontrolPlus
            if (tunnelData.ControllerModelId == 8)
            {
                List<Tag> tagsList = GetEcontolPlusTunnelGeneralTags(tunnelData);
                if (tagsList != null && tagsList.Count > 0)
                {
                    MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                    plc.WriteTags(mitsubishiTag, tunnelData.ControllerId, 2, SourcePage.WasherPage);
                }
            }
            else if (tunnelData.ControllerModelId == 11)
            {
                Ecolab.Models.ControllerSetup.Controller controllerDetails = this.controllerSetupService.GetControllerDetailById(tunnelData.ControllerId, this.EcolabAccountNumber);
                tunnelData.ControllerTypeId = controllerDetails.ControllerTypeId;
                List<Tag> tagsList = GetPLCXLTunnelGeneralTags(tunnelData, prevTunnelGeneralModelData);
                if (tagsList != null && tagsList.Count > 0)
                {
                    MitsubishiTag mitsubishiTag = plc.GetMitsubishiTags(tagsList);
                    plc.WriteTags(mitsubishiTag, tunnelData.ControllerId, 2, SourcePage.WasherPage);
                }
            }
        }

        /// <summary>
        /// Gets the econtol plus tunnel general tags.
        /// </summary>
        /// <param name="tunnelData">The tunnel data.</param>
        /// <returns>
        /// List of tunnel washer general tags
        /// </returns>
        private List<Tag> GetEcontolPlusTunnelGeneralTags(TunnelGeneralModel tunnelData)
        {
            //Get Address offset based on LFS washer number
            List<Tag> tagsList = new List<Tag>();

            if (tunnelData != null)
            {
                //Maximum Load
                tagsList.Add(new MitsubishiTag
                {
                    Address = "D317",
                    Value = tunnelData.MaxMachineLoad.ToString(),
                    TagItemType = UIInputType.TypeInt
                });
                //Minimum Load
                tagsList.Add(new MitsubishiTag
                {
                    Address = "D318",
                    Value = tunnelData.MinMachineLoad.ToString(),
                    TagItemType = UIInputType.TypeInt
                });
                //Washer operational (Start) Mode  (Mode)
                string washerMode = tunnelGeneralServices.GetWasherModelNumber(tunnelData.EcolabAccountNumber, tunnelData.ControllerId, tunnelData.WasherMode);
                washerMode = washerMode == string.Empty ? "0" : washerMode;
                tagsList.Add(new MitsubishiTag
                {
                    Address = "D319",
                    Value = washerMode,
                    TagItemType = UIInputType.TypeInt
                });
                //Number of compartments
                tagsList.Add(new MitsubishiTag
                {
                    Address = "D320",
                    Value = tunnelData.NoofCompartments.ToString(),
                    TagItemType = UIInputType.TypeInt
                });
                //TUN in TOM mode (Time from Machine)
                tagsList.Add(new MitsubishiTag
                {
                    Address = "D384",
                    Value = tunnelData.TunInTomMode.ToString().ToLower() == "true" ? "1" : "0",
                    TagItemType = UIInputType.TypeBool
                });
                //Delay time for TUN washing programs X 10 Seconds
                tagsList.Add(new MitsubishiTag
                {
                    Address = "M933",
                    Value = tunnelData.DelayTimeForTunWashingPrograms.ToString().ToLower() == "true" ? "1" : "0",
                    TagItemType = UIInputType.TypeBool
                });
                //Weight correction (F.F.C)
                tagsList.Add(new MitsubishiTag
                {
                    Address = "M992",
                    Value = tunnelData.WeightCorrectionFcc.ToString().ToLower() == "true" ? "1" : "0",
                    TagItemType = UIInputType.TypeBool
                });
            }
            return tagsList;
        }

        /// <summary>
        /// Gets the PLCXL tunnel general tags.
        /// </summary>
        /// <param name="tunnelGeneralData">The tunnel general data.</param>
        /// <param name="prevTunnelGeneralModelData">The previous tunnel general model data.</param>
        /// <returns>Returns List of Tags</returns>
        private List<Tag> GetPLCXLTunnelGeneralTags(TunnelGeneralModel tunnelGeneralData, TunnelGeneralModel prevTunnelGeneralModelData)
        {
            List<Tag> tagsList = new List<Tag>();

            if (tunnelGeneralData != null)
            {
                string washerModelNumber = tunnelGeneralServices.GetWasherModelNumber(tunnelGeneralData.EcolabAccountNumber, tunnelGeneralData.ControllerId, tunnelGeneralData.WasherMode);
                washerModelNumber = washerModelNumber == string.Empty ? "0" : washerModelNumber;
                // 14: 2-Tunnels; 13: 1-Tunnel, 5-Washers
                if (tunnelGeneralData.ControllerTypeId == 13)
                {
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WMAXMACHINELOAD, Value = Convert.ToString(tunnelGeneralData.MaxMachineLoad), TagType = "MAXMACHINELOAD" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WMINMACHINELOAD, Value = Convert.ToString(tunnelGeneralData.MinMachineLoad), TagType = "MINMACHINELOAD" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WUSEME1OFGROUP, Value = Convert.ToString(tunnelGeneralData.UseMe1OfGroup), TagType = "USEME1OFGROUP" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WUSEME2OFGROUP, Value = Convert.ToString(tunnelGeneralData.UseMe2OfGroup), TagType = "USEME2OFGROUP" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WAUTORINSEDESAMIXAFTER, Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamixAfter), TagType = "AUTORINSEDESAMIXAFTER" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WAUTORINSEDESAMIX1FOR, Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamix1For * 10), TagType = "AUTORINSEDESAMIX1FOR" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WAUTORINSEDESAMIX2FOR, Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamix2For * 10), TagType = "AUTORINSEDESAMIX2FOR" });

                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WPROGRAMNUMBER, Value = Convert.ToString(tunnelGeneralData.ProgramNumber), TagType = "PROGRAMNUMBER" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL1T5WWEIGHTCORRECTIONFCC, Value = Convert.ToString(tunnelGeneralData.WeightCorrectionFcc).ToLower() == "true" ? "1" : "0", TagType = "WEIGHTCORRECTIONFCC" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL1T5WTEMPERATUREALARMPROBE1, Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe1).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE1" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL1T5WTEMPERATUREALARMPROBE2, Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe2).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE2" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL1T5WTEMPERATUREALARMPROBE3, Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe3).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE3" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL1T5WDATEANDTIMEWHENBATCHEJECTS, Value = Convert.ToString(tunnelGeneralData.DateAndTimeWhenBatchEjects).ToLower() == "true" ? "1" : "0", TagType = "DATEANDTIMEWHENBATCHEJECTS" });

                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WNOOFCOMPARTMENTS, Value = Convert.ToString(tunnelGeneralData.NoofCompartments), TagType = "NOOFCOMPARTMENTS" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WNUMBEROFCOMPARTMENTSCONVEYORBELT, Value = Convert.ToString(tunnelGeneralData.NumberOfCompartmentsConveyorBelt), TagType = "NUMBEROFCOMPARTMENTSCONVEYORBELT" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WWASHERMODE, Value = Convert.ToString(Convert.ToInt32(washerModelNumber) * 10), TagType = "WASHERMODE" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + PLCXL1T5WTUNINTOMMODE, Value = Convert.ToString(tunnelGeneralData.TunInTomMode).ToLower() == "true" ? "1" : "0", TagType = "TUNINTOMMODE" });
                }
                else if (tunnelGeneralData.ControllerTypeId == 14)
                {
                    var offset = (tunnelGeneralData.LfsWasher - 1) * 15;
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TMAXMACHINELOAD + offset), Value = Convert.ToString(tunnelGeneralData.MaxMachineLoad), TagType = "MAXMACHINELOAD" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TMINMACHINELOAD + offset), Value = Convert.ToString(tunnelGeneralData.MinMachineLoad), TagType = "MINMACHINELOAD" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TUSEME1OFGROUP + offset), Value = Convert.ToString(tunnelGeneralData.UseMe1OfGroup), TagType = "USEME1OFGROUP" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TUSEME2OFGROUP + offset), Value = Convert.ToString(tunnelGeneralData.UseMe2OfGroup), TagType = "USEME2OFGROUP" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIXAFTER + offset), Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamixAfter), TagType = "AUTORINSEDESAMIXAFTER" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIX1FOR + offset), Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamix1For * 10), TagType = "AUTORINSEDESAMIX1FOR" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIX2FOR + offset), Value = Convert.ToString(tunnelGeneralData.AutoRinseDesamix2For * 10), TagType = "AUTORINSEDESAMIX2FOR" });

                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TPROGRAMNUMBER + (tunnelGeneralData.LfsWasher - 1)), Value = Convert.ToString(tunnelGeneralData.ProgramNumber), TagType = "PROGRAMNUMBER" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + PLCXL2TWEIGHTCORRECTIONFCC, Value = Convert.ToString(tunnelGeneralData.WeightCorrectionFcc).ToLower() == "true" ? "1" : "0", TagType = "WEIGHTCORRECTIONFCC" });

                    var offset3 = (tunnelGeneralData.LfsWasher - 1) * 3;
                    tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE1 + offset3), Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe1).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE1" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE2 + offset3), Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe2).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE2" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE3 + offset3), Value = Convert.ToString(tunnelGeneralData.TemperatureAlarmProbe3).ToLower() == "true" ? "1" : "0", TagType = "TEMPERATUREALARMPROBE3" });
                    tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TDATEANDTIMEWHENBATCHEJECTS + (tunnelGeneralData.LfsWasher - 1)), Value = Convert.ToString(tunnelGeneralData.DateAndTimeWhenBatchEjects).ToLower() == "true" ? "1" : "0", TagType = "DATEANDTIMEWHENBATCHEJECTS" });

                    var offset2 = (tunnelGeneralData.LfsWasher - 1) * 50;
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TNOOFCOMPARTMENTS + offset2), Value = Convert.ToString(tunnelGeneralData.NoofCompartments), TagType = "NOOFCOMPARTMENTS" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TNUMBEROFCOMPARTMENTSCONVEYORBELT + offset2), Value = Convert.ToString(tunnelGeneralData.NumberOfCompartmentsConveyorBelt), TagType = "NUMBEROFCOMPARTMENTSCONVEYORBELT" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TWASHERMODE + offset2), Value = Convert.ToString(Convert.ToInt32(washerModelNumber) * 10), TagType = "WASHERMODE" });
                    tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TTUNINTOMMODE + offset2), Value = Convert.ToString(tunnelGeneralData.TunInTomMode).ToLower() == "true" ? "1" : "0", TagType = "TUNINTOMMODE" });

                    if (prevTunnelGeneralModelData != null)
                    {
                        if (tunnelGeneralData.LfsWasher != prevTunnelGeneralModelData.LfsWasher)
                        {
                            var prevTunneloffset = (prevTunnelGeneralModelData.LfsWasher - 1) * 15;
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TMAXMACHINELOAD + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TMINMACHINELOAD + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TUSEME1OFGROUP + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TUSEME2OFGROUP + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIXAFTER + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIX1FOR + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TAUTORINSEDESAMIX2FOR + prevTunneloffset), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TPROGRAMNUMBER + (prevTunnelGeneralModelData.LfsWasher - 1)), Value = "0" });
                            var prevTunneloffset3 = (prevTunnelGeneralModelData.LfsWasher - 1) * 3;
                            tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE1 + prevTunneloffset3), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE2 + prevTunneloffset3), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TTEMPERATUREALARMPROBE3 + prevTunneloffset3), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "L" + (PLCXL2TDATEANDTIMEWHENBATCHEJECTS + (prevTunnelGeneralModelData.LfsWasher - 1)), Value = "0" });
                            var prevTunneloffset2 = (prevTunnelGeneralModelData.LfsWasher - 1) * 50;
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TNOOFCOMPARTMENTS + prevTunneloffset2), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TNUMBEROFCOMPARTMENTSCONVEYORBELT + prevTunneloffset2), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TWASHERMODE + prevTunneloffset2), Value = "0" });
                            tagsList.Add(new MitsubishiTag { Address = "R" + (PLCXL2TTUNINTOMMODE + prevTunneloffset2), Value = "0" });
                        }
                    }
                }
            }

            return tagsList;
        }

        /// <summary>
        /// Validates the tunnel general tags.
        /// </summary>
        /// <param name="tunneldata">The tunnel data.</param>
        /// <param name="ambiguousTagsList">The ambiguous tags list.</param>
        private void ValidateTunnelGeneralTags(TunnelGeneralModel tunneldata, List<string> ambiguousTagsList)
        {
            if (ambiguousTagsList.Count > 0)
            {
                if (ambiguousTagsList.Contains("MAXMACHINELOAD"))
                {
                    tunneldata.IsValueDiffforMaxMachineLoad = true;
                }
                if (ambiguousTagsList.Contains("MINMACHINELOAD"))
                {
                    tunneldata.IsValueDiffforMinMachineLoad = true;
                }
                if (ambiguousTagsList.Contains("USEME1OFGROUP"))
                {
                    tunneldata.IsValueDiffforUseMe1OfGroup = true;
                }
                if (ambiguousTagsList.Contains("USEME2OFGROUP"))
                {
                    tunneldata.IsValueDiffforUseMe2OfGroup = true;
                }
                if (ambiguousTagsList.Contains("AUTORINSEDESAMIXAFTER"))
                {
                    tunneldata.IsValueDiffforAutoRinseDesamixAfter = true;
                }
                if (ambiguousTagsList.Contains("AUTORINSEDESAMIX1FOR"))
                {
                    tunneldata.IsValueDiffforAutoRinseDesamix1For = true;
                }
                if (ambiguousTagsList.Contains("AUTORINSEDESAMIX2FOR"))
                {
                    tunneldata.IsValueDiffforAutoRinseDesamix2For = true;
                }
                if (ambiguousTagsList.Contains("PROGRAMNUMBER"))
                {
                    tunneldata.IsValueDiffforProgramNumber = true;
                }
                if (ambiguousTagsList.Contains("WEIGHTCORRECTIONFCC"))
                {
                    tunneldata.IsValueDiffforWeightCorrectionFcc = true;
                }
                if (ambiguousTagsList.Contains("TEMPERATUREALARMPROBE1"))
                {
                    tunneldata.IsValueDiffforTemperatureAlarmProbe1 = true;
                }
                if (ambiguousTagsList.Contains("TEMPERATUREALARMPROBE2"))
                {
                    tunneldata.IsValueDiffforTemperatureAlarmProbe2 = true;
                }
                if (ambiguousTagsList.Contains("TEMPERATUREALARMPROBE3"))
                {
                    tunneldata.IsValueDiffforTemperatureAlarmProbe3 = true;
                }
                if (ambiguousTagsList.Contains("DATEANDTIMEWHENBATCHEJECTS"))
                {
                    tunneldata.IsValueDiffforDateAndTimeWhenBatchEjects = true;
                }
                if (ambiguousTagsList.Contains("NOOFCOMPARTMENTS"))
                {
                    tunneldata.IsValueDiffforNoofCompartments = true;
                }
                if (ambiguousTagsList.Contains("NUMBEROFCOMPARTMENTSCONVEYORBELT"))
                {
                    tunneldata.IsValueDiffforNumberOfCompartmentsConveyorBelt = true;
                }
                if (ambiguousTagsList.Contains("WASHERMODE"))
                {
                    tunneldata.IsValueDiffforMode = true;
                }
                if (ambiguousTagsList.Contains("TUNINTOMMODE"))
                {
                    tunneldata.IsValueDiffforTunInTomMode = true;
                }
            }
        }

        /// <summary>
        /// Builds the PLCXL tunnel analogue tags.
        /// </summary>
        /// <param name="analogueDosingData">The Analogue Dosing Data data.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>
        /// Returns list of tags.
        /// </returns>
        private List<Tag> BuildPLCXLTunnelAnalogueTags(List<Models.Washers.Tunnel.AnalogueDosing> analogueDosingData, int tunnelNumber, int controllerTypeId)
        {
            List<Tag> tagAnalogue = new List<Tag>();
            int getphStartIndex = controllerTypeId == 13 ? 75 : (tunnelNumber == 1 ? 350 : 374);
            int getlhStartIndex = controllerTypeId == 13 ? 50 : (tunnelNumber == 1 ? 50 : 74);
            int setpointMultiplier = 0;
            int itemIndex = 0, levelIndex = 0, indexAnalogControlLevelId = 0;
            if (analogueDosingData.Count() > 0)
                indexAnalogControlLevelId = analogueDosingData[0].AnalogControlLevelId - 1;
            PropertyInfo[] properties;
            foreach (var item in analogueDosingData)
            {
                properties = item.GetType().GetProperties();
                setpointMultiplier = item.AnalogControlLevelTypeId == 1 ? 10 : 100;
                foreach (var property in properties)
                {
                    switch (property.Name.ToUpper())
                    {
                        case "SETPOINT":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.SetPoint * setpointMultiplier)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "SETPOINT"
                            });
                            itemIndex++;
                            break;
                        case "PREQUANTITY":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.PreQuantity)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "PREQUANTITY"
                            });
                            itemIndex++;
                            break;
                        case "PREPAUSETIME":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.PrePauseTime * PREPAUSETIMEMULTIPLIER)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "PREPAUSETIME"
                            });
                            itemIndex++;
                            break;
                        case "QUANTITY":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.Quantity)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "QUANTITY"
                            });
                            itemIndex++;
                            break;
                        case "PAUSETIME":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.PauseTime * PAUSETIMEMULTIPLIER)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "PAUSETIME"
                            });
                            itemIndex++;
                            break;
                        case "MAXTIME":
                            tagAnalogue.Add(new MitsubishiTag
                            {
                                Address = string.Format("R{0}", (item.AnalogControlLevelTypeId == 1 ? getphStartIndex : getlhStartIndex) + itemIndex + levelIndex),
                                Value = Convert.ToString(Convert.ToInt32(item.MaxTime * MAXTIMEMULTIPLIER)),
                                TagId = item.AnalogControlLevelTypeId,
                                TagTypeId = item.AnalogControlLevelId - indexAnalogControlLevelId,
                                TagType = "MAXTIME"
                            });
                            break;
                    }
                }
                levelIndex += 8;
                itemIndex = 0;
                if (item.AnalogControlLevelTypeId == 1 && item.Level == 3)
                    levelIndex = 0;
            }

            return tagAnalogue;
        }

        /// <summary>
        /// Builds the PLCXL tunnel analogue overrides.
        /// </summary>
        /// <param name="analogueDosingData">The LST data.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>Returns list of Analogue Dosing data.</returns>
        private List<Models.Washers.Tunnel.AnalogueDosing> BuildPLCXLTunnelAnalogueOverrides(List<Models.Washers.Tunnel.AnalogueDosing> analogueDosingData, int tunnelNumber, int controllerId, int controllerTypeId)
        {
            var plc = new PlcTagController(plcService, UserService, PlantService);
            var appTags = BuildPLCXLTunnelAnalogueTags(analogueDosingData, tunnelNumber, controllerTypeId);
            var plcBuildTags = BuildPLCXLTunnelAnalogueTags(analogueDosingData, tunnelNumber, controllerTypeId);
            var plcTags = plc.ValidateTags(new TagCollection { Tags = plcBuildTags }, controllerId, SourcePage.TunnelAnaloguePage);
            var ambiguousTags = new List<Tag>();
            int indexAnalogControlLevelId = 0;
            if (analogueDosingData.Count() > 0)
                indexAnalogControlLevelId = analogueDosingData[0].AnalogControlLevelId - 1;
            foreach (var appTag in appTags)
            {
                foreach (Tag plcTag in plcTags.Tags)
                {
                    if (appTag.Address == plcTag.Address && appTag.Value != plcTag.Value)
                    {
                        ambiguousTags.Add(appTag);
                    }
                }
            }
            foreach (var item in analogueDosingData)
            {
                item.IsValueDiffForSetPoint = ambiguousTags.Where(x => x.TagType.ToUpper() == "SETPOINT" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
                item.IsValueDiffForPreQuantity = ambiguousTags.Where(x => x.TagType.ToUpper() == "PREQUANTITY" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
                item.IsValueDiffForPrePauseTime = ambiguousTags.Where(x => x.TagType.ToUpper() == "PREPAUSETIME" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
                item.IsValueDiffForQuantity = ambiguousTags.Where(x => x.TagType.ToUpper() == "QUANTITY" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
                item.IsValueDiffForPauseTime = ambiguousTags.Where(x => x.TagType.ToUpper() == "PAUSETIME" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
                item.IsValueDiffForMaxTime = ambiguousTags.Where(x => x.TagType.ToUpper() == "MAXTIME" && x.TagTypeId == (item.AnalogControlLevelId - indexAnalogControlLevelId)).Count() > 0 ? true : false;
            }

            return analogueDosingData;
        }
    }
}