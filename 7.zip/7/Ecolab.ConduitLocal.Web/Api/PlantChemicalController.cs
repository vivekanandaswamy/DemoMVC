﻿// -----------------------------------------------------------------------
// <copyright file="PlantChemicalController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Plant Chemical Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Web.Http;
	using AutoMapper;
	using Castle.Core.Logging;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Ecolab.Models.WasherGroup;
	using Ecolab.Services.Interfaces.WasherGroup;
	using Elmah;
	using Mapper;
	using Models;
	using Services.Interfaces;
    using Model = Ecolab.Models.PlantSetup.Chemical;
	using WebModel = Models.PlantSetup.Chemical;

	/// <summary>
	///     class Plant Chemical Controller
	/// </summary>
	public class PlantChemicalController : BaseApiController
	{
		/// <summary>
		///     Product Master Service(Plant chemical)
		/// </summary>
		private readonly IProductMasterService prodMastService;

		/// <summary>
		/// Washer Group Service
		/// </summary>
		private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantChemicalController"/> class.
        /// </summary>
        /// <param name="userService">The user service</param>
        /// <param name="prodMastService">The product master service</param>
        /// <param name="plantService">The Plant Service</param>
        /// <param name="washerGroupService">The Washer group service</param>
        public PlantChemicalController(IUserService userService, IProductMasterService prodMastService, IPlantService plantService, IWasherGroupService washerGroupService) : base(userService, plantService)
		{
			this.prodMastService = prodMastService;
			this.washerGroupService = washerGroupService;
		}

		/// <summary>
		///     Gets or sets the logger.
		/// </summary>
		/// <value>The logger.</value>
		public ILogger Logger { get; set; }

		/// <summary>
		///     Get the plant chemical details
		/// </summary>
		/// <returns>List of ProductMasterModel</returns>
		[HttpGet]
		public IEnumerable<ProductMasterModel> GetPlantChemical()
		{
			List<Model.ProductMaster> plantChem = this.prodMastService.FetchPlantChemicalList(this.EcolabAccountNumber);
			List<ProductMasterModel> plantChemList = plantChem.Select(EntityConverter.ConvertToWebModel).ToList();
			plantChemList.ForEach(_ => _.CostAsString = _.Cost.ToString("#,0.##"));
			foreach (var item in plantChemList)
			{
				if (!string.IsNullOrEmpty(item.PackagingSize))
				{
					item.PackagingSize = item.UnitPerPackage + "-" + Math.Round(item.UnitWeightVolume.GetValueOrDefault()) + " " + item.UnitWeightVolumeUOMCode;
				}
			}
			return plantChemList.AsEnumerable();
		}

		/// <summary>
		///     Gets the ChemicalsList
		/// </summary>
		/// <param name="term">Search term to get matching chemicals</param>
		/// <returns>List of ChemicalsModel</returns>
		[HttpGet]
		public IEnumerable<WebModel.ChemicalsModel> GetChemicalList(string term)
		{
			PlantModel plantDetails = this.GetPlantDetails();
			List<Model.Chemicals> chemicals = this.prodMastService.FetchChemicalList(term, plantDetails.EcoalabAccountNumber);
			List<WebModel.ChemicalsModel> chemicalList =
				Mapper.Map<List<Model.Chemicals>, List<WebModel.ChemicalsModel>>(chemicals);

			return chemicalList;
		}

		/// <summary>
		///     creates new the Chemical data
		/// </summary>
		/// <param name="data">Chemical data to create</param>
		/// <returns>Returns Success or failure response Message</returns>
		[HttpPost]
        public HttpResponseMessage CreateChemical([FromBody] List<ProductMasterModel> data)
		{
			try
			{
				data[0].EcolabAccountNumber = this.EcolabAccountNumber;
                data[0].Volume = "0";
                data[0].Weight = "0";
				DateTime lastModifiedTimeStamp;
				Model.ProductMaster objChemical = Mapper.Map<ProductMasterModel, Model.ProductMaster>(data[0]);

				int result = this.prodMastService.SavePlantChemicalDetails(objChemical, this.UserId, out lastModifiedTimeStamp);
				objChemical.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
				objChemical.Id = result;

				switch (result)
				{
					case 51030:
						return this.Request.CreateResponse(HttpStatusCode.BadRequest, 51030);
				}

				Push.PushToQueue(objChemical, this.UserId, objChemical.Id, (int)TcdAdminMessageTypes.TcdAddPlantChemical,
					this.EcolabAccountNumber);
			}
			catch (Exception ex)
			{
				this.Logger.Error("Api - Chemical - Create Error :", ex);
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Chemical adding failed.");
			}

			return this.Request.CreateResponse(HttpStatusCode.OK, data);
		}

		/// <summary>
		///     Update plant chemical
		/// </summary>
		/// <param name="productId">Chemical Id in My Serice</param>
		/// <param name="data">The Product Master Model</param>
		/// <returns>Returns Success or failure response Message</returns>
		[HttpPut]
		public HttpResponseMessage Put(int productId, ProductMasterModel data)
		{
			try
			{
				data.EcolabAccountNumber = this.EcolabAccountNumber;
				DateTime lastModifiedTimeStamp;
				if (!data.IncludeinCI)
				{
					data.InventoryExpense = null;
				}
				else if (string.IsNullOrEmpty(data.InventoryExpense))
				{
					data.InventoryExpense = "I";
				}

				Model.ProductMaster objChemical = Mapper.Map<ProductMasterModel, Model.ProductMaster>(data);
				objChemical.Id = productId;
				objChemical.Id = this.prodMastService.UpdateChemicalDetails(objChemical, this.UserId, out lastModifiedTimeStamp);
				// Need to change this according to SP
				objChemical.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
				data.CostAsString = data.Cost.ToString("#,0.##");
				Push.PushToQueue(objChemical, this.UserId, objChemical.Id, (int)TcdAdminMessageTypes.TcdUpdatePlantChemical,
					this.EcolabAccountNumber);
			}
			catch (Exception ex)
			{
				this.Logger.Error("Api - Plant Chemical - Update Error :", ex);
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return this.Request.CreateResponse(HttpStatusCode.BadRequest,
					"Unable to update the plant chemical. Some error has occured. Please try again.");
			}

			return this.Request.CreateResponse(HttpStatusCode.OK, data);
		}

		/// <summary>
		///     Update plant chemical
		/// </summary>
		/// <param name="data">The Product Master Model</param>
		/// <returns>Returns Success or failure response Message</returns>
		public HttpResponseMessage Put(List<ProductMasterModel> data)
		{
            HttpResponseMessage status= new HttpResponseMessage();
		 
            foreach (var item in data)
		{
              status = this.Put(item.ProductId, item);
            }

            return status;
		}

		/// <summary>
		///     Delete the Chemical based on Id
		/// </summary>
		/// <param name="id">Delete the chemical</param>
		/// <param name="data">Product Master Model data</param>
		/// <returns>Returns Success or failure response Message</returns>
		[HttpDelete]
		public HttpResponseMessage DeleteChemical(int? id, ProductMasterModel data)
		{
			try
			{
				DateTime lastModifiedTimeStamp;
				Model.ProductMaster objChemical = EntityConverter.ConvertToServiceModel(data);

				if (id != null)
				{
					objChemical.Id = id.Value;
				}
				objChemical.IsDelete = true;
				objChemical.EcolabAccountNumber = this.EcolabAccountNumber;

				this.prodMastService.DeleteChemicalDetails(objChemical, this.UserId, out lastModifiedTimeStamp);
				objChemical.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

				objChemical.Id = data.Id;
				Push.PushToQueue(objChemical, this.UserId, id.Value, (int)TcdAdminMessageTypes.TcdDeletePlantChemical,
					this.EcolabAccountNumber);
			}
			catch (Exception ex)
			{
				this.Logger.Error("Api - Chemical - Delete Error :", ex);
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return this.Request.CreateResponse(HttpStatusCode.BadRequest,
					"Unable to delete the chemical. Some error has occured. Please try again.");
			}

			return this.Request.CreateResponse(HttpStatusCode.OK, id);
		}

		/// <summary>
		///     Delete the Meter data
		/// </summary>
		/// <param name="data">Chemical data to be deleted</param>
		/// <returns>Returns Success or failure response Message</returns>
        public HttpResponseMessage DeleteChemical(List<ProductMasterModel> data)
		{
			return this.DeleteChemical(data[0].ProductId, data[0]);
		}

		/// <summary>
		///     Get all the values related to Plant setup
		/// </summary>
		/// <returns>Returns the plant model</returns>
		[HttpGet]
		public IEnumerable<Models.WasherGroup.WasherGroup> GetWasherGroupList()
		{
			IEnumerable<WasherGroup> washerGroupModel = this.washerGroupService.GetWasherGroupDetails(-1, this.EcolabAccountNumber, 0, 0, string.Empty);
			IEnumerable<Models.WasherGroup.WasherGroup> washerGroups = Mapper.Map<IEnumerable<WasherGroup>, IEnumerable<Models.WasherGroup.WasherGroup>>(washerGroupModel);

			var result = from item in washerGroups
						 select new Models.WasherGroup.WasherGroup
						 {
							 EcolabAccountNumber = item.EcolabAccountNumber,
							 Id = item.Id,
							 IsDelete = item.IsDelete,
							 LastModifiedTimeStamp = item.LastModifiedTimeStamp,
							 LastSyncTime = item.LastSyncTime,
							 MaxNumberOfRecords = item.MaxNumberOfRecords,
							 MyServiceLastModifiedTime = item.MyServiceLastModifiedTime,
							 MyServiceWasherGroupGuid = item.MyServiceWasherGroupGuid,
							 MyServiceWasherGroupNumber = item.MyServiceWasherGroupNumber,
							 RowNumber = item.RowNumber,
							 RowTotalCount = item.RowTotalCount,
							 WasherGroupDescription = item.WasherGroupDescription,
							 WasherGroupId = item.WasherGroupId,
							 WasherGroupName = item.WasherGroupName,
							 WasherGroupNumber = item.WasherGroupNumber,
							 WasherGroupNumberInt = Convert.ToInt32(item.WasherGroupNumber),
							 WasherGroupTypeId = item.WasherGroupTypeId,
							 WasherGroupTypeName = item.WasherGroupTypeName,
							 ControllerCount = item.ControllerCount,
							 ControllerId = item.ControllerId,
							 ControllerModelId = item.ControllerModelId,
							 ControllerTypeId = item.ControllerTypeId
						 };
			return result.OrderBy(x => x.WasherGroupNumberInt);
		}

		/// <summary>
		///     Get the plant chemical details
		/// </summary>
        /// <param name="washerGroupId">Washer group identifier.</param>
		/// <returns>List of ProductMasterModel</returns>
		[HttpGet]
		public IEnumerable<WebModel.ChemicalsModel> GetUnUsedPlantChemicalList(int washerGroupId)
		{
			List<Model.Chemicals> chemicals = this.prodMastService.GetUnUsedPlantChemicalList(this.EcolabAccountNumber, washerGroupId).OrderBy( x => x.Name).ToList() ;
			List<WebModel.ChemicalsModel> chemicalList =
				Mapper.Map<List<Model.Chemicals>, List<WebModel.ChemicalsModel>>(chemicals);

			return chemicalList;
		}

		/// <summary>
		///     Check whether new product is used by any other washer group
		/// </summary>
		/// <param name="data">Chemical data to create</param>
		/// <returns>Responce Message</returns>
		[HttpPost]
		public WebModel.SubstituteChemicalModel CheckWasherGroupForProduct(WebModel.SubstituteChemicalModel data)
		{
			try
			{
				data.EcolabAccountNumber = this.EcolabAccountNumber;

				data.WasherGroupIds = this.prodMastService.CheckWasherGroupForProduct(data.WasherGroupId, data.EcolabAccountNumber);
				data.WasherGroupIds.Remove(data.WasherGroupId);

			}
			catch (Exception ex)
			{
				this.Logger.Error("Api - Chemical - CheckWasherGroupForProduct Error :", ex);
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return null;
			}

			return data;
		}

		/// <summary>
		///     update the old chemical with new chemical
		/// </summary>
		/// <param name="data">Chemical data to update</param>
		/// <returns>Responce Message</returns>
		[HttpPost]
		public HttpResponseMessage SaveSubstitueChemical(WebModel.SubstituteChemicalModel data)
		{
			int result = 0;
			try
			{
				data.EcolabAccountNumber = this.EcolabAccountNumber;
				Model.SubstituteChemical objChemical = Mapper.Map<WebModel.SubstituteChemicalModel, Model.SubstituteChemical>(data);

				result = this.prodMastService.SaveSubstitueChemical(objChemical, this.UserId);

				if (result == 0)
				{
					Push.PushToQueue(objChemical, this.UserId, objChemical.NewProductId, (int)TcdAdminMessageTypes.TcdSubstituteChemical, this.EcolabAccountNumber);
				}
			}
			catch (Exception ex)
			{
				this.Logger.Error("Api - Chemical - SaveSubstitueChemical Error :", ex);
				ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
				return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Substitute Chemical update failed.");
			}

			return this.Request.CreateResponse(HttpStatusCode.OK, result); 
		}

        /// <summary>
        /// creates new the Chemical data
        /// </summary>
        /// <param name="productMasterModel">The product master model.</param>
        /// <returns>
        /// Returns Success or failure response Message
        /// </returns>
		[HttpPost]
        public HttpResponseMessage CreatePumpsChemicalDetails(ProductMasterModel productMasterModel)
        {
            int response = 0;
            try
            {
                productMasterModel.EcolabAccountNumber = this.EcolabAccountNumber;
                productMasterModel.Volume = "0";
                productMasterModel.Weight = "0";
                DateTime lastModifiedTimeStamp;
                Model.ProductMaster objChemical = Mapper.Map<ProductMasterModel, Model.ProductMaster>(productMasterModel);

                response = this.prodMastService.SavePlantChemicalDetails(objChemical, this.UserId, out lastModifiedTimeStamp);
                objChemical.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                objChemical.Id = response;              

                Push.PushToQueue(objChemical, this.UserId, objChemical.Id, (int)TcdAdminMessageTypes.TcdAddPlantChemical,
                    this.EcolabAccountNumber);

                response = 0;
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Chemical - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ++response);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}