﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Controller Setup Controller </summary>
// -----------------------------------------------------------------------

using Ecolab.ConduitLocal.Web.Utilities;

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.ControllerSetup;
    using Elmah;
    using Models.ControllerSetup;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Plc;
    using Controller = Ecolab.Models.ControllerSetup.Controller;
    using ControllerModel = Models.ControllerSetup.ControllerModel;
    using ControllerType = Ecolab.Models.ControllerSetup.ControllerType;
    using EntityConverter = ConduitLocal.Web.Mapper.EntityConverter;
    using TagsModel = Dcs.Entities.OpcTag;
    using Models.Common;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     class ControllerSetup Controller
    /// </summary>
    public class ControllerSetupController : BaseApiController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="controllerSetupService">The Controller Setup service.</param>
        public ControllerSetupController(IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService)
            : base(userService, plantService)
        {
            this.controllerSetupService = controllerSetupService;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="controllerSetupService">The Controller Setup service.</param>
        /// <param name="plcService"> PLC service.</param>
        public ControllerSetupController(IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.controllerSetupService = controllerSetupService;
            this.plcService = plcService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get Controller Setup Meta Data
        /// </summary>
        /// <param name="tabId">Tab Id</param>
        /// <param name="controllerModelId">controller Model Id</param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <returns>Returns the Controller Setup Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupMetaData(int tabId, int controllerModelId, int controllerTypeId)
        {
            List<MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadata(tabId, controllerModelId, controllerTypeId, this.RoleId);
            List<MetaDataModel> controllerSetupMetaData = Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
            return controllerSetupMetaData;
        }

        /// <summary>
        ///     Get Controller Setup Meta Data with Values
        /// </summary>
        /// <param name="tabId">Tab Id</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns the Controller Setup Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupMetaDataWithValues(int tabId, int controllerId)
        {
            List<MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(tabId, controllerId, this.EcolabAccountNumber, this.RoleId);
            List<MetaDataModel> controllerSetupMetaData = Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
            foreach (MetaDataModel metaDataModel in controllerSetupMetaData)
            {
                int fieldCount = metaDataModel.FieldGroupInfo.Count();
                for (int i = 0; i < fieldCount; i++)
                {
                    if (metaDataModel.FieldGroupInfo.ElementAt(i).FieldType == "DATETIME")
                    {
                        if (!string.IsNullOrEmpty(metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue))
                        {
                            DateTime installDate = DateTime.ParseExact(metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue, "d", CultureInfo.InvariantCulture);
                            metaDataModel.FieldGroupInfo.ElementAt(i).FieldDefaultValue = installDate.ToString("d");
                        }
                    }
                    if (metaDataModel.FieldGroupInfo != null && metaDataModel.FieldGroupInfo.Count > 0 && metaDataModel.FieldGroupInfo[0].ControllerModelId == 7)
                    {
                        var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                        List<BeckhoffTag> appTags = new List<BeckhoffTag>();
                        List<BeckhoffTag> plcTags = new List<BeckhoffTag>();
                        List<string> tagCollectionList = new List<string>();
                        appTags = GenerateMyControlGeneralTags(metaDataModel);

                        if (appTags != null)
                        {
                            plcTags = plc.ValidateMyControlTags(appTags, controllerId, SourcePage.ControllerSetupGeneralPage);
                        }
                        appTags = GenerateMyControlGeneralTags(metaDataModel);
                        foreach (BeckhoffTag tag in appTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) || _.TagItemType == UIInputType.TypeString))
                        {
                            foreach (Tag plcTag in plcTags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) || _.TagItemType == UIInputType.TypeString))
                            {
                                if (tag.Address == plcTag.Address && tag.Value.ToLower() != plcTag.Value.ToLower())
                                {
                                    tagCollectionList.Add(tag.Address);
                                }
                            }
                        }
                        if (tagCollectionList.Count > 0)
                        {
                            if (tagCollectionList.Contains(".str_CustomerName"))
                            {
                                for (int j = 0; j < controllerSetupMetaData.Count; j++)
                                {
                                    foreach (ControllerSetupMetaDataModel metaData in controllerSetupMetaData[j].FieldGroupInfo)
                                    {
                                        if (metaData.FieldId == 212)
                                        {
                                            metaData.OverrideValues = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (controllerSetupService.IsSetupAdvanceDataExist(3, controllerId, EcolabAccountNumber))
            {
                controllerSetupMetaData[0].HasPumps = true;
            }
            return controllerSetupMetaData;
        }

        /// <summary>
        ///     Get Controller Details
        /// </summary>
        /// <returns>Returns the Controller Details</returns>
        public IEnumerable<ControllerModel> GetControllerDetails()
        {
            List<Controller> controllerModel = this.controllerSetupService.GetControllerDetails(EcolabAccountNumber, null, null).ToList();
            List<ControllerModel> controller = Mapper.Map<List<Controller>, List<ControllerModel>>(controllerModel);
            controller = controller.Where(item => item.IsDelete == false).ToList();
            controller.ForEach(_ => _.InstallDateAsString = _.InstallDate.ToString("d"));
            return controller.OrderBy(x => x.ControllerNumber);
        }

        /// <summary>
        ///     Get Controller Details By Id.
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <returns>Controller model</returns>
        public ControllerModel GetControllerDetailById(int controllerId, string ecolabAccountNumber)
        {
            Controller controllerModel = this.controllerSetupService.GetControllerDetailById(controllerId, ecolabAccountNumber);
            ControllerModel controller = Mapper.Map<Controller, ControllerModel>(controllerModel);
            controller.InstallDateAsString = controller.InstallDate.ToString("d");
            return controller;
        }

        /// <summary>
        ///     Get Controller Setup Advance Meta Data/Values
        /// </summary>
        /// <param name="tabId">Tab Identifier</param>
        /// <param name="controllerId">controller Id</param>
        /// <returns>Returns the Controller Setup Advance Meta Data Model</returns>
        public List<MetaDataModel> GetControllerSetupAdvanceMetaData(int tabId, int controllerId)
        {
            List<MetaData> controllerSetupMetaDataModel;
            bool hasPumps = false;
            List<string> tagCollectionList = new List<string>();
            string message = string.Empty;
            if (controllerSetupService.IsSetupAdvanceDataExist(tabId, controllerId, EcolabAccountNumber))
            {
                hasPumps = true;
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
                List<OpcTag> tagsList = null;
                List<OpcTag> tags = null;
                List<BeckhoffTag> tagsList1 = null;
                List<BeckhoffTag> tags1 = null;
                List<MitsubishiTag> tagsList2 = null;
                List<MitsubishiTag> tags2 = null;
                TagCollection tagStatus = new TagCollection { Tags = new List<Tag>() };

                controllerSetupMetaDataModel = controllerSetupService.GetControllerSetupAdvanceMetadataWithValues(
                    tabId, controllerId, EcolabAccountNumber);
                var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, controllerId);
                bool awea = fieldTags.AWEActive == true ? true : false;
                bool ratioDosing = fieldTags.RatioDosingActive == true ? true : false;
                var aweaFields = controllerSetupMetaDataModel.FirstOrDefault().FieldGroupInfo.Where(x => x.FieldResourceKey.Trim().ToLower() == "Automatic_Weight_Enabled".ToLower());
                if (aweaFields.Any())
                {
                    aweaFields.FirstOrDefault().FieldDefaultValue = awea.ToString().ToLower();
                }
                var ratioDosingFields = controllerSetupMetaDataModel.FirstOrDefault().FieldGroupInfo.Where(x => x.FieldResourceKey.Trim().ToLower() == "Ratio_Dosing_Enabled".ToLower());
                if (ratioDosingFields.Any())
                {
                    ratioDosingFields.FirstOrDefault().FieldDefaultValue = ratioDosing.ToString().ToLower();
                }
                IEnumerable<ControllerSetupMetaData> controllerTags = new List<ControllerSetupMetaData>();
                if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 7 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8)
                {
                    foreach (MetaData item in controllerSetupMetaDataModel)
                    {
                        for (int i = 0; i < item.FieldGroupInfo.Count(); i++)
                        {
                            if (item.FieldGroupInfo[0].ControllerModelId == 7)
                            {
                                item.FieldGroupInfo[i].TagDefaultValue = GetDefaultTagValues(item.FieldGroupInfo[i].HasFieldTag);   // Updates the TagDefaultValue for myControl

                                if (item.FieldGroupInfo[i].FieldType == "CHECKBOX")
                                {
                                    if (item.FieldGroupInfo[i].FieldDefaultValue == "0")
                                    {
                                        item.FieldGroupInfo[i].FieldDefaultValue = "false";
                                    }
                                    if (item.FieldGroupInfo[i].FieldDefaultValue == "1")
                                    {
                                        item.FieldGroupInfo[i].FieldDefaultValue = "true";
                                    }
                                }
                            }
                            else if (item.FieldGroupInfo[0].ControllerModelId == 11)
                            {
                                if (!string.IsNullOrEmpty(item.FieldGroupInfo[i].HasFieldTag) && item.FieldGroupInfo[i].FieldId != 214 && item.FieldGroupInfo[i].FieldId != 215 && item.FieldGroupInfo[i].FieldId != 216 && item.FieldGroupInfo[i].FieldId != 407 && item.FieldGroupInfo[i].FieldId != 474 && item.FieldGroupInfo[i].FieldId != 475)
                                {
                                    item.FieldGroupInfo[i].TagDefaultValue = item.FieldGroupInfo[0].ControllerModelId == 11 ? item.FieldGroupInfo[i].TagDefaultValue :
                                   item.FieldGroupInfo[i].HasFieldTag.Replace("Tag_", string.Empty);
                                }
                                else
                                {
                                    if (item.FieldGroupInfo[i].FieldId == 214 && item.FieldGroupInfo[0].ControllerModelId == 11)
                                    {
                                        item.FieldGroupInfo[i].TagDefaultValue = "L94";
                                    }
                                    else if (item.FieldGroupInfo[i].FieldId == 474 && item.FieldGroupInfo[0].ControllerModelId == 11)
                                    {
                                        item.FieldGroupInfo[i].TagDefaultValue = "D775";
                                    }
                                    else if (item.FieldGroupInfo[i].FieldId == 475 && item.FieldGroupInfo[0].ControllerModelId == 11)
                                    {
                                        item.FieldGroupInfo[i].TagDefaultValue = "D774";
                                    }
                                }

                                if (item.FieldGroupInfo[0].ControllerTypeId == 12)
                                    {
                                    if (item.FieldGroupInfo[i].FieldType == "TEXT" && (item.FieldGroupInfo[i].FieldId == 474 || item.FieldGroupInfo[i].FieldId == 475 || item.FieldGroupInfo[i].FieldId == 355 || item.FieldGroupInfo[i].FieldId == 368 || item.FieldGroupInfo[i].FieldId == 370))
                                    {
                                        item.FieldGroupInfo[i].FieldDefaultValue = (Convert.ToDecimal(item.FieldGroupInfo[i].FieldDefaultValue) / 10).ToString();
                                    }
                                }
                                else if (item.FieldGroupInfo[0].ControllerTypeId == 13)
                                {
                                    if (item.FieldGroupInfo[i].FieldType == "TEXT" && (item.FieldGroupInfo[i].FieldId == 474 || item.FieldGroupInfo[i].FieldId == 475 || item.FieldGroupInfo[i].FieldId == 316 || item.FieldGroupInfo[i].FieldId == 329 || item.FieldGroupInfo[i].FieldId == 331))
                                    {
                                        item.FieldGroupInfo[i].FieldDefaultValue = (Convert.ToDecimal(item.FieldGroupInfo[i].FieldDefaultValue) / 10).ToString();
                                    }
                                }
                                else if (item.FieldGroupInfo[0].ControllerTypeId == 14)
                                {
                                    if (item.FieldGroupInfo[i].FieldType == "TEXT" && (item.FieldGroupInfo[i].FieldId == 474 || item.FieldGroupInfo[i].FieldId == 475 || item.FieldGroupInfo[i].FieldId == 277 || item.FieldGroupInfo[i].FieldId == 290 || item.FieldGroupInfo[i].FieldId == 292))
                                    {
                                        item.FieldGroupInfo[i].FieldDefaultValue = (Convert.ToDecimal(item.FieldGroupInfo[i].FieldDefaultValue) / 10).ToString();
                                    }
                                }

                                if (item.FieldGroupInfo[i].FieldDefaultValue == "0" && item.FieldGroupInfo[i].FieldType != "TEXT" && (!(item.FieldGroupInfo[i].FieldId == 328 || item.FieldGroupInfo[i].FieldId == 330 || item.FieldGroupInfo[i].FieldId == 289 || item.FieldGroupInfo[i].FieldId == 291 || item.FieldGroupInfo[i].FieldId == 367 || item.FieldGroupInfo[i].FieldId == 369)))
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "false";
                                }
                                if (item.FieldGroupInfo[i].FieldDefaultValue == "1" && item.FieldGroupInfo[i].FieldType != "TEXT" && (!(item.FieldGroupInfo[i].FieldId == 328 || item.FieldGroupInfo[i].FieldId == 330 || item.FieldGroupInfo[i].FieldId == 289 || item.FieldGroupInfo[i].FieldId == 291 || item.FieldGroupInfo[i].FieldId == 367 || item.FieldGroupInfo[i].FieldId == 369)))
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "true";
                                }
                            }
                            else if (item.FieldGroupInfo[0].ControllerModelId == 8)
                            {
                                if (item.FieldGroupInfo[i].FieldId == 214)
                                {
                                    item.FieldGroupInfo[i].TagDefaultValue = "M934";
                                }
                                else if (item.FieldGroupInfo[i].FieldId == 215)
                                {
                                    item.FieldGroupInfo[i].TagDefaultValue = "D463";
                                }
                                else if (item.FieldGroupInfo[i].FieldId == 407)
                                {
                                    item.FieldGroupInfo[i].TagDefaultValue = "D462";
                                }
                                else
                                {
                                    item.FieldGroupInfo[i].TagDefaultValue = item.FieldGroupInfo[i].TagDefaultValue;
                                }
                                if (item.FieldGroupInfo[i].FieldType == "TEXT" && (item.FieldGroupInfo[i].FieldId == 215 || item.FieldGroupInfo[i].FieldId == 407 || item.FieldGroupInfo[i].FieldId == 390 || item.FieldGroupInfo[i].FieldId == 403))
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = (Convert.ToDecimal(item.FieldGroupInfo[i].FieldDefaultValue) / 10).ToString();
                                }
                                if (item.FieldGroupInfo[i].FieldDefaultValue == "0" && item.FieldGroupInfo[i].FieldType != "TEXT")
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "false";
                                }
                                if (item.FieldGroupInfo[i].FieldDefaultValue == "1" && item.FieldGroupInfo[i].FieldType != "TEXT")
                                {
                                    item.FieldGroupInfo[i].FieldDefaultValue = "true";
                                }
                            }
                            if (!string.IsNullOrEmpty(item.FieldGroupInfo[i].DataSourceKeyValue) && item.FieldGroupInfo[i].FieldClassName == "DosingLines")
                            {
                                item.FieldGroupInfo[i].DataSourceKeyValue = "0:0;" + item.FieldGroupInfo[i].DataSourceKeyValue;
                                if (item.FieldGroupInfo[i].DataSourceInfo != null)
                                {
                                    FieldSource fs = new FieldSource();
                                    fs.DataSourceId = 7;
                                    fs.Name = "0";
                                    fs.Value = "0";

                                    item.FieldGroupInfo[i].DataSourceInfo.Insert(0, fs);
                                }
                            }
                        }
                        controllerTags = controllerTags.Concat(item.FieldGroupInfo);
                    }
                }
                if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId != 7 && controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId != 8 && controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId != 11) // Existing Code handling the other controllermodels
                {
                    controllerTags =
                    controllerSetupMetaDataModel[0].FieldGroupInfo.Where(
                        _ => !string.IsNullOrWhiteSpace(_.TagDefaultValue));
                    tagsList = new List<OpcTag>();
                    foreach (ControllerSetupMetaData item in controllerTags)
                    {
                        tagsList.Add(new OpcTag { Address = item.TagDefaultValue, Value = item.FieldDefaultValue });
                    }
                    tags = tagsList.Clone();
                    try
                    {
                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, controllerId);
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    }
                    if (tagStatus != null)
                    {
                        string value = string.Empty;
                        string plcValue = string.Empty;
                        foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                            {
                                if (tag.Address == plcTag.Address && tag.TagItemType == UIInputType.TypeInt && (tag.Value.ToLower().Trim() == "true" || tag.Value.ToLower().Trim() == "false"))
                                {
                                    value = tag.Value.ToLower().Trim() == "true" ? "1" : "0";
                                    plcValue = plcTag.Value.ToLower().Trim() == "true" ? "1" : "0";
                                    if (value != plcValue)
                                        tagCollectionList.Add(tag.Address);
                                }
                                else if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                                {
                                    tagCollectionList.Add(tag.Address);
                                }
                            }
                        }
                    }
                    else
                    {
                        //message = "Unable to Connect to PLC";
                    }
                }
                else
                {
                    if (controllerTags.Any())
                    {
                        // Read of myControl - Beckhoff Tag
                        if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 7)
                        {
                            tagsList1 = new List<BeckhoffTag>();
                            foreach (ControllerSetupMetaData item in controllerTags)
                            {
                                tagsList1.Add(new BeckhoffTag { Address = item.TagDefaultValue, Value = item.FieldDefaultValue });
                            }
                            tags1 = tagsList1.Clone();
                            try
                            {
                                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList1) }, controllerId);
                            }
                            catch (Exception ex)
                            {
                                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                            }
                            if (tagStatus != null)
                            {
                                foreach (Tag plcTag in tagStatus.Tags)
                                {
                                    if ((plcTag.Address == "x_LineDosingMode[1]") || (plcTag.Address == "x_LineDosingMode[2]") || (plcTag.Address == "x_LineDosingMode[3]"))
                                    {
                                        plcTag.Value = (Convert.ToInt32(plcTag.Value) + 1).ToString();
                                    }
                                }
                                foreach (Tag tag in tags1.Where(_ => !string.IsNullOrWhiteSpace(_.Value) && !string.IsNullOrWhiteSpace(_.Address)))
                                {
                                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value) && !string.IsNullOrWhiteSpace(_.Address)))
                                    {
                                        if (tag.Address == plcTag.Address && tag.Value.ToUpper() != plcTag.Value.ToUpper())
                                        {
                                            tagCollectionList.Add(tag.Address);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11 || controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8) // Read of PLC XL and EControlPlus - Mitsubishi Tag
                        {
                            tagsList2 = new List<MitsubishiTag>();
                            foreach (ControllerSetupMetaData item in controllerTags)
                            {
                                tagsList2.Add(new MitsubishiTag { Address = item.TagDefaultValue, Value = item.FieldDefaultValue, TagItemType = (item.FieldType == "CHECKBOX" && (item.FieldId != 328 || item.FieldId != 330 || item.FieldId != 289 || item.FieldId != 291 || item.FieldId != 367 || item.FieldId != 369)) ? UIInputType.TypeBool : UIInputType.TypeInt });
                            }
                            tags2 = tagsList2.Clone();
                            try
                            {
                                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList2) }, controllerId);
                            }
                            catch (Exception ex)
                            {
                                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                            }
                            if (tagStatus != null && tagStatus.Tags.Count > 0)
                            {
                                if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 11)
                                {
                                    if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerTypeId == 12)
                                    {
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D774").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D775").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D776").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R672").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R673").Each(t => t.Value = (Convert.ToInt32(Convert.ToDecimal(t.Value) * 10)).ToString());
                                    }
                                    else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerTypeId == 13)
                                    {
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D774").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D775").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D776").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R3267").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R3268").Each(t => t.Value = (Convert.ToInt32(Convert.ToDecimal(t.Value) * 10)).ToString());
                                    }
                                    else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerTypeId == 14)
                                    {
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D774").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D775").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D776").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R192").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                        tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "R193").Each(t => t.Value = (Convert.ToInt32(Convert.ToDecimal(t.Value) * 10)).ToString());
                                    }
                                }
                                else if (controllerSetupMetaDataModel[0].FieldGroupInfo[0].ControllerModelId == 8)
                                {
                                    tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address != "D461").Each(t => t.Value = (Convert.ToInt32(Convert.ToDouble(t.Value)) * 10).ToString());
                                    tags2.Where(x => x.TagItemType == UIInputType.TypeInt && x.Address == "D461").Each(t => t.Value = (Convert.ToInt32(Convert.ToDecimal(t.Value) * 10)).ToString());
                                }
                                tags2.Where(x => x.TagItemType == UIInputType.TypeBool).Each(t => t.Value = t.Value.ToLower() == "true" ? "1" : "0");
                                foreach (Tag tag in tags2.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                {
                                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                                    {
                                        if (tag.Address == plcTag.Address && tag.Value.ToUpper() != plcTag.Value.ToUpper())
                                        {
                                            tagCollectionList.Add(tag.Address);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                controllerSetupMetaDataModel = controllerSetupService.GetControllerSetupAdvanceMetadata(tabId,
                    controllerId, EcolabAccountNumber);
            }
            List<MetaDataModel> controllerSetupMetaData = AutoMapper.Mapper.Map<List<MetaData>, List<MetaDataModel>>(controllerSetupMetaDataModel);
            if (controllerSetupMetaData != null && controllerSetupMetaData.Count > 0)
            {
                controllerSetupMetaData[0].HasPumps = hasPumps;
                if (tagCollectionList.Count > 0)
                {
                    for (int i = 0; i < controllerSetupMetaData.Count; i++)
                    {
                        foreach (ControllerSetupMetaDataModel metaData in controllerSetupMetaData[i].FieldGroupInfo)
                        {
                            foreach (var item in tagCollectionList.Where(item => metaData.TagDefaultValue == item))
                            {
                                metaData.OverrideValues = true;
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(message))
                {
                    controllerSetupMetaData[0].message = message;
                }
            }
            return controllerSetupMetaData;
        }

        /// <summary>
        /// Gets the default tag values.
        /// </summary>
        /// <param name="tagName">Name of the tag.</param>
        /// <returns>Returns the Default tag values</returns>
        public string GetDefaultTagValues(string tagName)
        {
            switch (tagName)
            {
                case "Tag_EC":
                    return "x_Connex_En";
                case "Tag_CAD":
                    return "uint_Connex_Alarm_Delay";
                case "Tag_HCAL":
                    return "uint_Connex_Level_Delay";
                case "Tag_EnvEnbl":
                    return "x_PMREn";
                case "Tag_CWF":
                    return "x_FlushControlEn";
                case "Tag_EnvTOE":
                    return "x_HelmsTimoutEn";
                case "Tag_CFLA":
                    return "x_FlushLeakEn";
                case "Tag_EnvTA":
                    return "uint_HelmsTimout";
                case "Tag_ERB":
                    return "x_Reset_Button_En";
                case "Tag_DPNFA":
                    return "x_AlmPrgNotFinishDis";
                case "Tag_ART":
                    return "uint_ResetAlrmTime";
                case "Tag_STB":
                    return "uint_StopDubixTime";
                case "Tag_SAPESA":
                    return "x_SeparateAirStopAlarm";
                case "Tag_IRT":
                    return "uint_IntermRinseTime";
                case "Tag_IMS":
                    return "x_invertMachineStop";
                case "Tag_FGAAV":
                    return "uint_AlarmAnalogFilter";
                case "Tag_ADTE":
                    return "x_AlarmRackLeakageEnable";
                case "Tag_L1":
                    return "uint_LinetoWaterFS[1]";
                case "Tag_L2":
                    return "uint_LinetoWaterFS[2]";
                case "Tag_L3":
                    return "uint_LinetoWaterFS[3]";
                case "Tag_L4":
                    return "uint_LinetoWaterFS[4]";
                case "Tag_L5":
                    return "uint_LinetoWaterFS[5]";
                case "Tag_L6":
                    return "uint_LinetoWaterFS[6]";
                case "Tag_L7":
                    return "uint_LinetoWaterFS[7]";
                case "Tag_L8":
                    return "uint_LinetoWaterFS[8]";
                case "Tag_L9":
                    return "uint_LinetoWaterFS[9]";
                case "Tag_L10":
                    return "uint_LinetoWaterFS[10]";
                case "Tag_L11":
                    return "uint_LinetoWaterFS[11]";
                case "Tag_L12":
                    return "uint_LinetoWaterFS[12]";
                case "Tag_L13":
                    return "uint_LinetoWaterFS[13]";
                case "Tag_L14":
                    return "uint_LinetoWaterFS[14]";
                case "Tag_L15":
                    return "uint_LinetoWaterFS[15]";
                case "Tag_L16":
                    return "uint_LinetoWaterFS[16]";
                case "Tag_Line1":
                    return "x_LineDosingMode[1]";
                case "Tag_DLM1":
                    return "x_LineDosingMode[1]";
                case "Tag_EAP1":
                    return "x_AuxiliaryPumpUsed[1]";
                case "Tag_FMFC1":
                    return "x_UseFlowMeter_for_FlowCheck[1]";
                case "Tag_NPCT1":
                    return "uint_TCR_PumpNb[1]";
                case "Tag_Line2":
                    return "x_LineDosingMode[2]";
                case "Tag_DLM2":
                    return "x_LineDosingMode[2]";
                case "Tag_EAP2":
                    return "x_AuxiliaryPumpUsed[2]";
                case "Tag_FMFC2":
                    return "x_UseFlowMeter_for_FlowCheck[2]";
                case "Tag_NPCT2":
                    return "uint_TCR_PumpNb[2]";
                case "Tag_Line3":
                    return "x_LineDosingMode[3]";
                case "Tag_DLM3":
                    return "x_LineDosingMode[3]";
                case "Tag_EAP3":
                    return "x_AuxiliaryPumpUsed[3]";
                case "Tag_FMFC3":
                    return "x_UseFlowMeter_for_FlowCheck[3]";
                case "Tag_NPCT3":
                    return "uint_TCR_PumpNb[3]";
                case "Tag_WELE":
                    return "x_WandE_Enable";
                case "Tag_EC2":
                    return "x_Connex2_En";
                case "Tag_CAD2":
                    return "uint_Connex2_Alarm_Delay";
                case "Tag_HCAL2":
                    return "uint_Connex2_Level_Delay";
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        ///     Get Controller Models Detail
        /// </summary>
        /// <param name="regionId">Region Id</param>
        /// <returns>Returns the Controller Models Detail</returns>
        public IEnumerable<ControllerModelModel> GetControllerModelsDetails(int regionId)
        {
            List<Ecolab.Models.ControllerSetup.ControllerModel> controllerModelModel = this.controllerSetupService.GetControllerModelsDetails(regionId).ToList();
            List<ControllerModelModel> controllerModels = Mapper.Map<List<Ecolab.Models.ControllerSetup.ControllerModel>, List<ControllerModelModel>>(controllerModelModel);
            return controllerModels;
        }

        /// <summary>
        ///     Get Controller Type Detail
        /// </summary>
        /// <param name="controllerModelId">Controller Model Id</param>
        /// <returns>Returns the Controller Types Detail</returns>
        public IEnumerable<ControllerTypeModel> GetControllerTypesDetails(int controllerModelId)
        {
            List<ControllerType> controllerTypeModel = this.controllerSetupService.GetControllerTypesDetails(controllerModelId).ToList();
            List<ControllerTypeModel> controllerTypes = Mapper.Map<List<ControllerType>, List<ControllerTypeModel>>(controllerTypeModel);
            return controllerTypes;
        }

        /// <summary>
        ///     To update the Controller details
        /// </summary>
        /// <param name="data">Controller data to update</param>
        /// <returns>Returns updated controller data</returns>
        [HttpPost]
        public HttpResponseMessage UpdateControllerDetails(ControllerModel data)
        {
            if (data.ControllerId <= 0)
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid Dispenser details.");
            }
            try
            {
                DateTime lastModifiedTimeStamp;
                this.controllerSetupService.UpdateControllerListData(EntityConverter.ConvertToServiceModel(data), this.UserId, this.EcolabAccountNumber, out lastModifiedTimeStamp);
                Controller controllerData = EntityConverter.ConvertToServiceModel(data);
                controllerData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                Push.PushToQueue(controllerData, this.UserId, data.ControllerId, (int)TcdAdminMessageTypes.TcdUpdateControllerSetupListing, this.EcolabAccountNumber);
            }
            catch (SqlException ex)
            {
                this.Logger.Error("Api - Controller - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Number == 2627 ? "Dispenser Id already exists. Please try again." : "Unable to update the Dispenser. Some error has occured. Please try again.");
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Delete the Controller
        /// </summary>
        /// <param name="controllerId">Delete the Controller based on ID</param>
        /// <returns>Returns the Controller data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteController(int? controllerId)
        {
            if (!(controllerId > 0))
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid Dispenser details.");
            }
            try
            {
                DateTime lastModifiedTimeStamp;
                this.controllerSetupService.DeleteControllerListData(controllerId.Value, this.UserId, this.EcolabAccountNumber, out lastModifiedTimeStamp);

                Controller controllerModel = this.controllerSetupService.GetControllerDetailById(controllerId.Value, this.EcolabAccountNumber);
                controllerModel.IsDelete = true;
                controllerModel.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                Push.PushToQueue(controllerModel, this.UserId, controllerId.Value, (int)TcdAdminMessageTypes.TcdDeleteControllerSetupListing, this.EcolabAccountNumber);
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Formula - Delete Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the Dispenser. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, controllerId);
        }

        /// <summary>
        ///     Delete the Controller data
        /// </summary>
        /// <param name="data">Delete the Controller datas</param>
        /// <returns>Returns the Controller data by Id</returns>
        public HttpResponseMessage DeleteController(ControllerModel data)
        {
            return this.DeleteController(data.ControllerId);
        }

        /// <summary>
        ///     Save the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>Returns Controller Id</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage SaveControllerSetupData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            List<PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<PLCDiscrepancyModel>();
            PLCDiscrepancyModel objPLCDiscrepancyModel = new PLCDiscrepancyModel();
            int controllerId = 0;
            try
            {
                List<ControllerSetupData> ctrlSetupData = Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);
                IPrincipal user = HttpContext.Current.User;
                int userId = 0;
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                if (user != null)
                {
                    userId = ((CustomPrincipal)user).UserId;
                    controllerId = this.controllerSetupService.SaveControllerSetupData(ctrlSetupData, userId, out lastModifiedTimeStamp);
                }
                if (controllerId > 0)
                {
                    ControllerSetupData setupData = ctrlSetupData.FirstOrDefault();
                    if (setupData != null)
                    {
                        ControllerSetupDataDetails ctrlSetupDataDetails = new ControllerSetupDataDetails
                        {
                            ControllerSetupList = ctrlSetupData,
                            ControllerId = controllerId,
                            UserId = userId,
                            EcolabAccountNumber = setupData.EcolabAccountNumber,
                            LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc)
                        };
                        Push.PushToQueue(ctrlSetupDataDetails, userId, controllerId,
                            (int)TcdAdminMessageTypes.TcdAddController, ctrlSetupDataDetails.EcolabAccountNumber);

                        // Insert auto generated washer groups
                        Services.WasherGroup.WasherGroupService washerGroupService = new Services.WasherGroup.WasherGroupService();
                        List<Ecolab.Models.WasherGroup.WasherGroup> washerGroupModel = washerGroupService.GetWasherGroupDetailsForResync(null, ctrlSetupDataDetails.EcolabAccountNumber, false);
                        List<Ecolab.Models.WasherGroup.WasherGroup> washerGroups = washerGroupModel.Where(t => t.ControllerId == controllerId).ToList();
                        foreach (Ecolab.Models.WasherGroup.WasherGroup washerGroupData in washerGroups)
                        {
                            Push.PushToQueue(washerGroupData, this.UserId, washerGroupData.WasherGroupId, (int)TcdAdminMessageTypes.TcdAddWasherGroup, washerGroupData.EcolabAccountNumber);
                        }
                    }
                    List<MetaDataModel> metaDataModel = new List<MetaDataModel>(this.GetControllerSetupAdvanceMetaData(3, controllerId));
                    List<ControllerSetupDataModel> controllerAdvanceData = new List<ControllerSetupDataModel>();
                    if (metaDataModel != null && metaDataModel.Count > 0)
                    {
                        foreach (var item in metaDataModel)
                        {
                            if (item.FieldGroupInfo != null && item.FieldGroupInfo.Count > 0)
                            {
                                foreach (var fieldGroupInfo in item.FieldGroupInfo)
                                {
                                    ControllerSetupDataModel advanceData = new ControllerSetupDataModel();
                                    advanceData.FieldGroupId = item.FieldGroupId;
                                    advanceData.EcolabAccountNumber = EcolabAccountNumber;
                                    advanceData.FieldId = fieldGroupInfo.FieldId;
                                    advanceData.FieldName = fieldGroupInfo.FieldName;
                                    advanceData.TabId = 3;
                                    advanceData.ControllerId = controllerId;
                                    advanceData.ControllerModelId = fieldGroupInfo.ControllerModelId;
                                    advanceData.ControllerTypeId = fieldGroupInfo.ControllerTypeId;
                                    advanceData.FieldGroupId = fieldGroupInfo.FieldGroupId;
                                    advanceData.FieldName = fieldGroupInfo.FieldName;
                                    advanceData.Value = fieldGroupInfo.FieldDefaultValue;
                                    advanceData.FieldTagAddress = fieldGroupInfo.TagDefaultValue;
                                    advanceData.FieldTagValue = fieldGroupInfo.HasFieldTag;
                                    controllerAdvanceData.Add(advanceData);
                                }
                            }
                        }
                        this.SaveControllerSetupAdvanceData(controllerAdvanceData);
                        if (controllerSetupData != null && controllerSetupData[0].ControllerModelId == 7)
                        {
                            objPLCDiscrepancyModel = new PLCDiscrepancyModel
                            {
                                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                                ParentEntityId = controllerSetupData[0].ControllerId,
                                Entity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                                EntityId = controllerSetupData[0].ControllerId,
                                IsCentral = false,
                                ControllerId = controllerSetupData[0].ControllerId,
                                UserId = this.UserId,
                                LastModifiedUserId = this.UserId
                            };
                            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
                            List<BeckhoffTag> beckhoffTags = new List<BeckhoffTag>();
                            string dispenserName = Convert.ToString(controllerSetupData.Where(_ => _.FieldId == 212).FirstOrDefault().Value);
                            if (!string.IsNullOrWhiteSpace(dispenserName) && dispenserName.Length > 30)
                            {
                                dispenserName = dispenserName.Substring(0, 30);
                            }
                            beckhoffTags.Add(new BeckhoffTag { Address = "str_CustomerName", Value = dispenserName, TagItemType = UIInputType.TypeString, SizetoRead = dispenserName.Length });
                            plc.WriteMyControlTags(beckhoffTags, controllerId, SourcePage.ControllerSetupGeneralPage);
                            objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - ControllerSetup - Save ControllerSetup Data  Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string errorMessage = string.Empty;
                controllerSetupData[0].ControllerId = controllerId;
                if (ex.Message == "901" || ex.Message == "902")
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message, errorData = controllerSetupData});
                }
                else if (ex.Message.IndexOf("303", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "Dispenser Number already exists";
                }
                else if (ex.Message.IndexOf("304", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "Dispenser Name already exists";
                }
                else if (ex.Message.IndexOf("305", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "IP Address/AMS Net ID Address already exists.";
                }
                else
                {
                    errorMessage = "Unable to save the Controller Setup Data. Some error has occured. Please try again.";
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
            }
            return Request.CreateResponse(HttpStatusCode.OK, new { controllerId = controllerId, source = SourcePage.ControllerSetupGeneralPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
        }

        /// <summary>
        ///     Update the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage UpdateControllerSetupData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            List<PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<PLCDiscrepancyModel>();
            PLCDiscrepancyModel objPLCDiscrepancyModel = new PLCDiscrepancyModel();
            try
            {
                List<ControllerSetupData> ctrlSetupData = Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);
                DateTime lastModifiedTimeStamp;
                this.controllerSetupService.UpdateControllerSetupData(ctrlSetupData, this.UserId, out lastModifiedTimeStamp);
                ControllerSetupData firstOrDefault = ctrlSetupData.FirstOrDefault();
                if (firstOrDefault != null)
                {
                    ControllerSetupDataDetails ctrlSetupDataDetails = new ControllerSetupDataDetails
                    {
                        ControllerSetupList = ctrlSetupData,
                        ControllerId = firstOrDefault.ControllerId,
                        UserId = UserId,
                        EcolabAccountNumber = firstOrDefault.EcolabAccountNumber,
                        LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc)
                    };
                    Push.PushToQueue(ctrlSetupDataDetails, this.UserId, ctrlSetupDataDetails.ControllerId, (int)TcdAdminMessageTypes.TcdUpdateController, ctrlSetupDataDetails.EcolabAccountNumber);
                }
                if (controllerSetupData != null && controllerSetupData[0].ControllerModelId == 7)
                {
                    objPLCDiscrepancyModel = new PLCDiscrepancyModel
                    {
                        ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                        ParentEntityId = controllerSetupData[0].ControllerId,
                        Entity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                        EntityId = controllerSetupData[0].ControllerId,
                        IsCentral = false,
                        ControllerId = controllerSetupData[0].ControllerId,
                        UserId = this.UserId,
                        LastModifiedUserId = this.UserId
                    };
                    PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
                    List<BeckhoffTag> beckhoffTags = new List<BeckhoffTag>();
                    string dispenserName = Convert.ToString(controllerSetupData.Where(_ => _.FieldId == 212).FirstOrDefault().Value);
                    if (!string.IsNullOrWhiteSpace(dispenserName) && dispenserName.Length > 30)
                    {
                        dispenserName = dispenserName.Substring(0, 30);
                    }
                    beckhoffTags.Add(new BeckhoffTag { Address = "str_CustomerName", Value = dispenserName, TagItemType = UIInputType.TypeString, SizetoRead = dispenserName.Length });
                    plc.WriteMyControlTags(beckhoffTags, controllerSetupData[0].ControllerId, SourcePage.ControllerSetupGeneralPage);
                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - ControllerSetup - Update ControllerSetup Data  Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string errorMessage = string.Empty;
                if (ex.Message == "901" || ex.Message == "902")
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = ex.Message, errorData = controllerSetupData});
                }
                else if (ex.Message.IndexOf("303", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "Dispenser Number already exists";
                }
                else if (ex.Message.IndexOf("304", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "Dispenser Name already exists";
                }
                else if (ex.Message.IndexOf("305", StringComparison.Ordinal) > -1)
                {
                    errorMessage = "IP Address/AMS Net ID Address already exists.";
                }
                else
                {
                    errorMessage = "Unable to save the Controller Setup Data. Some error has occured. Please try again.";
                }
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, new { source = SourcePage.ControllerSetupGeneralPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
        }

        /// <summary>
        ///     Save/Update the ControllerSetup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData class</param>
        /// <returns>http response message.</returns>
        [HttpPost]
        [PLCDiscrepancyCheck]
        public HttpResponseMessage SaveControllerSetupAdvanceData([FromBody] List<ControllerSetupDataModel> controllerSetupData)
        {
            List<PLCDiscrepancyModel> objPLCDiscrepancyModels = new List<PLCDiscrepancyModel>();
            if (controllerSetupData[0].ControllerModelId == 7 && controllerSetupData[0].ControllerTypeId == 2)
            {
                var i = 0;
                foreach (ControllerSetupDataModel model in controllerSetupData)
                {
                    if (controllerSetupData[i].Value == "false")
                    {
                        controllerSetupData[i].Value = "0";
                    }
                    if (controllerSetupData[i].Value == "true")
                    {
                        controllerSetupData[i].Value = "1";
                    }
                    model.FieldTagAddress = GetDefaultTagValues(model.FieldTagValue);
                    i++;
                }
            }
            else if (controllerSetupData[0].ControllerModelId == 11 || controllerSetupData[0].ControllerModelId == 8)
            {
                foreach (ControllerSetupDataModel model in controllerSetupData)
                {
                    if (!string.IsNullOrEmpty(model.Value) && (model.Value.ToLower() == "false" || model.Value.ToLower() == "true"))
                    {
                        model.Value = model.Value.ToLower() == "false" ? "0" : "1";
                    }
                    if (controllerSetupData[0].ControllerModelId == 11)
                    {
                        if (controllerSetupData[0].ControllerTypeId == 12)
                        {
                            if (model.FieldId == 474 || model.FieldId == 475 || model.FieldId == 355 || model.FieldId == 368 || model.FieldId == 370)
                            {
                                model.Value = (Convert.ToInt32(model.Value) * 10).ToString();
                            }
                        }
                        else if (controllerSetupData[0].ControllerTypeId == 13)
                        {
                            if (model.FieldId == 474 || model.FieldId == 475 || model.FieldId == 316 || model.FieldId == 329 || model.FieldId == 331)
                            {
                                model.Value = (Convert.ToInt32(model.Value) * 10).ToString();
                            }
                        }
                        else if (controllerSetupData[0].ControllerTypeId == 14)
                        {
                            if (model.FieldId == 474 || model.FieldId == 475 || model.FieldId == 277 || model.FieldId == 290 || model.FieldId == 292)
                            {
                                model.Value = (Convert.ToInt32(model.Value) * 10).ToString();
                            }
                        }
                    }
                    else if (controllerSetupData[0].ControllerModelId == 8)
                    {
                        if (model.FieldId == 215 || model.FieldId == 407)
                        {
                            model.Value = (Convert.ToInt32(model.Value) * 10).ToString();
                        }
                        else if (model.FieldId == 390 || model.FieldId == 403)
                        {
                            model.Value = Convert.ToInt32((Convert.ToDecimal(model.Value) * 10)).ToString();
                        }
                    }
                }
            }
            PLCDiscrepancyModel objPLCDiscrepancyModel = new PLCDiscrepancyModel
            {
                ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.Dispenser),
                ParentEntityId = controllerSetupData[0].ControllerId,
                Entity = Convert.ToInt32(PlcDiscrepancyEntity.Advanced),
                EntityId = controllerSetupData[0].ControllerId,
                IsCentral = false,
                ControllerId = controllerSetupData[0].ControllerId,
                UserId = this.UserId,
                LastModifiedUserId = this.UserId
            };
            string returnStatus = string.Empty;
            try
            {
                List<ControllerSetupData> ctrlSetupData =
                    Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);

                List<ControllerSetupData> ctrlSetupDataSync =
                    Mapper.Map<List<ControllerSetupDataModel>, List<ControllerSetupData>>(controllerSetupData);

                ControllerSetupData firstOrDefault = ctrlSetupData.FirstOrDefault();
                int actionType;
                DateTime lastModifiedTimeStamp;
                if (firstOrDefault != null && this.controllerSetupService.IsSetupAdvanceDataExist(firstOrDefault.TabId, firstOrDefault.ControllerId, this.EcolabAccountNumber))
                {
                    this.controllerSetupService.UpdateControllerSetupAdvanceData(ctrlSetupData, this.UserId, out lastModifiedTimeStamp);
                    actionType = (int)TcdAdminMessageTypes.TcdUpdateControllerAdvanced;
                }
                else
                {
                    this.controllerSetupService.SaveControllerSetupAdvanceData(ctrlSetupData, this.UserId, out lastModifiedTimeStamp);
                    actionType = (int)TcdAdminMessageTypes.TcdAddControllerAdvanced;
                }
                this.controllerSetupService.SaveAdvancedTags(ctrlSetupData);
                if (controllerSetupData[0].ControllerModelId == 7)
                {
                    if (actionType != 0 && firstOrDefault != null)
                    {
                        var ctrlSetupDataDetails = new ControllerSetupDataDetails
                        {
                            ControllerSetupList = ctrlSetupDataSync,
                            ControllerId = firstOrDefault.ControllerId,
                            UserId = UserId,
                            EcolabAccountNumber = firstOrDefault.EcolabAccountNumber,
                            LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc)
                        };

                        Push.PushToQueue(ctrlSetupDataDetails, this.UserId, ctrlSetupDataDetails.ControllerId, actionType, ctrlSetupDataDetails.EcolabAccountNumber);
                    }
                }
                if (controllerSetupData[0].ControllerModelId != 7 && controllerSetupData[0].ControllerModelId != 11 && controllerSetupData[0].ControllerModelId != 8)
                {
                    foreach (var item in ctrlSetupDataSync)
                    {
                        item.FieldTagAddress = string.Empty;
                        item.FieldTagValue = string.Empty;
                    }

                    if (actionType != 0 && firstOrDefault != null)
                    {
                        var ctrlSetupDataDetails = new ControllerSetupDataDetails
                        {
                            ControllerSetupList = ctrlSetupDataSync,
                            ControllerId = firstOrDefault.ControllerId,
                            UserId = UserId,
                            EcolabAccountNumber = firstOrDefault.EcolabAccountNumber,
                            LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc)
                        };

                        Push.PushToQueue(ctrlSetupDataDetails, this.UserId, ctrlSetupDataDetails.ControllerId, actionType, ctrlSetupDataDetails.EcolabAccountNumber);
                    }

                    try
                    {
                        if (controllerSetupData[0].Role >= 6 && controllerSetupData[0].PlcTagModelTags != null && controllerSetupData[0].PlcTagModelTags.Count > 0)
                        {
                            if (controllerSetupData[0].PlcTagModelTags.Any(_ => !string.IsNullOrWhiteSpace(_.Address)))
                            {
                                var plc = new PlcTagController(plcService, UserService, PlantService);

                                List<TagsModel> tagsList = controllerSetupData[0].PlcTagModelTags.Where(_ => !string.IsNullOrWhiteSpace(_.Address)).ToList();

                                TagCollection tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, controllerSetupData.FirstOrDefault().ControllerId);

                                returnStatus =
                                    tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad")
                                        .Aggregate(returnStatus, (c, status) => c + (status.Address + ","));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Logger.Error("Api - ControllerSetup - Save ControllerSetup Data  Error :", ex);
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        return this.Request.CreateResponse(HttpStatusCode.NotAcceptable, new { message = ex.Message });
                    }

                    if (!string.IsNullOrEmpty(returnStatus))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, new { message = returnStatus });
                    }
                    else
                    {
                        this.controllerSetupService.SaveAdvancedTags(ctrlSetupData);
                        if (controllerSetupData.Any() && controllerSetupData[0].PlcTagModelTags != null && !string.IsNullOrEmpty(controllerSetupData[0].PlcTagModelTags.FirstOrDefault().Address))
                        {
                            WriteToPlc(controllerSetupData);
                        }
                        if (actionType != 0 && firstOrDefault != null)
                        {
                            var ctrlSetupDataDetails = new ControllerSetupDataDetails
                            {
                                ControllerSetupList = ctrlSetupData,
                                ControllerId = firstOrDefault.ControllerId,
                                UserId = UserId,
                                EcolabAccountNumber = firstOrDefault.EcolabAccountNumber,
                                LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc)
                            };

                            Push.PushToQueue(ctrlSetupDataDetails, this.UserId, ctrlSetupDataDetails.ControllerId, (int)TcdAdminMessageTypes.TcdUpdateControllerAdvanced, ctrlSetupDataDetails.EcolabAccountNumber);
                        }
                    }
                    objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                    return this.Request.CreateResponse(HttpStatusCode.OK, new { source = SourcePage.AdvancedPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                }
                else
                {
                    try
                    {
                        WriteToPlc(controllerSetupData);
                        objPLCDiscrepancyModels.Add(objPLCDiscrepancyModel);
                        return this.Request.CreateResponse(HttpStatusCode.OK, new { source = SourcePage.AdvancedPage, plcDiscrepancyModel = objPLCDiscrepancyModels });
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                        string errorMessage = "406";
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - ControllerSetup - Save ControllerSetup Data  Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                string errorMessage = (ex.Message.IndexOf("303", StringComparison.Ordinal) > -1) ? "Controller Number already exists." : "Unable to save the Controller Setup Data. Some error has occured. Please try again.";
                if (ex.Message == "901")
                {
                    return this.Request.CreateResponse(HttpStatusCode.NotAcceptable, new { message = ex.Message });
                }
                else if (ex.Message == "Ads-Error 0x12 : Port is disabled." || ex.Message == "Read array Failed" || ex.Message == "Ads-Error 0x7 : Target machine could not be found.")
                {
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                }
                else
                {
                    errorMessage = "Unable to save the Controller Setup Data. Some error has occured. Please try again.";
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorMessage);
                }
            }
        }

        /// <summary>
        ///     Validate the PLC tag details
        /// </summary>
        /// <param name="controllerSetupData">Controller setup Data</param>
        /// <returns>Success or failure message</returns>
        [HttpPost]
        public HttpResponseMessage ValidateTags(List<ControllerSetupDataModel> controllerSetupData)
        {
            try
            {
                PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
                TagCollection tagStatus = new TagCollection();
                List<OpcTag> tagsList = (controllerSetupData[0].PlcTagModelTags.Where(
                    item => !string.IsNullOrWhiteSpace(item.Address))
                    .Select(item => new OpcTag { Address = item.Address, Value = item.Value })).ToList();
                List<OpcTag> tags = null;
                if (tagsList.Any())
                {
                    tags = tagsList.Clone();
                    tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, controllerSetupData[0].ControllerId);
                    string errorCode = null;
                    foreach (OpcTag item in controllerSetupData[0].PlcTagModelTags)
                    {
                        foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
                        {
                            if (item.Address == status.Address)
                            {
                                errorCode = !string.IsNullOrWhiteSpace(errorCode) ? errorCode + status.Address + "," : status.Address + ",";
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(errorCode))
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, new { message = errorCode });
                    }
                }
                Dictionary<string, object> error;
                string message = CompareTags(tagStatus, tags, out error);

                if (!string.IsNullOrWhiteSpace(message))
                {
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, error);
                }
                return Request.CreateResponse(HttpStatusCode.OK, message);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        /// <summary>
        /// Write values to PLC
        /// </summary>
        /// <param name="controllerSetupData">The controller setup data.</param>
        private void WriteToPlc(List<ControllerSetupDataModel> controllerSetupData)
        {
            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, controllerSetupData.FirstOrDefault().ControllerId);
            List<Tag> tagsList = new List<Tag>();
            if (controllerSetupData[0].ControllerModelId != 7 && controllerSetupData[0].ControllerModelId != 11 && controllerSetupData[0].ControllerModelId != 8)
            {
                if (controllerSetupData.Where(x => x.FieldTagValue == "Tag_AWEA").FirstOrDefault() != null)
                {
                    controllerSetupData.Where(x => x.FieldTagValue == "Tag_AWEA").FirstOrDefault().Value = fieldTags.AWEActive == true || Convert.ToString(fieldTags.AWEActive) == "on" ? "true" : "false";
                }
                if (controllerSetupData.Where(x => x.FieldTagValue == "Tag_RDE").FirstOrDefault() != null)
                {
                    controllerSetupData.Where(x => x.FieldTagValue == "Tag_RDE").FirstOrDefault().Value = fieldTags.RatioDosingActive == true || Convert.ToString(fieldTags.RatioDosingActive) == "on" ? "true" : "false";
                }
                foreach (ControllerSetupDataModel item in controllerSetupData)
                {
                    tagsList.Add(new BeckhoffTag { Address = item.FieldTagAddress, Value = item.Value });
                }
            }
            else if (controllerSetupData[0].ControllerModelId == 7)
            {
                foreach (ControllerSetupDataModel item in controllerSetupData)
                {
                    if ((item.FieldId == 248) || (item.FieldId == 253) || (item.FieldId == 258))
                    {
                        tagsList.Add(new BeckhoffTag
                        {
                            Address = item.FieldTagAddress,
                            Value = (Convert.ToInt32(item.Value) - 1).ToString()
                        });
                    }
                    else
                    {
                        tagsList.Add(new BeckhoffTag { Address = item.FieldTagAddress, Value = item.Value });
                    }
                }
            }
            else if (controllerSetupData[0].ControllerModelId == 11)
            {
                foreach (ControllerSetupDataModel item in controllerSetupData)
                {
                    if (item.FieldTagAddress == "x_Connex_En")
                    {
                        item.FieldTagAddress = "L94";
                    }
                    else if (item.FieldTagAddress == "uint_Connex_Alarm_Delay")
                    {
                        item.FieldTagAddress = "D775";
                    }
                    else if (item.FieldTagAddress == "uint_Connex_Level_Delay")
                    {
                        item.FieldTagAddress = "D774";
                    }
                    tagsList.Add(new MitsubishiTag { Address = item.FieldTagAddress, Value = item.Value });
                }
            }
            else if (controllerSetupData[0].ControllerModelId == 8)
            {
                foreach (ControllerSetupDataModel item in controllerSetupData)
                {
                    tagsList.Add(new MitsubishiTag { Address = item.FieldTagAddress, Value = item.Value });
                }
            }
            if (controllerSetupData[0].ControllerModelId == 7)
            {
                List<BeckhoffTag> beckhoffTags = new List<BeckhoffTag>();
                foreach (BeckhoffTag item in tagsList)
                {
                    beckhoffTags.Add(item);
                }
                plc.WriteMyControlTags(beckhoffTags, controllerSetupData[0].ControllerId, SourcePage.AdvancedPage);
            }
            else if (controllerSetupData[0].ControllerModelId == 11 || controllerSetupData[0].ControllerModelId == 8)
            {
                plc.WriteTags(new TagCollection { Tags = tagsList }, controllerSetupData[0].ControllerId, SourcePage.AdvancedPage);
            }
            else
            {
                plc.WriteTags(new TagCollection { Tags = tagsList }, controllerSetupData[0].ControllerId);
            }
        }

        /// <summary>
        /// MyControl controller model Tags are generated
        /// </summary>
        /// <param name="metaDataModel">Meta Data model</param>
        /// <returns>Beckhoff Tags with Complex Objects</returns>
        private List<BeckhoffTag> GenerateMyControlGeneralTags(MetaDataModel metaDataModel)
        {
            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            string dispenserName = Convert.ToString(metaDataModel.FieldGroupInfo.Where(_ => _.FieldId == 212).FirstOrDefault().FieldDefaultValue);
            if (!string.IsNullOrWhiteSpace(dispenserName) && dispenserName.Length > 30)
            {
                dispenserName = dispenserName.Substring(0, 30);
            }
            tags.Add(new BeckhoffTag { Address = ".str_CustomerName", Value = dispenserName, TagItemType = UIInputType.TypeString, SizetoRead = dispenserName.Length });
            return tags;
        }

        /// <summary>
        /// Get Max Injection Class count(JS calls)
        /// </summary>
        /// <param name="controllerId">Controller Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Count of Injection Classes</returns>
        public int GetMaxInjectionClassesCount(int controllerId, string ecolabAccountNumber)
        {
            return this.controllerSetupService.GetMaxInjectionClassesCount(controllerId, ecolabAccountNumber);
        }
    }
}