﻿// -----------------------------------------------------------------------
// <copyright file="StorageTanksController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Storage Tanks Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Web.Http;
    using AutoMapper;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Dcs.Entities;
    using Ecolab.Models.Common;
    using Ecolab.Models.StorageTanks;
    using Elmah;
    using Models.StorageTanks;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Plc;
    using Services.Interfaces.StorageTanks;
    using Utilities;
    using Controller = Ecolab.Models.ControllerSetup.Controller;
    using ControllerModel = Models.ControllerSetup.ControllerModel;
    using ProductModel = Ecolab.Models.ControllerSetup.Pumps.ProductModel;

    /// <summary>
    ///     class StorageTanks Controller
    /// </summary>
    public class StorageTanksController : BaseApiController
    {
        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IPumpsService pumpServices;

        /// <summary>
        ///     Storage Tanks Service
        /// </summary>
        private readonly IStorageTanksService storageTanksService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="StorageTanksController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="storageTanksService">The storage Tanks Service.</param>
        /// <param name="controllerSetupService">The controller setup service</param>
        /// <param name="pumpServices">The pump service</param>
        /// <param name="plcServiceobj">The PLC service object</param>
        /// <param name="plantService">The Plant Service</param>
        public StorageTanksController(IUserService userService, IStorageTanksService storageTanksService, IControllerSetupService controllerSetupService, IPumpsService pumpServices, IPlcService plcServiceobj, IPlantService plantService)
            : base(userService, plantService)
        {
            this.storageTanksService = storageTanksService;
            this.controllerSetupService = controllerSetupService;
            this.pumpServices = pumpServices;
            this.plcService = plcServiceobj;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get Tanks Details
        /// </summary>
        /// <returns>Returns the Tanks Details</returns>
        [HttpGet]
        public IEnumerable<TanksModel> GetTanksDetails(string ecolabAccountNumber)
        {
            List<Tanks> tanksModel = this.storageTanksService.GetTanksDetails(ecolabAccountNumber).ToList();
            List<TanksModel> tanks = Mapper.Map<List<Tanks>, List<TanksModel>>(tanksModel);
            tanks = ConvertUnits(tanks, false);
            tanks.ForEach(_ => _.CallibrationLevelAsString = _.CalibrationLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.LowLevelAsString = _.LowLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.EmptyLevelAsString = _.EmptyLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.LevelDeviationAsString = _.LevelDeviationDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.SizeAsString = _.SizeDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.CurrentLevelAsString = _.CurrentLevelDisplay.ToString("#,0.##"));
            return tanks;
        }

        /// <summary>
        /// ConvertUnits
        /// </summary>
        /// <param name="tanks">list of tanks</param>
        /// <param name="isEdit">boolean parameter is Edit</param>
        /// <returns>list of tanks</returns>
        private List<TanksModel> ConvertUnits(List<TanksModel> tanks, bool isEdit)
        {
            tanks.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, isEdit, 0);
            return tanks;
        }

        /// <summary>
        ///     Method to delete a StorageTank
        /// </summary>
        /// <param name="storageTankData">Storage tank data.</param>
        /// <returns>returns boolean</returns>
        [HttpPost]
        public HttpResponseMessage DeleteStorageTanks(TanksModel storageTankData)
        {
            var tanksData = new TanksModel { TankId = storageTankData.TankId };

            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            bool result = this.storageTanksService.DeleteStorageTanks(tanksData.TankId, this.UserId, storageTankData.EcolabAccountNumber, out lastModifiedTimeStamp);
            storageTankData.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

            var tanks = new Tanks
            {
                TankId = storageTankData.TankId,
                EcolabAccountNumber = this.EcolabAccountNumber,
                IsDelete = true,
                LastModifiedTimeStamp = storageTankData.LastModifiedTimeStamp
            };
            Push.PushToQueue(tanks, this.UserId, tanks.TankId, (int)TcdAdminMessageTypes.TcdDeleteStorageTanks, this.EcolabAccountNumber);
            if (result)
            {
                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }
            else
            {
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, result);
            }
        }

        /// <summary>
        ///     Get Tanks Details for Add/Edit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab account number.</param>
        /// <param name="id">The Id parameter.</param>
        /// <returns>returns boolean</returns>
        public IEnumerable<TanksModel> GetAddEditStorageTanksDetails(string ecolabAccountNumber, int id = 0)
        {
            List<Controller> controllerModel = this.controllerSetupService.GetControllerDetails(ecolabAccountNumber).ToList();
            List<ControllerModel> controller = Mapper.Map<List<Controller>, List<ControllerModel>>(controllerModel);

            List<ProductModel> productModel = this.pumpServices.GetProductList(ecolabAccountNumber);
            List<Models.ControllerSetup.Pumps.ProductModel> products = Mapper.Map<List<ProductModel>, List<Models.ControllerSetup.Pumps.ProductModel>>(productModel);
            List<TanksModel> tanks;
            if (id > 0)
            {
                List<Tanks> tanksModel = this.storageTanksService.GetTanksDetails(ecolabAccountNumber, id).ToList();
                tanks = Mapper.Map<List<Tanks>, List<TanksModel>>(tanksModel);
                tanks = ConvertUnits(tanks, false);
            }
            else
            {
                tanks = this.PopulateValue();
            }

            foreach (TanksModel item in tanks)
            {
                item.Controllers = controller.ToList();
                item.Products = products.ToList();
                item.IsCentral = "No";
            }

            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            List<OpcTag> tagsList = new List<OpcTag>();
            TagCollection tagStatus = new TagCollection();

            foreach (TanksModel model in tanks)
            {
                if (!string.IsNullOrEmpty(model.CurrentLevelTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.CurrentLevelTag,
                        Value = Convert.ToString(Convert.ToInt32(model.CurrentLevel)),
                        Topic = "CurrentLevel"
                    });
                }

                if (!string.IsNullOrEmpty(model.SizeTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.SizeTag,
                        Value = Convert.ToString(Convert.ToInt32(model.Size))
                    });
                }

                if (!string.IsNullOrEmpty(model.LevelDeviationTag))
                {
                    tagsList.Add(new OpcTag
                    {
                        Address = model.LevelDeviationTag,
                        Value = Convert.ToString(Convert.ToInt32(model.LevelDeviation))
                    });
                }
            }
            List<string> tagCollectionList = new List<string>();
            if (tagsList.Count > 0)
            {
                try
                {
                    tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, tanks[0].ControllerId);
                    foreach (OpcTag tag in tagsList.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                        {
                            if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                            {
                                tagCollectionList.Add(tag.Address);
                            }
                            if (tag.Address == plcTag.Address && tag.Topic == "CurrentLevel")
                            {
                                tanks.FirstOrDefault().CurrentLevelDisplay = Convert.ToDecimal(string.IsNullOrEmpty(plcTag.Value) ? tag.Value : plcTag.Value);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                }

                foreach (TanksModel metaData in tanks)
                {
                    if (!string.IsNullOrEmpty(metaData.SizeTag) && tagCollectionList.Contains(metaData.SizeTag))
                    {
                        metaData.SizePlcOverride = true;
                    }
                    if (!string.IsNullOrEmpty(metaData.LevelDeviationTag) && tagCollectionList.Contains(metaData.LevelDeviationTag))
                    {
                        metaData.LevelDeviationPlcOverride = true;
                    }
                }
            }

            tanks.ForEach(_ => _.CallibrationLevelAsString = _.CalibrationLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.LowLevelAsString = _.LowLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.EmptyLevelAsString = _.EmptyLevelDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.LevelDeviationAsString = _.LevelDeviationDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.SizeAsString = _.SizeDisplay.ToString("#,0.##"));
            tanks.ForEach(_ => _.CurrentLevelAsString = _.CurrentLevelDisplay.ToString("#,0.##"));

            return tanks;
        }

        /// <summary>
        ///     Get Tanks Details Basing on controller
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>returns Tank Model Details</returns>
        public IEnumerable<TanksModel> GetTankDetailsOnController(string ecolabAccountNumber, int controllerId)
        {
            return Mapper.Map<List<Tanks>, List<TanksModel>>(
                this.storageTanksService.GetTanksDetails(ecolabAccountNumber))
                .Where(_ => _.ControllerId == controllerId);
        }

        /// <summary>
        ///     Save the Storage Tanks Data
        /// </summary>
        /// <param name="data"> The data . </param>
        /// <returns>http response message</returns>
        [HttpPost]
        public HttpResponseMessage CreateStorageTank(TanksModel data)
        {
            TanksModel tanks = new TanksModel();
            try
            {
                Tanks tanksConverted;
                SetConvertedDataOnAdd_Update(data, out tanks, out tanksConverted);
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                tanksConverted.TankId = storageTanksService.SaveStorageTank(tanksConverted, this.UserId, out lastModifiedTimeStamp);
                tanksConverted.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);

                if (tanksConverted.TankId > 0)
                {
                    data.TankId = tanksConverted.TankId;
                    List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, tanksConverted.TankId);
                    objTanks.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                    objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;
                    Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdAddStorageTanks, this.EcolabAccountNumber);
                }

                try
                {
                    var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                    var tagsList = new List<OpcTag>();
                    var tagStatus = new TagCollection();

                    if (!string.IsNullOrEmpty(data.LevelDeviationTag))
                    {
                        tagsList.Add(new OpcTag { Address = data.LevelDeviationTag, Value = data.LevelDeviation.ToString() });
                    }

                    if (!string.IsNullOrEmpty(data.SizeTag))
                    {
                        tagsList.Add(new OpcTag { Address = data.SizeTag, Value = data.Size.ToString() });
                    }
                    List<OpcTag> tags = null;
                    if (tagsList.Any())
                    {
                        tags = tagsList.Clone();

                        if (tanksConverted.TankId > 0)
                        {
                            List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, tanksConverted.TankId);
                            objTanks.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                            string error = string.Empty;
                            this.storageTanksService.SaveStorageTankTags(tanksConverted, this.UserId, out error);
                            if (!string.IsNullOrEmpty(error))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, error + "#" + tanksConverted.TankId);
                            }
                            List<ModuleTagsModel> objModuleTags = this.storageTanksService.GetModuleTagsDetails(tanksConverted.TankId, 1, this.EcolabAccountNumber).ToList();
                            objTanks[0].moduleTags = objModuleTags;
                            objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;
                            Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks, this.EcolabAccountNumber);
                        }

                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, data.ControllerId);
                        string errorCode = GetErrorCodes(data, tagStatus);
                        if (!string.IsNullOrEmpty(errorCode))
                        {
                            errorCode += "#" + tanksConverted.TankId;
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                        }
                        //Write data to PLC
                        WriteToPlc(tagsList, data.ControllerId);
                    }
                }
                catch (Exception ex)
                {
                    //string result = string.Empty;
                    //result += "#" + tanks.TankId;
                    String msg = string.Empty;
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Port is not open") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        msg = "901," + ex.Message;
                    }
                    if (tanksConverted.TankId > 0)
                    {
                        if (msg != string.Empty)
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, msg + tanksConverted.TankId);
                        }
                        else
                        {
                            return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message + "#" + tanksConverted.TankId);
                        }
                    }
                    return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
                }

                if (tanksConverted.TankId > 0)
                {
                    List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, tanksConverted.TankId);
                    objTanks.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                    string error = string.Empty;
                    this.storageTanksService.SaveStorageTankTags(tanksConverted, this.UserId, out error);
                    if (!string.IsNullOrEmpty(error))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, error + "#" + tanksConverted.TankId);
                    }
                    List<ModuleTagsModel> objModuleTags = this.storageTanksService.GetModuleTagsDetails(tanksConverted.TankId, 1, this.EcolabAccountNumber).ToList();
                    objTanks[0].moduleTags = objModuleTags;
                    objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;
                    Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks, this.EcolabAccountNumber);
                }
            }
            catch (SqlException ex)
            {
                this.Logger.Error("Api - Storage tank - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message + "#" + tanks.TankId);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Save the Storage Tanks Data
        /// </summary>
        /// <param name="data"> The data . </param>
        /// <returns>http response message</returns>
        [HttpPost]
        public HttpResponseMessage UpdateStorageTank(TanksModel data)
        {
            try
            {
                TanksModel tanks;
                Tanks tanksConverted;
                SetConvertedDataOnAdd_Update(data, out tanks, out tanksConverted);
                DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                tanksConverted.TankId = this.storageTanksService.UpdateStorageTank(tanksConverted, this.UserId, out lastModifiedTimeStamp);
                tanksConverted.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                if (tanks.TankId > 0)
                {
                    List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, tanks.TankId);
                    objTanks.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                    //List<ModuleTagsModel> objModuleTags = this.storageTanksService.GetModuleTagsDetails(tanks.TankId, 1, this.EcolabAccountNumber).ToList();
                    //objTanks[0].moduleTags = objModuleTags;
                    objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;
                    Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks, this.EcolabAccountNumber);
                }
                try
                {
                    var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                    var tagsList = new List<OpcTag>();
                    var tagStatus = new TagCollection();

                    if (!string.IsNullOrEmpty(data.LevelDeviationTag))
                    {
                        tagsList.Add(new OpcTag { Address = data.LevelDeviationTag, Value = data.LevelDeviation.ToString() });
                    }

                    if (!string.IsNullOrEmpty(data.SizeTag))
                    {
                        tagsList.Add(new OpcTag { Address = data.SizeTag, Value = data.Size.ToString() });
                    }
                    List<OpcTag> tags = null;
                    if (tagsList.Any())
                    {
                        tags = tagsList.Clone();

                        string error = string.Empty;
                        this.storageTanksService.UpdateStorageTankTags(tanksConverted, this.UserId, out error);

                        if (!string.IsNullOrEmpty(error))
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, error + "#" + tanksConverted.TankId);
                        }

                        tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, data.ControllerId);
                        string errorCode = GetErrorCodes(data, tagStatus);
                        if (!string.IsNullOrEmpty(errorCode))
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                        }
                        else
                        {
                            error = string.Empty;
                            this.storageTanksService.UpdateStorageTankTags(tanksConverted, this.UserId, out error);

                            if (!string.IsNullOrEmpty(error))
                            {
                                return this.Request.CreateResponse(HttpStatusCode.BadRequest, error + "#" + tanksConverted.TankId);
                            }
                        }
                    }

                    var message = new StringBuilder();
                    var ambiguousTags = new List<OpcTag>();
                    GetStorageTanksAmbiguousTags(tagStatus, tags, message, ambiguousTags);
                    if (!string.IsNullOrWhiteSpace(message.ToString()))
                    {
                        message.Append("Do you want to override the value in plc ?");

                        var error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
                        return Request.CreateResponse(HttpStatusCode.Ambiguous, error);
                    }
                }
                catch (Exception ex)
                {
                    String msg = string.Empty;
                    if (ex.Message.Contains("Timeout has elapsed") ||
                        ex.Message.Contains("Port is disabled") ||
                        ex.Message.Contains("Target machine could not be found") ||
                        ex.Message.Contains("ADS could not be initialized") ||
                        ex.Message.Contains("Port is not open") ||
                        ex.Message.Contains("Open Failed") ||
                        ex.Message.Contains("Retrieving the COM class factory"))
                    {
                        msg = "901," + ex.Message;
                    }
                    if (msg != string.Empty)
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, msg + tanksConverted.TankId);
                    }
                    else
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
                    }
                }

                if (tanks.TankId > 0)
                {
                    List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, tanks.TankId);
                    objTanks.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
                    List<ModuleTagsModel> objModuleTags = this.storageTanksService.GetModuleTagsDetails(tanks.TankId, 1, this.EcolabAccountNumber).ToList();
                    objTanks[0].moduleTags = objModuleTags;
                    objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;
                    Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks, this.EcolabAccountNumber);
                }

            }
            catch (SqlException ex)
            {
                this.Logger.Error("Api - Storage tank - Update Error :", ex);
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return this.Request.CreateResponse(HttpStatusCode.OK, data);
        }

        /// <summary>
        ///     Writing tags to plc
        /// </summary>
        /// <param name="data">Storage Tanks Data To Update plc tags</param>
        /// <returns>Success</returns>
        [HttpPost]
        public HttpResponseMessage WriteTagsToPLC(TanksModel data)
        {
            try
            {
                if (this.RoleId >= 7)
                {
                    if (data.OverridePlcValues)
                    {
                        this.WriteToPlc(data.PlcTags, data.ControllerId);
                    }
                }

                if (data.TankId > 0)
                {
                    List<Tanks> objTanks = this.storageTanksService.GetTanksDetails(this.EcolabAccountNumber, data.TankId);
                    List<ModuleTagsModel> objModuleTags = this.storageTanksService.GetModuleTagsDetails(data.TankId, 1, this.EcolabAccountNumber).ToList();
                    string errorMsg = string.Empty;
                    if (!string.IsNullOrEmpty(errorMsg))
                    {
                        return Request.CreateResponse(HttpStatusCode.BadRequest, errorMsg);
                    }
                    objTanks[0].moduleTags = objModuleTags;
                    objTanks[0].EcolabAccountNumber = this.EcolabAccountNumber;

                    Push.PushToQueue(objTanks[0], this.UserId, objTanks[0].TankId, (int)TcdAdminMessageTypes.TcdUpdateStorageTanks, this.EcolabAccountNumber);
                }
            }
            catch (SqlException sqlex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, sqlex.Message);
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }
        /// <summary>
        /// Mthod to update converted data
        /// </summary>
        /// <param name="data">The tanks model data.</param>
        /// <param name="tanks">The tanks model.</param>
        /// <param name="tanksConverted">The tanks model.</param>
        private void SetConvertedDataOnAdd_Update(TanksModel data, out TanksModel tanks, out Tanks tanksConverted)
        {
            tanks = data;
            List<TanksModel> lstTanksModel = new List<TanksModel>();
            lstTanksModel.Add(tanks);
            lstTanksModel = ConvertUnits(lstTanksModel, true);
            tanksConverted = Mapper.Map<TanksModel, Tanks>(lstTanksModel.FirstOrDefault());
        }

        /// <summary>
        /// Write values to PLC
        /// </summary>
        /// <param name="tags">The tags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        private void WriteToPlc(List<OpcTag> tags, int controllerId)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            plc.WriteTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerId);
        }

        /// <summary>
        ///     To Populate empty list
        /// </summary>
        /// <returns>List of Tank Model</returns>
        private List<TanksModel> PopulateValue()
        {
            return new List<TanksModel> { new TanksModel { TankId = -1, TankName = string.Empty } };
        }

        /// <summary>
        ///     Validate the PLC tag details
        /// </summary>
        /// <param name="data">Storage Tanks Data</param>
        /// <returns>Success or failure message</returns>
        [HttpPost]
        public HttpResponseMessage ValidateTags(TanksModel data)
        {
            try
            {
                var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
                var tagsList = new List<OpcTag>();
                var tagStatus = new TagCollection();
                if (!string.IsNullOrEmpty(data.CurrentLevelTag))
                {
                    tagsList.Add(new OpcTag { Address = data.CurrentLevelTag, Value = data.CurrentLevel.ToString() });
                }

                if (!string.IsNullOrEmpty(data.LevelDeviationTag))
                {
                    tagsList.Add(new OpcTag { Address = data.LevelDeviationTag, Value = data.LevelDeviation.ToString() });
                }

                if (!string.IsNullOrEmpty(data.SizeTag))
                {
                    tagsList.Add(new OpcTag { Address = data.SizeTag, Value = data.Size.ToString() });
                }
                List<OpcTag> tags = null;
                if (tagsList.Any())
                {
                    tags = tagsList.Clone();
                    tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, data.ControllerId);
                    string errorCode = GetErrorCodes(data, tagStatus);
                    if (!string.IsNullOrEmpty(errorCode))
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, errorCode);
                    }
                }

                var message = new StringBuilder();
                var ambiguousTags = new List<OpcTag>();
                GetStorageTanksAmbiguousTags(tagStatus, tags, message, ambiguousTags);
                if (!string.IsNullOrWhiteSpace(message.ToString()))
                {
                    message.Append("Do you want to override the value in plc ?");

                    var error = new Dictionary<string, object>
                    {
                        { "Message", message.ToString() },
                        { "PlcTags", ambiguousTags }
                    };
                    return Request.CreateResponse(HttpStatusCode.Ambiguous, error);
                }
                return Request.CreateResponse(HttpStatusCode.OK, message.ToString());
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        /// <summary>
        /// Gets the storage tanks ambiguous tags.
        /// </summary>
        /// <param name="tagStatus">The tag status.</param>
        /// <param name="tags">The list of opc tags.</param>
        /// <param name="message">The message of storage tanks.</param>
        /// <param name="ambiguousTags">The ambiguous tags.</param>
        private static void GetStorageTanksAmbiguousTags(TagCollection tagStatus, List<OpcTag> tags, StringBuilder message, List<OpcTag> ambiguousTags)
        {
            if (tags != null)
            {
                foreach (OpcTag tag in tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                {
                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        if (tag.Address == plcTag.Address && tag.Value != plcTag.Value)
                        {
                            message.Append(string.Format("For Tag{0} : Entered Value is '{1}', Plc Value is '{2}'.<br>", tag.Address, tag.Value, plcTag.Value));
                            ambiguousTags.Add(tag);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Gets the error codes.
        /// </summary>
        /// <param name="data">The data of Tanks Model.</param>
        /// <param name="tagStatus">The tag status.</param>
        /// <returns>Returns the error codes</returns>
        private static string GetErrorCodes(TanksModel data, TagCollection tagStatus)
        {
            string errorCode = null;
            foreach (Tag status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
            {
                if (status.Address == data.CurrentLevelTag)
                {
                    errorCode += "804,";
                }
                if (status.Address == data.LevelDeviationTag)
                {
                    errorCode += "805,";
                }
                if (status.Address == data.SizeTag)
                {
                    errorCode += "806,";
                }
            }

            return errorCode;
        }
    }
}