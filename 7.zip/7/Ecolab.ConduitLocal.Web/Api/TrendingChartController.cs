﻿// -----------------------------------------------------------------------
// <copyright file="TrendingChartController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Trending Chart Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Ecolab.Models;
    using Services.Interfaces;

    /// <summary>
    ///     class Trending Chart Controller
    /// </summary>
    public class TrendingChartController : BaseApiController
    {
        /// <summary>
        ///     trending Chart Service
        /// </summary>
        private readonly ITrendingChartService trendingChartService;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrendingChartController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        /// <param name="trendingChartService">The user service.</param>
        public TrendingChartController(IUserService userService, IPlantService plantService, ITrendingChartService trendingChartService) : base(userService, plantService)
        {
            this.trendingChartService = trendingChartService;
        }

        /// <summary>
        ///     Get the charts based on filters
        /// </summary>
        /// <param name="chartId">The chart id.</param>
        /// <param name="washerId">Chart details based on washer or Tunnel ID </param>
        /// <param name="compId">The </param>
        /// <param name="parameterId">the parameter.</param>
        /// <param name="startDate">The start date</param>
        /// <param name="endDate">The end date</param>
        /// <returns>gets the Chart Details</returns>
        public IEnumerable<Dictionary<string, object>> GetByFilters(int chartId, int washerId, int compId, int parameterId, DateTime? startDate, DateTime? endDate)
        {
            List<TunnelReading> trendData = this.trendingChartService.GetTrendingdataDetails(chartId, washerId, compId, parameterId, Convert.ToDateTime(startDate).ToUniversalTime(), Convert.ToDateTime(endDate).ToUniversalTime(), this.UserId, this.EcolabAccountNumber);
            Dictionary<string, List<TunnelReading>> dictTrendData = trendData.AsEnumerable().Select(x => x).GroupBy(a => a.ParamterName).ToDictionary(d => d.Key, d => d.ToList());
            var dataResult = new List<Dictionary<string, object>>();

            foreach(KeyValuePair<string, List<TunnelReading>> data in dictTrendData)
            {
                var seriesList = new Dictionary<string, object>();
                seriesList["data"] = new List<object[]>();
                seriesList["name"] = data.Key;

                var desiredSeries = new Dictionary<string, object>();
                desiredSeries["data"] = new List<object[]>();
                desiredSeries["name"] = data.Key + " Standard";

                for(int j = 0; j < data.Value.Count(); j++)
                {
                    var values = new object[2];
                    values[0] = data.Value[j].TimeStamp.ToLocalTime();
                    values[1] = Math.Round(Convert.ToDouble(data.Value[j].Actual), 2);
                    ((List<object[]>)seriesList["data"]).Add(values);

                    if(!string.IsNullOrEmpty(data.Value[j].Desired))
                    {
                        var desiredValues = new object[2];
                        desiredValues[0] = data.Value[j].TimeStamp.ToLocalTime();
                        desiredValues[1] = Math.Round(Convert.ToDouble(data.Value[j].Desired), 2);
                        ((List<object[]>)desiredSeries["data"]).Add(desiredValues);
                    }
                }

                dataResult.Add(seriesList);
                if(data.Key.IndexOf("Customer") == -1 && data.Key.IndexOf("Formula Number") == -1 && data.Key.IndexOf("Transfer") == -1)
                {
                    dataResult.Add(desiredSeries);
                }
            }

            return dataResult;
        }

        /// <summary>
        ///     Get the Tunnel Details
        /// </summary>
        /// <returns>Returns the List of Tunnels</returns>
        public List<MachineSetupTunnel> GetTunnelDetails()
        {
            return this.trendingChartService.GetTunnelDetails();
        }

        /// <summary>
        ///     Get the Tunnel Details
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="chartId">Chart identifier</param>
        /// <returns>Returns the List of Tunnels</returns>
        public List<ConduitChartParameterMapping> GetParametersByTunnelId(int id, int chartId)
        {
            if(chartId == 2)
            {
                return this.trendingChartService.GetChemicalChartParametersByTunnelId(id);
            }
            return this.trendingChartService.GetParametersByTunnelId(id);
        }
    }
}