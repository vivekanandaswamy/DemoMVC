﻿// -----------------------------------------------------------------------
// <copyright file="TagManagementController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Management Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using Ecolab.Services.Interfaces;
    /// <summary>
    ///     class Tag Management Controller
    /// </summary>
    public class TagManagementController : BaseApiController
    {

        /// <summary>
        ///     Initializes a new instance of the <see cref="TagManagementController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public TagManagementController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {

        }
    }
}