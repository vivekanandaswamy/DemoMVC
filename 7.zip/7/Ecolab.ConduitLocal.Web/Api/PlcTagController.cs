﻿// -----------------------------------------------------------------------
// <copyright file="PlcTagController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The PLC Tag Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Text;
    using AutoMapper;
    using Dcs.CollectData;
    using Dcs.CollectData.Beckhoff;
    using Dcs.CollectData.Opc;
    using Dcs.Entities;
    using Ecolab.ConduitLocal.Web.Utilities;
    using Ecolab.Dcs.CollectData.Mitsubishi;
    using Ecolab.Models.Common;
    using Models.Common;
    using Models.PlantSetup;
    using Models.WasherGroup;
    using Services.Interfaces;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Enum;

    /// <summary>
    ///     Plc Tag Controller
    /// </summary>
    public class PlcTagController : BaseApiController
    {
        #region Constants

        /// <summary>
        /// MyControl Maximum Formulas
        /// </summary>
        private const int MyControl_MaximumFormulas = 99;

        /// <summary>
        /// MyControl Washer Formula Array
        /// </summary>
        private const int MyControl_WE_FormulaArray = 77;

        /// <summary>
        /// MyControl Washer Maximum Injection Steps for Dosing
        /// </summary>
        private const int MyControl_WE_MaximumInjectionSteps = 20;

        /// <summary>
        /// MyControl Washer Maximum Fields for Dosing for each Injection Step
        /// </summary>
        private const int MyControl_WE_MaximumFields = 3;

        /// <summary>
        /// MyControl Washer Maximum Temperature Analogue Controls
        /// </summary>
        private int MyControl_WE_MaximumTemperatureAnalogueControls = 1;

        /// <summary>
        /// MyControl Washer Maximum Temperature Fields
        /// </summary>
        private int MyControl_WE_MaximumTemperatureFields = 6;

        /// <summary>
        /// MyControl Washer Maximum Ph Analogue Controls
        /// </summary>
        private int MyControl_WE_MaximumPhAnalogueControls = 1;

        /// <summary>
        /// MyControl Washer Maximum Ph Fields
        /// </summary>
        private int MyControl_WE_MaximumPhFields = 6;

        /// <summary>
        /// MyControl Tunnel Formula Array
        /// </summary>
        private const int MyControl_TUN_FormulaArray = 136;

        /// <summary>
        /// MyControl Tunnel Maximum Pumps
        /// </summary>
        private const int MyControl_TUN_MaximumPumps = 26;

        /// <summary>
        /// MyControl Tunnel Maximum Dosing Points
        /// </summary>
        private const int MyControl_TUN_MaximumDosingPoints = 4;

        /// <summary>
        /// MyControl Tunnel Maximum Temperature Analogue Controls
        /// </summary>
        private const int MyControl_TUN_MaximumTemperatureAnalogueControls = 6;

        /// <summary>
        /// MyControl Tunnel Maximum Temperature Fields
        /// </summary>
        private const int MyControl_TUN_MaximumTemperatureFields = 5;

        /// <summary>
        /// PLC XL Maximum Formulas
        /// </summary>
        private const int PLCXL_MaximumFormulas = 99;

        /// <summary>
        /// PLC XL 10W Header Base Index
        /// </summary>
        private const int PLCXL10WWEHeaderBaseIndex = 3500;

        /// <summary>
        /// PLC XL 10W Header Base Index
        /// </summary>
        private const int PLCXL10WWE2HeaderBaseIndex = 3995;

        /// <summary>
        /// PLC XL 10W Temperature Base Index
        /// </summary>
        private const int PLCXL10WWE1TemperatureBaseIndex = 24300;

        /// <summary>
        /// PLC XL 10W Temperature Base Index
        /// </summary>
        private const int PLCXL10WWE2TemperatureBaseIndex = 26775;

        /// <summary>
        /// PLC XL 10W Start Delay Base Index
        /// </summary>
        private const int PLCXL10WWE1StartDelayBaseIndex = 31254;

        /// <summary>
        /// PLC XL 10W Start Delay Base Index
        /// </summary>
        private const int PLCXL10WWE2StartDelayBaseIndex = 31750;

        /// <summary>
        /// PLC XL 10W Ph Base Index
        /// </summary>
        private const int PLCXL10WWEPhBaseIndex = 29250;

        /// <summary>
        /// PLC XL 10W Ph Base Index
        /// </summary>
        private const int PLCXL10WWE2PhBaseIndex = 30240;

        /// <summary>
        /// PLC XL 10W Product Base Index
        /// </summary>
        private const int PLCXL10WWE1ProductBaseIndex = 4500;

        /// <summary>
        /// PLC XL 10W Product Base Index
        /// </summary>
        private const int PLCXL10WWE2ProductBaseIndex = 14400;

        /// <summary>
        /// PLC XL 5W1C Header Base Index
        /// </summary>
        private const int PLCXL5W1CWEHeaderBaseIndex = 4840;

        /// <summary>
        /// PLC XL 5W1C Temperature Base Index
        /// </summary>
        private const int PLCXL5W1CWETemperatureBaseIndex = 15235;

        /// <summary>
        /// PLC XL 5W1C Start Delay Base Index
        /// </summary>
        private const int PLCXL5W1CWEStartDelayBaseIndex = 30200;

        /// <summary>
        /// PLC XL 5W1C Ph Base Index
        /// </summary>
        private const int PLCXL5W1CWEPhBaseIndex = 25900;

        /// <summary>
        /// PLC XL 5W1C Product Base Index
        /// </summary>
        private const int PLCXL5W1CWEProductBaseIndex = 5335;

        /// <summary>
        /// PLC XL 5W1C Temperature Base Index
        /// </summary>
        private const int PLCXL5W1CTUN2TemperatureBaseIndex = 24640;

        /// <summary>
        /// PLC XL 5W1C Start Delay Base Index
        /// </summary>
        private const int PLCXL5W1CTUN2StartDelayBaseIndex = 30700;

        /// <summary>
        /// PLC XL 5W1C Ph Base Index
        /// </summary>
        private const int PLCXL5W1CTUN2PhBaseIndex = 31000;

        /// <summary>
        /// PLC XL 5W1C Conductivity Base Index
        /// </summary>
        private const int PLCXL5W1CTUN2ConductivityBaseIndex = 31500;

        /// <summary>
        /// PLC XL 5W1C Product Base Index
        /// </summary>
        private const int PLCXL5W1CTUN2ProductBaseIndex = 17710;

        /// <summary>
        /// PLC XL 2Cbw Temperature Base Index
        /// </summary>
        private const int PLCXL2CbwTUNTemperatureBaseIndex = 500;

        /// <summary>
        /// PLC XL 2Cbw Temperature Base Index
        /// </summary>
        private const int PLCXL2CbwTUN2TemperatureBaseIndex = 2660;

        /// <summary>
        /// PLC XL 2Cbw Start Delay Base Index
        /// </summary>
        private const int PLCXL2CbwTUNStartDelayBaseIndex = 20000;

        /// <summary>
        /// PLC XL 2Cbw Start Delay Base Index
        /// </summary>
        private const int PLCXL2CbwTUN2StartDelayBaseIndex = 21300;

        /// <summary>
        /// PLC XL 2Cbw Ph Base Index
        /// </summary>
        private const int PLCXL2CbwTUNPhBaseIndex = 20300;

        /// <summary>
        /// PLC XL 2Cbw Ph Base Index
        /// </summary>
        private const int PLCXL2CbwTUN2PhBaseIndex = 21600;

        /// <summary>
        /// PLC XL 2Cbw Conductivity Base Index
        /// </summary>
        private const int PLCXL2CbwTUNConductivityBaseIndex = 20800;

        /// <summary>
        /// PLC XL 2Cbw Conductivity Base Index
        /// </summary>
        private const int PLCXL2CbwTUN2ConductivityBaseIndex = 22100;

        /// <summary>
        /// PLC XL 2Cbw Product Base Index
        /// </summary>
        private const int PLCXL2CbwTUNProductBaseIndex = 3850;

        /// <summary>
        /// PLC XL 2Cbw Product Base Index
        /// </summary>
        private const int PLCXL2CbwTUN2ProductBaseIndex = 10780;

        /// <summary>
        /// EControl Plus Maximum Formulas
        /// </summary>
        private const int ECTRLPLUS_MaximumFormulas = 50;

        /// <summary>
        /// The ectrlplu s8 w_ w e_ header base index
        /// </summary>
        private const int ECTRLPLUS8WWEHeaderBaseIndex = 756;

        /// <summary>
        /// The ectrlplu s8 w_ w e_ temperature base index
        /// </summary>
        private const int ECTRLPLUS8WWETemperatureBaseIndex = 7400;

        /// <summary>
        /// The ectrlplu s8 w_ w e_ delay base index
        /// </summary>
        private const int ECTRLPLUS8WWEDelayBaseIndex = 5001;

        /// <summary>
        /// The ectrlplu s8 w_ w e_ ph base index
        /// </summary>
        private const int ECTRLPLUS8WWEPhBaseIndex = 6400;

        /// <summary>
        /// The ectrlplu s8 w_ w e_ product base index
        /// </summary>
        private const int ECTRLPLUS8WWEProductBaseIndex = 3001;

        /// <summary>
        /// The ectrlplu s_ tu N1_ temperature start index
        /// </summary>
        private const int ECTRLPLUSTUN1TemperatureStartIndex = 7100;

        /// <summary>
        /// The ectrlplu s_ tu N1_ ph start index
        /// </summary>
        private const int ECTRLPLUSTUN1PhStartIndex = 6700;

        /// <summary>
        /// The ectrlplu s_ tu N1_ conductivity start index
        /// </summary>
        private const int ECTRLPLUSTUN1ConductivityStartIndex = 6900;

        /// <summary>
        /// The ectrlplu s_ tu N1_ product start index
        /// </summary>
        private const int ECTRLPLUSTUN1ProductStartIndex = 1001;

        #endregion

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        /// The washer group service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///  Initializes a new instance of the <see cref="PlcTagController" /> class.
        /// </summary>
        /// <param name="plcService">The PLC Service</param>
        /// <param name="userService">The User Service</param>
        /// <param name="plantService">The Plant Service</param>
        public PlcTagController(IPlcService plcService, IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.plcService = plcService;
        }

        /// <summary>
        /// Gets Controller Info
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>
        /// List of ControllerInfoForPlcModel
        /// </returns>
        public List<ControllerInfoForPlcModel> GetControllerInfo(int controllerId)
        {
            IPlcService plcService = new Ecolab.Services.Plc.PlcService();
            return Mapper.Map<List<ControllerInfoForPlc>, List<ControllerInfoForPlcModel>>(
            plcService.GetControllerInfoForPlc(controllerId, EcolabAccountNumber));
        }

        /// <summary>
        /// Validates the washer conventional PLCXL tags.
        /// </summary>
        /// <param name="tags">The Tag Collection.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>The Tag Collection.</returns>
        public TagCollection ValidateWasherConventionalPLCXLTags(TagCollection tags, int controllerId, SourcePage sourcePage)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            if (controllerInfo != null)
            {
                if (sourcePage == SourcePage.WasherPage)
                {
                    return new TagCollection
                    {
                        Tags = new List<Tag>(ValidateWasherConventionalPLCXLTags(tags.Tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                    };
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Validates the conventional tags.
        /// </summary>
        /// <param name="tags">The Tag Collection.</param>
        /// <param name="ControllerId">The controller identifier.</param>
        /// <param name="mode">The Controller mode.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <returns>The Tag Collection.</returns>
        public TagCollection ValidateConventionalTags(TagCollection tags, int ControllerId, int mode, int tunnelNumber)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(ControllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                if (mode == 1)
                {
                    // General
                    return new TagCollection { Tags = new List<Tag>(ValidateMyConventionalGeneralTags(tags.Tags, controllerInfo.Value, ControllerId)) };
                }
                else if (mode == 2)
                {
                    // FlushTimesAndTOM
                    return new TagCollection { Tags = new List<Tag>(ValidateMyConventionalFlushTimesTomTags(tags.Tags, controllerInfo.Value, ControllerId, tunnelNumber)) }; ;
                }
                else if (mode == 3)
                {
                    // ProductDeviation
                    return new TagCollection { Tags = new List<Tag>(ValidateMyConventionalProductDeviationTags(tags.Tags, controllerInfo.Value, ControllerId, tunnelNumber)) };
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Validates my conventional general tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateMyConventionalGeneralTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };

            tags.Add(helmsTag);
            var tagSignalAcceptanceTag = beckhoffTags.Where(_ => _.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE")).FirstOrDefault();
            if (tagSignalAcceptanceTag != null)
            {
                tags.Add(new BeckhoffTag() { Address = string.Format(".uint_SignalAcceptTimeWE[{0}]", tagSignalAcceptanceTag.TagId), Value = tagSignalAcceptanceTag.Value, TagItemType = UIInputType.TypeUInt16 });
            }
            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCN uints_Helms_ConfigCN;
            uints_Helms_ConfigCN = (Uints_Helms_ConfigCN)helmsTag.ComplexObject;
            uints_Helms_ConfigCN.uint_Handshake = 65535;
            foreach (var itemTag in beckhoffTags)
            {
                if (itemTag.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE"))
                {
                    itemTag.Value = Convert.ToString(tags.Where(_ => _.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE")).FirstOrDefault().Value);
                }
                else if (!itemTag.Address.ToUpper().Contains("FLOWSWITCHNUMBER"))
                {
                    itemTag.Value = Convert.ToString(uints_Helms_ConfigCN.uint_WE_Parameter[itemTag.TagId]);
                }
                else if (itemTag.Address.ToUpper().Contains("FLOWSWITCHNUMBER"))
                {
                    itemTag.Value = Convert.ToString(uints_Helms_ConfigCN.uint_FlushWEtoWaterFS[itemTag.TagId]);
                }
            }

            return beckhoffTags;
        }

        /// <summary>
        /// Validate Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>
        /// Returns validated tags with status from PLC
        /// </returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public TagCollection ValidateTags(TagCollection tags, int controllerId, SourcePage sourcePage = 0)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            if (controllerInfo != null)
            {
                switch (controllerInfo.ControllerTypeId)
                {
                    case 1:
                        Mapper.CreateMap<Tag, OpcTag>();
                        var opcTags = new List<OpcTag>(Mapper.Map<List<Tag>, List<OpcTag>>(tags.Tags));
                        opcTags.ForEach(_ => _.Topic = controllerInfo.TopicName);
                        return new TagCollection
                        {
                            Tags = new List<Tag>(ValidateAllenBradleyTags(opcTags, controllerInfo.ControllerId, controllerInfo.TopicName, controllerInfo.Value))
                        };
                    case 2:
                        if (controllerInfo.ControllerModelId == 7)
                        {
                            if (sourcePage == SourcePage.TunnelGeneralPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(ValidateMyControlTunnelTags(tags.Tags, controllerInfo.Value, controllerId))
                                };
                            }
                            else if (sourcePage == SourcePage.TunnelAnaloguePage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(ValidateMyControlAnalogControlTags(tags.Tags, controllerInfo.Value, controllerId))
                                };
                            }
                            else if (sourcePage == SourcePage.TunnelFlushTimesTomPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(ValidateMyControlFlushTimesTOMTags(tags.Tags, controllerInfo.Value, controllerId))
                                };
                            }
                            else
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(ValidateMyControlTags(tags.Tags, controllerInfo.Value, controllerId))
                                };
                            }
                        }
                        else
                        {
                            Mapper.CreateMap<Tag, BeckhoffTag>();
                            var beckhoffTags = new List<BeckhoffTag>(Mapper.Map<List<Tag>, List<BeckhoffTag>>(tags.Tags));
                            return new TagCollection
                            {
                                Tags = new List<Tag>(ValidateBeckhoffTags(beckhoffTags, controllerInfo.Value, controllerId))
                            };
                        }
                    case 12:
                    case 13:
                    case 14:
                        if (controllerInfo.ControllerModelId == 11)
                        {
                            return new TagCollection
                            {
                                Tags = new List<Tag>(ValidatePLCXLTags(tags.Tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                            };
                        }
                        else
                        {
                            return null;
                        }
                    case 6:
                    case 7:
                        if (controllerInfo.ControllerModelId == 8)
                        {
                            return new TagCollection
                            {
                                Tags = new List<Tag>(ValidateEControlPlusTags(tags.Tags, controllerInfo.Value, controllerId))
                            };
                        }
                        else
                        {
                            return null;
                        }
                    default:
                        return null;
                }
            }
            throw new NoNullAllowedException("909");
        }
        /// <summary>
        /// Write tags method
        /// </summary>
        /// <param name="mitsubishiTag">mitsubishi Tag</param>
        /// <param name="controllerId">controller identifier</param>
        /// <param name="v">parameter v</param>
        /// <param name="washerPage">washer page.</param>
        internal void WriteTags(MitsubishiTag mitsubishiTag, int controllerId, int v, object washerPage)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Validates my control tags.
        /// </summary>
        /// <param name="tags">The List of BeckoffTags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>List of BeckoffTags</returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public List<BeckhoffTag> ValidateMyControlTags(List<BeckhoffTag> tags, int controllerId, SourcePage sourcePage)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            if (controllerInfo != null)
            {
                if (sourcePage == SourcePage.PumpsPage)
                {
                    return new List<BeckhoffTag>(ValidateMyControlPumpTags(tags, controllerInfo.Value, controllerId));
                }
                else if (sourcePage == SourcePage.ControllerSetupGeneralPage)
                {
                    return new List<BeckhoffTag>(ValidateMyControlGeneralTags(tags, controllerInfo.Value, controllerId));
                }
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Validates the PLCXL tags.
        /// </summary>
        /// <param name="tags">List of MitsubishiTags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>List of MitsubishiTags.</returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public List<MitsubishiTag> ValidatePLCXLTags(List<MitsubishiTag> tags, int controllerId, SourcePage sourcePage)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            if (controllerInfo != null)
            {
                if (sourcePage == SourcePage.PumpsPage)
                {
                    return new List<MitsubishiTag>(ValidatePLCXLTagsPumps(tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId));
                }
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Gets the mitsubishi tags.
        /// </summary>
        /// <param name="tagsList">The tags list.</param>
        /// <returns>The MitsubishiTag</returns>
        public MitsubishiTag GetMitsubishiTags(List<Tag> tagsList)
        {
            System.Text.StringBuilder addressesStringBuilder = new System.Text.StringBuilder();
            int[] arrayValues = new int[tagsList.Count];
            int i = 0;
            foreach (MitsubishiTag item in tagsList)
            {
                if (i > 0)
                {
                    addressesStringBuilder.Append("\n");
                }
                addressesStringBuilder.Append(item.Address);
                arrayValues[i] = Convert.ToInt32(item.Value);
                i++;
            }
            MitsubishiTag mitsubishiTag = new MitsubishiTag()
            {
                Address = addressesStringBuilder.ToString(),
                IntArrayData = arrayValues,
                ArrayLength = arrayValues.Length,
                TagItemType = UIInputType.TypeRandomArray
            };
            return mitsubishiTag;
        }

        /// <summary>
        /// Validate Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="topicName">Contrller Topic Name</param>
        /// <param name="opcServer">Controller Opc Server</param>
        /// <returns>
        /// Returns validated tags with status from PLC
        /// </returns>
        /// <exception cref="System.ApplicationException">901</exception>
        private IEnumerable<OpcTag> ValidateAllenBradleyTags(IList<OpcTag> tags, int controllerId, string topicName, string opcServer)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
                string opcItemFormat = ConfigurationManager.AppSettings["OpcItemFormat"];
                DataReader<OpcTag> dataReader =
                    new OpcDataReader(
                        new AllenBradleyController
                        {
                            ControllerId = controllerId,
                            Name = topicName,
                            OpcServer = opcServer
                        },
                        opcItemFormat);
                // Please check We did this for passing compilation error
                return dataReader.ReadTags(tags);
            }
            catch (Exception ex)
            {
                switch (ex.Message)
                {
                    case "Invalid_Server":
                        throw new ApplicationException("901", ex);
                    default:
                        throw;
                }
            }
        }

        /// <summary>
        /// Validate Beckhoff Tags
        /// </summary>
        /// <param name="beckhoffTags">List of Beckhoff Tags</param>
        /// <param name="amsNetId">AMS Net id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <returns>List of BeckhoffTags</returns>
        /// <exception cref="System.ApplicationException">901</exception>
        private IEnumerable<BeckhoffTag> ValidateBeckhoffTags(IList<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            var beckhoffReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);
            bool status = beckhoffReader.ConnectToPlc(amsNetId, comPort);
            if (status)
            {
                return beckhoffReader.ValidateTags(beckhoffTags);
            }
            throw new ApplicationException("901");
        }

        /// <summary>
        /// Validates my control tunnel tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateMyControlTunnelTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };

            int indexValue_x_PreDosingEnableTUN = beckhoffTags.Where(p => p.Address.ToUpper() == "KANNEGIESSERDOSAGEINPREPARATIONTANKMODE").FirstOrDefault().TagId;
            int indexValue_x_BatchOKKannegiesser = beckhoffTags.Where(p => p.Address.ToUpper() == "BATCHOK").FirstOrDefault().TagId;
            BeckhoffTag helmsTag_x_PreDosingEnableTUN = new BeckhoffTag() { Address = ".x_PreDosingEnableTUN[" + (indexValue_x_PreDosingEnableTUN + 1) + "]", TagItemType = UIInputType.TypeBool };
            BeckhoffTag helmsTag_x_BatchOKKannegiesser = new BeckhoffTag() { Address = ".x_BatchOKKannegiesser[" + (indexValue_x_BatchOKKannegiesser + 1) + "]", TagItemType = UIInputType.TypeBool };

            tags.Add(helmsTag);
            tags.Add(helmsTag_x_PreDosingEnableTUN);
            tags.Add(helmsTag_x_BatchOKKannegiesser);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;
            uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)helmsTag.ComplexObject;
            var x_PreDosingEnableTUN = helmsTag_x_PreDosingEnableTUN.Value;
            var x_BatchOKKannegiesser = helmsTag_x_BatchOKKannegiesser.Value;

            foreach (var itemTag in beckhoffTags)
            {
                if (itemTag.Address.ToUpper().Contains("KANNEGIESSERDOSAGEINPREPARATIONTANKMODE"))
                {
                    itemTag.Value = x_PreDosingEnableTUN == "true" ? "1" : "0";
                }
                else if (itemTag.Address.ToUpper().Contains("BATCHOK"))
                {
                    itemTag.Value = x_BatchOKKannegiesser == "true" ? "1" : "0";
                }
                else
                {
                    itemTag.Value = Convert.ToString(uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[itemTag.TagId]);
                }
            }

            return beckhoffTags;
        }

        /// <summary>
        /// Validates my control analog control tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateMyControlAnalogControlTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };

            tags.Add(helmsTag);
            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;
            uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)helmsTag.ComplexObject;

            foreach (var itemTag in beckhoffTags)
            {
                switch (itemTag.Address.ToUpper())
                {
                    case "SETPOINT":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].Setpoint))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].Setpoint));
                        break;
                    case "DELAYAFTERTRANSFER":
                        itemTag.Value = itemTag.TagId == 1 ?
                             Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].DelayTrsf))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].DelayTrsf));
                        break;
                    case "CONTROLDELAY":
                        itemTag.Value = itemTag.TagId == 1 ?
                            Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].CtrlDelay))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].CtrlDelay));
                        break;
                    case "MAXVALUE":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].MaxVal))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].MaxVal));
                        break;
                    case "MINVALUE":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].MinVal))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].MinVal));
                        break;
                    case "PAUSETIME":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].Pause))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].Pause));
                        break;
                    case "QUANTITY":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].Dose))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].Dose));
                        break;
                    case "MAXTIME":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].MaxTime))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].MaxTime));
                        break;
                    case "PREQUANTITY":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].FirstDose))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].FirstDose));
                        break;
                    case "PREPAUSETIME":
                        itemTag.Value = itemTag.TagId == 1 ?
                        Convert.ToString(Convert.ToDouble((uint_Helms_ConfigCNAndHelms_2.uint_pH_Setup[(itemTag.TagTypeId == 1 ? (Convert.ToInt32(itemTag.TagType) - 1) : (Convert.ToInt32(itemTag.TagType) + 2))].FisrtPause))) :
                        Convert.ToString(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_LF_Setup[(itemTag.TagTypeId == 1 ? ((Convert.ToInt32(itemTag.TagType) - 3) - 1) : ((Convert.ToInt32(itemTag.TagType) - 3) + 2))].FisrtPause));
                        break;
                    default:
                        break;
                }
            }

            return beckhoffTags;
        }

        /// <summary>
        /// Validates my control flush times tom tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateMyControlFlushTimesTOMTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

                BeckhoffDataReader dataReader = new BeckhoffDataReader(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

                List<BeckhoffTag> tags = new List<BeckhoffTag>();
                BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };

                tags.Add(helmsTag);

                dataReader.ReadMyControlTags(tags);

                Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;
                uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)helmsTag.ComplexObject;

                foreach (var item in beckhoffTags)
                {
                    //Water
                    if (item.Address.ToUpper().Contains("WATER"))
                    {
                        item.Value = Convert.ToString(uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((item.TagId == 1 ? 4 : 180) + Convert.ToInt32(item.TagType))]);
                    }
                    //Air Flush Times
                    if (item.Address.ToUpper().Contains("AIR"))
                    {
                        item.Value = Convert.ToString(uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[((item.TagId == 1 ? 20 : 196) + Convert.ToInt32(item.TagType))]);
                    }
                    //Dosing and Equipment Numbers
                    // ###BUSINESS RULE### (Dosing Point Number * 10000) + Equipment Number
                    // ###  (4 last digits = equipment number, 1 first digit = Dosing point)
                    if (item.Address.ToUpper().Contains("EQUIPMENT") || item.Address.ToUpper().Contains("DOSING"))
                    {
                        item.Value = item.Address.ToUpper().Contains("EQUIPMENT") ?
                             Convert.ToString(Convert.ToInt32(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[(item.TagId == 1 ? 121 : 297) + (Convert.ToInt32(item.TagType) - 1)]) % 10000)) :
                            Convert.ToString(Convert.ToInt32(Convert.ToDouble(uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[(item.TagId == 1 ? 121 : 297) + (Convert.ToInt32(item.TagType) - 1)]) / 10000));
                    }
                }
            }
            catch (Exception ex)
            {
                // Exception
            }

            return beckhoffTags;
        }

        /// <summary>
        /// Validates my control tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateMyControlTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag3 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCNAndHelms", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCNAndHelms).AssemblyQualifiedName };
            BeckhoffTag tag4 = new BeckhoffTag() { Address = ".x_invertMachineStop", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag5 = new BeckhoffTag() { Address = ".x_AlarmRackLeakageEnable", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag6 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
            BeckhoffTag tagWELoggerEnable = new BeckhoffTag() { Address = ".x_WandE_Enable", TagItemType = UIInputType.TypeBool };

            tags.Add(tag1);
            tags.Add(tag2);
            tags.Add(tag3);
            tags.Add(tag4);
            tags.Add(tag5);
            tags.Add(tag6);
            tags.Add(tagWELoggerEnable);

            dataReader.ReadMyControlTags(tags);
            Xs_Helms_ConfigCN x_Helms_ConfigCN;
            Uints_Helms_ConfigCN uint_Helms_ConfigCN;
            Xs_Helms_ConfigCNAndHelms x_Helms_ConfigCNAndHelms;
            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;

            x_Helms_ConfigCN = (Xs_Helms_ConfigCN)tag1.ComplexObject;
            uint_Helms_ConfigCN = (Uints_Helms_ConfigCN)tag2.ComplexObject;
            x_Helms_ConfigCNAndHelms = (Xs_Helms_ConfigCNAndHelms)tag3.ComplexObject;
            string x_invertMachineStop = tag4.Value;
            string x_AlarmRackLeakageEnable = tag5.Value;
            string x_WandE_Enable = tagWELoggerEnable.Value;
            uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)tag6.ComplexObject;

            beckhoffTags[0].Value = x_Helms_ConfigCN.x_Connex_En.ToString();
            beckhoffTags[1].Value = uint_Helms_ConfigCN.uint_Connex_Alarm_Delay.ToString();
            beckhoffTags[2].Value = uint_Helms_ConfigCN.uint_Connex_Level_Delay.ToString();
            beckhoffTags[3].Value = x_Helms_ConfigCN.x_FlushSystem_En.ToString();
            beckhoffTags[4].Value = uint_Helms_ConfigCN.uint_FlushSystem_Alarm_Delay.ToString();
            beckhoffTags[5].Value = uint_Helms_ConfigCN.uint_FlushSystem_Level_Delay.ToString();
            beckhoffTags[6].Value = x_Helms_ConfigCN.x_PMREn.ToString();
            beckhoffTags[7].Value = x_Helms_ConfigCN.x_FlushControlEn.ToString();
            beckhoffTags[8].Value = x_Helms_ConfigCN.x_HelmsTimoutEn.ToString();
            beckhoffTags[9].Value = x_Helms_ConfigCN.x_FlushLeakEn.ToString();
            beckhoffTags[10].Value = uint_Helms_ConfigCN.uint_HelmsTimout.ToString();
            beckhoffTags[11].Value = x_Helms_ConfigCN.x_Reset_Button_En.ToString();
            beckhoffTags[12].Value = x_Helms_ConfigCN.x_AlmPrgNotFinishDis.ToString();
            beckhoffTags[13].Value = uint_Helms_ConfigCN.uint_ResetAlrmTime.ToString();
            beckhoffTags[14].Value = uint_Helms_ConfigCN.uint_StopDubixTime.ToString();
            beckhoffTags[15].Value = x_Helms_ConfigCN.x_SeparateAirStopAlarm.ToString();
            beckhoffTags[16].Value = uint_Helms_ConfigCN.uint_IntermRinseTime.ToString();
            beckhoffTags[17].Value = x_invertMachineStop.ToString();
            beckhoffTags[18].Value = uint_Helms_ConfigCN.uint_AlarmAnalogFilter.ToString();
            beckhoffTags[19].Value = x_AlarmRackLeakageEnable.ToString();
            beckhoffTags[20].Value = x_WandE_Enable;
            beckhoffTags[21].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[0].ToString();
            beckhoffTags[22].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[1].ToString();
            beckhoffTags[23].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[2].ToString();
            beckhoffTags[24].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[3].ToString();
            beckhoffTags[25].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[4].ToString();
            beckhoffTags[26].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[5].ToString();
            beckhoffTags[27].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[6].ToString();
            beckhoffTags[28].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[7].ToString();
            beckhoffTags[29].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[8].ToString();
            beckhoffTags[30].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[9].ToString();
            beckhoffTags[31].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[10].ToString();
            beckhoffTags[32].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[11].ToString();
            beckhoffTags[33].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[12].ToString();
            beckhoffTags[34].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[13].ToString();
            beckhoffTags[35].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[14].ToString();
            beckhoffTags[36].Value = uint_Helms_ConfigCN.uint_LinetoWaterFS[15].ToString();
            beckhoffTags[37].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[0].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[38].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[0].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[39].Value = x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[0].ToString();
            beckhoffTags[40].Value = x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[0].ToString();
            beckhoffTags[41].Value = uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[0].ToString();
            beckhoffTags[42].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[1].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[43].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[1].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[44].Value = x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[1].ToString();
            beckhoffTags[45].Value = x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[1].ToString();
            beckhoffTags[46].Value = uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[1].ToString();
            beckhoffTags[47].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[2].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[48].Value = x_Helms_ConfigCNAndHelms.x_LineDosingMode[2].ToString().ToUpper() == "TRUE" ? "1" : "0";
            beckhoffTags[49].Value = x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[2].ToString();
            beckhoffTags[50].Value = x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[2].ToString();
            beckhoffTags[51].Value = uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[2].ToString();

            return beckhoffTags;
        }

        /// <summary>
        /// Validates the PLCXL tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidatePLCXLTags(IList<Tag> mitsubishiTags, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            switch (controllerTypeId)
            {
                case 12:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
                    break;
                case 13:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
                    break;
                default:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL2Cbw };
                    break;
            }
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            IList<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            List<Tag> tags = new List<Tag>();
            List<MitsubishiTag> mitsubishiTagList = new List<MitsubishiTag>();
            foreach (MitsubishiTag mtag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mtag);
            }
            mitsubishiTagList = ConvertMitsubishiTagsToRandomArray(mitsubishiTagsList).ToList();
            dataReader.ReadTags(mitsubishiTagList);
            mitsubishiTagsList = new List<MitsubishiTag>();
            mitsubishiTagsList = FetchMitsubishiTagsFromRandomArray(mitsubishiTagList.FirstOrDefault());
            foreach (MitsubishiTag tag in mitsubishiTagsList)
            {
                tags.Add(tag);
            }
            return tags;
        }

        /// <summary>
        /// Validates the PLCXL tags pumps.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>The list of MitsubishiTags</returns>
        private IEnumerable<MitsubishiTag> ValidatePLCXLTagsPumps(IList<MitsubishiTag> mitsubishiTags, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            switch (controllerTypeId)
            {
                case 12:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
                    break;
                case 13:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
                    break;
                default:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL2Cbw };
                    break;
            }
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            List<MitsubishiTag> rTag = new List<MitsubishiTag>();
            rTag = ConvertMitsubishiTagsToRandomArray(mitsubishiTags).ToList();
            dataReader.ReadTags(rTag);
            mitsubishiTags = new List<MitsubishiTag>();
            mitsubishiTags = FetchMitsubishiTagsFromRandomArray(rTag.FirstOrDefault());
            return mitsubishiTags;
        }

        /// <summary>
        /// Validates the washer conventional PLCXL tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateWasherConventionalPLCXLTags(IList<Tag> mitsubishiTags, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            switch (controllerTypeId)
            {
                case 12:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W, ControllerId = controllerId };
                    break;
                case 13:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C, ControllerId = controllerId };
                    break;
            }

            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            IList<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            List<Tag> tags = new List<Tag>();
            foreach (MitsubishiTag mtag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mtag);
            }
            dataReader.ReadTags(mitsubishiTagsList);
            foreach (MitsubishiTag tag in mitsubishiTagsList)
            {
                tags.Add(tag);
            }
            return tags;
        }

        /// <summary>
        /// Validates the e control plus tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> ValidateEControlPlusTags(IList<Tag> mitsubishiTags, string ipAddress, int controllerId)
        {
            MitsubishiController controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.EControlPlus, ControllerId = controllerId };
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            IList<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            List<Tag> tags = new List<Tag>();
            foreach (MitsubishiTag mtag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mtag);
            }
            dataReader.ReadTags(mitsubishiTagsList);
            foreach (MitsubishiTag tag in mitsubishiTagsList)
            {
                tags.Add(tag);
            }
            return tags;
        }

        /// <summary>
        /// Write Tags to the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>
        /// Returns the tags with status from PLC aftre write
        /// </returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public TagCollection WriteTags(TagCollection tags, int controllerId, SourcePage sourcePage = 0)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                switch (controllerInfo.ControllerTypeId)
                {
                    case 1:
                        Mapper.CreateMap<Tag, OpcTag>();
                        var opcTags = new List<OpcTag>(Mapper.Map<List<Tag>, List<OpcTag>>(tags.Tags));
                        opcTags.ForEach(_ => _.Topic = controllerInfo.TopicName);
                        return new TagCollection
                        {
                            Tags = new List<Tag>(WriteAllenBradleyTags(opcTags, controllerInfo.ControllerId, controllerInfo.TopicName, controllerInfo.Value))
                        };
                    case 2:
                        Mapper.CreateMap<BeckhoffTag, Tag>();
                        var beckhoffTags = new List<BeckhoffTag>(Mapper.Map<List<Tag>, List<BeckhoffTag>>(tags.Tags));
                        return new TagCollection
                        {
                            Tags = new List<Tag>(WriteBeckhoffTags(beckhoffTags, controllerInfo.Value, controllerId))
                        };
                    case 12: //10 Washers
                        if (controllerInfo.ControllerModelId == 11)
                        {
                            if (sourcePage == SourcePage.WasherPageGeneral || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WriteConventionalPLCXLTenWashersTags(tags.Tags, controllerInfo.Value))
                                };
                            }
                            else if (sourcePage == SourcePage.AdvancedPage || sourcePage == SourcePage.SensorsPage || sourcePage == SourcePage.MetersPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WritePLCXLTags(tags.Tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }

                    case 13: //5 Washers/1Tunnel
                        if (controllerInfo.ControllerModelId == 11)
                        {
                            if (sourcePage == SourcePage.WasherPageGeneral || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WriteConventionalPLCXLOneTunnelFiveWashersTags(tags.Tags, controllerInfo.Value))
                                };
                            }
                            else if (sourcePage == SourcePage.AdvancedPage || sourcePage == SourcePage.TunnelFlushTimesTomPage || sourcePage == SourcePage.TunnelAnaloguePage || sourcePage == SourcePage.SensorsPage || sourcePage == SourcePage.MetersPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WritePLCXLTags(tags.Tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }

                    case 14:
                        if (controllerInfo.ControllerModelId == 11)
                        {
                            if (sourcePage == SourcePage.AdvancedPage || sourcePage == SourcePage.TunnelFlushTimesTomPage || sourcePage == SourcePage.TunnelAnaloguePage || sourcePage == SourcePage.SensorsPage || sourcePage == SourcePage.MetersPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WritePLCXLTags(tags.Tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                    case 6:
                    case 7:
                        if (controllerInfo.ControllerModelId == 8)
                        {

                            if (sourcePage == SourcePage.AdvancedPage)
                            {
                                return new TagCollection
                                {
                                    Tags = new List<Tag>(WriteEControlPlusTags(tags.Tags, controllerInfo.Value, controllerId))
                                };
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                    default:
                        return null;
                }
            }
            else
            {
                return null;
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Writes the tags.
        /// </summary>
        /// <param name="mitsubishiTag">The mitsubishi tag.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        /// <param name="sourcePage">The source page.</param>
        /// <returns>
        /// The Mitsubishi Tag
        /// </returns>
        /// <exception cref="NoNullAllowedException">909 exception is occurring</exception>
        public MitsubishiTag WriteTags(MitsubishiTag mitsubishiTag, int controllerId, int washerGroupTypeId, SourcePage sourcePage = 0)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                switch (controllerInfo.ControllerTypeId)
                {
                    case 1:
                    case 2:

                    case 6://If controller is of type 8washer
                        if (controllerInfo.ControllerModelId == 8)
                        {

                            if (sourcePage == SourcePage.WasherPage || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation)
                            {
                                return WriteEcontrolPlusTagsWasherGeneralAndFlushTimeAndProductDeviation(mitsubishiTag, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId);
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                    case 7://If controller is of type 1tunnel-6washer
                        if (controllerInfo.ControllerModelId == 8)
                        {

                            if (sourcePage == SourcePage.WasherPage || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation)
                            {
                                return WriteEcontrolPlusTagsWasherGeneralAndFlushTimeAndProductDeviation(mitsubishiTag, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId);
                            }
                            else
                            {
                                return null;
                            }
                        }
                        else
                        {
                            return null;
                        }
                    case 12:
                        if (controllerInfo.ControllerModelId == 11 && (sourcePage == SourcePage.WasherPage || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation))
                        {
                            //For Conventional : 12	10 Washers, 13  1 Tunnel 5 Washers, 2-Tunnels
                            return WritePLCXLWashersTags(mitsubishiTag, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId);
                        }
                        else
                        {
                            return null;
                        }
                    case 13:
                    case 14:
                        if (controllerInfo.ControllerModelId == 11 && (sourcePage == SourcePage.WasherPage || sourcePage == SourcePage.WasherPageFlushTime || sourcePage == SourcePage.WasherPageProductDeviation))
                        {
                            //For Conventional : 12	10 Washers, 13  1 Tunnel 5 Washers, 2-Tunnels
                            return WritePLCXLWashersTags(mitsubishiTag, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId);
                        }
                        else
                        {
                            return null;
                        }

                    default:
                        return null;
                }
            }
            else
            {
                return null;
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Writes the tunnel tags.
        /// </summary>
        /// <param name="tunnelTags">The tunnel tags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="mode">The mode data.</param>
        /// <param name="tunnelIndex">Index of the tunnel.</param>
        /// <returns>The Tag Collection.</returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public TagCollection WriteTunnelTags(TagCollection tunnelTags, int controllerId, int mode, int tunnelIndex = 0)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                if (mode == 1)
                {
                    //Hold Conditions
                    return new TagCollection { Tags = new List<Tag>(WriteMyControlTunnelConditionTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
                if (mode == 2)
                {
                    //General
                    return new TagCollection { Tags = new List<Tag>(WriteMyControlTunnelTags(tunnelTags.Tags, controllerInfo.Value, controllerId, tunnelIndex)) };
                }
                else if (mode == 3)
                {
                    //Flush Times
                    return new TagCollection { Tags = new List<Tag>(WriteMyControlTunnelFlushTimesTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
                else if (mode == 4)
                {
                    //Analogue Digital
                    return new TagCollection { Tags = new List<Tag>(WriteMyControlTunnelAnalogueTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
                else if (mode == 5)
                {
                    //Eject Conditions
                    return new TagCollection { Tags = new List<Tag>(WriteMyControlConventionalConditionTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
                else if (mode == 6)
                {
                    //Eject Conditions
                    return new TagCollection { Tags = new List<Tag>(WriteConventionalGeneralTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
                else if (mode == 7)
                {
                    //Conventional Flush Times
                    return new TagCollection { Tags = new List<Tag>(WriteConventionalFlushTOMandDeviationTags(tunnelTags.Tags, controllerInfo.Value, controllerId)) };
                }
            }
            else
            {
                return null;
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Gets the tags status.
        /// </summary>
        /// <param name="tags">The mycontrol tags data.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="validate">if set to <c>true</c> [validate].</param>
        /// <returns>Return the status of validating mycontrol tags data.</returns>
        public string ValidateOrWriteTags(List<OpcTag> tags, int controllerId, bool validate = false)
        {
            var returnStatus = string.Empty;
            TagCollection tagStatus = null;

            if (validate)
            {
                tagStatus = ValidateTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerId);
            }
            else
            {
                tagStatus = WriteTags(new TagCollection { Tags = new List<Tag>(tags) }, controllerId);
            }

            foreach (var status in tagStatus.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
            {
                var last = tagStatus.Tags.LastIndexOf(status);
                if (last != 14 && !string.IsNullOrEmpty(status.Address))
                {
                    returnStatus += status.Address + ",";
                }
                else
                {
                    if (!string.IsNullOrEmpty(returnStatus))
                    {
                        returnStatus += status.Address;
                    }
                }
            }

            return returnStatus;
        }

        /// <summary>
        /// Writes the conventional PLCXL convetional washers tags.
        /// </summary>
        /// <param name="mitsubishiTag">The mitsubishi tag.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>The Mitsubishi Tag.</returns>
        private MitsubishiTag WritePLCXLWashersTags(MitsubishiTag mitsubishiTag, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            if (controllerTypeId == 12)
            {
                //10 Washers
                controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
            }
            else if (controllerTypeId == 13)
            {
                //5 Washers/1Tunnel
                controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
            }
            else if (controllerTypeId == 14)
            {
                //2-Tunnels
                controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL2Cbw };
            }

            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTag(mitsubishiTag);
            ((PLCXLEthernetWriter)writer).Dispose();
            return mitsubishiTag;
        }

        /// <summary>
        /// Writes my control tunnel analogue tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of Tags.</returns>
        private IEnumerable<Tag> WriteMyControlTunnelAnalogueTags(List<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };

            tags.Add(tag1);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Uints_Helms_ConfigCNAndHelms_2)tag1.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.uint_Handshake = 65535;

            //SET POINT
            var setPointTags_pH1 = beckhoffTags.Where(s => s.Address.ToUpper() == "SETPOINT" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int setPointTags = setPointTags_pH1.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemSetPoint in setPointTags_pH1)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[setPointTags].Setpoint = Convert.ToUInt16(itemSetPoint.Value);
                setPointTags++;
            }

            setPointTags = 0;
            var setPointTags_pH2 = beckhoffTags.Where(s => s.Address.ToUpper() == "SETPOINT" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            setPointTags = setPointTags_pH2.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemSetPoint in setPointTags_pH2)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[setPointTags].Setpoint = Convert.ToUInt16(itemSetPoint.Value);
                setPointTags++;
            }

            //DELAY TRANSFER
            var delayAfterTransfer_pH1 = beckhoffTags.Where(s => s.Address.ToUpper() == "DELAYAFTERTRANSFER" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int delayAfterTransfer = delayAfterTransfer_pH1.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemDelayAfterTransfer in delayAfterTransfer_pH1)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[delayAfterTransfer].DelayTrsf = Convert.ToUInt16(itemDelayAfterTransfer.Value);
                delayAfterTransfer++;
            }

            delayAfterTransfer = 0;
            var delayAfterTransfer_pH2 = beckhoffTags.Where(s => s.Address.ToUpper() == "DELAYAFTERTRANSFER" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            delayAfterTransfer = delayAfterTransfer_pH2.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemDelayAfterTransfer in delayAfterTransfer_pH2)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[delayAfterTransfer].DelayTrsf = Convert.ToUInt16(itemDelayAfterTransfer.Value);
                delayAfterTransfer++;
            }

            //FIRST DOSE
            var firstDose_pH1 = beckhoffTags.Where(s => s.Address.ToUpper() == "PREQUANTITY" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int iFirstDose = firstDose_pH1.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemFirstDose in firstDose_pH1)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[iFirstDose].FirstDose = Convert.ToUInt16(itemFirstDose.Value);
                iFirstDose++;
            }

            iFirstDose = 0;
            var firstDose_pH2 = beckhoffTags.Where(s => s.Address.ToUpper() == "PREQUANTITY" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            iFirstDose = firstDose_pH2.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemFirstDose in firstDose_pH2)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[iFirstDose].FirstDose = Convert.ToUInt16(itemFirstDose.Value);
                iFirstDose++;
            }

            //FIRST PAUSE
            var firstPause_pH1 = beckhoffTags.Where(s => s.Address.ToUpper() == "PREPAUSETIME" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int iFirstPause = firstPause_pH1.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemFirstPause in firstPause_pH1)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[iFirstPause].FisrtPause = Convert.ToUInt16(itemFirstPause.Value);
                iFirstPause++;
            }

            iFirstPause = 0;
            var firstPause_pH2 = beckhoffTags.Where(s => s.Address.ToUpper() == "PREPAUSETIME" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            iFirstPause = firstPause_pH2.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemFirstPause in firstPause_pH2)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[iFirstPause].FisrtPause = Convert.ToUInt16(itemFirstPause.Value);
                iFirstPause++;
            }

            //DOSE
            var dose_pH1 = beckhoffTags.Where(s => s.Address.ToUpper() == "QUANTITY" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int iDose = dose_pH1.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemDose in dose_pH1)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[iDose].Dose = Convert.ToUInt16(itemDose.Value);
                iDose++;
            }

            iFirstPause = 0;
            var dose_pH2 = beckhoffTags.Where(s => s.Address.ToUpper() == "QUANTITY" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            iDose = dose_pH2.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemDose in dose_pH2)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[iDose].Dose = Convert.ToUInt16(itemDose.Value);
                iDose++;
            }

            //CONTROL DELAY
            var controlDelay_pH = beckhoffTags.Where(s => s.Address.ToUpper() == "CONTROLDELAY" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int controlDelayTags = controlDelay_pH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemControlDelay in controlDelay_pH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[controlDelayTags].CtrlDelay = Convert.ToUInt16(itemControlDelay.Value);
                controlDelayTags++;
            }

            controlDelayTags = 0;
            var controlDelay_lH = beckhoffTags.Where(s => s.Address.ToUpper() == "CONTROLDELAY" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            controlDelayTags = controlDelay_lH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemControlDelay in controlDelay_lH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[controlDelayTags].CtrlDelay = Convert.ToUInt16(itemControlDelay.Value);
                controlDelayTags++;
            }

            //MAX TIME
            var maxTime_pH = beckhoffTags.Where(s => s.Address.ToUpper() == "MAXTIME" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int iMaxTimeTags = maxTime_pH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMaxTime in maxTime_pH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[iMaxTimeTags].MaxTime = Convert.ToUInt16(itemMaxTime.Value);
                iMaxTimeTags++;
            }

            iMaxTimeTags = 0;
            var maxTime_lH = beckhoffTags.Where(s => s.Address.ToUpper() == "MAXTIME" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            iMaxTimeTags = maxTime_lH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMaxTime in maxTime_lH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[iMaxTimeTags].MaxTime = Convert.ToUInt16(itemMaxTime.Value);
                iMaxTimeTags++;
            }

            //MAX VALUE
            var maxValue_pH = beckhoffTags.Where(s => s.Address.ToUpper() == "MAXVALUE" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int iMaxValueTags = maxValue_pH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMaxValue in maxValue_pH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[iMaxValueTags].MaxVal = Convert.ToUInt16(itemMaxValue.Value);
                iMaxValueTags++;
            }

            iMaxValueTags = 0;
            var maxValue_lH = beckhoffTags.Where(s => s.Address.ToUpper() == "MAXVALUE" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            iMaxValueTags = maxValue_lH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMaxValue in maxValue_lH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[iMaxValueTags].MaxVal = Convert.ToUInt16(itemMaxValue.Value);
                iMaxValueTags++;
            }

            //MIN VALUE
            int minValueTags = 0;
            var minValue_pH = beckhoffTags.Where(s => s.Address.ToUpper() == "MINVALUE" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            minValueTags = minValue_pH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMinValue in minValue_pH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[minValueTags].MinVal = Convert.ToUInt16(itemMinValue.Value);
                minValueTags++;
            }

            minValueTags = 0;
            var minValue_lH = beckhoffTags.Where(s => s.Address.ToUpper() == "MINVALUE" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            minValueTags = minValue_lH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemMinValue in minValue_lH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[minValueTags].MinVal = Convert.ToUInt16(itemMinValue.Value);
                minValueTags++;
            }

            //PAUSE TIME
            var pauseTime_pH = beckhoffTags.Where(s => s.Address.ToUpper() == "PAUSETIME" && s.TagId == 1).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            int pauseTimeTags = pauseTime_pH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemPauseTime in pauseTime_pH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_pH_Setup[pauseTimeTags].Pause = Convert.ToUInt16(itemPauseTime.Value);
                pauseTimeTags++;
            }

            pauseTimeTags = 0;
            var pauseTime_lH = beckhoffTags.Where(s => s.Address.ToUpper() == "PAUSETIME" && s.TagId == 2).ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 0 or else start from 3
            pauseTimeTags = pauseTime_lH.Where(s => s.TagTypeId == 1).Count() > 0 ? 0 : 3;
            foreach (var itemPauseTime in pauseTime_lH)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_LF_Setup[pauseTimeTags].Pause = Convert.ToUInt16(itemPauseTime.Value);
                pauseTimeTags++;
            }

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
             new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes my control tunnel flush times tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of tags</returns>
        private IEnumerable<Tag> WriteMyControlTunnelFlushTimesTags(List<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };

            tags.Add(tag1);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Uints_Helms_ConfigCNAndHelms_2)tag1.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.uint_Handshake = 65535;

            //Water
            var waterTags = beckhoffTags.Where(s => s.Address.ToUpper() == "WATER").ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 5 or else start from 181
            int iwaterTags = waterTags.Where(s => s.TagId == 1).Count() > 0 ? 5 : 181;
            foreach (var itemWaterTags in waterTags)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_Tun_Parameter[iwaterTags] = Convert.ToUInt16(itemWaterTags.Value);
                if ((itemWaterTags.TagId == 1 && iwaterTags == 20) || (itemWaterTags.TagId == 2 && iwaterTags == 196))
                {
                    //If Tunnel Number = 1 and Tag Address = 20 then breaking the loop.
                    //If Tunnel Number = 2 and Tag Address = 196 then breaking the loop.
                    break;
                }
                else
                {
                    iwaterTags++;
                }
            }

            //Air Flush Times
            var airFlushTags = beckhoffTags.Where(s => s.Address.ToUpper() == "AIR").ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 5 or else start from 181
            int iAirFlushTags = airFlushTags.Where(s => s.TagId == 1).Count() > 0 ? 21 : 197;
            foreach (var itemAirFlushTags in airFlushTags)
            {
                uint_Helms_ConfigCNAndHelms_2_1.uint_Tun_Parameter[iAirFlushTags] = Convert.ToUInt16(itemAirFlushTags.Value);
                if ((itemAirFlushTags.TagId == 1 && iAirFlushTags == 36) || (itemAirFlushTags.TagId == 2 && iAirFlushTags == 212))
                {
                    //If Tunnel Number = 1 and Tag Address = 36 then breaking the loop.
                    break;
                }
                else
                {
                    iAirFlushTags++;
                }
            }

            //Equipment && Dosing
            var equipmentTags = beckhoffTags.Where(s => s.Address.ToUpper() == "EQUIPMENT").ToList();
            var dosingTags = beckhoffTags.Where(s => s.Address.ToUpper() == "DOSING").ToList();
            //This is used to distunguish the data to be posted in PLC based on tunnel number - if tunnerl number is 1 then start from 5 or else start from 181
            int iEquipmentTags = equipmentTags.Where(s => s.TagId == 1).Count() > 0 ? 121 : 297;
            int dosingIndex = 0;
            foreach (var itemEquipmentTags in equipmentTags)
            {
                // ###BUSINESS RULE### (Dosing Point Number * 10000) + Equipment Number               
                var computedData = (Convert.ToDecimal(dosingTags[dosingIndex] != null ? itemEquipmentTags.Value : "0")) + (Convert.ToDecimal(dosingTags[dosingIndex].Value) * 10000);
                uint_Helms_ConfigCNAndHelms_2_1.uint_Tun_Parameter[iEquipmentTags] = Convert.ToUInt16(computedData);
                if ((itemEquipmentTags.TagId == 1 && iEquipmentTags == 142) || (itemEquipmentTags.TagId == 2 && iEquipmentTags == 318))
                {
                    //If Tunnel Number = 1 and Tag Address = 142 then breaking the loop.
                    break;
                }
                else
                {
                    iEquipmentTags++;
                    dosingIndex++;
                }
            }

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
             new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes my control tags.
        /// </summary>
        /// <param name="tags">The list of BeckhoffTags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="pg">The source page details.</param>
        /// <returns>The tag collection</returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public TagCollection WriteMyControlTags(List<BeckhoffTag> tags, int controllerId, SourcePage pg)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                if (controllerInfo.ControllerModelId == 7)
                {
                    //advanced
                    if (pg == SourcePage.AdvancedPage)
                    {
                        return new TagCollection
                        {
                            Tags = new List<Tag>(WriteMyControlAdvanceTags(tags, controllerInfo.Value, controllerId))
                        };
                    }
                    else if (pg == SourcePage.PumpsPage)
                    {
                        //Pumps
                        return new TagCollection
                        {
                            Tags = new List<Tag>(WriteMyControlPumpTags(tags, controllerInfo.Value, controllerId))
                        };
                    }
                    else if (pg == SourcePage.WasherPage || pg == SourcePage.FormulaPage)
                    {
                        //Washers or Formula
                        return new TagCollection
                        {
                            // Tags = new List<Tag>(WriteMyControlWasherTags(tags.Tags, controllerInfo.Value, controllerId))
                        };
                    }
                    else if (pg == SourcePage.ControllerSetupGeneralPage)
                    {
                        //General Tab
                        return new TagCollection
                        {
                            Tags = new List<Tag>(WriteBeckhoffTags(tags, controllerInfo.Value, controllerId))
                        };
                    }
                }
            }
            else
            {
                return null;
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Writes the PLCXL tags.
        /// </summary>
        /// <param name="tags">The list of MitsubishiTags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="pg">The SourcePage name.</param>
        /// <returns>The Tag Collection</returns>
        /// <exception cref="NoNullAllowedException">909</exception>
        public TagCollection WritePLCXLTags(List<MitsubishiTag> tags, int controllerId, SourcePage pg)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            if (controllerInfo != null)
            {
                if (controllerInfo.ControllerModelId == 11)
                {
                    if (pg == SourcePage.PumpsPage)//Pumps
                    {

                        return new TagCollection
                        {

                            Tags = new List<Tag>(WritePLCXLTagsPumps(tags, controllerInfo.Value, controllerId, controllerInfo.ControllerTypeId))
                        };
                    }
                    else if (pg == SourcePage.WasherPage)//Washers
                    {

                        return new TagCollection
                        {
                            // Tags = new List<Tag>(WriteMyControlWasherTags(tags.Tags, controllerInfo.Value, controllerId))
                        };
                    }
                    else if (pg == SourcePage.FormulaPage)//Formula
                    {

                        return new TagCollection
                        {
                            // Tags = new List<Tag>(WriteMyControlFormulaTags(tags.Tags, controllerInfo.Value, controllerId))
                        };
                    }

                }
            }
            else
            {
                return null;
            }
            throw new NoNullAllowedException("909");
        }

        /// <summary>
        /// Write Allen Bradley Tags against with the PLC
        /// </summary>
        /// <param name="tags">tags from UI</param>
        /// <param name="controllerId">controller Id</param>
        /// <param name="topicName">Contrller Topic Name</param>
        /// <param name="opcServer">Controller Opc Server</param>
        /// <returns>
        /// Returns validated tags with status from PLC
        /// </returns>
        private IEnumerable<OpcTag> WriteAllenBradleyTags(IList<OpcTag> tags, int controllerId, string topicName, string opcServer)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            string opcItemFormat = ConfigurationManager.AppSettings["OpcItemFormat"];
            DataWriter<OpcTag> dataWriter =
                new OpcDataWriter(
                    new AllenBradleyController { ControllerId = controllerId, Name = topicName, OpcServer = opcServer },
                    opcItemFormat);
            return dataWriter.WriteTags(tags);
        }

        /// <summary>
        /// Write Beckhoff Tags
        /// </summary>
        /// <param name="beckhoffTags">List of Beckhoff Tags</param>
        /// <param name="amsNetId">AMS Net id data</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>The list of BeckhoffTags</returns>
        /// <exception cref="System.ApplicationException">902</exception>
        private IEnumerable<BeckhoffTag> WriteBeckhoffTags(IList<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
                var beckhoffWriter =
                    new BeckoffDataWriter(
                        new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort },
                        string.Empty, amsNetId, comPort);
                beckhoffWriter.ConnectToPlc(amsNetId, comPort);

                return beckhoffWriter.WriteTags(beckhoffTags);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("902", ex);
            }
        }

        /// <summary>
        /// Writes Tunnel tags to PLC
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="tunnelIndex">Index of the tunnel.</param>
        /// <returns>Returns list of tags.</returns>
        private IEnumerable<Tag> WriteMyControlTunnelTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId, int tunnelIndex)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
            BeckhoffTag tag2 = new BeckhoffTag() { Address = ".x_PreDosingEnableTUN[" + tunnelIndex + "]", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag3 = new BeckhoffTag() { Address = ".x_BatchOKKannegiesser[" + tunnelIndex + "]", TagItemType = UIInputType.TypeBool };
            tags.Add(tag1);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Uints_Helms_ConfigCNAndHelms_2)tag1.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.uint_Handshake = 65535;

            foreach (var item in beckhoffTags)
            {
                if (item.Address.ToUpper().Contains("KANNEGIESSERDOSAGEINPREPARATIONTANKMODE"))
                {
                    tag2.Value = item.Value == "1" ? "true" : "false";
                }
                else if (item.Address.ToUpper().Contains("BATCHOK"))
                {
                    tag3.Value = item.Value == "1" ? "true" : "false";
                }
                else
                {
                    ///Here TagId is used to identify the index point of PLC address where we need to update the value
                    uint_Helms_ConfigCNAndHelms_2_1.uint_Tun_Parameter[item.TagId] = Convert.ToUInt16(item.Value);
                }
            }

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            tags.Add(tag2);
            tags.Add(tag3);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes my control advance tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of tags.</returns>
        private IEnumerable<Tag> WriteMyControlAdvanceTags(IList<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag3 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCNAndHelms", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCNAndHelms).AssemblyQualifiedName };
            BeckhoffTag tag4 = new BeckhoffTag() { Address = ".x_invertMachineStop", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag5 = new BeckhoffTag() { Address = ".x_AlarmRackLeakageEnable", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag6 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
            BeckhoffTag tag7 = new BeckhoffTag() { Address = ".x_WandE_Enable", TagItemType = UIInputType.TypeBool };

            tags.Add(tag1);
            tags.Add(tag2);
            tags.Add(tag3);
            tags.Add(tag4);
            tags.Add(tag5);
            tags.Add(tag6);
            tags.Add(tag7);

            dataReader.ReadMyControlTags(tags);
            Xs_Helms_ConfigCN x_Helms_ConfigCN;
            Uints_Helms_ConfigCN uint_Helms_ConfigCN;
            Xs_Helms_ConfigCNAndHelms x_Helms_ConfigCNAndHelms;
            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;

            x_Helms_ConfigCN = (Xs_Helms_ConfigCN)tag1.ComplexObject;
            uint_Helms_ConfigCN = (Uints_Helms_ConfigCN)tag2.ComplexObject;
            x_Helms_ConfigCNAndHelms = (Xs_Helms_ConfigCNAndHelms)tag3.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)tag6.ComplexObject;

            x_Helms_ConfigCN.x_Handshake = true;
            x_Helms_ConfigCNAndHelms.x_Handshake = true;
            uint_Helms_ConfigCN.uint_Handshake = 65535;
            uint_Helms_ConfigCNAndHelms_2.uint_Handshake = 65535;
            x_Helms_ConfigCN.x_Connex_En = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[0].Value));
            uint_Helms_ConfigCN.uint_Connex_Alarm_Delay = Convert.ToUInt16(beckhoffTags[1].Value);
            uint_Helms_ConfigCN.uint_Connex_Level_Delay = Convert.ToUInt16(beckhoffTags[2].Value);
            x_Helms_ConfigCN.x_FlushSystem_En = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[3].Value));
            uint_Helms_ConfigCN.uint_FlushSystem_Alarm_Delay = Convert.ToUInt16(beckhoffTags[4].Value);
            uint_Helms_ConfigCN.uint_FlushSystem_Level_Delay = Convert.ToUInt16(beckhoffTags[5].Value);
            x_Helms_ConfigCN.x_PMREn = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[6].Value));
            x_Helms_ConfigCN.x_FlushControlEn = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[7].Value));
            x_Helms_ConfigCN.x_HelmsTimoutEn = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[8].Value));
            x_Helms_ConfigCN.x_FlushLeakEn = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[9].Value));
            uint_Helms_ConfigCN.uint_HelmsTimout = Convert.ToUInt16(beckhoffTags[10].Value);
            x_Helms_ConfigCN.x_Reset_Button_En = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[11].Value));
            x_Helms_ConfigCN.x_AlmPrgNotFinishDis = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[12].Value));
            uint_Helms_ConfigCN.uint_ResetAlrmTime = Convert.ToUInt16(beckhoffTags[13].Value);
            uint_Helms_ConfigCN.uint_StopDubixTime = Convert.ToUInt16((beckhoffTags[14].Value == string.Empty ? "0" : beckhoffTags[14].Value));
            x_Helms_ConfigCN.x_SeparateAirStopAlarm = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[15].Value));
            uint_Helms_ConfigCN.uint_IntermRinseTime = Convert.ToUInt16(beckhoffTags[16].Value);
            tag4.Value = Convert.ToString(Convert.ToBoolean(Convert.ToInt32(beckhoffTags[17].Value)));
            uint_Helms_ConfigCN.uint_AlarmAnalogFilter = Convert.ToUInt16(beckhoffTags[18].Value);
            tag5.Value = Convert.ToString(Convert.ToBoolean(Convert.ToInt32(beckhoffTags[19].Value)));
            tag7.Value = Convert.ToString(Convert.ToBoolean(Convert.ToInt32(beckhoffTags[20].Value)));
            uint_Helms_ConfigCN.uint_LinetoWaterFS[0] = Convert.ToUInt16(beckhoffTags[21].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[1] = Convert.ToUInt16(beckhoffTags[22].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[2] = Convert.ToUInt16(beckhoffTags[23].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[3] = Convert.ToUInt16(beckhoffTags[24].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[4] = Convert.ToUInt16(beckhoffTags[25].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[5] = Convert.ToUInt16(beckhoffTags[26].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[6] = Convert.ToUInt16(beckhoffTags[27].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[7] = Convert.ToUInt16(beckhoffTags[28].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[8] = Convert.ToUInt16(beckhoffTags[29].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[9] = Convert.ToUInt16(beckhoffTags[30].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[10] = Convert.ToUInt16(beckhoffTags[31].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[11] = Convert.ToUInt16(beckhoffTags[32].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[12] = Convert.ToUInt16(beckhoffTags[33].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[13] = Convert.ToUInt16(beckhoffTags[34].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[14] = Convert.ToUInt16(beckhoffTags[35].Value);
            uint_Helms_ConfigCN.uint_LinetoWaterFS[15] = Convert.ToUInt16(beckhoffTags[36].Value);

            x_Helms_ConfigCNAndHelms.x_LineDosingMode[0] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[37].Value));
            x_Helms_ConfigCNAndHelms.x_LineDosingMode[0] = beckhoffTags[38].Value == "0" ? false : true;
            x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[0] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[39].Value));
            x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[0] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[40].Value));
            uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[0] = Convert.ToUInt16(beckhoffTags[41].Value);
            x_Helms_ConfigCNAndHelms.x_LineDosingMode[1] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[42].Value));
            x_Helms_ConfigCNAndHelms.x_LineDosingMode[1] = beckhoffTags[43].Value == "0" ? false : true;
            x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[1] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[44].Value));
            x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[1] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[45].Value));
            uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[1] = Convert.ToUInt16(beckhoffTags[46].Value);
            x_Helms_ConfigCNAndHelms.x_LineDosingMode[2] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[47].Value));
            x_Helms_ConfigCNAndHelms.x_LineDosingMode[2] = beckhoffTags[48].Value == "0" ? false : true;
            x_Helms_ConfigCNAndHelms.x_AuxiliaryPumpUsed[2] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[49].Value));
            x_Helms_ConfigCN.x_UseFlowMeter_for_FlowCheck[2] = Convert.ToBoolean(Convert.ToInt32(beckhoffTags[50].Value));
            uint_Helms_ConfigCNAndHelms_2.uint_TCR_PumpNb[2] = Convert.ToUInt16(beckhoffTags[51].Value);

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes my control pump tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of tags.</returns>
        private IEnumerable<Tag> WriteMyControlPumpTags(List<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();//Helms_Info.uint_Helms_ConfigCNAndHelms_2
            BeckhoffTag tagUint_Helms_ConfigCNAndHelms_2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", IsValid = true, TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName, Value = "0" };
            BeckhoffTag tagUint_Helms_ConfigCN = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", IsValid = true, TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName, Value = "0" };

            tags.Add(tagUint_Helms_ConfigCNAndHelms_2);
            tags.Add(tagUint_Helms_ConfigCN);
            beckhoffTags.Each(x => x.IsValid = true);

            dataReader.ReadMyControlTags(tags);
            Uints_Helms_ConfigCNAndHelms_2 uints_Helms_ConfigCNAndHelms_2;
            Uints_Helms_ConfigCN uints_Helms_ConfigCN;
            foreach (BeckhoffTag tg in beckhoffTags)
            {
                foreach (BeckhoffTag item in tags)
                {
                    if (tg.TagItemType == UIInputType.TypeObject)
                    {
                        if (tg.Address == item.Address)
                        {
                            if (tg.Address == "Helms_Info.uint_Helms_ConfigCN")
                            {
                                for (int i = 0; i < ((Uints_Helms_ConfigCN)item.ComplexObject).uint_WE_Parameter.Length; i++)
                                {
                                    if (((Uints_Helms_ConfigCN)item.ComplexObject).uint_WE_Parameter[i] != ((Uints_Helms_ConfigCN)tg.ComplexObject).uint_WE_Parameter[i])
                                    {
                                        if (((Uints_Helms_ConfigCN)tg.ComplexObject).uint_WE_Parameter[i] != 6550)
                                        {
                                            ((Uints_Helms_ConfigCN)item.ComplexObject).uint_WE_Parameter[i] = ((Uints_Helms_ConfigCN)tg.ComplexObject).uint_WE_Parameter[i];
                                        }
                                    }
                                }
                                ((Uints_Helms_ConfigCN)item.ComplexObject).uint_Handshake = 65535;
                            }
                            else if (tg.Address == "Helms_Info.uint_Helms_ConfigCNAndHelms_2")
                            {
                                for (int i = 0; i < ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Tun_Parameter.Length; i++)
                                {
                                    if (((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Tun_Parameter[i] != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Tun_Parameter[i])
                                    {
                                        //item -- plc with tags,  tg -- from appl
                                        if (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Tun_Parameter[i] != 6550)
                                        {
                                            ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Tun_Parameter[i] = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Tun_Parameter[i];
                                        }
                                    }
                                }
                                for (int i = 0; i < ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter.Length; i++)
                                {
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].DosLine != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].DosLine) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].DosLine != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].DosLine = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].DosLine;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FMMaxTime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMMaxTime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMMaxTime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FMMaxTime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMMaxTime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FSDelay != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FSDelay) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FSDelay != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FSDelay = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FSDelay;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].PumpCalib != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].PumpCalib) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].PumpCalib != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].PumpCalib = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].PumpCalib;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].AuxiliaryPumpCalib != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].AuxiliaryPumpCalib) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].AuxiliaryPumpCalib != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].AuxiliaryPumpCalib = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].AuxiliaryPumpCalib;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FMCalib != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMCalib) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMCalib != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].FMCalib = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].FMCalib;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].TUNNb_DD != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].TUNNb_DD) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].TUNNb_DD != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].TUNNb_DD = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].TUNNb_DD;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].CompNb_DD != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].CompNb_DD) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].CompNb_DD != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Pump_Parameter[i].CompNb_DD = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_Pump_Parameter[i].CompNb_DD;
                                    }
                                }
                                for (int i = 0; i < ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter.Length; i++)
                                {
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].DosLine != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].DosLine) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].DosLine != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].DosLine = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].DosLine;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FMMaxTime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMMaxTime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMMaxTime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FMMaxTime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMMaxTime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FSDelay != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FSDelay) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FSDelay != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FSDelay = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FSDelay;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PumpCalib != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PumpCalib) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PumpCalib != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PumpCalib = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PumpCalib;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PreFlushTime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PreFlushTime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].StNightFlush != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].StNightFlush) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].StNightFlush != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].StNightFlush = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].StNightFlush;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PreFlushTime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].PreFlushTime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].PreFlushTime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].NightFlushTime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].NightFlushTime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].NightFlushTime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].NightFlushTime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].NightFlushTime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FlushPumpingtime != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FlushPumpingtime) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FlushPumpingtime != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FlushPumpingtime = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FlushPumpingtime;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FMCalib != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMCalib) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMCalib != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].FMCalib = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].FMCalib;
                                    }
                                    if ((((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].METype != ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].METype) && (((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].METype != 6550))
                                    {
                                        ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_ME_Parameter[i].METype = ((Uints_Helms_ConfigCNAndHelms_2)tg.ComplexObject).uint_ME_Parameter[i].METype;
                                    }
                                }

                                ((Uints_Helms_ConfigCNAndHelms_2)item.ComplexObject).uint_Handshake = 65535;
                            }
                        }
                    }
                }
            }
            foreach (BeckhoffTag tg in beckhoffTags)
            {
                if (tg.TagItemType != UIInputType.TypeObject)
                {
                    tags.Add(tg);
                }
            }
            if (((Uints_Helms_ConfigCNAndHelms_2)tags.Where(x => x.Address == "Helms_Info.uint_Helms_ConfigCNAndHelms_2").FirstOrDefault().ComplexObject) != null)
            {
                uints_Helms_ConfigCNAndHelms_2 = ((Uints_Helms_ConfigCNAndHelms_2)tags.Where(x => x.Address == "Helms_Info.uint_Helms_ConfigCNAndHelms_2").FirstOrDefault().ComplexObject);
                uints_Helms_ConfigCNAndHelms_2.uint_Handshake = 65535;
            }
            if (((Uints_Helms_ConfigCN)tags.Where(x => x.Address == "Helms_Info.uint_Helms_ConfigCN").FirstOrDefault().ComplexObject) != null)
            {
                uints_Helms_ConfigCN = ((Uints_Helms_ConfigCN)tags.Where(x => x.Address == "Helms_Info.uint_Helms_ConfigCN").FirstOrDefault().ComplexObject);
                uints_Helms_ConfigCN.uint_Handshake = 65535;
            }
            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                   new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);
            beckOffWriter.WriteMyControlTags(tags);
            return beckhoffTags;
        }

        /// <summary>
        /// Validates my control pump tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        public IEnumerable<BeckhoffTag> ValidateMyControlPumpTags(List<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

                BeckhoffDataReader dataReader = new BeckhoffDataReader(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

                List<BeckhoffTag> tags = new List<BeckhoffTag>();//Helms_Info.uint_Helms_ConfigCNAndHelms_2
                BeckhoffTag tagUint_Helms_ConfigCNAndHelms_2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", IsValid = true, TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName, Value = "0" };
                BeckhoffTag tagUint_Helms_ConfigCN = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", IsValid = true, TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName, Value = "0" };

                tags.Add(tagUint_Helms_ConfigCNAndHelms_2);
                tags.Add(tagUint_Helms_ConfigCN);
                beckhoffTags.Each(x => x.IsValid = true);
                foreach (BeckhoffTag tg in beckhoffTags)
                {
                    if (tg.TagItemType != UIInputType.TypeObject)
                    {
                        tags.Add(tg);
                    }
                }

                dataReader.ReadMyControlTags(tags);
                return tags;
            }
            catch (Exception ex)
            {
                string x = ex.Message;
                return new List<BeckhoffTag>();
            }
        }

        /// <summary>
        /// Validates my control general tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        public IEnumerable<BeckhoffTag> ValidateMyControlGeneralTags(List<BeckhoffTag> beckhoffTags, string amsNetId, int controllerId)
        {
            try
            {
                int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

                BeckhoffDataReader dataReader = new BeckhoffDataReader(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

                dataReader.ReadMyControlTags(beckhoffTags);
                return beckhoffTags;
            }
            catch (Exception ex)
            {
                string x = ex.Message;
                return new List<BeckhoffTag>();
            }
        }

        /// <summary>
        /// Writes the conventional PLCXL one tunnel five washers tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteConventionalPLCXLOneTunnelFiveWashersTags(IList<Tag> mitsubishiTags, string ipAddress)
        {
            List<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            foreach (MitsubishiTag mitsubishiTag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mitsubishiTag);
            }
            MitsubishiController controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTags(mitsubishiTagsList);
            ((PLCXLEthernetWriter)writer).Dispose();
            return mitsubishiTagsList;
        }

        /// <summary>
        /// Writes the econtrol plus tags washer general and flush time and product deviation.
        /// </summary>
        /// <param name="mitsubishiTag">The mitsubishi tag.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>The Mitsubishi tag</returns>
        private MitsubishiTag WriteEcontrolPlusTagsWasherGeneralAndFlushTimeAndProductDeviation(MitsubishiTag mitsubishiTag, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            if (controllerTypeId == 6)
            {
                controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.EControlPlus8W };
            }
            else
            {
                controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.EControlPlus6W1T };
            }

            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTag(mitsubishiTag);
            return mitsubishiTag;
        }

        /// <summary>
        /// Writes the PLCXL tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        public IEnumerable<Tag> WritePLCXLTags(IList<Tag> mitsubishiTags, string ipAddress, int controllerId, int controllerTypeId)
        {
            List<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            foreach (MitsubishiTag mitsubishiTag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mitsubishiTag);
            }
            MitsubishiController controller = new MitsubishiController();
            switch (controllerTypeId)
            {
                case 12:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
                    break;
                case 13:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
                    break;
                default:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL2Cbw };
                    break;
            }
            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTags(ConvertMitsubishiTagsToRandomArray(mitsubishiTagsList.ToList()));
            ((PLCXLEthernetWriter)writer).Dispose();
            return mitsubishiTagsList;
        }

        /// <summary>
        /// Writes the PLCXL tags pumps.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IEnumerable<MitsubishiTag> WritePLCXLTagsPumps(IList<MitsubishiTag> mitsubishiTags, string ipAddress, int controllerId, int controllerTypeId)
        {
            MitsubishiController controller = new MitsubishiController();
            switch (controllerTypeId)
            {
                case 12:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
                    break;
                case 13:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL5W1C };
                    break;
                default:
                    controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL2Cbw };
                    break;
            }
            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTags(ConvertMitsubishiTagsToRandomArray(mitsubishiTags.ToList()));
            ((PLCXLEthernetWriter)writer).Dispose();
            return mitsubishiTags;
        }

        /// <summary>
        /// Writes the conventional PLCXL ten washers tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteConventionalPLCXLTenWashersTags(IList<Tag> mitsubishiTags, string ipAddress)
        {
            List<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            foreach (MitsubishiTag mitsubishiTag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mitsubishiTag);
            }
            MitsubishiController controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.PLCXL10W };
            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTags(mitsubishiTagsList);
            ((PLCXLEthernetWriter)writer).Dispose();
            return mitsubishiTagsList;
        }

        /// <summary>
        /// Converts the mitsubishi tags to random array.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IList<MitsubishiTag> ConvertMitsubishiTagsToRandomArray(IList<MitsubishiTag> mitsubishiTags)
        {
            System.Text.StringBuilder addressesStringBuilder = new System.Text.StringBuilder();
            int[] arrayValues = new int[mitsubishiTags.Count];
            int i = 0;
            List<MitsubishiTag> randomTag = new List<MitsubishiTag>();
            foreach (MitsubishiTag item in mitsubishiTags)
            {
                if (i > 0)
                {
                    addressesStringBuilder.Append("\n");
                }
                addressesStringBuilder.Append(item.Address);
                arrayValues[i] = item.TagItemType == UIInputType.TypeBool ? Convert.ToInt32(((item.Value.ToLower() == "true" || item.Value.ToLower() == "1") ? "1" : "0")) : Convert.ToInt32(item.Value);
                i++;
            }
            randomTag.Add(new MitsubishiTag()
            {
                Address = addressesStringBuilder.ToString(),
                IntArrayData = arrayValues,
                ArrayLength = arrayValues.Length,
                TagItemType = UIInputType.TypeRandomArray
            });
            return randomTag;
        }

        /// <summary>
        /// Fetches the mitsubishi tags from random array.
        /// </summary>
        /// <param name="randomArray">The random array.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IList<MitsubishiTag> FetchMitsubishiTagsFromRandomArray(MitsubishiTag randomArray)
        {
            string[] tagAddresses = randomArray.Address.Split('\n');
            int[] arrayValues = randomArray.IntArrayData;
            List<MitsubishiTag> mitsubishiTags = new List<MitsubishiTag>();
            for (int i = 0; i < tagAddresses.Length; i++)
            {
                if (!string.IsNullOrEmpty(tagAddresses[i]))
                {
                    mitsubishiTags.Add(new MitsubishiTag()
                    {
                        Address = tagAddresses[i].ToString(),
                        Value = arrayValues[i].ToString(),
                        TagItemType = UIInputType.TypeInt
                    });
                }
            }
            return mitsubishiTags;
        }

        /// <summary>
        /// Writes the e control plus tags.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="ipAddress">The ip address.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteEControlPlusTags(IList<Tag> mitsubishiTags, string ipAddress, int controllerId)
        {
            MitsubishiController controller = new MitsubishiController() { HostAdress = ipAddress, PLCType = MitsubishiPLCType.EControlPlus, ControllerId = controllerId };
            IList<MitsubishiTag> mitsubishiTagsList = new List<MitsubishiTag>();
            foreach (MitsubishiTag mtag in mitsubishiTags)
            {
                mitsubishiTagsList.Add(mtag);
            }
            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            writer.WriteTags(mitsubishiTagsList);
            return mitsubishiTags;
        }

        /// <summary>
        /// Writes my control tunnel condition tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteMyControlTunnelConditionTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag()
            {
                Address = "Helms_Info.x_Helms_ConfigCN",
                TagItemType = UIInputType.TypeObject,
                ComplexObjectType = typeof(Xs_Helms_ConfigCN).AssemblyQualifiedName
            };

            tags.Add(tag1);

            dataReader.ReadMyControlTags(tags);

            Xs_Helms_ConfigCN xs_Helms_ConfigCN;
            xs_Helms_ConfigCN = (Xs_Helms_ConfigCN)tag1.ComplexObject;
            xs_Helms_ConfigCN.x_Handshake = true;

            foreach (var item in beckhoffTags)
            {
                ///Here TagId is used to identify the index point of PLC address where we need to update the value                
                xs_Helms_ConfigCN.x_StopEjectTunCondition[item.TagId] = Convert.ToBoolean(Convert.ToInt32(item.Value));
            }
            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes my control conventional condition tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteMyControlConventionalConditionTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCN).AssemblyQualifiedName };
            tags.Add(tag1);

            dataReader.ReadMyControlTags(tags);

            Xs_Helms_ConfigCN uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Xs_Helms_ConfigCN)tag1.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.x_Handshake = true;

            foreach (var item in beckhoffTags)
            {
                ///Here TagId is used to identify the index point of PLC address where we need to update the value
                uint_Helms_ConfigCNAndHelms_2_1.x_StopWeCondition[item.TagId] = Convert.ToBoolean(Convert.ToInt32(item.Value));
            }

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Writes the conventional general tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteConventionalGeneralTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tagUints_Helms_ConfigCN = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
            tags.Add(tagUints_Helms_ConfigCN);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCN uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Uints_Helms_ConfigCN)tagUints_Helms_ConfigCN.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.uint_Handshake = 65535;

            foreach (var item in beckhoffTags)
            {//Here TagId is used to identify the index point of PLC address where we need to update the value
                if (item.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE"))
                {
                    tags.Add(new BeckhoffTag() { Address = string.Format(".uint_SignalAcceptTimeWE[{0}]", item.TagId), Value = item.Value, TagItemType = UIInputType.TypeUInt16 });
                }
                else if (!item.Address.ToUpper().Contains("FLOWSWITCHNUMBER") && !item.Address.ToUpper().Contains("SIGNALACCEPTTIMEWE"))
                {
                    uint_Helms_ConfigCNAndHelms_2_1.uint_WE_Parameter[item.TagId] = Convert.ToUInt16(item.Value);
                    tagUints_Helms_ConfigCN.Value = item.Value;
                }
                else if (item.Address.ToUpper().Contains("FLOWSWITCHNUMBER"))
                {
                    uint_Helms_ConfigCNAndHelms_2_1.uint_FlushWEtoWaterFS[item.TagId] = Convert.ToUInt16(item.Value);
                    tagUints_Helms_ConfigCN.Value = item.Value;
                }
            }
            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);
            beckOffWriter.WriteMyControlTags(tags);
            return beckhoffTags;
        }

        /// <summary>
        /// Writes the conventional flush to mand deviation tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> WriteConventionalFlushTOMandDeviationTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
            tags.Add(tag1);
            dataReader.ReadMyControlTags(tags);
            Uints_Helms_ConfigCN uint_Helms_ConfigCNAndHelms_2_1;
            uint_Helms_ConfigCNAndHelms_2_1 = (Uints_Helms_ConfigCN)tag1.ComplexObject;
            uint_Helms_ConfigCNAndHelms_2_1.uint_Handshake = 65535;

            foreach (var item in beckhoffTags)
            {
                ///Here TagId is used to identify the index point of PLC address where we need to update the value
                uint_Helms_ConfigCNAndHelms_2_1.uint_WE_Parameter[item.TagId] = Convert.ToUInt16(item.Value);
                tag1.Value = item.Value;
            }

            BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
               new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            beckOffWriter.WriteMyControlTags(tags);

            return beckhoffTags;
        }

        /// <summary>
        /// Validates my conventional flush times tom tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> ValidateMyConventionalFlushTimesTomTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId, int tunnelNumber)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            const int conventionalPLCIndex = 72;
            int startIndex = ((tunnelNumber - 1) * conventionalPLCIndex);
            int tomStartIndex = 52;
            int airStartTagIndex = 40;
            int iwaterstartTagIndex = 28;
            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };

            tags.Add(helmsTag);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCN objuint_Helms_ConfigCN;
            objuint_Helms_ConfigCN = (Uints_Helms_ConfigCN)helmsTag.ComplexObject;
            objuint_Helms_ConfigCN.uint_Handshake = 65535;

            foreach (var item in beckhoffTags)
            {
                //Water For Type Water 30…41
                if (item.Address.ToUpper().Contains("WATER"))
                {
                    item.Value = Convert.ToString(objuint_Helms_ConfigCN.uint_WE_Parameter[(iwaterstartTagIndex + (Convert.ToInt32(item.TagType)) + startIndex)]);
                }
                //Air Flush Times 42…53
                if (item.Address.ToUpper().Contains("AIR"))
                {
                    item.Value = Convert.ToString(objuint_Helms_ConfigCN.uint_WE_Parameter[(airStartTagIndex + (Convert.ToInt32(item.TagType)) + startIndex)]);
                }
                //TOM TimeOutMachine 54..65 
                if (item.Address.ToUpper().Contains("EQUIPMENT"))
                {
                    item.Value = Convert.ToString(objuint_Helms_ConfigCN.uint_WE_Parameter[(tomStartIndex + (Convert.ToInt32(item.TagType)) + startIndex)]);
                }
            }
            return beckhoffTags;
        }

        /// <summary>
        /// Validates my conventional product deviation tags.
        /// </summary>
        /// <param name="beckhoffTags">The beckhoff tags.</param>
        /// <param name="amsNetId">The ams net identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <returns>Returns list of Tags.</returns>
        private IEnumerable<Tag> ValidateMyConventionalProductDeviationTags(IList<Tag> beckhoffTags, string amsNetId, int controllerId, int tunnelNumber)
        {
            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);
            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = amsNetId, Comport = comPort }, string.Empty, amsNetId, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            BeckhoffTag helmsTag = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };

            tags.Add(helmsTag);

            dataReader.ReadMyControlTags(tags);

            Uints_Helms_ConfigCN objuint_Helms_ConfigCN;
            objuint_Helms_ConfigCN = (Uints_Helms_ConfigCN)helmsTag.ComplexObject;

            foreach (var item in beckhoffTags)
            {
                // For  Type ProductDeviation 3…28
                if (item.Address.ToUpper().Contains("PRODUCTDEVIATION"))
                {
                    item.Value = Convert.ToString(objuint_Helms_ConfigCN.uint_WE_Parameter[(item.TagId)]);
                }
            }
            return beckhoffTags;
        }

        /// <summary>
        /// Writes the e control plus device tags.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeID">The controller type identifier.</param>
        /// <param name="tagList">The tag list.</param>
        public void WriteEControlPlusDeviceTags(int controllerId, int controllerTypeID, List<MitsubishiTag> tagList)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            string IpAddress = controllerInfo.Value;
            MitsubishiController controller = new MitsubishiController() { ControllerId = controllerId, HostAdress = IpAddress };
            controller.PLCType = (MitsubishiPLCType)controllerTypeID;
            DataWriter<MitsubishiTag> dataWriter = MitsubishiFactory.GetDataWriter(controller);
            dataWriter.WriteTags(tagList);
        }

        /// <summary>
        /// Reads the e control plus device tags.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerTypeID">The controller type identifier.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        public List<MitsubishiTag> ReadEControlPlusDeviceTags(int controllerId, int controllerTypeID)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            string IpAddress = controllerInfo.Value;

            MitsubishiTag cbwParametersTag = new MitsubishiTag() { Address = "D317", TagItemType = UIInputType.TypeArray, ArrayLength = 68 };
            MitsubishiTag weParametersTag = new MitsubishiTag() { Address = "D516", TagItemType = UIInputType.TypeArray, ArrayLength = 30 * 8 };

            //FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
            MitsubishiTag pumpParametersTag = new MitsubishiTag() { Address = "D390", TagItemType = UIInputType.TypeArray, ArrayLength = 60 };

            //Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            MitsubishiTag flowTag = new MitsubishiTag() { Address = "M901", TagItemType = UIInputType.TypeRandomArray, ArrayLength = 100 };

            //FlowMeterPulsesPerLiter,MaxTimeFlowMeter
            MitsubishiTag flowIntTags = new MitsubishiTag() { Address = "D464", TagItemType = UIInputType.TypeArray, ArrayLength = 20 };

            List<MitsubishiTag> tagList = new List<MitsubishiTag>() { cbwParametersTag, weParametersTag, pumpParametersTag, flowTag, flowIntTags };
            MitsubishiController controller = new MitsubishiController() { ControllerId = controllerId, HostAdress = IpAddress };
            controller.PLCType = (MitsubishiPLCType)controllerTypeID;
            StringBuilder tagAdress = new StringBuilder(1000);
            for (int i = 901; i <= 1000; i++)
            {
                if (i > 901)
                    tagAdress.Append("\n");
                tagAdress.Append("M" + i.ToString());
            }
            flowTag.Address = tagAdress.ToString();
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            dataReader.ReadTags(tagList);
            return tagList;
        }

        /// <summary>
        /// Writes the e control plus tags with random array.
        /// </summary>
        /// <param name="mitsubishiTags">The mitsubishi tags.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <exception cref="System.ApplicationException">901 Application Exception</exception>
        public void WriteEControlPlusTagsWithRandomArray(List<Tag> mitsubishiTags, int controllerId)
        {
            try
            {
                if (mitsubishiTags != null && mitsubishiTags.Count > 0)
                {
                    ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
                    MitsubishiController controller = new MitsubishiController() { HostAdress = controllerInfo.Value, PLCType = MitsubishiPLCType.EControlPlus, ControllerId = controllerId };
                    MitsubishiTag mitsubishiTag = new MitsubishiTag()
                    {
                        Address = string.Join("\n", mitsubishiTags.Select(_ => _.Address)),
                        IntArrayData = mitsubishiTags.Select(_ => Convert.ToInt32(Convert.ToDecimal((_.Value)))).ToArray(),
                        ArrayLength = mitsubishiTags.Count,
                        TagItemType = UIInputType.TypeRandomArray
                    };
                    DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
                    writer.WriteTag(mitsubishiTag);
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("901", ex);
            }
        }

        #region "Meters and Sensors"

        /// <summary>
        /// Write MyControl Settings For Meters
        /// </summary>
        /// <param name="meter">The meter Value of Meter.</param>
        /// <param name="controllerId">Controller Id of Meter</param>
        /// <param name="areResetTags">Are Reset Tags</param>
        public void WriteMyControlSettingsForMeters(MeterWebModel meter, int controllerId, bool areResetTags)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            List<BeckhoffTag> tags = GetMyControlMeterTags(meter, controllerInfo, areResetTags).ToList();

            if (tags.Count > 0)
            {
                BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                        new BeckhoffController { ControllerId = controllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                beckOffWriter.WriteMyControlTags(tags);
            }
        }

        /// <summary>
        /// Write MyControl Settings For Sensors
        /// </summary>
        /// <param name="sensor">The Sensor data</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="areResetTags">Are Reset Tags</param>
        public void WriteMyControlSettingsForSensors(SensorWebModel sensor, int controllerId, bool areResetTags)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            List<BeckhoffTag> tags = GetMyControlSensorTags(sensor, controllerInfo, areResetTags).ToList();

            if (tags.Count > 0)
            {
                BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                beckOffWriter.WriteMyControlTags(tags);
            }
        }

        /// <summary>
        /// Get MyControl Meter Tags
        /// </summary>
        /// <param name="meter">The Meter web model data</param>
        /// <param name="controllerInfo">The Controller Info</param>
        /// <param name="areResetTags">Are Reset Tags</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        public IEnumerable<BeckhoffTag> GetMyControlMeterTags(MeterWebModel meter, ControllerInfoForPlcModel controllerInfo, bool areResetTags)
        {
            List<BeckhoffTag> tags = new List<BeckhoffTag>();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            if (meter.ISWaterEnergyLogSel == true && meter.ExternalCounter > 0)
            {
                string meterName = areResetTags == true ? string.Empty : meter.Description;
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_Enable", TagItemType = UIInputType.TypeBool, Value = meter.ISWaterEnergyLogSel.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".str_WandE_DigInpName[" + meter.ExternalCounter + "]", TagItemType = UIInputType.TypeString, Value = meterName, SizetoRead = meterName.Length });
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_DigInp_Config[" + meter.ExternalCounter + ",2]", TagItemType = UIInputType.TypeBool, Value = areResetTags == true ? "false" : meter.CounterUsage.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_DigInp_Config[" + meter.ExternalCounter + ",3]", TagItemType = UIInputType.TypeBool, Value = areResetTags == true ? "false" : meter.RunningTimeUsage.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".uint_WandE_DigInp_Config[" + meter.ExternalCounter + "]", TagItemType = UIInputType.TypeUInt16, Value = areResetTags == true ? "0" : Convert.ToString((int)meter.Calibration) });
            }
            else
            {
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_Enable", TagItemType = UIInputType.TypeBool, Value = meter.ISWaterEnergyLogSel.ToString() });

                if (meter.CounterNum > 0)
                {
                    BeckhoffDataReader dataReader = new BeckhoffDataReader(
                    new BeckhoffController { ControllerId = controllerInfo.ControllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                    int CalibrationCodeValue = (int)meter.Calibration;

                    if (meter.IsTunnel)
                    {
                        BeckhoffTag Tag_Helms_ConfigCNAndHelms_2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
                        tags.Add(Tag_Helms_ConfigCNAndHelms_2);

                        dataReader.ReadMyControlTags(tags);

                        Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;
                        uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)Tag_Helms_ConfigCNAndHelms_2.ComplexObject;
                        uint_Helms_ConfigCNAndHelms_2.uint_Handshake = 65535;

                        int tunnelNumber = meter.LfsWasherNumber;
                        int tunnelRootIndex = (tunnelNumber - 1) * 176;
                        int compartmentNumber = 0;

                        if (meter.MachineId.HasValue)
                        {
                            compartmentNumber = (meter.MachineId.Value >= 1 && meter.MachineId.Value <= 25) ? meter.MachineId.Value : 0;
                        }

                        switch (meter.MeterType)
                        {
                            case "2":
                                if (meter.CounterNum == 1)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (144 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (150 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                else if (meter.CounterNum == 2)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (145 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (151 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                else if (meter.CounterNum == 3)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (146 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (152 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                else if (meter.CounterNum == 4)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (147 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (153 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                else if (meter.CounterNum == 5)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (148 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (154 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                else if (meter.CounterNum == 6)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (149 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (155 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                break;
                            default:
                                break;
                        }

                        Tag_Helms_ConfigCNAndHelms_2.ComplexObject = uint_Helms_ConfigCNAndHelms_2;
                    }
                    else
                    {
                        int lfsNumber = meter.LfsWasherNumber;

                        if (lfsNumber != 0)
                        {
                            BeckhoffTag Tag_Helms_ConfigCN = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
                            tags.Add(Tag_Helms_ConfigCN);

                            dataReader.ReadMyControlTags(tags);

                            Uints_Helms_ConfigCN uint_Helms_ConfigCN;
                            uint_Helms_ConfigCN = (Uints_Helms_ConfigCN)Tag_Helms_ConfigCN.ComplexObject;
                            uint_Helms_ConfigCN.uint_Handshake = 65535;

                            int lfsRootIndex = (lfsNumber - 1) * 72;

                            switch (meter.MeterType)
                            {
                                case "2":
                                    if (meter.CounterNum == 1)
                                    {
                                        uint_Helms_ConfigCN.uint_WE_Parameter[lfsRootIndex + (66 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    }
                                    else if (meter.CounterNum == 2)
                                    {
                                        uint_Helms_ConfigCN.uint_WE_Parameter[lfsRootIndex + (67 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    }
                                    break;
                                default:
                                    break;
                            }

                            Tag_Helms_ConfigCN.ComplexObject = uint_Helms_ConfigCN;
                        }
                    }
                }
            }

            return tags;
        }
        /// <summary>
        /// Get MyControl Sensor Tags
        /// </summary>
        /// <param name="sensor">The Sensor Data</param>
        /// <param name="controllerInfo">The Controller Info</param>
        /// <param name="areResetTags">Are Reset Tags</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        public IEnumerable<BeckhoffTag> GetMyControlSensorTags(SensorWebModel sensor, ControllerInfoForPlcModel controllerInfo, bool areResetTags)
        {
            List<BeckhoffTag> tags = new List<BeckhoffTag>();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            if (sensor.ISWaterEnergyLogSel == true && sensor.ExternalSensor > 0)
            {
                string sensorName = areResetTags == true ? string.Empty : sensor.SensorName;
                bool Is_4_20_mA_OutputType = sensor.OutputType == "4-20mA" ? true : false;
                tags.Add(new BeckhoffTag() { Address = ".str_WandE_AnaInpName[" + sensor.ExternalSensor + "]", TagItemType = UIInputType.TypeString, Value = sensorName, SizetoRead = sensorName.Length });
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",1]", TagItemType = UIInputType.TypeBool, Value = areResetTags == true ? "false" : Is_4_20_mA_OutputType.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".x_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",2]", TagItemType = UIInputType.TypeBool, Value = areResetTags == true ? "false" : sensor.AlarmEnable.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".uint_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",1]", TagItemType = UIInputType.TypeUInt16, Value = areResetTags == true ? "0" : Convert.ToString((int)sensor.CalibrationValue4) });
                tags.Add(new BeckhoffTag() { Address = ".uint_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",2]", TagItemType = UIInputType.TypeUInt16, Value = areResetTags == true ? "0" : Convert.ToString((int)sensor.CalibrationValue20) });
                tags.Add(new BeckhoffTag() { Address = ".uint_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",3]", TagItemType = UIInputType.TypeUInt16, Value = areResetTags == true ? "0" : sensor.MinimumAlarmValue.ToString() });
                tags.Add(new BeckhoffTag() { Address = ".uint_WandE_AnaInp_Config[" + sensor.ExternalSensor + ",4]", TagItemType = UIInputType.TypeUInt16, Value = areResetTags == true ? "0" : sensor.MaximumAlarmValue.ToString() });
            }
            else
            {
                if (sensor.SensorNum > 0)
                {
                    BeckhoffDataReader dataReader = new BeckhoffDataReader(
                            new BeckhoffController { ControllerId = controllerInfo.ControllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                    int CalibrationCodeValue = 0;
                    if (sensor.OutputType == "4-20mA")
                    {
                        CalibrationCodeValue = GetCalibrationValueWithFactor(sensor.SensorType, sensor.CalibrationValue20) + 1 * 10000;
                    }
                    else
                    {
                        CalibrationCodeValue = GetCalibrationValueWithFactor(sensor.SensorType, sensor.CalibrationValue20) + 0 * 10000;
                    }

                    if (sensor.IsTunnel)
                    {
                        BeckhoffTag Tag_Helms_ConfigCNAndHelms_2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
                        tags.Add(Tag_Helms_ConfigCNAndHelms_2);

                        dataReader.ReadMyControlTags(tags);

                        Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;
                        uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)Tag_Helms_ConfigCNAndHelms_2.ComplexObject;
                        uint_Helms_ConfigCNAndHelms_2.uint_Handshake = 65535;

                        int tunnelNumber = sensor.LfsWasherNumber;
                        int tunnelRootIndex = (tunnelNumber - 1) * 176;
                        int compartmentNumber = 0;
                        if (sensor.MachineId.HasValue)
                        {
                            compartmentNumber = (sensor.MachineId.Value >= 1 && sensor.MachineId.Value <= 25) ? sensor.MachineId.Value : 0;
                        }

                        int pump = (sensor.PumpNumber >= 1 && sensor.PumpNumber <= 26) ? sensor.PumpNumber : 0;

                        int specialControl = 0;
                        int PumpCompartmentCodeValue = 0;
                        int PumpSpecialControlCompartmentCodeValue = 0;

                        PumpCompartmentCodeValue = pump + compartmentNumber * 1000;
                        PumpSpecialControlCompartmentCodeValue = pump + specialControl + compartmentNumber * 1000;

                        switch (sensor.SensorType)
                        {
                            case 1:
                                if (sensor.SensorNum == 1)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (156 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (162 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 2)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (157 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (163 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 3)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (158 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (164 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpSpecialControlCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 4)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (159 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (165 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpSpecialControlCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 5)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (160 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (166 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 6)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (161 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (167 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                break;
                            case 2:
                                if (sensor.SensorNum == 1)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (168 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (170 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                else if (sensor.SensorNum == 2)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (169 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (171 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(compartmentNumber);
                                }
                                break;
                            case 4:
                                if (sensor.SensorNum == 1)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (172 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (173 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(PumpCompartmentCodeValue);
                                }
                                break;
                            case 5:
                                if (sensor.SensorNum == 1)
                                {
                                    uint_Helms_ConfigCNAndHelms_2.uint_Tun_Parameter[tunnelRootIndex + (174 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                }
                                break;
                            default:
                                break;
                        }

                        Tag_Helms_ConfigCNAndHelms_2.ComplexObject = uint_Helms_ConfigCNAndHelms_2;
                    }
                    else
                    {
                        int lfsNumber = sensor.LfsWasherNumber;
                        if (lfsNumber != 0)
                        {
                            BeckhoffTag Tag_Helms_ConfigCN = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
                            tags.Add(Tag_Helms_ConfigCN);

                            dataReader.ReadMyControlTags(tags);

                            Uints_Helms_ConfigCN uint_Helms_ConfigCN;
                            uint_Helms_ConfigCN = (Uints_Helms_ConfigCN)Tag_Helms_ConfigCN.ComplexObject;
                            uint_Helms_ConfigCN.uint_Handshake = 65535;

                            int lfsRootIndex = (lfsNumber - 1) * 72;

                            switch (sensor.SensorType)
                            {
                                case 1:
                                    uint_Helms_ConfigCN.uint_WE_Parameter[lfsRootIndex + (68 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    break;
                                case 2:
                                    uint_Helms_ConfigCN.uint_WE_Parameter[lfsRootIndex + (69 - 1)] = areResetTags == true ? Convert.ToUInt16(0) : Convert.ToUInt16(CalibrationCodeValue);
                                    break;
                                default:
                                    break;
                            }

                            Tag_Helms_ConfigCN.ComplexObject = uint_Helms_ConfigCN;
                        }                        
                    }
                }
            }

            return tags;
        }

        /// <summary>
        /// Get Calibration Value With Factor
        /// </summary>
        /// <param name="sensorType">The Sensor Type</param>
        /// <param name="calibration">The Calibration</param>
        /// <returns>Returns Calibration ValueWithFactor.</returns>
        public int GetCalibrationValueWithFactor(int? sensorType, decimal calibration)
        {
            int calibrationValue = 0;

            switch (sensorType)
            {
                //Temperature, Weight
                case 1:
                case 5:
                    calibrationValue = (int)(calibration * 10);
                    break;
                //PH,LF
                case 2:
                case 4:
                    calibrationValue = (int)(calibration * 100);
                    break;
            }

            return calibrationValue;
        }

        #endregion

        #region "Formula Settings"

        /// <summary>
        /// Write Washer Group Formula Settings To MyControl PLC
        /// </summary>
        /// <param name="washerGroupFormulaDetails">Washer Group Formula Details</param>
        /// <param name="controllerId">The Controller Id</param>
        public void WriteMyControlWasherGroupFormulaSettings(Models.WasherGroup.WasherGroupFormulaDetails washerGroupFormulaDetails, int controllerId)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            BeckhoffDataReader dataReader = new BeckhoffDataReader(
                new BeckhoffController { ControllerId = controllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();

            if (washerGroupFormulaDetails.WasherGroupTypeId == 1)
            {
                #region "Conventional Formulas"

                if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                {
                    List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                    foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                    {
                        tags.AddRange(GetConventionalFormulaResetTagsForMyControl(deletedFormulaNumber));
                    }
                }

                foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                {
                    if (washerFormula.ProgramNumber <= MyControl_MaximumFormulas)
                    {
                        List<int> washerFormulaList = new List<int>(MyControl_WE_FormulaArray);

                        //Header Fields
                        tags.Add(new BeckhoffTag() { Address = ".uint_ProgCategory[1," + washerFormula.ProgramNumber + "]", TagItemType = UIInputType.TypeInt, Value = washerFormula.EcolabTextileCategoryID.ToString() });

                        //Include products in all Dosing Steps
                        List<Models.WasherGroup.WasherFormulaDosingStepProduct> allProducts = new List<Models.WasherGroup.WasherFormulaDosingStepProduct>();
                        foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                        {
                            foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts)
                            {
                                allProducts.Add(product);
                            }
                        }

                        //Product Fields
                        int[,] dosingArray = new int[MyControl_WE_MaximumInjectionSteps, MyControl_WE_MaximumFields];
                        int productIndex = 0;
                        foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in allProducts)
                        {
                            productIndex += 1;
                            if (productIndex >= 1 && productIndex <= MyControl_WE_MaximumInjectionSteps)
                            {
                                //Product Fields
                                dosingArray[productIndex - 1, 0] = Convert.ToInt32(String.Format("{0:D3}{1:D2}", product.InjectionNumber, product.EquipmentNumber));
                                dosingArray[productIndex - 1, 1] = (int)(product.Quantity * 10);
                                dosingArray[productIndex - 1, 2] = product.Delay;
                            }
                        }

                        //Temparature Control Fields
                        int[,] temperatureAnalogArray = new int[MyControl_WE_MaximumTemperatureAnalogueControls, MyControl_WE_MaximumTemperatureFields];
                        int temperatureAnalogIndex = 0;
                        foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(MyControl_WE_MaximumTemperatureAnalogueControls))
                        {
                            temperatureAnalogIndex += 1;
                            if (temperatureAnalogIndex >= 1 && temperatureAnalogIndex <= MyControl_WE_MaximumTemperatureAnalogueControls)
                            {
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 0] = temperatureAnalogueControlStep.StepNumber;
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 1] = (int)(temperatureAnalogueControlStep.SetPointTemperature * 10);
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 2] = temperatureAnalogueControlStep.StartDelay;
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 3] = temperatureAnalogueControlStep.MinimumTime;
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 4] = temperatureAnalogueControlStep.AcceptedDelay;
                                temperatureAnalogArray[temperatureAnalogIndex - 1, 5] = temperatureAnalogueControlStep.EquipmentNumber;
                            }
                        }

                        //Ph Control Fields
                        int[,] phAnalogArray = new int[MyControl_WE_MaximumPhAnalogueControls, MyControl_WE_MaximumPhFields];
                        int phAnalogIndex = 0;
                        foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps.Take(MyControl_WE_MaximumPhAnalogueControls))
                        {
                            phAnalogIndex += 1;
                            if (phAnalogIndex >= 1 && phAnalogIndex <= MyControl_WE_MaximumPhAnalogueControls)
                            {
                                phAnalogArray[phAnalogIndex - 1, 0] = phAnalogueControlStep.StepNumber;
                                phAnalogArray[phAnalogIndex - 1, 1] = (int)(phAnalogueControlStep.PhMinimum * 100);
                                phAnalogArray[phAnalogIndex - 1, 2] = (int)(phAnalogueControlStep.PhMaximum * 100);
                                phAnalogArray[phAnalogIndex - 1, 3] = phAnalogueControlStep.PhDelayTime;
                                phAnalogArray[phAnalogIndex - 1, 4] = phAnalogueControlStep.PhMeasuringTime;
                                phAnalogArray[phAnalogIndex - 1, 5] = (phAnalogueControlStep.PhControlDuringDrain == true ? 1 : 0);
                            }
                        }

                        //TYPE uints_WashPrgWE :
                        //STRUCT
                        //      NomLoad: UINT; (*Nominal load(%) *)
	                    //      DosStepNb: UINT; (*Dosing step number *)
	                    //      ThWashTime: UINT; (*Theoretical wash time (mn) *)
	                    //      ExtraTime: UINT; (*Extra time after last dosing step *)
	                    //      CoolDwnStep: UINT; (*Cool down step *)
	                    //      DosPrg: ARRAY[1..20, 1..3] OF UINT; (*Program dose[Dose number, (Step & Pump nb, Quantity, Delay)] *)
	                    //      CtrlTemp: ARRAY[1..6] OF UINT; (*Step for temperature control, Setpoint, Delay to start control, Minimum time, Accepted time below T., Chemical check *)
                        //      CtrlpH: ARRAY[1..6] OF UINT; (*Step for pH control, pH min, pH max, delay to start control, Measuring time, Control during drain *)
                        //END_STRUCT
                        //END_TYPE

                        washerFormulaList.Add(washerFormula.NominalLoad);
                        washerFormulaList.Add(washerFormula.WashStepsCount);
                        washerFormulaList.Add(washerFormula.TotalRunTime);
                        washerFormulaList.Add(washerFormula.ExtraTime);
                        washerFormulaList.Add(washerFormula.CoolDownStep);

                        for (int rowIndex = 0; rowIndex < MyControl_WE_MaximumInjectionSteps; rowIndex++)
                        {
                            washerFormulaList.AddRange(dosingArray.SliceRow<int>(rowIndex));
                        }

                        for (int rowIndex = 0; rowIndex < MyControl_WE_MaximumTemperatureAnalogueControls; rowIndex++)
                        {
                            washerFormulaList.AddRange(temperatureAnalogArray.SliceRow<int>(rowIndex));
                        }

                        for (int rowIndex = 0; rowIndex < MyControl_WE_MaximumPhAnalogueControls; rowIndex++)
                        {
                            washerFormulaList.AddRange(phAnalogArray.SliceRow<int>(rowIndex));
                        }

                        //Create Tag for Formula with all 77 Memory Locations
                        tags.Add(new BeckhoffTag() { Address = ".uint_Wash_Prg_WE[" + washerFormula.ProgramNumber + "]", TagItemType = UIInputType.TypeArray, BatchData = washerFormulaList.Select(i => (ushort)i).ToList() });
                    }
                }

                #endregion
            }
            else
            {
                #region "Tunnel Formulas"

                if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                {
                    List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();

                    List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                    foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                    {
                        tags.AddRange(GetTunnelFormulaResetTagsForMyControl(washerGroupFormulaDetails.WasherDosingNumber, deletedFormulaNumber));
                    }
                }
                
                foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                {
                    if (washerFormula.ProgramNumber <= MyControl_MaximumFormulas)
                    {
                        List<int> tunnelFormulaList = new List<int>(MyControl_TUN_FormulaArray);

                        //Header Fields
                        tags.Add(new BeckhoffTag() { Address = ".uint_ProgCategory[" + (washerFormula.WasherDosingNumber == 1 ? 2 : 3) + "," + washerFormula.ProgramNumber + "]", TagItemType = UIInputType.TypeInt, Value = washerFormula.EcolabTextileCategoryID.ToString() });

                        //Regulation Levels
                        int phRegulationLevel = 0;
                        int phMonitoringLevel = 0;
                        int conductivityRegulationLevel = 0;

                        foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps)
                        {
                            //PH Sensor 1 is PH Regulation Sensor
                            if (phAnalogueControlStep.ProbeNumber == 1)
                            {
                                phRegulationLevel = phAnalogueControlStep.PhRegulationLevel;
                            }

                            //PH Sensor 2 is PH Monitoring Sensor
                            if (phAnalogueControlStep.ProbeNumber == 2)
                            {
                                phMonitoringLevel = phAnalogueControlStep.PhMonitoringLevel;
                            }
                        }

                        foreach (ConductivityAnalogueControlStep conductivityAnalogueControlStep in washerFormula.washerFormulaConductivityAnalogueControlSteps)
                        {
                            if (conductivityAnalogueControlStep.ProbeNumber == 1)
                            {
                                conductivityRegulationLevel = conductivityAnalogueControlStep.ConductivityRegulationLevel;
                            }
                        }
                        
                        int[,] dosingArray = new int[MyControl_TUN_MaximumPumps, MyControl_TUN_MaximumDosingPoints];
                        foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                        {
                            if (washerFormulaDosingStep.ControllerEquipmentId >= 1 && washerFormulaDosingStep.ControllerEquipmentId <= MyControl_TUN_MaximumPumps)
                            {
                                //Product Fields
                                foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts)
                                {
                                    //If Direct Dosing Write PLC Information to First Dosing Point Number
                                    if (product.IsDirectDosing)
                                    {
                                        product.DosingPointNumber = 1;
                                    }
                                    dosingArray[washerFormulaDosingStep.ControllerEquipmentId - 1, product.DosingPointNumber - 1] = Convert.ToInt32(String.Format("{0:D2}{1:D3}", product.Delay, (int)(product.Quantity * 10)));
                                }
                            }
                        }

                        //Ph Control Fields - Not Required as it is set at Tunnel Level

                        //Temparature Control Fields
                        int[,] temperatureAnalogArray = new int[MyControl_TUN_MaximumTemperatureAnalogueControls, MyControl_TUN_MaximumTemperatureFields];
                        foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(6))
                        {
                            if (temperatureAnalogueControlStep.ProbeNumber >= 1 && temperatureAnalogueControlStep.ProbeNumber <= MyControl_TUN_MaximumTemperatureAnalogueControls)
                            {
                                temperatureAnalogArray[temperatureAnalogueControlStep.ProbeNumber - 1, 0] = (int)(temperatureAnalogueControlStep.TunnelSetPointTemperature * 10);
                                temperatureAnalogArray[temperatureAnalogueControlStep.ProbeNumber - 1, 1] = temperatureAnalogueControlStep.TunnelStartDelay;
                                temperatureAnalogArray[temperatureAnalogueControlStep.ProbeNumber - 1, 2] = temperatureAnalogueControlStep.TunnelMinimumTime;
                                temperatureAnalogArray[temperatureAnalogueControlStep.ProbeNumber - 1, 3] = temperatureAnalogueControlStep.TunnelAcceptedDelay;
                                temperatureAnalogArray[temperatureAnalogueControlStep.ProbeNumber - 1, 4] = (temperatureAnalogueControlStep.ProductCheck == true ? 1 : 0);
                            }
                        }

                        //TYPE uints_WashPrgTUN :
                        //STRUCT
                        //    NomLoad: UINT; (*Nominal load(kg) *)
                        //    pHLF: UINT; (*pH & LF level for regulation *)
                        //    DosPrg: ARRAY[1..26, 1..4] OF UINT; (*Program dose[Pump number, (Qty DP1, Qty DP2, Qty DP3, Qty DP4)] *)
                        //    CtrlTemp: ARRAY[1..6, 1..5] OF UINT; (*Temperature control[Temp number, (Setpoint, Delay to start control, Minimum time, Accepted time below T., Chemical check)] *)
                        //END_STRUCT
                        //END_TYPE

                        tunnelFormulaList.Add(washerFormula.NominalLoad);
                        tunnelFormulaList.Add((phRegulationLevel * 100) + (phMonitoringLevel * 10) + (conductivityRegulationLevel * 1));

                        for (int rowIndex = 0; rowIndex < MyControl_TUN_MaximumPumps; rowIndex++)
                        {
                            tunnelFormulaList.AddRange(dosingArray.SliceRow<int>(rowIndex));
                        }

                        for (int rowIndex = 0; rowIndex < MyControl_TUN_MaximumTemperatureAnalogueControls; rowIndex++)
                        {
                            tunnelFormulaList.AddRange(temperatureAnalogArray.SliceRow<int>(rowIndex));
                        }

                        //Create Tag for Formula with all 136 Memory Locations
                        tags.Add(new BeckhoffTag() { Address = ".uint_Wash_Prg_TUN[" + washerFormula.WasherDosingNumber + "," + washerFormula.ProgramNumber + "]", TagItemType = UIInputType.TypeArray, BatchData = tunnelFormulaList.Select(i => (ushort)i).ToList() });
                    }
                }

                #endregion
            }

            if (tags.Count > 0)
            {
                BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                beckOffWriter.WriteMyControlTags(tags);
            }
        }

        /// <summary>
        /// Write MyControl Washer Group Deleted Formula Settings
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="washerGroupTypeId">Washer Group Type Id</param>
        /// <param name="deletedFormulas">Deleted Formulas List</param>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        public void WriteMyControlWasherGroupDeletedFormulaSettings(int controllerId, int washerGroupTypeId, List<WasherGroupFormula> deletedFormulas, int washerDosingNumber = 0)
        {
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            int comPort = Convert.ToInt32(ConfigurationManager.AppSettings["ComPort"]);

            List<BeckhoffTag> tags = new List<BeckhoffTag>();

            if (washerGroupTypeId == 1)
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetConventionalFormulaResetTagsForMyControl(deletedFormula.ProgramNumber));
                }
            }
            else
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetTunnelFormulaResetTagsForMyControl(washerDosingNumber, deletedFormula.ProgramNumber));
                }
            }

            if (tags.Count > 0)
            {
                BeckoffDataWriter beckOffWriter = new BeckoffDataWriter(
                    new BeckhoffController { ControllerId = controllerId, AmsNetAddress = controllerInfo.Value, Comport = comPort }, string.Empty, controllerInfo.Value, comPort);

                beckOffWriter.WriteMyControlTags(tags);
            }
        }

        /// <summary>
        /// Write Washer Group Formula Settings To PLC XL
        /// </summary>
        /// <param name="washerGroupFormulaDetailsList">Washer Group Formula Details List</param>
        /// <param name="controllerId">Controller Id</param>
        public void WritePLCXLWasherGroupFormulaSettings(List<WasherGroupFormulaDetails> washerGroupFormulaDetailsList, int controllerId)
        {
            int PLCXL_WE_HeaderStartIndex = 0;
            int PLCXL_WE2_HeaderStartIndex = 0;
            int PLCXL_WE_TemperatureStartIndex = 0;
            int PLCXL_WE2_TemperatureStartIndex = 0;
            int PLCXL_WE_StartDelayStartIndex = 0;
            int PLCXL_WE2_StartDelayStartIndex = 0;
            int PLCXL_WE_PhStartIndex = 0;
            int PLCXL_WE2_PhStartIndex = 0;
            int PLCXL_WE_ProductStartIndex = 0;
            int PLCXL_WE2_ProductStartIndex = 0;

            int PLCXL_TUN_TemperatureStartIndex = 0;
            int PLCXL_TUN_StartDelayStartIndex = 0;
            int PLCXL_TUN2_TemperatureStartIndex = 0;
            int PLCXL_TUN2_StartDelayStartIndex = 0;
            int PLCXL_TUN_PhStartIndex = 0;
            int PLCXL_TUN2_PhStartIndex = 0;
            int PLCXL_TUN_ConductivityStartIndex = 0;
            int PLCXL_TUN2_ConductivityStartIndex = 0;
            int PLCXL_TUN_ProductStartIndex = 0;
            int PLCXL_TUN2_ProductStartIndex = 0;

            List<MitsubishiTag> tags = new List<MitsubishiTag>();

            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            MitsubishiController controller = new MitsubishiController() { HostAdress = controllerInfo.Value, ControllerId = controllerId };
            switch (controllerInfo.ControllerTypeId)
            {
                case 12:
                    PLCXL_WE_HeaderStartIndex = PLCXL10WWEHeaderBaseIndex;
                    PLCXL_WE2_HeaderStartIndex = PLCXL10WWE2HeaderBaseIndex;
                    PLCXL_WE_TemperatureStartIndex = PLCXL10WWE1TemperatureBaseIndex;
                    PLCXL_WE2_TemperatureStartIndex = PLCXL10WWE2TemperatureBaseIndex;
                    PLCXL_WE_StartDelayStartIndex = PLCXL10WWE1StartDelayBaseIndex;
                    PLCXL_WE2_StartDelayStartIndex = PLCXL10WWE2StartDelayBaseIndex;
                    PLCXL_WE_PhStartIndex = PLCXL10WWEPhBaseIndex;
                    PLCXL_WE2_PhStartIndex = PLCXL10WWE2PhBaseIndex;
                    PLCXL_WE_ProductStartIndex = PLCXL10WWE1ProductBaseIndex;
                    PLCXL_WE2_ProductStartIndex = PLCXL10WWE2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL10W;

                    break;
                case 13:
                    PLCXL_WE_HeaderStartIndex = PLCXL5W1CWEHeaderBaseIndex;
                    PLCXL_WE_TemperatureStartIndex = PLCXL5W1CWETemperatureBaseIndex;
                    PLCXL_WE_StartDelayStartIndex = PLCXL5W1CWEStartDelayBaseIndex;
                    PLCXL_WE_PhStartIndex = PLCXL5W1CWEPhBaseIndex;
                    PLCXL_WE_ProductStartIndex = PLCXL5W1CWEProductBaseIndex;

                    PLCXL_TUN2_TemperatureStartIndex = PLCXL5W1CTUN2TemperatureBaseIndex;
                    PLCXL_TUN2_StartDelayStartIndex = PLCXL5W1CTUN2StartDelayBaseIndex;
                    PLCXL_TUN2_PhStartIndex = PLCXL5W1CTUN2PhBaseIndex;
                    PLCXL_TUN2_ConductivityStartIndex = PLCXL5W1CTUN2ConductivityBaseIndex;
                    PLCXL_TUN2_ProductStartIndex = PLCXL5W1CTUN2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL5W1C;
                    break;
                case 14:
                    PLCXL_TUN_TemperatureStartIndex = PLCXL2CbwTUNTemperatureBaseIndex;
                    PLCXL_TUN2_TemperatureStartIndex = PLCXL2CbwTUN2TemperatureBaseIndex;
                    PLCXL_TUN_StartDelayStartIndex = PLCXL2CbwTUNStartDelayBaseIndex;
                    PLCXL_TUN2_StartDelayStartIndex = PLCXL2CbwTUN2StartDelayBaseIndex;
                    PLCXL_TUN_PhStartIndex = PLCXL2CbwTUNPhBaseIndex;
                    PLCXL_TUN2_PhStartIndex = PLCXL2CbwTUN2PhBaseIndex;
                    PLCXL_TUN_ConductivityStartIndex = PLCXL2CbwTUNConductivityBaseIndex;
                    PLCXL_TUN2_ConductivityStartIndex = PLCXL2CbwTUN2ConductivityBaseIndex;
                    PLCXL_TUN_ProductStartIndex = PLCXL2CbwTUNProductBaseIndex;
                    PLCXL_TUN2_ProductStartIndex = PLCXL2CbwTUN2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL2Cbw;
                    break;
            }

            foreach (WasherGroupFormulaDetails washerGroupFormulaDetails in washerGroupFormulaDetailsList)
            {

                if (washerGroupFormulaDetails.WasherGroupTypeId == 1)
                {
                    #region "Conventional Formulas"

                    if (controllerInfo.ControllerTypeId == 12) // 10W
                    {
                        tags.Add(new MitsubishiTag()
                        {
                            Address = "L90",
                            TagItemType = UIInputType.TypeBool,
                            Value = washerGroupFormulaDetails.UseGroup1FormulaUsedForGroup2ForPLCXL == true ? "1" : "0"
                        });

                        if (washerGroupFormulaDetails.WasherDosingNumber == 2)
                        {
                            if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                            {
                                tags.AddRange(GetAllConventionalFormulaResetTagsForPLCXL(washerGroupFormulaDetails.WasherDosingNumber,
                                                                                        PLCXL_WE_HeaderStartIndex,
                                                                                        PLCXL_WE2_HeaderStartIndex,
                                                                                        PLCXL_WE_TemperatureStartIndex,
                                                                                        PLCXL_WE2_TemperatureStartIndex,
                                                                                        PLCXL_WE_StartDelayStartIndex,
                                                                                        PLCXL_WE2_StartDelayStartIndex,
                                                                                        PLCXL_WE_PhStartIndex,
                                                                                        PLCXL_WE2_PhStartIndex,
                                                                                        PLCXL_WE_ProductStartIndex,
                                                                                        PLCXL_WE2_ProductStartIndex));
                            }
                            else
                            {
                                tags.AddRange(GetConventionalFormulaResetTagsForPLCXL(washerGroupFormulaDetails.WasherDosingNumber,
                                                                       washerGroupFormulaDetails.WasherGroupFormulas.First().ProgramNumber,
                                                                       PLCXL_WE_HeaderStartIndex,
                                                                       PLCXL_WE2_HeaderStartIndex,
                                                                       PLCXL_WE_TemperatureStartIndex,
                                                                       PLCXL_WE2_TemperatureStartIndex,
                                                                       PLCXL_WE_StartDelayStartIndex,
                                                                       PLCXL_WE2_StartDelayStartIndex,
                                                                       PLCXL_WE_PhStartIndex,
                                                                       PLCXL_WE2_PhStartIndex,
                                                                       PLCXL_WE_ProductStartIndex,
                                                                       PLCXL_WE2_ProductStartIndex));
                            }
                        }
                    }

                    if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                    {
                        List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                        List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                        List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                        foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                        {
                            tags.AddRange(GetConventionalFormulaResetTagsForPLCXL(washerGroupFormulaDetails.WasherDosingNumber,
                                                                    deletedFormulaNumber,
                                                                    PLCXL_WE_HeaderStartIndex,
                                                                    PLCXL_WE2_HeaderStartIndex,
                                                                    PLCXL_WE_TemperatureStartIndex,
                                                                    PLCXL_WE2_TemperatureStartIndex,
                                                                    PLCXL_WE_StartDelayStartIndex,
                                                                    PLCXL_WE2_StartDelayStartIndex,
                                                                    PLCXL_WE_PhStartIndex,
                                                                    PLCXL_WE2_PhStartIndex,
                                                                    PLCXL_WE_ProductStartIndex,
                                                                    PLCXL_WE2_ProductStartIndex));
                        }
                    }

                    foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                    {
                        if (washerFormula.ProgramNumber <= PLCXL_MaximumFormulas)
                        {
                            int formulaHeaderStartIndex_WE = PLCXL_WE_HeaderStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaHeaderStartIndex_WE2 = PLCXL_WE2_HeaderStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaTempStartIndex_WE = PLCXL_WE_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * (5 * 5));
                            int formulaTempStartIndex_WE2 = PLCXL_WE2_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * (5 * 5));
                            int formulaStartDelayStartIndex_WE = PLCXL_WE_StartDelayStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaStartDelayStartIndex_WE2 = PLCXL_WE2_StartDelayStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaPhStartIndex_WE = PLCXL_WE_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 10);
                            int formulaPhStartIndex_WE2 = PLCXL_WE2_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 10);
                            int formulaProductStartIndex_WE = PLCXL_WE_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * (25 * 4));
                            int formulaProductStartIndex_WE2 = PLCXL_WE2_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * (25 * 4));

                            //Header Fields
                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaHeaderStartIndex_WE : formulaHeaderStartIndex_WE2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 5,
                                IntArrayData = new int[]
                                {
                                  washerFormula.NominalLoad,
                                  washerFormula.WashStepsCount,
                                  washerFormula.CoolDownStep,
                                  washerFormula.ExtraTime,
                                  washerFormula.TotalRunTime
                                }
                            });

                            //Temparature Control Fields
                            int[,] temperatureControlArray = new int[5, 5];

                            int controlIndex = 0;
                            int[] startDelayArray = new int[5];
                            foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(5))
                            {
                                controlIndex += 1;
                                if (controlIndex <= 5)
                                {
                                    int equipmentNumberIndexForPLCXL = 0;
                                    if (washerGroupFormulaDetails.UseGroup1FormulaUsedForGroup2ForPLCXL)
                                    {
                                        equipmentNumberIndexForPLCXL = GetEquipmentNumberIndexForPLCXL(temperatureAnalogueControlStep.EquipmentNumber, washerFormula.WasherDosingNumber);
                                    }
                                    else
                                    {
                                        equipmentNumberIndexForPLCXL = GetEquipmentNumberIndexForPLCXL(temperatureAnalogueControlStep.EquipmentNumber, washerGroupFormulaDetails.WasherDosingNumber);
                                    }

                                    temperatureControlArray[controlIndex - 1, 0] = temperatureAnalogueControlStep.StepNumber;
                                    temperatureControlArray[controlIndex - 1, 1] = (int)(temperatureAnalogueControlStep.SetPointTemperature);
                                    temperatureControlArray[controlIndex - 1, 2] = temperatureAnalogueControlStep.MinimumTime;
                                    temperatureControlArray[controlIndex - 1, 3] = equipmentNumberIndexForPLCXL + 1;
                                    temperatureControlArray[controlIndex - 1, 4] = temperatureAnalogueControlStep.AcceptedDelay;

                                    startDelayArray[controlIndex - 1] = temperatureAnalogueControlStep.StartDelay;
                                }
                            }

                            int[] temperatureControlArr = new int[]
                            {
                                temperatureControlArray.Slice(0)[0],
                                temperatureControlArray.Slice(0)[1],
                                temperatureControlArray.Slice(0)[2],
                                temperatureControlArray.Slice(0)[3],
                                temperatureControlArray.Slice(0)[4],
                                temperatureControlArray.Slice(1)[0],
                                temperatureControlArray.Slice(1)[1],
                                temperatureControlArray.Slice(1)[2],
                                temperatureControlArray.Slice(1)[3],
                                temperatureControlArray.Slice(1)[4],
                                temperatureControlArray.Slice(2)[0],
                                temperatureControlArray.Slice(2)[1],
                                temperatureControlArray.Slice(2)[2],
                                temperatureControlArray.Slice(2)[3],
                                temperatureControlArray.Slice(2)[4],
                                temperatureControlArray.Slice(3)[0],
                                temperatureControlArray.Slice(3)[1],
                                temperatureControlArray.Slice(3)[2],
                                temperatureControlArray.Slice(3)[3],
                                temperatureControlArray.Slice(3)[4],
                                temperatureControlArray.Slice(4)[0],
                                temperatureControlArray.Slice(4)[1],
                                temperatureControlArray.Slice(4)[2],
                                temperatureControlArray.Slice(4)[3],
                                temperatureControlArray.Slice(4)[4]
                            };

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaTempStartIndex_WE : formulaTempStartIndex_WE2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 25,
                                IntArrayData = temperatureControlArr
                            });

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaStartDelayStartIndex_WE : formulaStartDelayStartIndex_WE2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 5,
                                IntArrayData = startDelayArray
                            });

                            //Ph Control Fields
                            int[] phControlArray = new int[6];
                            foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps.Take(1))
                            {
                                phControlArray[0] = phAnalogueControlStep.StepNumber;
                                phControlArray[1] = phAnalogueControlStep.PhControlDuringDrain == true ? 1 : 0;
                                phControlArray[2] = phAnalogueControlStep.PhDelayTime;
                                phControlArray[3] = phAnalogueControlStep.PhMeasuringTime;
                                phControlArray[4] = (int)(phAnalogueControlStep.PhMinimum * 10);
                                phControlArray[5] = (int)(phAnalogueControlStep.PhMaximum * 10);
                            }

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaPhStartIndex_WE : formulaPhStartIndex_WE2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 6,
                                IntArrayData = phControlArray
                            });

                            //Include products in all Dosing Steps
                            List<Models.WasherGroup.WasherFormulaDosingStepProduct> allProducts = new List<Models.WasherGroup.WasherFormulaDosingStepProduct>();
                            foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                            {
                                foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts)
                                {
                                    allProducts.Add(product);
                                }
                            }

                            //Product Fields
                            int[,] productsArray = new int[25, 4];

                            int productIndex = 0;
                            foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in allProducts.Take(25))
                            {
                                productIndex += 1;
                                if (productIndex <= 25)
                                {
                                    productsArray[productIndex - 1, 0] = product.InjectionNumber;
                                    int equipmentNumberIndexForPLCXL = 0;
                                    if (washerGroupFormulaDetails.UseGroup1FormulaUsedForGroup2ForPLCXL)
                                    {
                                        equipmentNumberIndexForPLCXL = GetEquipmentNumberIndexForPLCXL(product.EquipmentNumber, washerFormula.WasherDosingNumber);
                                    }
                                    else
                                    {
                                        equipmentNumberIndexForPLCXL = GetEquipmentNumberIndexForPLCXL(product.EquipmentNumber, washerGroupFormulaDetails.WasherDosingNumber);
                                    }
                                    productsArray[productIndex - 1, 1] = equipmentNumberIndexForPLCXL;
                                    productsArray[productIndex - 1, 2] = (int)(product.Quantity * 10);
                                    productsArray[productIndex - 1, 3] = product.Delay * 10;
                                }
                            }

                            int[] productsArr = new int[]
                                        {
                                productsArray.Slice(0)[0],
                                productsArray.Slice(0)[1],
                                productsArray.Slice(0)[2],
                                productsArray.Slice(0)[3],
                                productsArray.Slice(1)[0],
                                productsArray.Slice(1)[1],
                                productsArray.Slice(1)[2],
                                productsArray.Slice(1)[3],
                                productsArray.Slice(2)[0],
                                productsArray.Slice(2)[1],
                                productsArray.Slice(2)[2],
                                productsArray.Slice(2)[3],
                                productsArray.Slice(3)[0],
                                productsArray.Slice(3)[1],
                                productsArray.Slice(3)[2],
                                productsArray.Slice(3)[3],
                                productsArray.Slice(4)[0],
                                productsArray.Slice(4)[1],
                                productsArray.Slice(4)[2],
                                productsArray.Slice(4)[3],
                                productsArray.Slice(5)[0],
                                productsArray.Slice(5)[1],
                                productsArray.Slice(5)[2],
                                productsArray.Slice(5)[3],
                                productsArray.Slice(6)[0],
                                productsArray.Slice(6)[1],
                                productsArray.Slice(6)[2],
                                productsArray.Slice(6)[3],
                                productsArray.Slice(7)[0],
                                productsArray.Slice(7)[1],
                                productsArray.Slice(7)[2],
                                productsArray.Slice(7)[3],
                                productsArray.Slice(8)[0],
                                productsArray.Slice(8)[1],
                                productsArray.Slice(8)[2],
                                productsArray.Slice(8)[3],
                                productsArray.Slice(9)[0],
                                productsArray.Slice(9)[1],
                                productsArray.Slice(9)[2],
                                productsArray.Slice(9)[3],
                                productsArray.Slice(10)[0],
                                productsArray.Slice(10)[1],
                                productsArray.Slice(10)[2],
                                productsArray.Slice(10)[3],
                                productsArray.Slice(11)[0],
                                productsArray.Slice(11)[1],
                                productsArray.Slice(11)[2],
                                productsArray.Slice(11)[3],
                                productsArray.Slice(12)[0],
                                productsArray.Slice(12)[1],
                                productsArray.Slice(12)[2],
                                productsArray.Slice(12)[3],
                                productsArray.Slice(13)[0],
                                productsArray.Slice(13)[1],
                                productsArray.Slice(13)[2],
                                productsArray.Slice(13)[3],
                                productsArray.Slice(14)[0],
                                productsArray.Slice(14)[1],
                                productsArray.Slice(14)[2],
                                productsArray.Slice(14)[3],
                                productsArray.Slice(15)[0],
                                productsArray.Slice(15)[1],
                                productsArray.Slice(15)[2],
                                productsArray.Slice(15)[3],
                                productsArray.Slice(16)[0],
                                productsArray.Slice(16)[1],
                                productsArray.Slice(16)[2],
                                productsArray.Slice(16)[3],
                                productsArray.Slice(17)[0],
                                productsArray.Slice(17)[1],
                                productsArray.Slice(17)[2],
                                productsArray.Slice(17)[3],
                                productsArray.Slice(18)[0],
                                productsArray.Slice(18)[1],
                                productsArray.Slice(18)[2],
                                productsArray.Slice(18)[3],
                                productsArray.Slice(19)[0],
                                productsArray.Slice(19)[1],
                                productsArray.Slice(19)[2],
                                productsArray.Slice(19)[3],
                                productsArray.Slice(20)[0],
                                productsArray.Slice(20)[1],
                                productsArray.Slice(20)[2],
                                productsArray.Slice(20)[3],
                                productsArray.Slice(21)[0],
                                productsArray.Slice(21)[1],
                                productsArray.Slice(21)[2],
                                productsArray.Slice(21)[3],
                                productsArray.Slice(22)[0],
                                productsArray.Slice(22)[1],
                                productsArray.Slice(22)[2],
                                productsArray.Slice(22)[3],
                                productsArray.Slice(23)[0],
                                productsArray.Slice(23)[1],
                                productsArray.Slice(23)[2],
                                productsArray.Slice(23)[3],
                                productsArray.Slice(24)[0],
                                productsArray.Slice(24)[1],
                                productsArray.Slice(24)[2],
                                productsArray.Slice(24)[3],
                            };

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaProductStartIndex_WE : formulaProductStartIndex_WE2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 100,
                                IntArrayData = productsArr
                            });
                        }
                    }

                    #endregion
                }
                else
                {
                    #region "Tunnel Formulas"

                    if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                    {
                        List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                        List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                        List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                        foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                        {
                            tags.AddRange(GetTunnelFormulaResetTagsForPLCXL(washerGroupFormulaDetails.WasherDosingNumber,
                                                            deletedFormulaNumber,
                                                            PLCXL_TUN_TemperatureStartIndex,
                                                            PLCXL_TUN2_TemperatureStartIndex,
                                                            PLCXL_TUN_StartDelayStartIndex,
                                                            PLCXL_TUN2_StartDelayStartIndex,
                                                            PLCXL_TUN_ProductStartIndex,
                                                            PLCXL_TUN2_ProductStartIndex,
                                                            PLCXL_TUN_PhStartIndex,
                                                            PLCXL_TUN2_PhStartIndex,
                                                            PLCXL_TUN_ConductivityStartIndex,
                                                            PLCXL_TUN2_ConductivityStartIndex));
                        }
                    }

                    foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                    {
                        if (washerFormula.ProgramNumber <= PLCXL_MaximumFormulas)
                        {
                            int formulaTempStartIndex_TUN = PLCXL_TUN_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * (3 * 4));
                            int formulaTempStartIndex_TUN2 = PLCXL_TUN2_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * (3 * 4));
                            int formulaStartDelayStartIndex_TUN = PLCXL_TUN_StartDelayStartIndex + ((washerFormula.ProgramNumber - 1) * 3);
                            int formulaStartDelayStartIndex_TUN2 = PLCXL_TUN2_StartDelayStartIndex + ((washerFormula.ProgramNumber - 1) * 3);
                            int formulaPhStartIndex_TUN = PLCXL_TUN_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaPhStartIndex_TUN2 = PLCXL_TUN2_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaConductivityStartIndex_TUN = PLCXL_TUN_ConductivityStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaConductivityStartIndex_TUN2 = PLCXL_TUN2_ConductivityStartIndex + ((washerFormula.ProgramNumber - 1) * 5);
                            int formulaProductStartIndex_TUN = PLCXL_TUN_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * 70);
                            int formulaProductStartIndex_TUN2 = PLCXL_TUN2_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * 70);

                            int[] doseArray = new int[70];

                            //Header Fields
                            doseArray[66] = washerFormula.NominalLoad;

                            //Regulation Levels
                            int phRegulationLevel = 0;
                            int phMonitoringLevel = 0;
                            int conductivityRegulationLevel = 0;

                            int[] phControlArray = new int[5];

                            int regulationIndex = 0;
                            foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps.Take(1))
                            {
                                regulationIndex += 1;
                                if (regulationIndex <= 1)
                                {
                                    phRegulationLevel = phAnalogueControlStep.PhRegulationLevel;
                                    phMonitoringLevel = phAnalogueControlStep.PhMonitoringLevel;
                                    phControlArray[0] = (int)(phAnalogueControlStep.PhMinimum * 10);
                                    phControlArray[1] = (int)(phAnalogueControlStep.PhMaximum * 10);
                                    phControlArray[2] = phAnalogueControlStep.PhDelayTime;
                                    phControlArray[3] = phAnalogueControlStep.PhMeasuringTime;
                                }
                            }

                            regulationIndex = 0;

                            int[] conductivityControlArray = new int[5];

                            foreach (ConductivityAnalogueControlStep conductivityAnalogueControlStep in washerFormula.washerFormulaConductivityAnalogueControlSteps.Take(1))
                            {
                                regulationIndex += 1;
                                if (regulationIndex <= 1)
                                {
                                    conductivityRegulationLevel = conductivityAnalogueControlStep.ConductivityRegulationLevel;
                                    conductivityControlArray[0] = (int)(conductivityAnalogueControlStep.ConductivityMinimum * 100);
                                    conductivityControlArray[1] = (int)(conductivityAnalogueControlStep.ConductivityMaximum * 100);
                                    conductivityControlArray[2] = conductivityAnalogueControlStep.ConductivityDelayTime;
                                    conductivityControlArray[3] = conductivityAnalogueControlStep.ConductivityMeasuringTime;
                                }
                            }

                            doseArray[64] = phRegulationLevel;
                            doseArray[65] = conductivityRegulationLevel;

                            //Ph Analogue Details
                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaPhStartIndex_TUN : formulaPhStartIndex_TUN2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 5,
                                IntArrayData = phControlArray
                            });

                            //Conductivity Analogue Details
                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaConductivityStartIndex_TUN : formulaConductivityStartIndex_TUN2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 5,
                                IntArrayData = conductivityControlArray
                            });

                            //Product Fields
                            foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                            {
                                foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts)
                                {
                                    int quantity = (int)(product.Quantity * 10);
                                    int delay = (product.Delay * 10);

                                    if (product.IsDirectDosing)
                                    {
                                        switch (product.EquipmentNumber)
                                        {
                                            case 1:
                                            case 15:
                                                doseArray[6] = quantity;
                                                doseArray[38] = delay;
                                                break;
                                            case 2:
                                            case 16:
                                                doseArray[7] = quantity;
                                                doseArray[39] = delay;
                                                break;
                                            case 3:
                                            case 17:
                                                doseArray[8] = quantity;
                                                doseArray[40] = delay;
                                                break;
                                            case 4:
                                            case 18:
                                                doseArray[9] = quantity;
                                                doseArray[41] = delay;
                                                break;
                                            case 5:
                                            case 19:
                                                doseArray[10] = quantity;
                                                doseArray[42] = delay;
                                                break;
                                            case 6:
                                            case 20:
                                                doseArray[11] = quantity;
                                                doseArray[43] = delay;
                                                break;
                                            case 7:
                                            case 21:
                                                doseArray[12] = quantity;
                                                doseArray[44] = delay;
                                                break;
                                            case 8:
                                            case 22:
                                                doseArray[13] = quantity;
                                                doseArray[45] = delay;
                                                break;
                                            case 9:
                                            case 23:
                                                doseArray[14] = quantity;
                                                doseArray[46] = delay;
                                                break;
                                            case 10:
                                            case 24:
                                                doseArray[15] = quantity;
                                                doseArray[47] = delay;
                                                break;
                                            case 11:
                                            case 25:
                                                doseArray[16] = quantity;
                                                doseArray[48] = delay;
                                                break;
                                            case 12:
                                            case 26:
                                                doseArray[17] = quantity;
                                                doseArray[49] = delay;
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        //ME1
                                        if (product.EquipmentNumber == 13 || product.EquipmentNumber == 27)
                                        {
                                            switch (product.ValveNumber)
                                            {
                                                case 1:
                                                    doseArray[0] = quantity;
                                                    doseArray[32] = delay;
                                                    break;
                                                case 2:
                                                    doseArray[1] = quantity;
                                                    doseArray[33] = delay;
                                                    break;
                                                case 3:
                                                    doseArray[2] = quantity;
                                                    doseArray[34] = delay;
                                                    break;
                                                case 4:
                                                    doseArray[3] = quantity;
                                                    doseArray[35] = delay;
                                                    break;
                                                case 5:
                                                    doseArray[4] = quantity;
                                                    doseArray[36] = delay;
                                                    break;
                                                case 6:
                                                    doseArray[5] = quantity;
                                                    doseArray[37] = delay;
                                                    break;
                                            }
                                        }
                                        else if (product.EquipmentNumber == 14 || product.EquipmentNumber == 28) //ME2
                                        {
                                            switch (product.ValveNumber)
                                            {
                                                case 1:
                                                    doseArray[18] = quantity;
                                                    doseArray[50] = delay;
                                                    break;
                                                case 2:
                                                    doseArray[19] = quantity;
                                                    doseArray[51] = delay;
                                                    break;
                                                case 3:
                                                    doseArray[20] = quantity;
                                                    doseArray[52] = delay;
                                                    break;
                                                case 4:
                                                    doseArray[21] = quantity;
                                                    doseArray[53] = delay;
                                                    break;
                                                case 5:
                                                    doseArray[22] = quantity;
                                                    doseArray[54] = delay;
                                                    break;
                                                case 6:
                                                    doseArray[23] = quantity;
                                                    doseArray[55] = delay;
                                                    break;
                                            }
                                        }
                                        else //Pump
                                        {
                                            switch (product.ValveNumber)
                                            {
                                                case 1:
                                                    doseArray[24] = quantity;
                                                    doseArray[56] = delay;
                                                    break;
                                                case 2:
                                                    doseArray[25] = quantity;
                                                    doseArray[57] = delay;
                                                    break;
                                                case 3:
                                                    doseArray[26] = quantity;
                                                    doseArray[58] = delay;
                                                    break;
                                                case 4:
                                                    doseArray[27] = quantity;
                                                    doseArray[59] = delay;
                                                    break;
                                                case 5:
                                                    doseArray[28] = quantity;
                                                    doseArray[60] = delay;
                                                    break;
                                                case 6:
                                                    doseArray[29] = quantity;
                                                    doseArray[61] = delay;
                                                    break;
                                                case 7:
                                                    doseArray[30] = quantity;
                                                    doseArray[62] = delay;
                                                    break;
                                                case 8:
                                                    doseArray[31] = quantity;
                                                    doseArray[63] = delay;
                                                    break;
                                            }
                                        }
                                    }
                                }
                            }

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaProductStartIndex_TUN : formulaProductStartIndex_TUN2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 70,
                                IntArrayData = doseArray
                            });
                            //Temparature Control Fields
                            int[,] temperatureControlArray = new int[3, 4];
                            int[] startDelayArray = new int[3];
                            foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(3))
                            {
                                if (temperatureAnalogueControlStep.ProbeNumber >= 1 && temperatureAnalogueControlStep.ProbeNumber <= 3)
                                {
                                    temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 0] = (int)(temperatureAnalogueControlStep.TunnelSetPointTemperature);
                                    temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 1] = temperatureAnalogueControlStep.TunnelMinimumTime;
                                    temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 2] = temperatureAnalogueControlStep.TunnelAcceptedDelay;
                                    temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 3] = temperatureAnalogueControlStep.ProductCheck == true ? 1 : 0;

                                    startDelayArray[temperatureAnalogueControlStep.ProbeNumber - 1] = temperatureAnalogueControlStep.TunnelStartDelay;
                                }
                            }
                            int[] temperatureControlArr = new int[]
                            {
                            temperatureControlArray.Slice(0)[0],
                            temperatureControlArray.Slice(0)[1],
                            temperatureControlArray.Slice(0)[2],
                            temperatureControlArray.Slice(0)[3],
                            temperatureControlArray.Slice(1)[0],
                            temperatureControlArray.Slice(1)[1],
                            temperatureControlArray.Slice(1)[2],
                            temperatureControlArray.Slice(1)[3],
                            temperatureControlArray.Slice(2)[0],
                            temperatureControlArray.Slice(2)[1],
                            temperatureControlArray.Slice(2)[2],
                            temperatureControlArray.Slice(2)[3]
                            };
                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaTempStartIndex_TUN : formulaTempStartIndex_TUN2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 12,
                                IntArrayData = temperatureControlArr
                            });

                            tags.Add(new MitsubishiTag()
                            {
                                Address = string.Format("R{0}", (washerGroupFormulaDetails.WasherDosingNumber == 1 ? formulaStartDelayStartIndex_TUN : formulaStartDelayStartIndex_TUN2)),
                                TagItemType = UIInputType.TypeArray,
                                ArrayLength = 3,
                                IntArrayData = startDelayArray
                            });
                        }
                    }
                    #endregion
                }
            }

            if (tags.Count > 0)
            {
                DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
                writer.WriteTags(tags);
                ((PLCXLEthernetWriter)writer).Dispose();
            }
        }

        /// <summary>
        /// Write MyControl Washer Group Deleted Formula Settings
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="washerGroupTypeId">Washer Group Type Id</param>
        /// <param name="deletedFormulas">Deleted Formulas List</param>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        public void WritePLCXLWasherGroupDeletedFormulaSettings(int controllerId, int washerGroupTypeId, List<WasherGroupFormula> deletedFormulas, int washerDosingNumber = 0)
        {
            int PLCXL_WE_HeaderStartIndex = 0;
            int PLCXL_WE2_HeaderStartIndex = 0;
            int PLCXL_WE_TemperatureStartIndex = 0;
            int PLCXL_WE2_TemperatureStartIndex = 0;
            int PLCXL_WE_StartDelayStartIndex = 0;
            int PLCXL_WE2_StartDelayStartIndex = 0;
            int PLCXL_WE_PhStartIndex = 0;
            int PLCXL_WE2_PhStartIndex = 0;
            int PLCXL_WE_ProductStartIndex = 0;
            int PLCXL_WE2_ProductStartIndex = 0;

            int PLCXL_TUN_TemperatureStartIndex = 0;
            int PLCXL_TUN_StartDelayStartIndex = 0;
            int PLCXL_TUN2_TemperatureStartIndex = 0;
            int PLCXL_TUN2_StartDelayStartIndex = 0;
            int PLCXL_TUN_PhStartIndex = 0;
            int PLCXL_TUN2_PhStartIndex = 0;
            int PLCXL_TUN_ConductivityStartIndex = 0;
            int PLCXL_TUN2_ConductivityStartIndex = 0;
            int PLCXL_TUN_ProductStartIndex = 0;
            int PLCXL_TUN2_ProductStartIndex = 0;

            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();

            MitsubishiController controller = new MitsubishiController() { HostAdress = controllerInfo.Value, ControllerId = controllerId };
            switch (controllerInfo.ControllerTypeId)
            {
                case 12:
                    PLCXL_WE_HeaderStartIndex = PLCXL10WWEHeaderBaseIndex;
                    PLCXL_WE2_HeaderStartIndex = PLCXL10WWE2HeaderBaseIndex;
                    PLCXL_WE_TemperatureStartIndex = PLCXL10WWE1TemperatureBaseIndex;
                    PLCXL_WE2_TemperatureStartIndex = PLCXL10WWE2TemperatureBaseIndex;
                    PLCXL_WE_StartDelayStartIndex = PLCXL10WWE1StartDelayBaseIndex;
                    PLCXL_WE2_StartDelayStartIndex = PLCXL10WWE2StartDelayBaseIndex;
                    PLCXL_WE_PhStartIndex = PLCXL10WWEPhBaseIndex;
                    PLCXL_WE2_PhStartIndex = PLCXL10WWE2PhBaseIndex;
                    PLCXL_WE_ProductStartIndex = PLCXL10WWE1ProductBaseIndex;
                    PLCXL_WE2_ProductStartIndex = PLCXL10WWE2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL10W;
                    break;
                case 13:
                    PLCXL_WE_HeaderStartIndex = PLCXL5W1CWEHeaderBaseIndex;
                    PLCXL_WE_TemperatureStartIndex = PLCXL5W1CWETemperatureBaseIndex;
                    PLCXL_WE_StartDelayStartIndex = PLCXL5W1CWEStartDelayBaseIndex;
                    PLCXL_WE_PhStartIndex = PLCXL5W1CWEPhBaseIndex;
                    PLCXL_WE_ProductStartIndex = PLCXL5W1CWEProductBaseIndex;

                    PLCXL_TUN2_TemperatureStartIndex = PLCXL5W1CTUN2TemperatureBaseIndex;
                    PLCXL_TUN2_StartDelayStartIndex = PLCXL5W1CTUN2StartDelayBaseIndex;
                    PLCXL_TUN2_PhStartIndex = PLCXL5W1CTUN2PhBaseIndex;
                    PLCXL_TUN2_ConductivityStartIndex = PLCXL5W1CTUN2ConductivityBaseIndex;
                    PLCXL_TUN2_ProductStartIndex = PLCXL5W1CTUN2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL5W1C;
                    break;
                case 14:
                    PLCXL_TUN_TemperatureStartIndex = PLCXL2CbwTUNTemperatureBaseIndex;
                    PLCXL_TUN2_TemperatureStartIndex = PLCXL2CbwTUN2TemperatureBaseIndex;
                    PLCXL_TUN_StartDelayStartIndex = PLCXL2CbwTUNStartDelayBaseIndex;
                    PLCXL_TUN2_StartDelayStartIndex = PLCXL2CbwTUN2StartDelayBaseIndex;
                    PLCXL_TUN_PhStartIndex = PLCXL2CbwTUNPhBaseIndex;
                    PLCXL_TUN2_PhStartIndex = PLCXL2CbwTUN2PhBaseIndex;
                    PLCXL_TUN_ConductivityStartIndex = PLCXL2CbwTUNConductivityBaseIndex;
                    PLCXL_TUN2_ConductivityStartIndex = PLCXL2CbwTUN2ConductivityBaseIndex;
                    PLCXL_TUN_ProductStartIndex = PLCXL2CbwTUNProductBaseIndex;
                    PLCXL_TUN2_ProductStartIndex = PLCXL2CbwTUN2ProductBaseIndex;

                    controller.PLCType = MitsubishiPLCType.PLCXL2Cbw;
                    break;
            }

            List<MitsubishiTag> tags = new List<MitsubishiTag>();

            if (washerGroupTypeId == 1)
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetConventionalFormulaResetTagsForPLCXL(washerDosingNumber,
                                                                deletedFormula.ProgramNumber,
                                                                PLCXL_WE_HeaderStartIndex,
                                                                PLCXL_WE2_HeaderStartIndex,
                                                                PLCXL_WE_TemperatureStartIndex,
                                                                PLCXL_WE2_TemperatureStartIndex,
                                                                PLCXL_WE_StartDelayStartIndex,
                                                                PLCXL_WE2_StartDelayStartIndex,
                                                                PLCXL_WE_PhStartIndex,
                                                                PLCXL_WE2_PhStartIndex,
                                                                PLCXL_WE_ProductStartIndex,
                                                                PLCXL_WE2_ProductStartIndex));
                }
            }
            else
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetTunnelFormulaResetTagsForPLCXL(washerDosingNumber,
                                                        deletedFormula.ProgramNumber,
                                                        PLCXL_TUN_TemperatureStartIndex,
                                                        PLCXL_TUN2_TemperatureStartIndex,
                                                        PLCXL_TUN_StartDelayStartIndex,
                                                        PLCXL_TUN2_StartDelayStartIndex,
                                                        PLCXL_TUN_ProductStartIndex,
                                                        PLCXL_TUN2_ProductStartIndex,
                                                        PLCXL_TUN_PhStartIndex,
                                                        PLCXL_TUN2_PhStartIndex,
                                                        PLCXL_TUN_ConductivityStartIndex,
                                                        PLCXL_TUN2_ConductivityStartIndex));
                }
            }

            if (tags.Count > 0)
            {
                DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
                writer.WriteTags(tags);
                ((PLCXLEthernetWriter)writer).Dispose();
            }
        }

        /// <summary>
        /// Write Washer Group Formula Settings To EControl Plus.
        /// </summary>
        /// <param name="washerGroupFormulaDetails">Washer Group Formula Details</param>
        /// <param name="controllerId">Controller Id</param>
        public void WriteEControlPlusWasherGroupFormulaSettings(WasherGroupFormulaDetails washerGroupFormulaDetails, int controllerId)
        {
            int ECTRLPLUS_WE_HeaderStartIndex = 0;
            int ECTRLPLUS_WE_TemperatureStartIndex = 0;
            int ECTRLPLUS_WE_DelayStartIndex = 0;
            int ECTRLPLUS_WE_PhStartIndex = 0;
            int ECTRLPLUS_WE_ProductStartIndex = 0;
            int ECTRLPLUS_TUN_TemperatureStartIndex = 0;
            int ECTRLPLUS_TUN_PhStartIndex = 0;
            int ECTRLPLUS_TUN_ConductivityStartIndex = 0;
            int ECTRLPLUS_TUN_ProductStartIndex = 0;

            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            MitsubishiController controller = new MitsubishiController() { HostAdress = controllerInfo.Value, ControllerId = controllerId };

            switch (controllerInfo.ControllerTypeId)
            {
                case 6:
                    ECTRLPLUS_WE_HeaderStartIndex = ECTRLPLUS8WWEHeaderBaseIndex;
                    ECTRLPLUS_WE_TemperatureStartIndex = ECTRLPLUS8WWETemperatureBaseIndex;
                    ECTRLPLUS_WE_DelayStartIndex = ECTRLPLUS8WWEDelayBaseIndex;
                    ECTRLPLUS_WE_PhStartIndex = ECTRLPLUS8WWEPhBaseIndex;
                    ECTRLPLUS_WE_ProductStartIndex = ECTRLPLUS8WWEProductBaseIndex;
                    controller.PLCType = MitsubishiPLCType.EControlPlus8W;
                    break;
                case 7:
                    ECTRLPLUS_WE_HeaderStartIndex = ECTRLPLUS8WWEHeaderBaseIndex;
                    ECTRLPLUS_WE_TemperatureStartIndex = ECTRLPLUS8WWETemperatureBaseIndex;
                    ECTRLPLUS_WE_DelayStartIndex = ECTRLPLUS8WWEDelayBaseIndex;
                    ECTRLPLUS_WE_PhStartIndex = ECTRLPLUS8WWEPhBaseIndex;
                    ECTRLPLUS_WE_ProductStartIndex = ECTRLPLUS8WWEProductBaseIndex;
                    ECTRLPLUS_TUN_TemperatureStartIndex = ECTRLPLUSTUN1TemperatureStartIndex;
                    ECTRLPLUS_TUN_PhStartIndex = ECTRLPLUSTUN1PhStartIndex;
                    ECTRLPLUS_TUN_ConductivityStartIndex = ECTRLPLUSTUN1ConductivityStartIndex;
                    ECTRLPLUS_TUN_ProductStartIndex = ECTRLPLUSTUN1ProductStartIndex;
                    controller.PLCType = MitsubishiPLCType.EControlPlus6W1T;
                    break;
            }

            List<MitsubishiTag> tags = new List<MitsubishiTag>();
            if (washerGroupFormulaDetails.WasherGroupTypeId == 1)
            {
                #region "Conventional Formulas"

                if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                {
                    List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                    foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                    {
                        tags.AddRange(GetConventionalFormulaResetTagsForEControlPlus(washerGroupFormulaDetails.WasherDosingNumber,
                                                                deletedFormulaNumber,
                                                                ECTRLPLUS_WE_HeaderStartIndex,
                                                                ECTRLPLUS_WE_TemperatureStartIndex,
                                                                ECTRLPLUS_WE_PhStartIndex,
                                                                ECTRLPLUS_WE_ProductStartIndex,
                                                                ECTRLPLUS_WE_DelayStartIndex
                                                                ));
                    }
                }

                foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                {
                    if (washerFormula.ProgramNumber <= ECTRLPLUS_MaximumFormulas)
                    {
                        int formulaHeaderStartIndex_WE = ECTRLPLUS_WE_HeaderStartIndex + ((washerFormula.ProgramNumber - 1) * 4);
                        int formulaTempStartIndex_WE = ECTRLPLUS_WE_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * 4);
                        int formulaPhStartIndex_WE = ECTRLPLUS_WE_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 6);
                        int formulaProductStartIndex_WE = ECTRLPLUS_WE_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * 40);
                        int formulaProductStartdelayIndex_WE = ECTRLPLUS_WE_DelayStartIndex + ((washerFormula.ProgramNumber - 1) * 20);
                        //Header Fields
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("D{0}", (washerFormula.WasherDosingNumber == 1 ? formulaHeaderStartIndex_WE : 0)),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 4,
                            IntArrayData = new int[]
                            {
                              washerFormula.NominalLoad,
                              washerFormula.WashStepsCount,
                              washerFormula.TotalRunTime,
                              washerFormula.ExtraTime
                            }
                        });
                        //Temparature Control Fields
                        int[] tempControlArray = new int[4];
                        foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(1))
                        {
                            tempControlArray[0] = temperatureAnalogueControlStep.StepNumber;
                            tempControlArray[1] = (int)temperatureAnalogueControlStep.SetPointTemperature;
                            tempControlArray[2] = temperatureAnalogueControlStep.StartDelay;
                            tempControlArray[3] = temperatureAnalogueControlStep.AcceptedDelay;
                        }
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("R{0}", formulaTempStartIndex_WE),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 4,
                            IntArrayData = tempControlArray
                        });

                        //Ph Control Fields
                        int[] phControlArray = new int[6];
                        foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps.Take(1))
                        {
                            phControlArray[0] = phAnalogueControlStep.StepNumber;
                            phControlArray[1] = phAnalogueControlStep.PhControlDuringDrain == true ? 1 : 0;
                            phControlArray[2] = phAnalogueControlStep.PhDelayTime;
                            phControlArray[3] = phAnalogueControlStep.PhMeasuringTime;
                            phControlArray[4] = (int)(phAnalogueControlStep.PhMinimum * 10);
                            phControlArray[5] = (int)(phAnalogueControlStep.PhMaximum * 10);
                        }
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("R{0}", formulaPhStartIndex_WE),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 6,
                            IntArrayData = phControlArray
                        });
                        //Include products in all Dosing Steps
                        List<Models.WasherGroup.WasherFormulaDosingStepProduct> allProducts = new List<Models.WasherGroup.WasherFormulaDosingStepProduct>();
                        foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                        {
                            foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts)
                            {
                                allProducts.Add(product);
                            }
                        }
                        //Product Fields
                        int[,] productsArray = new int[20, 3];
                        int productIndex = 0;
                        foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in allProducts.Take(20))
                        {
                            productIndex += 1;
                            if (productIndex <= 20)
                            {
                                string value = String.Format("{0}{1}", Convert.ToString(product.InjectionNumber).PadLeft(3, '0'), Convert.ToString(GetEquipmentNumberIndexForECTRLPLUS(product.EquipmentNumber, washerFormula.WasherDosingNumber)).PadLeft(2, '0'));
                                productsArray[productIndex - 1, 0] = (int)(product.Quantity * 10);
                                productsArray[productIndex - 1, 1] = Convert.ToInt32(value);
                                productsArray[productIndex - 1, 2] = product.Delay;
                            }
                        }
                        int[] productsArr = new int[]
                            {
                                productsArray.Slice(0)[0],
                                productsArray.Slice(0)[1],
                                productsArray.Slice(1)[0],
                                productsArray.Slice(1)[1],
                                productsArray.Slice(2)[0],
                                productsArray.Slice(2)[1],
                                productsArray.Slice(3)[0],
                                productsArray.Slice(3)[1],
                                productsArray.Slice(4)[0],
                                productsArray.Slice(4)[1],
                                productsArray.Slice(5)[0],
                                productsArray.Slice(5)[1],
                                productsArray.Slice(6)[0],
                                productsArray.Slice(6)[1],
                                productsArray.Slice(7)[0],
                                productsArray.Slice(7)[1],
                                productsArray.Slice(8)[0],
                                productsArray.Slice(8)[1],
                                productsArray.Slice(9)[0],
                                productsArray.Slice(9)[1],
                                productsArray.Slice(10)[0],
                                productsArray.Slice(10)[1],
                                productsArray.Slice(11)[0],
                                productsArray.Slice(11)[1],
                                productsArray.Slice(12)[0],
                                productsArray.Slice(12)[1],
                                productsArray.Slice(13)[0],
                                productsArray.Slice(13)[1],
                                productsArray.Slice(14)[0],
                                productsArray.Slice(14)[1],
                                productsArray.Slice(15)[0],
                                productsArray.Slice(15)[1],
                                productsArray.Slice(16)[0],
                                productsArray.Slice(16)[1],
                                productsArray.Slice(17)[0],
                                productsArray.Slice(17)[1],
                                productsArray.Slice(18)[0],
                                productsArray.Slice(18)[1],
                                productsArray.Slice(19)[0],
                                productsArray.Slice(19)[1]
                        };
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("D{0}", formulaProductStartIndex_WE),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 40,
                            IntArrayData = productsArr
                        });
                        int[] productsDelayArr = new int[]
                        {
                             productsArray.Slice(0)[2],
                             productsArray.Slice(1)[2],
                             productsArray.Slice(2)[2],
                             productsArray.Slice(3)[2],
                             productsArray.Slice(4)[2],
                             productsArray.Slice(5)[2],
                             productsArray.Slice(6)[2],
                             productsArray.Slice(7)[2],
                             productsArray.Slice(8)[2],
                             productsArray.Slice(9)[2],
                             productsArray.Slice(10)[2],
                             productsArray.Slice(11)[2],
                             productsArray.Slice(12)[2],
                             productsArray.Slice(13)[2],
                             productsArray.Slice(14)[2],
                             productsArray.Slice(15)[2],
                             productsArray.Slice(16)[2],
                             productsArray.Slice(17)[2],
                             productsArray.Slice(18)[2],
                             productsArray.Slice(19)[2]
                        };
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("D{0}", formulaProductStartdelayIndex_WE),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 20,
                            IntArrayData = productsDelayArr
                        });
                    }
                }
                #endregion
            }
            else
            {
                #region "Tunnel Formulas"

                if (washerGroupFormulaDetails.AreSendAllFormulasToPLC)
                {
                    List<int> deletedFormulaNumbers = washerGroupFormulaDetails.WasherGroupDeletedFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> formulaNumbers = washerGroupFormulaDetails.WasherGroupFormulas.Select(x => (int)x.ProgramNumber).ToList<int>();
                    List<int> deletedFormulaNumbersNotInFormulas = deletedFormulaNumbers.Except(formulaNumbers).ToList<int>();

                    foreach (int deletedFormulaNumber in deletedFormulaNumbersNotInFormulas)
                    {
                        tags.AddRange(GetTunnelFormulaResetTagsForEControlPlus(washerGroupFormulaDetails.WasherDosingNumber,
                                                        deletedFormulaNumber,
                                                        ECTRLPLUS_TUN_TemperatureStartIndex,
                                                        ECTRLPLUS_TUN_PhStartIndex,
                                                        ECTRLPLUS_TUN_ConductivityStartIndex,
                                                        ECTRLPLUS_TUN_ProductStartIndex));
                    }
                }

                foreach (Models.WasherGroup.WasherFormula washerFormula in washerGroupFormulaDetails.WasherGroupFormulas)
                {
                    if (washerFormula.ProgramNumber <= ECTRLPLUS_MaximumFormulas)
                    {
                        int offset = 0;

                        int formulaTempStartIndex_TUN = ECTRLPLUS_TUN_TemperatureStartIndex + ((washerFormula.ProgramNumber - 1) * (2 * 3));
                        int formulaPhStartIndex_TUN = ECTRLPLUS_TUN_PhStartIndex + ((washerFormula.ProgramNumber - 1) * 4);
                        int formulaConductivityStartIndex_TUN = ECTRLPLUS_TUN_ConductivityStartIndex + ((washerFormula.ProgramNumber - 1) * 4);
                        int formulaProductStartIndex_TUN = ECTRLPLUS_TUN_ProductStartIndex + ((washerFormula.ProgramNumber - 1) * 40);
                        int[] phControlArray = new int[4];
                        int regulationIndex = 0;
                        foreach (PhAnalogueControlStep phAnalogueControlStep in washerFormula.washerFormulaPhAnalogueControlSteps.Take(1))
                        {
                            regulationIndex += 1;
                            if (regulationIndex <= 1)
                            {
                                phControlArray[0] = (int)(phAnalogueControlStep.PhMinimum * 10);
                                phControlArray[1] = (int)(phAnalogueControlStep.PhMaximum * 10);
                                phControlArray[2] = phAnalogueControlStep.PhDelayTime;
                                phControlArray[3] = phAnalogueControlStep.PhMeasuringTime;
                            }
                        }

                        //Ph Analogue Details
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("R{0}", formulaPhStartIndex_TUN),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 4,
                            IntArrayData = phControlArray
                        });

                        regulationIndex = 0;
                        int[] conductivityControlArray = new int[5];
                        foreach (ConductivityAnalogueControlStep conductivityAnalogueControlStep in washerFormula.washerFormulaConductivityAnalogueControlSteps.Take(1))
                        {
                            regulationIndex += 1;
                            if (regulationIndex <= 1)
                            {
                                conductivityControlArray[0] = (int)(conductivityAnalogueControlStep.ConductivityMinimum * 100);
                                conductivityControlArray[1] = (int)(conductivityAnalogueControlStep.ConductivityMaximum * 100);
                                conductivityControlArray[2] = conductivityAnalogueControlStep.ConductivityDelayTime;
                                conductivityControlArray[3] = conductivityAnalogueControlStep.ConductivityMeasuringTime;
                            }
                        }

                        //Conductivity Analogue Details
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("R{0}", formulaConductivityStartIndex_TUN),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 5,
                            IntArrayData = conductivityControlArray
                        });

                        int[,] temperatureControlArray = new int[2, 3];
                        foreach (TemperatureAnalogueControlStep temperatureAnalogueControlStep in washerFormula.washerFormulaTemperatureAnalogueControlSteps.Take(2))
                        {
                            if (temperatureAnalogueControlStep.ProbeNumber >= 1 && temperatureAnalogueControlStep.ProbeNumber <= 2)
                            {
                                temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 0] = (int)(temperatureAnalogueControlStep.TunnelSetPointTemperature);
                                temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 1] = temperatureAnalogueControlStep.TunnelStartDelay;
                                temperatureControlArray[temperatureAnalogueControlStep.ProbeNumber - 1, 2] = temperatureAnalogueControlStep.TunnelAcceptedDelay;
                            }
                        }

                        int[] temperatureControlArr = new int[]
                        {
                            temperatureControlArray.Slice(0)[0],
                            temperatureControlArray.Slice(0)[1],
                            temperatureControlArray.Slice(0)[2],
                            temperatureControlArray.Slice(1)[0],
                            temperatureControlArray.Slice(1)[1],
                            temperatureControlArray.Slice(1)[2]
                        };

                        //Temperature Analogue Details
                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("R{0}", formulaTempStartIndex_TUN),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 6,
                            IntArrayData = temperatureControlArr
                        });

                        //Product Fields
                        int[] productsArray = new int[40];
                        int productIndex = 0;

                        List<Models.WasherGroup.WasherFormulaDosingStepProduct> lstproduct = new List<Models.WasherGroup.WasherFormulaDosingStepProduct>();
                        foreach (Models.WasherGroup.WasherFormulaDosingStep washerFormulaDosingStep in washerFormula.WasherFormulaDosingSteps)
                        {
                            foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in washerFormulaDosingStep.WasherFormulaDosingStepProducts.Take(40))
                            {
                                lstproduct.Add(product);
                                lstproduct.OrderBy(p => p.EquipmentNumber == product.EquipmentNumber).ThenBy(p => p.DosingPointNumber == product.DosingPointNumber);
                            }
                        }

                        foreach (Models.WasherGroup.WasherFormulaDosingStepProduct product in lstproduct)
                        {
                            int quantity = (int)(product.Quantity * 10);
                            int delay = product.Delay;
                            offset = Convert.ToInt32(product.EquipmentNumber) * 4;
                            if (product.EquipmentNumber == 9)
                            {
                                offset = 0;
                            }
                            else if (product.EquipmentNumber == 10)
                            {
                                offset = Convert.ToInt32(product.EquipmentNumber - 1) * 4;
                            }
                            productIndex += 1;
                            if (productIndex <= 40)
                            {
                                string value = String.Format("{0}{1}", Convert.ToString(quantity).PadLeft(3, '0'), Convert.ToString(delay).PadLeft(2, '0'));
                                productsArray[offset + product.DosingPointNumber - 1] = Convert.ToInt32(value);
                            }
                        }

                        int[] productsArr = new int[]
                           {
                                productsArray[0],
                                productsArray[1],
                                productsArray[2],
                                productsArray[3],
                                productsArray[4],
                                productsArray[5],
                                productsArray[6],
                                productsArray[7],
                                productsArray[8],
                                productsArray[9],
                                productsArray[10],
                                productsArray[11],
                                productsArray[12],
                                productsArray[13],
                                productsArray[14],
                                productsArray[15],
                                productsArray[16],
                                productsArray[17],
                                productsArray[18],
                                productsArray[19],
                                productsArray[20],
                                productsArray[21],
                                productsArray[22],
                                productsArray[23],
                                productsArray[24],
                                productsArray[25],
                                productsArray[26],
                                productsArray[27],
                                productsArray[28],
                                productsArray[29],
                                productsArray[30],
                                productsArray[31],
                                productsArray[32],
                                productsArray[33],
                                productsArray[34],
                                productsArray[35],
                                productsArray[36],
                                productsArray[37],
                                productsArray[38],
                                productsArray[39]
                       };

                        tags.Add(new MitsubishiTag()
                        {
                            Address = string.Format("D{0}", formulaProductStartIndex_TUN),
                            TagItemType = UIInputType.TypeArray,
                            ArrayLength = 40,
                            IntArrayData = productsArr
                        });
                    }
                }
                #endregion
            }

            if (tags.Count > 0)
            {
                DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
                writer.WriteTags(tags);
                FX3UEthernetWriter mitWriter = (FX3UEthernetWriter)writer;
                mitWriter.ClosePLC();
            }
        }

        /// <summary>
        /// Write EControl Plus Washer Group Deleted Formula Settings
        /// </summary>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="washerGroupTypeId">Washer Group Type Id</param>
        /// <param name="deletedFormulas">Deleted Formulas List</param>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        public void WriteEControlPlusWasherGroupDeletedFormulaSettings(int controllerId, int washerGroupTypeId, List<WasherGroupFormula> deletedFormulas, int washerDosingNumber = 0)
        {
            int ECTRLPLUS_WE_HeaderStartIndex = 0;
            int ECTRLPLUS_WE_TemperatureStartIndex = 0;
            int ECTRLPLUS_WE_DelayStartIndex = 0;
            int ECTRLPLUS_WE_PhStartIndex = 0;
            int ECTRLPLUS_WE_ProductStartIndex = 0;
            int ECTRLPLUS_TUN_TemperatureStartIndex = 0;
            int ECTRLPLUS_TUN_PhStartIndex = 0;
            int ECTRLPLUS_TUN_ConductivityStartIndex = 0;
            int ECTRLPLUS_TUN_ProductStartIndex = 0;
            ControllerInfoForPlcModel controllerInfo = GetControllerInfo(controllerId).FirstOrDefault();
            MitsubishiController controller = new MitsubishiController() { HostAdress = controllerInfo.Value, ControllerId = controllerId };
            switch (controllerInfo.ControllerTypeId)
            {
                case 6:
                    ECTRLPLUS_WE_HeaderStartIndex = ECTRLPLUS8WWEHeaderBaseIndex;
                    ECTRLPLUS_WE_TemperatureStartIndex = ECTRLPLUS8WWETemperatureBaseIndex;
                    ECTRLPLUS_WE_DelayStartIndex = ECTRLPLUS8WWEDelayBaseIndex;
                    ECTRLPLUS_WE_PhStartIndex = ECTRLPLUS8WWEPhBaseIndex;
                    ECTRLPLUS_WE_ProductStartIndex = ECTRLPLUS8WWEProductBaseIndex;
                    controller.PLCType = MitsubishiPLCType.EControlPlus8W;
                    break;
                case 7:
                    ECTRLPLUS_TUN_TemperatureStartIndex = ECTRLPLUSTUN1TemperatureStartIndex;
                    ECTRLPLUS_TUN_PhStartIndex = ECTRLPLUSTUN1PhStartIndex;
                    ECTRLPLUS_TUN_ConductivityStartIndex = ECTRLPLUSTUN1ConductivityStartIndex;
                    ECTRLPLUS_TUN_ProductStartIndex = ECTRLPLUSTUN1ProductStartIndex;
                    controller.PLCType = MitsubishiPLCType.EControlPlus6W1T;
                    break;
            }
            List<MitsubishiTag> tags = new List<MitsubishiTag>();
            if (washerGroupTypeId == 1)
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetConventionalFormulaResetTagsForEControlPlus(washerDosingNumber,
                                                                deletedFormula.ProgramNumber,
                                                                ECTRLPLUS_WE_HeaderStartIndex,
                                                                ECTRLPLUS_WE_TemperatureStartIndex,
                                                                ECTRLPLUS_WE_PhStartIndex,
                                                                ECTRLPLUS_WE_ProductStartIndex,
                                                                ECTRLPLUS_WE_DelayStartIndex
                                                                ));
                }
            }
            else
            {
                foreach (WasherGroupFormula deletedFormula in deletedFormulas)
                {
                    tags.AddRange(GetTunnelFormulaResetTagsForEControlPlus(washerDosingNumber,
                                                        deletedFormula.ProgramNumber,
                                                        ECTRLPLUS_TUN_TemperatureStartIndex,
                                                        ECTRLPLUS_TUN_PhStartIndex,
                                                        ECTRLPLUS_TUN_ConductivityStartIndex,
                                                        ECTRLPLUS_TUN_ProductStartIndex));
                }
            }
            if (tags.Count > 0)
            {

                DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
                writer.WriteTags(tags);
            }
        }

        /// <summary>
        /// Get Conventional Formula Reset Tags For MyControl
        /// </summary>
        /// <param name="programNumber">Program Number</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        private IEnumerable<BeckhoffTag> GetConventionalFormulaResetTagsForMyControl(int programNumber)
        {
            return new List<BeckhoffTag>() {
                new BeckhoffTag() {
                    Address = ".uint_Wash_Prg_WE[" + programNumber + "]",
                    TagItemType = UIInputType.TypeArray,
                    BatchData = Enumerable.Repeat(0, MyControl_WE_FormulaArray).Select(i => (ushort)i).ToList()
                }
            };
        }

        /// <summary>
        /// Get Tunnel Formula Reset Tags For MyControl
        /// </summary>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <param name="programNumber">Program Number</param>
        /// <returns>Returns list of BeckhoffTags.</returns>
        private IEnumerable<BeckhoffTag> GetTunnelFormulaResetTagsForMyControl(int washerDosingNumber, int programNumber)
        {
            return new List<BeckhoffTag>() {
                new BeckhoffTag() {
                    Address = ".uint_Wash_Prg_TUN[" + washerDosingNumber + "," + programNumber + "]",
                    TagItemType = UIInputType.TypeArray,
                    BatchData = Enumerable.Repeat(0, MyControl_TUN_FormulaArray).Select(i => (ushort)i).ToList()
                }
            };
        }

        /// <summary>
        /// Get Conventional Formula Reset Tags for PLC XL
        /// </summary>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="programNumber">Program Number of Formula</param>
        /// <param name="PLCXL_WE_HeaderStartIndex">Start index of the PLCX l_ w e_ header.</param>
        /// <param name="PLCXL_WE2_HeaderStartIndex">Start index of the PLCX l_ w e2_ header.</param>
        /// <param name="PLCXL_WE_TemperatureStartIndex">Start index of the PLCX l_ w e_ temperature.</param>
        /// <param name="PLCXL_WE2_TemperatureStartIndex">Start index of the PLCX l_ w e2_ temperature.</param>
        /// <param name="PLCXL_WE_StartDelayStartIndex">Start index of the PLCX l_ w e_ start delay.</param>
        /// <param name="PLCXL_WE2_StartDelayStartIndex">Start index of the PLCX l_ w e2_ start delay.</param>
        /// <param name="PLCXL_WE_PhStartIndex">Start index of the PLCX l_ w e_ ph.</param>
        /// <param name="PLCXL_WE2_PhStartIndex">Start index of the PLCX l_ w e2_ ph.</param>
        /// <param name="PLCXL_WE_ProductStartIndex">Start index of the PLCX l_ w e_ product.</param>
        /// <param name="PLCXL_WE2_ProductStartIndex">Start index of the PLCX l_ w e2_ product.</param>
        /// <returns>
        /// Returns List of MitsubishiTags
        /// </returns>
        private IEnumerable<MitsubishiTag> GetConventionalFormulaResetTagsForPLCXL(int washerDosingNumber,
                                                                                    int programNumber,
                                                                                    int PLCXL_WE_HeaderStartIndex,
                                                                                    int PLCXL_WE2_HeaderStartIndex,
                                                                                    int PLCXL_WE_TemperatureStartIndex,
                                                                                    int PLCXL_WE2_TemperatureStartIndex,
                                                                                    int PLCXL_WE_StartDelayStartIndex,
                                                                                    int PLCXL_WE2_StartDelayStartIndex,
                                                                                    int PLCXL_WE_PhStartIndex,
                                                                                    int PLCXL_WE2_PhStartIndex,
                                                                                    int PLCXL_WE_ProductStartIndex,
                                                                                    int PLCXL_WE2_ProductStartIndex)
        {
            List<MitsubishiTag> tags = new List<MitsubishiTag>();
            int formulaHeaderStartIndex_WE = PLCXL_WE_HeaderStartIndex + ((programNumber - 1) * 5);
            int formulaHeaderStartIndex_WE2 = PLCXL_WE2_HeaderStartIndex + ((programNumber - 1) * 5);
            int formulaTempStartIndex_WE = PLCXL_WE_TemperatureStartIndex + ((programNumber - 1) * (5 * 5));
            int formulaTempStartIndex_WE2 = PLCXL_WE2_TemperatureStartIndex + ((programNumber - 1) * (5 * 5));
            int formulaStartDelayStartIndex_WE = PLCXL_WE_StartDelayStartIndex + ((programNumber - 1) * 5);
            int formulaStartDelayStartIndex_WE2 = PLCXL_WE2_StartDelayStartIndex + ((programNumber - 1) * 5);
            int formulaPhStartIndex_WE = PLCXL_WE_PhStartIndex + ((programNumber - 1) * 10);
            int formulaPhStartIndex_WE2 = PLCXL_WE2_PhStartIndex + ((programNumber - 1) * 10);
            int formulaProductStartIndex_WE = PLCXL_WE_ProductStartIndex + ((programNumber - 1) * (25 * 4));
            int formulaProductStartIndex_WE2 = PLCXL_WE2_ProductStartIndex + ((programNumber - 1) * (25 * 4));

            //Header Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaHeaderStartIndex_WE : formulaHeaderStartIndex_WE2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 5,
                IntArrayData = new int[5]
            });

            //Temparature Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaTempStartIndex_WE : formulaTempStartIndex_WE2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 25,
                IntArrayData = new int[25]
            });

            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaStartDelayStartIndex_WE : formulaStartDelayStartIndex_WE2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 5,
                IntArrayData = new int[5]
            });

            //Ph Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaPhStartIndex_WE : formulaPhStartIndex_WE2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 6,
                IntArrayData = new int[5]
            });

            //Product Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaProductStartIndex_WE : formulaProductStartIndex_WE2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 100,
                IntArrayData = new int[100]
            });

            return tags;
        }

        /// <summary>
        /// Get Tunnel Formula Reset Tags For PLCXL
        /// </summary>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <param name="programNumber">Program Number</param>
        /// <param name="PLCXL_TUN_TemperatureStartIndex">Start index of the PLCX l_ tu n_ temperature.</param>
        /// <param name="PLCXL_TUN2_TemperatureStartIndex">Start index of the PLCX l_ tu N2_ temperature.</param>
        /// <param name="PLCXL_TUN_StartDelayStartIndex">Start index of the PLCX l_ tu n_ start delay.</param>
        /// <param name="PLCXL_TUN2_StartDelayStartIndex">Start index of the PLCX l_ tu N2_ start delay.</param>
        /// <param name="PLCXL_TUN_ProductStartIndex">Start index of the PLCX l_ tu n_ product.</param>
        /// <param name="PLCXL_TUN2_ProductStartIndex">Start index of the PLCX l_ tu N2_ product.</param>
        /// <param name="PLCXL_TUN_PhStartIndex">Start index of the PLCX l_ tu n_ ph.</param>
        /// <param name="PLCXL_TUN2_PhStartIndex">Start index of the PLCX l_ tu N2_ ph.</param>
        /// <param name="PLCXL_TUN_ConductivityStartIndex">Start index of the PLCX l_ tu n_ conductivity.</param>
        /// <param name="PLCXL_TUN2_ConductivityStartIndex">Start index of the PLCX l_ tu N2_ conductivity.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IEnumerable<MitsubishiTag> GetTunnelFormulaResetTagsForPLCXL(int washerDosingNumber,
                                                                            int programNumber,
                                                                            int PLCXL_TUN_TemperatureStartIndex,
                                                                            int PLCXL_TUN2_TemperatureStartIndex,
                                                                            int PLCXL_TUN_StartDelayStartIndex,
                                                                            int PLCXL_TUN2_StartDelayStartIndex,
                                                                            int PLCXL_TUN_ProductStartIndex,
                                                                            int PLCXL_TUN2_ProductStartIndex,
                                                                            int PLCXL_TUN_PhStartIndex,
                                                                            int PLCXL_TUN2_PhStartIndex,
                                                                            int PLCXL_TUN_ConductivityStartIndex,
                                                                            int PLCXL_TUN2_ConductivityStartIndex)
        {
            List<MitsubishiTag> tags = new List<MitsubishiTag>();

            int formulaTempStartIndex_TUN = PLCXL_TUN_TemperatureStartIndex + ((programNumber - 1) * (3 * 4));
            int formulaTempStartIndex_TUN2 = PLCXL_TUN2_TemperatureStartIndex + ((programNumber - 1) * (3 * 4));
            int formulaStartDelayStartIndex_TUN = PLCXL_TUN_StartDelayStartIndex + ((programNumber - 1) * 3);
            int formulaStartDelayStartIndex_TUN2 = PLCXL_TUN2_StartDelayStartIndex + ((programNumber - 1) * 3);
            int formulaPhStartIndex_TUN = PLCXL_TUN_PhStartIndex + ((programNumber - 1) * 5);
            int formulaPhStartIndex_TUN2 = PLCXL_TUN2_PhStartIndex + ((programNumber - 1) * 5);
            int formulaConductivityStartIndex_TUN = PLCXL_TUN_ConductivityStartIndex + ((programNumber - 1) * 5);
            int formulaConductivityStartIndex_TUN2 = PLCXL_TUN2_ConductivityStartIndex + ((programNumber - 1) * 5);
            int formulaProductStartIndex_TUN = PLCXL_TUN_ProductStartIndex + ((programNumber - 1) * 70);
            int formulaProductStartIndex_TUN2 = PLCXL_TUN2_ProductStartIndex + ((programNumber - 1) * 70);

            //Header Fields, Regulation Levels & Dosing 
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaProductStartIndex_TUN : formulaProductStartIndex_TUN2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 70,
                IntArrayData = new int[70]
            });

            //Temparature Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaTempStartIndex_TUN : formulaTempStartIndex_TUN2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 12,
                IntArrayData = new int[12]
            });

            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaStartDelayStartIndex_TUN : formulaStartDelayStartIndex_TUN2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 3,
                IntArrayData = new int[3]
            });

            //Ph Analogue Details
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaPhStartIndex_TUN : formulaPhStartIndex_TUN2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 5,
                IntArrayData = new int[5]
            });

            //Conductivity Analogue Details
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaConductivityStartIndex_TUN : formulaConductivityStartIndex_TUN2)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 5,
                IntArrayData = new int[5]
            });

            return tags;
        }

        /// <summary>
        /// Gets All Conventional Formula Reset Tags For PLCXL
        /// </summary>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <param name="PLCXL_WE_HeaderStartIndex">Start index of the PLCX l_ w e_ header.</param>
        /// <param name="PLCXL_WE2_HeaderStartIndex">Start index of the PLCX l_ w e2_ header.</param>
        /// <param name="PLCXL_WE_TemperatureStartIndex">Start index of the PLCX l_ w e_ temperature.</param>
        /// <param name="PLCXL_WE2_TemperatureStartIndex">Start index of the PLCX l_ w e2_ temperature.</param>
        /// <param name="PLCXL_WE_StartDelayStartIndex">Start index of the PLCX l_ w e_ start delay.</param>
        /// <param name="PLCXL_WE2_StartDelayStartIndex">Start index of the PLCX l_ w e2_ start delay.</param>
        /// <param name="PLCXL_WE_PhStartIndex">Start index of the PLCX l_ w e_ ph.</param>
        /// <param name="PLCXL_WE2_PhStartIndex">Start index of the PLCX l_ w e2_ ph.</param>
        /// <param name="PLCXL_WE_ProductStartIndex">Start index of the PLCX l_ w e_ product.</param>
        /// <param name="PLCXL_WE2_ProductStartIndex">Start index of the PLCX l_ w e2_ product.</param>
        /// <returns></returns>
        private IEnumerable<MitsubishiTag> GetAllConventionalFormulaResetTagsForPLCXL(int washerDosingNumber,
                                                                                    int PLCXL_WE_HeaderStartIndex,
                                                                                    int PLCXL_WE2_HeaderStartIndex,
                                                                                    int PLCXL_WE_TemperatureStartIndex,
                                                                                    int PLCXL_WE2_TemperatureStartIndex,
                                                                                    int PLCXL_WE_StartDelayStartIndex,
                                                                                    int PLCXL_WE2_StartDelayStartIndex,
                                                                                    int PLCXL_WE_PhStartIndex,
                                                                                    int PLCXL_WE2_PhStartIndex,
                                                                                    int PLCXL_WE_ProductStartIndex,
                                                                                    int PLCXL_WE2_ProductStartIndex)
        {
            List<MitsubishiTag> tags = new List<MitsubishiTag>();
            //Header Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? PLCXL_WE_HeaderStartIndex : PLCXL_WE2_HeaderStartIndex)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 495,
                IntArrayData = new int[495]
            });

            //Temparature Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? PLCXL_WE_TemperatureStartIndex : PLCXL_WE2_TemperatureStartIndex)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 2475,
                IntArrayData = new int[2475]
            });

            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? PLCXL_WE_StartDelayStartIndex : PLCXL_WE2_StartDelayStartIndex)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 495,
                IntArrayData = new int[495]
            });

            //Ph Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? PLCXL_WE_PhStartIndex : PLCXL_WE2_PhStartIndex)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 594,
                IntArrayData = new int[594]
            });

            //Product Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? PLCXL_WE_ProductStartIndex : PLCXL_WE2_ProductStartIndex)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 9900,
                IntArrayData = new int[9900]
            });

            return tags;
        }

        /// <summary>
        /// Get Conventional Formula Reset Tags For EControl Plus
        /// </summary>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <param name="programNumber">Program Number</param>
        /// <param name="ECTRLPLUS_WE_HeaderStartIndex">Start index of the ectrlplu s_ w e_ header.</param>
        /// <param name="ECTRLPLUS_WE_TemperatureStartIndex">Start index of the ectrlplu s_ w e_ temperature.</param>
        /// <param name="ECTRLPLUS_WE_PhStartIndex">Start index of the ectrlplu s_ w e_ ph.</param>
        /// <param name="ECTRLPLUS_WE_ProductStartIndex">Start index of the ectrlplu s_ w e_ product.</param>
        /// <param name="ECTRLPLUS_WE_DelayStartIndex">Start index of the ectrlplu s_ w e_ delay.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IEnumerable<MitsubishiTag> GetConventionalFormulaResetTagsForEControlPlus(int washerDosingNumber,
                                                                                   int programNumber,
                                                                                   int ECTRLPLUS_WE_HeaderStartIndex,
                                                                                   int ECTRLPLUS_WE_TemperatureStartIndex,
                                                                                   int ECTRLPLUS_WE_PhStartIndex,
                                                                                   int ECTRLPLUS_WE_ProductStartIndex,
                                                                                   int ECTRLPLUS_WE_DelayStartIndex)
        {
            List<MitsubishiTag> tags = new List<MitsubishiTag>();
            int formulaHeaderStartIndex_WE = ECTRLPLUS_WE_HeaderStartIndex + ((programNumber - 1) * 4);
            int formulaTempStartIndex_WE = ECTRLPLUS_WE_TemperatureStartIndex + ((programNumber - 1) * 4);
            int formulaPhStartIndex_WE = ECTRLPLUS_WE_PhStartIndex + ((programNumber - 1) * 6);
            int formulaProductStartIndex_WE = ECTRLPLUS_WE_ProductStartIndex + ((programNumber - 1) * 2);
            int formulaProductStartdelayIndex_WE = ECTRLPLUS_WE_DelayStartIndex + ((programNumber - 1) * 1);
            //Header Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("D{0}", (washerDosingNumber == 1 ? formulaHeaderStartIndex_WE : 0)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 4,
                IntArrayData = new int[4]
            });
            //Temparature Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaTempStartIndex_WE : 0)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 4,
                IntArrayData = new int[4]
            });
            //Ph Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", (washerDosingNumber == 1 ? formulaPhStartIndex_WE : 0)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 6,
                IntArrayData = new int[6]
            });
            //Product Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("D{0}", (washerDosingNumber == 1 ? formulaProductStartIndex_WE : 0)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 40,
                IntArrayData = new int[40]
            });
            //Delay product Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("D{0}", (washerDosingNumber == 1 ? formulaProductStartdelayIndex_WE : 0)),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 20,
                IntArrayData = new int[20]
            });
            return tags;
        }

        /// <summary>
        /// Get Tunnel Formula Reset Tags For EControl Plus
        /// </summary>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <param name="programNumber">Program Number</param>
        /// <param name="PLCXL_TUN_TemperatureStartInde">The PLCX l_ tu n_ temperature start inde.</param>
        /// <param name="PLCXL_TUN_PhStartIndex">Start index of the PLCX l_ tu n_ ph.</param>
        /// <param name="PLCXL_TUN_ConductivityStartIndex">Start index of the PLCX l_ tu n_ conductivity.</param>
        /// <param name="PLCXL_TUN_ProductStartIndex">Start index of the PLCX l_ tu n_ product.</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private IEnumerable<MitsubishiTag> GetTunnelFormulaResetTagsForEControlPlus(int washerDosingNumber,
                                                                           int programNumber,
                                                                           int PLCXL_TUN_TemperatureStartInde,
                                                                           int PLCXL_TUN_PhStartIndex,
                                                                           int PLCXL_TUN_ConductivityStartIndex,
                                                                            int PLCXL_TUN_ProductStartIndex)
        {
            List<MitsubishiTag> tags = new List<MitsubishiTag>();

            int formulaTempStartIndex_TUN = PLCXL_TUN_TemperatureStartInde + ((programNumber - 1) * 3);
            int formulaPhStartIndex_TUN = PLCXL_TUN_PhStartIndex + ((programNumber - 1) * 4);
            int formulaConductivityStartIndex_TUN = PLCXL_TUN_ConductivityStartIndex + ((programNumber - 1) * 4);
            int formulaProductStartIndex_TUN = PLCXL_TUN_ProductStartIndex + ((programNumber - 1) * 20);

            //Product Dosing 
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", formulaProductStartIndex_TUN),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 20,
                IntArrayData = new int[20]
            });

            //Temparature Control Fields
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", formulaTempStartIndex_TUN),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 6,
                IntArrayData = new int[6]
            });

            //Ph Analogue Details
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", formulaPhStartIndex_TUN),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 4,
                IntArrayData = new int[4]
            });

            //Conductivity Analogue Details
            tags.Add(new MitsubishiTag()
            {
                Address = string.Format("R{0}", formulaConductivityStartIndex_TUN),
                TagItemType = UIInputType.TypeArray,
                ArrayLength = 4,
                IntArrayData = new int[4]
            });

            return tags;
        }

        /// <summary>
        /// Get Equipment Number Index For PLCXL
        /// </summary>
        /// <param name="equipmentNumber">Equipment Number</param>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        private byte GetEquipmentNumberIndexForPLCXL(byte equipmentNumber, int washerDosingNumber)
        {
            //0 = ME1, 13 = ME2, 1..12 = Pump number
            byte equipmentNumberIndex = 0;

            if (washerDosingNumber == 1)
            {
                if (equipmentNumber == 13 || equipmentNumber == 14)
                {
                    equipmentNumberIndex = (byte)(equipmentNumber == 14 ? 13 : 0);
                }
                else
                {
                    equipmentNumberIndex = equipmentNumber;
                }
            }
            else
            {
                if (equipmentNumber == 27 || equipmentNumber == 28)
                {
                    equipmentNumberIndex = (byte)(equipmentNumber == 28 ? 13 : 0);
                }
                else
                {
                    equipmentNumberIndex = (byte)(equipmentNumber - 14);
                }
            }

            return equipmentNumberIndex;
        }

        /// <summary>
        /// Get Equipment Number Index For EControl Plus
        /// </summary>
        /// <param name="equipmentNumber">Equipment Number</param>
        /// <param name="washerDosingNumber">Washer Dosing Number</param>
        /// <returns>Returns list of MitsubishiTags.</returns>
        public byte GetEquipmentNumberIndexForECTRLPLUS(byte equipmentNumber, int washerDosingNumber)
        {
            //0 = ME1, 9 = ME2, 1..8 = Pump number
            byte equipmentNumberIndex = 0;

            if (equipmentNumber == 9 || equipmentNumber == 10)
            {
                equipmentNumberIndex = (byte)(equipmentNumber == 10 ? 9 : 0);
            }
            else
            {
                equipmentNumberIndex = equipmentNumber;
            }

            return equipmentNumberIndex;
        }

        #endregion
    }
}