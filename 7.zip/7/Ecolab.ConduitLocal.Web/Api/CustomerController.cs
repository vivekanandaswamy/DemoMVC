﻿// -----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Customer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Http;
    using Castle.Core.Logging;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Elmah;
    using Models;
    using Services;
    using Services.Interfaces;
    using EntityConverter = Mapper.EntityConverter;
    
    /// <summary>
    ///     class Customer Controller
    /// </summary>
    public class CustomerController : BaseApiController
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private readonly IPlantCustomerService plantCustService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="CustomerController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantCustService">The Plant Customer Service</param>
        /// <param name="plantService">The plant service</param>
        public CustomerController(IUserService userService, IPlantCustomerService plantCustService, IPlantService plantService) : base(userService, plantService)
        {
            this.plantCustService = plantCustService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Get the Customer list
        /// </summary>
        /// <returns>Returns the Customer list</returns>
        [HttpGet]
        public IEnumerable<PlantCustomerModel> GetCustomer()
        {
            List<PlantCustomer> cust = this.plantCustService.GetPlantCustomer(this.EcolabAccountNumber);
            List<PlantCustomerModel> custList = cust.Select(EntityConverter.ConvertToWebModel).ToList();
            custList = custList.Where(item => item.IsDeleted == false).ToList();
            return custList.AsEnumerable();
        }

        /// <summary>
        ///     creates new the customer data
        /// </summary>
        /// <param name="data">customer data to create</param>
        /// <returns>Returns created customer data</returns>
        [HttpPost]
        public HttpResponseMessage CreateCustomer([FromBody] List< PlantCustomerModel> data)
        {
            PlantCustomer objplantCust = EntityConverter.ConvertToServiceModel(data[0]);
            try
            { 
                data[0].LastModifiedTimeStamp = DateTime.SpecifyKind(data[0].LastModifiedTimeStamp, DateTimeKind.Utc);
                IPrincipal user = HttpContext.Current.User;
                if (user != null)
                {
                    int userId = ((CustomPrincipal)user).UserId;
                    objplantCust.EcoalabAccountNumber = this.EcolabAccountNumber;
                    DateTime lastModifiedTimeStamp;
                    objplantCust.Id = this.plantCustService.SavePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
                    objplantCust.LastModifiedTimeStamp = lastModifiedTimeStamp;
                    objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                    if (objplantCust.Id.Value > 0)
                    {
                        Push.PushToQueue(objplantCust, this.UserId, objplantCust.Id.Value, (int)TcdAdminMessageTypes.TcdAddPlantCustomer, this.EcolabAccountNumber);
                    }
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Customer - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, 301);
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, objplantCust.Id);
        }

        /// <summary>
        ///     To update the customer details
        /// </summary>
        /// <param name="id">customer id</param>
        /// <param name="plantCustomerModel">customer data to update</param>
        /// <returns>Returns updated customer data</returns>
        [HttpPut]
        public HttpResponseMessage Put(int id, PlantCustomerModel plantCustomerModel)
        {
            if (id > 0)
            {
                try
                {
                    PlantCustomer objplantCust = EntityConverter.ConvertToServiceModel(plantCustomerModel);
                    objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                    IPrincipal user = HttpContext.Current.User;
                    if (user != null)
                    {
                        int userId = ((CustomPrincipal)user).UserId;
                        DateTime lastModifiedTimeStamp;
                        int response = this.plantCustService.SavePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
                        if (response == 301)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Customer Id already exists. Please try again.");
                        }
                        if (response > 0 && objplantCust.Id.HasValue)
                        {
                            objplantCust.LastModifiedTimeStamp = lastModifiedTimeStamp;
                            objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objplantCust, this.UserId, objplantCust.Id.Value, (int)TcdAdminMessageTypes.TcdUpdatePlantCustomer, this.EcolabAccountNumber);
                        }
                    }
                }
                catch (SqlException ex)
                {
                    this.Logger.Error("Api - Customer - Update Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    if (ex.Number == 2627)
                    {
                        return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Customer Id already exists. Please try again.");
                    }
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the customer. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, plantCustomerModel);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Save failed. Invalid customer details.");
        }

        /// <summary>
        ///     To update the customer details
        /// </summary>
        /// <param name="data">Customer data to update</param>
        /// <returns>Returns the updated data</returns>
        public HttpResponseMessage Put(List< PlantCustomerModel> data)
        {
            HttpResponseMessage HttpResponseMessage = new HttpResponseMessage();

            foreach (PlantCustomerModel PlantCustomerModel in data)
        {
                HttpResponseMessage = this.Put(PlantCustomerModel.CustomerId, PlantCustomerModel);
            }

            return HttpResponseMessage;
        }

        /// <summary>
        ///     Delete the Customer
        /// </summary>
        /// <param name="id">Delete the cUstomer based on ID</param>
        /// <param name="plantCustomerModel">customer data to update</param>
        /// <returns>Returns the Customer data by ID</returns>
        [HttpDelete]
        public HttpResponseMessage DeleteCustomer(int? id, PlantCustomerModel plantCustomerModel)
        {
            if (id > 0)
            {
                PlantCustomer objplantCust = EntityConverter.ConvertToServiceModel(plantCustomerModel);
                try
                {
                    objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                    IPrincipal user = HttpContext.Current.User;
                    if (user != null)
                    {
                        int userId = ((CustomPrincipal)user).UserId;
                        DateTime lastModifiedTimeStamp;
                        int response = this.plantCustService.DeletePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);

                        if (response > 0 && objplantCust.Id.HasValue)
                        {
                            objplantCust.LastModifiedTimeStamp = lastModifiedTimeStamp;
                            objplantCust.LastModifiedTimeStamp = DateTime.SpecifyKind(objplantCust.LastModifiedTimeStamp, DateTimeKind.Utc);
                            Push.PushToQueue(objplantCust, this.UserId, objplantCust.Id.Value, (int)TcdAdminMessageTypes.TcdDeletePlantCustomer, this.EcolabAccountNumber);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.Logger.Error("Api - Customer - Delete Error :", ex);
                    ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                    return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to delete the customer. Some error has occured. Please try again.");
                }

                return this.Request.CreateResponse(HttpStatusCode.OK, objplantCust.Id);
            }
            return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Delete failed. Invalid customer details.");
        }

        /// <summary>
        ///     Delete the Customer data
        /// </summary>
        /// <param name="data">Delete the Customer datas</param>
        /// <returns>Returns the deleted data by Id</returns>
        public HttpResponseMessage DeleteCustomer(List< PlantCustomerModel> data)
        {
            return this.DeleteCustomer(data[0].Id.Value, data[0]);
        }
    }
}