﻿// -----------------------------------------------------------------------
// <copyright file="DashboardController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dashboard Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
    using System.Collections.Generic;
    using System.Web.Http;
    using AutoMapper;
    using Ecolab.Models.Visualization.Monitor;
    using Models.Visualization.Monitor;
    using Services.Interfaces;
    using Services.Interfaces.Visualization.Monitor;

    /// <summary>
    ///     class Dashboard Controller
    /// </summary>
    public class DashboardController : BaseApiController
    {
        /// <summary>
        ///     Dashboard Service
        /// </summary>
        private readonly IMonitorSetupService monitorSetupService;

        /// <summary>
        ///     Initializes a new instance of the DashboardController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="monitorSetupService">monitorSetup Service</param>
        public DashboardController(IUserService userService, IPlantService plantService, IMonitorSetupService monitorSetupService) : base(userService, plantService)
        {
            this.monitorSetupService = monitorSetupService;
        }

        /// <summary>
        ///     Gets Dashboard list
        /// </summary>
        /// <returns>Returns list of dashboards</returns>
        [HttpGet]
        public List<MonitorSetupModel> FetchDashboardList()
        {
            List<MonitorSetUp> monitorSetUpList = this.monitorSetupService.FetchDashboards(this.EcolabAccountNumber);
            return Mapper.Map<List<MonitorSetUp>, List<MonitorSetupModel>>(monitorSetUpList);
        }
    }
}