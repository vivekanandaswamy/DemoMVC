﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shift Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Api
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Net;
	using System.Net.Http;
	using System.Security.Principal;
	using System.Web;
	using System.Web.Http;
	using AutoMapper;
	using Castle.Core.Logging;
	using Conduit.Library.Enums;
	using Conduit.PushHandler;
	using Ecolab.Models.Common;
	using Elmah;
	using Models;
	using Models.PlantSetup.ShiftLabor;
	using Services;
	using Services.Interfaces;
	using Services.Interfaces.PlantSetup.ShiftLabor;
	using Utilities;
	using Model = Ecolab.Models.PlantSetup.ShiftLabor;
	using WebModel = Models.PlantSetup;

    /// <summary>
    ///     Api controller for ShiftLaborController
    /// </summary>
    public class ShiftLaborController : BaseApiController
    {
        /// <summary>
        ///     ShiftBreak Service
        /// </summary>
        private readonly ILaborService laborService;

        /// <summary>
        ///     ShiftBreak Service
        /// </summary>
        private readonly IShiftBreakService shiftBreakService;
        /// <summary>
        /// Initializes a new instance of the <see cref="ShiftLaborController"/> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="shiftBreakService">The shift break service.</param>
        /// <param name="laborService">The Labor service.</param>
        /// <param name="plantService">The plant service.</param>
        public ShiftLaborController(IUserService userService, IShiftBreakService shiftBreakService, ILaborService laborService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.shiftBreakService = shiftBreakService;
            this.laborService = laborService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Method to get shifts data based on shift id and day id.
        /// </summary>
        /// <param name="dayId">day is value</param>
        /// <param name="shiftId">shift id value</param>
        /// <returns>Dictionary of day as key and shifts as value</returns>
        public Dictionary<string, List<ShiftModel>> GetShiftData(int? dayId, int? shiftId)
        {
            var dicShift = new Dictionary<string, List<ShiftModel>>();
            string[] days = { "Samle", "SunDay", "MonDay", "TuesDay", "Wednesday", "Thursday", "FriDay", "Saturday" };
            List<Model.Shift> shifts = this.shiftBreakService.FetchShiftDetails(shiftId, dayId, this.EcolabAccountNumber);
            List<Model.ShiftLabor> shiftsLabors = this.laborService.FetchShiftLaborDetails(this.EcolabAccountNumber);
            List<ShiftModel> shiftModel = new List<ShiftModel>();
            shiftModel = Mapper.Map<List<Model.Shift>, List<ShiftModel>>(shifts);
            var shiftBreak = shiftModel.AsEnumerable().Select(x => x).GroupBy(s => new { s.DayId, s.ShiftId }).ToDictionary(a => a.Key, a => a.ToList());
            var shiftDays = new List<ShiftModel>();

            foreach (var item in shiftBreak)
            {
                ShiftModel shiftDay = new ShiftModel();
                for (int i = 0; i < item.Value.Count(); i++)
                {
                    if (item.Key.ShiftId == item.Value[i].ShiftId && item.Key.DayId == item.Value[i].DayId)
                    {
                        shiftDay.Id = item.Value[i].Id;
                        shiftDay.DayId = item.Value[i].DayId;
                        shiftDay.ShiftId = item.Value[i].ShiftId;
                        shiftDay.ShiftName = item.Value[i].ShiftName;
                        shiftDay.DayName = item.Value[i].DayName;
                        shiftDay.TargetProduction = item.Value[i].TargetProduction;
                        shiftDay.TargetProductionDisplay = shiftDay.TargetProduction;
                        shiftDay.StartTime = shiftDay.StartTime = DateTime.ParseExact(item.Value[i].StartTime, "HH:mm:ss", null).ToString("HH:mm");
                        shiftDay.EndTime = DateTime.ParseExact(item.Value[i].EndTime, "HH:mm:ss", null).ToString("HH:mm");
                        if ((item.Value[i].ShiftBreak.StartTime != "00:00:00") || (item.Value[i].ShiftBreak.EndTime != "00:00:00"))
                        {
                            shiftDay.ShiftBreaks.Add(new ShiftBreakModel
                            {
                                BreakId = item.Value[i].ShiftBreak.BreakId,
                                DayId = item.Value[i].ShiftBreak.DayId,
                                ShiftId = item.Value[i].ShiftBreak.ShiftId,
                                StartTime = DateTime.ParseExact(item.Value[i].ShiftBreak.StartTime, "HH:mm:ss", null).ToString("HH:mm"),
                                EndTime = DateTime.ParseExact(item.Value[i].ShiftBreak.EndTime, "HH:mm:ss", null).ToString("HH:mm")
                            });
                        }
                    }
                }

                shiftDays.Add(shiftDay);
                string day = Days.Sunday.ToString();
                List<ShiftModel> lstShiftModel = shiftDays.Where(x => x.DayId == item.Key.DayId && x.ShiftId == item.Key.ShiftId).ToList();
                //lstShiftModel.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0);
                shiftDay.TargetProductionAsString = shiftDay.TargetProduction.ToString("#,0.##");
                if (!dicShift.ContainsKey(days[item.Key.DayId]))
                {
                    dicShift.Add(days[item.Key.DayId], lstShiftModel);
                }
                else
                {
                    dicShift[days[item.Key.DayId]].AddRange(lstShiftModel);
                }
            }

            if (shiftId == null && dayId == null)
            {
                List<ShiftLaborModel> laborList = Mapper.Map<List<Model.ShiftLabor>, List<ShiftLaborModel>>(shiftsLabors);
                var shiftLaborModel = new List<ShiftLaborModel>();
                //laborList.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0, ExchangeRate, GetPlantDetails().CurrencyCode);
                foreach (ShiftLaborModel labor in laborList)
                {
                    labor.PricePerHrAsString = labor.PricePerHr.ToString("#,0.##");
                    labor.LaborTypes = this.FetchLaborType();
                    labor.Locations = this.FetchLaborLocation();
                    labor.LaborHoursAsString = labor.LaborHours.ToString("#,0.##");
                    if (dicShift.ContainsKey(days[labor.DayId]))
                    {
                        dicShift[days[labor.DayId]].AsEnumerable().First(x => x.ShiftId == labor.ShiftId).ShiftLabors.Add(labor);
                    }
                }
                return dicShift;
            }
            return this.FetchShiftsWithWeekDays(dicShift, dayId);
        }

        /// <summary>
        ///     Method to construct shift to display while editing.
        /// </summary>
        /// <param name="dicShift">shift object.</param>
        /// <param name="dayId">day of value.</param>
        /// <returns>Dictionary with days information</returns>
        private Dictionary<string, List<ShiftModel>> FetchShiftsWithWeekDays(Dictionary<string, List<ShiftModel>> dicShift, int? dayId)
        {
            var dicShiftEdit = new Dictionary<string, List<ShiftModel>>();
            var tempList = new List<ShiftModel>();
            string weekDay = string.Empty;
            foreach (KeyValuePair<string, List<ShiftModel>> item in dicShift)
            {
                switch (item.Key.ToLower())
                {
                    case "monday":
                        weekDay += "monday_";
                        break;
                    case "tuesday":
                        weekDay += "tuesday_";
                        break;
                    case "wednesday":
                        weekDay += "wednesday_";
                        break;
                    case "thursday":
                        weekDay += "thursday_";
                        break;
                    case "friday":
                        weekDay += "friday_";
                        break;
                    case "saturday":
                        weekDay += "saturday_";
                        break;
                    case "sunday":
                        weekDay += "sunday_";
                        break;
                }
                if (item.Value.AsEnumerable().Any(x => x.DayId == dayId))
                {
                    tempList.AddRange(item.Value);
                }
            }
            string[] day = weekDay.TrimEnd('_').Split('_');
            foreach (string dayItem in day)
            {
                switch (dayItem.ToLower())
                {
                    case "monday":
                        tempList[0].IsMonday = true;
                        break;
                    case "tuesday":
                        tempList[0].IsTuesday = true;
                        break;
                    case "wednesday":
                        tempList[0].IsWednesday = true;
                        break;
                    case "thursday":
                        tempList[0].IsThursday = true;
                        break;
                    case "friday":
                        tempList[0].IsFriday = true;
                        break;
                    case "saturday":
                        tempList[0].IsSaturday = true;
                        break;
                    case "sunday":
                        tempList[0].IsSunday = true;
                        break;
                }
            }
            dicShiftEdit.Add("day", tempList);
            return dicShiftEdit;
        }

        /// <summary>
        ///     Method to Get all shifts data on page load
        /// </summary>
        /// <returns>All shifts with day as key </returns>
        public Dictionary<string, List<ShiftModel>> Get()
        {
            return this.GetShiftData(null, null);
        }

        /// <summary>
        ///     Method to update shift
        /// </summary>
        /// <param name="shift">shift model.</param>
        /// <returns>Message returned from service</returns>
        public string UpdateShift(ShiftModel shift)
        {
            string result = string.Empty;
            string getMessage = string.Empty;
            //shift.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, true, 0);
            var lstShift = new List<Model.Shift>();
            IPrincipal user = HttpContext.Current.User;
            lstShift.AddRange(this.ConstructShift(shift, shift.DayId));
            if (user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;
                DateTime lastModifiedTimeStamp;
                result = this.shiftBreakService.UpdateShiftAndBreak(lstShift, userId, out lastModifiedTimeStamp);
                if (!getMessage.Contains(result))
                {
                    getMessage = result + "_" + getMessage;
                }
            }
            int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdUpdateShift;
            this.SyncShiftData(tcdAdminMessagetype);
            return getMessage;
        }

        /// <summary>
        ///     Method to return EcoLabAccountNumber
        /// </summary>
        /// <returns>Ecolab Account number.</returns>
        public string GetEcoLabAccountNumber()
        {
            PlantModel plantDetails = this.GetPlantDetails();
            return plantDetails.EcoalabAccountNumber;
        }

		/// <summary>
		/// Sync shift data to central
		/// </summary>
        /// <param name="tcdAdminMessageType">Admin Message type.</param>
		public void SyncShiftData(int tcdAdminMessageType)
		{
			Model.ShiftSyncContainer syncContainer = new Model.ShiftSyncContainer();
			syncContainer.Shift = this.shiftBreakService.FetchShiftDetailsForSync(null, null, this.EcolabAccountNumber, true);
            syncContainer.ShiftLabor = this.laborService.FetchShiftLaborDetailsForSync(this.EcolabAccountNumber, true);
            if (syncContainer.Shift!=null)
			syncContainer.Shift.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
            if (syncContainer.ShiftLabor != null)
			syncContainer.ShiftLabor.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
			if (tcdAdminMessageType == 43 || tcdAdminMessageType == 44 || tcdAdminMessageType == 45)
			{
				syncContainer.IsLabor = true;
			}
            Push.PushToQueue<Model.ShiftSyncContainer>(syncContainer, this.UserId, 0, tcdAdminMessageType, this.EcolabAccountNumber);
			
		}

        /// <summary>
        ///     Method to construct shift type with day id's for creating shifts
        /// </summary>
        /// <param name="shift">The shift model.</param>
        /// <param name="dayId">day of value</param>
        /// <returns>List of shifts</returns>
        private List<Model.Shift> ConstructShift(ShiftModel shift, int dayId)
        {
            var lstShift = new List<Model.Shift>();
            bool breakDeleted = false;

            foreach (ShiftBreakModel item in shift.ShiftBreaks)
            {
                if (shift.ShiftId == 0)
                {
                    breakDeleted = item.IsDeleted;
                }
                if (!breakDeleted)
                {
                    Model.Shift objShift = new Model.Shift
                    {
                        DayId = dayId,
                        DayName = shift.DayName,
                        StartTime = new TimeSpan(Convert.ToInt32(shift.StartTime.Split(':')[0]), Convert.ToInt32(shift.StartTime.Split(':')[1]), 0),
                        EndTime = new TimeSpan(Convert.ToInt32(shift.EndTime.Split(':')[0]), Convert.ToInt32(shift.EndTime.Split(':')[1]), 0),
                        Id = Convert.ToInt16(shift.Id),
                        ShiftId = shift.ShiftId,
                        ShiftName = shift.ShiftName,
                        EcolabAccountNumber = this.EcolabAccountNumber,
                        TargetProduction = shift.TargetProduction,
                        IsFriday = shift.IsFriday,
                        IsSaturday = shift.IsSaturday,
                        IsSunday = shift.IsSunday,
                        IsMonday = shift.IsMonday,
                        IsTuesday = shift.IsTuesday,
                        IsWednesday = shift.IsWednesday,
                        IsThursday = shift.IsThursday,
                        DesiredUnits = shift.DesiredUnits,
                        ShiftBreak = new Model.ShiftBreak
                        {
                            IsDeleted = item.IsDeleted,
                            BreakId = item.BreakId,
                            ShiftId = shift.ShiftId,
                            DayId = dayId,
                            StartTime = new TimeSpan(Convert.ToInt32(item.StartTime.Split(':')[0]), Convert.ToInt32(item.StartTime.Split(':')[1]), 0),
                            EndTime = new TimeSpan(Convert.ToInt32(item.EndTime.Split(':')[0]), Convert.ToInt32(item.EndTime.Split(':')[1]), 0),
                            EcolabAccountNumber = this.EcolabAccountNumber
                        }
                    };
                    lstShift.Add(objShift);
                }
                else
                {
                    lstShift.Add(this.ConstructShiftWithoutBreaks(shift, dayId));
                }
            }

            if (shift.ShiftBreaks.Count == 0)
            {
                lstShift.Add(this.ConstructShiftWithoutBreaks(shift, dayId));
            }

            return lstShift;
        }

        /// <summary>
        ///     Method to construct shift object
        /// </summary>
        /// <param name="shift">The shift model.</param>
        /// <param name="dayId">Day of value.</param>
        /// <returns>shift object</returns>
        private Model.Shift ConstructShiftWithoutBreaks(ShiftModel shift, int dayId)
        {
            Model.Shift objShift = new Model.Shift
            {
                DayId = dayId,
                DayName = shift.DayName,
                TargetProduction = shift.TargetProduction,
                StartTime = new TimeSpan(Convert.ToInt32(shift.StartTime.Split(':')[0]), Convert.ToInt32(shift.StartTime.Split(':')[1]), 0),
                EndTime = new TimeSpan(Convert.ToInt32(shift.EndTime.Split(':')[0]), Convert.ToInt32(shift.EndTime.Split(':')[1]), 0),
                Id = Convert.ToInt16(shift.Id),
                ShiftId = shift.ShiftId,
                ShiftName = shift.ShiftName,
                IsFriday = shift.IsFriday,
                IsSaturday = shift.IsSaturday,
                IsSunday = shift.IsSunday,
                IsMonday = shift.IsMonday,
                IsTuesday = shift.IsTuesday,
                IsWednesday = shift.IsWednesday,
                IsThursday = shift.IsThursday,
                EcolabAccountNumber = this.EcolabAccountNumber,
                ShiftBreak = new Model.ShiftBreak()
            };
            return objShift;
        }

        /// <summary>
        ///     Method to create shift
        /// </summary>
        /// <param name="shift">The shift model.</param>
        /// <returns>success/ error message</returns>
        [HttpPost]
        public HttpResponseMessage CreateShift([FromBody] ShiftModel shift)
        {
            string result = string.Empty;
            string editResult = string.Empty;
            IPrincipal user = HttpContext.Current.User;
            var lstShift = new List<Model.Shift>();
            if (shift.IsSunday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 1));
            }
            if (shift.IsMonday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 2));
            }
            if (shift.IsTuesday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 3));
            }
            if (shift.IsWednesday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 4));
            }
            if (shift.IsThursday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 5));
            }
            if (shift.IsFriday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 6));
            }
            if (shift.IsSaturday)
            {
                lstShift.AddRange(this.ConstructShift(shift, 7));
            }
            //If shift id > 0, it is edit.
            if (shift.ShiftId > 0)
            {
                editResult = this.UpdateShift(shift);
                string s = editResult;
                string[] values = s.Split('_');
                string resultMess = "201";
                if (!values.Any(resultMess.Contains))
                {
                    return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Shift updation");
                }
                return this.Request.CreateResponse(HttpStatusCode.OK, editResult.TrimEnd('#'));
            }

            string dbresult = string.Empty;
            if (user != null)
            {
                int userId = ((CustomPrincipal)user).UserId;
                DateTime lastModifiedTimeStamp;
                dbresult = this.shiftBreakService.InsertShiftAndBreak(lstShift, userId, out lastModifiedTimeStamp);
            }
            int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdAddShift;
            this.SyncShiftData(tcdAdminMessagetype);
            return this.Request.CreateResponse(HttpStatusCode.OK, dbresult.TrimEnd('#'));
        }

        /// <summary>
        ///     Method to delete shift
        /// </summary>
        /// <param name="id">Delete the shift based on identifier.</param>
        /// <param name="shiftId">The shift identifier.</param>
        [HttpGet]
        public void DeleteShift(int id, int shiftId)
        {
            IPrincipal user = HttpContext.Current.User;
            if (user != null)
            {
                DateTime lastModifiedTimeStamp;
                int userId = ((CustomPrincipal)user).UserId;
                Model.Shift objshift = new Model.Shift { DayId = id, ShiftId = Convert.ToInt16(shiftId), EcolabAccountNumber = this.EcolabAccountNumber };
                objshift.IsDelete = true;
                this.shiftBreakService.DeleteShiftAndBreak(objshift, userId, out lastModifiedTimeStamp);
                objshift.LastModifiedTimeStamp = lastModifiedTimeStamp;
                int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdDeleteShift;
                this.SyncShiftData(tcdAdminMessagetype);
            }
        }

        /// <summary>
        ///     Method to delete break
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="dayId">Day of value.</param>
        /// <param name="breakId">The break identifier.</param>
        [HttpGet]
        public void DeleteBreak(int id, int dayId, int breakId)
        {
            IPrincipal user = HttpContext.Current.User;
            if (user != null)
            {
                DateTime lastModifiedTimeStamp;
                int userId = ((CustomPrincipal)user).UserId;
                Model.Shift objshift = new Model.Shift { DayId = dayId, ShiftId = Convert.ToInt16(id), ShiftBreak = new Model.ShiftBreak { BreakId = breakId }, EcolabAccountNumber = this.EcolabAccountNumber };
                objshift.IsDelete = true;
                this.shiftBreakService.DeleteBreak(objshift, userId, out lastModifiedTimeStamp);
                objshift.LastModifiedTimeStamp = lastModifiedTimeStamp;
                int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdDeleteBreak;
                this.SyncShiftData(tcdAdminMessagetype);
            }
        }

        /// <summary>
        ///     Method to get shifts data based on day id and shift id to edit
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="shiftId">The shift identifier.</param>
        /// <returns>Dictionary of day as key and shift as value for editing</returns>
        [HttpGet]
        public Dictionary<string, List<ShiftModel>> GetShiftToEdit(int id, int shiftId)
        {
            return this.GetShiftData(id, shiftId);
        }

        /// <summary>
        ///     Fetches Labor Cost basing on Labor Type
        /// </summary>
        /// <param name="id">Labor Type Id</param>
        /// <returns>Labor Cost</returns>
        [HttpGet]
        public decimal FetchLaborCost(int id)
        {
            Model.LaborTypeCost cost = this.laborService.FetchCostByLabourType(id, this.EcolabAccountNumber);
            LaborTypeCostModel laborCost = Mapper.Map<Model.LaborTypeCost, LaborTypeCostModel>(cost);
            //laborCost.ConvertUnit(GetPlantDetails().UOMId, GetPlantDetails().EcoalabAccountNumber, GetCurrentUser().UserId, false, 0, ExchangeRate, GetPlantDetails().CurrencyCode);
            return laborCost.Cost;
        }

        #region Labor

        /// <summary>
        ///     Method to get Labor Type and Labor Locations
        /// </summary>
        /// <returns>ShiftLaborModel </returns>
        [HttpGet]
        public ShiftLaborModel GetLaborTypeAndLocation()
        {
            ShiftLaborModel shiftLaborModel = new ShiftLaborModel();
            shiftLaborModel.Locations = this.FetchLaborLocation();
            shiftLaborModel.LaborTypes = this.FetchLaborType();
            return shiftLaborModel;
        }

        /// <summary>
        ///     Method to get Labor Types for dropdowns
        /// </summary>
        /// <returns>Labor type model.</returns>
        public List<WebModel.LaborTypeModel> FetchLaborType()
        {
            List<LaborType> laborType = this.laborService.FetchLabourType();
            List<WebModel.LaborTypeModel> laborTypeList = Mapper.Map<List<LaborType>, List<WebModel.LaborTypeModel>>(laborType);
            return laborTypeList;
        }

        /// <summary>
        ///     Method to return Labor Locations for dropdowns
        /// </summary>
        /// <returns>labor location list.</returns>
        public List<WebModel.GroupTypeModel> FetchLaborLocation()
        {
            List<GroupType> laborLocation = this.laborService.GetGroupTypeDetails();
            List<WebModel.GroupTypeModel> laborLocationList = Mapper.Map<List<GroupType>, List<WebModel.GroupTypeModel>>(laborLocation);
            return laborLocationList;
        }

        /// <summary>
        ///     Method to create Labor
        /// </summary>
        /// <param name="labor">labor object.</param>
        /// <returns>success/ error message</returns>
        [HttpPost]
        public HttpResponseMessage CreateLabor([FromBody] ShiftLaborModel labor)
        {
            int result = 0;
            string editResult = string.Empty;
            IPrincipal user = HttpContext.Current.User;
            try
            {
                Model.ShiftLabor objLabor = Mapper.Map<ShiftLaborModel, Model.ShiftLabor>(labor);
                objLabor.EcolabAccountNumber = this.EcolabAccountNumber;
                //If shift id > 0, it is edit.
                if (labor.LaborId > 0)
                {
                    editResult = this.Updatelabor(objLabor);
                    if (editResult == "201")
                    {
                        return this.Request.CreateResponse(HttpStatusCode.OK, editResult);
                    }
                    return this.Request.CreateResponse(HttpStatusCode.Forbidden, editResult);
                }
                if (user != null)
                {
                    int userId = ((CustomPrincipal)user).UserId;
                    int count = 0;
                    DateTime lastModifiedTimeStamp;
                    result = this.laborService.InsertShiftLabor(objLabor, userId, out lastModifiedTimeStamp);
                    objLabor.LastModifiedTimeStamp = lastModifiedTimeStamp;

                    int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdAddShiftLabor;
                    this.SyncShiftData(tcdAdminMessagetype);
                    if (result != 0)
                    {
                        if (result == 301)
                        {
                            return this.Request.CreateResponse(HttpStatusCode.Forbidden, "301");
                        }
                    }
                    count++;
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Shift Labor - Create Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Shift Labor. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.OK, result);
        }

        /// <summary>
        ///     Method to update Labor
        /// </summary>
        /// <param name="labor">the shift labor model.</param>
        /// <returns>results whether the shift labor is updated or not.</returns>
        public string Updatelabor(Model.ShiftLabor labor)
        {
            int result = 0;
            IPrincipal user = HttpContext.Current.User;
            try
            {
                DateTime lastModifiedTimeStamp;
                if (user != null)
                {
                    int userId = ((CustomPrincipal)user).UserId;
                    result = this.laborService.UpdateShiftLabor(labor, userId, out lastModifiedTimeStamp);
                    labor.LastModifiedTimeStamp = lastModifiedTimeStamp;
                    int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdUpdateShiftLabor;
                    this.SyncShiftData(tcdAdminMessagetype);
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Shift Labor - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return "Unable to update the Shift Labor. Some error has occured. Please try again.";
                //  return Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Shift Labor. Some error has occured. Please try again.");
            }
            return Convert.ToString(result);
        }
        /// <summary>
        /// Method to delete labor
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Http response message.</returns>
        [HttpGet]
        public HttpResponseMessage DeleteLabor(int id)
        {
            int isDeleted = 0;

            try
            {
                IPrincipal user = HttpContext.Current.User;
                if (user != null)
                {
                    int userId = ((CustomPrincipal)user).UserId;
                    Model.ShiftLabor objShiftLabor = new Model.ShiftLabor { LaborId = id, EcolabAccountNumber = this.EcolabAccountNumber };
                    DateTime lastModifiedTimeStamp;
                    isDeleted = this.laborService.DeleteShiftLabor(objShiftLabor, userId, out lastModifiedTimeStamp);
                    objShiftLabor.IsDelete = true;
                    int tcdAdminMessagetype = (int)TcdAdminMessageTypes.TcdDeleteShiftLabor;
                    SyncShiftData(tcdAdminMessagetype);
                }
                if (isDeleted == id)
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, "Labor Deleted");
                }
            }
            catch (Exception ex)
            {
                this.Logger.Error("Api - Shift Labor - Delete Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Request.CreateResponse(HttpStatusCode.BadRequest, "Unable to update the Shift Labor. Some error has occured. Please try again.");
            }
            return this.Request.CreateResponse(HttpStatusCode.Forbidden, "Labor Deletion");
        }

        #endregion
    }
}