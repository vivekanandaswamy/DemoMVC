﻿// -----------------------------------------------------------------------
// <copyright file="AccountController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Account Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Mvc;
    using Castle.Core.Logging;
    using Ecolab.Models;
    using Elmah;
    using Models;
    using Services;
    using Services.Interfaces;

    /// <summary>
    ///     Class AccountController
    /// </summary>
    public class AccountController : Controller
    {
        /// <summary>
        ///     Forms Authentication
        /// </summary>
        private readonly IFormsAuthentication mFormsAuth;

        /// <summary>
        ///     User Service
        /// </summary>
        private readonly IUserService mUserService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="AccountController" /> class.
        /// </summary>
        /// <param name="formsAuth">The forms authentication.</param>
        /// <param name="userService">The user service.</param>
        public AccountController(IFormsAuthentication formsAuth, IUserService userService)
        {
            this.mFormsAuth = formsAuth;
            this.mUserService = userService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     LogOn for login details
        /// </summary>
        /// <param name="logonModel">Logon model for username</param>
        /// <param name="returnUrl">Return url to pass to related page</param>
        /// <returns>the related controller method</returns>
        [HttpPost]
        public ActionResult LogOn(LogOnModel logonModel, string returnUrl)
        {
            this.Logger.Debug(string.Format("Start LogOn : User {0}", logonModel.UserName));
            string loginFailureReason;
            this.TempData["LoginError"] = null;

            if (!this.ModelState.IsValid)
            {
                logonModel.Password = null;
                logonModel.UserName = null;
                loginFailureReason = "Login form is invalid.";
            }
            else
            {
                try
                {
                    User user = this.mUserService.Login(logonModel.UserName, logonModel.Password, out loginFailureReason);
                    if (user == null)
                    {
                        this.Logger.WarnFormat("User {0} attempted login but password validation failed", logonModel.UserName);
                        loginFailureReason = "The username or password is incorrect.";
                    }
                    else
                    {
                        this.mFormsAuth.SignIn(user, logonModel.RememberMe);
                        this.mUserService.SetToken(logonModel.UserName, logonModel.Password, logonModel.RememberMe);
                        UserAudit userAuditData = new UserAudit
                        {
                            EcolabAccountNumber = user.EcolabAccountNumber,
                            UserId = user.UserId,
                            UserActivity = 4,
                            IPAddress = GetIpAddress()
                        };
                        this.mUserService.SaveUserAudit(userAuditData);
						HttpContext.Response.Cookies.Add(new HttpCookie("showMissingFieldsAuto", "True") { Expires = DateTime.Now.AddMinutes(30) });						
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog.GetDefault(null).Log(new Error(ex)
                    {
                        Message = ex.Message
                    });
                    loginFailureReason = "Unexpected error occurred. Please try again.";
                }
                finally
                {
                    this.Logger.Debug(string.Format("End LogOn : User {0}", logonModel.UserName));
                }
            }

            if (!string.IsNullOrEmpty(loginFailureReason))
            {
                this.TempData["LoginError"] = loginFailureReason;
            }

            if (this.Url.IsLocalUrl(returnUrl))
            {
                return this.Redirect(returnUrl);
            }
            return this.RedirectToAction("Index", "Home");
        }

        /// <summary>
        ///     Logs the out.
        /// </summary>
        /// <returns>LogOut View</returns>
        public ActionResult LogOut()
        {
            IPrincipal context = System.Web.HttpContext.Current.User;
            if (context != null && context.Identity.Name != string.Empty)
            {
                CustomPrincipal currentUser = (CustomPrincipal) context;
                UserAudit userAuditData = new UserAudit
                {
                    EcolabAccountNumber = currentUser.EcolabAccountNumber,
                    UserId = currentUser.UserId,
                    UserActivity = 5,
                    IPAddress = GetIpAddress()
                };
                this.mUserService.SaveUserAudit(userAuditData);
            }

            this.mUserService.Logout();
            this.mFormsAuth.SignOut();
            return this.RedirectToAction("Index", "Home");
        }
        /// <summary>
        /// Gets IP Address
        /// </summary>
        /// <returns>Returns IP address</returns>
        private static string GetIpAddress()
        {
            HttpContext context = System.Web.HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}