﻿// -----------------------------------------------------------------------
// <copyright file="ContactController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ContactController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     class for ContactController
    /// </summary>
    [Authorize]
    public class ContactController : BaseController
    {
        /// <summary>
        ///     Plant Contact Service
        /// </summary>
        private readonly IPlantContactService plantContactService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plantContactService">Plant Contact Service</param>
        public ContactController(IUserService userService, IPlantService plantService, IPlantContactService plantContactService) : base(userService, plantService)
        {
            this.plantContactService = plantContactService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}