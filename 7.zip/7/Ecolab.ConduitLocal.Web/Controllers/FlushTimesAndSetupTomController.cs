﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTomController.cs" company="Ecolab">
// This web controller is for compartments for tunnels.
// </copyright>
// <summary>This controller is for get or set the compartment controller.</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Ecolab.ConduitLocal.Web.Models.Washers.Tunnel;
using Ecolab.Models.Washers;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services.Interfaces;
using Ecolab.Services.Interfaces.Washers;
using Ecolab.Services.Interfaces.Washers.Tunnel;

namespace Ecolab.ConduitLocal.Web.Controllers
{
    /// <summary>
    ///     Compartment controller class.
    /// </summary>
    public class FlushTimesAndSetupTomController : BaseController
    {

        /// <summary>
        ///     The Tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServicesInstance;
        /// <summary>
        ///  Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        /// <param name="tunnelGeneralServices">The Tunnel General Service</param>
        public FlushTimesAndSetupTomController(IUserService userService, IPlantService plantService, ITunnelGeneralServices tunnelGeneralServices, IWasherServices washerServices)
            : base(userService, plantService)
        {
            tunnelGeneralServicesInstance = tunnelGeneralServices;
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     This action method is for loading the tunnel compartment view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string machineId = this.Request.QueryString.Get("machineId");
            string groupId = this.Request.QueryString.Get("groupId");
            string groupTypeId = this.Request.QueryString.Get("groupTypeId");
            string compartments = this.Request.QueryString.Get("Compartments");
            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdtail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(groupId));
            int plantWasherNumber = 0;
            foreach (var washer in washerdtail)
            {
                if (washer.Id == int.Parse(machineId))
                    plantWasherNumber = washer.WasherNumber;
            }
            this.GetPageSetupViewBags();
            if (!string.IsNullOrWhiteSpace(machineId) && !string.IsNullOrWhiteSpace(groupId) && !string.IsNullOrWhiteSpace(groupTypeId))
            {
                TunnelGeneralModel tunnelData = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServicesInstance.GetTunnelData(Convert.ToInt32(machineId), Convert.ToInt32(groupId), this.EcolabAccountNumber));
                this.ViewBag.TunnelId = tunnelData.Id;
                this.ViewBag.WasherGroupId = tunnelData.WasherGroupId;
                this.ViewBag.WasherGroupTypeId = groupTypeId;
                this.ViewBag.ControllerId = tunnelData.ControllerId;
                this.ViewBag.Compartments = tunnelData.NoofCompartments;
                this.ViewBag.ControllerTypeId = tunnelData.ControllerTypeId;
                this.ViewBag.ControllerModelId = tunnelData.ControllerModelId;
                this.ViewBag.PlantWasherNumber = plantWasherNumber;
            }

            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}