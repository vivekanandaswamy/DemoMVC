﻿// -----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CustomerController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class CustomerController : BaseController
    {
        /// <summary>
        ///     plant Custumer Service
        /// </summary>
        private readonly IPlantCustomerService plantCustService;

        /// <summary>
        ///     Customer Controller
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plantCustService">Plant Customer Service</param>
        public CustomerController(IUserService userService, IPlantService plantService, IPlantCustomerService plantCustService) : base(userService, plantService)
        {
            this.plantCustService = plantCustService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}