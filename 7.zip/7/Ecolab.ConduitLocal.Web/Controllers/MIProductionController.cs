﻿// -----------------------------------------------------------------------
// <copyright file="MIProductionController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MIProductionController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.ConduitLocal.Web.Models.ManualInput;
    using Ecolab.ConduitLocal.Web.Models.ManualInput.Production;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup;
    using Ecolab.Models.ManualInput;
    using Ecolab.Models.ManualInput.Production;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services.Interfaces.ManualInput;
    using Services.Interfaces;

    [Authorize]
    public class MiProductionController : BaseController
    {
        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualProductionDataEntryService manualProductionService;

        /// <summary>
        ///     MIProductionController constructor
        /// </summary>
        /// <param name="userService">userService</param>
        /// <param name="plantService">plantService</param>
        public MiProductionController(IUserService userService, IPlantService plantService, IManualProductionDataEntryService manualProductionService)
            : base(userService, plantService)
        {
            this.manualProductionService = manualProductionService;
        }

        /// <summary>
        ///     Index
        /// </summary>
        /// <returns>Action Result</returns>
        public ActionResult Index()
        {
            ManualProductionViewModel productionModel = new ManualProductionViewModel();           
            productionModel = FetchWasherGroupsList();
            productionModel.RegionId = Convert.ToInt32(GetCurrentUser().RegionId.ToString());
            this.GetPageSetupViewBags();
            return this.View(productionModel);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private ManualProductionViewModel FetchWasherGroupsList()
        {
            ManualProductionViewModel productionModel = new ManualProductionViewModel();
            List<GroupTypeModel> washerGroups = this.FetchWasherGroups(this.EcolabAccountNumber);
            string groupIds = string.Join(",", washerGroups.Select(x => x.GroupTypeId));

            productionModel = LoadDefaultData(groupIds);
            productionModel.WasherGroups = washerGroups;
            productionModel.WasherGroupId = groupIds.Split(',');

            return productionModel;
        }

        /// <summary>
        /// LoadDefaultData
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>
        /// manual batch view model
        /// </returns>
        private ManualProductionViewModel LoadDefaultData(string groupIds)
        {
            int rowsPerPage = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            int pageNumber = 0;

            if (string.IsNullOrWhiteSpace(groupIds))
            {
                groupIds = null;
            }

            ManualProductionViewModel batchModel = new ManualProductionViewModel();
            batchModel.RowsCount = rowsPerPage;
            batchModel.Washers = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.manualProductionService.FetchWashersByGroupId(groupIds, this.EcolabAccountNumber));
			var firstWasher = batchModel.Washers.DefaultIfEmpty(new MachineSetupModel()).FirstOrDefault();
            string firstWasherGroupId = firstWasher.MachineID.ToString();
            List<WashProgramSetupModel> formulaList = FetchWasherGroupFormulas(firstWasherGroupId);
            batchModel.Formulas = formulaList;
            int formulaId = batchModel.ProgramId;
            batchModel.WasherId = firstWasher.MachineID;
            List<ManualProductionModel> productionList = FetchProductionData(groupIds, batchModel.WasherId, formulaId, DateTime.Now.Date.ToUniversalTime(), this.EcolabAccountNumber, pageNumber, rowsPerPage);

            if (productionList.Count > 0)
            {
                batchModel.ProductionList = productionList;
                batchModel.TotalRows = productionList[0].TotalRows;
            }

            batchModel.StartDate = DateTime.Today;
            batchModel.StartDateText = Convert.ToString(DateTime.Now);
            batchModel.ProductionDate = DateTime.Today;
            batchModel.ProductionDateText = Convert.ToString(DateTime.Today);

            batchModel.StartDate = DateTime.Now;
            return batchModel;
        }

        /// <summary>
        /// FetchWashers
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>list of washers</returns>
        [HttpPost]
        public JsonResult FetchWashers(string groupIds)
        {
            ManualProductionViewModel batchModel = LoadDefaultData(groupIds);
            return new JsonResult { Data = batchModel };
        }

        /// <summary>
        /// FetchWasherGroupFormulas
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>list of washer group formula</returns>
        public List<WashProgramSetupModel> FetchWasherGroupFormulas(string groupIds)
        {
            ManualProductionViewModel batchModel = new ManualProductionViewModel();
            batchModel.Formulas = Mapper.Map<List<WashProgramSetup>, List<WashProgramSetupModel>>(this.manualProductionService.FetchFormulasByGroupId(groupIds, this.EcolabAccountNumber));
            return batchModel.Formulas;
        }

        /// <summary>
        /// FetchBatchData
        /// </summary>
        /// <param name="groupId">groupId</param>
        /// <param name="washerId">washerId</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="startDate">startDate</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="pageNumber">The page number.</param>
        /// <param name="rowsPerPage">The rows per page.</param>
        /// <returns>
        /// list of manual batch data
        /// </returns>
        public List<ManualProductionModel> FetchProductionData(string groupId, int washerId, int formulaId, DateTime startDate, string ecolabAccountNumber, int pageNumber, int rowsPerPage)
        {
            return (Mapper.Map<List<Ecolab.Models.ManualInput.Production.ManualProduction>, List<Models.ManualInput.Production.ManualProductionModel>>
                (this.manualProductionService.FetchProductionData(groupId, washerId, formulaId, startDate, ecolabAccountNumber, pageNumber, rowsPerPage)));
        }

        /// <summary>
        /// FetchBatchData
        /// </summary>
        /// <param name="manualProductionViewModel">The manual production view model.</param>
        /// <returns>
        /// list of manual batch data
        /// </returns>
        [HttpPost]
        public ActionResult FetchProductionData(ManualProductionViewModel manualProductionViewModel)
        {
            if (manualProductionViewModel.ProductionDataAddMode)
            {
                SaveManualProduction(manualProductionViewModel);
            }
            List<ManualProductionModel> productionData = new List<ManualProductionModel>();
            int rowsPerPage = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            manualProductionViewModel.RowsCount = rowsPerPage;

            if (manualProductionViewModel.WasherGroupId != null)
            {
                string groupId = string.Join(",", manualProductionViewModel.WasherGroupId);
                DateTime date = DateTime.Parse(manualProductionViewModel.StartDateText) == DateTime.MinValue ? DateTime.Now.ToUniversalTime() : DateTime.Parse(manualProductionViewModel.StartDateText);

                List<ManualProductionModel> productionList = Mapper.Map<List<Ecolab.Models.ManualInput.Production.ManualProduction>, List<Models.ManualInput.Production.ManualProductionModel>>
                    (this.manualProductionService.FetchProductionData(groupId,
                    manualProductionViewModel.WasherId,
                    manualProductionViewModel.ProgramId,
                   date.ToUniversalTime(),
                   this.EcolabAccountNumber,
                    manualProductionViewModel.PageNumber,
                    rowsPerPage));

                if (productionList.Count > 0)
                {
                    manualProductionViewModel.ProductionList = productionList;
                    manualProductionViewModel.TotalRows = productionList[0].TotalRows;
                    manualProductionViewModel.RegionId = Convert.ToInt32(GetCurrentUser().RegionId.ToString());
                }
            }

            return PartialView("_ManualProduction", manualProductionViewModel);

        }

        /// <summary>
        ///     Method to return list of washer groups
        /// </summary>
        /// <returns>List of WasherGroups</returns>
        public List<GroupTypeModel> FetchWasherGroups(string ecolabAccountNumber)
        {
            return Mapper.Map<List<GroupType>, List<GroupTypeModel>>(this.manualProductionService.FetchWasherGroups(ecolabAccountNumber));
        }

        /// <summary>
        /// Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="groupIds">The group ids.</param>
        /// <returns>
        /// List of Formulas
        /// </returns>
        [HttpPost]
        public List<MachineSetupModel> FetchMiWasherDetails(string groupIds)
        {
            List<MachineSetup> washers = new List<MachineSetup>();
            washers.AddRange(this.manualProductionService.FetchWashersByGroupId(groupIds, this.EcolabAccountNumber));
            return Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(washers);
        }

        /// <summary>
        /// Method to get all the washers assosiated to the washer group
        /// </summary>
        /// <param name="groupIds">The group ids.</param>
        /// <returns>
        /// List of Washers
        /// </returns>
        [HttpPost]
        public JsonResult FetchMiFormulaDetails(string groupIds)
        {
            List<WashProgramSetup> washerGroupFormula = new List<WashProgramSetup>();
            washerGroupFormula.AddRange(this.manualProductionService.FetchFormulasByGroupId(groupIds, this.EcolabAccountNumber));
            return this.Json(Mapper.Map<List<WashProgramSetup>, List<WashProgramSetupModel>>(washerGroupFormula));
        }

        /// <summary>
        /// Method to save ManualInputProduction data
        /// </summary>
        /// <param name="manualProductionData">The manual production data.</param>
        /// <returns>
        /// status wheather saved or not
        /// </returns>
        public string SaveManualProduction(ManualProductionViewModel manualProductionData)
        {
            string result = string.Empty;
            int userId = this.GetCurrentUser().UserId;
            int productionId = 0;            
            ManualProduction manualProductionModelService = new ManualProduction
            {
                WasherId = manualProductionData.WasherId,
                FormulaId = manualProductionData.ProgramIdToAdd,               
                RecordedDate = DateTime.Parse(manualProductionData.ProductionDateText) == DateTime.MinValue ? DateTime.Now.ToUniversalTime() : DateTime.Parse(manualProductionData.ProductionDateText + ' ' + DateTime.Now.ToString("h:mm:ss tt")).ToUniversalTime(),                
                Value = manualProductionData.ProductionValueToAdd,
				EcolabAccountNumber = this.EcolabAccountNumber
            };

            result = this.manualProductionService.SaveManualProduction(manualProductionModelService, this.EcolabAccountNumber, userId, out productionId);
			manualProductionModelService.Id = productionId;
			ManualProductionSyncContainer productionContainer = new ManualProductionSyncContainer();
			productionContainer.ManualProductionList  = new List<ManualProduction>();
			productionContainer.ManualProductionList.Add(manualProductionModelService);
			Push.PushToQueue(productionContainer, userId, manualProductionModelService.Id, (int)TcdAdminMessageTypes.TcdAddManualInputProduction, this.EcolabAccountNumber);
            manualProductionData.ErrorMessage = "Added Successfully.";
            // return RedirectToAction("Index");
            return result;
        }

        /// <summary>
        ///     Method to delete ManualInputProduction data
        /// </summary>
        /// <param name="manualProductionViewModel">Manual Production View Model</param>
        /// <returns>status wheather deleted or not</returns>
        [HttpPost]
        public ActionResult DeleteManualProduction(ManualProductionViewModel manualProductionViewModel)
        {
            int rowsPerPage = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            manualProductionViewModel.RowsCount = rowsPerPage;
            manualProductionViewModel.RowsCount = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            int userId = this.GetCurrentUser().UserId;
            string result = string.Empty;
            if (manualProductionViewModel.ProductionIdToDelete == 0)
            {
                List<Ecolab.Models.ManualInput.Production.ManualProduction> productionDataList = Mapper.Map<List<ManualProductionModel>, List<Ecolab.Models.ManualInput.Production.ManualProduction>>(manualProductionViewModel.ProductionList);
                result = this.manualProductionService.UpdateManualProductionData(productionDataList, this.EcolabAccountNumber, userId);
				ManualProductionSyncContainer productionContainer = new ManualProductionSyncContainer();
				productionContainer.ManualProductionList = new List<ManualProduction>();
				productionContainer.ManualProductionList = productionDataList;
				productionContainer.ManualProductionList.ForEach(t => t.EcolabAccountNumber = this.EcolabAccountNumber);
				Push.PushToQueue(productionContainer, userId, productionDataList.FirstOrDefault().Id, (int)TcdAdminMessageTypes.TcdUpdateManualInputProduction, this.EcolabAccountNumber);
                manualProductionViewModel.ErrorMessage = "Successfully updated.";
            }
            else
            {
                result = this.manualProductionService.DeleteManualProduction(manualProductionViewModel.ProductionIdToDelete, this.EcolabAccountNumber, userId);
				ManualProduction manualProduction = new ManualProduction();
				manualProduction.ProductionId = manualProductionViewModel.ProductionIdToDelete;
				manualProduction.EcolabAccountNumber = this.EcolabAccountNumber;
				ManualProductionSyncContainer productionContainer = new ManualProductionSyncContainer();
				productionContainer.ManualProductionList = new List<ManualProduction>();
				productionContainer.ManualProductionList.Add(manualProduction);
				Push.PushToQueue(productionContainer, userId, manualProduction.ProductionId, (int)TcdAdminMessageTypes.TcdDeleteManualInputProduction, this.EcolabAccountNumber);
				manualProductionViewModel = FetchWasherGroupsList();
                manualProductionViewModel.ErrorMessage = "Deleted Successfully.";
            }

            return PartialView("_ManualProductionMessage", manualProductionViewModel);
        }
    }
}