﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The UserManagementController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class UserManagementController : BaseController
    {
        public UserManagementController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}