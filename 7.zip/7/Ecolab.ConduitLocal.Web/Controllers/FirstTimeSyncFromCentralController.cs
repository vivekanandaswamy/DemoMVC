﻿// -----------------------------------------------------------------------
// <copyright file="FirstTimeSyncFromCentralController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FirstTimeSyncFromCentralController </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.PushHandler;

namespace Ecolab.ConduitLocal.Web.Controllers
{
    public class FirstTimeSyncFromCentralController : Controller
    {
        //
        // GET: /FirstTimeSyncFromCentral/
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Firsts the time synchronize.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns></returns>
        public ActionResult FirstTimeSync(string ecolabAccountNumber)
        {
            int errorCode = 0;
            for (int iterator = 1; iterator < 15; iterator++)
            {
                errorCode = (int)Push.FetchCentralData(ecolabAccountNumber, (int)TcdAdminMessageTypes.TcdGetPlantEntities, string.Empty, iterator);
            }
            return RedirectToAction("Index", "Home");
        }
	}
}