﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtilityController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualUtilityController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Manual Utility Controller
    /// </summary>
    [Authorize]
    public class ManualUtilityController : BaseController
    {
        /// <summary>
        ///     Manual Utility Controller
        /// </summary>
        /// <param name="userService">user Service</param>
        /// <param name="plantService">plant Service</param>
        public ManualUtilityController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Index
        /// </summary>
        /// <returns>Returns ActionResult</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}