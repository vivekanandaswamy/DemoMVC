﻿// -----------------------------------------------------------------------
// <copyright file="TrendingChartController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Trending Chart Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     class Trending Chart Controller
    /// </summary>
    [Authorize]
    public class TrendingChartController : BaseController
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private readonly ITrendingChartService trendingChartService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="TrendingChartController" /> class.
        /// </summary>
        /// <param name="trendingChartService">trending chart service.</param>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">plant service.</param>
        public TrendingChartController(ITrendingChartService trendingChartService, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.trendingChartService = trendingChartService;
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Returns the related view</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.ServerTimeZoneOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).TotalHours;

            return this.View();
        }
    }
}