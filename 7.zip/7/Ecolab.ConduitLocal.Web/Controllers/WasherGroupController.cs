﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupController.cs" company="Ecolab">
// This web controller is for washer group.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.WasherGroup;

    /// <summary>
    ///     This is washer group controller which inherits from base controller for authentication purpose.
    /// </summary>
    public class WasherGroupController : BaseController
    {
        /// <summary>
        ///     Interface for washer group in service layer as IWasherGroupService
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherGroupController" /> class.
        /// </summary>
        /// <param name="washerGroupService">The interface for WasherGroup.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public WasherGroupController(IWasherGroupService washerGroupService, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.washerGroupService = washerGroupService;
        }

        /// <summary>
        ///     This action method is for loading the washer group view.
        /// </summary>
        /// <returns>Washer group view.</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}