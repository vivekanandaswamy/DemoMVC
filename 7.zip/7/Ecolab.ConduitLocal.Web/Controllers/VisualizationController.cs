﻿// -----------------------------------------------------------------------
// <copyright file="VisualizationController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Visualization Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Configuration;
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Visualization Controller
    /// </summary>
    public class VisualizationController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="VisualizationController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        public VisualizationController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <param name="typeId"></param>
        /// <returns>Returns the related view</returns>
        public ActionResult Index(int typeId)
        {
            this.GetPageSetupViewBags();
            this.ViewBag.Red = (new AppSettingsReader()).GetValue("red", typeof(string)).ToString();
            this.ViewBag.Yellow = (new AppSettingsReader()).GetValue("yellow", typeof(string)).ToString();
            this.ViewBag.Green = (new AppSettingsReader()).GetValue("green", typeof(string)).ToString();
            this.ViewBag.ServerTimeZoneOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).TotalHours;

            if(typeId == 1)
            {
                return this.View("ConventionalWasher");
            }
            return this.View();
        }
    }
}