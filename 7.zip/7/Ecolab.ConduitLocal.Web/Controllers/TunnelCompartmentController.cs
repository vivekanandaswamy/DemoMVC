﻿// -----------------------------------------------------------------------
// <copyright file="TunnelCompartmentController.cs" company="Ecolab">
// This web controller is for compartments for tunnels.
// </copyright>
// <summary>This controller is for get or set the compartment controller.</summary>
// -----------------------------------------------------------------------
namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Models.Washers.Tunnel;
    using Ecolab.Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.Washers;
    using Ecolab.Models.Washers.Tunnel;
    using Services.Interfaces.Washers.Tunnel;

    /// <summary>
    ///     Compartment controller class.
    /// </summary>
    public class TunnelCompartmentController : BaseController
    {
        /// <summary>
        ///     Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelCompartmentController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washer service.</param>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public TunnelCompartmentController(IWasherServices washerServices, ITunnelGeneralServices tunnelGeneralServices, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.washerServices = washerServices;
            this.tunnelGeneralServices = tunnelGeneralServices;

        }

        /// <summary>
        ///     This action method is for loading the tunnel compartment view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string tunnelId = this.Request.QueryString.Get("TunnelId");
            string washerGroupId = this.Request.QueryString.Get("WasherGroupId");
            string controllerId = this.Request.QueryString.Get("ControllerId");
            string compartments = this.Request.QueryString.Get("Compartments");
            string controllerTypeId = this.Request.QueryString.Get("ControllerTypeId");
            string controllerModelId = this.Request.QueryString.Get("ControllerModelId");

            int washerGroupTypeId = 2;
            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdetail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(washerGroupId));
            int plantWasherNumber = 0;
            foreach (var washer in washerdetail)
            {
                if (washer.Id == int.Parse(tunnelId))
                    plantWasherNumber = washer.WasherNumber;
            }
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(int.Parse(tunnelId), int.Parse(washerGroupId), ecolabAccountNumber));
            string washerName = tunneldata.Name;
            this.GetPageSetupViewBags();
            if (!(string.IsNullOrEmpty(tunnelId) && string.IsNullOrEmpty(controllerTypeId) && string.IsNullOrEmpty(washerGroupId) && string.IsNullOrEmpty(controllerId) && string.IsNullOrEmpty(compartments)))
            {
                this.ViewBag.TunnelId = tunnelId;
                this.ViewBag.WasherGroupId = washerGroupId;
                this.ViewBag.WasherGroupTypeId = washerGroupTypeId;
                this.ViewBag.ControllerId = controllerId;
                this.ViewBag.Compartments = compartments;
                this.ViewBag.ControllerTypeId = controllerTypeId;
                this.ViewBag.ControllerModelId = controllerModelId;
                this.ViewBag.PlantWasherNumber = plantWasherNumber;
                this.ViewBag.WasherName = washerName;
            }

            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}