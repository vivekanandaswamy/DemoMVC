﻿// -----------------------------------------------------------------------
// <copyright file="HomeController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Home Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
	using System.Collections.Generic;
	using System.Configuration;
	using System.Web.Mvc;
	using Services.Interfaces;
    using Services.Interfaces.Plc;
    using Services.Plc;
    using Ecolab.ConduitLocal.Web.Models.Common;

    /// <summary>
    ///     class HomeController
    /// </summary>
    [Authorize]
    public class HomeController : BaseController
    {
		/// <summary>
		/// Gets or Sets the Plant Service object
		/// </summary>
		IPlantService PlantServiceInstance { get; set; }

        /// <summary>
		/// Gets or Sets the Plant Service object
		/// </summary>
		IPlcService PlcService { get; set; }

        /// <summary>
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        public HomeController(IUserService userService, IPlantService plantService, IPlcService plcService) : base(userService, plantService)
        {
			this.PlantServiceInstance = plantService;
            this.PlcService = plcService;
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <param name="returnUrl">The url to return</param>
        /// <returns>Redirects to related view</returns>
        [AllowAnonymous]
        public ActionResult Index(string returnUrl)
        {
            if (PlantService != null && PlantService.GetPlantDetails() == null)
            {
                return RedirectToAction("Index", "FirstTimeSyncFromCentral");
            }
            if(this.TempData["LoginError"] != null)
            {
                this.ModelState.AddModelError(string.Empty, this.TempData["LoginError"].ToString());
            }

            if(this.Request.IsAuthenticated)
            {
               ViewBag.RegionId = this.GetPlantDetails().RegionId;
                this.GetPageSetupViewBags();
            }
            this.ViewBag.VisualizationUrl = (new AppSettingsReader()).GetValue("VisualizationUrl", typeof(string)).ToString();
            return this.View();
        }
		/// <summary>
		///  Fetches the Missing Fields
		/// </summary>
		/// <returns> The List of MissingFieldsModel</returns>
		[HttpPost]
		public ActionResult FetchMissingFields()
		{
            List<Models.MissingFieldsModel> missingFields = new List<Models.MissingFieldsModel>();
            try
            { 	            
				missingFields = AutoMapper.Mapper.Map<List<Ecolab.Models.MissingFields>, List<Models.MissingFieldsModel>>(this.PlantServiceInstance.FetchMissingFields(this.EcolabAccountNumber));
			}
			catch(System.Exception)
			{
				missingFields = new List<Models.MissingFieldsModel>();
			}
			return this.PartialView("_MissingFields", missingFields);
		}
        /// <summary>
		/// Fetches the Plc Discrepancy Data for all entities
		/// </summary>
		/// <returns>The List of PLCDiscrepancyModel</returns>
		[HttpPost]
        public ActionResult FetchPlcDiscrepancyData()
        {
            IEnumerable<Models.Common.PLCDiscrepancyModel> plcDiscrepancyData;
            try
            {
                plcDiscrepancyData = AutoMapper.Mapper.Map<IEnumerable<Ecolab.Models.Common.PLCDiscrepancyModel>, IEnumerable<Models.Common.PLCDiscrepancyModel>>(this.PlcService.FetchPlcDiscrepancyData());                
            }
            catch (System.Exception)
            {
                plcDiscrepancyData = new List<Models.Common.PLCDiscrepancyModel>();
            }
            return this.PartialView("_PlcDiscrepancyData", plcDiscrepancyData);
        }
        [HttpGet]
        public ActionResult Images()
        {
            return null;
        }

        [HttpGet]
        public ActionResult Visualization()
        {
            return null;
        }
    }
}