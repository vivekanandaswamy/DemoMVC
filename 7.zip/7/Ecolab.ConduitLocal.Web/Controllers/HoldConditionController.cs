﻿// -----------------------------------------------------------------------
// <copyright file="HoldConditionController.cs" company="Ecolab">
// This web controller is for HoldCondition.
// </copyright>
// <summary>The HoldCondition is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Mvc;
    using Ecolab.Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Washers;
    using Controller = Ecolab.Models.ControllerSetup.Controller;

    public class HoldConditionController : BaseController
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="HoldConditionController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washers.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public HoldConditionController(IWasherServices washerServices, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="HoldConditionController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washers.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        /// <param name="controllerSetupService">The interface for controllersetup service.</param>
        public HoldConditionController(IWasherServices washerServices, IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService) : base(userService, plantService)
        {
            this.washerServices = washerServices;
            this.controllerSetupService = controllerSetupService;
        }

        /// <summary>
        ///     This action method is for loading the HoldCondition view.
        /// </summary>
        /// <returns>HoldCondition view.</returns>
        public ActionResult Index()
        {
            string controllerModelId = this.Request.QueryString.Get("ControllerModelId");
            string machineNumber = this.Request.QueryString.Get("MachineNumber");
            string controllerTypelId = this.Request.QueryString.Get("ControllerTypelId");
            string washergroupId = this.Request.QueryString.Get("WashergroupId");
            string noofCompartments = this.Request.QueryString.Get("NoofCompartments");
            string tunnelId = this.Request.QueryString.Get("TunnelId");
            string washergroupTypeId = this.Request.QueryString.Get("WashergroupTypeId");
            string controllerId = this.Request.QueryString.Get("ControllerId");
            string tabToSelect = this.Request.QueryString.Get("TabToSelect");

            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdetail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(washergroupId));
            int plantWasherNumber = 0;
            string washerName = string.Empty;
            foreach (var washer in washerdetail)
            {
                if (washer.Id == int.Parse(tunnelId))
                {
                    plantWasherNumber = washer.WasherNumber;
                    washerName = washer.WasherName;
                }
            }

            int ctlrId;
            if (int.TryParse(controllerId, out ctlrId))
            {
                bool controlTunnel = washergroupTypeId == "1" ? false : true;
                foreach (Controller item in this.controllerSetupService.GetControllerDetails(this.EcolabAccountNumber, controlTunnel).Where(_ => _.ControllerId == ctlrId))
                {
                    controllerModelId = Convert.ToString(item.ControllerModelId);
                    controllerTypelId = Convert.ToString(item.ControllerTypeId);
                }
            }
            this.ViewBag.ControllerModelId = controllerModelId;
            this.ViewBag.MachineNumber = machineNumber;
            this.ViewBag.ControllerTypeId = controllerTypelId;
            this.ViewBag.WashergroupId = washergroupId;
            this.ViewBag.NoofCompartments = noofCompartments;
            this.ViewBag.TunnelId = tunnelId;
            this.ViewBag.WashergroupTypeId = washergroupTypeId;
            this.ViewBag.ControllerId = controllerId;
            this.ViewBag.TabToSelect = tabToSelect;
            this.ViewBag.PlantWasherNumber = plantWasherNumber;
            this.ViewBag.WasherName = washerName;
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}