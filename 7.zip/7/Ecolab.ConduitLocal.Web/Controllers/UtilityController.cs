﻿// -----------------------------------------------------------------------
// <copyright file="UtilityController.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Utility Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    /// <summary>
    ///     Class UtilityController
    /// </summary>
    [Authorize]
    public class UtilityController : BaseController
    {
        /// <summary>
        ///     Utility Service
        /// </summary>
        private readonly IUtilityService utilityService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="UtilityController" /> class.
        /// </summary>
        /// <param name="userService"> the user service</param>
        /// <param name="plantService">the plant service</param>
        /// <param name="utilityService">the utility service</param>
        public UtilityController(IUserService userService, IPlantService plantService, IUtilityService utilityService) : base(userService, plantService)
        {
            this.utilityService = utilityService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}