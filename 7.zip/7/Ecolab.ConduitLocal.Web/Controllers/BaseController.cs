﻿// -----------------------------------------------------------------------
// <copyright file="BaseController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Base Controller Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Globalization;
    using System.Linq;
    using System.Security.Principal;
    using System.Threading;
    using System.Web.Mvc;
    using Ecolab.Models;
    using Entities;
    using Models;
    using Services;
    using Services.Interfaces;
    using EntityConverter = Mapper.EntityConverter;
    using Plant = Ecolab.Models.Plant;
    using UserRoles = Ecolab.Models.UserRoles;

    /// <summary>
    ///     Class BaseController
    /// </summary>
    public class BaseController : Controller
    {
        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantService PlantService;

        /// <summary>
        ///     User Service
        /// </summary>
        /// `
        protected readonly IUserService UserService;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        private string ecolabAccountNumber;

        /// <summary>
        ///     Initializes a new instance of the <see cref="BaseController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public BaseController(IUserService userService, IPlantService plantService)
        {
            this.UserService = userService;
            this.PlantService = plantService;
        }

        /// <summary>
        ///     Gets Ecolab Account Number
        /// </summary>
        protected string EcolabAccountNumber
        {
            get { return this.ecolabAccountNumber ?? (this.ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber); }
        }

        /// <summary>
        ///     Get Current User logged in
        /// </summary>
        /// <returns>The user details</returns>
        protected User GetCurrentUser()
        {
            User user = null;
            IPrincipal context = System.Web.HttpContext.Current.User;
            if (context != null && context.Identity.Name != string.Empty)
            {
                CustomPrincipal currentUser = (CustomPrincipal) context;
                user = new User
                {
                    Id = currentUser.UserId,
                    UserId = currentUser.UserId,
                    Name = currentUser.UserName,
                    EcolabAccountNumber = currentUser.EcolabAccountNumber,
                    RegionId = currentUser.RegionId,
                    LanguageId = PlantService.GetPlantDetails(currentUser.UserId).LanguageId ,
                    Locale = currentUser.Locale
                };
                string[] roleIds = currentUser.UserRoleIds.Split(',');
                string[] rolesList = currentUser.UserRoles.Split(',');
                var userRolesList = new List<UserRoles>();
                for (int i = 0; i < rolesList.Length; i++)
                {
                    if (!string.IsNullOrEmpty(roleIds[i]))
                    {
                        userRolesList.Add(new UserRoles
                        {
                            Code = rolesList[i], 
                            RoleId = Convert.ToInt32(roleIds[i])
                        });
                    }
                }
                user.Roles = userRolesList;
            }
            return user;
        }

        /// <summary>
        ///     Get Plant Details
        /// </summary>
        /// <returns>Plant Model Object</returns>
        protected PlantModel GetPlantDetails()
        {
            Plant plant = this.PlantService.GetPlantDetails(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId);
            return EntityConverter.ConvertToWebModel(plant);
        }

        /// <summary>
        ///     Get Page Setup ViewBags
        /// </summary>
        protected void GetPageSetupViewBags()
        {
            if (this.Request.IsAuthenticated)
            {
                User user = this.GetCurrentUser();
                PlantModel plantDetails = this.GetPlantDetails();
                string roles = string.Join(",", user.Roles.Select(i => i.Code).ToArray());
                if (!string.IsNullOrEmpty(roles))
                {
                    List<MenuItem> menuItems = this.UserService.GetMenuSectionsByRoles(roles);
                    this.ViewBag.MenuItems = menuItems;
                    this.ViewBag.UserId = user.UserId;
                    this.ViewBag.Roles = roles;
                    this.ViewBag.Locale = user.Locale;
                    this.ViewBag.MaxLevel = user.Roles.Select(i => i.RoleId).Max();
                    this.ViewBag.RegionId = user.RegionId;
                    this.ViewBag.EcolabAccountNumber = !string.IsNullOrEmpty(this.Request.QueryString["PlantId"]) ? this.Request.QueryString["PlantId"] : user.EcolabAccountNumber;
                    this.ViewBag.AllowManualRewash = plantDetails.AllowManualRewash;
                    this.ViewBag.PlantName = plantDetails.Name;
                    this.ViewBag.PlantLogo = plantDetails.Logo;
                    this.ViewBag.UserName = user.Name;
                    this.ViewBag.PlantChainId = plantDetails.PlantChainId;
                    this.ViewBag.MaxNoOfRecordsPerPage = ConfigurationManager.AppSettings["MaxNoOfRecordsPerPage"];
                }
            }
        }

        /// <summary>
        ///     Called before the action method is invoked.
        /// </summary>
        /// <param name="filterContext">Information about the current request and action.</param>
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (this.GetCurrentUser() != null)
            {
                User user = this.GetCurrentUser();
                if (user.Locale != null)
                {
                    Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(user.Locale);
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(user.Locale);
                }
            }
        }
    }
}