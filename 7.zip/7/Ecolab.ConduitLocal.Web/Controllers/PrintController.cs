﻿// -----------------------------------------------------------------------
// <copyright file="PrintController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Print Controller </summary>
// -----------------------------------------------------------------------

using Ecolab.Dcs.Entities;

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Api;
    using Api.Washers.Conventional;
    using Api.Washers.Tunnel;
    using Ecolab.Models;
    using Models;
    using Models.ControllerSetup;
    using Models.PdfGeneration;
    using Models.WasherGroup;
    using Models.Washers;
    using Models.Washers.Conventional;
    using Models.Washers.Tunnel;
    using Newtonsoft.Json;
    using Services;
    using Services.ControllerSetup;
    using Services.ControllerSetup.Pumps;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.PlantSetup.Dryer;
    using Services.Interfaces.PlantSetup.Finnisher;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.Interfaces.Plc;
    using Services.Interfaces.StorageTanks;
    using Services.Interfaces.Visualization.Monitor;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Conventional;
    using Services.Interfaces.Washers.Tunnel;
    using Services.PlantSetup;
    using Services.PlantSetup.Dryer;
    using Services.PlantSetup.Finnisher;
    using Services.PlantSetup.ShiftLabor;
    using Services.Plc;
    using Services.StorageTanks;
    using Services.Visualization.Monitor;
    using Services.WasherGroup;
    using Services.Washers;
    using Services.Washers.conventional;
    using Services.Washers.Tunnel;
    using Utilities;

    /// <summary>
    ///     Class Print Controller
    /// </summary>
    public class PrintController : BaseController
    {
        /// <summary>
        ///     Locale Controller
        /// </summary>
        private LocaleController locale;

        /// <summary>
        ///     Parameter Plant Location
        /// </summary>
        private string plantLocation;

        /// <summary>
        ///     Parameter Plant Name
        /// </summary>
        private string plantName;

        /// <summary>
        ///     Parameter Title
        /// </summary>
        private string title;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PrintController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service</param>
        public PrintController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        [HttpGet]
        public void GetPdf(string page)
        {
            page = page.ToLower();
            this.title = string.IsNullOrEmpty(page) ? "Plant Setup" : page;
            this.locale = new LocaleController(this.UserService, this.PlantService);

            //The title has to be dynamically coming as part of the request             
            PlantModel plantDetails = this.GetPlantDetails();
            this.plantName = plantDetails.Name;
            this.plantLocation = plantDetails.RegionName;
            this.ViewBag.RegionId = plantDetails.RegionId;
            User user = this.GetCurrentUser();
            this.ViewBag.MaxLevel = user.Roles.Select(i => i.RoleId).Max();
            IPlantCustomerService customerService = new PlantCustomerService();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerService = new WasherServices();

            string fileName = "Ecolab - " + this.locale.Localize("FIELD_PLANT SETUP", "Plant Setup") + " - {0} - " + DateTime.Now.ToShortDateString();
            switch (page)
            {
                case "general":
                    Api.PlantSetupController plant = new Api.PlantSetupController(this.UserService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_PlantGeneral", plant.Get())), string.Format(fileName, this.locale.Localize("FIELD_SETUP", "Setup")), this.Breadcrumb(page));
                    break;
                case "contact":
                    PlantContactService contactService = new PlantContactService();
                    Api.ContactController contact = new Api.ContactController(this.UserService, this.PlantService, contactService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Contact", contact.GetContact())), string.Format(fileName, this.locale.Localize("FIELD_CONTACTS", "Contacts")), this.Breadcrumb(page));
                    break;
                case "shiftlabor":
                    IShiftBreakService shiftBreakService = new ShiftBreakService();
                    ILaborService laborService = new LaborService();
                    Api.ShiftLaborController shiftlabor = new Api.ShiftLaborController(this.UserService, shiftBreakService, laborService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ShiftLabor", shiftlabor.Get())), string.Format(fileName, this.locale.Localize("FIELD_SHIFT", "Shift")), this.Breadcrumb(page));
                    break;
                case "laborcost":
                    ILaborCostService laborCostService = new LaborCostService();
                    Api.LaborCostController laborCost = new Api.LaborCostController(this.UserService, this.PlantService, laborCostService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_LaborCost", laborCost.Fetch())), string.Format(fileName, this.locale.Localize("FIELD_LABORCOST", "Labor Cost")), this.Breadcrumb(page));
                    break;
                case "chemical":
                    IProductMasterService chemicalService = new ProductMasterService();
                    PlantChemicalController chemical = new PlantChemicalController(this.UserService, chemicalService, this.PlantService, null);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Chemical", chemical.GetPlantChemical())), string.Format(fileName, this.locale.Localize("FIELD_CHEMICALS", "Chemicals")), this.Breadcrumb(page));
                    break;
                case "formula":
                    IProgramMasterService formulaService = new ProgramMasterService();

                    PlantFormulaController formula = new PlantFormulaController(this.UserService, this.PlantService, formulaService, customerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Formula", formula.GetFormulaForPrint(1, 10000, 0))), string.Format(fileName, this.locale.Localize("FIELD_FORMULAS", "Formulas")), this.Breadcrumb(page));
                    break;
                case "redflag":
                    IRedFlagService redFlagService = new RedFlagService();
                    Api.RedFlagController redFlag = new Api.RedFlagController(this.UserService, this.PlantService, redFlagService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_RedFlag", redFlag.Get())), string.Format(fileName, this.locale.Localize("FIELD_REDFLAG", "Red Flag")), this.Breadcrumb(page));
                    break;
                case "customer":

                    Api.CustomerController customer = new Api.CustomerController(this.UserService, customerService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Customer", customer.GetCustomer())), string.Format(fileName, this.locale.Localize("FIELD_CUSTOMER", "Customer")), this.Breadcrumb(page));
                    break;
                case "dryer":
                    IDryerGroupService dryerGroupService = new DryerGroupService();
                    IDryerService dryerService = new DryerService();
                    Api.DryerController dryer = new Api.DryerController(this.UserService, this.PlantService, dryerGroupService, dryerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Dryer", dryer.Get())), string.Format(fileName, this.locale.Localize("FIELD_DRYER", "Dryer")), this.Breadcrumb(page));
                    break;
                case "finisher":
                    IFinnisherGroupService finnisherGroupService = new FinnisherGroupService();
                    IFinnisherService finnisherService = new FinnisherService();
                    Api.FinnisherController finnisher = new Api.FinnisherController(this.UserService, finnisherGroupService, finnisherService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Finisher", finnisher.Get())), string.Format(fileName, this.locale.Localize("FIELD_FINNISHERS", "Finishers")), this.Breadcrumb(page));
                    break;
                case "utility":
                    IPlantUtilityService utilityService = new PlantUtilityService();
                    Api.PlantUtilitySetupController utility = new Api.PlantUtilitySetupController(this.UserService, this.PlantService, utilityService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Utility", utility.Get())), string.Format(fileName, this.locale.Localize("FIELD_UTILITY", "Utility")), this.Breadcrumb(page));
                    break;
                case "meter":
                    IMeterService meterService1 = new MeterService();
                    IPlcService plcService = new PlcService();
                    IPlantUtilityService plantUtilityService = new PlantUtilityService();
                    Api.MeterController meter = new Api.MeterController(this.UserService, meterService1, this.PlantService, plcService, plantUtilityService, controllerSetupService, washerGroupService, washerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Meter", meter.GetMeter())), string.Format(fileName, this.locale.Localize("FIELD_METERS", "Meters")), this.Breadcrumb(page));
                    break;
                case "sensor":
                    ISensorService sensorService = new SensorService();
                    IPlcService plcService1 = new PlcService();

                    Api.SensorController sensor = new Api.SensorController(this.UserService, sensorService, this.PlantService, plcService1, controllerSetupService, washerGroupService, washerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Sensor", sensor.GetSensor())), string.Format(fileName, this.locale.Localize("FIELD_SENSORS", "Sensors")), this.Breadcrumb(page));
                    break;
                case "waterandenergy":
                    IUtilityService waterAndEnergyService = new UtilityService();
                    Api.UtilityController waterAndEnergy = new Api.UtilityController(this.UserService, waterAndEnergyService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WaterAndEnergy", waterAndEnergy.GetUtility())), string.Format(fileName, this.locale.Localize("FIELD_WATERENERGYDEVICE", "Water & Energy Device")), this.Breadcrumb(page));
                    break;
                case "usermanagement":
                    IUserManagementService userManagementService = new UserManagementService();
                    Api.UserManagementController userManagement = new Api.UserManagementController(this.UserService, this.PlantService, userManagementService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_UserManagement", userManagement.FetchUserList())), string.Format(fileName, this.locale.Localize("FIELD_USERMANAGEMENT", "User Management")), this.Breadcrumb(page));
                    break;
                case "monitorsetup":
                    IMonitorSetupService monitorSetupService = new MonitorSetupService();
                    Api.Visualization.Monitor.MonitorSetupController monitorSetup = new Api.Visualization.Monitor.MonitorSetupController(this.UserService, this.PlantService, monitorSetupService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_monitorSetup", monitorSetup.FetchMonitorSetUpDetails())), string.Format(fileName, this.locale.Localize("FIELD_DASHBOARDSETUP", "Dashboard Setup")), this.Breadcrumb(page));
                    break;
                case "targetproduction":
                    IShiftBreakService targetProductionService = new ShiftBreakService();
                    Api.TargetProductionController targetProduction = new Api.TargetProductionController(this.UserService, this.PlantService, targetProductionService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TargetProduction", targetProduction.FetchTargetProductionDetails())), string.Format(fileName, this.locale.Localize("FIELD_TARGETPRODUCTION", "Target Production")), this.Breadcrumb(page));
                    break;
                case "controllersetuplist":
                    Api.ControllerSetupController controllerSetupcontroller = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ControllerSetupList", controllerSetupcontroller.GetControllerDetails())), string.Format(fileName, this.locale.Localize("FIELD_CONTROLLERSETUPLIST", "Dispenser Setup List")), this.Breadcrumb(page));
                    break;
            }
            string pathName = "Ecolab - " + this.locale.Localize("FIELD_WASHER", "Washer") + " - {0} - " + DateTime.Now.ToShortDateString();
        }

        /// <summary>
        ///     Generates Pdf with the given data
        /// </summary>
        /// <param name="data">The Parameter Data</param>
        [HttpGet]
        public void GeneratePdf(string data)
        {
            PrintModel printObject = JsonConvert.DeserializeObject<PrintModel>(data);
            this.title = !string.IsNullOrEmpty(printObject.PageTitle) ? printObject.PageTitle.ToLower() : string.Empty;

            this.locale = new LocaleController(this.UserService, this.PlantService);
            PlantModel plant = this.GetPlantDetails();
            this.plantName = plant.Name;
            this.plantLocation = plant.RegionName;
            printObject.EcolabAccountNumber = plant.EcoalabAccountNumber;

            string fileName = "Ecolab - {0} - " + DateTime.Now.ToShortDateString();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IPlcService plcService = new PlcService();

            switch (this.title)
            {
                case "washer list":
                    IWasherServices washerService = new WasherServices();
                    IWasherGroupService washerGroupService = new WasherGroupService();
                    IInjectionService injectionservices = new InjectionService();
                    Api.Washers.WasherController washerList = new Api.Washers.WasherController(washerService, washerGroupService, injectionservices);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Washers", washerList.GetWashersDetails(printObject.EcolabAccountNumber))), string.Format(fileName, this.locale.Localize("FIELD_WASHER", "Washer")), this.Breadcrumb(this.title));
                    break;
                case "washer group":
                    WasherGroupPrintModel washerGroupPrintModel = this.GetWasherGroupDataWithWashersList(printObject);

                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WasherGroup", washerGroupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_WASHERGROUP", "WasherGroup")), this.Breadcrumb(this.title));
                    break;
                case "washergroup":
                    IWasherGroupService washerGroupservice = new WasherGroupService();
                    IWasherServices washerServices = new WasherServices();
                    Api.WasherGroupController washerGroup = new Api.WasherGroupController(washerGroupservice, washerServices);

                    IProgramMasterService programMasterService = new ProgramMasterService();
                    IWasherGroupFormulaService washerGrpFormulaService = new WasherGroupFormulaService();
                    IPlantUtilityService plantUtilityService = new PlantUtilityService();
                    IProductMasterService productMasterService = new ProductMasterService();

                    IInjectionService injectionService = new InjectionService();
                    WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupservice, programMasterService, washerGrpFormulaService, plantUtilityService, productMasterService, this.PlantService, this.UserService, washerServices, injectionService, plcService, controllerSetupService);
                    WasherGroupPrintModel washergroupPrintModel = new WasherGroupPrintModel();
                    washergroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists>();
                    washergroupPrintModel.WasherGroupWithWashers.Add(washerGroupFormula.GetWasherGroupWithWasherDetails(printObject.WasherGroupId, printObject.EcolabAccountNumber, 0, 12, string.Empty, printObject.RegionId));
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WasherGroupWithWashers", washergroupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_WASHERGROUP", "WasherGroup")), this.Breadcrumb(this.title));
                    break;
                case "storage tanks":
                    IStorageTanksService storageTankService = new StorageTanksService();
                    IPumpsService pumpServices = new PumpsServices();
                    Api.StorageTanksController storageTanks = new Api.StorageTanksController(this.UserService, storageTankService, controllerSetupService, pumpServices, plcService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_StorageTank", storageTanks.GetTanksDetails(printObject.EcolabAccountNumber))), string.Format(fileName, this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks")), this.Breadcrumb(this.title));
                    break;
                case "storage tank":
                    IStorageTanksService storageTanksService = new StorageTanksService();
                    IPumpsService pumpsServices = new PumpsServices();
                    IPlcService plcServices = new PlcService();
                    Api.StorageTanksController storageTank = new Api.StorageTanksController(this.UserService, storageTanksService, controllerSetupService, pumpsServices, plcServices, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_StorageTanksForm", storageTank.GetAddEditStorageTanksDetails(printObject.EcolabAccountNumber, printObject.StorageTankId).FirstOrDefault())), string.Format(fileName, this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks")), this.Breadcrumb(this.title));
                    break;
                case "conventional general":
                    ConventionGeneralPrintModel conventionalGeneralPrint = this.GetConventionalGeneralData(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalGeneral", conventionalGeneralPrint)), string.Format(fileName, this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General")), this.Breadcrumb(this.title));
                    break;
                case "conventionalgeneral":
                    ConventionGeneralPrintModel conventionGeneralPrintData = this.GetConventionalGeneralDataForHoldConditions(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalGeneral", conventionGeneralPrintData)), string.Format(fileName, this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General")), this.Breadcrumb(this.title));
                    break;
                case "tunnel general":
                    TunnelGeneralPrintModel tunnelGeneralPrint = this.GetTunnelGeneralData(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TunnelGeneral", tunnelGeneralPrint)), string.Format(fileName, this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General")), this.Breadcrumb(this.title));
                    break;
                case "formula list":
                    WasherGroupFormulaLists washerGroupFormulaLists = this.GetFormulaList(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_FormulaList", washerGroupFormulaLists)), string.Format(fileName, this.locale.Localize("FIELD_FORMULAS", "Formulas")), this.Breadcrumb(this.title));

                    break;
                case "formula washstep list":
                    ConventionGeneralPrintModel conventionGeneralPrintModel = this.GetConventionalWashStepData(printObject);
                    var washstepModal = conventionGeneralPrintModel.FormulaData.WasherGroupFormulaWashStepModel.OrderBy(x => x.StepNumber);
                    conventionGeneralPrintModel.FormulaData.WasherGroupFormulaWashStepModel = washstepModal.ToList();
                    conventionGeneralPrintModel.RegionId = this.GetPlantDetails().RegionId;
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalWashStep", conventionGeneralPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_CONVENTIONALWASHSTEPS", "Conventional Wash Steps")), this.Breadcrumb(this.title));
                    break;
                case "tunnel compartment list":
                    TunnelGeneralPrintModel tunnelGeneralPrintModel = this.GetTunnelCompartmentList(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TunnelWashStep", tunnelGeneralPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_TUNNELWASHSTEPS", "Tunnel Wash Steps")), this.Breadcrumb(this.title));
                    break;
                case "controller setup":
                    ControllerSetupPrintModel controllerSetupPrintModel = this.GetControllerSetupData(printObject);
                    controllerSetupPrintModel.RegionId = printObject.RegionId;
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ControllerSetup", controllerSetupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_CONTROLLER SETUP", "Controller Setup")), this.Breadcrumb(this.title));
                    break;
                case "product deviation":
                    ProductDeviationPrintModel productDeviationPrintModel = this.GetProductDeviationData(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ProductDeviation", productDeviationPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_PRODUCTDEVIATION", "Product Deviation")), this.Breadcrumb(this.title));
                    break;
            }
            string pathName = "Ecolab - " + this.locale.Localize("FIELD_WASHER", "Washer") + " - {0} - " + DateTime.Now.ToShortDateString();
        }

        /// <summary>
        ///     Creates PDF file
        /// </summary>
        /// <param name="htmlText">The content HTML of PDF file</param>
        /// <param name="fileName">File Name of Generated PDF file</param>
        /// <param name="breadcrumb">Page breadcrumb path in PDF</param>
        private void DownloadPdf(string htmlText, string fileName, string breadcrumb)
        {
            PdfGenerator pdfGenerator = new PdfGenerator();
            var plantAddr = new List<string>();
            PlantModel plantDetails = this.GetPlantDetails();
            if (!string.IsNullOrWhiteSpace(plantDetails.plantCustAddr.BillingAddr1))
            {
                plantAddr.Add(plantDetails.plantCustAddr.BillingAddr1);
            }
            if (!string.IsNullOrWhiteSpace(plantDetails.plantCustAddr.City))
            {
                plantAddr.Add(plantDetails.plantCustAddr.City);
            }
            if (!string.IsNullOrWhiteSpace(plantDetails.plantCustAddr.Country))
            {
                plantAddr.Add(plantDetails.plantCustAddr.Country);
            }
            if (!string.IsNullOrWhiteSpace(plantDetails.plantCustAddr.Zip))
            {
                plantAddr.Add(plantDetails.plantCustAddr.Zip);
            }
            HtmlContentForPdf contentForPdf = new HtmlContentForPdf { HtmlText = htmlText, Logo = this.GetPlantDetails().Logo, Title = this.plantName, PlantName = this.plantName, PlantLocation = this.plantLocation, Breadcrumb = string.Join(", ", plantAddr.ToArray()) };

            byte[] response = pdfGenerator.CreatePdf(contentForPdf);

            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.ContentType = "application/octet-stream";
            System.Web.HttpContext.Current.Response.AddHeader("Content-Type", "application/octet-stream");
            System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".pdf");
            System.Web.HttpContext.Current.Response.BinaryWrite(response);
            System.Web.HttpContext.Current.Response.End();
        }

        /// <summary>
        ///     Converts Partial view to string
        /// </summary>
        /// <param name="controller">The Controller</param>
        /// <param name="viewName">Name of the Partial View</param>
        /// <param name="model">Model data to be binded in view</param>
        /// <returns>Converted view as string</returns>
        private static string RenderPartialViewToString(Controller controller, string viewName, object model)
        {
            controller.ViewData.Model = model;
            using (StringWriter sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(controller.ControllerContext, viewName);
                ViewContext viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                return sw.ToString();
            }
        }

        /// <summary>
        ///     Generates a breadcrumb string
        /// </summary>
        /// <param name="page">The name of page</param>
        /// <returns>Breadcrumb as string</returns>
        private string Breadcrumb(string page)
        {
            page = page.ToLower();
            var breadcrumb = new List<string>();
            switch (page)
            {
                case "general":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    break;
                case "contact":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONTACTS", "Contacts"));
                    break;
                case "shiftlabor":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SHIFT", "Shift"));
                    break;
                case "laborcost":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_LABORCOST", "Labor Cost"));
                    break;
                case "chemical":
                    breadcrumb.Add(this.locale.Localize("FIELD_CHEMICALS", "Chemicals"));
                    break;
                case "formula":
                    breadcrumb.Add(this.locale.Localize("FIELD_FORMULAS", "Formulas"));
                    break;
                case "redflag":
                    breadcrumb.Add(this.locale.Localize("FIELD_REDFLAG", "Red Flag"));
                    break;
                case "customer":
                    breadcrumb.Add(this.locale.Localize("FIELD_CUSTOMER", "Customer"));
                    break;
                case "dryer":
                    breadcrumb.Add(this.locale.Localize("FIELD_CLEANSIDE", "Clean Side"));
                    breadcrumb.Add(this.locale.Localize("FIELD_DRYER", "Dryer"));
                    break;
                case "finisher":
                    breadcrumb.Add(this.locale.Localize("FIELD_CLEANSIDE", "Clean Side"));
                    breadcrumb.Add(this.locale.Localize("FIELD_FINNISHERS", "Finishers"));
                    break;
                case "utility":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITY", "Utility"));
                    break;
                case "meter":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_METERS", "Meters"));
                    break;
                case "sensor":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SENSORS", "Sensors"));
                    break;
                case "waterandenergy":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WATERENERGYDEVICE", "Water & Energy Device"));
                    break;
                case "usermanagement":
                    breadcrumb.Add(this.locale.Localize("FIELD_USERMANAGEMENT", "User Management"));
                    break;
                case "monitorsetup":
                    breadcrumb.Add(this.locale.Localize("FIELD_DASHBOARDSETUP", "Dashboard Setup"));
                    break;
                case "washer list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
                case "washer group":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERGROUP", "Washer Group"));
                    break;
                case "storage tanks":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks"));
                    break;
                case "storage tank":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks"));
                    break;
                case "conventional general":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General"));
                    break;
                case "conventionalgeneral":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General"));
                    break;
                case "tunnel general":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General"));
                    break;
                case "tunnelgeneral":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General"));
                    break;
                case "formula list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
                case "formula washstep list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
            }
            return string.Join(" > ", breadcrumb.ToArray());
        }

        /// <summary>
        ///     Gets WasherGroup Data with Washers
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private WasherGroupPrintModel GetWasherGroupDataWithWashersList(PrintModel printModel)
        {
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            Api.WasherGroupController washerGroup = new Api.WasherGroupController(washerGroupService, washerServices);
            IControllerSetupService cntrlSetup = new ControllerSetupService();
            IProgramMasterService programMasterService = new ProgramMasterService();
            IWasherGroupFormulaService washerGrpFormulaService = new WasherGroupFormulaService();
            IPlantUtilityService plantUtilityService = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();
            IInjectionService injectionService = new InjectionService();
            IPlcService plcService = new PlcService();
            WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupService, programMasterService, washerGrpFormulaService, plantUtilityService, productMasterService, this.PlantService, this.UserService, washerServices, injectionService, plcService, cntrlSetup);
            WasherGroupPrintModel washerGroupPrintModel = new WasherGroupPrintModel();
            washerGroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists>();
            washerGroupPrintModel.WasherGroupList = washerGroup.GetWasherGroupDetails(-1, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            for (int i = 0; i < washerGroupPrintModel.WasherGroupList.Count(); i++)
            {
                washerGroupPrintModel.WasherGroupWithWashers.Add(washerGroupFormula.GetWasherGroupWithWasherDetails(washerGroupPrintModel.WasherGroupList.ElementAt(i).WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty, printModel.RegionId));
            }

            return washerGroupPrintModel;
        }

        /// <summary>
        ///     Gets Conventional General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalGeneralData(PrintModel printModel)
        {
            IUserService userService = new UserService();
            IPlantService plantService = new PlantService();
            IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            ConventionGeneralPrintModel conventionalGeneralPrintModel = new ConventionGeneralPrintModel();
            ControllerModel controllerModel = new ControllerModel();

            IProductDeviationService productDeviationService = new ProductDeviationService();
            IConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();

            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();

            IInjectionService injectionService = new InjectionService();
            ConventionalController conventionalController = new ConventionalController(conventionalGeneralService,
                controllerSetupService, washerGroupService, userService, plantService, injectionService, washerServices);
            IWasherServices washerService = new WasherServices();
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerService);
            ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            Api.ControllerSetupController controllerSetupController = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerServices, washerGroupService, injectionService);

            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(userService, plantService, tunnelGeneralServices, washerServices);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(userService, plantService, flushTimesAndTomServices, tunnelGeneralServices, washerGroupService);
            conventionalGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);

            Api.Washers.ProductDeviationController productDeviationController = new Api.Washers.ProductDeviationController(this.UserService, this.PlantService, productDeviationService, conventionalGeneralServices, washerGroupService);

            conventionalGeneralPrintModel.ProductDeviationPrintData = productDeviationController.GetProductDeviationData(printModel.WasherId, printModel.WasherGroupId, printModel.ControllerId);

            conventionalGeneralPrintModel.ConventionalGeneralData = conventionalController.GetConventionalData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.RegionId);
            conventionalGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            conventionalGeneralPrintModel.WasherModeList = conventionalController.GetWasherModeList(printModel.ControllerId, printModel.EcolabAccountNumber);

            if (printModel.ControllerId != 0)
            {
                controllerModel = controllerSetupController.GetControllerDetailById(printModel.ControllerId, printModel.EcolabAccountNumber);
            }
            conventionalGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            conventionalGeneralPrintModel.HoldConditionData.AlarmsModel = conventionalGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);

            return conventionalGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Conventional General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalGeneralDataForHoldConditions(PrintModel printModel)
        {
            IUserService userService = new UserService();
            IPlantService plantService = new PlantService();
            IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            ConventionGeneralPrintModel conventionalGeneralPrintModel = new ConventionGeneralPrintModel();
            IInjectionService injectionService = new InjectionService();
            ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();
            IProductDeviationService productDeviationService = new ProductDeviationService();
            ConventionalController conventionalGeneralController = new ConventionalController(conventionalGeneralService, controllerSetupService, washerGroupService, userService, plantService, injectionService, washerServices);
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerServices);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerServices, washerGroupService, injectionService);

            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(userService, plantService, tunnelGeneralServices, washerServices);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(userService, plantService, flushTimesAndTomServices, tunnelGeneralServices, washerGroupService);
            conventionalGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);

            Api.Washers.ProductDeviationController productDeviationController = new Api.Washers.ProductDeviationController(this.UserService, this.PlantService, productDeviationService, conventionalGeneralService, washerGroupService);

            conventionalGeneralPrintModel.ProductDeviationPrintData = productDeviationController.GetProductDeviationData(printModel.WasherId, printModel.WasherGroupId, printModel.ControllerId);

            conventionalGeneralPrintModel.ConventionalGeneralData = conventionalGeneralController.GetConventionalData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.RegionId);
            conventionalGeneralPrintModel.WasherModeList = conventionalGeneralController.GetWasherModeList(conventionalGeneralPrintModel.ConventionalGeneralData.ControllerId, printModel.EcolabAccountNumber);
            conventionalGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            conventionalGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(printModel.ControllerModelId, printModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            conventionalGeneralPrintModel.HoldConditionData.AlarmsModel = conventionalGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);

            return conventionalGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Tunnel General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns TunnelGeneralPrintModel</returns>
        private TunnelGeneralPrintModel GetTunnelGeneralData(PrintModel printModel)
        {
            IUserService userService = new UserService();
            IPlantService plantService = new PlantService();
            ITunnelGeneralServices tunnelGeneralService = new TunnelGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerService = new WasherServices();
            IConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            ITunnelCompartmentServices tunnelCompartmentService = new TunnelCompartmentServices();
            TunnelGeneralPrintModel tunnelGeneralPrintModel = new TunnelGeneralPrintModel();
            ITunnelConnectionServices tunnelConnectionService = new TunnelConnectionServices();
            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();
            ITunnelAnalogueDosingControlServices analogueDosingControlServices = new TunnelAnalogueDosingControlServices();
            List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstAnalogDosing = analogueDosingControlServices.FetchAnalogueDosingDataForMachineId(printModel.WasherId, printModel.EcolabAccountNumber);
            List<Models.Washers.Tunnel.AnalogueDosing> lstad = AutoMapper.Mapper.Map<List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>, List<Models.Washers.Tunnel.AnalogueDosing>>(lstAnalogDosing);

            IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections> lstconn = tunnelConnectionService.FetchTunnelConnections(printModel.WasherId, printModel.ControllerId, printModel.EcolabAccountNumber);
            IEnumerable<Models.Washers.Tunnel.TunnelConnections> tunnelconn = AutoMapper.Mapper.Map<IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections>, List<Models.Washers.Tunnel.TunnelConnections>>(lstconn);
            ControllerModel controllerModel = new ControllerModel();
            IInjectionService injectionService = new InjectionService();
            IWasherServices washerServices = new WasherServices();
            ITunnelConnectionServices tunnelservices = new TunnelConnectionServices();
            TunnelController tunnelController = new TunnelController(tunnelGeneralService, controllerSetupService, washerGroupFormulaService, tunnelCompartmentService, washerGroupService, userService, plantService, tunnelservices);
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerService);
            Api.ControllerSetupController controllerSetupController = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerService, washerGroupService, injectionService);
            ConventionalController conventionalController = new ConventionalController(conventionalGeneralServices, controllerSetupService, washerGroupService, userService, plantService, injectionService, washerServices);
            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(userService,
                plantService, tunnelGeneralService, washerService);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(userService, plantService, flushTimesAndTomServices, tunnelGeneralService, washerGroupService);
            tunnelGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);
            tunnelGeneralPrintModel.TunnelConnectionsdata = tunnelconn.ToList();
            tunnelGeneralPrintModel.AnalogueDosingData = lstad;
            tunnelGeneralPrintModel.TunnelGeneralData = tunnelController.GetTunnelData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber);
            tunnelGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            tunnelGeneralPrintModel.TunnelGeneralDropDownData = tunnelController.GetDropDownData(printModel.EcolabAccountNumber, printModel.RegionId, "Tunnel", printModel.WasherGroupId);
            tunnelGeneralPrintModel.CompartmentDropDownData = tunnelController.GetCompartmentDropDownData(printModel.EcolabAccountNumber, printModel.RegionId, printModel.ControllerId, printModel.WasherId, printModel.WasherGroupId);

            tunnelGeneralPrintModel.TunnelCompartmentData = new List<TunnelCompartmentModel>();
            if (printModel.ControllerId != 0)
            {
                controllerModel = controllerSetupController.GetControllerDetailById(printModel.ControllerId, printModel.EcolabAccountNumber);
                tunnelGeneralPrintModel.WasherModeList = tunnelController.GetWasherModes(printModel.ControllerId, printModel.EcolabAccountNumber);
            }
            for (int i = 1; i <= printModel.NumberOfCompartments; i++)
            {
                tunnelGeneralPrintModel.TunnelCompartmentData.Add(tunnelController.GetCompartmentData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, Convert.ToByte(i), printModel.RegionId, printModel.ControllerId));
            }
            tunnelGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            tunnelGeneralPrintModel.HoldConditionData.AlarmsModel = tunnelGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);
            tunnelGeneralPrintModel.BatchEjectData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, true);
            tunnelGeneralPrintModel.BatchEjectData.AlarmsModel = tunnelGeneralPrintModel.BatchEjectData.AlarmsModel.Where(a => a.Active);
            return tunnelGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Formulas List
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns WasherGroupFormulaLists</returns>
        private WasherGroupFormulaLists GetFormulaList(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IProgramMasterService programMasterServcs = new ProgramMasterService();
            IPlantUtilityService plantUtilityService = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();
            IWasherServices washerServices = new WasherServices();
            IInjectionService injectionService = new InjectionService();
            WasherGroupFormulaLists washerGroupFormulaLists = new WasherGroupFormulaLists();
            IPlcService plcService = new PlcService();
            IControllerSetupService cntrlSetup = new ControllerSetupService();
            WasherGroupFormulaController washerGroupFormulaController = new WasherGroupFormulaController(washerGroupService, programMasterServcs, washerGroupFormulaService, plantUtilityService, productMasterService, this.PlantService, this.UserService, washerServices, injectionService, plcService, cntrlSetup);

            washerGroupFormulaLists = washerGroupFormulaController.GetWasherGroupFormula(printModel.WasherGroupId, printModel.EcolabAccountNumber);
            washerGroupFormulaLists.RegionId = this.GetPlantDetails().RegionId;
            return washerGroupFormulaLists;
        }

        /// <summary>
        ///     Gets Conventional WashStep data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalWashStepData(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupSrvice = new WasherGroupService();
            IProgramMasterService prgMasterServcs = new ProgramMasterService();
            IPlantUtilityService plntUtltyService = new PlantUtilityService();
            IProductMasterService prdMasterService = new ProductMasterService();
            IWasherServices wshrSvc = new WasherServices();
            IControllerSetupService ctrlStpSrvice = new ControllerSetupService();
            IInjectionService injectionService = new InjectionService();
            IWasherServices washerServices = new WasherServices();
            ConventionGeneralPrintModel conventionGeneralPrintModel = new ConventionGeneralPrintModel();
            IPlcService plcService = new PlcService();
            WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupSrvice, prgMasterServcs, washerGroupFormulaService, plntUtltyService, prdMasterService, this.PlantService, this.UserService, washerServices, injectionService, plcService, ctrlStpSrvice);
            WasherGroupPrintModel washergroupPrintModel = new WasherGroupPrintModel();
            washergroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists> { washerGroupFormula.GetWasherGroupWithWasherDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty, printModel.RegionId) };
            WasherGroupFormulaController washerGroupData = new WasherGroupFormulaController(washerGroupSrvice, prgMasterServcs, washerGroupFormulaService, plntUtltyService, prdMasterService, this.PlantService, this.UserService, wshrSvc, injectionService, plcService, ctrlStpSrvice);
            conventionGeneralPrintModel.WasherGroupWithWashers = washergroupPrintModel;
            conventionGeneralPrintModel.FormulaData = washerGroupData.GetEditFormulaDetails(printModel.WasherGroupId, printModel.ProgramSetupId, printModel.EcolabAccountNumber, printModel.RegionId);
            return conventionGeneralPrintModel;
        }

        /// <summary>
        ///     Gets TunnelCompartment data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns TunnelGeneralPrintModel</returns>
        private TunnelGeneralPrintModel GetTunnelCompartmentList(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IProgramMasterService programMasterService = new ProgramMasterService();
            IPlantUtilityService plantUtilitySrvice = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();
            IWasherServices washerService = new WasherServices();
            IEnumerable<WashersModel> washersModel = new List<WashersModel>();
            TunnelGeneralPrintModel tunnelGeneralPrintModel = new TunnelGeneralPrintModel();
            IInjectionService injectionService = new InjectionService();
            IPlcService plcService = new PlcService();
            IControllerSetupService ctrlStpSrvice = new ControllerSetupService();
            WasherGroupFormulaController washerGroupdata = new WasherGroupFormulaController(washerGroupService, programMasterService, washerGroupFormulaService, plantUtilitySrvice, productMasterService, this.PlantService, this.UserService, washerService, injectionService, plcService, ctrlStpSrvice);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerService, washerGroupService, injectionService);

            washersModel = washerController.GetWashersDetails(printModel.EcolabAccountNumber);
            tunnelGeneralPrintModel.WashersData = washersModel.Where(x => x.WasherGroupId == printModel.WasherGroupId).ToList();
            tunnelGeneralPrintModel.TunnelFormulaData = washerGroupdata.GetTunnelGridDetails(printModel.ProgramSetupId, printModel.EcolabAccountNumber, printModel.CompartmentNumber, printModel.WasherGroupId, printModel.RegionId);
            tunnelGeneralPrintModel.RegionId = printModel.RegionId;
            return tunnelGeneralPrintModel;
        }

        /// <summary>
        ///     Gets ControllerSetup data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ControllerSetupPrintModel</returns>
        private ControllerSetupPrintModel GetControllerSetupData(PrintModel printModel)
        {
            var user = this.GetCurrentUser();
            int maxLevel = user.Roles.Select(i => i.RoleId).Max();
            ControllerSetupPrintModel controllerSetupPrintModel = new ControllerSetupPrintModel();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IPumpsService pumpsService = new PumpsServices();
            IPlcService plcService = new PlcService();
            Api.ControllerSetupController controllerSetupcontroller = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.PumpsController pumpsController = new Api.PumpsController(pumpsService, plcService, this.UserService, this.PlantService, controllerSetupService);
            controllerSetupPrintModel.ControllerGeneralData = controllerSetupcontroller.GetControllerSetupMetaDataWithValues(printModel.TabId, printModel.ControllerId);
            controllerSetupPrintModel.Pumpsproducts = pumpsController.GetPumpsProducts(printModel.ControllerId, printModel.EcolabAccountNumber);
            if (maxLevel >= 8)
            {
                controllerSetupPrintModel.ControllerAdvancedData = controllerSetupcontroller.GetControllerSetupAdvanceMetaData(3, printModel.ControllerId);
            }

            if (printModel.ControllerModelId != 5)
            {
                controllerSetupPrintModel.PumpsValvesData = pumpsController.GetPumps(printModel.EcolabAccountNumber, printModel.ControllerId, "All", 1);
            }

            return controllerSetupPrintModel;
        }

        /// <summary>
        ///     Gets ProductDeviation data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ProductDeviationPrintModel</returns>
        private ProductDeviationPrintModel GetProductDeviationData(PrintModel printModel)
        {
            var user = this.GetCurrentUser();
            int maxLevel = user.Roles.Select(i => i.RoleId).Max();
            ProductDeviationPrintModel productDeviationPrintModel = new ProductDeviationPrintModel();
            IProductDeviationService productDeviationService = new ProductDeviationService();
            IConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            Api.Washers.ProductDeviationController productDeviationController = new Api.Washers.ProductDeviationController(this.UserService, this.PlantService, productDeviationService, conventionalGeneralServices, washerGroupService);
            productDeviationPrintModel.WasherProductDeviationModel = productDeviationController.GetProductDeviationData(printModel.WasherId, printModel.WasherGroupId, printModel.ControllerId);
            return productDeviationPrintModel;
        }
    }
}