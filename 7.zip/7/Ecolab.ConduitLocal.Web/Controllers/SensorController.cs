﻿// -----------------------------------------------------------------------
// <copyright file="SensorController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Linq;
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.PlantSetup;

    [Authorize]
    public class SensorController : BaseController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     Sensor Service
        /// </summary>
        /// <param name="sensorService"></param>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        private readonly ISensorService sensorService;

        public SensorController(ISensorService sensorService, IUserService userService, IPlantService plantService, IControllerSetupService controllerSetupService) : base(userService, plantService)
        {
            this.sensorService = sensorService;
            this.controllerSetupService = controllerSetupService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.ControllerCount = this.controllerSetupService.GetControllerDetails(this.EcolabAccountNumber).ToList().Count;
            this.ViewBag.IsCentral = "No";
            return this.View();
        }
    }
}