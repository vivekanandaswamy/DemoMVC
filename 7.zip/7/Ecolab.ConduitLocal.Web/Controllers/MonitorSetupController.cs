﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetupController.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Monitor Setup Controller class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.Visualization.Monitor;

    [Authorize]
    public class MonitorSetupController : BaseController
    {
        /// <summary>
        ///     MonitorSetup Service
        /// </summary>
        private readonly IMonitorSetupService monitorSetUpService;

        /// <summary>
        ///     Controller Constructor for Initializing service objects
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        /// <param name="monitorSetUpService"></param>
        public MonitorSetupController(IUserService userService, IPlantService plantService, IMonitorSetupService monitorSetUpService) : base(userService, plantService)
        {
            this.monitorSetUpService = monitorSetUpService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();

            return this.View();
        }
    }
}