﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupAdvanceController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerSetupAdvanceController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class ControllerSetupAdvanceController
    /// </summary>
    [Authorize]
    public class ControllerSetupAdvanceController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupAdvanceController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        public ControllerSetupAdvanceController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            string controllerId = this.Request.QueryString.Get("ControllerId");
            string controllerModelId = this.Request.QueryString.Get("ControllerModelId");
            string controllerTypeId = this.Request.QueryString.Get("ControllerTypeId");
            if(!string.IsNullOrEmpty(controllerId) && !string.IsNullOrEmpty(controllerModelId) && !string.IsNullOrEmpty(controllerTypeId))
            {
                this.ViewBag.ControllerId = controllerId;
                this.ViewBag.ControllerModelId = controllerModelId;
                this.ViewBag.ControllerTypeId = controllerTypeId;
            }
            else
            {
                this.ViewBag.ControllerId = "-1";
                this.ViewBag.ControllerModelId = "-1";
                this.ViewBag.ControllerTypeId = "-1";
            }
            ViewBag.IsCentral = "No";
            return this.View();
        }
    }
}