﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewashController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualRewashController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class ManualRewashController : BaseController
    {
        public ManualRewashController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}