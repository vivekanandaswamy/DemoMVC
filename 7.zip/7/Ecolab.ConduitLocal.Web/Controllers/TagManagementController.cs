﻿// -----------------------------------------------------------------------
// <copyright file="TagManagementController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Web controller for TagManagementController</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Castle.Core.Logging;
    using Ecolab.ConduitLocal.Web.Api;
    using Ecolab.ConduitLocal.Web.Utilities;
    using Ecolab.Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Services.ControllerSetup;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Ecolab.Services.Interfaces.Plc;
    using Models.Common;
    using Elmah;

    /// <summary>
    /// Tagmanagement class
    /// </summary>
    [Authorize]
    public class TagManagementController : BaseController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly ITagManagementService tagManagementService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IPlcService plcService;

        /// <summary>
        ///     The controller setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///  Static variable to hold factors multiplier for k-factor
        /// </summary>
        public static int FactorsMultiplier { get; set; }

        /// <summary>
        /// Static variable to hold ouncepersecond multiplier for time volume calibration
        /// </summary>
        public static int OunceSecMultiplier { get; set; }

        /// <summary>
        ///     Initializes a new instance of the <see cref="TagManagementController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="tagManagementService">The tag management service.</param>
        /// <param name="plcService"> PLC service.</param>
        public TagManagementController(IUserService userService, IPlantService plantService, ITagManagementService tagManagementService, IPlcService plcService, IControllerSetupService controllerSerivce)
            : base(userService, plantService)
        {
            this.tagManagementService = tagManagementService;
            this.plcService = plcService;
            this.controllerSetupService = controllerSerivce;
            FactorsMultiplier = 10;
            OunceSecMultiplier = 10;
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <param name="ControllerId"></param>
        /// <param name="plcDiscrepancyData"></param>
        /// <returns>Redirects to related view</returns>
        [HttpGet]
        public ActionResult Index(int ControllerId, List<PLCDiscrepancyModel> plcDiscrepancyData)
        {
            Models.TagManagementModel tagModel = new Models.TagManagementModel();
            tagModel = GetSettings(ControllerId, plcDiscrepancyData);

            if (!Request.IsAjaxRequest())
            {
                return this.View(tagModel);
            }
            else
            {
                return PartialView("TagDetails", tagModel);
            }
        }

        /// <summary>
        /// Writes the PLC values to data base.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="lstTagManagement">The list of tag management entities.</param>
        public void WritePLCValuesToDataBase(int controllerId, List<TagManagement> lstTagManagement, List<PLCDiscrepancyModel> plcDiscrepancyData)
        {
            List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, 1);
            var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Factors Multiplier").FirstOrDefault().FieldDefaultValue);
            var ounceSecMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "OZ/Second Multiplier").FirstOrDefault().FieldDefaultValue);
            FactorsMultiplier = (Int32)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
            OunceSecMultiplier = (Int32)Convert.ToDecimal(ounceSecMulti.FirstOrDefault().ToString());
            int userId = this.GetCurrentUser().UserId;
            tagManagementService.SavePLCDataToDatabase(controllerId, lstTagManagement);
            List<OpcTag> tagValues = new List<OpcTag>();
            OpcTag tagAWEA = new OpcTag() { };
            OpcTag tagRATD = new OpcTag();
            var fieldTags = this.controllerSetupService.GetWasherFieldsForTags(this.EcolabAccountNumber, controllerId);
            bool awea = fieldTags.AWEActive == true ? true : false;
            bool ratioDosing = fieldTags.RatioDosingActive == true ? true : false;
            if (fieldTags.ControllerTypeId == 1 || fieldTags.ControllerTypeId == 2)//Allenbradley and Beckhoff
            {
                tagAWEA.Address = fieldTags.ControllerTypeId == 1 ? "B3:9/0" : "L_AWEE";
                tagAWEA.TagItemType = UIInputType.TypeBool;
                tagAWEA.TagType = "Tag_AWEA";
                tagAWEA.Value = awea.ToString();

                tagRATD.Address = fieldTags.ControllerTypeId == 1 ? "B3:10/0" : "L_RATD";
                tagRATD.TagItemType = UIInputType.TypeBool;
                tagRATD.TagType = "Tag_RDE";
                tagRATD.Value = ratioDosing.ToString();

                tagValues.Add(tagAWEA);
                tagValues.Add(tagRATD);
                SendSettingstoPLC(tagValues, controllerId, null);
            }
            plcDiscrepancyData = plcDiscrepancyData.GroupBy(x => x.EntityId).Select(x => x.First()).ToList();
            plcDiscrepancyData.Each(x => x.UserId = userId);
            foreach (PLCDiscrepancyModel plcDiscrepancyModel in plcDiscrepancyData)
            {
                this.plcService.DeletePlcDiscrepancy(AutoMapper.Mapper.Map<PLCDiscrepancyModel, Ecolab.Models.Common.PLCDiscrepancyModel>(plcDiscrepancyModel));
            }
        }

        /// <summary>
        ///     Gets all the PLC data and enVision data along with ambiguous data.
        /// </summary>
        /// <param name="controllerId"></param>
        /// <param name="plcDiscrepancyData"></param>
        /// <returns>TagMangagement Model to the View</returns>
        private Models.TagManagementModel GetSettings(int controllerId, List<PLCDiscrepancyModel> plcDiscrepancyData)
        {
            List<string> valDiffEntities = new List<string>();
            Models.TagManagementModel tagModel = new Models.TagManagementModel();
            List<string> tagCollectionList = new List<string>();
            int userId = this.GetCurrentUser().UserId;
            this.GetPageSetupViewBags();

            var controllerInfo = this.controllerSetupService.GetControllerDetailById(controllerId, this.EcolabAccountNumber);

            if (controllerInfo != null)
            {
                this.ViewBag.ControllerId = controllerInfo.ControllerId;
                this.ViewBag.ControllerModelId = controllerInfo.ControllerModelId;
                this.ViewBag.ControllerTypeId = controllerInfo.ControllerTypeId;
                this.ViewBag.ControllerName = controllerInfo.ControllerName;
            }
            List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, 1);
            var factorsMulti = (Int32)Convert.ToDecimal(controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Factors Multiplier").FirstOrDefault().FieldDefaultValue).FirstOrDefault().ToString());
            var ounceSecMulti = (Int32)Convert.ToDecimal(controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "OZ/Second Multiplier").FirstOrDefault().FieldDefaultValue).FirstOrDefault().ToString());

            List<TagManagement> tagsManagementModel = tagManagementService.GetTagManagementDetails(controllerId, this.EcolabAccountNumber, userId);
            List<TagManagement> controllerGeneralandAdvanceTags = tagsManagementModel.Where(t => t.EntityType.Equals("[TCD].[ControllerSetupData]")).ToList().OrderBy(t => t.ColoumnName).ToList();
            controllerGeneralandAdvanceTags.RemoveAll(x => x.TagType.ToLower() == "Tag_RDE".ToLower() || x.TagType.ToLower() == "Tag_AWEA".ToLower());
            List<TagManagement> pumpTags = tagsManagementModel.Where(t => t.EntityType.Equals("[TCD].[ControllerEquipmentSetup]")).ToList().OrderBy(t => Convert.ToInt32(t.ControllerEquipmentSetupId)).ThenBy(t => Convert.ToInt32(t.SortingOrder)).ToList();
            List<TagManagement> tankTags = tagsManagementModel.Where(t => t.EntityType.Equals("[TCD].[TankSetup]")).ToList().OrderBy(t => t.Id).ThenBy(x => x.ColoumnName).ToList();
            List<TagManagement> washerTags = tagsManagementModel.Where(t => t.EntityType.Equals("[TCD].[Washer]")).ToList().OrderBy(t => Convert.ToInt32(t.ControllerEquipmentSetupId)).ThenBy(t => Convert.ToInt32(t.SortingOrder)).ToList();

            List<TagManagement> tagsManagementList = new List<TagManagement>();
            tagsManagementList.AddRange(controllerGeneralandAdvanceTags);
            tagsManagementList.AddRange(pumpTags);
            tagsManagementList.AddRange(tankTags);
            tagsManagementList.AddRange(washerTags);

            tagModel.tagManagementWebModel = Mapper.Map<List<TagManagement>, List<Ecolab.ConduitLocal.Web.Models.TagManagementModel>>(tagsManagementList);

            PlcTagController plc = new PlcTagController(plcService, UserService, PlantService);
            List<OpcTag> tagsList = null;
            List<OpcTag> tags = null;
            TagCollection tagStatus = new TagCollection { Tags = new List<Tag>() };

            IEnumerable<Models.TagManagementModel> tagManagementTags =
                tagModel.tagManagementWebModel.Where(
                    _ => !string.IsNullOrWhiteSpace(_.TagAddress) && !string.IsNullOrWhiteSpace(_.ConduitValue));
            tagsList = new List<OpcTag>();

            foreach (var item in tagManagementTags)
            {
                var tagItemType = UIInputType.TypeInt;
                if (item.DataType.ToUpper() == "BIT")
                {
                    if (item.ConduitValue == "1")
                        item.ConduitValue = "true";
                    else if (item.ConduitValue.ToLower().Trim() == "true")
                        item.ConduitValue = "true";
                    else
                        item.ConduitValue = "false";
                    tagItemType = UIInputType.TypeBool;
                }
                if (item.DataType.ToUpper() == "STRING")
                {
                    tagItemType = UIInputType.TypeString;
                }
                if (item.TagAddress.Contains(".fLossOfFlowDuration") || item.TagAddress.Contains(".fTdFlowMeter") || item.TagAddress.Contains(".fTAlarmDelayFlowMeter"))
                {
                    tagItemType = UIInputType.TypeFloat;
                }
                tagsList.Add(new OpcTag { Address = item.TagAddress, Value = item.ConduitValue, TagItemType = tagItemType });
            }

            tags = tagsList.Clone();
            try
            {
                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(tagsList) }, controllerId);
            }
            catch (Exception ex)
            {
                if (ex.Message == "909" || ex.Message == "901")
                {
                    tagModel = null;
                }
            }
            if (tagModel != null)
            {
                foreach (var tagsData in tagModel.tagManagementWebModel)
                {
                    foreach (Tag plcTag in tagStatus.Tags.Where(_ => !string.IsNullOrWhiteSpace(_.Value)))
                    {
                        if (plcTag.TagItemType == UIInputType.TypeBool)
                        {
                            plcTag.Value = (plcTag.Value.Trim().ToLower() == "true" || plcTag.Value.Trim().ToLower() == "1") ? "true" : "false";
                        }

                        if (tagsData.TagAddress == plcTag.Address)
                        {
                            tagsData.Quality = plcTag.Quality;
                            tagsData.PLCValue = plcTag.Value;
                            tagsData.PLCTimeStamp = plcTag.TimeStamp;

                            if (tagsData.TagAddress.Contains(".fLossOfFlowDuration")
                                || tagsData.TagAddress.Contains(".fTdFlowMeter")
                                || tagsData.TagAddress.Contains(".fTAlarmDelayFlowMeter"))
                            {
                                if (Convert.ToDouble(tagsData.ConduitValue.Trim()) != Convert.ToDouble(tagsData.PLCValue.Trim()))
                                {
                                    tagsData.overRideValues = true;
                                    valDiffEntities.Add(Convert.ToString(tagModel.PlcEntityId));
                                }
                                else
                                    tagsData.overRideValues = false;
                            }
                            else
                            {
                                if (tagsData.ConduitValue.Trim() != tagsData.PLCValue.Trim())
                                {
                                    tagsData.overRideValues = true;
                                    valDiffEntities.Add(Convert.ToString(tagsData.PlcEntityId));
                                }
                                else
                                    tagsData.overRideValues = false;
                            }
                        }
                    }
                    if (tagsData.TagAddress.Contains(".fLossOfFlowDuration") || tagsData.TagAddress.Contains(".fTdFlowMeter") || tagsData.TagAddress.Contains(".fTAlarmDelayFlowMeter"))
                    {
                        tagsData.DataType = "FLOAT";

                    }
                }
            }
            this.ViewBag.HasPumps = false;
            if (controllerSetupService.IsSetupAdvanceDataExist(3, controllerId, EcolabAccountNumber))
            {
                this.ViewBag.HasPumps = true;
            }
            if (tagModel != null)
            {
                tagModel.tagManagementWebModel.Where(t => t.EntityType.Equals("[TCD].[ControllerEquipmentSetup]") && t.OriginalColumnName.ToLower().Equals("kfactor")).ToList().ForEach(_ => _.ConduitValue = Convert.ToString(Convert.ToDecimal(_.ConduitValue) / factorsMulti));
                tagModel.tagManagementWebModel.Where(t => t.EntityType.Equals("[TCD].[ControllerEquipmentSetup]") && t.OriginalColumnName.ToLower().Equals("kfactor")).ToList().ForEach(_ => _.PLCValue = Convert.ToString(Convert.ToDecimal(_.PLCValue) / factorsMulti));

                tagModel.tagManagementWebModel.Where(t => t.EntityType.Equals("[TCD].[ControllerEquipmentSetup]") && t.OriginalColumnName.ToLower().Equals("pumpcalibration")).ToList().ForEach(_ => _.ConduitValue = Convert.ToString(Convert.ToDecimal(_.ConduitValue) / ounceSecMulti));
                tagModel.tagManagementWebModel.Where(t => t.EntityType.Equals("[TCD].[ControllerEquipmentSetup]") && t.OriginalColumnName.ToLower().Equals("pumpcalibration")).ToList().ForEach(_ => _.PLCValue = Convert.ToString(Convert.ToDecimal(_.PLCValue) / ounceSecMulti));
            }
            if (plcDiscrepancyData != null)
            {
                foreach (var plcDiscrepancyModel in plcDiscrepancyData)
                {
                    if (!valDiffEntities.Contains(Convert.ToString(plcDiscrepancyModel.EntityId)))
                    {
                        this.plcService.DeletePlcDiscrepancy(AutoMapper.Mapper.Map<PLCDiscrepancyModel, Ecolab.Models.Common.PLCDiscrepancyModel>(plcDiscrepancyModel));
                    }
                }
            }
            return tagModel;
        }
        /// <summary>
        ///     sending data from UI to PLC 
        /// </summary>
        /// <param name="tagValues">Tags with Values</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="plcDiscrepancyData">The PLC Discrepancy data</param>
        /// <returns>
        ///     Return Responcse of Success
        /// </returns>
        [HttpPost]
        public void SendSettingstoPLC(List<OpcTag> tagValues, int controllerId, List<PLCDiscrepancyModel> plcDiscrepancyData)
        {
            try
            {
                List<PLCDiscrepancyModel> objPlcDiscrepancyModels = new List<PLCDiscrepancyModel>();
                int userId = this.GetCurrentUser().UserId;
                Ecolab.Models.ControllerSetup.Controller controllerInfo = this.controllerSetupService.GetControllerDetailById(controllerId, this.EcolabAccountNumber);
                List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, 1);
                var factorsMulti = (Int32)Convert.ToDecimal(controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Factors Multiplier").FirstOrDefault().FieldDefaultValue).FirstOrDefault().ToString());
                var ounceSecMulti = (Int32)Convert.ToDecimal(controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "OZ/Second Multiplier").FirstOrDefault().FieldDefaultValue).FirstOrDefault().ToString());
                if (tagValues != null)
                {
                    Models.TagManagementModel data = new Models.TagManagementModel();
                    tagValues.Where(x => x.TagType == "STRING").Each(_ => _.TagItemType = UIInputType.TypeString);
                    tagValues.Where(x => x.TagType == "INT").Each(_ => _.TagItemType = UIInputType.TypeInt);
                    tagValues.Where(x => x.TagType == "FLOAT").Each(_ => _.TagItemType = UIInputType.TypeFloat);
                    tagValues.Where(x => x.TagType == "BOOL").Each(_ => _.TagItemType = UIInputType.TypeBool);

                    if (controllerInfo.ControllerTypeId == 1)
                    {
                        foreach (var item in tagValues)
                        {
                            if (item.Value.Trim().ToLower() == "true")
                                item.Value = "1";
                            if (item.Value.Trim().ToLower() == "false")
                                item.Value = "0";
                        }
                    }
                    foreach (var item in tagValues)
                    {
                        if (item.Topic.ToUpper().Contains("TIME VOLUME CALIBRATION"))
                        {
                            item.Value = Convert.ToString(Convert.ToInt32((Convert.ToDecimal(item.Value) * ounceSecMulti)));
                        }

                        if (item.Topic.ToUpper().Contains("K-FACTOR"))
                        {
                            item.Value = Convert.ToString(Convert.ToInt32((Convert.ToDecimal(item.Value) * factorsMulti)));
                        }
                    }

                    data.PlcTags = tagValues;
                    data.ControllerId = Convert.ToInt32(controllerId);
                    this.WriteToPlc(data);
                    this.Index(controllerId, plcDiscrepancyData);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }
        }

        /// <summary>
        ///     Write values to PLC
        /// </summary>
        /// <param name="data">Tag Management Data</param>
        private void WriteToPlc(Models.TagManagementModel data)
        {
            var plc = new PlcTagController(this.plcService, this.UserService, this.PlantService);
            plc.WriteTags(new TagCollection { Tags = new List<Tag>(data.PlcTags) }, data.ControllerId);
        }

    }
}