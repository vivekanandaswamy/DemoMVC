﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualInput Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.ConduitLocal.Web.Models.ManualInput;
    using Ecolab.ConduitLocal.Web.Models.ManualInput.Batch;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup;
    using Ecolab.Models.ManualInput;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services.Interfaces.ManualInput;
    using Services.Interfaces;

    [Authorize]
    public class ManualBatchController : BaseController
    {
        /// <summary>
        ///     BatchData Service
        /// </summary>
        private readonly IManualBatchDataService manualBatchDataService;

        /// <summary>
        ///     ProductionData Service
        /// </summary>
        private readonly IManualProductionDataEntryService manualProductionService;

        /// <summary>
        /// ManualBatchController
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        public ManualBatchController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Initializes a new instance of the ManualBatchController class.
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="manualBatchDataService">manualBatchData Service</param>
        /// <param name="manualProductionService">Manual Production Data Service</param>
        public ManualBatchController(IUserService userService, IPlantService plantService, IManualBatchDataService manualBatchDataService, IManualProductionDataEntryService manualProductionService)
            : base(userService, plantService)
        {
            this.manualBatchDataService = manualBatchDataService;
            this.manualProductionService = manualProductionService;
        }

        /// <summary>
        /// The Index method
        /// </summary>
        /// <returns>the default value to load the page</returns>
        public ActionResult Index()
        {
            List<Models.WasherGroup.WasherGroup> washerGroups = this.FetchWasherGroups(this.EcolabAccountNumber);
            string groupIds = string.Join(",", washerGroups.Select(x => x.WasherGroupId));
            ManualBatchViewModel batchModel = LoadDefaultData(groupIds);
            batchModel.WasherGroupList = washerGroups;
            this.GetPageSetupViewBags();
            return this.View(batchModel);
        }

        /// <summary>
        /// FetchWasherGroups
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>list of washer groups</returns>
        public List<Models.WasherGroup.WasherGroup> FetchWasherGroups(string ecolabAccountNumber)
        {
            return Mapper.Map<List<Ecolab.Models.WasherGroup.WasherGroup>, List<Models.WasherGroup.WasherGroup>>(this.manualBatchDataService.FetchBatchWasherGroups(ecolabAccountNumber));
        }

        /// <summary>
        /// FetchWashers
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>list of washers</returns>
        [HttpPost]
        public JsonResult FetchWashers(string groupIds)
        {
            ManualBatchViewModel batchModel = LoadDefaultData(groupIds);
            return new JsonResult { Data = batchModel };
        }

        /// <summary>
        /// LoadDefaultData
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>manual batch view model</returns>
        private ManualBatchViewModel LoadDefaultData(string groupIds)
        {
            if (string.IsNullOrWhiteSpace(groupIds))
            {
                groupIds = null;
            }
            ManualBatchViewModel batchModel = new ManualBatchViewModel();
            batchModel.Washers = Mapper.Map<List<MachineSetup>, List<MachineSetupModel>>(this.manualBatchDataService.FetchWashersByGroupId(groupIds, this.EcolabAccountNumber));
            var firstWasher = batchModel.Washers.DefaultIfEmpty(new MachineSetupModel()).FirstOrDefault();
            batchModel.RowsCount = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            string firstWasherGroupId = firstWasher.MachineID.ToString();

            batchModel.Formulas = FetchWasherGroupFormulas(firstWasherGroupId);
            batchModel.WasherId = firstWasher.MachineID;
            int pageNumber = 1;
            int formulaId = batchModel.ProgramId;
            List<ManualBatchDataModel> batchList = Mapper.Map<List<Ecolab.Models.ManualInput.ManualBatchData>, List<Models.ManualInput.Batch.ManualBatchDataModel>>
               (this.manualBatchDataService.FetchDispencerRecordedLoads(groupIds, batchModel.WasherId, formulaId, DateTime.Now.Date, this.EcolabAccountNumber, batchModel.RowsCount, pageNumber));

            if (batchList.Count > 0)
            {
                batchModel.BatchList = batchList;
                batchModel.TotalRows = batchList[0].TotalRows;
            }

            batchModel.StartDate = DateTime.Now;
            batchModel.StartDateText = Convert.ToString(DateTime.Now);
            return batchModel;
        }

        /// <summary>
        /// FetchWasherGroupFormulas
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>list of washer group formula</returns>
        public List<WashProgramSetupModel> FetchWasherGroupFormulas(string groupIds)
        {
            ManualBatchViewModel batchModel = new ManualBatchViewModel();
            batchModel.Formulas = Mapper.Map<List<WashProgramSetup>, List<WashProgramSetupModel>>(this.manualBatchDataService.FetchFormulasByGroupId(groupIds, this.EcolabAccountNumber));
            return batchModel.Formulas;
        }

        /// <summary>
        /// FetchWasherGroupFormulasOnWasherChange
        /// </summary>
        /// <param name="groupIds">groupIds</param>
        /// <returns>list of formulas on washer change</returns>
        [HttpPost]
        public JsonResult FetchWasherGroupFormulasOnWasherChange(string groupIds)
        {
            ManualBatchViewModel batchModel = new ManualBatchViewModel();
            batchModel.Formulas = Mapper.Map<List<WashProgramSetup>, List<WashProgramSetupModel>>(this.manualBatchDataService.FetchFormulasByGroupId(groupIds, this.EcolabAccountNumber));
            return new JsonResult { Data = batchModel.Formulas };
        }

        /// <summary>
        /// FetchBatchData
        /// </summary>
        /// <param name="groupId">groupId</param>
        /// <param name="washerId">washerId</param>
        /// <param name="programId">programId</param>
        /// <param name="startDate">startDate</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>list of manual batch data</returns>
        public List<ManualBatchDataModel> FetchBatchData(string groupId, int washerId, int programId, DateTime startDate, string ecolabAccountNumber, int pageNumber)
        {
            int rowsPerPage = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            return (Mapper.Map<List<Ecolab.Models.ManualInput.ManualBatchData>, List<Models.ManualInput.Batch.ManualBatchDataModel>>
                (this.manualBatchDataService.FetchBatchData(groupId, washerId, programId, startDate.ToUniversalTime(), ecolabAccountNumber, rowsPerPage, pageNumber)));

        }

        /// <summary>
        /// Update manual batch data details
        /// </summary>
        /// <param name="manualBatchViewModel">The manual batch view model.</param>
        /// <returns>
        /// updated batch data
        /// </returns>
        [HttpPost]
        public ActionResult UpdateManualBatch(ManualBatchViewModel manualBatchViewModel)
        {
            manualBatchViewModel.RowsCount = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            int userId = this.GetCurrentUser().UserId;

            List<Ecolab.Models.ManualInput.ManualBatchData> batchDataList = Mapper.Map<List<ManualBatchDataModel>, List<Ecolab.Models.ManualInput.ManualBatchData>>(manualBatchViewModel.BatchList);
            string status = this.manualBatchDataService.UpdateManualBatch(batchDataList, this.EcolabAccountNumber, userId);
            
            Push.PushToQueue(batchDataList, userId, 1, (int)TcdAdminMessageTypes.TcdUpdateManualBatch, this.EcolabAccountNumber);
            
            manualBatchViewModel.ErrorMessage = "Successfully updated.";
            return PartialView("_ManualBatchMessage", manualBatchViewModel);
        }

        /// <summary>
        /// GetBatchDataByFilters
        /// </summary>
        /// <param name="manualBatchViewModel">manualBatchViewModel</param>
        /// <returns>the index with model</returns>
        [HttpPost]
        public ActionResult GetBatchDataByFilters(ManualBatchViewModel manualBatchViewModel)
        {
			//manualBatchViewModel.StartDate = !string.IsNullOrWhiteSpace(manualBatchViewModel.StartDateText) ? DateTime.Parse(manualBatchViewModel.StartDateText) : manualBatchViewModel.StartDate;
            manualBatchViewModel.RowsCount = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["RowsPerPage"]);
            manualBatchViewModel.BatchList = new List<ManualBatchDataModel>();
            if (manualBatchViewModel.WasherGroupId != null)
            {
                string groupId = string.Join(",", manualBatchViewModel.WasherGroupId);
                DateTime date = DateTime.Parse(manualBatchViewModel.StartDateText) == DateTime.MinValue ? DateTime.Now.ToUniversalTime() : DateTime.Parse(manualBatchViewModel.StartDateText);                                
                List<ManualBatchDataModel> batchList = Mapper.Map<List<Ecolab.Models.ManualInput.ManualBatchData>, List<Models.ManualInput.Batch.ManualBatchDataModel>>
                         (this.manualBatchDataService.FetchDispencerRecordedLoads(groupId, manualBatchViewModel.WasherId, manualBatchViewModel.ProgramId, date, this.EcolabAccountNumber, manualBatchViewModel.RowsCount, manualBatchViewModel.PageNumber));
                if (batchList.Count > 0)
                {
                    manualBatchViewModel.BatchList = batchList;
                    manualBatchViewModel.TotalRows = batchList[0].TotalRows;
                }
            }

            manualBatchViewModel.ErrorMessage = string.Empty;
            this.GetPageSetupViewBags();
            return PartialView("_ManualBatch", manualBatchViewModel);
        }
    }
}