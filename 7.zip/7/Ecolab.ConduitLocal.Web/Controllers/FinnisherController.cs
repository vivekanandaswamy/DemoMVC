﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class FinnisherController : BaseController
    {
        public FinnisherController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}