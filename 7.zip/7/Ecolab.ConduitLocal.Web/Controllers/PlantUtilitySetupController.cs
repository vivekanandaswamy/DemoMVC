﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilitySetupController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Web.Mvc;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Elmah;
    using log4net.Core;
    using Mapper;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    public class PlantUtilitySetupController : BaseController
    {
        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantUtilityService PlantUtilityService;

        private readonly IPlantUtilityService utilityService;

        public PlantUtilitySetupController(IPlantUtilityService utilityService, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.utilityService = utilityService;
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
			ViewBag.IsCentral = "No";
            return this.View();
        }

        /// <summary>
        ///     The plant Utility Setup save
        /// </summary>
        /// <param name="plantUtilitySetupModel">Save the plant  Utility Setup details</param>
        /// <returns>returns the action result</returns>
        [HttpPost]
        public ActionResult Save(PlantUtilitySetupModel plantUtilitySetupModel)
        {
            try
            {
                PlantUtilitySetup objPlantUtilitySetup = EntityConverter.ConvertToServiceModel(plantUtilitySetupModel);
                User user = this.GetCurrentUser();
            }
            catch(Exception ex)
            {
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Json(false, JsonRequestBehavior.AllowGet);
            }
            return this.Json(true, JsonRequestBehavior.AllowGet);
        }
    }
}