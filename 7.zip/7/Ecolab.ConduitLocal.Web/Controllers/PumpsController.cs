﻿// -----------------------------------------------------------------------
// <copyright file="PumpsController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PumpsController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class PumpsController.
    /// </summary>
    public class PumpsController : BaseController
    {
        // GET: /Pumps/
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public PumpsController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Indexes this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Index()
        {
            string controllerId = this.Request.QueryString.Get("ControllerId");
            string controllerModelId = this.Request.QueryString.Get("ControllerModelId");
            string controllerTypeId = this.Request.QueryString.Get("ControllerTypeId");
            if(!string.IsNullOrEmpty(controllerId))
            {
                this.ViewBag.ControllerId = controllerId;
                this.ViewBag.ControllerModelId = controllerModelId;
                this.ViewBag.ControllerTypeId = controllerTypeId;
            }
            else
            {
                this.ViewBag.ControllerId = "-1";
                this.ViewBag.ControllerModelId = "-1";
                this.ViewBag.ControllerTypeId = "-1";
            }
            this.ViewBag.IsCentral = "No";
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}