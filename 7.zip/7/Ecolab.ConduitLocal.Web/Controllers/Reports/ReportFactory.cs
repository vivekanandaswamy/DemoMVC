﻿// -----------------------------------------------------------------------
// <copyright file="ReportFactory.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportFactory </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using Services.Interfaces.Reports;
    using Services.Reports;

    public static class ReportFactory
    {
        public static IReportService CreateService(int reportType)
        {
            switch (reportType)
            {
                case (int)ReportType.AlarmSummary:
                    return new AlarmSummaryReportService();
                case (int)ReportType.AlarmDetails:
                    return new AlarmReportService();

                case (int)ReportType.ProductionSummary:
                    return new ProductionSummaryReportService();
                case (int)ReportType.ChemicalConsumption:
                    return new ChemicalConsumptionService();
                case (int)ReportType.UserLog:
                    return new UserLogService();
                case (int)ReportType.ProductionMix:
                    return new ProductionMixReportService();
                case (int)ReportType.OperationsSummary:
                    return new OperationsSummaryService();
                case (int)ReportType.ChemicalInventory:
                    return new ChemicalInventoryReportService();
                default:
                    throw new NotImplementedException();
            }
        }
    }

    public enum ReportType
    {
        AlarmSummary = 12,
        AlarmDetails = 13,
        ProductionSummary = 1,
        ChemicalConsumption = 5,
        UserLog = 30,
        ProductionMix = 2,
        OperationsSummary = 10,
        ChemicalInventory = 6
    }
}