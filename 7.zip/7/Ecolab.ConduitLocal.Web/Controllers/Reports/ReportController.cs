﻿// -----------------------------------------------------------------------
// <copyright file="ReportController.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Controller class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Microsoft.Ajax.Utilities;
    using Services.Interfaces;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using ServiceModel = Ecolab.Models.Reports;
    using webModel = Models.Reports;

    [Authorize]
    public class ReportController : BaseController
    {
        private readonly IReportSubView reportSubViewService = new ReportSubViewService();

        /// <summary>
        ///     IRibbonOptionService
        /// </summary>
        /// <value>RibbonOptionService interface type object</value>
        private readonly IRibbonOptionService ribbonOptionService;

        /// <summary>
        ///     LocalReports
        /// </summary>
        /// <value>LocalReports object</value>
        private readonly webModel.LocalReports modelLocalReports = new webModel.LocalReports();

        /// <summary>
        ///     IReportCategoryService
        /// </summary>
        /// <value>ReportCategoryService Interface type object</value>
        private readonly IReportCategoryService reportCategoryService;

        /// <summary>
        ///     LocalReports
        /// </summary>
        /// <value>ReportModel object</value>
        private webModel.ReportModel reportWebModel = new webModel.ReportModel();

        /// <summary>
        ///     IReportService
        /// </summary>
        /// <value>ReportService interface type object</value>
        private IReportService modelReportService;

        /// <summary>
        ///     Report Controller Constructor
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        /// <param name="rptribbonOptionService"></param>
        /// <param name="reportCategoryService"></param>
        /// <param name="productionMixReportService"></param>
        /// <param name="reportSubView"></param>
        public ReportController(IUserService userService, IPlantService plantService, IRibbonOptionService rptribbonOptionService, IReportCategoryService reportCategoryService, IProductionMixReportService productionMixReportService, IReportSubView reportSubView)
            : base(userService, plantService)
        {
            this.reportCategoryService = reportCategoryService;
            ribbonOptionService = rptribbonOptionService;
            reportSubViewService = reportSubView;
        }

        /// <summary>
        ///     Loading Report Layout Pages and Landing page
        /// </summary>
        /// <returns>View</returns>
        [HttpGet]
        public ActionResult Index(string id = "1")
        {
            int reportId = Convert.ToInt32(id);
            SetReportLeftNavAndSettings(reportId);
            GetRibbon(reportWebModel.ReportSettingsModel);
            GetReportDetails(reportWebModel.ReportSettingsModel.ReportId);
            GetPageSetupViewBags();
            return View("Index", reportWebModel);
        }

        /// <summary>
        /// To load portlets
        /// </summary>
        /// <param name="id">report id</param>
        /// <returns>returns chart</returns>
        [HttpGet]
        public ActionResult GetPortlets(int id)
        {
            try
            {
                var flag = false;
                SetReportLeftNavAndSettings(id);
                GetRibbon(reportWebModel.ReportSettingsModel);
                GetReportDetails(reportWebModel.ReportSettingsModel.ReportId);
                GetPageSetupViewBags();

                if (reportWebModel.ReportGridAndChartModel.ChartModel.ChartData.ChartType.ToLower() == "column")
                {
                    var items = reportWebModel.ReportGridAndChartModel.ChartModel.ChartData.series.seriesData.Where(x => x.data.Count > 0);
                    if (!items.Any())
                    {
                        flag = true;
                    }
                    else
                    {
                        var operationSummyItems = items.Select(x => x.data.Count(a => a.y != 0));
                        if (!operationSummyItems.Any(x => x > 0))
                        {
                            flag = true;
                        }
                    }
                }
                else if (reportWebModel.ReportGridAndChartModel.ChartModel.ChartData.ChartType.ToLower() == "pie")
                {
                    if (reportWebModel.ReportGridAndChartModel.ChartModel.ChartData.series.seriesData.All(x => x.y == 0))
                    {
                        flag = true;
                    }
                }
                if (flag)
                {
                    return Content("<b>No data to display the chart</b>");
                }
                return PartialView("_ReportChartView", reportWebModel);
            }
            catch
            {
                return Content("<b>Report not Configured for this user</b>");
            }
        }

        /// <summary>
        ///     Sets the report left navigation and settings.
        /// </summary>
        /// <param name="reportId">The report identifier.</param>
        private void SetReportLeftNavAndSettings(int reportId)
        {
            List<ServiceModel.Report> reportLayout = reportCategoryService.FetchReports(GetCurrentUser().Roles.Select(i => i.RoleId).Max(), GetCurrentUser().LanguageId);
            List<webModel.ReportLayoutModel> reportModels = Mapper.Map<List<ServiceModel.Report>, List<webModel.ReportLayoutModel>>(reportLayout).ToList();

            var centralReports = GetDataForReport(reportModels);
            reportWebModel.ReportLayoutModel = centralReports;
            var report = centralReports.Reports.Where(p => p.ReportId == reportId).Select(i => i).FirstOrDefault();
            //This is should be called only  on landing report loads - one time calling
            var reportSettings = GetReportBasicSettings(report);
            reportWebModel.ReportSettingsModel = reportSettings;
        }

        /// <summary>
        ///     This method will be called when user selects a report from ReportNavigation Menu.
        /// </summary>
        /// <param name="id">ReportId</param>
        /// <returns>Chart,Grid and Ribbon partial views as Json</returns>
        [HttpGet]
        public JsonResult GetReport(int id)
        {
            SetReportLeftNavAndSettings(id);
            GetRibbon(reportWebModel.ReportSettingsModel);
            GetReportDetails(reportWebModel.ReportSettingsModel.ReportId);

            return GetReporDataInJson();
        }

        /// <summary>
        ///     This method will be called when user selects a ribbon option.
        /// </summary>
        /// <param name="model">Report Model</param>
        /// <returns>Chart,Grid partial views as Json</returns>
        [HttpPost]
        public JsonResult UpdateReport(webModel.ReportModel model)
        {
            reportWebModel = model;
            reportWebModel.ReportSettingsModel.SubView = Enum.GetName(typeof(ServiceModel.ReportSubViewEnum), reportWebModel.ReportSettingsModel.SubViewId);

            GetReportDetails(reportWebModel.ReportSettingsModel.ReportId);
            if (model.ReportSettingsModel.IsLinkingReport == true)
            {
                GetRibbon(model.ReportSettingsModel);
            }

            return GetReporDataInJson();
        }
        /// <summary>
        ///     This method will be called to get report data.
        /// </summary>
        /// <returns>Chart,Grid partial views as Json</returns>
        private JsonResult GetReporDataInJson()
        {
            var ribbonPartialView = RenderPartialViewToString("_ReportRibbonView", reportWebModel);
            var tablePartialView = RenderPartialViewToString("_ReportTableView", reportWebModel);
            var chartPartialView = RenderPartialViewToString("_ReportChartView", reportWebModel);

            var reportData = Json(new
            {
                reportModel = reportWebModel,
                ribbonPartialView,
                tablePartialView,
                chartPartialView
            }, JsonRequestBehavior.AllowGet);
            return reportData;
        }

        /// <summary>
        ///     Renders PartialView To String
        /// </summary>
        /// <param name="viewName">The viewName</param>
        /// <param name="model">The model</param>
        /// <returns>String</returns>
        protected string RenderPartialViewToString(string viewName, object model)
        {
            if (string.IsNullOrEmpty(viewName))
            {
                viewName = ControllerContext.RouteData.GetRequiredString("action");
            }

            ViewData.Model = model;

            using (StringWriter sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                ViewContext viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);

                return sw.GetStringBuilder().ToString();
            }
        }

        /// <summary>
        /// This method converts partial view to string
        /// </summary>
        /// <param name="controllerContext">ControllerContext</param>
        /// <param name="viewName">View Name</param>
        /// <param name="model">Report Model</param>
        /// <returns>partial in string format</returns>
        private static String RenderRazorViewToString(ControllerContext controllerContext, string viewName, Object model)
        {
            controllerContext.Controller.ViewData.Model = model;

            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(controllerContext, viewName);
                var viewContext = new ViewContext(controllerContext, viewResult.View, controllerContext.Controller.ViewData, controllerContext.Controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(controllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        /// <summary>
        ///     All report Data
        /// </summary>
        /// <param name="reportModels"></param>
        /// <returns>Model Data for the Report (Categories,Subcategories,Reports)</returns>
        private webModel.LocalReports GetDataForReport(List<webModel.ReportLayoutModel> reportModels)
        {
            modelLocalReports.ReportCategories = new List<webModel.ReportCategoriesModel>();
            modelLocalReports.ReportSubCategories = new List<webModel.ReportSubCategoriesModel>();
            modelLocalReports.Reports = new List<webModel.ReportLayoutModel>();

            GetReportCategories(reportModels);

            GetReportSubCategories(reportModels);
            GetAllReports(reportModels);

            return modelLocalReports;
        }

        /// <summary>
        ///     Get only Report Categories Data
        /// </summary>
        /// <param name="reportModels">All report data</param>
        private void GetReportCategories(IEnumerable<webModel.ReportLayoutModel> reportModels)
        {
            var categories = from element in reportModels
                             group element by element.ReportCategoryId
                                 into groups
                             select groups.First();

            foreach (var item in categories)
            {
                var cat = new webModel.ReportCategoriesModel
                {
                    ReportCategoryId = item.ReportCategoryId,
                    CategoryName = item.ReportCategoryName
                };

                modelLocalReports.ReportCategories.Add(cat);
            }
        }

        /// <summary>
        ///     Get only Report SubCategories Data
        /// </summary>
        /// <param name="reportModels">All report data</param>
        private void GetReportSubCategories(IEnumerable<webModel.ReportLayoutModel> reportModels)
        {
            var subcategories = from element in reportModels
                                group element by element.SubCategoryId
                                    into groups
                                select groups.First();

            foreach (var item in subcategories)
            {
                webModel.ReportSubCategoriesModel subCat = new webModel.ReportSubCategoriesModel
                {
                    ReportCategoryId = item.ReportCategoryId,
                    ReportSubCategoryId = item.SubCategoryId,
                    SubCategoryName = item.SubCategoryName
                };
                modelLocalReports.ReportSubCategories.Add(subCat);
            }
        }

        /// <summary>
        ///     Get only Report Data
        /// </summary>
        /// <param name="reportModels">All report data</param>
        private void GetAllReports(IEnumerable<webModel.ReportLayoutModel> reportModels)
        {
            var reportlist = from element in reportModels
                             group element by element.ReportId
                                 into groups
                             select groups.First();

            foreach (var item in reportlist)
            {
                webModel.ReportLayoutModel report = new webModel.ReportLayoutModel
                {
                    SubCategoryId = item.SubCategoryId,
                    ReportId = item.ReportId,
                    ReportName = item.ReportName,
                    DisplayTopRecordsCount = item.DisplayTopRecordsCount,
                    ShowTotal = item.ShowTotal,
                    ShowOthers = item.ShowOthers,
                    ChartType = item.ChartType,
                    PageSize = item.PageSize
                };

                modelLocalReports.Reports.Add(report);
            }
        }

        /// <summary>
        ///     This method construct basic settings for Report
        /// </summary>
        /// <param name="report"></param>
        /// <returns></returns>
        private webModel.ReportSettingsModel GetReportBasicSettings(webModel.ReportLayoutModel report)
        {
            var firstDayOfTheMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

            webModel.ReportSettingsModel modelReportSettings = new webModel.ReportSettingsModel
            {
                DisplayTopRecordsCount = report.DisplayTopRecordsCount,
                ShowOthers = report.ShowOthers,
                ShowTotal = report.ShowTotal,
                ReportId = report.ReportId,
                FromDate = firstDayOfTheMonth,
                ToDate = DateTime.Today,
                IsMonthWise = true,
                IsFormulaWise = false,
                IsViewByTime = true,
                ChartType = report.ChartType,
                ReportName = report.ReportName,
                PageSize = report.PageSize,
                PrevCurrentStandardId = 2, //Current tab in TimeLine
                StandardTimeLineId = 3, //Month tab in TimeLine
                SortDirection = "Desc",
                CurrentPageIndex = 1,
                EcolabAccountNumber = EcolabAccountNumber,
                UserId = GetCurrentUser().UserId,
                UserRegion = GetCurrentUser().RegionId,
                UserLanguageId = GetCurrentUser().LanguageId,
                UserCulture = GetCurrentUser().Locale               
            };
            return modelReportSettings;
        }

        /// <summary>
        ///     Get Details for the report Gridview
        /// </summary>

        private void GetReportDetails(int reportId)
        {
            ViewBag.reportId = reportWebModel.ReportSettingsModel.ReportId;
            modelReportService = ReportFactory.CreateService(reportId);

            var reportSettings = Mapper.Map<webModel.ReportSettingsModel, ServiceModel.ReportSettings>(reportWebModel.ReportSettingsModel);
            ServiceModel.ReportTableAndChart serviceModel = modelReportService.GenerateReport(reportSettings, reportSettings.EcolabAccountNumber);
            webModel.ReportTableAndChartModel model = Mapper.Map<ServiceModel.ReportTableAndChart, webModel.ReportTableAndChartModel>(serviceModel);

            reportWebModel.ReportGridAndChartModel = model;
        }
        /// <summary>
        ///     Set Drill Navigaton
        /// </summary>
        /// <param name="currentView">Current view in context</param>
        /// <param name="model">Model to drilldown</param>
        /// <param name="navigationModel">Navigation Model</param>
        /// <returns>Navigation Model</returns>
        private webModel.NavigationModel SetDrillNavigaton(string currentView, ServiceModel.ReportTableAndChart model, webModel.NavigationModel navigationModel)
        {
            if (!navigationModel.IsUpdated)
            {
                navigationModel.CurrentOptionsList = new List<webModel.OptionsList>();

                foreach (var options in model.DataList.Select(item => new webModel.OptionsList
                {
                    Name = item.Name,
                    Id = item.Id,
                }))
                {
                    navigationModel.CurrentOptionsList.Add(options);
                }
                navigationModel.IsUpdated = true;
            }

            this.ViewBag.Options = navigationModel.PreviousOptionsList;
            this.ViewBag.SelectedOption = navigationModel.SelectedOption;
            if (navigationModel.CurrentViewing != null)
            {
                currentView = navigationModel.CurrentViewing.Aggregate(currentView, (current, view) => current + ">" + view);
                if (!string.IsNullOrEmpty(currentView))
                {
                    currentView = currentView.Remove(currentView.IndexOf('>'), 1).Trim();
                }
            }
            this.ViewBag.CurrentViewing = currentView;
            return navigationModel;
        }

        /// <summary>
        ///     Gets the ribbon.
        /// </summary>
        /// <param name="reportSettings">The report settings.</param>
        private void GetRibbon(webModel.ReportSettingsModel reportSettings)
        {
            List<webModel.RibbonOptionModel> lstRibbonOptions = Mapper.Map<List<ServiceModel.RibbonOption>, List<webModel.RibbonOptionModel>>(this.ribbonOptionService.FetchRibbonOption(reportSettings.ReportId));

            //To do "1" = need to pass plant or region id.
            var ribbonData = this.ribbonOptionService.FetchRibbonOptionDataForReport(reportSettings.ReportId, reportSettings.ViewModeId, this.GetCurrentUser().Roles.Max(x => x.RoleId), this.GetCurrentUser().LanguageId);
            List<webModel.ReportRibbonOptionsModel> reportRibbonData = Mapper.Map<List<ServiceModel.ReportRibbonOptions>, List<webModel.ReportRibbonOptionsModel>>(ribbonData);

            RibbonOptions(lstRibbonOptions, reportRibbonData);

            //This call is get subviews of Time to bind to the Ribbon TimeLine.
            GetSubViewsForTime((int)webModel.ReportViewByEnum.Time, reportSettings.UserLanguageId);
        }
        /// <summary>
        ///     Ribbon Options
        /// </summary>
        /// <param name="lstRibbonOptions">Last Ribbon Options</param>
        /// <param name="reportRibbonData">Report Ribbon Data</param>
        private void RibbonOptions(IEnumerable<webModel.RibbonOptionModel> lstRibbonOptions, List<webModel.ReportRibbonOptionsModel> reportRibbonData)
        {
            reportWebModel.RibbonDetailsModel = new webModel.RibbonDetailsModel();

            foreach (var option in lstRibbonOptions.OrderByDescending(x => x.Id).DistinctBy(_ => _.Id))
            {
                switch (option.Id)
                {
                    case (int)webModel.RibbonOptionsEnum.SwitchCategory:
                        GetChartDisplayMode(reportWebModel.ReportSettingsModel, reportWebModel.RibbonDetailsModel);
                        break;
                    case (int)webModel.RibbonOptionsEnum.AllColumns:
                        GetAllColumnsForReport(reportWebModel.ReportSettingsModel, reportWebModel.RibbonDetailsModel);
                        break;
                    case (int)webModel.RibbonOptionsEnum.ChartDisplayMode:
                        GetChartDisplayMode(reportWebModel.ReportSettingsModel, reportWebModel.RibbonDetailsModel, true);
                        break;
                    case (int)webModel.RibbonOptionsEnum.Filter:
                        GetRibbonFilters(reportRibbonData, reportWebModel.ReportSettingsModel, reportWebModel.RibbonDetailsModel);
                        break;
                    case (int)webModel.RibbonOptionsEnum.StandardAndCustom:
                        reportWebModel.RibbonDetailsModel.StandardAndCustom = true;
                        break;
                    case (int)webModel.RibbonOptionsEnum.ViewBy:
                        GetRibbonViewBy(reportRibbonData, reportWebModel.ReportSettingsModel, reportWebModel.RibbonDetailsModel);
                        break;
                    case (int)webModel.RibbonOptionsEnum.AsOnToday:
                        reportWebModel.RibbonDetailsModel.AsOnToday = true;
                        break;
                }
            }
        }

        /// <summary>
        ///     Extracting Switch Modes for the report to bind it in Ribbon
        /// </summary>
        /// <param name="ribbonData">Ribbon Options Data for the Report</param>
        /// <param name="reportModel">The Report Data</param>
        private void GetSwitchModesForReport(IEnumerable<webModel.ReportRibbonOptionsModel> ribbonData, webModel.ReportModel reportModel)
        {
            var swithces = from element in ribbonData
                           group element by element.SwitchModeId
                               into groups
                           select groups.First();
            reportModel.RibbonDetailsModel.SwitchModes = new List<webModel.ReportSwitchModeModel>();
            foreach (var item in swithces)
            {
                webModel.ReportSwitchModeModel swtch = new webModel.ReportSwitchModeModel
                {
                    Id = item.SwitchModeId,
                    SwitchName = item.SwitchName,
                    IsSelected = item.SwitchName == "Formula"
                };

                if (item.SwitchName == "Formula")
                {
                    reportModel.ReportSettingsModel.SwitchModeId = 1;
                }
                reportModel.RibbonDetailsModel.SwitchModes.Add(swtch);
            }
        }

        /// <summary>
        ///     Extracting All columns for the report to bind it in Ribbon
        /// </summary>
        /// <param name="reportSettings">Filter report settings</param>
        /// <param name="ribbonModel">Ribbon Model</param>
        private void GetAllColumnsForReport(webModel.ReportSettingsModel reportSettings, webModel.RibbonDetailsModel ribbonModel)
        {
            List<webModel.ReportAllColumnsModel> allColumns = Mapper.Map<List<ServiceModel.ReportAllColumns>, List<webModel.ReportAllColumnsModel>>(this.ribbonOptionService.FetchReportAllColumns(
                Mapper.Map<webModel.ReportSettingsModel, ServiceModel.ReportSettings>(reportSettings)));
            var list = allColumns.Where(cl => cl.ViewModeId == reportSettings.ViewModeId && cl.SwitchModeId == reportSettings.SwitchModeId).OrderBy(cl => cl.DisplayOrder).ToList();
            if (reportSettings.ReportId == (int)webModel.ReportEnum.OperationsSummary) { list.RemoveAll(x => x.Id == (int)webModel.ReportColumnsEnum.Costperload); }
            ribbonModel.AllColumns = new List<webModel.ReportAllColumnsModel>();
            foreach (var item in list.Where(x => x.Id != (int)ServiceModel.ReportColumnsEnum.Total && x.Id != (int)ServiceModel.ReportColumnsEnum.Others))
            {
                var ribbonColumns = new webModel.ReportAllColumnsModel
                {
                    Id = item.Id,
                    ColumnName = item.ColumnName + (string.IsNullOrEmpty(item.LocalizedUom) ? string.Empty : "(" + item.LocalizedUom + ")"),
                    IsChartDisplay = item.IsChartDisplay,
                    IsVisible = item.IsVisible,
                    DisplayOrder = item.DisplayOrder,
                    LocalizedName = item.LocalizedName + (string.IsNullOrEmpty(item.LocalizedUom) ? string.Empty : "(" + item.LocalizedUom + ")")
                };
                ribbonModel.AllColumns.Add(ribbonColumns);
            }
            reportWebModel.ReportSettingsModel = reportSettings;
            reportWebModel.RibbonDetailsModel = ribbonModel;
        }

        /// <summary>
        ///     Extracting Chart Display Columns for the report to bind it in Ribbon
        /// </summary>
        /// <param name="reportSettings">Filter report settings</param>
        /// <param name="ribbonModel">Ribbon Model</param>
        /// <param name="isChartDisplayMode">Chart display mode status</param>
        private void GetChartDisplayMode(webModel.ReportSettingsModel reportSettings, webModel.RibbonDetailsModel ribbonModel, bool isChartDisplayMode = false)
        {
            List<webModel.ReportAllColumnsModel> allColumns = Mapper.Map<List<ServiceModel.ReportAllColumns>, List<webModel.ReportAllColumnsModel>>(this.ribbonOptionService.FetchReportAllColumns(Mapper.Map<webModel.ReportSettingsModel, ServiceModel.ReportSettings>(reportSettings)));
            const int switchModeId = 1;
            IEnumerable<webModel.ReportAllColumnsModel> list;
            if (!isChartDisplayMode)
            {
                list =
                   (from cl in allColumns where cl.SwitchModeId == switchModeId orderby cl.DisplayOrder select cl)
                       .ToList().Distinct();
            }
            else
            {
                list =
              (from cl in allColumns where cl.ViewModeId == reportSettings.ViewModeId orderby cl.DisplayOrder select cl)
                  .ToList().Distinct();
            }

            ribbonModel.ChartDisplayMode = new List<webModel.ReportChartDisplayModes>();
            bool flag = false;
            foreach (var item in list)
            {
                webModel.ReportChartDisplayModes display = new webModel.ReportChartDisplayModes();

                if (item.IsChartDisplay)
                {
					item.LocalizedName = string.Concat(item.LocalizedName, " ("+item.LocalizedUom+")");
                    display.ChartDisplayId = item.Id;
                    display.ChartDisplayMode = item.LocalizedName;
                    if (flag == false)
                    {
                        display.IsSelected = true;
                        reportSettings.ChartDisplayId = display.ChartDisplayId;
                        flag = true;
                    }
                    ribbonModel.ChartDisplayMode.Add(display);
                }
            }
            if (reportSettings.ReportId == (int)webModel.ReportEnum.ChemicalConsumption)
            {
                ribbonModel.ChartDisplayMode = ribbonModel.ChartDisplayMode.OrderByDescending(x => x.ChartDisplayId).ToList();
                ribbonModel.ChartDisplayMode.ForEach(x => x.IsSelected = false);
                var reportChartDisplayModes = ribbonModel.ChartDisplayMode.FirstOrDefault(x => x.ChartDisplayId == (int)webModel.ReportColumnsEnum.Costperload);
                if (reportChartDisplayModes != null)
                {
                    reportChartDisplayModes.IsSelected = true;
                    reportSettings.ChartDisplayId = (int)webModel.ReportColumnsEnum.Costperload;
                }
            }
            reportWebModel.ReportSettingsModel = reportSettings;
            reportWebModel.RibbonDetailsModel = ribbonModel;
        }

        /// <summary>
        ///     Extracting  Filters for the report to bind it in Ribbon
        /// </summary>
        /// <param name="ribbonData">Ribbon Options Data for the Report</param>
        /// <param name="reportSettings">The m report settings.</param>
        /// <param name="ribbonModel">The m ribbon model.</param>
        private void GetRibbonFilters(IEnumerable<webModel.ReportRibbonOptionsModel> ribbonData, webModel.ReportSettingsModel reportSettings, webModel.RibbonDetailsModel ribbonModel)
        {
            var filters = from element in ribbonData
                          group element by element.ReportFilterId
                              into groups
                          select groups.First();

            ribbonModel.Filters = new List<webModel.ReportFilterModel>();
            foreach (var item in filters)
            {
                webModel.ReportFilterModel filter = new webModel.ReportFilterModel
                {
                    Id = item.ReportFilterId,
                    FilterName = item.FilterName
                };
                ribbonModel.Filters.Add(filter);
            }
            this.reportWebModel.ReportSettingsModel = reportSettings;
            this.reportWebModel.RibbonDetailsModel = ribbonModel;

            //New Filters Code
            var filtersList = this.ribbonOptionService.GetFilters(reportSettings.ReportId, this.GetCurrentUser().UserId, this.GetCurrentUser().Roles.Select(i => i.RoleId).Max(), true, this.GetCurrentUser().LanguageId);
            var reportFilters = Mapper.Map<List<ServiceModel.Filter>, List<webModel.FilterModel>>(filtersList);
            var rfilters = new webModel.FiltersModel
            {
                ReportFilters = reportFilters
            };
            reportWebModel.Filters = rfilters;
        }

        /// <summary>
        ///     Extracting ViewBy options for the report to bind it in Ribbon
        /// </summary>
        /// <param name="ribbonData">Ribbon Options Data for the Report</param>
        /// <param name="modelReportSettings">The Report Options</param>
        /// <param name="modelRibbonModel">Ribbon Details Model</param>
        private void GetRibbonViewBy(IEnumerable<webModel.ReportRibbonOptionsModel> ribbonData, webModel.ReportSettingsModel modelReportSettings, webModel.RibbonDetailsModel modelRibbonModel)
        {
            var viewBy = from element in ribbonData
                         group element by element.ViewModeId
                             into groups
                         select groups.First();

            modelRibbonModel.ViewMode = new List<webModel.ReportViewModel>();

            foreach (var item in viewBy)
            {
                var view = new webModel.ReportViewModel
                {
                    ViewModeName = item.ViewModeName,
                    ViewModeId = item.ViewModeId,
                    SubViewName = item.SubViewName,
                    SubViewId = item.SubViewId,
                    ChartType = item.ChartType
                };

                if (item.IsDefault)
                {
                    modelReportSettings.ViewType = item.ViewModeName;
                    modelReportSettings.SubViewId = item.SubViewId;
                    modelReportSettings.ViewModeId = item.ViewModeId;
                    modelReportSettings.SubView = item.SubViewName;
                    modelReportSettings.HasGroupBy = item.HasGroupBy;

                    view.IsSelected = true;
                }

                modelRibbonModel.ViewMode.Add(view);
            }
            reportWebModel.ReportSettingsModel = modelReportSettings;
            reportWebModel.RibbonDetailsModel = modelRibbonModel;
        }
        /// <summary>
        ///     Get Sub Views For Time in report dibbon for standard time display
        /// </summary>
        /// <param name="viewModeId">Ribbon Options Data for the Report</param>
        /// <param name="languageId">The Report Options</param>
        private void GetSubViewsForTime(int viewModeId, int languageId)
        {
            List<ServiceModel.ReportSubView> timeSubviews = reportSubViewService.FetchSubViewsForView(viewModeId, languageId);
            reportWebModel.RibbonDetailsModel.TimeLineSubView = Mapper.Map<List<ServiceModel.ReportSubView>, List<webModel.ReportSubView>>(timeSubviews);
            var subViews = reportWebModel.RibbonDetailsModel.TimeLineSubView.OrderBy(i => i.SubViewId).Take((int)webModel.ReportSubViewByEnum.Day);
            reportWebModel.RibbonDetailsModel.TimeLineSubView = subViews.OrderByDescending(i => i.SubViewId).ToList();
        }

        /// <summary>
        ///     Gets the filter dropdown data by identifier.
        /// </summary>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="countryId">The country identifier.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="machinType">Type of the machine.</param>
        /// <param name="machinGroup">The machine group.</param>
        /// <param name="typeId">The Type Id</param>
        /// <returns> Filter dropdown data in JsonResult format</returns>
        [HttpPost]
        public JsonResult GetFilterDropdownDataById(int reportId, string regionId, string countryId, string plantId, string machinType, string machinGroup, string typeId)
        {
            var machintypeIds = machinType.Split(',');
            if (machintypeIds.Count() > 1)
            {
                if (machintypeIds.Contains("3") || (machintypeIds.Contains("1") && machintypeIds.Contains("2")))
                {
                    machinType = "3";
                }
            }
            var data = ribbonOptionService.GetFilterDropdownDataById(reportId, machinType, machinGroup, Convert.ToInt32(typeId), GetCurrentUser().UserId, GetCurrentUser().Roles.Select(i => i.RoleId).Max(), true);
            var dropDownData = Mapper.Map<List<ServiceModel.SelectList>, List<webModel.SelectListModel>>(data);
            return Json(new
            {
                dropDownData
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        ///     Gets the countries.
        /// </summary>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="isCountry">The is country.</param>
        /// <returns>Categories in JsonResult format</returns>
        [HttpPost]
        public JsonResult GetCountries(int reportId, string isCountry)
        {
            var data = ribbonOptionService.GetFilterDropdownDataById(reportId, string.Empty, string.Empty, 2, GetCurrentUser().UserId, GetCurrentUser().Roles.Select(i => i.RoleId).Max(), true);
            var dropDownData = Mapper.Map<List<ServiceModel.SelectList>, List<webModel.SelectListModel>>(data);
            return Json(new
            {
                dropDownData
            }, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        ///     Get otional filter data based on the typeid
        /// </summary>
        /// <param name="typeId">The type id</param>
        /// <returns>Optional Filter Data in JsonResult format</returns>
        [HttpPost]
        public JsonResult GetOptionalFilterData(int typeId)
        {
            var data = ribbonOptionService.GetOptionalFilterData(typeId);
            var dropDownData = Mapper.Map<List<ServiceModel.SelectList>, List<webModel.SelectListModel>>(data);
            return Json(new
            {
                dropDownData
            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        ///     This method will return updated partial views.
        /// </summary>
        /// <param name="model">Report Model</param>
        /// <returns>updated Chart,Grid partial views as Json</returns>
        [HttpPost]
        public JsonResult LinkUpdateReport(webModel.ReportModel model)
        {
            return UpdateReport(model);
        }
    }
}