﻿// -----------------------------------------------------------------------
// <copyright file="MeterController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MeterController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Linq;
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.PlantSetup;

    [Authorize]
    public class MeterController : BaseController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly IControllerSetupService controllerSetupService;

        /// <summary>
        /// </summary>
        private readonly IMeterService meterService;

        /// <summary>
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        /// <param name="meterService"></param>
        public MeterController(IUserService userService, IPlantService plantService, IMeterService meterService, IControllerSetupService controllerSetupService) : base(userService, plantService)
        {
            this.meterService = meterService;
            this.controllerSetupService = controllerSetupService;
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.ControllerCount = this.controllerSetupService.GetControllerDetails(this.EcolabAccountNumber).ToList().Count;
            this.ViewBag.IsCentral = "No";
            return this.View();
        }
    }
}