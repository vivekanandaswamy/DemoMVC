﻿// -----------------------------------------------------------------------
// <copyright file="ManualInputLaborController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualInput Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     class ManualInputLaborController
    /// </summary>
    public class ManualInputLaborController : BaseController
    {
        /// <summary>
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        public ManualInputLaborController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}