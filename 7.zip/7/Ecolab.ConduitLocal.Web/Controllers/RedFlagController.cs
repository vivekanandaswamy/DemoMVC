﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class RedFlagController : BaseController
    {
        /// <summary>
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        public RedFlagController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}