﻿// -----------------------------------------------------------------------
// <copyright file="FormulaController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class FormulaController : BaseController
    {
        public FormulaController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Meter Service
        /// </summary>
        /// <returns> action result.</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}