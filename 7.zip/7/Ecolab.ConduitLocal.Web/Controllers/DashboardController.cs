﻿// -----------------------------------------------------------------------
// <copyright file="DashboardController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dashboard Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Configuration;
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Dashboard Controller
    /// </summary>
    [Authorize]
    public class DashboardController : BaseController
    {
        private readonly IAlarmService alarmService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="DashboardController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        public DashboardController(IUserService userService, IPlantService plantService, IAlarmService alarmService) : base(userService, plantService)
        {
            this.alarmService = alarmService;
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.VisualizationUrl = (new AppSettingsReader()).GetValue("VisualizationUrl", typeof(string)).ToString();
            return this.View();
        }
    }
}