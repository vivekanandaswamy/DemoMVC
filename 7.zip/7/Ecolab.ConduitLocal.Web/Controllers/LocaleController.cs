﻿// -----------------------------------------------------------------------
// <copyright file="LocaleController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Locale Controller  </summary>
// -----------------------------------------------------------------------

using System.Web.UI.WebControls;
using Ecolab.Models;

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using Entities;
    using Mapper;
    using Models;
    using Services.Interfaces;
    using LanguageMaster = LanguageMaster;
    using Plant = Plant;

    /// <summary>
    ///     class LocaleController
    /// </summary>
   [AllowAnonymous]
    public class LocaleController : BaseController
    {
        /// <summary>
        ///     Localization Data
        /// </summary>
        private Dictionary<string, string> localizationData;

        private Dictionary<string, string> localizationUomData;

        /// <summary>
        ///     Locale Controller
        /// </summary>
        /// <param name="userService">user related service</param>
        /// <param name="plantService">Plant service</param>
        public LocaleController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Property for Localization Data
        /// </summary>
        public Dictionary<string, string> LocalizationData
        {
            get { return localizationData ?? (localizationData = FetchLocalizationData()); }
        }

        public Dictionary<string, string> LocalizationUomData
        {
            get { return localizationUomData ?? (localizationUomData = FetchLocalizationUomData()); }
        }

        /// <summary>
        ///     Get Localization Data
        /// </summary>
        /// <returns>JSON Result</returns>
        //[OutputCache(Duration = 300)]
        public ActionResult GetLocalizationData(string locale = "")
        {
            Dictionary<string, string> data = GetData((GetCurrentUser() == null ? 0: GetCurrentUser().UserId) ,locale);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        ///     Get Localization Data
        /// </summary>
        /// <returns>JSON Result</returns>
        //[OutputCache(Duration = 300)]
        public ActionResult GetUomLocalizationData(string locale = "")
        {
            Dictionary<string, string> data = null;

            List<Locale> dataUom = UserService.GetResourceKeyValuesForUom(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, EcolabAccountNumber);

            if (dataUom != null)
            {
                data = dataUom.ToDictionary(e => e.Key, e => e.Value);
            }

            return Json(data, JsonRequestBehavior.AllowGet);
        }

         /// <summary>
        ///     Gets Localization Data
        /// </summary>
        /// <param name="locale">Language type</param>
        /// <returns>Dictionary of Localization Data</returns>
        public Dictionary<string, string> FetchLocalizationData(string locale = "")
        {
            return GetData(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, locale);
        }

        /// <summary>
        /// Gets Localization Data
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="locale">Language type</param>
        /// <returns>
        /// Dictionary of Localization Data
        /// </returns>
        private Dictionary<string, string> GetData(int userId ,string locale = "" )
        {
            List<Locale> data = null;
            if (string.IsNullOrEmpty(locale))
            {
                Plant plant = PlantService.GetPlantDetails(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId);
                List<LanguageMaster> languages = PlantService.GetLanguageDetails();
                LanguageMasterModel plantLanguage = languages.Select(EntityConverter.ConvertToWebModel).ToList().FirstOrDefault(c => c.LanguageId == plant.LanguageId);
                if (plantLanguage != null)
                {
                    data = UserService.GetResourcesByLocale(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId,plantLanguage.Locale, plant.EcoalabAccountNumber);
                    List<Locale> dataUom = UserService.GetResourceKeyValuesForUom(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, EcolabAccountNumber);
                }
            }
            else
            {
                data = UserService.GetResourcesByLocale(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId,locale, string.Empty);
            }

            if (data == null)
            {
                return null;
            }
            return data.ToDictionary(e => e.Key, e => e.Value);
        }

        /// <summary>
        ///     Get Localized value using the Key
        /// </summary>
        /// <param name="key">Localization Key</param>
        /// <param name="defaultValue">Return string if data is unavailable for the Key</param>
        /// <returns>Localized value</returns>
        public string Localize(string key, string defaultValue)
        {
            return LocalizationData.ContainsKey(key) ? LocalizationData[key] : defaultValue;
        }

        /// <summary>
        /// Localizes the uom.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        public string LocalizeUom(string key, string defaultValue)
        {
            return LocalizationUomData.ContainsKey(key) ? LocalizationUomData[key] : defaultValue;
        }

        /// <summary>
        /// Fetches the localization uom data.
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> FetchLocalizationUomData()
        {
            Dictionary<string, string> data = null;

            var dataUom = UserService.GetResourceKeyValuesForUom(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, EcolabAccountNumber);

            if (dataUom != null)
            {
                data = dataUom.ToDictionary(e => e.Key, e => e.Value);
            }
            return data.ToDictionary(e => e.Key, e => e.Value);
        }
    }
}