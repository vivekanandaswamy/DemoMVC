﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Set up Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.IO;
    using System.Web.Mvc;
    using Castle.Core.Logging;
    using Ecolab.Models;
    using Elmah;
    using Mapper;
    using Models;
    using Services.Interfaces;

    /// <summary>
    ///     Class PlantSetupController
    /// </summary>
    [Authorize]
    public class PlantSetupController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public PlantSetupController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
			this.ViewBag.IsCentral = "No";
            return this.View();
        }

        /// <summary>
        ///     The plant Setup save
        /// </summary>
        /// <param name="plant">Save the plant details</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Save(PlantModel plant)
        {
            try
            {
                Plant objPlant = EntityConverter.ConvertToServiceModel(plant);
                User user = this.GetCurrentUser();
                bool isFolderPathExists = Directory.Exists(objPlant.ExportPath);
                if(!isFolderPathExists)
                {
                    return this.Json("The specified Export path does not exists.Please provide a valid path", JsonRequestBehavior.AllowGet);
                }
                DateTime lastModifiedTimeStamp;
                this.PlantService.SavePlantDetails(objPlant, user.Id, out lastModifiedTimeStamp);
            }
            catch(Exception ex)
            {
                this.Logger.Error("PlantSetup  - Save Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return this.Json(false, JsonRequestBehavior.AllowGet);
            }

            return this.Json(true, JsonRequestBehavior.AllowGet);
        }
    }
}