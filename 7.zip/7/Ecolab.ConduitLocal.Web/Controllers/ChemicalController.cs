﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ChemicalController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    [Authorize]
    public class ChemicalController : BaseController
    {
        /// <summary>
        ///     production Master Service
        /// </summary>
        private readonly IProductMasterService prodMastService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ChemicalController" /> class.
        /// </summary>
        /// <param name="userService">The user Service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="prodMastService">The product Master Service</param>
        public ChemicalController(IUserService userService, IPlantService plantService, IProductMasterService prodMastService) : base(userService, plantService)
        {
            this.prodMastService = prodMastService;
        }
        /// <summary>
        /// Index page.
        /// </summary>
        /// <returns>Action Result Index</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}