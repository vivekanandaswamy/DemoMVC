﻿// -----------------------------------------------------------------------
// <copyright file="ErrorController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Error Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Web.Mvc;
    using Castle.Core.Logging;
    using Models;
    using Shared;

    /// <summary>
    ///     class ErrorController
    /// </summary>
    public class ErrorController : Controller
    {
        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     Indexes the specified error.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns>View contains error description</returns>
        public ActionResult Index(Exception error)
        {
            string m = error.Message;
            string viewName = "Error";
            this.ViewBag.Error = error.Message;
            object message = null;

            if(error.InnerException != null)
            {
                m += " | " + error.InnerException.Message;
            }

            this.ViewBag.Message = m;
            if(this.Request.IsAjaxRequest())
            {
                if(error is ConduitLocalException)
                {
                    viewName = "Expectedp";
                }
                else
                {
                    viewName = "Errorp";
                }
            }

            ConduitLocalException conduitLocalException = error as ConduitLocalException;
            if(conduitLocalException != null)
            {
                if(conduitLocalException.Type == ExceptionType.Cache_Expired)
                {
                    return this.RedirectToAction("Login", "Account");
                }

                viewName = "Expected";
                message = new ErrorModel { Message = error.Message };
            }

            try
            {
                if(this.ViewBag.Message != "Session state has created a session id, but cannot save it because the response was already flushed by the application.")
                {
                }
            }
            catch(ConduitLocalException)
            {
            }

            return message != null ? this.View(viewName, message) : this.View(viewName);
        }

        /// <summary>
        ///     HTTPs the error404.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns>View contains error description</returns>
        public ActionResult HttpError404(Exception error)
        {
            return this.View();
        }

        /// <summary>
        ///     HTTPs the error401.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns>View contains error description</returns>
        public ActionResult HttpError401(Exception error)
        {
            return this.View();
        }

        /// <summary>
        ///     HTTPs the error505.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <returns>View contains error description</returns>
        public ActionResult HttpError505(Exception error)
        {
            return this.View();
        }
    }
}