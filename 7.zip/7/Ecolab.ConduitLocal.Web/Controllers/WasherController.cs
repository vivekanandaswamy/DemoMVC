﻿// -----------------------------------------------------------------------
// <copyright file="WasherController.cs" company="Ecolab">
// This web controller is for Washer.
// </copyright>
// <summary>The Washer is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.Washers;

    public class WasherController : BaseController
    {
        /// <summary>
        ///     Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washers.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public WasherController(IWasherServices washerServices, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     This action method is for loading the washer view.
        /// </summary>
        /// <returns>Washer view.</returns>
        public ActionResult Index()
        {
            string massage = this.Request.QueryString.Get("Massage");
            if(!string.IsNullOrEmpty(massage))
            {
                this.ViewBag.Massage = massage;
            }
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}