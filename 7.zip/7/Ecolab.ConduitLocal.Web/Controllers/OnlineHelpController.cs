﻿// -----------------------------------------------------------------------
// <copyright file="OnlineHelpController.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Online Help Controller</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ecolab.Services.Interfaces;

namespace Ecolab.ConduitLocal.Web.Controllers
{
    public class OnlineHelpController : BaseController
    {
        /// <summary>
        /// Online Help Controller Constructor
        /// </summary>
        /// <param name="userService">user service parameter</param>
        /// <param name="plantService">plant service parameter</param>
        public OnlineHelpController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.IsCentral = "No";
            return this.PartialView("_OnlineHelp");
        }
    }
}