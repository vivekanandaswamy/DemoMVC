﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu Controller </summary>
// -----------------------------------------------------------------------
namespace Ecolab.ConduitLocal.Web.Controllers
{
    using Ecolab.Services.Interfaces;
    using System.Web.Mvc;

    /// <summary>
    ///     NavigationMenuController Controller
    /// </summary>
    [Authorize]
    public class NavigationMenuController : BaseController
    {
        public NavigationMenuController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        /// <summary>
        ///      The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            GetPageSetupViewBags();
            return View();
        }
    }
}
