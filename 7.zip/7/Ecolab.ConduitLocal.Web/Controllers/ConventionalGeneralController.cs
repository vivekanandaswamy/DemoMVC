﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneralController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalGeneralController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
	using System;
    using System.Configuration;
    using System.Web.Mvc;
    using Ecolab.Services.Interfaces.Washers.Conventional;
	using Services.Interfaces;

    public class ConventionalGeneralController : BaseController
    {
		public IConventionalGeneralServices ConventionalGeneralServices { get; set; }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ConventionalGeneralController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
		public ConventionalGeneralController(IUserService userService, IPlantService plantService)
			: base(userService, plantService)
        {
        }

        public ConventionalGeneralController(IUserService userService, IPlantService plantService, IConventionalGeneralServices conventionalGeneralServices)
            : base(userService, plantService)
        {
            this.ConventionalGeneralServices = conventionalGeneralServices;
        }

        // GET: /ConventionalGeneral/
        /// <summary>
        ///     Indexes this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Index()
        {
            string conventionalId = this.Request.QueryString.Get("WasherId");
            string washerGroupId = this.Request.QueryString.Get("WasherGroupId");
			string controllerModelId = this.Request.QueryString.Get("controllerModelId");
            int washerGroupTypeId = 1;
            this.GetPageSetupViewBags();
			if (!(string.IsNullOrEmpty(conventionalId) && string.IsNullOrEmpty(washerGroupId)))
            {
                this.ViewBag.ConventionalId = conventionalId;
                this.ViewBag.WasherGroupId = washerGroupId;
                this.ViewBag.WasherGroupTypeId = washerGroupTypeId;
				this.ViewBag.ControllerModelId = controllerModelId;
                this.ViewBag.LfsNumber = ConfigurationManager.AppSettings["LfsWasherNumber"];
                ViewBag.IsCentral = "No";
				string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
				ViewBag.MaxPlantWashNumber = this.ConventionalGeneralServices.GetMaxPlantWasherNumber(ecolabAccountNumber);
				if (conventionalId != null)
				{
					ViewBag.ControllerId = this.ConventionalGeneralServices.GetConventionalData(Convert.ToInt32(conventionalId), Convert.ToInt32(washerGroupId), ecolabAccountNumber).ControllerId; 
				}
            }
            return this.View();
        }
    }
}