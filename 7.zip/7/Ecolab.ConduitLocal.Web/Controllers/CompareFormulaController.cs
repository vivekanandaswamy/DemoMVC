﻿// -----------------------------------------------------------------------
// <copyright file="CompareFormulaController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Web controller for CompareFormulaController</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Castle.Core.Logging;
    using Ecolab.ConduitLocal.Web.Api;
    using Ecolab.ConduitLocal.Web.Models.ControllerSetup;
    using Ecolab.ConduitLocal.Web.Models.ControllerSetup.Pumps;
    using Ecolab.ConduitLocal.Web.Models.WasherGroup;
    using Ecolab.ConduitLocal.Web.Models.Washers;
    using Ecolab.ConduitLocal.Web.Utilities;
    using Ecolab.Dcs.Entities;
    using Ecolab.Models;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Services.ControllerSetup;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Ecolab.Services.Interfaces.ControllerSetup.Pumps;
    using Ecolab.Services.Interfaces.Plc;
    using Ecolab.Services.Interfaces.WasherGroup;
    using Ecolab.Services.Interfaces.Washers;
    using Elmah;
    using Models.Common;
    using Ecolab.Models.Enum;

    /// <summary>
    /// Tagmanagement class
    /// </summary>
    [Authorize]
    public class CompareFormulaController : BaseController
    {
        /// <summary>
        ///     Controller Setup Service
        /// </summary>
        private readonly ICompareFormulaService compareFormulaService;

        /// <summary>
        ///     The PLC Service
        /// </summary>
        private readonly IWasherGroupFormulaService washerGroupFormulaService;

        /// <summary>
        ///     The controller setup Service
        /// </summary>
        private readonly IWasherGroupService washerGroupService;

        private readonly IInjectionService injectionService;

        private readonly IPumpsService pumpsService;

        private readonly IWasherServices washerService;

        private readonly IControllerSetupService controllerSetupService;

        private readonly IPlcService plcService;

        /// <summary>
        /// Gets or sets the logger.
        /// </summary>
        /// <value>
        /// The logger details.
        /// </value>
        public ILogger Logger { get; set; }

        /// <summary>
        /// Gets or sets Static variable to hold factors multiplier for k-factor
        /// </summary>
        /// <value>
        /// The factors multiplier.
        /// </value>
        public int FactorsMultiplier { get; set; }

        /// <summary>
        /// Gets or sets Static variable to hold ouncepersecond multiplier for time volume calibration
        /// </summary>
        /// <value>
        /// The ounce sec multiplier.
        /// </value>
        public static int OunceSecMultiplier { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="TagManagementController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="compareFormulaService">The compare formula service.</param>
        /// <param name="washerGroupService">The washer group service.</param>
        /// <param name="washerGroupFormulaService">The washer group formula service.</param>
        /// <param name="injectionService">The injection service.</param>
        /// <param name="pumpsService">The pumps service.</param>
        /// <param name="washerService">The washer service.</param>
        /// <param name="controllerSetupService">The controller setup service.</param>
        /// <param name="plcService">PLC service.</param>
        public CompareFormulaController(IUserService userService, IPlantService plantService, ICompareFormulaService compareFormulaService, IWasherGroupService washerGroupService, IWasherGroupFormulaService washerGroupFormulaService, IInjectionService injectionService, IPumpsService pumpsService, IWasherServices washerService, IControllerSetupService controllerSetupService, IPlcService plcService)
            : base(userService, plantService)
        {
            this.compareFormulaService = compareFormulaService;
            this.washerGroupService = washerGroupService;
            this.washerGroupFormulaService = washerGroupFormulaService;
            this.injectionService = injectionService;
            this.pumpsService = pumpsService;
            this.washerService = washerService;
            this.controllerSetupService = controllerSetupService;
            this.plcService = plcService;
            FactorsMultiplier = 0;
            OunceSecMultiplier = 10;
        }

        /// <summary>
        /// The Index method
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>
        /// Redirects to related view
        /// </returns>
        [HttpPost]
        public ActionResult Index(int washerGroupId, int formulaId)
        {
            int controllerId = 0;
            Models.WasherGroup.WasherGroupCompareModel washerGroupCompareModel = new Models.WasherGroup.WasherGroupCompareModel();

            washerGroupCompareModel.WasherGroupDetails = GetWasherGroupData(washerGroupId);
            washerGroupCompareModel.WasherDetailsList = GetWashersList(washerGroupId);
            washerGroupCompareModel.WasherId = washerGroupCompareModel.WasherDetailsList[0].Id;
            washerGroupCompareModel.WasherGroupFormulaDetailsList = GetWasherGroupFormulaDetails(washerGroupId);
            washerGroupCompareModel.DispenserSetupDetailsList = GetDispenserSetupDetails(washerGroupId);

            short maxLoad = washerGroupCompareModel.WasherDetailsList.Max(_ => _.Maxload);
            WashersModel maxLoadWasher = washerGroupCompareModel.WasherDetailsList.Where(_ => _.Maxload == maxLoad && _.WasherControllerId != 0).FirstOrDefault();
            if (maxLoadWasher != null)
            {
                controllerId = maxLoadWasher.WasherControllerId;
                washerGroupCompareModel.WasherId = maxLoadWasher.Id;
            }

            washerGroupCompareModel.WasherDetailsList = washerGroupCompareModel.WasherDetailsList.Where(_ => _.WasherControllerId == controllerId && _.WasherControllerId != 0).ToList();

            List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, 9);
            var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Injection Quantity Multiplier").FirstOrDefault().FieldDefaultValue);

            if (factorsMulti.Any())
            {
                FactorsMultiplier = (int)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
            }

            washerGroupCompareModel.InjectionDetailsList = GetInjectionDetails(washerGroupId).Where(item => item.ControllerId == controllerId).ToList();
            washerGroupCompareModel.PumpsDetailsList = new List<PumpsModel>();

            washerGroupCompareModel.PumpsDetailsList = this.GetPumpDetails(controllerId, formulaId);
            washerGroupCompareModel.MaxInjectionCount = this.compareFormulaService.GetMaxInjectionCount(controllerId, EcolabAccountNumber);

            List<Models.WasherGroup.InjectionDetails> envisionInjectionList = GetEnvisionInjectionDetails(EcolabAccountNumber, washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount);
            envisionInjectionList = envisionInjectionList.Where(_ => _.WasherProgramSetupId == formulaId).ToList();
            envisionInjectionList = CalculateTotalQunatity(envisionInjectionList, washerGroupCompareModel, formulaId);
            washerGroupCompareModel = GetDefaultValues(washerGroupCompareModel, washerGroupId, formulaId, controllerId);

            washerGroupCompareModel.WasherGroupFormulaDetailsList.OrderBy(_ => _.Id);
            try
            {
                TagCollection plcInjectionList = GetDispenserInjectionDetails(washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount, true, formulaId);

                foreach (var pump in washerGroupCompareModel.PumpsDetailsList)
                {
                    pump.EnvisionInjectionDetailsList = ProcessInjectionDetails(envisionInjectionList, pump, washerGroupCompareModel.MaxInjectionCount);
                    List<Models.WasherGroup.InjectionDetails> newInjectionList = GetEnvisionInjectionDetails(EcolabAccountNumber, washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount);
                    newInjectionList = newInjectionList.Where(_ => _.WasherProgramSetupId == formulaId).ToList();
                    if (plcInjectionList != null)
                    {
                        pump.DispenserInjectionDetailsList = ProcessDispenserInjectionDetails(plcInjectionList, newInjectionList, pump, washerGroupCompareModel.MaxInjectionCount);
                        pump.EnvisionInjectionDetailsList = ComparingDispAndEnvQuantities(pump.EnvisionInjectionDetailsList, pump.DispenserInjectionDetailsList);
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == "901" || ex.Message == "902")
                {
                    washerGroupCompareModel.IsPLCError = true;
                }
                else { washerGroupCompareModel.IsError = true; }
                this.Logger.Error("Api - Controller - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }

            return PartialView("_ComapareFormula", washerGroupCompareModel);
        }

        /// <summary>
        /// Gets the dispenser and formula data.
        /// </summary>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <returns>Return Dispenser And Formula Data</returns>
        [HttpPost]
        public ActionResult GetDispenserAndFormulaData(int formulaId, int controllerId, int washerGroupId, int washerId)
        {
            WasherGroupCompareModel washerGroupCompareModel = CreatePartialViewModel(formulaId, controllerId, washerGroupId, washerId);
            return PartialView("_ComapareFormula", washerGroupCompareModel);
        }

        /// <summary>
        /// Creates the partial view model.
        /// </summary>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <returns>Washer Group Compare Model</returns>
        private WasherGroupCompareModel CreatePartialViewModel(int formulaId, int controllerId, int washerGroupId, int washerId)
        {
            Models.WasherGroup.WasherGroupCompareModel washerGroupCompareModel = new Models.WasherGroup.WasherGroupCompareModel();

            washerGroupCompareModel.WasherGroupDetails = GetWasherGroupData(washerGroupId);
            washerGroupCompareModel.WasherDetailsList = GetWashersList(washerGroupId);

            if (washerId == 0)
            {
                List<WashersModel> washersModelList = washerGroupCompareModel.WasherDetailsList.Where(_ => _.WasherControllerId == controllerId && _.WasherControllerId != 0).ToList();
                if (washersModelList != null && washersModelList.Count > 0)
                {
                    int maxload = washersModelList.Max(_ => _.Maxload);
                    WashersModel washersModel = washersModelList.Where(_ => _.Maxload == maxload && _.WasherControllerId != 0).FirstOrDefault();
                    if (washersModel != null)
                    {
                        washerId = washersModel.Id;
                    }
                }
            }

            WashersModel washer = washerGroupCompareModel.WasherDetailsList.Where(item => item.Id == washerId && item.WasherControllerId != 0).FirstOrDefault();
            if (washer != null)
            {
                washerGroupCompareModel.WasherId = washer.Id;
                controllerId = washer.WasherControllerId;
                washerGroupCompareModel.DispenserId = controllerId;
                washerGroupCompareModel.FormulaId = formulaId;
                washerGroupCompareModel.WasherGroupId = washerGroupId;
            }
            else
            {
                washerGroupCompareModel.WasherId = washerId;
                controllerId = washer == null ? controllerId : washer.WasherControllerId;
                washerGroupCompareModel.DispenserId = controllerId;
                washerGroupCompareModel.FormulaId = formulaId;
                washerGroupCompareModel.WasherGroupId = washerGroupId;
            }
            washerGroupCompareModel.WasherGroupFormulaDetailsList = GetWasherGroupFormulaDetails(washerGroupId);

            washerGroupCompareModel.DispenserSetupDetailsList = GetDispenserSetupDetails(washerGroupId);
            washerGroupCompareModel.InjectionDetailsList = GetInjectionDetails(washerGroupId).Where(item => item.ControllerId == controllerId).ToList();
            washerGroupCompareModel.PumpsDetailsList = new List<PumpsModel>();

            washerGroupCompareModel.PumpsDetailsList = this.GetPumpDetails(controllerId, formulaId);
            washerGroupCompareModel.MaxInjectionCount = this.compareFormulaService.GetMaxInjectionCount(controllerId, EcolabAccountNumber);

            List<Models.WasherGroup.InjectionDetails> envisionInjectionList = GetEnvisionInjectionDetails(EcolabAccountNumber, washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount);
            envisionInjectionList = envisionInjectionList.Where(_ => _.WasherProgramSetupId == formulaId).ToList();
            envisionInjectionList = CalculateTotalQunatity(envisionInjectionList, washerGroupCompareModel, formulaId);
            washerGroupCompareModel = GetDefaultValues(washerGroupCompareModel, washerGroupId, formulaId, controllerId);
            washerGroupCompareModel.WasherDetailsList = washerGroupCompareModel.WasherDetailsList.Where(_ => _.WasherControllerId == controllerId && _.WasherControllerId != 0).ToList();
            try
            {
                TagCollection plcInjectionList = GetDispenserInjectionDetails(washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount, true, formulaId);

                foreach (var pump in washerGroupCompareModel.PumpsDetailsList)
                {
                    pump.EnvisionInjectionDetailsList = ProcessInjectionDetails(envisionInjectionList, pump, washerGroupCompareModel.MaxInjectionCount);
                    List<Models.WasherGroup.InjectionDetails> newInjectionList = GetEnvisionInjectionDetails(EcolabAccountNumber, washerGroupId, controllerId, washerGroupCompareModel.MaxInjectionCount);
                    newInjectionList = newInjectionList.Where(_ => _.WasherProgramSetupId == formulaId).ToList();
                    pump.DispenserInjectionDetailsList = ProcessDispenserInjectionDetails(plcInjectionList, newInjectionList, pump, washerGroupCompareModel.MaxInjectionCount);
                    pump.EnvisionInjectionDetailsList = ComparingDispAndEnvQuantities(pump.EnvisionInjectionDetailsList, pump.DispenserInjectionDetailsList);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == "901" || ex.Message == "902")
                {
                    washerGroupCompareModel.IsPLCError = true;
                }
                else
                {
                    washerGroupCompareModel.IsError = true;
                }
                this.Logger.Error("Api - Controller - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }
            return washerGroupCompareModel;
        }

        /// <summary>
        /// Gets the default values.
        /// </summary>
        /// <param name="washerGroupCompareModel">The washer group compare model.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Washer Group Compare Model</returns>
        private WasherGroupCompareModel GetDefaultValues(WasherGroupCompareModel washerGroupCompareModel, int washerGroupId, int formulaId, int controllerId)
        {
            washerGroupCompareModel.DispenserId = controllerId;
            washerGroupCompareModel.FormulaId = formulaId;

            List<WashersModel> washerList = washerGroupCompareModel.WasherDetailsList.Where(item => item.Id == washerGroupCompareModel.WasherId).ToList();

            washerGroupCompareModel.WasherGroupId = washerGroupId;
            List<WasherGroupFormulaModel> objlist = washerGroupCompareModel.WasherGroupFormulaDetailsList.Where(item => item.Id == formulaId).ToList();
            washerGroupCompareModel.NominalLoad = objlist[0].NominalLoad;

            if (washerGroupCompareModel.InjectionDetailsList.Count > 0)
            {
                washerGroupCompareModel.InjectionClass = washerGroupCompareModel.InjectionDetailsList[0].InjectionClass;
                washerGroupCompareModel.OperationClass = washerGroupCompareModel.InjectionDetailsList[0].ReferenceLoad;
            }
            if (washerList != null && washerList.Count > 0)
            {
                washerGroupCompareModel.MaxLoad = washerList[0].Maxload;
            }
            else
            {
                washerGroupCompareModel.MaxLoad = 0;
            }

            if (washerGroupCompareModel.OperationClass > 0)
            {
                washerGroupCompareModel.InjectionRatio = ((Convert.ToDecimal(washerGroupCompareModel.MaxLoad) * 100) / washerGroupCompareModel.OperationClass).ToString("#.##");
            }

            return washerGroupCompareModel;
        }

        /// <summary>
        /// Comparings the disp and env quantities.
        /// </summary>
        /// <param name="envList">The env list.</param>
        /// <param name="dispList">The disp list.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionDetails> ComparingDispAndEnvQuantities(List<Models.WasherGroup.InjectionDetails> envList, List<Models.WasherGroup.InjectionDetails> dispList)
        {
            for (int i = 0; i < envList.Count; i++)
            {
                if (envList[i].TotalQuantity != dispList[i].Quantity)
                {
                    envList[i].PLCOverRidden = true;
                }
            }
            return envList;
        }

        /// <summary>
        /// Calculates the total qunatity.
        /// </summary>
        /// <param name="envisionInjectionList">The envision injection list.</param>
        /// <param name="washerGroupCompareModel">The washer group compare model.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionDetails> CalculateTotalQunatity(List<Models.WasherGroup.InjectionDetails> envisionInjectionList, Models.WasherGroup.WasherGroupCompareModel washerGroupCompareModel, int formulaId)
        {
            int nominalLoad = 0;
            int refrenceLoad = (washerGroupCompareModel.InjectionDetailsList != null && washerGroupCompareModel.InjectionDetailsList.Count() > 0) ? washerGroupCompareModel.InjectionDetailsList[0].ReferenceLoad : 0;

            List<WasherGroupFormulaModel> objlist = washerGroupCompareModel.WasherGroupFormulaDetailsList.Where(item => item.Id == formulaId).ToList();
            nominalLoad = objlist[0].NominalLoad;

            foreach (var item in envisionInjectionList)
            {
                var nL = Convert.ToDecimal(nominalLoad / 100.00);
                var totalQuantity = Math.Round(Convert.ToDecimal(item.Quantity * nL * refrenceLoad) / 100, 1);
                item.TotalQuantity = totalQuantity;
            }
            return envisionInjectionList;
        }

        /// <summary>
        /// Processes the injection details.
        /// </summary>
        /// <param name="injectionList">The injection list.</param>
        /// <param name="pump">The pumps model data.</param>
        /// <param name="maxInj">The maximum inj.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionDetails> ProcessInjectionDetails(List<Models.WasherGroup.InjectionDetails> injectionList, PumpsModel pump, int maxInj)
        {
            List<Models.WasherGroup.InjectionDetails> injectionListObj = new List<Models.WasherGroup.InjectionDetails>();
            if (injectionList.Any(item => item.ProductId == pump.ProductId))
            {
                for (int i = 1; i <= maxInj; i++)
                {
                    if (!injectionList.Any(item => item.InjectionNumber == i))
                    {
                        Models.WasherGroup.InjectionDetails newOnbj = new Models.WasherGroup.InjectionDetails();
                        newOnbj.InjectionNumber = Convert.ToByte(i);
                        newOnbj.Quantity = 0;
                        injectionListObj.Add(newOnbj);
                    }
                    else if (injectionList.Any(item => item.InjectionNumber == i && item.ProductId == pump.ProductId))
                    {
                        var obj = injectionList.Where(item => item.InjectionNumber == i && item.ProductId == pump.ProductId).FirstOrDefault();
                        injectionListObj.Add(obj);
                    }
                    else
                    {
                        var obj = injectionList.Where(item => item.InjectionNumber == i).FirstOrDefault().Clone();
                        obj.Quantity = 0;
                        injectionListObj.Add(obj);
                    }
                }

                return injectionListObj.OrderBy(item => item.InjectionNumber).ToList();
            }
            else
            {
                for (int i = 0; i < maxInj; i++)
                {
                    Models.WasherGroup.InjectionDetails newOnbj = new Models.WasherGroup.InjectionDetails();
                    newOnbj.InjectionNumber = Convert.ToByte(i);
                    newOnbj.Quantity = 0;
                    injectionListObj.Add(newOnbj);
                }
                return injectionListObj.OrderBy(item => item.InjectionNumber).ToList();
            }
        }

        /// <summary>
        /// Processes the dispenser injection details.
        /// </summary>
        /// <param name="plcInjectionList">The PLC injection list.</param>
        /// <param name="injectionData">The injection data.</param>
        /// <param name="pump">The pumps model data.</param>
        /// <param name="maxInjCount">The maximum inj count.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionDetails> ProcessDispenserInjectionDetails(TagCollection plcInjectionList, List<Models.WasherGroup.InjectionDetails> injectionData, PumpsModel pump, int maxInjCount)
        {
            for (int i = 0; i < plcInjectionList.Tags.Count; i++)
            {
                injectionData[i].Quantity = Convert.ToDecimal(plcInjectionList.Tags[i].Value) / FactorsMultiplier;
            }
            injectionData = ProcessInjectionDetails(injectionData, pump, maxInjCount);

            return injectionData;
        }

        #region GettingData

        /// <summary>
        /// Gets the washers list.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>The Washers WashersModel Details</returns>
        private List<Models.Washers.WashersModel> GetWashersList(int washerGroupId)
        {
            List<Ecolab.Models.Washers.Washers> washerList = this.washerService.GetWashersDetails(EcolabAccountNumber, washerGroupId, false).ToList();
            return Mapper.Map<List<Ecolab.Models.Washers.Washers>, List<Models.Washers.WashersModel>>(washerList);
        }

        /// <summary>
        /// Gets the envision injection details.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="maxInjec">The maximum injec.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionDetails> GetEnvisionInjectionDetails(string ecolabAccountNumber, int washerGroupId, int controllerId, int maxInjec)
        {
            List<Ecolab.Models.WasherGroup.InjectionDetails> injectionData = injectionService.GetWasherGroupInjectionDetails(ecolabAccountNumber, washerGroupId, controllerId);
            return Mapper.Map<List<Ecolab.Models.WasherGroup.InjectionDetails>, List<Web.Models.WasherGroup.InjectionDetails>>(injectionData);
        }

        /// <summary>
        /// Gets the pump details.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>List of pumps model</returns>
        private List<PumpsModel> GetPumpDetails(int controllerId, int formulaId)
        {
            List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel> pumpsData = pumpsService.GetCompareFormulaPumps(EcolabAccountNumber, controllerId, formulaId, string.Empty);
            return Mapper.Map<List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel>, List<PumpsModel>>(pumpsData);
        }

        /// <summary>
        /// Gets the injection details.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>The WasherGroup Injection Details</returns>
        private List<Models.WasherGroup.InjectionData> GetInjectionDetails(int washerGroupId)
        {
            List<Ecolab.Models.WasherGroup.InjectionData> injectionData = this.injectionService.GetInjectionDetails(washerGroupId);
            return Mapper.Map<List<Ecolab.Models.WasherGroup.InjectionData>, List<Models.WasherGroup.InjectionData>>(injectionData);
        }

        /// <summary>
        /// Gets the dispenser setup details.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>The List of Controller Model Details</returns>
        private List<ControllerModel> GetDispenserSetupDetails(int washerGroupId)
        {
            List<Ecolab.Models.ControllerSetup.Controller> controllerData = this.compareFormulaService.GetDispenserSetupList(washerGroupId, EcolabAccountNumber);
            return Mapper.Map<List<Ecolab.Models.ControllerSetup.Controller>, List<ControllerModel>>(controllerData);
        }

        /// <summary>
        /// Gets the washer group formula details.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>the list of WasherGroup Formula data</returns>
        private List<Web.Models.WasherGroup.WasherGroupFormulaModel> GetWasherGroupFormulaDetails(int washerGroupId)
        {
            List<Ecolab.Models.WasherGroup.WasherGroupFormula> data = this.washerGroupFormulaService.GetWasherGroupFormula(EcolabAccountNumber, washerGroupId, 0).ToList();
            data = data.OrderBy(x => x.ProgramNumber).ToList();
            return Mapper.Map<List<Ecolab.Models.WasherGroup.WasherGroupFormula>, List<Web.Models.WasherGroup.WasherGroupFormulaModel>>(data);
        }

        /// <summary>
        /// Gets the washer group data.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <returns>Return the washer groups.</returns>
        private Web.Models.WasherGroup.WasherGroup GetWasherGroupData(int washerGroupId)
        {
            List<Ecolab.Models.WasherGroup.WasherGroup> washerGroupDetails = this.washerGroupService.GetWasherGroupDetails(washerGroupId, EcolabAccountNumber, 0, 0, string.Empty);
            List<Web.Models.WasherGroup.WasherGroup> washerGroupDetailslist = Mapper.Map<List<Ecolab.Models.WasherGroup.WasherGroup>, List<Web.Models.WasherGroup.WasherGroup>>(washerGroupDetails);
            return washerGroupDetailslist[0];
        }

        #endregion

        #region PLCInjectionDetails
        /// <summary>
        /// Gets the dispenser injection details.
        /// </summary>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="maxInjc">The maximum injc.</param>
        /// <param name="validate">if set to <c>true</c> [validate].</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <returns>Returns the tag collection of Injection Details</returns>
        private TagCollection GetDispenserInjectionDetails(int washerGroupId, int controllerId, int maxInjc, bool validate = false, int formulaId = 0)
        {
            TagCollection tagStatus = null;
            List<Ecolab.Models.WasherGroup.InjectionDetails> injectionData = injectionService.GetWasherGroupInjectionDetails(EcolabAccountNumber, washerGroupId, controllerId);
            var taglst = new List<OpcTag>();
            if (formulaId != 0)
            {
                injectionData = injectionData.Where(_ => _.WasherProgramSetupId == formulaId).ToList();
            }
            taglst = BuildInjectionTagList(injectionData, controllerId);

            var plc = new PlcTagController(plcService, UserService, PlantService);

            if (validate)
            {
                tagStatus = plc.ValidateTags(new TagCollection { Tags = new List<Tag>(taglst) }, controllerId);
            }
            else
            {
                tagStatus = plc.WriteTags(new TagCollection { Tags = new List<Tag>(taglst) }, controllerId);
            }
            return tagStatus;
        }

        /// <summary>
        /// Builds the injection tag list.
        /// </summary>
        /// <param name="injectionData">The injection data.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <returns>Returns the tag collection of Injection tag list</returns>
        private List<OpcTag> BuildInjectionTagList(List<Ecolab.Models.WasherGroup.InjectionDetails> injectionData, int controllerId)
        {
            User user = GetCurrentUser();
            var taglst = new List<OpcTag>();
            foreach (var injection in injectionData)
            {
                var tag = new OpcTag();
                int value;
                decimal nominalLoadPercent = injection.NominalLoad;
                decimal nominalLoad = nominalLoadPercent / 100;
                FactorsMultiplier = 1;
                List<Ecolab.Models.ControllerSetup.MetaData> controllerSetupMetaDataModel = this.controllerSetupService.GetControllerSetupMetadataWithValues(1, controllerId, this.EcolabAccountNumber, 9);
                var factorsMulti = controllerSetupMetaDataModel.Select(x => x.FieldGroupInfo.AsEnumerable().Where(_ => _.FieldLabel == "Injection Quantity Multiplier").FirstOrDefault().FieldDefaultValue);

                if (factorsMulti.Any())
                {
                    FactorsMultiplier = (int)Convert.ToDecimal(factorsMulti.FirstOrDefault().ToString());
                }

                switch (injection.ControllerType)
                {
                    case 1:
                        var x = injection.ProgramId + 10;
                        var y = ((Convert.ToInt32(injection.InjectionClass) - 1) * 60) + (Convert.ToInt32((injection.InjectionNumber) - 1) * 10) + (injection.ControllerEquipmentId - 1);
                        var adderess = "N" + x + ":" + y;
                        value = Convert.ToInt32(((injection.Quantity * nominalLoad * injection.ReferenceLoad) / 100) * FactorsMultiplier);
                        tag.Address = adderess;
                        tag.Value = Convert.ToString(value);
                        taglst.Add(tag);
                        break;

                    case 2:
                        var beckhoffTagFormat = ConfigurationManager.AppSettings["BeckhoffTagFormat"];
                        beckhoffTagFormat = beckhoffTagFormat.Replace("x", Convert.ToString(injection.InjectionClass)).Replace("#F", Convert.ToString(injection.ProgramId)).Replace("#I", Convert.ToString(injection.InjectionNumber)).Replace("#V", Convert.ToString(injection.ControllerEquipmentId));
                        value = Convert.ToInt32(((injection.Quantity * nominalLoad * injection.ReferenceLoad) / 100) * FactorsMultiplier);
                        tag.Address = beckhoffTagFormat;
                        tag.Value = Convert.ToString(value);
                        taglst.Add(tag);
                        break;
                }
            }
            return taglst;
        }

        /// <summary>
        /// Processes the error string from PLC.
        /// </summary>
        /// <param name="plcInjectionList">The PLC injection list.</param>
        /// <returns>Returns the tag collection of error Details</returns>
        private string ProcessErrorStringFromPLC(TagCollection plcInjectionList)
        {
            string ErrorMsg = string.Empty;
            foreach (var status in plcInjectionList.Tags.Where(status => !status.IsValid || status.Quality == "Bad"))
            {
                var last = plcInjectionList.Tags.LastIndexOf(status);
                if (last != 14 && !string.IsNullOrEmpty(status.Address))
                {
                    ErrorMsg += status.Address + ",";
                }
                else
                {
                    if (!string.IsNullOrEmpty(ErrorMsg))
                    {
                        ErrorMsg += status.Address;
                    }
                }
            }
            if (!string.IsNullOrEmpty(ErrorMsg))
            {
                return "Missing tags: " + ErrorMsg;
            }
            else
            {
                return ErrorMsg;
            }
        }

        /// <summary>
        /// Writes the settings to PLC and Deletes PLC Discrepant data.
        /// </summary>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <returns>Write the data plc.</returns>
        public ActionResult WriteSettingsToPlc(int formulaId, int controllerId, int washerGroupId, int washerId)
        {
            WasherGroupCompareModel washerGroupCompareModel = new WasherGroupCompareModel();
            PLCDiscrepancyModel objPLCDiscrepancyModel = new PLCDiscrepancyModel();
            int userId = 0;
            try
            {
                var maxInjCount = this.compareFormulaService.GetMaxInjectionCount(controllerId, EcolabAccountNumber);
                TagCollection tagStatus = this.GetDispenserInjectionDetails(washerGroupId, controllerId, maxInjCount, false, formulaId);
                washerGroupCompareModel = CreatePartialViewModel(formulaId, controllerId, washerGroupId, washerId);
                Ecolab.ConduitLocal.Web.Models.Common.ControllerInfoForPlcModel controllerInfoForPlcModel
                    = Mapper.Map<List<Ecolab.Models.Common.ControllerInfoForPlc>, List<Ecolab.ConduitLocal.Web.Models.Common.ControllerInfoForPlcModel>>(plcService.GetControllerInfoForPlc(controllerId, EcolabAccountNumber)).FirstOrDefault();
                if (controllerInfoForPlcModel != null && controllerInfoForPlcModel.ControllerTypeId != 2)
                {
                    washerGroupCompareModel.ErrorMsg = ProcessErrorStringFromPLC(tagStatus);
                }
                if (washerGroupCompareModel.ErrorMsg == null || washerGroupCompareModel.ErrorMsg.Length == 0)
                {
                    washerGroupCompareModel.ErrorMsg = "Injections saved successfully";
                    #region Delete PLC Discrepant data
                    userId = GetCurrentUser().Id;
                    objPLCDiscrepancyModel = new Models.Common.PLCDiscrepancyModel()
                    {
                        ParentEntity = Convert.ToInt32(PlcDiscrepancyEntity.WasherGroup),
                        ParentEntityId = washerGroupId,
                        Entity = Convert.ToInt32(PlcDiscrepancyEntity.ConventionalFormula),
                        EntityId = formulaId,
                        IsCentral = false,
                        ControllerId = controllerId,
                        UserId = userId,
                        LastModifiedUserId = userId
                    };
                    this.plcService.DeletePlcDiscrepancy(AutoMapper.Mapper.Map<PLCDiscrepancyModel, Ecolab.Models.Common.PLCDiscrepancyModel>(objPLCDiscrepancyModel));
                    #endregion
                }
            }
            catch (Exception ex)
            {
                washerGroupCompareModel.IsPLCError = true;
                this.Logger.Error("Api - Controller - Update Error :", ex);
                ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
            }
            return PartialView("_ComapareFormula", washerGroupCompareModel);
        }
        #endregion
    }
}