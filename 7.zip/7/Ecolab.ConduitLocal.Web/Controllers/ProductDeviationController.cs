﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductDeviationController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Web.Controllers
{
    using System;
    using System.Web.Mvc;
    using Ecolab.ConduitLocal.Web.Models.Washers.Conventional;
    using Ecolab.Models.Washers.Conventional;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services.Interfaces.Washers.Conventional;

    /// <summary>
    ///     The ProductDeviationController Class
    /// </summary>
    public class ProductDeviationController : BaseController
    {
        /// <summary>
        ///     The Tunnel general services
        /// </summary>
        private readonly IConventionalGeneralServices conventionalGeneralServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        /// <param name="conventionalGeneralServicesInstance">The conventional general services.</param>
        public ProductDeviationController(IUserService userService, IPlantService plantService, IConventionalGeneralServices conventionalGeneralServicesInstance)
            : base(userService, plantService)
        {
            conventionalGeneralServices = conventionalGeneralServicesInstance;
        }

        /// <summary>
        ///     This action method is for loading the Product deviation view.
        /// </summary>
        /// <returns>Product deviation view.</returns>
        public ActionResult Index()
        {
            string machineId = this.Request.QueryString.Get("machineId");
            string groupId = this.Request.QueryString.Get("groupId");
            string groupTypeId = this.Request.QueryString.Get("groupTypeId");
            string controllerId = this.Request.QueryString.Get("controllerId");
            if (!string.IsNullOrWhiteSpace(machineId) && !string.IsNullOrWhiteSpace(groupId) && !string.IsNullOrWhiteSpace(controllerId) && !string.IsNullOrWhiteSpace(groupTypeId))
            {
                ConventionalGeneralModel tunnelData = AutoMapper.Mapper.Map<ConventionalGeneral, ConventionalGeneralModel>(this.conventionalGeneralServices.GetConventionalData(Convert.ToInt32(machineId), Convert.ToInt32(groupId), this.EcolabAccountNumber));
                this.ViewBag.TunnelId = tunnelData.Id; 
                this.ViewBag.WasherGroupId = tunnelData.WasherGroupId;
                this.ViewBag.WasherGroupTypeId = groupTypeId;
                this.ViewBag.ControllerId = tunnelData.ControllerId;
                this.ViewBag.ControllerModelId = tunnelData.ControllerModelId;
                this.ViewBag.ControllerTypeId = tunnelData.ControllerTypeId;
                this.ViewBag.WasherId = machineId;
                this.ViewBag.GroupId = groupId;
                this.ViewBag.ControllerId = controllerId;
                this.ViewBag.PlantWasherNumber = tunnelData.PlantWasherNumber;
            }
            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}