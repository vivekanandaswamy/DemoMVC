﻿// -----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AssemblyInfo </summary>
// -----------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using log4net.Config;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Ecolab.ConduitLocal.Web")]
[assembly: AssemblyDescription("")]
[assembly: XmlConfigurator(Watch = true, ConfigFile = "log4net.config")]