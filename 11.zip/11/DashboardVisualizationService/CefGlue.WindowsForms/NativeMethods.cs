﻿// -----------------------------------------------------------------------
// <copyright file="NativeMethods.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>NativeMethods </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    using System;
    using System.Runtime.InteropServices;

    internal static class NativeMethods
    {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, SetWindowPosFlags uFlags);

        [DllImport("user32.dll")]
        public static extern IntPtr GetFocus();
    }
}