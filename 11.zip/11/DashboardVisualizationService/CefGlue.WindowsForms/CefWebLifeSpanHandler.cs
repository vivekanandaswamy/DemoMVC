﻿// -----------------------------------------------------------------------
// <copyright file="CefWebLifeSpanHandler.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CefWebLifeSpanHandler </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    internal sealed class CefWebLifeSpanHandler : CefLifeSpanHandler
    {
        private readonly CefWebBrowser _core;

        public CefWebLifeSpanHandler(CefWebBrowser core)
        {
            _core = core;
        }

        protected override void OnAfterCreated(CefBrowser browser)
        {
            base.OnAfterCreated(browser);

            _core.BrowserAfterCreated(browser);
        }

        protected override bool DoClose(CefBrowser browser)
        {
            // TODO: ... dispose core
            return false;
        }
    }
}