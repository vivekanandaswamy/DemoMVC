﻿// -----------------------------------------------------------------------
// <copyright file="CefWebBrowser.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CefWebBrowser </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Drawing.Drawing2D;
    using System.Windows.Forms;

    [ToolboxBitmap(typeof (CefWebBrowser))]
    public sealed class CefWebBrowser : Control
    {
        private IntPtr _browserWindowHandle;
        private bool _handleCreated;

        public CefWebBrowser()
        {
            SetStyle(ControlStyles.ContainerControl | ControlStyles.ResizeRedraw | ControlStyles.FixedWidth | ControlStyles.FixedHeight | ControlStyles.StandardClick | ControlStyles.UserMouse | ControlStyles.SupportsTransparentBackColor | ControlStyles.StandardDoubleClick | ControlStyles.OptimizedDoubleBuffer | ControlStyles.CacheText | ControlStyles.EnableNotifyMessage | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UseTextForAccessibility | ControlStyles.Opaque, false);

            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.Selectable, true);

            StartUrl = "about:blank";
        }

        [DefaultValue("about:blank")]
        public string StartUrl { get; set; }

        public string Title { get; private set; }
        public string Address { get; private set; }
        public CefBrowser Browser { get; private set; }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            if (DesignMode)
            {
                if (!_handleCreated)
                {
                    Paint += PaintInDesignMode;
                }
            }
            else
            {
                CefWindowInfo windowInfo = CefWindowInfo.Create();
                windowInfo.SetAsChild(Handle, new CefRectangle { X = 0, Y = 0, Width = Width, Height = Height });

                CefWebClient client = new CefWebClient(this);

                CefBrowserSettings settings = new CefBrowserSettings
                {
                    FileAccessFromFileUrls = CefState.Enabled, UniversalAccessFromFileUrls = CefState.Enabled, TextAreaResize = CefState.Default
                    // AuthorAndUserStylesDisabled = false,                      
                };

                CefBrowserHost.CreateBrowser(windowInfo, client, settings, StartUrl);
            }

            _handleCreated = true;
        }

        protected override void Dispose(bool disposing)
        {
            if (Browser != null)
            {
                CefBrowserHost host = Browser.GetHost();
                host.CloseBrowser();
                host.ParentWindowWillClose();
                host.Dispose();
                Browser.Dispose();
                Browser = null;
                _browserWindowHandle = IntPtr.Zero;
            }

            base.Dispose(disposing);
        }

        internal void BrowserAfterCreated(CefBrowser browser)
        {
            Browser = browser;
            _browserWindowHandle = Browser.GetHost().GetWindowHandle();
            ResizeWindow(_browserWindowHandle, Width, Height);
        }

        internal void OnTitleChanged(string title)
        {
            Title = title;

            EventHandler handler = TitleChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }

        public event EventHandler TitleChanged;

        internal void OnAddressChanged(string address)
        {
            Address = address;

            EventHandler handler = AddressChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }

        public event EventHandler AddressChanged;

        internal void OnStatusMessage(string value)
        {
            EventHandler<StatusMessageEventArgs> handler = StatusMessage;
            if (handler != null)
            {
                handler(this, new StatusMessageEventArgs(value));
            }
        }

        public event EventHandler<StatusMessageEventArgs> StatusMessage;

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            Form form = TopLevelControl as Form;
            if (form != null && form.WindowState != FormWindowState.Minimized)
            {
                ResizeWindow(_browserWindowHandle, Width, Height);
            }
        }

        private void PaintInDesignMode(object sender, PaintEventArgs e)
        {
            int width = Width;
            int height = Height;
            if (width > 1 && height > 1)
            {
                SolidBrush brush = new SolidBrush(ForeColor);
                Pen pen = new Pen(ForeColor);
                pen.DashStyle = DashStyle.Dash;

                e.Graphics.DrawRectangle(pen, 0, 0, width - 1, height - 1);

                int fontHeight = (int) ( Font.GetHeight(e.Graphics) * 1.25 );

                int x = 3;
                int y = 3;

                e.Graphics.DrawString("CefWebBrowser", Font, brush, x, y + ( 0 * fontHeight ));
                e.Graphics.DrawString(string.Format("StartUrl: {0}", StartUrl), Font, brush, x, y + ( 1 * fontHeight ));

                brush.Dispose();
                pen.Dispose();
            }
        }

        private static void ResizeWindow(IntPtr handle, int width, int height)
        {
            if (handle != IntPtr.Zero)
            {
                NativeMethods.SetWindowPos(handle, IntPtr.Zero, 0, 0, width, height, SetWindowPosFlags.NoMove | SetWindowPosFlags.NoZOrder);
            }
        }
    }
}