﻿// -----------------------------------------------------------------------
// <copyright file="CefWebClient.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CefWebClient </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    internal sealed class CefWebClient : CefClient
    {
        private readonly CefWebBrowser _core;
        private readonly CefWebDisplayHandler _displayHandler;
        private readonly CefWebLifeSpanHandler _lifeSpanHandler;

        public CefWebClient(CefWebBrowser core)
        {
            _core = core;
            _lifeSpanHandler = new CefWebLifeSpanHandler(_core);
            _displayHandler = new CefWebDisplayHandler(_core);
        }

        protected override CefLifeSpanHandler GetLifeSpanHandler()
        {
            return _lifeSpanHandler;
        }

        protected override CefDisplayHandler GetDisplayHandler()
        {
            return _displayHandler;
        }
    }
}