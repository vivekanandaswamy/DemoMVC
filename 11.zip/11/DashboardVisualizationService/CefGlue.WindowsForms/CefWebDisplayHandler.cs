﻿// -----------------------------------------------------------------------
// <copyright file="CefWebDisplayHandler.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CefWebDisplayHandler </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    internal sealed class CefWebDisplayHandler : CefDisplayHandler
    {
        private readonly CefWebBrowser _core;

        public CefWebDisplayHandler(CefWebBrowser core)
        {
            _core = core;
        }

        protected override void OnTitleChange(CefBrowser browser, string title)
        {
            _core.OnTitleChanged(title);
        }

        protected override void OnAddressChange(CefBrowser browser, CefFrame frame, string url)
        {
            if (frame.IsMain)
            {
                _core.OnAddressChanged(url);
            }
        }

        protected override void OnStatusMessage(CefBrowser browser, string value)
        {
            _core.OnStatusMessage(value);
        }
    }
}