﻿// -----------------------------------------------------------------------
// <copyright file="StatusMessageEventArgs.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>StatusMessageEventArgs </summary>
// -----------------------------------------------------------------------
namespace Xilium.CefGlue.WindowsForms
{
    using System;

    public sealed class StatusMessageEventArgs : EventArgs
    {
        private readonly string _value;

        public StatusMessageEventArgs(string value)
        {
            _value = value;
        }

        public string Value
        {
            get { return _value; }
        }
    }
}