﻿// -----------------------------------------------------------------------
// <copyright file="Extensions.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Extensions </summary>
// -----------------------------------------------------------------------

namespace DashboardVisualizationService.Common
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;

    public static class Extensions
    {
        public static DataTable ToDataTable<T>(this IList<T> listObject)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof (T));

            DataTable myTable = new DataTable();

            foreach (PropertyDescriptor prop in properties)
            {
                myTable.Columns.Add(prop.Name, prop.PropertyType);
            }

            var values = new object[properties.Count];

            foreach (T item in listObject)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = properties[i].GetValue(item);
                }

                myTable.Rows.Add(values);
            }

            return myTable;
        }
    }
}