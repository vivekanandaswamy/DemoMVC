﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Program </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.DashboardVisualizationService
{
    using System;
    using System.IO;
    using System.Reflection;
    using System.Windows.Forms;
    using Xilium.CefGlue;

    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                string pluginPath = Path.Combine(GetViewDirectory1(), "DynamicWebTWAINPlugIn.msi");
                CefRuntime.AddWebPluginPath(pluginPath);
                CefRuntime.AddWebPluginDirectory(GetViewDirectory1());
                CefRuntime.Load();
            }
            catch (DllNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            catch (CefRuntimeException ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 2;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 3;
            }

            CefMainArgs mainArgs = new CefMainArgs(args);
            DemoApp app = new DemoApp();

            int exitCode = CefRuntime.ExecuteProcess(mainArgs, app);
            if (exitCode != -1)
            {
                return exitCode;
            }

            CefSettings settings = new CefSettings
            { 
                // BrowserSubprocessPath = @"D:\fddima\Projects\Xilium\Xilium.CefGlue\CefGlue.Demo\bin\Release\Xilium.CefGlue.Demo.exe",
                SingleProcess = false, MultiThreadedMessageLoop = true, LogSeverity = CefLogSeverity.Disable, LogFile = "CefGlue.log"
            };

            CefRuntime.Initialize(mainArgs, settings, app);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (!settings.MultiThreadedMessageLoop)
            {
                Application.Idle += (sender, e) => 
                {
                    CefRuntime.DoMessageLoopWork();
                };
            }

            Application.Run(new Main());

            CefRuntime.Shutdown();
            return 0;
        }

        private static string GetViewDirectory1()
        {
            return Path.Combine(Path.GetDirectoryName(new Uri(Assembly.GetEntryAssembly().CodeBase).LocalPath), "DWT_HTML_BasicScan\\Resources");
        }
    }
}