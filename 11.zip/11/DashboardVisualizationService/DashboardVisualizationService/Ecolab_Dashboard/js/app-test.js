$(document).ready(function () {
    var windwoH = window.innerHeight;
    var windwoW = window.innerWidth;
    var count = 1;
    var compHeight = $('.row-tunnel').height();
    var compWidth = $('.row-tunnel').width();
    var compnumberWidth = $('.compt-number').width();
    var compcontWidth = $('.compartment').width() + 4;
    var compnumberPos = (compWidth / 2) - (compnumberWidth / 2);
    var rowTunnelH = ((windwoH + 120) / 2) - compHeight / 2;
    var rowTunnelW = ((windwoW / 2) - (compWidth / 2));
    var tunDatalen = 24;
    var tunnelLength = 3;
    var resLower = window.matchMedia("screen and (max-width: 1024px)");
    var resMedium = window.matchMedia("screen and (max-width: 1152px)");
    var resSemiMedium = window.matchMedia("screen and (max-width: 1280px)");
    var resSemi = window.matchMedia("screen and (max-width: 1450px)");
    var resHigher = window.matchMedia("screen and (max-width: 1920px)");

    //$('.row-tunnel').css({ top: rowTunnelH, position: 'fixed' });
   // $('.row-tunnel').css({ left: rowTunnelW, position: 'fixed' });
    //$('.compt-number').css({ left: (compnumberPos - 5.5) });
    //var tunnel = $('.row-tunnel');
    loadCompartments();
    function loadCompartments() {
        if (tunDatalen > 0) {
            for (i = 1; i < tunDatalen; i++) {
                var dyndivs = $('<div class="compartment" id="compt' + i + 1 + '"><div class="compt-number">01</div><div class="comp-content">02</div><div class="comp-content">05</div><div class="comp-content-weight">150</div></div>');
                var dyndivsSecTon = $('<div class="compartment" id="comptsec' + i + 1 + '"><div class="compt-number">01</div><div class="comp-content">02</div><div class="comp-content">05</div><div class="comp-content-weight">150</div></div>');
                var dyndivsFinTon = $('<div class="compartment" id="comptfin' + i + 1 + '"><div class="compt-number">01</div><div class="comp-content">02</div><div class="comp-content">05</div><div class="comp-content-weight">150</div></div>');
                $('#tunnel-1').append(dyndivs);
                $('#tunnel-2').append(dyndivsSecTon);
                $('#tunnel-3').append(dyndivsFinTon);
                count = i + 1;
                if (count < 10) {
                    count = '0' + count;
                }
                //tunnel#1
                var getId = $(dyndivs).attr('id');
                $('#' + getId).find('.compt-number').html(count);

                //tunnel#2
                var getTunSecId = $(dyndivsSecTon).attr('id');
                $('#' + getTunSecId).find('.compt-number').html(count);

                //tunnel#3
                var getTunFinId = $(dyndivsFinTon).attr('id');
                $('#' + getTunFinId).find('.compt-number').html(count);
            }
            updateContentPos();
        }

        if (tunDatalen <= 16) {
            //changeTunnelSize();
        }

    }


    function changeTunnelSize() {
        if (tunnelLength < 3) {
            if (resLower.matches) {
                $('.comp-content-weight').attr('style', 'font-size:140% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:120% !important;');
                $('.compt-number').attr('style', 'font-size:100% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:20px !important; height:20px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:24px !important; height:24px !important;');
            }
            else if (resMedium.matches) {
                $('.comp-content-weight').attr('style', 'font-size:160% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:135% !important;');
                $('.compt-number').attr('style', 'font-size:100% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:28px !important; height:28px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:32px !important; height:32px !important;');
            }
            else if (resSemiMedium.matches) {
                $('.comp-content-weight').attr('style', 'font-size:180% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:155% !important;');
                $('.compt-number').attr('style', 'font-size:115% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:28px !important; height:28px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:32px !important; height:32px !important;');
            }
            else if (resSemi.matches) {
                $('.comp-content-weight').attr('style', 'font-size:180% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:155% !important;');
                $('.compt-number').attr('style', 'font-size:155% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:28px !important; height:28px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:32px !important; height:32px !important;');
            }
            else if (resHigher.matches) {
                $('.comp-content-weight').attr('style', 'font-size:290% !important;padding-left:10px !important; padding-right:10px !important');
                $('.comp-content').attr('style', 'font-size:240% !important;');
                $('.compt-number').attr('style', 'font-size:180% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:28px !important; height:28px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:32px !important; height:32px !important;');
            }
        } else {
            if (resLower.matches) {
                $('.comp-content-weight').attr('style', 'font-size:90% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:80% !important;');
                $('.compt-number').attr('style', 'font-size:70% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:16px !important; height:16px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:20px !important; height:20px !important;');
            }
            else if (resMedium.matches) {
                $('.comp-content-weight').attr('style', 'font-size:120% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:105% !important;');
                $('.compt-number').attr('style', 'font-size:80% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:20px !important; height:20px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:24px !important; height:24px !important;');
            }
            else if (resSemiMedium.matches) {
                $('.comp-content-weight').attr('style', 'font-size:150% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:125% !important;');
                $('.compt-number').attr('style', 'font-size:90% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:24px !important; height:24px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:28px !important; height:28px !important;');
            }
            else if (resSemi.matches) {
                $('.comp-content-weight').attr('style', 'font-size:155% !important;padding-left:8px !important; padding-right:8px !important');
                $('.comp-content').attr('style', 'font-size:130% !important;');
                $('.compt-number').attr('style', 'font-size:95% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:26px !important; height:26px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:30px !important; height:30px !important;');
            }
            else if (resHigher.matches) {
                $('.comp-content-weight').attr('style', 'font-size:200% !important;padding-left:10px !important; padding-right:10px !important');
                $('.comp-content').attr('style', 'font-size:160% !important;');
                $('.compt-number').attr('style', 'font-size:110% !important;');
                $('.compartment-icons .imgadj').attr('style', 'width:32px !important; height:32px !important;');
                $('.compartment-icons .imgadj_level1').attr('style', 'width:36px !important; height:36px !important;');
            }
        }
        updateContentPos();

    }

    function updateContentPos() {
        compHeight = $('.row-tunnel').height();
        rowTunnelH = ((windwoH + 120) / 2) - compHeight / 2;
        $('.row-tunnel').css({ top: rowTunnelH, position: 'fixed' });

    }

});