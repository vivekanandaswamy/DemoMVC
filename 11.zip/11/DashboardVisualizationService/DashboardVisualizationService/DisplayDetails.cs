﻿// -----------------------------------------------------------------------
// <copyright file="DisplayDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Class Gets External Montiors Details</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.DashboardVisualizationService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Win32;

    /// <summary>
    ///     The Class Gets External Montiors Details
    /// </summary>
    public class DisplayDetails
    {
        /// <summary>
        ///     The Constructor to create a new instances of the DisplayDetails class...
        /// </summary>
        public DisplayDetails(string pnpID, string serialNumber, string model, string monitorID)
        {
            PnPID = pnpID;
            SerialNumber = serialNumber;
            Model = model;
            MonitorID = monitorID;
        }

        public string PnPID { get; set; }
        public string SerialNumber { get; set; }
        public string Model { get; set; }
        public string MonitorID { get; set; }

        /// <summary>
        ///     This Function returns all Monitor Details
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<DisplayDetails> GetMonitorDetails()
        {
            //Open the Display Reg-Key
            RegistryKey Display = Registry.LocalMachine;
            Boolean isFailed = false;
            try
            {
                Display = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum\DISPLAY");
            }
            catch
            {
                isFailed = true;
            }

            if (!isFailed & (Display != null))
            {
                //Get all MonitorIDss
                foreach (string monitorKeyID in Display.GetSubKeyNames())
                {
                    RegistryKey MonitorID = Display.OpenSubKey(monitorKeyID);

                    if (MonitorID != null)
                    {
                        //Get all Plug&Play ID's
                        foreach (string pnpkey in MonitorID.GetSubKeyNames())
                        {
                            RegistryKey PnPID = MonitorID.OpenSubKey(pnpkey);
                            if (PnPID != null)
                            {
                                string[] subkeysArray = PnPID.GetSubKeyNames();

                                //Check if Monitor is active
                                if (subkeysArray.Contains("Control") && subkeysArray.Contains("Device Parameters"))
                                {
                                    RegistryKey DevParam = PnPID.OpenSubKey("Device Parameters");
                                    string serial = string.Empty;
                                    string model = string.Empty;

                                    //Define Search Keys
                                    string serFind = new string(new[] { (char)00, (char)00, (char)00, (char)0xff });
                                    string modFind = new string(new[] { (char)00, (char)00, (char)00, (char)0xfc });

                                    //Get the EDID code
                                    var encodedString = DevParam.GetValue("EDID", null) as byte[];
                                    if (encodedString != null)
                                    {
                                        //Get the 4 Vesa descriptor blocks
                                        var descriptorArray = new string[4];
                                        descriptorArray[0] = Encoding.Default.GetString(encodedString, 0x36, 18);
                                        descriptorArray[1] = Encoding.Default.GetString(encodedString, 0x48, 18);
                                        descriptorArray[2] = Encoding.Default.GetString(encodedString, 0x5A, 18);
                                        descriptorArray[3] = Encoding.Default.GetString(encodedString, 0x6C, 18);

                                        //Search the Keys
                                        foreach (string descriptor in descriptorArray)
                                        {
                                            if (descriptor.Contains(serFind))
                                            {
                                                serial = descriptor.Substring(4).Replace("\0", string.Empty).Trim();
                                            }
                                            if (descriptor.Contains(modFind))
                                            {
                                                model = descriptor.Substring(4).Replace("\0", string.Empty).Trim();
                                            }
                                        }
                                    }
                                    if (!string.IsNullOrEmpty(pnpkey + serFind + model + monitorKeyID))
                                    {
                                        yield return new DisplayDetails(pnpkey, serial, model, monitorKeyID);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}