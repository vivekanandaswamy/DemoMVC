﻿// -----------------------------------------------------------------------
// <copyright file="Utilities.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Utility Class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.DashboardVisualizationService
{
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Windows.Forms;
    using AutoMapper;
    using Data.Access;
    using Ecolab.Models.Visualization.Monitor;
    using Microsoft.Win32;
    using Services.Infra;
    using Services.Visualization.Monitor;

    /// <summary>
    ///     The Utility Class is to provide common functionalities
    /// </summary>
    public class Utilities
    {
        /// <summary>
        ///     Checking whether Database is up or not..
        /// </summary>
        /// <returns>A boolean value</returns>
        public static bool IsDBRunning()
        {
            SqlConnection con = null;

            try
            {
                using (con = new SqlConnection(ConfigurationManager.ConnectionStrings["ScreenDashboardMapping"].ToString()))
                {
                    con.Open();
                    return con.State == ConnectionState.Open;
                }
            }
            catch (SqlException)
            {
                return false;
            }
        }

        /// <summary>
        ///     Save Connected Monitors to Database
        /// </summary>
        public static void DetectAndSaveMonitors()
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["ScreenDashboardMapping"].ToString());
            var listMonitorDetails = new List<MonitorDetails>();

            IEnumerable<Screen> displays = (from screen in Screen.AllScreens select screen);
            IEnumerable<DisplayDetails> monitors = DisplayDetails.GetMonitorDetails();
            int monitorId = 0;
            DisplayDevices objDevices = new DisplayDevices();
            List<DisplayDevices.DISPLAY_DEVICE> devices = objDevices.Display();

            foreach (Screen display in displays)
            {
                foreach (DisplayDevices.DISPLAY_DEVICE device in devices)
                {
                    //Checking Devicename and DisplayName if they are Same then Check DeviceId with Monitor Id
                    string displayName = display.DeviceName.Replace(@"\", string.Empty);
                    string deviceName = device.DeviceName.Replace("Monitor0", string.Empty).Replace(@"\", string.Empty);

                    if (displayName == deviceName && !displayName.ToLower(CultureInfo.InvariantCulture).Contains(".display1"))
                    {
                        //Getting Monitor by checing with DeviceId with Monitor Id
                        DisplayDetails monitor = (from mn in monitors where device.DeviceID.Contains(mn.MonitorID) select mn).FirstOrDefault();

                        //Checking Monitor Name with ScreenName if they are same then creating forms
                        if (monitor != null)
                        {
                            MonitorDetails details = new MonitorDetails();
                            monitorId++;

                            details.MonitorId = monitorId.ToString();
                            details.MonitorName = monitor.Model;

                            details.XBound = display.Bounds.X;
                            details.YBound = display.Bounds.Y;
                            listMonitorDetails.Add(details);
                        }
                    }
                }
            }

            MonitorSetupService service = new MonitorSetupService();
            service.SaveMonitorDetails(listMonitorDetails);
        }

        /// <summary>
        ///     Configuring Automapper
        /// </summary>
        public static void Configure()
        {
            Mapper.Initialize(cfg => { cfg.AddProfile(new ServiceMappingProfile()); });
        }

        /// <summary>
        ///     Setting this app as Start up service
        /// </summary>
        public static void SetAsStartup()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
            //Surround path with " " to make sure that there are no problems
            //if path contains spaces.
            key.SetValue("Tray minimizer", "\"" + Application.ExecutablePath + "\"");

            key.Close();
        }

        public static void DiposeFormsOnRefersh()
        {
            if (Main.formControls.Count > 0)
            {
                foreach (Control item in Main.formControls)
                {
                    item.Dispose();
                }
            }
        }
    }
}