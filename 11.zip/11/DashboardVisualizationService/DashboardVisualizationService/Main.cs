﻿// -----------------------------------------------------------------------
// <copyright file="Main.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machines For Wash Group Type class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.DashboardVisualizationService
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using Data.Access;
    using Ecolab.Models.Common;
    using Ecolab.Models.Visualization.Monitor;
    using log4net;
    using log4net.Config;
    using Services;
    using Services.Visualization.Monitor;

    /// <summary>
    ///     Main class
    /// </summary>
    /// 
    public partial class Main : Form
    {
        //These are used in Hiding the form on Startup.
        private const int GWLEXSTYLE = -20;
        private const int WSEXTOOLWINDOW = 0x00000080;
        private const int WSEXAPPWINDOW = 0x00040000;
        private const int WMNCLBUTTONDBLCLK = 0x00A3;
        //form Contol Collection
        public static List<Control> formControls = new List<Control>();
        private readonly Timer dbTimer = new Timer();
        //Collections to capture intial and periodical Dashboards assigned to same monitor.
        private readonly List<ExternalDisplay> initialDashboards = new List<ExternalDisplay>();
        //Logger
        private readonly ILog log = LogManager.GetLogger(typeof(Main));
        private readonly List<ExternalDisplay> periodicalDashboards = new List<ExternalDisplay>();
        private bool isDBRunning = true;
        //bool variables
        private bool isLoaded;
        //ContextMenu Items
        private MenuItem miDisplay;
        private MenuItem miExit;
        private bool switchflag;
        string plantId = string.Empty;
        public Main()
        {
            try
            {
                InitializeComponent();
                XmlConfigurator.Configure();
                FormBorderStyle = FormBorderStyle.FixedSingle;
                StartPosition = FormStartPosition.CenterScreen;

                //Database connection monitor Timer and Dashboard reload monitor timer
                timer.Enabled = true;
                timer.Interval = Convert.ToInt32(ConfigurationManager.AppSettings["DashboardLoadInterval"]);
                dbTimer.Tick += dbTimer_Tick;
                dbTimer.Enabled = true;
                dbTimer.Interval = Convert.ToInt32(ConfigurationManager.AppSettings["DBInterval"]);

                dgMapping.RowHeadersVisible = false;
                dgMapping.ReadOnly = true;

                CreateContextMenu();
                Utilities.Configure();
                Utilities.SetAsStartup();
                Utilities.DetectAndSaveMonitors();
            }
            catch (Exception ex)
            {
                log.Error("Error -- ", ex);
            }
        }

        // It is used in Hiding the form on Startup.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern int SetWindowLong(IntPtr window, int index, int value);

        //It is used in Hiding the form on Startup.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern int GetWindowLong(IntPtr window, int index);

        /// <summary>
        ///     It Hides form and Displays  Dashboards in External Displays
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Main_Load(object sender, EventArgs e)
        {
            try
            {
                HideFormOnStartup();
                if (DisplayDashboard.CheckForConnectedDisplays())
                {
                    log.Info("Displays ..");
                    notify.Visible = false;

                    FetchMappedDashboards();
                    ExternalDisplaySettings externalDisplaySettings = new ExternalDisplayService().FetchDisplaySettings(plantId);
                    timer.Interval = Convert.ToInt32(externalDisplaySettings.DashboardLoadInterval);
                    SendAppToTray();
                }
                else
                {
                    log.Info("No External Displays  found to show Dashboards ..");
                    MessageBox.Show("No External Displays  found to show Dashboards");
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Fetching Mapped Dashboard Details.
        /// </summary>
        private void FetchMappedDashboards()
        {
            if (Utilities.IsDBRunning())
            {
                log.Info("Entered in FetchMappedDashboards method ..");
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["ScreenDashboardMapping"].ToString());

                List<ExternalDisplay> mappingDetails = new ExternalDisplayService().FetchMappingDetails().OrderBy(p => p.MonitorId).Select(i => i).ToList();

                if (mappingDetails.Count > 0)
                {
                    var gridSource = mappingDetails.Select(c => new { c.DashboardName, c.MonitorName, c.DashboardType });

                    string ecolabAccountNumber = mappingDetails.Select(c => c.EcolabAccountNumber).First();
                    plantId = ecolabAccountNumber;
                    ChangeLanguage(ecolabAccountNumber);
                    dgMapping.DataSource = gridSource.ToList();

                    string mName = string.Empty;

                    foreach (ExternalDisplay item in mappingDetails)
                    {
                        string dashboardUrl = ConfigurationManager.AppSettings["DashboardUrl"];

                        Screen display = (from sc in Screen.AllScreens where sc.Bounds.X == item.XBound select sc).FirstOrDefault();
                        if ((item.MonitorId != mName) || (mName.Length == 0))
                        {
                            isLoaded = true;
                            initialDashboards.Add(item);
                            log.Info("calling Display method ..");

                            DisplayDashboard.LoadDashboard(item.DashboardName, display, dashboardUrl + "?id=" + item.DashboardId + "&typeId=" + item.TypeId);
                            mName = item.MonitorId;
                        }
                        else
                        {
                            periodicalDashboards.Add(item);
                            switchflag = true;
                        }
                    }
                }
            }
            else
            {
                isDBRunning = false;
                MessageBox.Show("Database is initializing.. please wait..");
            }
        }

        /// <summary>
        ///     Displays Dshboard and Hides the App
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                Utilities.DiposeFormsOnRefersh();
                FetchMappedDashboards();
                if (isDBRunning)
                {
                    SendAppToTray();
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     This Method applys localization to the controls.
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        private void ChangeLanguage(string ecolabAccountNumber)
        {
            UserService userService = new UserService();
            string pageName = ConfigurationManager.AppSettings["PageName"];
            List<Locale> keyValues = userService.FetchLanguageDataForPage(pageName, ecolabAccountNumber);

            foreach (Locale item in keyValues)
            {
                if (item.Key == ConfigurationManager.AppSettings["FIELD_DISPLAY"])
                {
                    btnDisplay.Text = item.Value;
                    miDisplay.Text = item.Value;
                }
                if (item.Key == ConfigurationManager.AppSettings["FIELD_EXIT"])
                {
                    btnClose.Text = item.Value;
                    miExit.Text = item.Value;
                }
            }
        }

        /// <summary>
        ///     Showing Notification Icon and Hiding the form
        /// </summary>
        private void SendAppToTray()
        {
            notify.Visible = true;
            notify.ShowBalloonTip(100);
            Hide();
        }

        /// <summary>
        ///     OnClose Checks for the Displays ,if found Hides the form elese closes the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (DisplayDashboard.CheckForConnectedDisplays())
                {
                    notify.Visible = true;
                    SendAppToTray();
                    e.Cancel = true;
                }
                else
                {
                    Dispose();
                    notify.Dispose();
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Shows form on mouse click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notify_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Left)
                {
                    Show();
                    TopMost = true;
                    Focus();
                    BringToFront();
                    TopMost = false;
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Dispose Form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                notify.Icon.Dispose();
                Dispose();
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Method to hide the form on Startup
        /// </summary>
        private void HideFormOnStartup()
        {
            Visible = false;
            ShowInTaskbar = false;
            int windowStyle = GetWindowLong(Handle, GWLEXSTYLE);
            SetWindowLong(Handle, GWLEXSTYLE, windowStyle | WSEXTOOLWINDOW);
        }

        /// <summary>
        ///     Loading Dashboards in External Displays periodically, if Dashboards assign to multiple Displays
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                var list = new List<ExternalDisplay>();
                if (isLoaded)
                {
                    if (switchflag)
                    {
                        list = periodicalDashboards;
                        switchflag = false;
                    }
                    else
                    {
                        list = (from t in periodicalDashboards join x in initialDashboards on t.MonitorId equals x.MonitorId select new ExternalDisplay { MonitorName = x.MonitorName, DashboardName = x.DashboardName, DashboardId = x.DashboardId, XBound = x.XBound, TypeId = x.TypeId }).ToList();
                        switchflag = true;
                    }
                    foreach (ExternalDisplay item in list)
                    {
                        string dashboardUrl = ConfigurationManager.AppSettings["DashboardUrl"];
                        Screen display = (from sc in Screen.AllScreens where sc.Bounds.X == item.XBound select sc).FirstOrDefault();
                        DisplayDashboard.LoadDashboard(item.DashboardName, display, dashboardUrl + "?id=" + item.DashboardId + "&typeId=" + item.TypeId);
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Database Connection Checking..
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dbTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (!Utilities.IsDBRunning())
                {
                    Utilities.DetectAndSaveMonitors();
                    isDBRunning = false;
                    MessageBox.Show("Database is initialising please wait..");
                }
                else
                {
                    isDBRunning = true;
                    dbTimer.Tick -= dbTimer_Tick;
                }
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Creating context menu to assign to Notify Icon
        /// </summary>
        private void CreateContextMenu()
        {
            ContextMenu cmExitMenu = new ContextMenu();

            miDisplay = new MenuItem("Display");
            miExit = new MenuItem("Exit");
            miExit.Click += miExit_Click;
            miDisplay.Click += miDisplay_Click;
            cmExitMenu.MenuItems.Add(miDisplay);
            cmExitMenu.MenuItems.Add(miExit);
            notify.ContextMenu = cmExitMenu;
        }

        /// <summary>
        ///     Showing Form on click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void miDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                Utilities.DiposeFormsOnRefersh();

                FetchMappedDashboards();
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Dispose Form,notify ICon on click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void miExit_Click(object sender, EventArgs e)
        {
            try
            {
                notify.Icon.Dispose();
                notify.Dispose();
                Dispose();
            }
            catch (Exception ex)
            {
                log.Error("Error--", ex);
            }
        }

        /// <summary>
        ///     Html file Directory
        /// </summary>
        /// <returns></returns>
        private string GetViewDirectory()
        {
            return Path.Combine(Path.GetDirectoryName(new Uri(Assembly.GetEntryAssembly().CodeBase).LocalPath), "Ecolab_Dashboard");
        }

        /// <summary>
        ///     Double click on a title bar a.k.a. non-client area of the form
        /// </summary>
        /// <param name="m"></param>
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WMNCLBUTTONDBLCLK)
            {
                m.Result = IntPtr.Zero;
                return;
            }
            base.WndProc(ref m);
        }
    }
}