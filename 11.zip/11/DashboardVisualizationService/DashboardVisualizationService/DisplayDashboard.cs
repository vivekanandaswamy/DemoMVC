﻿// -----------------------------------------------------------------------
// <copyright file="DisplayDashboard.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Class to assign Dashboards to Monitors</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.DashboardVisualizationService
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows.Forms;
    using Xilium.CefGlue.WindowsForms;

    /// <summary>
    ///     The Class assigns Dashboards to Monitors
    /// </summary>
    public class DisplayDashboard
    {
        /// <summary>
        /// Assign Dashboards to the mapped Screens
        /// </summary>
        /// <param name="dashboardName">Dashboard Name</param>
        /// <param name="screen">The screen.</param>
        /// <param name="url">Dashboard Url</param>
        public static void LoadDashboard(string dashboardName, Screen screen, string url)
        {
            Form frm = new Form();
            frm.Name = dashboardName;
            frm.Text = dashboardName;
            frm.Top = screen.Bounds.Top;
            frm.Left = screen.Bounds.Left;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.StartPosition = FormStartPosition.Manual;
            frm.Height = screen.Bounds.Height;
            frm.Width = screen.Bounds.Width;
            Main.formControls.Add(frm);
            CefWebBrowser browser = new CefWebBrowser();
            browser.StartUrl = url;
            browser.Dock = DockStyle.Fill;
            frm.Controls.Add(browser);
            frm.ShowInTaskbar = false;
            frm.Show();
        }

        /// <summary>
        ///     Checking for Displays connected to PC
        /// </summary>
        /// <returns>boolean value</returns>
        public static bool CheckForConnectedDisplays()
        {
            bool connected = false;
            IEnumerable<Screen> displays = ( from screen in Screen.AllScreens select screen );
            if (displays.Count() > 1)
            {
                connected = true;
            }

            return connected;
        }
    }
}