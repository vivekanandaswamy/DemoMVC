﻿namespace Xilium.CefGlue
{
    /// <summary>
    ///     Key event types.
    /// </summary>
    public enum CefKeyEventType
    {
        RawKeyDown = 0,
        KeyDown,
        KeyUp,
        Char
    }
}