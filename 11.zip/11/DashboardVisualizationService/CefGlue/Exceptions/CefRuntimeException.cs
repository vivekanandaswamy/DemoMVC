﻿namespace Xilium.CefGlue
{
    using System;

    public class CefRuntimeException : Exception
    {
        public CefRuntimeException(string message) : base(message)
        {
        }
    }
}