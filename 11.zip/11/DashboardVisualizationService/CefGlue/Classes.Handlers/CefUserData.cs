﻿namespace Xilium.CefGlue
{
    public abstract partial class CefUserData
    {
    }
}