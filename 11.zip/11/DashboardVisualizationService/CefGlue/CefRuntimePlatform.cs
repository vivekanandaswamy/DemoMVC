﻿namespace Xilium.CefGlue
{
    public enum CefRuntimePlatform
    {
        Windows,
        Linux,
        MacOSX
    }
}