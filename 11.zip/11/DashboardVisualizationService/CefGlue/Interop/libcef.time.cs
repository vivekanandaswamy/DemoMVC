//
// This file manually written from cef/include/internal/cef_time.h.
//
// See also:
//   /Interop/Structs/cef_time_t.cs
//

namespace Xilium.CefGlue.Interop
{
    internal static partial class libcef
    {
    }
}