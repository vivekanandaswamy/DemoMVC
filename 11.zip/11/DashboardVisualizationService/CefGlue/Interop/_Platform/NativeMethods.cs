﻿namespace Xilium.CefGlue.Interop
{
    internal static class NativeMethods
    {
        public const int CW_USEDEFAULT = unchecked( (int) 0x80000000 );
    }
}